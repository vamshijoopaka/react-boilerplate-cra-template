import React from 'react';
import { connect } from 'react-redux';
import { compose } from 'redux';
import { injectIntl } from 'react-intl';

import Form from 'components/common/Form/Form';
import FieldInput from 'components/common/Form/FieldInput';
import {
    COLUMN_HEADER_ACCESSOR,
    COLUMN_VALUE_ACCESSOR
} from 'components/common/constants';
import ErrorMessageComponent from '../../components/common/ErrorMessageComponent';
import { withStyles } from '@material-ui/core/styles';

const styles = theme => ({
    simpleCardCheckbox: {
        '&.Mui-checked': {
            color: 'var(--primary-default)',
        },
        //E3C-32449, 8thJun2021, Thanuja
        '&.Mui-disabled': {
            color: 'var(--primary-disabled) !important'
        }
    },
});
class CheckboxRenderer extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            nameInput: false,
            inputValue: false,
            errorMessageLabel: null
        }
        this.setOnChangeValue = this.setOnChangeValue.bind(this);
    }

    componentDidMount(){
        let { props, onCellValueChanged, value, colDef } = this.props;
        this.setState({
            inputValue: value ? (Number(value) >=1 ? 1 : 0) : 0,
            errorMessageLabel: colDef[COLUMN_HEADER_ACCESSOR]
        })
    }

    setOnChangeValue(value) {
        const { rowIndex, column, data, colDef } = this.props;
        let columnName = !colDef.prefixFlag ? this.props.agGridReact.props.listPredecessor + colDef[COLUMN_VALUE_ACCESSOR].trim() : colDef[COLUMN_VALUE_ACCESSOR].trim();
        let newData = data;
        this.setState({
            inputValue: value
        })
        newData[columnName] = value;
        this.props.agGridReact.props.onValueChanged(data, rowIndex, column.colId.trim(), 'checkbox', newData, colDef, columnName, value);
    }

    render() {
        let { rowIndex, column, colDef, value, agGridReact, gridCallBack } = this.props;
        let key = 'gridCheckbox' + rowIndex + column.colId;
        return (
            <div>
                <Form>
                    {form => (
                        <FieldInput
                            gridCallBack={agGridReact.props.gridCallBack}
                            isFromGrid={true}
                            errorMessageLabels={agGridReact.props.errorMessageLabels}
                            errorMessageLabel={this.state.errorMessageLabel}
                            isCheckWildCard={colDef.isCheckWildCard}
                            fieldType={colDef.validationType}
                            value={this.state.inputValue}
                            disabled={(column.colId == 'LW' || column.colId == 'OW') || colDef.disabled}
                            field={{
                                type: 'checkbox', key: key
                            }}
                            onFocusOut={() => this.onFocusOut()}
                            onChange={(key, val, event) => {
                                this.setOnChangeValue(val);
                            }}
                            className={this.props.classes.simpleCardCheckbox}
                        />
                    )}
                </Form>
            </div>
        )
    }
}

export default withStyles(styles)(CheckboxRenderer);
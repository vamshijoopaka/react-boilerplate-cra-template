/*
 * CompanyProperties Messages
 *
 * This contains all the text for the CompanyProperties component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.CompanyProperties';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'This is the CompanyProperties component!',
  },
});

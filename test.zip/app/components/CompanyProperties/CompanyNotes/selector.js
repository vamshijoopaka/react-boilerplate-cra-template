const selectData = (state) => state.get('CompanyNotes');
//get company details from Global state_Begin 
const makeSelectCompanyDetails = (state) => state.get('app').get('companyDetails');
//get company details from Global state_End 

export {selectData, makeSelectCompanyDetails};
/*Changelog
* LogStart -- E3C-33396, 06-Dec-2021, Vamshi - 2022.1.0.0
              Creating Special Account History Option doesnt get refreshed and published on its own;
*/
import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core';
import FormFieldsGenerator from '../../../../common/FormFieldsGenerator';
import DialogComponent from '../../../../common/DialogComponent';
import BoxBorder from '../../../../../containers/common/BoxBorder';
import { TEXT_CANCEL, TEXT_OK } from '../../../../../containers/common/constants';

const styles = () => ({
  dialogClass: {
    minWidth: 'auto',
    maxWidth: '25rem',
    height: 'auto',
    borderRadius: 4
  },
  border: {
    margin: '1rem',
  }
});

class CreateSpecialAccountHistoryDialog extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      newAccountID: null,
    };
  }
  //E3C-31626 J Vamshi:Begin
  componentDidUpdate(prevProps, prevState) {
    //E3C-33396, 06-Dec-2021, Vamshi: Start
    const {
      newSplActCreated,
      open,
    } = this.props;
    if (newSplActCreated && open) {
      this.onClose();
    }
    //E3C-33396, 06-Dec-2021, Vamshi: End
  }
  //E3C-31626 J Vamshi:End
  onAccountIDChange = (key, value) => {
    this.setState({ newAccountID: value });
  };

  isDisabled = () => {
    if (this.state.newAccountID) {
      return false;
    }
    return true;
  };

  onClose = () => {
    this.setState({
      newAccountID: null,
    });
    this.props.onClose();
  };

  onSubmit = () => {
    this.props.onSubmit(this.state.newAccountID);
    // this.onClose();//E3C-31626 J Vamshi:
  };

  render() {
    const { classes, open, title, addSpecialAccountLabels } = this.props;
    return (
      <DialogComponent
        dialogTitle="28001"
        submitText={TEXT_OK}
        cancelText={TEXT_CANCEL}
        handleSubmit={this.onSubmit}
        handleCancel={this.onClose}
        handleClose={this.onClose}
        disableSubmit={this.isDisabled()}
        isOpen={open}
        className={classes.dialogClass}
      >
        <BoxBorder
          className={classes.border}
        >
          {
            addSpecialAccountLabels?.length ?
              <FormFieldsGenerator
                currentPage="items"
                fieldsArray={addSpecialAccountLabels}
                valuesArray={{ IACCT: this.state.newAccountID }}
                noMassMaintenance
                handleChangeValue={this.onAccountIDChange}
                valueDisplayCharacters={20}
              />
              : null
          }
        </BoxBorder>
      </DialogComponent>
    );
  }
}

CreateSpecialAccountHistoryDialog.propTypes = {
  classes: PropTypes.object,
  onClose: PropTypes.func,
  onSubmit: PropTypes.func,
  open: PropTypes.bool,
  title: PropTypes.string,
  onAccountIDChange: PropTypes.func,
  addSpecialAccountLabels: PropTypes.array,
};

export default withStyles(styles)(CreateSpecialAccountHistoryDialog);

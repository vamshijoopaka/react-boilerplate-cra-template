import {
    COLUMN_HEADER_ACCESSOR, 
    COLUMN_VALUE_ACCESSOR,
    COLUMN_SHOW_HIDE_FLAG,
    COLUMN_POSITION,
    COLUMN_HEADER_PREFIX_FLAG
} from '../common/constants';


export const DEFAULT_ACTION = 'app/MassmaintenancejobsListPage/DEFAULT_ACTION';
export const LOAD_MASSMAINTENANCEJOBS = 'app/MassmaintenancejobsListPage/LOAD_MASSMAINTENANCEJOBS';
export const LOAD_MASSMAINTENANCEJOBS_ERROR = 'app/MassmaintenancejobsListPage/LOAD_MASSMAINTENANCEJOBS_ERROR';
export const LOAD_MASSMAINTENANCEJOBS_SUCCESS = 'app/MassmaintenancejobsListPage/LOAD_MASSMAINTENANCEJOBS_SUCCESS';
export const SET_SEARCHPROPS = 'app/MassmaintenancejobsListPage/SET_SEARCHPROPS';
export const SET_SORTPROPS = 'app/MassmaintenancejobsListPage/SET_SORTPROPS';
export const SET_FILTERID = 'app/MassmaintenancejobsListPage/SET_FILTERID';
export const SET_ADVANCED_FILTERS = 'app/MassmaintenancejobsListPage/SET_ADVANCED_FILTERS';
export const SET_FILTERPROPS = 'app/MassmaintenancejobsListPage/SET_FILTERPROPS';
export const SET_PAGEPROPS = 'app/MassmaintenancejobsListPage/SET_PAGEPROPS';
export const SET_PROPERTIESPROPS = 'app/MassmaintenancejobsListPage/SET_PROPERTIESPROPS';
export const SET_MASSMAINTENANCEJOB_COLUMN_DEF = 'app/MassmaintenancejobsListPage/SET_MASSMAINTENANCEJOB_COLUMN_DEF';
export const LOAD_HEADER = 'app/LOAD_HEADER';
export const GET_MASSMAINTENANCEJOB_COLUMN_DEF = 'app/MassmaintenancejobsListPage/GET_MASSMAINTENANCEJOB_COLUMN_DEF';

export const MASSMAINTENANCEJOB_COLUMN_HEADER_ACCESSOR = "TLLAB";
export const MASSMAINTENANCEJOB_COLUMN_VALUE_ACCESSOR = "FDFNAM";
export const MASSMAINTENANCEJOB_COLUMN_POSITION = "FLDPOS";
export const MASSMAINTENANCEJOB_COLUMN_SHOW_HIDE_FLAG = "FLDSHW"
export const MASSMAINTENANCEJOB_COLUMN_HEADER_PREFIX_FLAG = "FDPRFX";

export const MASSMAINTENANCEJOB_PROPERTIES = {
    "headerName": COLUMN_HEADER_ACCESSOR,
    "field": COLUMN_VALUE_ACCESSOR,
    "showHideFlag": COLUMN_SHOW_HIDE_FLAG,
    "columnPosition": COLUMN_POSITION,
    "prefixFlag": COLUMN_HEADER_PREFIX_FLAG
}

export const PAGE_SIZES = [10, 20, 30];

export const MASSMAINTENANCEJOB_LIST_PAGE = "massmaintenancejobsListPage";

export const SET_MASSMAINTENANCEJOB_GLOBAL_FILTER_PROPS = "SET_MASSMAINTENANCEJOB_GLOBAL_FILTER_PROPS";

export const MASSMAINTENANCEJOBS_FILTER_OPTIONS = [{ "accessor": "JTYP", 'prefixFlag': 0, "key": "JTYP", "value": "MMN", "operator": "=", "fieldValue": "MMN", "jOpr": 'and', "serverString": "[JTYP]=MMN", "query": "Job Type = MMN" }];


export const INITIAL_PAGE_PROPS = {
    actualPage: 0,
    currentPage: 0,
    totalCount: 10,
    actualPageSize: 10,
    pageSize: 100,
    isPageSizeChanged: false,
    isForwardDirection: true
}

export const HAS_PAGINATION = true;
import React from 'react';
import { connect } from 'react-redux';
import { compose } from 'redux';
import { injectIntl } from 'react-intl';

import Form from 'components/common/Form/Form';
import FieldInput from 'components/common/Form/FieldInput';
import {
    COLUMN_HEADER_ACCESSOR,
    COLUMN_VALUE_ACCESSOR
} from 'components/common/constants';
import ErrorMessageComponent from '../../components/common/ErrorMessageComponent';
import {
    getUnformattedValue
} from 'utils/util';

class NumberRenderer extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            nameInput: false,
            inputValue: false,
            errorMessageLabel: null
        }
        this.setOnChangeValue = this.setOnChangeValue.bind(this);
        this.onFocusOut = this.onFocusOut.bind(this);
    }

    setOnChangeValue(value) {
        const { rowIndex, column, data, colDef, agGridReact } = this.props;

        let columnName = !colDef.prefixFlag ? this.props.agGridReact.props.listPredecessor + colDef[COLUMN_VALUE_ACCESSOR].trim() : colDef[COLUMN_VALUE_ACCESSOR].trim();
        let newData = JSON.parse(JSON.stringify(data));

        let unformattedValue = getUnformattedValue(value, agGridReact.props.globalNumberFormat, agGridReact.props.globalNumberSeparator, agGridReact.props.globalDecimalSeparator, colDef.numberType);
        this.setState({
            inputValue: unformattedValue
        })
        newData[columnName] = unformattedValue;
        this.props.agGridReact.props.onValueChanged(data, rowIndex, column.colId.trim(), 'number', newData, colDef, columnName, unformattedValue);
    }



    componentDidMount() {
        let { props, onCellValueChanged, value, colDef } = this.props;
        this.setState({
            inputValue: value.toString(),
            errorMessageLabel: colDef[COLUMN_HEADER_ACCESSOR]
        })
    }

    onFocusOut() {
        const { rowIndex, column, data, colDef, agGridReact } = this.props;
        let columnName = !colDef.prefixFlag ? this.props.agGridReact.props.listPredecessor + colDef[COLUMN_VALUE_ACCESSOR].trim() : colDef[COLUMN_VALUE_ACCESSOR].trim();
        let newData = JSON.parse(JSON.stringify(data));
        if ((Number(data[columnName]) != Number(this.state.inputValue)) && this.props.agGridReact.props.sendAPIcallOnChange) {
            newData[columnName] = this.state.inputValue;
            let unformattedValue = getUnformattedValue(this.state.inputValue, agGridReact.props.globalNumberFormat, agGridReact.props.globalNumberSeparator, agGridReact.props.globalDecimalSeparator);

            this.props.agGridReact.props.sendAPIcallOnChange(unformattedValue, rowIndex, column.colId, 'number', newData, colDef, columnName, unformattedValue);
        }
    }

    render() {
        let { rowIndex, column, colDef, value, agGridReact, gridCallBack } = this.props;
        let key = 'gridNumber' + rowIndex + column.colId;
        return (
            <div>
                <Form>
                    {form => (
                        <FieldInput
                            gridCallBack={agGridReact.props.gridCallBack}
                            isFromGrid={true}
                            errorMessageLabels={agGridReact.props.errorMessageLabels}
                            errorMessageLabel={this.state.errorMessageLabel}
                            isCheckWildCard={colDef.isCheckWildCard}
                            toUppercase={colDef.toUppercase}
                            numberType={colDef.numberType}
                            isNegative={colDef.isNegative}
                            precisionLength={colDef.precisionLength}
                            minValue={colDef.minValue}
                            maxValue={colDef.maxValue}
                            fieldType={colDef.validationType}
                            maxLength={colDef.maxLength}
                            value={this.state.inputValue}
                            disabled={(column.colId == 'LW' || column.colId == 'OW') || colDef.disabled}
                            field={{
                                type: 'number', key: key,
                                Attr: colDef.validationType ? colDef.validationType : ' '
                            }}
                            onFocusOut={() => this.onFocusOut()}
                            onChange={(key, val, event) => {
                                this.setOnChangeValue(val);
                            }}
                            globalNumberFormat={agGridReact.props.globalNumberFormat}
                            globalNumberSeparator={agGridReact.props.globalNumberSeparator}
                            globalDecimalSeparator={agGridReact.props.globalDecimalSeparator}
                        />
                    )}
                </Form>
            </div>
        );
    }
}


export default NumberRenderer;
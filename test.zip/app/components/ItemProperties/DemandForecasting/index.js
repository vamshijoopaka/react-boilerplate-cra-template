/*** ChangeLog
*LogStart - 2021.1.0.2 AWR
    E3C-33303 - J Vamshi 28-Oct-2021 : The Radio labels are displaying in multiple lines
* LogStart -- E3C-33396, 06-Dec-2021, Vamshi - 2022.1.0.0
              Creating Special Account History Option doesnt get refreshed and published on its own;
***/
import React from 'react';
import PropTypes from 'prop-types';
import Grid from '@material-ui/core/Grid';
import { withStyles } from '@material-ui/styles';
import ExceptionGraph from 'components/ItemProperties/DemandForecasting/ExceptionGraph';
import SeasonalityGraph from 'components/ItemProperties/DemandForecasting/SeasonalityGraph';
import AdjustmentGraph from 'components/ItemProperties/DemandForecasting/AdjustmentGraph';
import DemandTable from 'components/ItemProperties/DemandForecasting/DemandTable';
import FormFieldsGenerator from 'components/common/FormFieldsGenerator';
import CardComponent from 'components/common/CardComponent';
import { prepareValueDataForItems, getFormattedNumber, } from 'utils/util';
import { ITEMS_LIST_PAGE } from '../../common/constants';
import { ITEM_PROPERTIES, DEFAULT_VALUE_URL_DATA } from '../constants';
import SeasonalityTable from './SeasonalityTable';
import SpecialAccountHistory from './SpecialAccountHistory';
import { ACTIONS_CONTEXT_MENU } from './constants';
import { isEqual, mean, round } from 'lodash';
import moment from 'moment';
import { getDateFormatted } from '../../common/Form/dateTimeUtils';

const styles = () => ({
  pageContainer: {
    backgroundColor: 'var(--background-app)',
    padding: 10,
  },
  card: {
    padding: '0px',
    backgroundColor: 'var(--background-content)',
    borderRadius: '4px',
    margin: '8px',
    '& .MuiCardHeader-root': {
      padding: '16px 32px',
    },
    '& .MuiCardContent-root': {
      padding: '16px 32px',
    },
  },
  graphOptionsMinHeight: {
    minHeight: 463,
  },
  cardMinHeights: {
    minHeight: 550,
  },
  demand: {
    '& > div': {
      width: '100%',
      '& > div': {
        width: '100%',
        // E3C-33303, 28-Ot-2021, J Vamshi
        // '&:last-child': {
        //   width: 0,
        // },
        '& > label': {
          display: 'none',
        },
        '& > div': {
          width: '100%',
          '& fieldset': {
            width: '100%',
            '& > div': {
              display: 'grid',
              gridTemplateColumns: '16.66% 16.66% 16.66% 16.66% 16.66% 16.66%',
            },
          },
        },
      },
    },
  },
  orderControlFactors: {
    minHeight: 350,
    '& div.MuiCardContent-root': {
      '& > div': {
        '& > div': {
          display: 'grid',
          gridTemplateColumns: '50% 50%',
          '& > div': {
            marginLeft: 5,
            marginRight: 5,
            width: 'auto',
            '& > div': {
              // minWidth: '100%',
              '& > div': {
                width: '50% !important',
              },
            },
          },
        },
      },
    },
  },
  form: {},
  demandForecastingControl: {
    '& div.MuiCardContent-root': {
      '& > div': {
        '& > div': {
          display: 'grid',
          gridTemplateColumns: '25% 25% 25% 25%',
          '& > div': {
            marginLeft: 5,
            marginRight: 5,
            width: 'auto',
            '& > div': {
              minWidth: '100%',
              '& > div': {
                width: '50% !important',
              },
            },
          },
        },
      },
    },
  },
  label: {
    fontSize: '14px',
    fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
    color: 'var(--text)',
    float: 'right',
    padding: '0.5rem',
  },
});

class DemandForecasting extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      adjustmentEdit: false,
      selectedGraphType: 1,
      demandData: {
        demandType: this.props.openSpecialAccountHistory ? '5292343' : '50753',
      },
      data: { ...this.props.ItemPropertiesData.newValueData },
      simProfileMenuList: [...ACTIONS_CONTEXT_MENU],
      editedComposite: {},
    };
  }

  componentDidMount = () => {
    const {
      onDemandOptionChange,
      getSeasonalityGraphData,
      getExceptionGraphData,
      ItemPropertiesData,
      getSpecialAccountHistoryData,
      getSpecialAccountIDColumns,
    } = this.props;
    const { valueData, pageProps, seasonalityGraphOptions, } = ItemPropertiesData;
    if (onDemandOptionChange) {
      onDemandOptionChange(
        this.props.openSpecialAccountHistory ? '5292343' : '50753',
      );
    }
    if (getSeasonalityGraphData) {
      const data = prepareValueDataForItems(DEFAULT_VALUE_URL_DATA, {
        ...valueData,
      });
      const apiObj = this.getApiObj(data, null, ITEM_PROPERTIES, pageProps);
      if (valueData.IPERDF === '13') {
        this.rollGraphTo13();
      } else {
        this.showWeeklyData();
      }
      const isMonthly = valueData.IPERDF === '12';
      getExceptionGraphData({ data: apiObj, isMonthly });
      getSpecialAccountHistoryData(apiObj);
    }
    if (getSpecialAccountIDColumns) {
      getSpecialAccountIDColumns();
    }
    if (seasonalityGraphOptions?.series) {
      this.setInitialSimMenu();
    } else{
      this.setState({ simMenuNotSet: true });
    }

    this.getWarehouseDetails(valueData);
  };

  componentDidUpdate = prevProps => {
    const {
      getSeasonalityGraphData,
      getExceptionGraphData,
      ItemPropertiesData,
      getSpecialAccountHistoryData,
      getSpecialAccountIDColumns,
    } = this.props;
    const { valueData, pageProps, seasonalityGraphOptions,
      profileAccepted = false,
      itemSimulationInProgress = false,
      historyMultiplied = false,
      promoIncluded = false,
      rolledTo13 = false,
      adjustmentsApplied = false,
      specialAccountID,
      itemMiscData,
      newSplActCreated,
    } = ItemPropertiesData;
    if (
      (valueData && !isEqual(valueData, prevProps.ItemPropertiesData.valueData) && !itemSimulationInProgress) 
      || (historyMultiplied && historyMultiplied !== prevProps.ItemPropertiesData.historyMultiplied)
    ) {
      if (historyMultiplied) {
        this.props.setStoreKeyValue('historyMultiplied', false);
      }
      if (rolledTo13) {
        promoIncluded ? this.rollGraphTo13WithPromo() : this.rollGraphTo13();
      } else {
        promoIncluded ? this.showWeeklyDataWithPromo() : this.showWeeklyData();
      }
      if (getSpecialAccountIDColumns && !specialAccountID.columnDefs) {
        getSpecialAccountIDColumns();
      }
    }
    
    if (this.state.simMenuNotSet && seasonalityGraphOptions && !isEqual(seasonalityGraphOptions, prevProps.seasonalityGraphOptions)) {
      this.setState({ simMenuNotSet: false });
      this.setInitialSimMenu();
    }

    if (profileAccepted && profileAccepted !== prevProps.ItemPropertiesData.profileAccepted) {
      this.setInitialSimMenu();
    }

    if ( this.props.ItemPropertiesData.massSuccess && this.props.ItemPropertiesData.massSuccess != prevProps.ItemPropertiesData.massSuccess && this.props.tab == 5  ) {       //Fix for E3C-31590
      this.props.resetMassMaintenance()
      if (getSeasonalityGraphData) {
        const data = prepareValueDataForItems(DEFAULT_VALUE_URL_DATA, {
          ...valueData,
        });
        const apiObj = this.getApiObj(data, null, ITEM_PROPERTIES, pageProps);

        if (rolledTo13) {
          promoIncluded ? this.rollGraphTo13WithPromo() : this.rollGraphTo13();
        } else {
          promoIncluded ? this.showWeeklyDataWithPromo() : this.showWeeklyData();
        }

        const isMonthly = valueData.IPERDF === '12';
        getExceptionGraphData({ data: apiObj, isMonthly });
        getSpecialAccountHistoryData(apiObj);
      }
      if (getSpecialAccountIDColumns && !specialAccountID.columnDefs) {
        getSpecialAccountIDColumns();
      }
    }

    const keyFields = ['IITEM', 'IWHSE', 'IVNDR', 'ISUBV', 'ICOMP', 'IPERDF', 'IPERDH', 'ISUPER'];
    if (valueData && keyFields.some(key => valueData[key] !== prevProps.ItemPropertiesData.valueData[key])
      || (adjustmentsApplied && adjustmentsApplied !== prevProps.ItemPropertiesData.adjustmentsApplied)
    ) {
      if (adjustmentsApplied) {
        this.props.setStoreKeyValue('adjustmentsApplied', false);
        this.props.setStoreKeyValue('adjustmentsInProgress', false);
      }
      const data = prepareValueDataForItems(DEFAULT_VALUE_URL_DATA, {
        ...valueData,
      });
      const apiObj = this.getApiObj(data, null, ITEM_PROPERTIES, pageProps);
      const isMonthly = valueData.IPERDF === '12';
      getExceptionGraphData({ data: apiObj, isMonthly });
      getSpecialAccountHistoryData(apiObj);
      this.setState({ editedComposite: {}, simMenuNotSet: true });
      this.setSimProfileMenu('cancelSim');
    }
    if (valueData && valueData.IWHSE !== prevProps.ItemPropertiesData.valueData?.IWHSE) {
      this.getWarehouseDetails(valueData);
    }
    //E3C-33396, 06-Dec-2021, Vamshi: Start
    if (newSplActCreated && itemMiscData?.IMSPHS === "1") {
      this.demandOptionChange("demandType", "5292343");
      this.props.setStoreKeyValue('newSplActCreated', false);
    }
    if (itemMiscData?.IMSPHS === "0" && itemMiscData.IMSPHS !== prevProps.ItemPropertiesData?.itemMiscData?.IMSPHS) {
      this.demandOptionChange("demandType", "50753");
    }
    //E3C-33396, 06-Dec-2021, Vamshi: End
  };

  demandOptionChange = (key, value, field) => {
    const { onDemandOptionChange } = this.props;
    this.setState(prevState => {
      const { demandData } = prevState;
      demandData[key] = value;
      return {
        demandData,
      };
    });
    if (onDemandOptionChange) {
      onDemandOptionChange(value);
    }
  };

  getApiObj = (
    recordData,
    record = false,
    currentPage = ITEM_PROPERTIES,
    pageProps = false,
  ) => {
    let recordObj = false;
    if (record) {
      recordObj = record;
    }
    const apiObj = {
      recordData,
      pageProps,
      direction: pageProps.isForwardDirection,
      record: recordObj,
      currentPage,
      parentPage: ITEMS_LIST_PAGE,
    };
    return apiObj;
  };

  showWeeklyData = () => {
    const { getSeasonalityGraphData, ItemPropertiesData } = this.props;
    if (getSeasonalityGraphData) {

      this.props.setStoreKeyValue('rolledTo13', false);
      this.props.setStoreKeyValue('promoIncluded', false);

      const { valueData, pageProps } = ItemPropertiesData;
      const data = prepareValueDataForItems(DEFAULT_VALUE_URL_DATA, valueData);
      const apiObj = this.getApiObj(data, null, ITEM_PROPERTIES, pageProps);
      if (valueData.IPERDF === '12') {
        this.props.getSeasonalityGraphData12({
          data: apiObj,
          profileFraction: valueData.IDEM12,
          profileId: valueData.IDMPRF,
          includePromo: false,
        })
      }
      else {
        getSeasonalityGraphData(
          apiObj,
          null,
          null,
          null,
          `${valueData.IDMPRF}`,
          valueData.IDEM52,
        );
      }
    }
  };

  rollGraphTo13 = () => {
    const { getSeasonalityGraphDataRollTo13, ItemPropertiesData } = this.props;
    if (getSeasonalityGraphDataRollTo13) {
      this.props.setStoreKeyValue('rolledTo13', true);
      this.props.setStoreKeyValue('promoIncluded', false);
      const { valueData, pageProps } = ItemPropertiesData;
      const data = prepareValueDataForItems(DEFAULT_VALUE_URL_DATA, valueData);
      const apiObj = this.getApiObj(data, null, ITEM_PROPERTIES, pageProps);
      getSeasonalityGraphDataRollTo13(
        apiObj,
        `${valueData.IDMPRF}`,
        valueData.IDEM13,
      );
    }
  };

  showWeeklyDataWithPromo = () => {
    const { getPromoSeasonalityGraphData, ItemPropertiesData } = this.props;
    if (getPromoSeasonalityGraphData) {
      this.props.setStoreKeyValue('rolledTo13', false);
      this.props.setStoreKeyValue('promoIncluded', true);
      const { valueData, pageProps } = ItemPropertiesData;
      const data = prepareValueDataForItems(DEFAULT_VALUE_URL_DATA, valueData);
      const apiObj = this.getApiObj(data, null, ITEM_PROPERTIES, pageProps);
      if (valueData.IPERDF === '12') {
        this.props.getSeasonalityGraphData12({
          data: apiObj,
          profileFraction: valueData.IDEM12,
          profileId: valueData.IDMPRF,
          includePromo: true,
        })
      }
      else {
        getPromoSeasonalityGraphData(
          apiObj,
          `${valueData.IDMPRF}`,
          valueData.IDEM52,
        );
      }
    }
  };

  rollGraphTo13WithPromo = () => {
    const {
      getPromoSeasonalityGraphDataRollTo13,
      ItemPropertiesData,
    } = this.props;
    if (getPromoSeasonalityGraphDataRollTo13) {
      this.props.setStoreKeyValue('rolledTo13', true);
      this.props.setStoreKeyValue('promoIncluded', true);
      const { valueData, pageProps } = ItemPropertiesData;
      const data = prepareValueDataForItems(DEFAULT_VALUE_URL_DATA, valueData);
      const apiObj = this.getApiObj(data, null, ITEM_PROPERTIES, pageProps);
      getPromoSeasonalityGraphDataRollTo13(
        apiObj,
        `${valueData.IDMPRF}`,
        valueData.IDEM13,
      );
    }
  };

  onAdjust = () => {
    this.setState({
      adjustmentEdit: true,
    });
  };

  onCancelAdjust = () => {
    this.setState({
      adjustmentEdit: false,
    });
  };

  handleValueChange = (key, value, field) => {
    if (!value && value !== '') return;
    this.props.onChange('saveDemandValues');
    if (typeof this.props.setValueData === 'function') {
      this.props.setValueData({ key: `${key}`, val: value });
    }
  };

  getDatefromHistData = data => {
    let date;
    if (data === '0') return '';
    if (data !== '0') {
      date = getDateFormatted(data, this.props.globalDateFormat);//E3C-32862, J vamshi
      return date;
    }
    return date;
  };

  getMADPName = () => {
    const { ItemPropertiesData } = this.props;
    const { item } = ItemPropertiesData;
    if (item) {
      const { IPERDF } = item;
      return `MAD${IPERDF}`;
    }
    return 'MAD';
  };
  handleSimProfileMenuClick = key => {
    switch(key) {
      case 'simprofile': {
        this.setSimProfileMenu('simInProgress');
        this.props.getTempProfileId(this.props.currentOwnerName);
        break;
      }
      case 'acceptprofile': {
        this.handleAcceptProfile();
        break;
      }
      case 'simitem': {
        this.handleSimItem();
        break;
      }
      case 'cancel': {
        if (this.props.ItemPropertiesData.profileCreated) {
          this.props.cancelSimulateItem();
          this.deleteTempProfileId();
        }
        this.setSimProfileMenu('cancelSim');break;
      }
    }
  }
  setInitialSimMenu = () => {
    const { seasonalityGraphOptions } = this.props.ItemPropertiesData;
    if(seasonalityGraphOptions?.series) {
      const compositeData = seasonalityGraphOptions.series.find(ele => ele.key === "Composite")?.data;
      if (compositeData && compositeData.some(Boolean)) {
        this.setSimProfileMenu('cancelSim');
      }
    }
  }
  setSimProfileMenu = (type = 'simInProgress') => {
    if (!this.props.canUpdateComponent?.update) {
      this.setState({ simProfileMenuList: this.state.simProfileMenuList.map(ele => ({ ...ele, isDisable: true }))});
      return;
    }
    if(type === 'cancelSim') {
      this.setState(({ simProfileMenuList }) => {
        simProfileMenuList = simProfileMenuList.map(ele => {
          if (ele.key === 'simprofile')
            ele.isDisable = false;
          else
            ele.isDisable = true;
          return ele;
        })
        return {
          simProfileMenuList,
          simInProgress: false,
          editedComposite: {}
        }
      })
    }
    else if (type === 'simInProgress') {
      this.setState(({ simProfileMenuList }) => {
        simProfileMenuList = simProfileMenuList.map(ele => {
          if (ele.key === 'simprofile')
            ele.isDisable = true;
          else 
            ele.isDisable = false;
          return ele;
        })
        return {
          simProfileMenuList,
          simInProgress: true,
        }
      })
    } 
  }
  getSeasonalitySeries = seasonalityGraphOptions => {
    if (!seasonalityGraphOptions?.series) return [];
    const { getLabelFromId } = this.props;
    let series = JSON.parse(JSON.stringify(seasonalityGraphOptions.series));
    if (this.state.simInProgress) {
      const { editedComposite } = this.state;
      const { valueData: { IDEM13, IDEM52, IDEM12, IDEM01: demandForecastAnnual } = {} } = this.props.ItemPropertiesData;
      let compositeSeries = series.find(s => s.key === 'Composite');
      let profileSeries = series.find(s => s.key === 'Profile');

      if (!compositeSeries) return series || [];
      if (!profileSeries) {
        profileSeries = series.find(s => s.key === 'Forecast');
        if (profileSeries) {
          profileSeries.name = getLabelFromId("25237");
          profileSeries.key = 'Profile';
          profileSeries.displayId = '25237';
          profileSeries.visible = true;
        }
      }
      let demand = {
        13: round((demandForecastAnnual/52.143)*4, 2),
        52: round(demandForecastAnnual/52.143, 2),
        12: round(demandForecastAnnual/12, 2),
      }
      demand = demand[compositeSeries.data.length] || round(demandForecastAnnual/12, 2);
      let forecastSeries = {
        name: getLabelFromId('52794'),
        key: 'Forecast',
        displayId: '52794',
        data: Array(compositeSeries.data.length).fill(demand),
        type: 'spline',
        color: "#6ce07a",
      }

      for (let key in editedComposite) {
        compositeSeries.data[key] = +editedComposite[key];
      }
      let demandForecast = 1;
      if (IDEM13 && IDEM52 && IDEM12) {
        demandForecast = ({
          12: IDEM12,
          13: IDEM13,
          52: IDEM52,
        })[compositeSeries.data?.length] || 1;
      }
      const avgDemand = mean(compositeSeries.data);
      profileSeries.data = compositeSeries.data.map(val => round(val * demandForecast/ avgDemand, 2));
      // if (Object.keys(editedComposite).length) {
        compositeSeries.visible = true;
      // }
      series.push(forecastSeries);
    }
    return series;
  }
  handleCompositeChange = (key, value) => {
    if (typeof value === 'string' && value.includes(this.props.globalNumberSeparator))
      value = value.replace(new RegExp(this.props.globalNumberSeparator, "g"), '');
    this.setState(({ editedComposite }) => ({ editedComposite: { ...editedComposite, [key]: value } }))
  }
  prepareProfileAndActionPayload = () => {
    const {
      companyDetails: { CJDATE: systemDate = "" } = {},
      ItemPropertiesData: { tempProfileId: temp, valueData }
    } = this.props;
    let tempProfileId = temp;
    if (!temp) {
      tempProfileId = this.props.currentOwnerName + "9"; //Fallback
    }
    let profilePayload = {
      "PRECD": "008001",
      "PSTAT": "A",
      "PBIRDT": systemDate,
      "PPRFL": tempProfileId,
      "PPTYPE": "D",
      "PNAME": "",
      "PPERD": valueData.IPERDF === '12' ? "012": "052",
      "PMESG": "0",
      "PUSEDT": "0000000",
    }
    let actionPayload = {
      "IACOMP": valueData.ICOMP,
      "IAWHSE": valueData.IWHSE,
      "IAVNDR": valueData.IVNDR,
      "IAITEM": valueData.IITEM,
      "IAPROF": tempProfileId,
      "IAPINC": "5",
    };
    let compositeData = this.props.ItemPropertiesData.seasonalityGraphOptions?.series?.find(s => s.key === 'Composite')?.data;
    if (!compositeData) return {};

    for (let key in this.state.editedComposite) {
      compositeData[key] = +this.state.editedComposite[key];
    }

    const avgDemand = mean(compositeData);
    let profileData = compositeData.map(val => round(val / avgDemand, 2))

    if (profileData.length === 13) {
      let i = 0
      profileData.forEach((val) => {
        val = val.toString();
        profilePayload['PIX' + (`${i + 1}`.padStart(2, '0'))] = val;
        profilePayload['PIX' + (`${i + 2}`.padStart(2, '0'))] = val;
        profilePayload['PIX' + (`${i + 3}`.padStart(2, '0'))] = val;
        profilePayload['PIX' + (`${i + 4}`.padStart(2, '0'))] = val;
        i += 4;
      })
    }
    else if (profileData.length === 52) {
      profileData.forEach((val, i) => {
        val = val.toString();
        profilePayload['PIX' + (`${i + 1}`.padStart(2, '0'))] = val;
      })
    }
    else if (profileData.length === 12) {
      profileData.forEach((val, i) => {
        val = val.toString();
        profilePayload['PIX' + (`${i + 1}`.padStart(2, '0'))] = val;
      })
    }
    return { profilePayload, actionPayload };
  }
  handleAcceptProfile = () => {
    const { profileCreated = false } = this.props.ItemPropertiesData;
    let { profilePayload, actionPayload } = this.prepareProfileAndActionPayload();
    if (!profilePayload) return;
    this.props.acceptProfile({ profilePayload, actionPayload, profileCreated });
  }
  deleteTempProfileId = () => {
    const { tempProfileId, companyDetails: { CJDATE: systemDate } = {}, valueData } = this.props.ItemPropertiesData;
    let payload={
      "PRECD": "008001",
      "PSTAT": "D",
      "PBIRDT": systemDate,
      "PPRFL": tempProfileId,
      "PPTYPE": "D",
      "PPERD": valueData.IPERDF === '12' ? "012": "052",
    };
    this.props.deleteTempProfileId(payload);
  }
  handleSimItem = () => {
    const { profileCreated = false } = this.props.ItemPropertiesData;
    const { profilePayload, actionPayload } = this.prepareProfileAndActionPayload();
    if (!profilePayload) return;
    this.props.simulateItem({ profilePayload, actionPayload, profileCreated });
  }
  getIgnoreHistory = () => {
    const {
      getIgnoreHistory,
      ItemPropertiesData,
    } = this.props;
    if (getIgnoreHistory) {
      const { valueData, pageProps } = ItemPropertiesData;
      const data = prepareValueDataForItems(DEFAULT_VALUE_URL_DATA, valueData);
      const apiObj = this.getApiObj(data, null, ITEM_PROPERTIES, pageProps);
      const isMonthly = valueData.IPERDF === '12';
      getIgnoreHistory({ ...apiObj, isMonthly });
    }
  };
  hideValuesFromCurrentDate = ({data, year, index, columnDefs}) => {
    const { companyDetails: {CJDATE: systemDate}, ItemPropertiesData: { valueData: { IPERDF } = {} } = {} } = this.props;
    if (!systemDate || !IPERDF) return this.getFormattedNumber(data);

    const isMonthly = IPERDF === '12';

    const systemYear = systemDate.substr(0, 4);
    if (year != systemYear || index === 0) return this.getFormattedNumber(data);

    const systemMonth = moment(systemDate, 'YYYYDDD').format('MM');

    const month = columnDefs[index].substr?.(0, 2);
    if (isMonthly && !month) {
      return +systemMonth <= (index + 1) ? '' : this.getFormattedNumber(data);
    }
    return +systemMonth <= +month ? '' : this.getFormattedNumber(data);
  }
  getFormattedNumber = number => {
    if (!number) return number;
    return getFormattedNumber(number, this.props.globalNumberFormat, this.props.globalNumberSeparator, 0, this.props.globalDecimalSeparator)
  }
  getWarehouseDetails = valueData => {
    if (typeof this.props.getWarehouseDetails === 'function') {
      const queryString = `KCOMP=${valueData.ICOMP}&KWHSE=${valueData.IWHSE}`;
      this.props.getWarehouseDetails(queryString);
    }
  }
  render() {
    const {
      classes,
      labelsData,
      chartType,
      ItemPropertiesData,
      updateSpecialAccountHistoryData,
      openSpecialAccountHistoryDialog,
      onClose,
      onChange,
      globalDateFormat,
      filterCriteriaDetails,
      pageFilterOptions,
      globalFilterOptions,
      columnDefs,
      companyDetails,
      canUpdateComponent,
      setSaveData,
      getLabelFromId,
    } = this.props;
    const { selectedGraphType,
      simInProgress,
    } = this.state;
    const {
      seasonalityGraphOptions,
      exceptionGraphOptions,
      specialAccountHistoryOptions,
      specialAccountID,
      itemsEmbeddedList,
      specialAccountHistoryLabelData,
      item,
      adjustmentGraphOptions,
      valueData,
      newValueData,
      itemMiscData,
      adjustmentsInProgress = false,
      adjustmentGraphAPIData,
    } = ItemPropertiesData;
    if (!labelsData) {
      return null;
    }
    const { tabcards } = labelsData;
    if (!tabcards) {
      return null;
    }
    const optionsCard = tabcards.find(
      // tabcard => tabcard.cardtitle.trim() === 'Options',
      tabcard => tabcard.cardkey == "50758",
    );
    optionsCard.cardfields = optionsCard.cardfields.map(cardfield => ({
      ...cardfield,
      dataType: cardfield.FLDTYPE,
      labelPlacement: cardfield.FLDTYPE === 'checkbox' ? 'end' : undefined,
    }));
    let demandCard = tabcards.find(tabcard => tabcard.cardkey == '50757'/*tabcard.cardtitle === 'Demand'*/);
    
    if (demandCard?.cardfields?.length && itemMiscData?.IMSPHS === '0') {
      demandCard = JSON.parse(JSON.stringify(demandCard));//E3C-33396, 06-Dec-2021, Vamshi
      demandCard.cardfields = demandCard.cardfields.map(field => {
        return {
          ...field,
          valueSuggestionList: field.valueSuggestionList.filter(ele => ele.FLDID !== '5292343'),
        }
      })
    }

    const demandForecastCard = tabcards.find(
      // tabcard => tabcard.cardtitle.trim() === 'Demand Forecast',
      tabcard => tabcard.cardkey == '50888'
    );
    const orderControlFactorsCard = tabcards.find(
      // tabcard => tabcard.cardtitle.trim() === 'Order Control Factors',
      tabcard => tabcard.cardkey == '50916'
    );
    const disabledFields = [
      '3848',
      '3797',
      '3798',
      '3837',
      '3796',
      '50389',
      '51059',
      '3890',
    ];
    let disableOnSimProfile = false;
    if (simInProgress) {
      disabledFields.push('3891');
      disabledFields.push('3786');
      disableOnSimProfile = true;
    }
    const demandFactorsEnableFields = [];
    if (!demandForecastCard?.cardfields && !orderControlFactorsCard?.cardfields) {
      return null;
    }
    demandForecastCard.cardfields = demandForecastCard.cardfields.map(cardfield => {
      if (!demandFactorsEnableFields.includes(cardfield.FLDID)) {
        cardfield.disabled = disableOnSimProfile;
      }
      if (cardfield?.FLDID === '3760' && valueData.IPERDF !== '12') 
        return false; 
      if (cardfield?.FLDID === '3761' && valueData.IPERDF === '12') 
        return false; 
      return cardfield;
    }).filter(Boolean)
    //Override ManualSS if ManualSafetyStock is 2 or 1 and ManualSS < CalcSS;
    const overrideManualSS = (({ IPROWK, IDCMNQ, IDCOOD }) => {
      if (IPROWK && (IPROWK === '2') || (IPROWK === '1' && IDCMNQ < IDCOOD)) {
        return true;
      }
      return false;
    })(valueData);

    orderControlFactorsCard.cardfields = orderControlFactorsCard.cardfields
      .filter(cardfield => cardfield.TIDNO !== '33810')
      .map(cardfield => ({
        ...cardfield,
        disabled: disabledFields.includes(cardfield.FLDID),
        FDFNAM: (() => {
          if (cardfield.TIDNO === '50389') {
            const { IPERDF } = item;
            return `TRK${IPERDF}`;
          }
          return cardfield.TIDNO === '51059'
            ? this.getMADPName()
            : cardfield.FDFNAM;
        })(),
        TLLAB: (() => {
          if (cardfield.FDFILD === '3848') {
            return getLabelFromId(overrideManualSS ? '40154' : '33848');
          }
          return cardfield.TLLAB;
        })()
      }));
    let demandForecastingControlCard = tabcards.find(
      tabcard => tabcard.cardkey === '50903',
    );
    if (demandForecastingControlCard) {
      demandForecastingControlCard.cardfields = demandForecastingControlCard.cardfields.map(field => {
        let disabled = false;
        if (simInProgress) 
          disabled = true;
        if (field.FDFILD === '3784' && valueData) {
          let validValues = valueData.IPERDF === '12' ? ['12'] : ['13', '52'];
          field.valueSuggestionList = field.valueSuggestionList.filter(ele => validValues.includes(ele.value));
        }
        if (field.FDFILD === '9915' && valueData) {
          let validValues = valueData.IPERDF === '12' ? ['A', 'E', 'R'] : ['A', 'E', 'R', 'D'];
          field.valueSuggestionList = field.valueSuggestionList.filter(ele => validValues.includes(ele.value));
        }
        if (field.FLDID === '3923') {
          disabled = valueData.IXFLG1 !== 'E' || disabled;
        }
        return ({ ...field, disabled })
      });
    }
    let forecastMethod = "E3 Regular AVS Forecast";
    if (demandForecastingControlCard?.cardfields) {
      const forecast = valueData.IXFLG2 !== '0' ? valueData.IXFLG2 : valueData.IXFLG1;
      let label = demandForecastingControlCard.cardfields.find(field => field.FLDID === '9915')?.valueSuggestionList?.find(ele => ele.value === forecast)?.label;
      if (label) {
        label = label.split('-')[1]?.trim();
        forecastMethod = label;
      }
    }
    const isMonthly = valueData.IPERDF === '12';
    return (
      <Grid container className={classes.pageContainer}>
        <Grid item xs={12} style={{ padding: 0 }}>
          <CardComponent className={`${classes.card}`} title=" ">
            <Grid container>
              {demandCard && !simInProgress && !adjustmentsInProgress ? (
                <Grid
                  item
                  xs={12}
                  sm={12}
                  md={12}
                  lg={10}
                  xl={8}
                  style={{ padding: 0 }}
                >
                  <FormFieldsGenerator
                    fieldsArray={demandCard.cardfields}
                    className={classes.demand}
                    currentPage="itemproperties"
                    valuesArray={this.state.demandData || {}}
                    handleChangeValue={this.demandOptionChange}
                    canUpdateComponent={canUpdateComponent}
                    noMassMaintenance //E3C-33303,28-Oct-2021, J Vamshi
                  />
                </Grid>
              ) : null}
              {chartType === 'demandtable1' ? (
                <Grid item xs={12} sm={12} md={6} lg={4} xl={4}>
                  <FormFieldsGenerator
                    fieldsArray={optionsCard.cardfields}
                    currentPage="itemProperties"
                    valuesArray={this.state.optionsData || {}}
                    handleChangeValue={() => { }}
                    canUpdateComponent={canUpdateComponent}
                  />
                </Grid>
              ) : null}
            </Grid>
            {chartType === 'exception' ? (
              <ExceptionGraph
                series={
                  exceptionGraphOptions ? exceptionGraphOptions.series : []
                }
                categories={
                  exceptionGraphOptions ? exceptionGraphOptions.categories : []
                }
                getLabelFromId={getLabelFromId}
                isMonthly={isMonthly}
              />
            ) : null}
            {chartType === 'seasonality' ? (
              <SeasonalityGraph
                series={this.getSeasonalitySeries(seasonalityGraphOptions)}
                categories={
                  seasonalityGraphOptions
                    ? seasonalityGraphOptions.categories
                    : []
                }
                rollGraphTo13={this.rollGraphTo13}
                rollGraphTo13WithPromo={this.rollGraphTo13WithPromo}
                showWeeklyData={this.showWeeklyData}
                showWeeklyDataWithPromo={this.showWeeklyDataWithPromo}
                scrollable
                handleSimProfileMenuClick={this.handleSimProfileMenuClick}
                simProfileMenuList={this.state.simProfileMenuList}
                simInProgress={this.state.simInProgress}
                show3Dots
                rolledTo13={this.props.ItemPropertiesData.rolledTo13}
                promoIncluded={this.props.ItemPropertiesData.promoIncluded}
                getLabelFromId={getLabelFromId}
                handleCompositeChange={this.handleCompositeChange}
              />
            ) : null}
            {chartType === 'adjustment' ? (
              <AdjustmentGraph
                series={
                  adjustmentGraphOptions ? adjustmentGraphOptions.series : []
                }
                categories={
                  adjustmentGraphOptions
                    ? adjustmentGraphOptions.categories
                    : []
                }
                hideLegends={false}
                years={
                  seasonalityGraphOptions ? seasonalityGraphOptions.years : []
                }
                adjustmentData={
                  adjustmentGraphOptions ? adjustmentGraphOptions.adjustmentData : []
                }
                scrollable
                editable={this.state.adjustmentEdit}
                updateAdjustments={this.props.updateAdjustments}
                onChange={onChange}
                canUpdateComponent={canUpdateComponent}
                setSideBySideAdjustment={this.props.setSideBySideGraph}
                setYearToYearAdjustment={this.props.setYearToYearGraph}
                show3Dots
                cancelAdjustments={this.props.cancelAdjustments}
                setStoreKeyValue={this.props.setStoreKeyValue}
                adjustmentsInProgress={adjustmentsInProgress}
                adjustmentGraphAPIData={adjustmentGraphAPIData}
                valueData={valueData}
                adjustmentGraphType={this.props.ItemPropertiesData?.adjustmentGraphType || false}
                applyAdjustments={this.props.applyAdjustments}
                getLabelFromId={getLabelFromId}
                isMonthly={isMonthly}
                errorMessageLabels={this.props.errorMessageLabels}
                globalNumberFormat={this.props.globalNumberFormat}
                globalNumberSeparator={this.props.globalNumberSeparator}
                globalDecimalSeparator={this.props.globalDecimalSeparator}
              />
            ) : null}
            {chartType === 'demandtable' ? (
              <DemandTable
                series={
                  seasonalityGraphOptions ? seasonalityGraphOptions.series : []
                }
                columnDefs={
                  seasonalityGraphOptions
                    ? seasonalityGraphOptions.categories
                    : []
                }
                canUpdateComponent={canUpdateComponent}
                itemData={item}
                ignoreHistory={this.props.ignoreHistory}
                show3Dots
                rollGraphTo13={this.rollGraphTo13}
                rollGraphTo13WithPromo={this.rollGraphTo13WithPromo}
                showWeeklyData={this.showWeeklyData}
                showWeeklyDataWithPromo={this.showWeeklyDataWithPromo}
                rolledTo13={this.props.ItemPropertiesData.rolledTo13}
                promoIncluded={this.props.ItemPropertiesData.promoIncluded}
                getIgnoreHistory={this.getIgnoreHistory}
                ignoreHistoryData={this.props.ItemPropertiesData?.ignoreHistoryData || {}}
                historyIgnored={this.props.ItemPropertiesData?.historyIgnored}
                getLabelFromId={getLabelFromId}
                isMonthly={isMonthly}
                hideValuesFromCurrentDate={this.hideValuesFromCurrentDate}
                getSuperItemHistory={this.props.getSuperItemHistory}
                superHistoryRowData={this.props.ItemPropertiesData?.superHistoryRowData}
                superHistoryColDefs={this.props.ItemPropertiesData?.superHistoryColDefs}
                superHistoryCategories={this.props.ItemPropertiesData?.superHistoryCategories}
                superHistorySeries={this.props.ItemPropertiesData?.superHistorySeries}
                globalDateFormat={globalDateFormat}
                systemDate={companyDetails?.CJDATE}
                getFormattedNumber={this.getFormattedNumber}
              />
            ) : null}
            {chartType === 'multiplegraph' ? (
              <Grid container>
                <Grid item xs={12} sm={12} md={6} lg={4} xl={4}>
                  <SeasonalityGraph
                    series={
                      seasonalityGraphOptions
                        ? seasonalityGraphOptions.series
                        : []
                    }
                    categories={
                      seasonalityGraphOptions
                        ? seasonalityGraphOptions.categories
                        : []
                    }
                    rollGraphTo13={this.rollGraphTo13}
                    rollGraphTo13WithPromo={this.rollGraphTo13WithPromo}
                    showWeeklyData={this.showWeeklyData}
                    showWeeklyDataWithPromo={this.showWeeklyDataWithPromo}
                    scrollable={false}
                    hideLegends
                    getLabelFromId={getLabelFromId}
                  />
                </Grid>
                <Grid item xs={12} sm={12} md={6} lg={8} xl={8}>
                  <AdjustmentGraph
                    series={
                      adjustmentGraphOptions
                        ? adjustmentGraphOptions.series
                        : []
                    }
                    categories={
                      adjustmentGraphOptions
                        ? adjustmentGraphOptions.categories
                        : []
                    }
                    scrollable={false}
                    hideLegends
                    years={
                      seasonalityGraphOptions
                        ? seasonalityGraphOptions.years
                        : []
                    }
                    getLabelFromId={getLabelFromId}
                  />
                </Grid>
                <Grid
                  item
                  xs={12}
                  sm={12}
                  md={12}
                  lg={12}
                  xl={12}
                  style={{ paddingTop: 15 }}
                >
                  <DemandTable
                    series={
                      seasonalityGraphOptions
                        ? seasonalityGraphOptions.series
                        : []
                    }
                    columnDefs={
                      seasonalityGraphOptions
                        ? seasonalityGraphOptions.categories
                        : []
                    }
                    ignoreHistoryData={
                      seasonalityGraphOptions &&
                        seasonalityGraphOptions.ignoreHistoryData
                        ? seasonalityGraphOptions.ignoreHistoryData
                        : {}
                    }
                    canUpdateComponent={canUpdateComponent}
                    getLabelFromId={getLabelFromId}
                    hideValuesFromCurrentDate={this.hideValuesFromCurrentDate}
                  />
                </Grid>
              </Grid>
            ) : null}
            {chartType === 'specialAccountHistory' && specialAccountHistoryOptions?.series && Object.keys(specialAccountHistoryOptions.series)[0] != "undefined" ? (
              <SpecialAccountHistory
                series={
                  seasonalityGraphOptions ? seasonalityGraphOptions.series : []
                }
                categories={
                  seasonalityGraphOptions
                    ? seasonalityGraphOptions.categories
                    : []
                }
                getSpecialAccountHistory={
                  this.props.getSpecialAccountHistoryData
                }
                specialAccountHistoryOptions={specialAccountHistoryOptions}
                updateSpecialAccountHistoryData={
                  updateSpecialAccountHistoryData
                }
                specialAccountIDTableData={specialAccountID}
                openSpecialAccountHistoryDialog={
                  openSpecialAccountHistoryDialog
                }
                onClose={onClose}
                selectSpecialAccountHistory={
                  this.props.selectSpecialAccountHistory
                }
                onChange={onChange}
                getItemsEmbeddedListColumns={
                  this.props.getItemsEmbeddedListColumns
                }
                itemsEmbeddedList={itemsEmbeddedList}
                cardfields={
                  specialAccountHistoryLabelData
                    ? specialAccountHistoryLabelData.tabcards[0].cardfields
                    : []
                }
                specialAccountHistoryAction={
                  this.props.specialAccountHistoryAction
                }
                canUpdateComponent={canUpdateComponent}
                specialAccountUpd={this.props.specialAccountUpd}
                ItemData = {this.props.ItemPropertiesData.item}
              />
            ) : null}
          </CardComponent>
        </Grid>
        {chartType === 'seasonality' ? (
          <Grid xs={12} sm={12} md={12} lg={12} xl={12}>
            <CardComponent title="" className={classes.card}>
              <SeasonalityTable
                columnDefs={
                  seasonalityGraphOptions
                    ? seasonalityGraphOptions.categories
                    : []
                }
                series={
                  seasonalityGraphOptions ? seasonalityGraphOptions.series : []
                }
                profileIndices={
                  seasonalityGraphOptions
                    ? seasonalityGraphOptions.profileIndices
                    : []
                }
                simInProgress={this.state.simInProgress}
                globalNumberFormat={this.props.globalNumberFormat}
                globalNumberSeparator={this.props.globalNumberSeparator}
                errorMessageLabels={this.props.errorMessageLabels}
                handleCompositeChange={this.handleCompositeChange}
                compositeSeries={
                  this.getSeasonalitySeries(seasonalityGraphOptions)
                    .find(s => s.key === 'Composite')
                }
                globalDecimalSeparator={this.props.globalDecimalSeparator}
                getLabelFromId={getLabelFromId}
                hideValuesFromCurrentDate={this.hideValuesFromCurrentDate}
              />
            </CardComponent>
          </Grid>
        ) : null}
        {demandForecastCard ? (
          <Grid item xs={4} style={{ padding: 0 }}>
            <CardComponent
              title={`${forecastMethod}  ${this.getDatefromHistData(
                valueData.IACTDT,
              )} ${companyDetails.CFCVAV === '1'?'(S)':''}`}
              className={`${classes.card} ${classes.cardMinHeights}`}
            >
              <Grid item container>
                {+valueData.IACSLS ?
                  <Grid item xs={12}>
                    <label className={classes.label}>
                      {this.props.getLabelFromId('25248')} : {this.getDatefromHistData(valueData.IACSLS) /*E3C-32862 J Vamshi 25/6*/}
                    </label>
                  </Grid>
                  : null
                }
                <Grid item xs={12}>
                  <FormFieldsGenerator
                    key={demandForecastCard.cardkey}
                    className={classes.form}
                    parentPage={ITEMS_LIST_PAGE}
                    fieldsArray={demandForecastCard.cardfields.filter(
                      cardField =>
                        !['51008', '33790', '33752'].includes(cardField.TIDNO),
                    )}
                    valuesArray={newValueData}
                    handleChangeValue={this.handleValueChange}
                    enableAddButton={e => {
                      setSaveData(e);
                    }}
                    globalDateFormat={globalDateFormat}
                    filterCriteriaDetails={filterCriteriaDetails}
                    pageFilterOptions={pageFilterOptions}
                    globalFilterOptions={globalFilterOptions}
                    columnDefs={columnDefs}
                    currentPage="itemProperties"
                    parentData={newValueData}
                    labelDisplayCharacters={18}
                    valueDisplayCharacters={17}
                    canUpdateComponent={canUpdateComponent}
                  />
                </Grid>
                <Grid item xs={12}>
                  <FormFieldsGenerator
                    key={demandForecastCard.cardkey}
                    parentPage={ITEMS_LIST_PAGE}
                    className={classes.form}
                    fieldsArray={this.props.appendConditionalASR?.(demandForecastCard.cardfields.filter(
                      cardField => ['33790', '33752'].includes(cardField.TIDNO),
                    ))}
                    valuesArray={newValueData}
                    handleChangeValue={this.handleValueChange}
                    enableAddButton={e => {
                      setSaveData(e);
                    }}
                    globalDateFormat={globalDateFormat}
                    filterCriteriaDetails={filterCriteriaDetails}
                    pageFilterOptions={pageFilterOptions}
                    globalFilterOptions={globalFilterOptions}
                    columnDefs={columnDefs}
                    currentPage="itemProperties"
                    parentData={newValueData}
                    labelDisplayCharacters={18}
                    valueDisplayCharacters={17}
                    canUpdateComponent={canUpdateComponent}
                  />
                </Grid>
              </Grid>
            </CardComponent>
          </Grid>
        ) : null}
        <Grid item xs={4} style={{ padding: 0 }}>
          <CardComponent
            className={`${classes.card} ${classes.cardMinHeights}`}
            title={orderControlFactorsCard.cardtitle || ""}
          >
            <Grid item container>
              <Grid item xs={12}>
                <FormFieldsGenerator
                  fieldsArray={orderControlFactorsCard.cardfields}
                  currentPage="itemproperties"
                  className={classes.form}
                  valuesArray={newValueData}
                  handleChangeValue={this.handleValueChange}
                  // className="REFORECAST"
                  globalDateFormat={globalDateFormat}
                  filterCriteriaDetails={filterCriteriaDetails}
                  pageFilterOptions={pageFilterOptions}
                  globalFilterOptions={globalFilterOptions}
                  columnDefs={columnDefs}
                  parentData={newValueData}
                  labelDisplayCharacters={18}
                  valueDisplayCharacters={17}
                  canUpdateComponent={canUpdateComponent}
                  enableAddButton={e => {
                    setSaveData(e);
                  }}
                  parentPage={ITEMS_LIST_PAGE}
                />
              </Grid>
            </Grid>
          </CardComponent>
        </Grid>
        {demandForecastingControlCard ? (
          <Grid item xs={4} style={{ padding: 0 }}>
            <CardComponent
              className={`${classes.card} ${classes.cardMinHeights}`}
              title={demandForecastingControlCard.cardtitle}
            >
              <FormFieldsGenerator
                fieldsArray={demandForecastingControlCard.cardfields}
                currentPage="itemproperties"
                className={classes.form}
                valuesArray={{ ...newValueData, ...itemMiscData }}
                handleChangeValue={this.handleValueChange}
                globalDateFormat={globalDateFormat}
                filterCriteriaDetails={filterCriteriaDetails}
                pageFilterOptions={pageFilterOptions}
                globalFilterOptions={globalFilterOptions}
                columnDefs={columnDefs}
                parentData={newValueData}
                labelDisplayCharacters={18}
                valueDisplayCharacters={17}
                canUpdateComponent={canUpdateComponent}
                enableAddButton={e => {
                  setSaveData(e);
                }}
                cardHasCheckBox
                parentPage={ITEMS_LIST_PAGE}
              />
            </CardComponent>
          </Grid>
        ) : null}
      </Grid>
    );
  }
}

DemandForecasting.propTypes = {
  classes: PropTypes.object,
  labelsData: PropTypes.object,
  onDemandOptionChange: PropTypes.func,
  chartType: PropTypes.string,
  getSeasonalityGraphData: PropTypes.func,
  getSeasonalityGraphDataRollTo13: PropTypes.func,
  getPromoSeasonalityGraphData: PropTypes.func,
  getPromoSeasonalityGraphDataRollTo13: PropTypes.func,
  ItemPropertiesData: PropTypes.object,
  getExceptionGraphData: PropTypes.func,
  getSpecialAccountHistoryData: PropTypes.func,
  updateSpecialAccountHistoryData: PropTypes.func,
  getSpecialAccountIDColumns: PropTypes.func,
  specialAccountID: PropTypes.object,
  openSpecialAccountHistoryDialog: PropTypes.bool,
  onClose: PropTypes.func,
  selectSpecialAccountHistory: PropTypes.func,
  onChange: PropTypes.func,
  openSpecialAccountHistory: PropTypes.bool,
  getItemsEmbeddedListColumns: PropTypes.func,
  updateAdjustments: PropTypes.func,
  ignoreHistory: PropTypes.func,
  setSideBySideGraph: PropTypes.func,
  setYearToYearGraph: PropTypes.func,
};

export default withStyles(styles)(DemandForecasting);

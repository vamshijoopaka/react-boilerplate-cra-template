const TabsPanel = ({ children, tabs }) => {
  const { activeIndex } = tabs;
  return children[activeIndex] || null;
};

export default TabsPanel;

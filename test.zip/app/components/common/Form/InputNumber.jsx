
/*
* * //==========================================================================
*
* * // Copyright 2021-2021, Blue Yonder Group, Inc.
*
* * // All Rights Reserved
*
* * //
*
* * // THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF
*
* * // BLUE YONDER GROUP, INC.
*
* * //
*
* * //
*
* * // The copyright notice above does not evidence any actual
*
* * // or intended publication of such source code.
*
* * //
*
* * // ===========================================================================
*/
import classNames from 'classnames';
import PropTypes from 'prop-types';
import React, { Component } from 'react';
import { compose } from 'redux';
import { connect } from 'react-redux';

import TextField from '@material-ui/core/TextField';
import { ALLOWED_MODIFY_KEYS, ALLOWED_OPERATION_KEYS, ALLOWED_KEYS } from '../../../components/common/constants';
import { checkMaxMinCondition, prepareDefaultValues, getFormattedNumber, getUnformattedValue } from 'utils/util';
import {
  checkWildCards, validateNumbers, validateInputNumbers, checkBlankInput, postValidateInputNumber, validateControlKeys, checkMinCondition,
  checkMaxCondition
} from 'utils/fieldValidations';
import { getErrorLabels } from 'utils/handleErrorLabels';
import ErrorMessageComponent from '../ErrorMessageComponent';
import { POPUP_TIMEOUT } from 'utils/constants';
import { withStyles } from '@material-ui/core';
import GridErrorMessages from '../GridErrorMessages';
import MassMaintenance from 'containers/common/MassMaintenance';
import { createStructuredSelector } from 'reselect';
import OpenInNewIcon from '@material-ui/icons/OpenInNew';
import { validateInputFieldOnPaste } from '../../../utils/fieldValidations';
import CustomizedTooltip from '../CustomizedTooltip';
import {
  selectGlobalNumberFormat,
  selectGlobalNumberSeparator,
  selectGlobalDecimalSeparator,
  selectGlobalDateFormat// E3C-30525-Ajit
} from './selectors'


const defaultProps = {
  className: '',
  autoComplete: true,
  autoFocus: false,
  addValueOnPostValidation: false,
};

const propTypes = {
  className: PropTypes.string,
  field: PropTypes.shape({}).isRequired,
  onChange: PropTypes.func.isRequired,
  // onKeyDown: PropTypes.func.isRequired,
  value: PropTypes.any,
  autoComplete: PropTypes.bool,
  autoFocus: PropTypes.bool,
  maxLength: PropTypes.number,
  showTooltip: PropTypes.any,
  onFocusOut: PropTypes.any,
  addValueOnPostValidation: PropTypes.bool,
  preValue: PropTypes.number
};

const style = theme => ({
  inputNumberWrapper: {
    position: 'relative',
    display: 'flex',
    width: '100%'
  },
  inputWrapper: {
    width: '100%'
  },
  errorMessageWrapper: {
    display: 'flex',
    position: 'relative',
  }
});

class InputNumber extends Component {

  state = {
    isError: false,
    errorId: 0,
    values: [],
    globalNumberFormatOverride: 'en-IN',
    globalNumberSeparatorOverride: ',',
    globalDecimalSeparatorOverride: '.',
  }

  constructor() {
    super();
    this.onChange = this.onChange.bind(this);
    this.onValueChange = this.onValueChange.bind(this);
    this.setErrorId = this.setErrorId.bind(this);
    this.onBlur = this.onBlur.bind(this);
    this.showErrorTooltipPostValidate = this.showErrorTooltipPostValidate.bind(this);
    this.onFocus = this.onFocus.bind(this);
    this.onPaste = this.onPaste.bind(this);
  }

  onFocus() {
    const { onFocus } = this.props;
    this.setState({ showMassMaintainance: true });
    if (onFocus) {
      onFocus();
    }
  }

  setErrorId = (id) => {
    this.setState({ errorId: id });
  }

  showErrorTooltipPostValidate() {
    const { updateFieldError, field } = this.props;
    this.setState({ isError: true });
    if (updateFieldError) {
      updateFieldError(field, true)
    }
    this.setFieldError(true);
    return false;
  }

  onPaste(e) {
    const { maxValue, minValue, numberType,
      precisionLength, maxLength, updateFieldError, field } = this.props;
    let mL = maxLength ? Number(maxLength) : undefined;
    let max = maxValue ? Number(maxValue) : undefined;
    let min = minValue ? Number(minValue) : undefined;
    let value = this.props.value + e.clipboardData.getData('Text');
    value = getUnformattedValue(value, this.state.globalNumberFormatOverride, this.state.globalNumberSeparatorOverride, this.state.globalDecimalSeparatorOverride);
    let obj = validateInputFieldOnPaste(value, max, min, mL, precisionLength, numberType);
    if (!obj.isValid) {
      e.preventDefault();
      if (updateFieldError) {
        updateFieldError(field, true)
      }
      if (obj.errorId)
        this.setErrorId(obj.errorId);
      else
        this.setErrorId(512);
      this.showErrorTooltipPostValidate();
    }
  }

  onValueChange(keyEvent, enableAddButton) {
    const { maxValue, minValue, isNegative, numberType, errorMessageLabel, updateFieldError,
      precisionLength, value, maxLength, isCheckWildCard, gridCallBack, field,isDataExpression } = this.props;
    let mL = maxLength ? Number(maxLength) : undefined;
    let max = maxValue ? Number(maxValue) : undefined;
    let min = minValue ? Number(minValue) : undefined;
    let valueChanged = value ? value : "";
    let symbolsCount = 0;
    if(isDataExpression)
      return true
    if (this.state.globalDecimalSeparatorOverride == '.')
      symbolsCount = (valueChanged.substring(0, keyEvent.target.selectionStart).match(/\,/g) || []).length;
    else if (this.state.globalDecimalSeparatorOverride == ',')
      symbolsCount = (valueChanged.substring(0, keyEvent.target.selectionStart).match(/\./g) || []).length;
    let unformattedValue;
    if (value)
      unformattedValue = getUnformattedValue(value, this.state.globalNumberFormatOverride, this.state.globalNumberSeparatorOverride, this.state.globalDecimalSeparatorOverride, this.props.numberType);
    else
      unformattedValue = "";
    let obj = validateInputNumbers(keyEvent, (unformattedValue ? unformattedValue : ''), isNegative, numberType, min, max, precisionLength, mL, isCheckWildCard, this.setErrorId, symbolsCount, this.state.globalDecimalSeparatorOverride);
    if (obj.isValid) {
      this.setState({ isError: false });
      if (updateFieldError) {
        updateFieldError(field, false)
      }
      this.setFieldError(false)
      if (enableAddButton) {
        enableAddButton(true);
        if (!checkBlankInput(unformattedValue, keyEvent)) {
          enableAddButton(false);
        }
      }
      return true;
    }
    else {
      keyEvent.preventDefault();
      if (updateFieldError) {
        updateFieldError(field, true)
      }
      this.setFieldError(true);
      this.setState({ isError: true });
      if (enableAddButton) {
        enableAddButton(false);
      }
      setTimeout(
        () => {
          if (updateFieldError) {
            updateFieldError(field, false)
          }
          if (enableAddButton) {
            enableAddButton(true);      //Added by sachin
          }
          this.setState({ isError: false })
          this.setFieldError(false)
        }, POPUP_TIMEOUT);
      if (gridCallBack && obj.errorId) {
        gridCallBack("number",
          obj.errorId,
          errorMessageLabel,
          maxLength,
          precisionLength,
          minValue,
          maxValue);
      }
      return false;
    }
  }

  onChange(e) {
    const { field, onChange, numberType,isDataExpression } = this.props;
    const { key } = field;

    //comma seperator code
    // displayValue[key] = val;
    if(isDataExpression)
      onChange(key, e.currentTarget.value ? e.currentTarget.value : e.target.value, e);
    else
    {  
    let val = e.currentTarget.value ? e.currentTarget.value : e.target.value
    if (!val.includes(this.state.globalDecimalSeparatorOverride) && numberType == 'decimal')
      val = val.replaceAll(this.state.globalNumberSeparatorOverride, '')
    let value = getUnformattedValue(val, this.state.globalNumberFormatOverride, this.state.globalNumberSeparatorOverride, this.state.globalDecimalSeparatorOverride, numberType);

    onChange(key, value, e);
    }

  }



  onBlur(minValue, value, event) {
    const { onBlurMinValidate, onFocusOut, maxValue, onChange,
      field, isNegative, numberType, precisionLength, addValueOnPostValidation,
      preValue, updateFieldError, errorMessageLabel } = this.props;
    const { key, type } = field;
    let unformattedValue = getUnformattedValue(value, this.state.globalNumberFormatOverride, this.state.globalNumberSeparatorOverride, this.state.globalDecimalSeparatorOverride, this.props.numberType);
    let updatedValue = addValueOnPostValidation ? unformattedValue + preValue : (unformattedValue ? unformattedValue : "");

    let isMinMaxConditionValid = false
    const hasWildCard = updatedValue.includes('*')
    if (this.props.expressionLock) {
      if (!this.props.expressionLock && !this.props.newFieldLock)    //Added by sachin	
        isMinMaxConditionValid = checkMaxCondition(maxValue, Number(updatedValue), minValue) && checkMinCondition(minValue, updatedValue);
      else
        isMinMaxConditionValid = true;
    }
    else {
      if (hasWildCard) {
        isMinMaxConditionValid = true
      } else {
        isMinMaxConditionValid = checkMaxCondition(maxValue, Number(updatedValue), minValue) && checkMinCondition(minValue, updatedValue);
      }
    }


    //let isMinMaxConditionValid = checkMaxCondition(maxValue, Number(updatedValue), minValue) && checkMinCondition(minValue, updatedValue);

    if (!isMinMaxConditionValid) {
      if (updateFieldError) {
        updateFieldError(field, true);
      }
      this.setErrorId(506);
      this.showErrorTooltipPostValidate();
    }

    if (isMinMaxConditionValid || updatedValue == undefined) {
      this.setState({ isError: false });
      if (updateFieldError) {
        updateFieldError(field, false);
      }
      this.setFieldError(false)
    }

    if ((unformattedValue == "" || (unformattedValue && unformattedValue.length && unformattedValue.trim() == '')) && (minValue && Number(minValue) < 0)) {
      onChange(key, prepareDefaultValues(numberType, isNegative, precisionLength));
    }
    //to enable addbutton PASS onBlurPostvalidate as props 
    // onBlurPostValidate() takes an object as 
    if (onBlurMinValidate) onBlurMinValidate({ isMinMaxConditionValid });
    if (onFocusOut) onFocusOut();
    if (errorMessageLabel && errorMessageLabel.trim() !== "Year" && !hasWildCard) {
      let formattedNumber = value
      if (field.Attr && !field.Attr.includes('G'))
        formattedNumber = getFormattedNumber(value, this.state.globalNumberFormatOverride, this.state.globalNumberSeparatorOverride, precisionLength, this.state.globalDecimalSeparatorOverride, false, this.props.numberType);

      this.onChange(event, formattedNumber, key);
    }
    this.setFieldError(!isMinMaxConditionValid)
  }

  setFieldError = (val) => {
    if (this.props.setFieldError) {
      this.props.setFieldError(this.props.field, val);
    }
  }

  componentDidMount() {
    let prefobj = JSON.parse(localStorage.getItem('userpreferences'))
    if (prefobj['DECCH'] == ',')
      this.setState({ globalNumberSeparatorOverride: '.', globalDecimalSeparatorOverride: ',' })
    else
      this.setState({ globalNumberSeparatorOverride: ',', globalDecimalSeparatorOverride: '.' })
  }

  componentDidUpdate(prevProps) {
    const { hasError, errorCode, updateFieldError, field } = this.props;
    if (hasError && errorCode && (hasError !== prevProps.hasError)) {
      this.setState({ isError: hasError });
      this.setErrorId(errorCode);
      if (updateFieldError) {
        updateFieldError(field, hasError);
      }
      this.setFieldError(hasError);
      setTimeout(
        () => {
          if (updateFieldError) {
            updateFieldError(field, false);
          }
          enableAddButton(true);    //Added by sachin
          this.setFieldError(false);
          this.setState({ isError: false })
          if (this.props.clearErrorCode) {
            this.props.clearErrorCode();
          }
        }, POPUP_TIMEOUT);
    }

    if (prevProps.value !== this.props.value && this.props.value === "") {
      this.setState({ isError: false })
    }
  }
  render() {
    const { classes, className, field, value, autoComplete, autoFocus, onKeyDown, onFocus,
      disabled, maxLength, maxValue, minValue, isNegative, numberType, isFromGrid,
      precisionLength, errorMessageLabel, enableAddButton, showTooltip, onFocusOut, hasMassMaintainance, mmComponent, parentErrorClass } = this.props;
    const { key, placeholder, type } = field;
    const { fieldStyle } = this.props;
    let mL = maxLength ? Number(maxLength) : undefined;
    let max = maxValue ? Number(maxValue) : undefined;
    let min = minValue ? Number(minValue) : undefined;
    //let newvalue=value
    //Comma seperator code
    let newvalue = value
    if (Boolean(Number(value)) || Number(value) == 0) {
      if (field.Attr && !field.Attr.includes('G')) {
        newvalue = getFormattedNumber(value, this.state.globalNumberFormatOverride, this.state.globalNumberSeparatorOverride, field.precisionLength, this.state.globalDecimalSeparatorOverride, false, this.props.numberType);
        if (value && String(value).lastIndexOf(".") == value.length - 1) {
          newvalue += this.state.globalDecimalSeparatorOverride
        }
      }
      else
        newvalue = value
    }
    else if (value && value.toString().includes(this.state.globalNumberSeparatorOverride)) //if(this.state.globalNumberSeparatorOverride==',' && this.state.globalDecimalSeparatorOverride == '.')
    {
      let unformatvalue = getUnformattedValue(value, this.state.globalNumberFormatOverride, this.state.globalNumberSeparatorOverride, this.state.globalDecimalSeparatorOverride, this.props.numberType);
      newvalue = getFormattedNumber(unformatvalue, this.state.globalNumberFormatOverride, this.state.globalNumberSeparatorOverride, field.precisionLength, this.state.globalDecimalSeparatorOverride, false, this.props.numberType);

    }
    else
      newvalue = value

    //Comma seperator code

    return (<div className={classes.inputNumberWrapper}>
      <div onClick={this.onFocus} className={classes.inputWrapper}
        onBlur={() => { this.onBlur(minValue, value, event) }}>
        <CustomizedTooltip title={showTooltip && value ? value : ''}>
          <TextField
            className={classNames({
              input: true,
              'input-number': true,
              [className]: className,
            }) +
              (this.state.isError && errorMessageLabel ? ' error-input' : '')
            }
            autoFocus={autoFocus}
            id={key}
            onChange={this.onChange}
            onKeyDown={e => { this.onValueChange(e, enableAddButton); }}
            onPaste={e => { this.onPaste(e); }}
            placeholder={placeholder}
            type={'text'}
            value={newvalue}
            {...fieldStyle}
            {...(autoComplete ? {} : { autoComplete: 'off' })}
            disabled={disabled}
            onFocus={this.onFocus}
            autoComplete="off"
            inputProps={{
              // maxLength: mL,
              min: min,
              max: max
            }}
          >
          </TextField>
        </CustomizedTooltip>
      </div>
      {this.state.isError && errorMessageLabel && !isFromGrid &&
        <div className={classes.errorMessageWrapper} >
          <div className={"error-icon-pure-css " + parentErrorClass}></div>
          <ErrorMessageComponent
            id={this.state.errorId}
            replaceValues={getErrorLabels(
              this.state.errorId,
              errorMessageLabel,
              maxLength,
              precisionLength,
              minValue,
              getFormattedNumber(maxValue=='999999999.9999'?Math.round(maxValue):maxValue, this.state.globalNumberFormatOverride, this.state.globalNumberSeparatorOverride, null, this.state.globalDecimalSeparatorOverride, false),  //E3C-30006 , 6/29/21, Kumar
              this.state.globalDecimalSeparatorOverride
            )}
          >
          </ErrorMessageComponent>
        </div>
      }
    </div>
    );
  }
}
// const mapStateToProps = createStructuredSelector({
//   globalNumberFormatOverride: selectGlobalNumberFormat(),
//   globalNumberSeparatorOverride: selectGlobalNumberSeparator(),
//   globalDecimalSeparatorOverride: selectGlobalDecimalSeparator(),
//   globalDateFormatOverride: selectGlobalDateFormat()
// });
//const withConnect = connect(mapStateToProps, null);
InputNumber.defaultProps = defaultProps;
InputNumber.propTypes = propTypes;

//export default compose(withConnect, withStyles(style))(InputNumber);

export default compose(withStyles(style))(InputNumber);
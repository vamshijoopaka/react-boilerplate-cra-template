import { createSelector } from "reselect";

const errorMessageLabels = (state) => state.get('root').get('errorMessageLabels')


    const errorMessageLabelsFormat = () =>
    createSelector(
        errorMessageLabels, errorMessageLabels => errorMessageLabels
        )    


export {
   
    errorMessageLabelsFormat
};

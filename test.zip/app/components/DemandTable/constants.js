export const DEMAND_TABLE = "DemandTable";

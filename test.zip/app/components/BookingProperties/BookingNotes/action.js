import {GET_BOOKING_NOTES, GET_BOOKING_NOTES_SUCCESS, GET_BOOKING_NOTES_FAILURE, CLEAR_NOTES_DATA, GET_BOOKING_NOTE_DETAILS, GET_BOOKING_NOTE_DETAILS_SUCCESS,
    GET_BOOKING_NOTE_DETAILS_FAILURE, SET_BOOKING_SELECTED_NOTE_DETAILS, GET_BOOKING_NOTES_ALL_SUCCESS, CONTROL_BOOKING_NOTE_CREATION,
    CONTROL_BOOKING_NOTE_CREATION_SUCCESS, CONTROL_BOOKING_NOTE_CREATION_FAILURE, SET_BOOKING_NOTE_CONTROL_COUNT,
    REMOVE_BOOKING_NOTE_OF_KEY, CLEAR_BOOKING_NOTES, SET_IS_EMBEDDED_LIST, CLEAR_STATE_VALUES } from './constants';

export function getBookingNotes(data){
   return {
       type: GET_BOOKING_NOTES,
       data
   }
}
export function getBookingNotesSuccess(data){
   return {
       type: GET_BOOKING_NOTES_SUCCESS,
       data
   }
}
export function getBookingNotesFailure(data){
   return {
       type: GET_BOOKING_NOTES_FAILURE,
       data
   }    
}

export function clearNotesData() {
   return {
       type: CLEAR_NOTES_DATA
   }
}
export function getNoteDetails(data) {
   return {
       type: GET_BOOKING_NOTE_DETAILS,
       data
   }
}
export function getNoteDetailsSuccess(data) {
   return {
       type: GET_BOOKING_NOTE_DETAILS_SUCCESS,
       data
   }
}
export function getNoteDetailsFailure(data) {
   return {
       type: GET_BOOKING_NOTE_DETAILS_FAILURE,
       data
   }
}
export function getNoteDetailsAllSuccess(data) {
   return {
       type: GET_BOOKING_NOTES_ALL_SUCCESS,
       data
   }
}
export function setSelectedNoteDetails(data) {
   return {
       type: SET_BOOKING_SELECTED_NOTE_DETAILS,
       data
   }
}
export function controlNoteCreation(data) {
   return {
       type: CONTROL_BOOKING_NOTE_CREATION,
       data
   }
}
export function controlNoteCreationSuccess(data) {
   return {
       type: CONTROL_BOOKING_NOTE_CREATION_SUCCESS,
       data
   }
}
export function controlNoteCreationFailure(data) {
   return {
       type: CONTROL_BOOKING_NOTE_CREATION_FAILURE,
       data
   }
}
export function setControlNoteCount(data) {
   return {
       type: SET_BOOKING_NOTE_CONTROL_COUNT,
       data
   }
}
export function removeNoteByKey(data) {
   return {
       type: REMOVE_BOOKING_NOTE_OF_KEY,
       data
   }
}
export function clearAllBookingNotes() {
   return {
       type: CLEAR_BOOKING_NOTES
   }
}

export function setIsEmbeddedList() {
   return {
       type: SET_IS_EMBEDDED_LIST
   }
}
export function clearStateValues(){
   return{
       type: CLEAR_STATE_VALUES
   }
}
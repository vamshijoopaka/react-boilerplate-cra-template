import React from 'react';
import { withStyles } from '@material-ui/core/styles';
import { Table, TableHead, TableRow, TableBody, TableContainer, TableCell } from '@material-ui/core';
import { getDateFromJulian } from 'utils/util';
import { getDateFormatted } from '../../../common/Form/dateTimeUtils';
import '../style.scss';

const style = (theme) => ({
    pageContainer: {
        backgroundColor: 'var(--background-app)',
        borderTop: 'none',
        padding: '10px 20px',
    },
    pageContainerFifty: {
        width: '50%',
    },
    pageContainerThirty: {
        width: '30%',
        marginLeft: '20px',
    },
    tableBody:{
        borderRight: '1px solid black !important',
        borderLeft: '1px solid black !important',
        borderTop: '1px solid black !important',
        borderBottom: '1px solid black !important',
        minWidth:'190px'
    },
    cardWithborder: {
        border: '1px solid var(--secondary-s3)',
        borderRadius: '4px',
        padding: '10px',
        margin: '10px',
        width: '100%',
        backgroundColor: 'var(--secondary-s5)',
    },
    card: {
        padding: '0px',
        backgroundColor: 'var(--background-content)',
        borderRadius: '4px',
        width: '100%',
        margin: '10px',
        '& .MuiCardHeader-root': {
            padding: '16px 32px'
        },
        '& .MuiCardContent-root': {
            padding: '16px 32px'
        }
    },
    cardName: {
        fontWeight: '500',
        margin: '10px 0 20px 5px',
    },
    simpleCardGroup: {
        width: '100%',
        display: 'flex',
        justifyContent: 'space-around',
    },
    dashedBottomBorder: {
        borderBottom: '1px dashed var(--secondary-s21)',
        marginBottom: '20px',
    },
    marginLeftZero: {
        marginLeft: '0',
    },
    marginRightZero: {
        marginRight: '0',
    },
    unitDaysHeading: {
        display: 'grid',
        gridTemplateColumns: '50% 50%',
        gridGap: '2ch',
        padding: '0 1rem',
        '& #days': {
            paddingLeft: '120pt'
        },
    },
    tablecard: {
        padding: '0px',
        backgroundColor: 'var(--background-content)',
        borderRadius: '4px',
        width: '100%',
        margin: '10px',
        '& .MuiCardHeader-root': {
            padding: '8px 16px'
        },
        '& .MuiCardContent-root': {
            padding: '16px 32px'
        }
    },
    tableRow: {
        '&:nth-of-type(even)': {
            backgroundColor: 'var(--list-alternate-row)',
            color: 'var(--text) !important'
        }
    },
    tableWidth: {
        width: 'auto'
    },
    tableCellBorder: {
        border: '2px solid var(--list-divider-line)'
    },
    ignoreChecks: {
        display: "inline-block",
        position: "absolute",
        left: "36%",
        paddingTop: 5,
        [theme.breakpoints.down('sm')]: {
            left: '66%'
        }
    },
    cardHeight: {
        height: '96%'
    },
    floatTableParent: {
        position: 'absolute',
        top: '30%',
        width: '100%',
        marginLeft: '0.5rem'
    },
    floatTableChild: {
        width: '50%',
        float: 'right',
    },
    cardWrapperForFloatTable: {
        position: 'relative'
    },
    tableHead: {
        fontSize: "12px",
        color: 'black',
    }
});

class ForecastTable extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            fields: false,
            values: false,
            hasError: false,
            errorId: false,
            customCards: false,
            salesGraphCheck: false,
            depletionGraphCheck: false,
            hasHardError: false,
            dates: false
        };
    }

    getdateCount=(data)=>{
        const {valueData}=this.props.ItemPropertiesData;
        let periodicty = parseInt(valueData["IPERDH"]);
        let values={...data};
        let dateArray=[];
        if(periodicty==12){
            for(let i=0;i<12;i++){
                if (values[`MFPER${i + 1}`]!=='0'){
                    dateArray.push(values[`MFPER${i + 1}`]);
                }
            }
            return dateArray.length;
        } else if (periodicty == 52) {
            for (let i = 0; i < 52; i++) {
                if (values[`FPER${i + 1}`] !== '0') {
                    dateArray.push(values[`FPER${i + 1}`]);
                }
            }
            return dateArray.length;
        } else if (periodicty == 13) {
            for (let i = 0; i < 13; i++) {
                if (values[`PFPER${i + 1}`] !== '0') {
                    dateArray.push(values[`PFPER${i + 1}`]);
                }
            }
            return dateArray.length;
        }


    }
    render(){
        const { valueData, histDemRec, histForRec, histForFct, histForOvr} = this.props.ItemPropertiesData;
        const { classes, getLabelValue}=this.props;
        let count = histDemRec&&valueData ? this.getdateCount(histDemRec):null;
        return(
            <div>
                {(valueData["IPERDH"] == '13') ? (
                    <TableContainer>
                        <Table className={'TABLE_CELL'}>
                            <TableHead className={classes.tableHead}>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL1'} align="left" >{getLabelValue("25744")}</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_1'} align="left" >{this.props.dates[i]}</TableCell>)}
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL2'} align="left" >{getLabelValue("28365")}</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_2'} align="left" >{histDemRec[`PFED${i + 1}`]}</TableCell>)}
                                </TableRow>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL1'} align="left" >{getLabelValue("28366")}</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_1'} align="left" >{histDemRec[`PFAD${i + 1}`]}</TableCell>)}
                                </TableRow>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL2'} align="left" >{getLabelValue("28367")}</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_2'} align="left" >{histDemRec[`PFFD${i + 1}`]}</TableCell>)}
                                </TableRow>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL1'} align="left" >&nbsp;</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_1'} align="left" >&nbsp;</TableCell>)}
                                </TableRow>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL2'} align="left" >{getLabelValue("28364")}</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_2'} align="left" >{histForRec[`PFBF${i + 1}`]}</TableCell>)}
                                </TableRow>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL1'} align="left" >{getLabelValue("25745")}</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_1'} align="left" >{histForRec[`PFOF${i + 1}`]}</TableCell>)}
                                </TableRow>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL2'} align="left" >{getLabelValue("25746")}</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_2'} align="left" >{histForRec[`PFIX${i + 1 <= 9 ? "0" + (i + 1) : (i + 1)}`]}</TableCell>)}
                                </TableRow>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL1'} align="left" >{getLabelValue("25747")}</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_1'} align="left" >{histForRec[`PFFA${i + 1 <= 9 ? "0" + (i + 1) : (i + 1)}`]}</TableCell>)}
                                </TableRow>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL2'} align="left" >&nbsp;</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_2'} align="left" >&nbsp;</TableCell>)}
                                </TableRow>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL1'} align="left" >{getLabelValue("50389")}</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_1'} align="left" >{histForFct[`PFTK${i + 1 <= 9 ? "0" + (i + 1) : (i + 1)}`]}</TableCell>)}
                                </TableRow>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL2'} align="left" >{getLabelValue("51059")}</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_2'} align="left" >{histForFct[`PFMD${i + 1 <= 9 ? "0" + (i + 1) : (i + 1)}`]}</TableCell>)}
                                </TableRow>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL1'} align="left" >&nbsp;</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_1'} align="left" >&nbsp;</TableCell>)}
                                </TableRow>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL2'} align="left" >{getLabelValue("25748")}</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_2'} align="left" >{histForOvr[`PFBC${i + 1 <= 9 ? "0" + (i + 1) : (i + 1)}`]}</TableCell>)}
                                </TableRow>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL1'} align="left" >{getLabelValue("25749")}</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_1'} align="left" >{histForOvr[`PFDF${i + 1 <= 9 ? "0" + (i + 1) : (i + 1)}`]}</TableCell>)}
                                </TableRow>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL2'} align="left" >{getLabelValue("25750")}</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_2'} align="left" >{histForOvr[`PFOC${i + 1 <= 9 ? "0" + (i + 1) : (i + 1)}`]}</TableCell>)}
                                </TableRow>
                            </TableBody>
                        </Table>
                    </TableContainer>
                ) : null}
                {(valueData["IPERDH"] == '52') ? (
                    <TableContainer>
                        <Table className={'TABLE_CELL'}>
                            <TableHead className={classes.tableHead}>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL1'} align="left"  >{getLabelValue("25744")}</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_1'}/* className={'TABLE_CELL'} */ align="left"  >{this.props.dates[i]}</TableCell>)}
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL2'} align="left"  >{getLabelValue("28365")}</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_2'} align="left" >{histDemRec[`FED${i + 1}`]}</TableCell>)}
                                </TableRow>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL1'} align="left" >{getLabelValue("28366")}</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_1'} align="left" >{histDemRec[`FAD${i + 1}`]}</TableCell>)}
                                </TableRow>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL2'} align="left" >{getLabelValue("28367")}</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_2'} align="left" >{histDemRec[`FFD${i + 1}`]}</TableCell>)}
                                </TableRow>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL1'} align="left" >&nbsp;</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_1'} align="left"  >&nbsp;</TableCell>)}
                                </TableRow>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL2'} align="left" >{getLabelValue("28364")}</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_2'} align="left" >{histForRec[`FBF${i + 1}`]}</TableCell>)}
                                </TableRow>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL1'} align="left" >{getLabelValue("25745")}</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_1'} align="left"  >{histForRec[`FOF${i + 1}`]}</TableCell>)}
                                </TableRow>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL2'} align="left">{getLabelValue("25746")}</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_2'} align="left" >{histForRec[`FIX${i + 1 <= 9 ? "0" + (i + 1) : (i + 1)}`]}</TableCell>)}
                                </TableRow>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL1'} align="left" >{getLabelValue("25747")}</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_1'} align="left" >{histForRec[`FFA${i + 1 <= 9 ? "0" + (i + 1) : (i + 1)}`]}</TableCell>)}
                                </TableRow>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL2'} align="left">&nbsp;</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_2'} align="left" >&nbsp;</TableCell>)}
                                </TableRow>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL1'} align="left" >{getLabelValue("50389")}</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_1'} align="left" >{histForFct[`FTK${i + 1 <= 9 ? "0" + (i + 1) : (i + 1)}`]}</TableCell>)}
                                </TableRow>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL2'} align="left" >{getLabelValue("51059")}</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_2'} align="left" >{histForFct[`FMD${i + 1 <= 9 ? "0" + (i + 1) : (i + 1)}`]}</TableCell>)}
                                </TableRow>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL1'} align="left">&nbsp;</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_1'} align="left" >&nbsp;</TableCell>)}
                                </TableRow>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL2'} align="left">{getLabelValue("25748")}</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_2'} align="left" >{histForOvr[`FBC${i + 1 <= 9 ? "0" + (i + 1) : (i + 1)}`]}</TableCell>)}
                                </TableRow>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL1'} align="left">{getLabelValue("25749")}</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_1'} align="left" >{histForOvr[`FDF${i + 1 <= 9 ? "0" + (i + 1) : (i + 1)}`]}</TableCell>)}
                                </TableRow>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL2'} align="left">{getLabelValue("25750")}</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_2'} align="left" >{histForOvr[`FOC${i + 1 <= 9 ? "0" + (i + 1) : (i + 1)}`]}</TableCell>)}
                                </TableRow>
                            </TableBody>
                        </Table>
                    </TableContainer>
                ) : null}
                {(valueData["IPERDH"] == '12') ? (
                    <TableContainer>
                        <Table className={'TABLE_CELL'}>
                            <TableHead className={classes.tableHead}>
                                <TableRow>
                                <TableCell className={'TABLE_CELL1'} align="left" >{getLabelValue("25744")}</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_1'} align="left" >{this.props.dates[i]}</TableCell>)}
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL2'} align="left" >{getLabelValue("28365")}</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_2'} align="left" >{histDemRec[`MFED${i+1}`]}</TableCell>)}
                                </TableRow>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL1'} align="left" >{getLabelValue("28366")}</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_1'} align="left" >{histDemRec[`MFAD${i + 1}`]}</TableCell>)}
                                </TableRow>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL2'} align="left" >{getLabelValue("28367")}</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_2'} align="left" >{histDemRec[`MFFD${i + 1}`]}</TableCell>)}
                                </TableRow>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL1'} align="left" >&nbsp;</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_1'} align="left" >&nbsp;</TableCell>)}
                                </TableRow>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL2'} align="left" >{getLabelValue("28364")}</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_2'} align="left" >{histForRec[`MFBF${i + 1}`]}</TableCell>)}
                                </TableRow>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL1'} align="left" >{getLabelValue("25745")}</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_1'} align="left" >{histForRec[`MFOF${i + 1}`]}</TableCell>)}
                                </TableRow>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL2'} align="left" >{getLabelValue("25746")}</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_2'} align="left" >{histForRec[`MFIX${i + 1<=9?"0"+(i+1):(i+1)}`]}</TableCell>)}
                                </TableRow>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL1'} align="left" >{getLabelValue("25747")}</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_1'} align="left" >{histForRec[`MFFA${i + 1 <= 9 ? "0" + (i + 1) : (i + 1)}`]}</TableCell>)}
                                </TableRow>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL2'} align="left" >&nbsp;</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_2'} align="left" >&nbsp;</TableCell>)}
                                </TableRow>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL1'} align="left" >{getLabelValue("50389")}</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_1'} align="left" >{histForFct[`MFTK${i + 1 <= 9 ? "0" + (i + 1) : (i + 1)}`]}</TableCell>)}
                                </TableRow>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL2'} align="left" >{getLabelValue("51059")}</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_2'} align="left" >{histForFct[`MFMD${i + 1 <= 9 ? "0" + (i + 1) : (i + 1)}`]}</TableCell>)}
                                </TableRow>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL1'} align="left" >&nbsp;</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_1'} align="left" >&nbsp;</TableCell>)}
                                </TableRow>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL2'} align="left" >{getLabelValue("25748")}</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_2'} align="left" >{histForOvr[`MFBC${i + 1 <= 9 ? "0" + (i + 1) : (i + 1)}`]}</TableCell>)}
                                </TableRow>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL1'} align="left" >{getLabelValue("25749")}</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_1'} align="left" >{histForOvr[`MFDF${i + 1 <= 9 ? "0" + (i + 1) : (i + 1)}`]}</TableCell>)}
                                </TableRow>
                                <TableRow>
                                    <TableCell className={'TABLE_CELL2'} align="left" >{getLabelValue("25750")}</TableCell>
                                    {Array.from(Array(count), (_, i) => <TableCell className={'TABLE_CELL_2'} align="left" >{histForOvr[`MFOC${i + 1 <= 9 ? "0" + (i + 1) : (i + 1)}`]}</TableCell>)}
                                </TableRow>
                            </TableBody>
                        </Table>
                    </TableContainer>
                ) : null}
            </div>
           );
    }
}
ForecastTable.propTypes = {};

export default withStyles(style)(ForecastTable);
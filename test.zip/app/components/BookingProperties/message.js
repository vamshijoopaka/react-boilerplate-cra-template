/*
 * BookingProperties Messages
 *
 * This contains all the text for the BookingProperties component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.BookingProperties';

export default defineMessages({
    header: {
        id: `${scope}.header`,
        defaultMessage: 'This is the BookingProperties component!',
    },
});


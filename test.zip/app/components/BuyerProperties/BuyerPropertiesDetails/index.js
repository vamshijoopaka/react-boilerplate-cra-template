/*
 *
 * BuyerPropertiesPage 
 *
 */
/** Change Log
 * LogStart --  E3C-33046-Sachin, Introduce Vendor Type at Buyer Level
*/
import React from 'react';
import { compose } from 'redux';
import { withStyles } from '@material-ui/core/styles';
import PropTypes from 'prop-types';
import FormFieldsGenerator from '../../common/FormFieldsGenerator';
import {
  BUYER_BUYER_TOTALS,
  BUYER_PERSONAL_DATA,
  BUYER_EXCEPTION_TOTALS,
} from './constants';
import './style.scss';
import {
  BUYERS_LIST_PAGE,
  COLUMN_VALUE_ACCESSOR,
} from 'components/common/constants';
import CardComponent from '../../common/CardComponent';
const propTypes = {
  setSaveData: PropTypes.func,
};
import { Grid,Box } from '@material-ui/core';//E3C-33046 Ajit

import { getLabelToDisplay} from '../../../utils/util';

const style = () => ({
  pageContainer: {
    fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
    display: 'flex',
    backgroundColor: 'var(--background-app)',
    borderTop: 'none',
    padding: '15px 13px 15px 20px',
    overflowX: 'auto',
    borderRadius: '4px',
    overflow: 'hidden',
    boxShadow: '0 2px 4px var(--secondary-s10)',
  },
  pageContainerThirty: {
    width: '100%',
    flexFlow: 'wrap',
    display: 'flex',
    padding: '0px 10px 0px 0px',
  },
  card: {
    padding: '0px',
    backgroundColor: 'var(--background-content)',
    borderRadius: '4px',
    width: '100%',
    margin: '10px',
    '& .MuiCardHeader-root': {
      padding: '16px 32px',
    },
    '& .MuiCardContent-root': {
      padding: '16px 32px',
    },
  },
  simpleCardGroup: {
    width: '100%',
    display: 'flex',
    justifyContent: 'space-around',
  },
  marginLeftZero: {
    marginLeft: '0',
  },
  //E3C-33046 Ajit
  buyerTotalsCard: {
    '& div.MuiCardContent-root': {
      padding: '16px 32px',
      '& > div': {
        '& > div': {
          display: 'grid',
          gridTemplateColumns: '50% 50%',

        },
      },
    },
  },
    unitDaysHeading: {
      display: 'grid',
      gridTemplateColumns: '50% 50%',
      gridGap: '2ch',
      padding: '0 1rem',
      '& #days': {
        paddingLeft: '120pt'
      },  //Fix for E3C-33046,Sachin
    },
  
  //E3C-33046 Ajit
});

class BuyerPropertiesDetails extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      tabcards: false,
    };
    this.handleChangeValue = this.handleChangeValue.bind(this);
    this.getMessageText = this.getMessageText.bind(this)
  }
//Begin Fix for E3C-33046
  getMessageText = id => {
    const { messages } = this.props;
    if (messages && messages['H' + id]) {
      return messages['H' + id].TLLAB;
    }
    else if (+id) return id;
    else return '';
  }
//End E3C-33046
  handleChangeValue(key, val, field, setEnableDisable = true) {
    this.props.setValueData({ key, val, field });
    if (
      field.dataType === 'checkbox' ||
      field.dataType === 'select' ||
      field.dataType === 'date'
    ) {
      if (setEnableDisable) {
        let tabsData = this.setFieldEnableDisable(
          key,
          val,
          field,
          this.state.tabcards,
        );
        this.setState({ tabcards: tabsData });
      }
    }
  }

  setFieldEnableDisable = (key, value, field, tabsData) => {
    const { valueData } = this.props.BuyerPropertiesData;
    let valueDataUpdated = JSON.parse(JSON.stringify(valueData));
    valueDataUpdated = Object.assign({}, valueDataUpdated, { [key]: value });
    // fieldKey --- field changed
    // cardFieldKey --- field to be disabled
    let cardFieldKey,
      fieldKey = field[COLUMN_VALUE_ACCESSOR].trim();
    let tabcards = JSON.parse(JSON.stringify(tabsData));
    tabcards = tabcards.map(card => {
      card.cardfields = card.cardfields.map(cardField => {
        cardFieldKey = cardField[COLUMN_VALUE_ACCESSOR]
          ? cardField[COLUMN_VALUE_ACCESSOR].trim()
          : '';
        if (
          fieldKey === 'PLCTL' &&
          (cardFieldKey === 'ORCPW' || cardFieldKey === 'PLWRN') &&
          value > 0
        ) {
          cardField['disabled'] = false;
        } else if (
          fieldKey === 'PLCTL' &&
          (cardFieldKey === 'ORCPW' || cardFieldKey === 'PLWRN') &&
          value === 0
        ) {
          cardField['disabled'] = true;
        }

        return cardField;
      });
      return card;
    });
    return tabcards;
  };

  getValueData(valueData, newValueData) {
    if (
      Object.keys(valueData).length &&
      Object.keys(newValueData).length &&
      JSON.parse(JSON.stringify(valueData)) !==
      JSON.parse(JSON.stringify(newValueData))
    ) {
      return newValueData;
    }
    return valueData;
  }

  componentDidMount() {
    let tabsData = this.props.BuyerPropertiesData
      .buyerPropertiesDetailsLabelsData.tabcards;
    let valueForm = this.props.BuyerPropertiesData.valueData;

    if (tabsData) {
      tabsData.forEach(card => {
        card.cardfields.forEach(field => {
          if (field.key) {
            tabsData = this.setFieldEnableDisable(
              field.key,
              valueForm[field.key],
              field,
              tabsData,
              true,
            );
            if (field.hasCheckbox) {
              tabsData = this.setFieldEnableDisable(
                field.checkfieldJson.key,
                valueForm[field.checkfieldJson.key],
                field.checkfieldJson,
                tabsData,
                true,
              );
            }
          }
        });
      }); // to check the data
      this.setState({ tabcards: tabsData });
    }
  }

  render() {
    const {
      classes,
      setSaveData,
      globalDateFormat,
      filterCriteriaDetails,
      pageFilterOptions,
      globalFilterOptions,
      columnDefs,
      canUpdateComponent,
      currentOwnerName,
      currentPage,
    } = this.props;
    const { loading, valueData, newValueData } = this.props.BuyerPropertiesData;
    const { tabcards } = this.state;
    return (
      <div>
        {tabcards && tabcards.length ? (//E3C-32871, J Vamshi:
          <Grid container className={classes.pageContainer}>
            
            <Grid item xs={6} className={classes.pageContainerThirty}>
              {/* <h1>Card 1 - BUYER_PERSONAL_DATA </h1> */}
              {//E3C-32871, J Vamshi:
                tabcards.map(formCard => {
                  if (formCard.cardkey === BUYER_PERSONAL_DATA) {
                    return (
                      <CardComponent
                        title={formCard.cardtitle}
                        className={classes.card + ' ' + classes.marginLeftZero}
                      >
                        <FormFieldsGenerator
                          currentOwnerName={currentOwnerName}
                          cardHasDotsBtn={false}
                          cardHasCheckBox={false}
                          noMassMaintenance={true}
                          labelDisplayCharacters={20}
                          valueDisplayCharacters={20}
                          handleSubmitDataCallBack={
                            this.props.handleSubmitDataCallBack
                          }
                          key={formCard.cardkey}
                          parentPage={BUYERS_LIST_PAGE}
                          className={'BUYER_CONTROLS_FULL_GRID'}
                          fieldsArray={formCard.cardfields}
                          valuesArray={this.getValueData(
                            valueData,
                            newValueData,
                          )}
                          handleChangeValue={(key, val, field) =>
                            this.handleChangeValue(key, val, field)
                          }
                          enableAddButton={e => {
                            setSaveData(e);
                          }}
                          globalDateFormat={globalDateFormat}
                          filterCriteriaDetails={filterCriteriaDetails}
                          pageFilterOptions={pageFilterOptions}
                          globalFilterOptions={globalFilterOptions}
                          columnDefs={columnDefs}
                          currentPage={currentPage}
                          parentData={this.props.buyerData}
                          canUpdateComponent={canUpdateComponent}
                        />
                      </CardComponent>
                    );
                  }
                })}
              {//E3C-32871, J Vamshi:
                tabcards.map(formCard => {
                  if (formCard.cardkey === BUYER_EXCEPTION_TOTALS) {
                    return (
                      <CardComponent
                        title={formCard.cardtitle}
                        className={classes.card + ' ' + classes.marginLeftZero}
                      >
                        <FormFieldsGenerator
                          currentOwnerName={currentOwnerName}
                          cardHasDotsBtn={false}
                          cardHasCheckBox={false}
                          noMassMaintenance={true}
                          labelDisplayCharacters={20}
                          valueDisplayCharacters={40}
                          handleSubmitDataCallBack={
                            this.props.handleSubmitDataCallBack
                          }
                          key={formCard.cardkey}
                          parentPage={BUYERS_LIST_PAGE}
                          className={'BUYER_CONTROLS_FULL_GRID'}
                          fieldsArray={formCard.cardfields}
                          valuesArray={this.getValueData(
                            valueData,
                            newValueData,
                          )}
                          handleChangeValue={(key, val, field) =>
                            this.handleChangeValue(key, val, field)
                          }
                          enableAddButton={e => {
                            setSaveData(e);
                          }}
                          globalDateFormat={globalDateFormat}
                          filterCriteriaDetails={filterCriteriaDetails}
                          pageFilterOptions={pageFilterOptions}
                          globalFilterOptions={globalFilterOptions}
                          columnDefs={columnDefs}
                          currentPage={currentPage}
                          parentData={this.props.holdData}
                          canUpdateComponent={canUpdateComponent}
                        />
                      </CardComponent>
                    );
                  }
                })}
            </Grid>
            <Grid item xs={6} className={classes.simpleCardGroup}>
              {/* <h1>Card 3 - BUYER_BUYER_TOTALS </h1> */}
              {//E3C-32871, J Vamshi:
                tabcards.map(formCard => {
                  if (formCard.cardkey === BUYER_BUYER_TOTALS) {
                    return (
                      //Fix for E3C-33046,Sachin
                      <CardComponent
                        title={
                          <Box className={classes.unitDaysHeading}>
                            <label id="days" className={'MuiCardHeader-title'}>{this.getMessageText('99398')}</label>
                            <label className={'MuiCardHeader-title'}>{this.getMessageText('99399')}</label>
                          </Box>
                        } className={`${classes.card}`}
                      >
                        <FormFieldsGenerator
                          currentOwnerName={currentOwnerName}
                          cardHasDotsBtn={false}
                          cardHasCheckBox={false}
                          noMassMaintenance={true}
                          labelDisplayCharacters={20}
                          valueDisplayCharacters={40}
                          handleSubmitDataCallBack={
                            this.props.handleSubmitDataCallBack
                          }
                          key={formCard.cardkey}
                          parentPage={BUYERS_LIST_PAGE}
                          className={'BUYER_CONTROLS_TOTALS'}
                          fieldsArray={formCard.cardfields}
                          valuesArray={this.getValueData(
                            valueData,
                            newValueData,
                          )}
                          handleChangeValue={(key, val, field) =>
                            this.handleChangeValue(key, val, field)
                          }
                          enableAddButton={e => {
                            setSaveData(e);
                          }}
                          globalDateFormat={globalDateFormat}
                          filterCriteriaDetails={filterCriteriaDetails}
                          pageFilterOptions={pageFilterOptions}
                          globalFilterOptions={globalFilterOptions}
                          columnDefs={columnDefs}
                          currentPage={currentPage}
                          parentData={this.props.buyerData}
                          canUpdateComponent={canUpdateComponent}
                        />                        
                      </CardComponent>
                    );
                  }
                })}
            </Grid>
          </Grid>
        ) : null
        }{/* //E3C-32871, J Vamshi: */}
      </div >
    );
  }
}

BuyerPropertiesDetails.propTypes = propTypes;

export default compose(withStyles(style))(BuyerPropertiesDetails);

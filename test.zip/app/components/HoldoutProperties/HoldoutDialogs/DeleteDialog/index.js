import React, { Component } from 'react';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import { withStyles, Box } from '@material-ui/core';
import theme from '../../../../jda-gcp-theme';
import DialogComponent from 'components/common/DialogComponent';
import FormattedMessageComponent from '../../../common/FormattedMessageComponent';
import FormFieldsGenerator from '../../../common/FormFieldsGenerator';
import EmbeddedList from 'containers/common/EmbeddedList';
import Spinner from 'components/Common/Spinner';
import {
    DIALOG_TITLE_DELETE, TEXT_DELETE,
    FROM_WAREHOUSES, HOLDOUT_INFORMATION, MENU_ITEMS, HOLDOUTS_FILTER_VALUES, HOLDOUTS_DELETE,
    WAREHOUSE_PAGE, HOLDOUTS_PAGE
} from "./constants";
import { TEXT_CANCEL, TEXT_ALERT, TEXT_OK } from '../../../common/constants';
import { INITIAL_PAGE_PROPS } from 'components/common/constants';
import { getListPredecessor } from 'utils/util';
import reducer from './reducer';
import saga from './saga';
import ConfirmationDialog from 'components/common/ConfirmationDialog';
import {
    rowDataSelector,
    columnDefsSelector,
    loadingSelector,
    columnFlagSelector,
    pagePropsSelector,
    filterPropsSelector,
    columnInfoSelector,
    isAPIProgressSelector,
    totalCountSelector,
    moreRecordsSelector,
    apiCallCountSelector,
    updateColumnsListSelector,
    errorMessageLabels,
    holdoutsListSelector,
    makeSelectHoldoutDelete
} from './selector';
import {
    getHoldoutDeleteList,
    setApiCallCount,
    onSetPageProps,
    getHoldoutDeleteColumnDefs,
    setFilterValues,
    setColumnDefsLoaded,
    updateShowHide,
    resetStateData,
    resetDefault,
    getHoldoutsList,
    setLabelDataFlags
} from './action';

const styles = () => ({
    adjustDialog1: {
        maxHeight: '93vh',
        '& .MuiDialogContent-root': {
            padding: '12px'
        },
    },
    notesForBlock: {
        display: 'flex',
        flexDirection: 'column',
        marginTop: '25px',
        border: '1px solid var(--divider-line)',
        padding: '10px 10px 0 10px',
        position: 'relative'
    },
    notesForLabel: {
        position: 'absolute',
        top: '-7px',
        left: '10px',
        background: 'var(--background-content)',
        padding: '0 8px',
    },
    fieldValue: {
        color: 'var(--value)'
    },
    adjustCardFieldsInline: {
        display: 'grid !important',
        width: '100%',
        gridTemplateColumns: 'auto auto',
        '& label': {
            display: 'block !important',
            alignItems: 'center',
            whiteSpace: 'nowrap',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
        }
    },
});

class DeleteDialog extends Component {
    constructor(props) {
        super(props);
        this.state = {
            selectAllFlag: false,
            selectedCount: 0,
            selectedRecordsObject: {},
            menuItems: [...MENU_ITEMS],
            rowSelection: 'multiple',
            selectedRows: false,
            valueArrayToHoldout: {},
            deleteConfirmationDialog: false,
            valueDataFailureMessages: [],
            showValueConfirmationDialog: false,
        }
    }

    getLabelValue = (id) => +id ? <FormattedMessageComponent id={id} /> : id;

    setAssociativeArrayObject = (rowData) => {
        const { apiCallCount } = this.props;
        let str = apiCallCount + "buffer";
        let data = this.state.selectedRecordsObject;
        if (data && Object.keys(data) && rowData && rowData.length) {
            for (let key in data) {
                let recordData = data[key];
                if (recordData && recordData.length && (key == str)) {
                    recordData.forEach((record, index) => {
                        rowData[index]["isSelected"] = record.isSelected;
                    })
                }
            }
        }
        data[str] = rowData;
        this.setState({ selectedRecordsObject: data })
    }
    updateSelectAllFlag = (flag) => {
        const { rowData = [] } = this.props;
        this.setState({ selectAllFlag: flag, selectedCount: flag ? rowData.length : 0 });
    }
    changeValuesOnSelectDeselect = (flag) => {
        let recordObj = this.state.selectedRecordsObject;
        if (recordObj && Object.keys(recordObj)) {
            for (let key in recordObj) {
                if (recordObj[key] && recordObj[key].length) {
                    recordObj[key].forEach((record) => {
                        record.isSelected = flag;
                    })
                }
            }
        }
        this.setState({ selectedRecordsObject: recordObj })
    }
    onRowSelected = (event) => {
        if (this.grid && this.grid.api) {
            const { apiCallCount, pageProps } = this.props;
            const { actualPageSize, actualPage } = pageProps;
            let data = this.state.selectedRecordsObject;
            if (data && Object.keys(data) && Object.keys(data).length) {
                let key = apiCallCount + "buffer";
                let rowIndex = (event.rowIndex + (actualPageSize * actualPage)) % 100;
                const { selected } = event.node;
                data[key][rowIndex]['isSelected'] = selected;
                this.setState({ selectedRecordsObject: data });
                this.setState(() => ({ selectedCount: this.grid.api.getSelectedRows().length || 0 }))
            }
        }
    }
    getApiObj = (filterProps, record, pageProps, currentPage) => {
        let apiObj = {
            filterProps, filterProps,
            pageProps: pageProps,
            direction: pageProps.isForwardDirection,
            record: record,
            currentPage: currentPage //'warehouses'
        };
        return apiObj;
    }

    setPageForwardDirection = (flag) => {
        let initialPageData = {
            ...INITIAL_PAGE_PROPS,
            actualPage: 0,
            currentPage: 0,
            totalCount: 10,
            isForwardDirection: flag
        };
        this.setState({ initialPageData: initialPageData });
        this.props.onSetPageProps(initialPageData);
    }

    componentWillUnmount() {
        this.props.setColumnDefsLoaded(false);
        this.props.resetStateData(false)
    }
    componentDidMount() {
        const { headerJson, holdoutDetailData } = this.props;
        let valueArrayToHoldout = { ...holdoutDetailData }
        valueArrayToHoldout["VNAME"] = headerJson["HOVNAME"];
        valueArrayToHoldout["VSUBV"] = headerJson["HOSUBV"];
        valueArrayToHoldout["INAME"] = headerJson["HOINAME"];
        valueArrayToHoldout["HOWNAME"] = headerJson["HOWNAME"];
        valueArrayToHoldout["HOTSDT"] = headerJson["HOSDAT"];
        valueArrayToHoldout["HOTEDT"] = headerJson["HOEDAT"];
        valueArrayToHoldout["showDetail"] = 0;

        let filterData = [...HOLDOUTS_FILTER_VALUES];
        this.props.setFilterValues(filterData);
        this.setPageForwardDirection(true);
        this.props.getHoldoutDeleteColumnDefs({ type: HOLDOUTS_DELETE });

        this.setState({ valueArrayToHoldout });
    }

    componentDidUpdate(prevProps, prevState) {
        const { columnDefs, rowData, isColumnDefsLoaded, filterProps, pageProps, updateColumnsList, holdoutDetailData } = this.props;
        const {
            isAPIforHoldoutCopyList,
            isAPIforColumns,
            isAPIforColumnsUpdate,
            isAPIforResetColumns,
            isAPIforHoldoutList,
        } = this.props.holdoutsDelete
        if (this.state.valueDataFailureMessages && this.state.valueDataFailureMessages.length
            && (JSON.stringify(this.state.valueDataFailureMessages) != JSON.stringify(prevState.valueDataFailureMessages))) {
            this.handleValueDataErrorMessages(this.state.valueDataFailureMessages[0]);
        }

        if (isAPIforHoldoutCopyList && (isAPIforHoldoutCopyList != prevProps.holdoutsDelete.isAPIforHoldoutCopyList)) {
            let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
            values.push("Failed to fetch Warehouse List");
            this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
            this.props.setLabelDataFlags({ key: 'isAPIforHoldoutCopyList', value: false });
        }

        if (isAPIforColumns && (isAPIforColumns != prevProps.holdoutsDelete.isAPIforColumns)) {
            let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
            values.push("Failed to fetch columns For Warehouse Embeddedlist");
            this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
            this.props.setLabelDataFlags({ key: 'isAPIforColumns', value: false });
        }

        if (isAPIforColumnsUpdate && (isAPIforColumnsUpdate != prevProps.holdoutsDelete.isAPIforColumnsUpdate)) {
            let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
            values.push("Failed to update columns For Warehouse Embeddedlist");
            this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
            this.props.setLabelDataFlags({ key: 'isAPIforColumnsUpdate', value: false });
        }

        if (isAPIforResetColumns && (isAPIforResetColumns != prevProps.holdoutsDelete.isAPIforResetColumns)) {
            let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
            values.push("Failed to Rest columns For Warehouse Embeddedlist");
            this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
            this.props.setLabelDataFlags({ key: 'isAPIforResetColumns', value: false });
        }

        if (isAPIforHoldoutList && (isAPIforHoldoutList != prevProps.holdoutsDelete.isAPIforHoldoutList)) {
            let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
            values.push("Failed to fetch Holdouts List");
            this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
            this.props.setLabelDataFlags({ key: 'isAPIforHoldoutList', value: false });
        }

        let filterData = ['COMP', 'VNDR', 'ITEM', 'SDAT', 'EDAT', 'ACCT'].map(accessor => {
            let fieldValue = holdoutDetailData["HO" + accessor];
            if (/SDAT|EDAT/.test(accessor) && !+fieldValue)
                fieldValue = "0000000";
            return ({ accessor, 'prefixFlag': 0, "operator": "=", fieldValue });
        })
        
        if ((pageProps != prevProps.pageProps) && pageProps.isPageSizeChanged) {
            let initialPageData = {
                ...pageProps,
                actualPage: 0,
                currentPage: 0,
                totalCount: 10,
                isForwardDirection: true,
            };
            this.props.onSetPageProps({
                ...pageProps,
                isPageSizeChanged: false
            });
            this.props.setApiCallCount(0);
            this.props.getHoldoutDeleteList(this.getApiObj(filterProps, false, initialPageData, WAREHOUSE_PAGE));
            this.props.getHoldoutsList(this.getApiObj(filterData, false, initialPageData, HOLDOUTS_PAGE));
        }

        if (columnDefs != prevProps.columnDefs && isColumnDefsLoaded != prevProps.isColumnDefsLoaded) {
            if (isColumnDefsLoaded) {
                this.props.getHoldoutDeleteList(this.getApiObj(filterProps, false, pageProps, WAREHOUSE_PAGE));
                this.props.getHoldoutsList(this.getApiObj(filterData, false, pageProps, HOLDOUTS_PAGE));
            }
        }

        if (rowData != prevProps.rowData) {
            this.setAssociativeArrayObject(rowData)
        }

        if ((updateColumnsList != prevProps.updateColumnsList) && updateColumnsList) {
            this.props.getHoldoutDeleteColumnDefs({ type: HOLDOUTS_DELETE });
        }
        if ((prevState.selectAllFlag != this.state.selectAllFlag) || prevState.selectedCount != this.state.selectedCount) {
            if (this.state.selectAllFlag) {
                let deselectAllDisable = false, selectAllDisable = true;
                this.disableMenuItem(deselectAllDisable, selectAllDisable);
            }
            else if (!this.state.selectedCount) {
                let deselectAllDisable = true, selectAllDisable = false;
                this.disableMenuItem(deselectAllDisable, selectAllDisable);
            }
            else {
                this.disableMenuItem(false);

            }
        }
    }
    disableMenuItem = (deselectAllDisable, selectAllDisable) => {
        this.setState({
            menuItems: MENU_ITEMS.map(row => {
                let item = { ...row };
                if (item.key == 'deselectAll')
                    item.isDisable = deselectAllDisable;
                else if (item.key == 'selectAll' && selectAllDisable != undefined)
                    item.isDisable = selectAllDisable;
                return item;
            })
        })
    }

    getSelectedRowsForAPI = () => {
        let selectedRows = [];
        let recordObj = this.state.selectedRecordsObject;
        if (recordObj && Object.keys(recordObj)) {
            for (let key in recordObj) {
                let dataRecord = recordObj[key];
                if (dataRecord && dataRecord.length) {
                    dataRecord.forEach((record) => {
                        if (record.isSelected) {
                            selectedRows.push(record);
                        }
                    })
                }
            }
        }
        return selectedRows;
    }

    handleClose = () => {
        this.props.handleCopyDeletePopup('delete', false)
    }

    onGridReady = (params) => {
        this.grid = params;
    }

    //Create an array of Objects and send to api 
    handleSubmit = () => {
        const { filterProps, holdoutDetailData, headerJson } = this.props;
        let currentRecord = headerJson;
        let rowdata = this.getSelectedRowsForAPI();
        const { holdouts } = this.props;
        let selectedRows = rowdata.filter(row => holdouts.find(holdout => holdout.HOWHSE === row.WWHSE));
        if (this.state.selectAllFlag) {
            let filters = [{ "accessor": "HOCOMP", 'prefixFlag': 1, "operator": "=", "fieldValue": "E3T" },
            { "accessor": "HOVNDR", 'prefixFlag': 1, "operator": "=", "fieldValue": headerJson["HOVNDR"] },
            { "accessor": "HOITEM", 'prefixFlag': 1, "operator": "=", "fieldValue": headerJson["HOITEM"] },
            { "accessor": "HOACCT", 'prefixFlag': 1, "operator": "=", "fieldValue": headerJson["HOACCT"] },
            { "accessor": "HOSDAT", 'prefixFlag': 1, "operator": "=", "fieldValue": +holdoutDetailData["HOSDAT"] ? holdoutDetailData["HOSDAT"] : "0000000"},
            { "accessor": "HOEDAT", 'prefixFlag': 1, "operator": "=", "fieldValue": +holdoutDetailData["HOEDAT"] ? holdoutDetailData["HOEDAT"] : "0000000"}];
            let pageFilter = [...filterProps]
            this.props.onDeleteAll(selectedRows, { filterProps: filters, pageFilter, currentRecord, pageProps: { pageSize: 3 }, direction: true, currentPage: 'holdouts' });
        } else {
            let includesCurrent = selectedRows.find(row => row.WWHSE.trim() === currentRecord.HOWHSE.trim());

            let finalArray = this.prepareData(selectedRows)
            let listParams = includesCurrent ? { filterProps, pageProps: { pageSize: 3 }, direction: true, currentPage: 'holdouts' } : {}
            this.props.onSubmit(finalArray, includesCurrent, listParams);
            this.handleClose();
        }
        this.handleClose();
    }
    prepareData = data => {
        let dataArray = []
        const { headerJson, holdoutDetailData } = this.props;
        data.forEach(row => {
            let obj = {};
            obj['HOCOMP'] = holdoutDetailData['HOCOMP'],
                obj['HOWHSE'] = row['WWHSE'],
                obj['HOVNDR'] = holdoutDetailData['HOVNDR'],
                obj['HOITEM'] = headerJson['HOITEM'],
                obj['HOMFGI'] = holdoutDetailData['HOMFGI'],
                obj['HOUPCI'] = holdoutDetailData['HOUPCI'],
                obj['HOSDAT'] = holdoutDetailData['HOSDAT'],
                obj['HOEDAT'] = holdoutDetailData['HOEDAT'],
                obj['HOQNTY'] = holdoutDetailData['HOQNTY'],
                obj['HOOLTF'] = holdoutDetailData['HOOLTF'],
                obj['HOTYPE'] = holdoutDetailData['HOTYPE'],
                obj['HODEAL'] = holdoutDetailData['HODEAL'],
                obj['HOEVNT'] = holdoutDetailData['HOEVNT'],
                obj['HOACCT'] = holdoutDetailData['HOACCT'],
                obj['HOWSTN'] = holdoutDetailData['HOWSTN'],
                obj['HOSEQN'] = holdoutDetailData['HOSEQN'],
                obj['INAME'] = headerJson['INAME'],
                obj['HOSTOR'] = holdoutDetailData['HOSTOR'],
                obj['HOPLNI'] = holdoutDetailData['HOPLNI'],
                dataArray.push(obj);
        });
        return dataArray;
    }
    handleConfirmBeforeSubmit = (flag = true) => {
        this.setState({ deleteConfirmationDialog: flag })
    }

    closeValueDialog = () => {
        this.setState({ showValueConfirmationDialog: false });
        if (this.state.valueDataFailureMessages && this.state.valueDataFailureMessages.length) {
            let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
            values.shift();
            this.setState({ valueDataFailureMessages: values });
            if (values && values.length == 0) {
                this.handleClose();
            }
        }
    }
    handleValueDataErrorMessages = (content) => {
        this.setState({ showValueConfirmationDialog: true, dialogContent: content });
    }
    render() {
        const { classes, columnDefs, apiCallCount, loading, rowData, errorMessages, holdouts, deleteLabels, currentOwnerName,
            globalDateFormat, pageFilterOptions, canUpdateComponent,
            currentPage, globalFilterOptions } = this.props;

        const { valueArrayToHoldout } = this.state;

        const { tabcards } = deleteLabels;

        return (<React.Fragment>
            <DialogComponent
                className={classes.adjustDialog1}
                isOpen={this.props.openDeletePopup}
                dialogTitle={this.getLabelValue(DIALOG_TITLE_DELETE)}
                cancelText={TEXT_CANCEL}
                submitText={TEXT_DELETE}
                handleClose={() => this.handleClose()}
                handleCancel={() => this.handleClose()}
                handleSubmit={() => this.handleConfirmBeforeSubmit()}
                disableSubmit={(this.getSelectedRowsForAPI() && this.getSelectedRowsForAPI().length) ? false : true}>
                <React.Fragment>
                    <div className={classes.notesForBlock}>
                        <Box mb={theme.spacing(0.5)} className={classes.notesForLabel}>
                            {this.getLabelValue(HOLDOUT_INFORMATION)}
                        </Box>
                        {valueArrayToHoldout && tabcards && tabcards.map(formCard => {
                            if (formCard.cardkey == HOLDOUT_INFORMATION) {
                                return <FormFieldsGenerator
                                    labelDisplayCharacters={18}
                                    valueDisplayCharacters={22}
                                    className={classes.adjustCardFieldsInline}
                                    currentOwnerName={currentOwnerName}
                                    handleSubmitDataCallBack={() => { }}
                                    key={formCard.cardkey}
                                    fieldsArray={JSON.parse(JSON.stringify(formCard.cardfields))}
                                    valuesArray={JSON.parse(JSON.stringify(valueArrayToHoldout))}
                                    handleChangeValue={(key, val) => { this.handleChangeValue(key, val) }}
                                    enableAddButton={() => { }}
                                    globalDateFormat={globalDateFormat}
                                    pageFilterOptions={pageFilterOptions}
                                    globalFilterOptions={globalFilterOptions}
                                    columnDefs={columnDefs}
                                    currentPage={currentPage}
                                    canUpdateComponent={canUpdateComponent}
                                    noMassMaintenance={true}
                                />
                            }
                        })}
                    </div>
                    <div className={classes.notesForBlock}>
                        <Box mb={theme.spacing(0.5)} className={classes.notesForLabel}>
                            {this.getLabelValue(FROM_WAREHOUSES)}
                        </Box>
                        {!loading && valueArrayToHoldout && tabcards && tabcards.map(formCard => {
                            if (formCard.cardkey == FROM_WAREHOUSES) {
                                return <FormFieldsGenerator
                                    labelDisplayCharacters={22}
                                    valueDisplayCharacters={18}
                                    className={classes.adjustCardFieldsInline}
                                    currentOwnerName={currentOwnerName}
                                    handleSubmitDataCallBack={() => { }}
                                    key={formCard.cardkey}
                                    fieldsArray={JSON.parse(JSON.stringify(formCard.cardfields))}
                                    valuesArray={JSON.parse(JSON.stringify(valueArrayToHoldout))}
                                    handleChangeValue={(key, val) => { this.handleChangeValue(key, val) }}
                                    enableAddButton={() => { }}
                                    globalDateFormat={globalDateFormat}
                                    pageFilterOptions={pageFilterOptions}
                                    globalFilterOptions={globalFilterOptions}
                                    columnDefs={columnDefs}
                                    currentPage={currentPage}
                                    canUpdateComponent={canUpdateComponent}
                                    noMassMaintenance={true}
                                />
                            }
                        })}

                        {!loading && columnDefs && columnDefs.length && rowData && rowData.length ?
                            <EmbeddedList
                                pageProps={this.props.pageProps}
                                selectAllFlag={this.state.selectAllFlag}
                                updateSelectAllFlag={this.updateSelectAllFlag}
                                selectedRecordsObject={this.state.selectedRecordsObject}
                                hasSelectDeselectAll={true}
                                changeValuesOnSelectDeselect={this.changeValuesOnSelectDeselect}
                                updateMenuItems={() => { }}
                                suppressRowClickSelection={true}
                                onRowSelected={this.onRowSelected}
								props={this.props}
								listProps={this.props}
                                currentPage={"warehouses"}
                                listPredecessor={getListPredecessor("warehouses")}
                                rowSelection={this.state.rowSelection}
                                suppressSizeToFit={true}
                                nameSpace={"holdoutsDelete"}
                                onGridReady={this.onGridReady}
                                rowData={rowData.filter(row => holdouts.find(holdout => holdout.HOWHSE === row.WWHSE))}
                                updateShowHide={(data) => this.props.updateShowHide({ ...data, type: HOLDOUTS_DELETE })}
                                resetDefault={() => this.props.resetDefault({ type: HOLDOUTS_DELETE })}
                                menuItems={this.state.menuItems}
                                onSelectAll={(data) => this.onSelectAll(data)}
                                columnDefs={columnDefs}
                                columnInfo={this.props.columnInfo}
                                gridHeight={'250px'}
                                totalCount={apiCallCount * 100 + (rowData.filter(row => holdouts.find(holdout => holdout.HOWHSE === row.WWHSE)).length)}
                                hasGridActions={true}>
                            </EmbeddedList> : <Spinner loading type="list" />}


                    </div>
                    {this.state.deleteConfirmationDialog &&
                        <ConfirmationDialog
                            isOpen={this.state.deleteConfirmationDialog}
                            dialogTitle={this.getLabelValue('52891')}
                            cancelText={TEXT_CANCEL}
                            submitText={TEXT_OK}
                            handleClose={() => this.handleConfirmBeforeSubmit(false)}
                            handleCancel={() => this.handleConfirmBeforeSubmit(false)}
                            handleSubmit={() => this.handleSubmit()}>
                            <div>
                                {errorMessages ? errorMessages['E12042']?.['MTEXT'] : 'Confirmation'}
                            </div>
                        </ConfirmationDialog>
                    }
                    {this.state.showValueConfirmationDialog && <ConfirmationDialog
                        hasError={true}
                        isOpen={this.state.showValueConfirmationDialog}
                        dialogTitle={TEXT_ALERT}
                        submitText={TEXT_OK}
                        handleClose={() => this.closeValueDialog()}
                        handleCancel={() => this.closeValueDialog()}
                        handleSubmit={() => this.closeValueDialog()}
                    >
                        <div>
                            {this.state.dialogContent}
                        </div>
                    </ConfirmationDialog>
                    }
                </React.Fragment>
            </DialogComponent>

        </React.Fragment>
        );
    }
}
const mapStateToProps = createStructuredSelector({
    holdoutsDelete: makeSelectHoldoutDelete(),
    rowData: rowDataSelector(),
    columnDefs: columnDefsSelector(),
    loading: loadingSelector(),
    pageProps: pagePropsSelector(),
    isColumnDefsLoaded: columnFlagSelector(),
    filterProps: filterPropsSelector(),
    columnInfo: columnInfoSelector(),
    isAPIProgress: isAPIProgressSelector(),
    totalCount: totalCountSelector(),
    moreRecordsAvailable: moreRecordsSelector(),
    apiCallCount: apiCallCountSelector(),
    updateColumnsList: updateColumnsListSelector(),
    errorMessages: errorMessageLabels(),
    holdouts: holdoutsListSelector(),
})

function mapDispatchToProps(dispatch, ownProps) {
    return {
        dispatch,
        getHoldoutDeleteList: (data) => dispatch(getHoldoutDeleteList(ownProps.nameSpace, data)),
        setApiCallCount: (data) => dispatch(setApiCallCount(ownProps.nameSpace, data)),
        onSetPageProps: (data) => dispatch(onSetPageProps(ownProps.namespace, data)),
        getHoldoutDeleteColumnDefs: (data) => dispatch(getHoldoutDeleteColumnDefs(ownProps.nameSpace, data)),
        setFilterValues: (data) => dispatch(setFilterValues(ownProps.nameSpace, data)),
        setColumnDefsLoaded: (data) => dispatch(setColumnDefsLoaded(ownProps.nameSpace, data)),
        updateShowHide: (data) => dispatch(updateShowHide(ownProps.nameSpace, data)),
        resetStateData: (data) => dispatch(resetStateData(ownProps.nameSpace, data)),
        resetDefault: (data) => dispatch(resetDefault(data)),
        getHoldoutsList: (data) => dispatch(getHoldoutsList(ownProps.nameSpace, data)),
        setLabelDataFlags: (data) => dispatch(setLabelDataFlags(ownProps.nameSpace, data)),
    }
}

const withConnect = connect(
    mapStateToProps,
    mapDispatchToProps,
);
const withReducer = injectReducer({ key: 'holdoutDeleteReducer', reducer });
const withSaga = injectSaga({ key: 'holdoutDeleteSaga', saga });
export default compose(
    withReducer,
    withSaga,
    withConnect,
    withStyles(styles),
)(DeleteDialog);

/*
 *
 * BuyerProperties
 *
 */
/** Change Log
 * LogStart --  E3C-33046-Sachin, Introduce Vendor Type at Buyer Level
*/

import React from 'react';
import { compose } from 'redux';
import { withRouter } from 'react-router-dom';
import { Formik } from 'formik';

import {
  getListPredecessor,
  prepareValueDataForBuyers,
  getUpdateRestrictionOnComponent,
  capitalizeFirstLetter,
  setNumberFields,
  getFilterDataFromLocalStorage,
  getFilterDataFromCriteriaDetails,
  handleFieldValuesByLength,
} from 'utils/util';
import { withStyles } from '@material-ui/core';
import FormattedMessageComponent from 'components/common/FormattedMessageComponent';
import {
  getDBSelectorFilterValues,
  prepareTooltipValues,
} from 'utils/filterData';

import { isEqual } from 'lodash';
import GridErrorMessages from 'components/common/GridErrorMessages';

import './styles.scss';

import { onChangeContextMenu,updateBreadCrumbContextMenu } from 'utils/contextMenu';
import ConfirmationDialog from 'components/common/ConfirmationDialog';
import DeleteDialog from './BuyerDialogs/DeleteDialog';
import {
  BUYERS_LIST_PAGE,
  BUYER_PROPERTIES_PAGE,
  INITIAL_PAGE_PROPS,
  COLUMN_VALUE_ACCESSOR,
  GLOBAL_FILTER_OPTIONS,
  TEXT_ALERT,
  TEXT_OK,
  COLUMN_FIELD_LEN,
} from '../common/constants';
import Spinner from '../common/Spinner';
import {
  BUYER_PROPERTIES,
  DEFAULT_VALUE_URL_DATA,
  LABEL_LIST_URL_DATA,
  FILTER_DATA,
  ORDER_LIST,
  BRACKET_LABEL_URL_DATA
} from './constants';
import Filter from '../../containers/common/Filter';
import BuyerPropertiesDetails from './BuyerPropertiesDetails';
import Header from './Header';
import BuyerNotes from './BuyerNotes';

const style = () => ({
  hideContent: {
    display: 'none',
  },
  showContent: {
    display: 'block',
  },
});

class BuyerProperties extends React.Component {
  constructor() {
    super();
    this.state = {
      isSaveDataDisabled: true,
      headerData: false,
      buyerName: '',
      columnDefs: [],
      buyerDataJSON: [],
      stateData: false,
      updatedNotes: false,
      totalCount: 0,
      fromPage: false,
      hasError: false,
      ServerError: false,
      updatedFieldValues: {},
      selectedRow: null,
      canUpdateComponent: false,
      changeDataAPI: false,
      openFilterPopup: false,
      bracketsNotesFilterObj: {},
      isFiltersChanged: false,
      previousFilterValues: false,
      showConfirmationDialog: false,
      dialogTitle: '',

      hasWarning: false,
      fromListPage: null,
      hasFiltersChanged: false,
      isDataLoaded: false,
      isInitialAPICall: true,
      valueDataFailureMessages: [],
      notesFilterObj: {},
      notesCount: 0,
      notesCountWidth: '22px',
    };

    this.setNotesCount = this.setNotesCount.bind(this);
    this.prepareHeaderDataJSON = this.prepareHeaderDataJSON.bind(this);
    this.handleBuyerHeaderLeftArrowClick = this.handleBuyerHeaderLeftArrowClick.bind(
      this,
    );
    this.handleBuyerHeaderRightArrowClick = this.handleBuyerHeaderRightArrowClick.bind(
      this,
    );
    this.getApiObj = this.getApiObj.bind(this);
    this.makeAPICallForPageUpDown = this.makeAPICallForPageUpDown.bind(this);
    this.getApiObjForPageUpDown = this.getApiObjForPageUpDown.bind(this);
    this.handleSubmitDataCallBack = this.handleSubmitDataCallBack.bind(this);
    this.setHeaderAndSendAPI = this.setHeaderAndSendAPI.bind(this);
    this.setBuyerColumnDefs = this.setBuyerColumnDefs.bind(this);
    this.getLabelValue = this.getLabelValue.bind(this);
    this.setRecordDataValues = this.setRecordDataValues.bind(this);
    this.forceUpdateHandler = this.forceUpdateHandler.bind(this);
    this.setFilterValuesFromState = this.setFilterValuesFromState.bind(this);
    this.onFieldValueChange = this.onFieldValueChange.bind(this);
    this.onRowSelectedChange = this.onRowSelectedChange.bind(this);
    this.handleBuyerHeaderFilterClick = this.handleBuyerHeaderFilterClick.bind(
      this,
    );
    this.sendAPICallForValues = this.sendAPICallForValues.bind(this);
    this.handleNoDataSets = this.handleNoDataSets.bind(this);

    this.handleValueDataErrorMessages = this.handleValueDataErrorMessages.bind(
      this,
    );
  }

  handleNoDataSets() {
    const { buyerPropertiesDetailsLabelsData } = this.props.BuyerPropertiesData;
    if (this.state.isDataLoaded) {
      if (
        buyerPropertiesDetailsLabelsData &&
        Object.keys(buyerPropertiesDetailsLabelsData) &&
        Object.keys(buyerPropertiesDetailsLabelsData).length
      ) {
        // do nothing here
      } else {
        this.props.setNoDataCallBackValue(true);
        const paramsString = window.location.search;
        if (paramsString && paramsString.length) {
          const paramsArray = paramsString.split('?');
          if (paramsArray && paramsArray.length && paramsArray.length > 1) {
            const params = paramsArray[1].split('&');
            const tabId = params[0].split('=')[1];
            const breadCrumbId = params[1].split('=')[1];
            this.props.removeCurrentRecordObj(tabId, breadCrumbId);
          }
        }
      }
    }
  }

  handleBuyerHeaderFilterClick() {
    if (
      this.state.isFiltersChanged &&
      this.props.BuyerPropertiesData.isValueDataAPIFailure
    ) {
      this.props.onSetFilterProps(this.state.previousFilterValues);
      this.props.setGlobalFilterProps(this.state.previousFilterValues);
      this.props.setChildTabFilterProps(this.state.previousFilterValues);
      this.setState({ isFiltersChanged: false });
      this.props.setValueDataAPIFailureFlag(false);
    }
    this.setState({ openFilterPopup: !this.state.openFilterPopup });
  }

  getLabelValue(id) {
    return <FormattedMessageComponent id={id} />;
  }

  handleSubmitDataCallBack(data) {
    this.props.updateValueData(
      data,
      this.props.globalNumberFormat,
      this.props.globalNumberSeparator,
      this.props.globalDecimalSeparator,
    );
  }

  setFilterValuesFromState(values) {
    const filterValues = [];
    const { columnDefs } = this.state;
    if (
      (columnDefs && columnDefs.length) ||
      (this.columnDefData && this.columnDefData.length)
    ) {
      const colData =
        columnDefs && columnDefs.length ? columnDefs : this.columnDefData;
      values.forEach(value => {
        const isExists = colData.find(
          column => column[COLUMN_VALUE_ACCESSOR].trim() == value.accessor,
        );
        if (isExists) {
          filterValues.push(value);
        }
        else if (value.hasOwnProperty('accessor') && value.accessor != 'BTOTL'){
          filterValues.push(value);
        }
      });
      if (filterValues && filterValues.length) {
        this.props.onSetFilterProps(filterValues);
        this.props.setGlobalFilterProps(filterValues);
        return filterValues;
      }
    } else {
      this.props.onSetFilterProps(values);
      this.props.setGlobalFilterProps(values);
      return values;
    }
  }

  getApiObj(recordData, record, currentPage, pageProps) {
    let recordObj = false;
    if (record) {
      recordObj = record;
    }
    const apiObj = {
      recordData,
      pageProps,
      direction: pageProps.isForwardDirection,
      record: recordObj,
      currentPage,
      parentPage: BUYERS_LIST_PAGE,
    };
    return apiObj;
  }

  prepareHeaderDataJSON = obj => {
    const headerValues = {};
    const prefix = getListPredecessor(BUYERS_LIST_PAGE);

    const keyWareHouseID = `${prefix}WHSE`;
    const leadkeyWareHouseID = obj[keyWareHouseID];
    headerValues.BWHSE = leadkeyWareHouseID
      ? leadkeyWareHouseID.trim()
      : leadkeyWareHouseID;

    const keyCompanyID = `${prefix}COMP`;
    const leadkeyCompanyID = obj[keyCompanyID];
    headerValues.BCOMP = leadkeyCompanyID
      ? leadkeyCompanyID.trim()
      : leadkeyCompanyID;

    const keyBuyerID = `${prefix}BUYR`;
    const leadkeyBuyerID = obj[keyBuyerID];
    headerValues.BBUYR = leadkeyBuyerID
      ? leadkeyBuyerID.trim()
      : leadkeyBuyerID;

    const keyBuyerName = `${prefix}NAME`;
    const leadkeyBuyerName = obj[keyBuyerName];
    headerValues.BNAME = leadkeyBuyerName
      ? leadkeyBuyerName.trim()
      : leadkeyBuyerName;

    return [headerValues];
  };

  forceUpdateHandler() {
    this.forceUpdate();
  }

  makePrevNextAPICall = flag => {
    const { filterProps, valueData } = this.props.BuyerPropertiesData;
    const data = JSON.parse(JSON.stringify(INITIAL_PAGE_PROPS));
    data.isForwardDirection = flag;
    data.pageSize = 3;
    this.props.getPageUpDownFlagAPI(
      this.getApiObjForPageUpDownFlags(
        filterProps,
        valueData,
        BUYERS_LIST_PAGE,
        data,
        flag,
      ),
    );
  };

  prepareTooltipData = () => {
    const { detailCallData, buyerColumnDefs } = this.props.BuyerPropertiesData;
    const tooltipData = prepareTooltipValues(
      BUYERS_LIST_PAGE,
      detailCallData,
      buyerColumnDefs,
      'buyersproperties',
    );
    this.props.setDataInTabs(
      'toolTipData',
      JSON.parse(JSON.stringify(tooltipData)),
    );
  };

  setHeaderAndSendAPI(jsonData, from) {
    const data = this.prepareHeaderDataJSON(jsonData);
    this.setState({ headerData: data });
    this.setState({ stateData: jsonData });
    const valueData = prepareValueDataForBuyers(
      DEFAULT_VALUE_URL_DATA,
      jsonData,
      from,
    );
    this.sendAPICallForValues(valueData);
  }

  sendAPICallForValues(valueData) {
    const { pageProps } = this.props.BuyerPropertiesData;

    this.props.onLoadBuyerData(
      this.getApiObj(valueData, null, BUYER_PROPERTIES, pageProps),
    );
    this.props.getValueList(
      this.getApiObj(valueData, null, BUYER_PROPERTIES, pageProps),
      this.props.globalNumberFormat,
      this.props.globalNumberSeparator,
      this.props.globalDecimalSeparator,
    );
  }

  setBuyerColumnDefs(data) {
    if (data && data.length) {
      let vData = data.find(
        column => column[COLUMN_VALUE_ACCESSOR].trim() === 'BNAME',
      );
      vData = setNumberFields([vData]);
      const prefix = getListPredecessor(BUYERS_LIST_PAGE);
      vData[0].key = !vData[0].prefixFlag
        ? prefix + vData[0][COLUMN_VALUE_ACCESSOR].trim()
        : vData[0][COLUMN_VALUE_ACCESSOR].trim();
      return vData;
    }
  }

  handleValueDataErrorMessages(content) {
    this.setState({ showValueConfirmationDialog: true });
    this.setState({ dialogTitle: TEXT_ALERT });
    this.setState({ dialogContent: content });
  }

  closeValueDialog = () => {
    this.setState({ showValueConfirmationDialog: false });
    if (
      this.state.valueDataFailureMessages &&
      this.state.valueDataFailureMessages.length
    ) {
      const values = JSON.parse(
        JSON.stringify(this.state.valueDataFailureMessages),
      );
      values.shift();
      this.setState({ valueDataFailureMessages: values });
    }
  };

  setRecordDataValues() {
    let isRecordValuesExists = false;
    let isLocalStorageValuesExists = false;
    let isFilterValuesExists = false;
    const { history } = this.props;
    const paramsString = window.location.search;
    if (paramsString && paramsString.length) {
      const paramsArray = paramsString.split('?');
      if (paramsArray && paramsArray.length && paramsArray.length > 1) {
        const params = paramsArray[1].split('&');
        const tabId = params[0].split('=')[1];
        const breadCrumbId = params[1].split('=')[1];
        const localStorageValues = getFilterDataFromLocalStorage(
          tabId,
          breadCrumbId,
        );
        if (
          localStorageValues &&
          Object.keys(localStorageValues) &&
          Object.keys(localStorageValues).length
        ) {
          isLocalStorageValuesExists = true;
          const itemData = localStorageValues.item_data;
          let dbSelectorValues = [];
          if (itemData && itemData.recordData && localStorageValues.childType) {
            this.columnDefData = JSON.parse(
              JSON.stringify(itemData.recordData.columnDefs),
            );
            this.setState({ columnDefs: itemData.recordData.columnDefs });
            this.props.setCurrentRecord(itemData.recordData.data);
            this.setState({ totalCount: itemData.recordData.totalCount });
            this.setState({ fromPage: itemData.recordData.fromPage });
            this.setState({ fromListPage: itemData.recordData.fromPage });
            this.props.setRowIndex(itemData.recordData.rowIndex);
            this.setHeaderAndSendAPI(
              itemData.recordData.data,
              itemData.recordData.fromPage,
            );
            isRecordValuesExists = true;
            this.props.setSelectedRecord(false, false);
            if (itemData) {
              if (itemData.dbSelector && itemData.dbSelector.length) {
                dbSelectorValues = JSON.parse(
                  JSON.stringify(itemData.dbSelector),
                );
              }
              if (itemData.filterProps && itemData.filterProps.length) {
                this.setState({ hasFiltersChanged: false });
                isFilterValuesExists = true;
                const values = getDBSelectorFilterValues(
                  dbSelectorValues,
                  itemData.filterProps,
                );
                this.setFilterValuesFromState(values);
              } else if (dbSelectorValues && dbSelectorValues.length) {
                this.setState({ hasFiltersChanged: false });
                isFilterValuesExists = true;
                const dbValues = getDBSelectorFilterValues(
                  dbSelectorValues,
                  [],
                );
                this.setFilterValuesFromState(dbValues);
              }
              if (
                itemData.defaultFilterInfo &&
                Object.keys(itemData.defaultFilterInfo) &&
                Object.keys(itemData.defaultFilterInfo).length
              ) {
                this.props.setDefaultFilterpropsForTabs(
                  itemData.defaultFilterInfo,
                );
              }
            }
          }
        }
        if (!isLocalStorageValuesExists && tabId && breadCrumbId) {
          history.push({ pathname: '/Dashboard' });
        }
      }
    }

    const filterOptions = GLOBAL_FILTER_OPTIONS;
    const { dbSelector } = this.props;
    if (!isFilterValuesExists) {
      const gbValues = getDBSelectorFilterValues(dbSelector, filterOptions);
      this.setFilterValuesFromState(gbValues);
    }
    return isRecordValuesExists;
  }

  resetValues = () => {
    this.props.setInitialState();
    this.props.setValueDataFlag(false);
    this.props.setCurrentRecord(null);
    this.setState({ isDataLoaded: false });
    this.setState({ updatedBrackets: false });
    this.setState({ updatedNotes: false });
    this.props.getBuyersColumnDefs({ type: BUYERS_LIST_PAGE });
  };

  componentDidMount() {
    this.resetValues();
    const currentPage = BUYER_PROPERTIES_PAGE;
    this.props.onLoadCurrentPage(currentPage);
    const { detailCallData } = this.props.BuyerPropertiesData;
    this.props.setIsShowContextMenu(true);
    const isFound = this.setRecordDataValues();
    if (!isFound) {
      if (this.props.location && this.props.location.state) {
        this.props.setCurrentRecord(this.props.location.state.data);
        this.setState({ columnDefs: this.props.location.state.columnDefs });
        this.setState({ fromPage: this.props.location.state.fromPage });
        const data = this.setBuyerColumnDefs(
          this.props.location.state.columnDefs,
        );
        if (data) {
          this.setState({ buyerDataJSON: data });
        }
        this.props.setRowIndex(this.props.location.state.rowIndex);
        this.setHeaderAndSendAPI(
          this.props.location.state.data,
          BUYERS_LIST_PAGE,
        );
      }
    }

    if (
      detailCallData &&
      Object.keys(detailCallData) &&
      Object.keys(detailCallData).length
    ) {
      this.props.setSelectedRecord(detailCallData, BUYERS_LIST_PAGE);
    }

    const labelFilters = LABEL_LIST_URL_DATA;
    this.props.getLabelsList({
      recordData: labelFilters,
      currentPage: 'vendorproperties',
    });
    this.setState({ isSaveDataDisabled: true });
    const canUpdateComponent = getUpdateRestrictionOnComponent(
      capitalizeFirstLetter(BUYERS_LIST_PAGE),
      this.props.authorizedComponentsList,
    );
    this.props.getTrimCommonJson({ recordData: BRACKET_LABEL_URL_DATA, currentPage: 'vendorproperties' });
    this.setState({ canUpdateComponent });
  }


  setNotesCount(count) {
    if (this.state.notesCount != count) {
      this.setState({ notesCount: count })
      if (count == 9)
        this.setState({ notesCountWidth: '28px' })

      else if (count < 9 && this.notesCountWidth != '22px')
        this.setState({ notesCountWidth: '22px' })
    }
  }

  updatedNotesData = () => {
    this.setState({ updatedNotes: true });
  }


  componentDidUpdate(prevProps, prevState) {
    const {
      currentRecordData,
      pageUpDownData,
      isSaveSuccess,
      valueData,
      filterProps,
      isValueDataAPICall,
      isValueDataAPIFailure,
      buyerColumnDefs,
      filterCriteriaDetails,
      detailCallData,
      labelsDataFailure,
      commonLabelsDataFailure,
      isBuyerResultAPIFailure,
      previousNextFlagAPIFailure,
    } = this.props.BuyerPropertiesData;

    if (
      this.state.valueDataFailureMessages &&
      this.state.valueDataFailureMessages.length &&
      JSON.stringify(this.state.valueDataFailureMessages) !==
      JSON.stringify(prevState.valueDataFailureMessages)
    ) {
      this.handleValueDataErrorMessages(this.state.valueDataFailureMessages[0]);
    }

    if (
      labelsDataFailure &&
      labelsDataFailure !== prevProps.BuyerPropertiesData.labelsDataFailure
    ) {
      this.setState({ isDataLoaded: true });
      this.handleNoDataSets();
      this.props.setLabelDataFlags({ key: 'labelsDataFailure', value: false });
    }

    if (
      commonLabelsDataFailure &&
      commonLabelsDataFailure !==
      prevProps.BuyerPropertiesData.commonLabelsDataFailure
    ) {
      this.setState({ isDataLoaded: true });
      this.handleNoDataSets();
      this.props.setLabelDataFlags({
        key: 'commonLabelsDataFailure',
        value: false,
      });
    }

    if (
      previousNextFlagAPIFailure &&
      previousNextFlagAPIFailure !==
      prevProps.BuyerPropertiesData.previousNextFlagAPIFailure
    ) {
      const values = JSON.parse(
        JSON.stringify(this.state.valueDataFailureMessages),
      );
      values.push(
        'Failed to update the previous & next flags data from the server',
      );
      this.setState({
        valueDataFailureMessages: JSON.parse(JSON.stringify(values)),
      });
      this.props.setLabelDataFlags({
        key: 'previousNextFlagAPIFailure',
        value: false,
      });
    }

    if (
      isBuyerResultAPIFailure &&
      isBuyerResultAPIFailure !==
      prevProps.BuyerPropertiesData.isBuyerResultAPIFailure
    ) {
      const values = JSON.parse(
        JSON.stringify(this.state.valueDataFailureMessages),
      );
      values.push('Failed to get the buyer result data from the server');
      this.setState({
        valueDataFailureMessages: JSON.parse(JSON.stringify(values)),
      });
      this.props.setLabelDataFlags({
        key: 'isBuyerResultAPIFailure',
        value: false,
      });
    }

    if (
      JSON.stringify(filterProps) !==
      JSON.stringify(prevProps.BuyerPropertiesData.filterProps) &&
      filterProps &&
      filterProps.length
    ) {
      this.setState({ isFiltersChanged: true });
      this.props.setChildTabFilterProps(filterProps);
      if (!this.state.isInitialAPICall) {
        if (
          this.state.fromPage != BUYERS_LIST_PAGE &&
          !this.state.hasFiltersChanged
        ) {
          this.setHeaderAndSendAPI(this.state.stateData, this.state.fromPage);
        } else {
          this.makeAPICallForPageUpDown('down', {});
        }
      }
    }

    if (
      filterCriteriaDetails !==
      prevProps.BuyerPropertiesData.filterCriteriaDetails
    ) {
      this.props.setDataInTabs(
        'defaultFilterInfo',
        JSON.parse(JSON.stringify(filterCriteriaDetails)),
      );
      if (
        filterCriteriaDetails &&
        Object.keys(filterCriteriaDetails) &&
        Object.keys(filterCriteriaDetails).length &&
        buyerColumnDefs &&
        buyerColumnDefs.length
      ) {
        const list = getFilterDataFromCriteriaDetails(
          filterCriteriaDetails,
          buyerColumnDefs,
          BUYERS_LIST_PAGE,
        );
        if (list && list.length) {
          this.props.setGlobalFilterProps(list);
          this.props.onSetFilterProps(list);
        }
      }
    }

    if (
      detailCallData &&
      !isEqual(detailCallData, prevProps.BuyerPropertiesData.detailCallData)
    ) {
      if (Object.keys(detailCallData) && Object.keys(detailCallData).length) {
        if (buyerColumnDefs && buyerColumnDefs.length) {
          this.prepareTooltipData();
        }
        this.props.setSelectedRecord(detailCallData, BUYERS_LIST_PAGE);
        this.setState({
          headerData: this.prepareHeaderDataJSON(detailCallData),
        });
      }
    }

    if (
      valueData &&
      !isEqual(valueData, prevProps.BuyerPropertiesData.valueData)
    ) {
    }

    if (
      buyerColumnDefs &&
      buyerColumnDefs.length &&
      !isEqual(
        buyerColumnDefs,
        prevProps.BuyerPropertiesData.buyerColumnDefs,
      ) &&
      (detailCallData &&
        Object.keys(detailCallData) &&
        Object.keys(detailCallData).length)
    ) {
      if (!this.state.changeDataAPI) {
        this.prepareTooltipData();
      }
    }

    if (
      buyerColumnDefs &&
      !isEqual(buyerColumnDefs, prevProps.BuyerPropertiesData.buyerColumnDefs)
    ) {
      if (buyerColumnDefs && buyerColumnDefs.length) {
      } else {
        // handle no data sets
      }
    }

    if (
      buyerColumnDefs &&
      buyerColumnDefs.length &&
      !isEqual(buyerColumnDefs, prevProps.BuyerPropertiesData.buyerColumnDefs)
    ) {
      const data = this.setBuyerColumnDefs(buyerColumnDefs);
      if (data) {
        this.setState({ buyerDataJSON: data });
      }
    }

    if (
      isValueDataAPICall != prevProps.BuyerPropertiesData.isValueDataAPICall &&
      isValueDataAPICall
    ) {
      this.setState({
        previousFilterValues: prevProps.BuyerPropertiesData.filterProps,
      });
      this.setState({ isInitialAPICall: false });
      this.makePrevNextAPICall(true);
      this.setState({ bracketsNotesFilterObj: {} });
      this.props.setValueDataFlag(false);
      if (this.state.isFiltersChanged) {
        this.setState({ openFilterPopup: false });
        this.setState({ isFiltersChanged: false });
      }
    }

    if (
      isValueDataAPIFailure !==
      prevProps.BuyerPropertiesData.isValueDataAPIFailure &&
      isValueDataAPIFailure
    ) {
      this.updatedBracketListData();
      this.setState({ isInitialAPICall: false });
      const values = JSON.parse(
        JSON.stringify(this.state.valueDataFailureMessages),
      );
      values.push('Failed to get the detail data');
      this.setState({ valueDataFailureMessages: values });
      if (this.state.isFiltersChanged) {
        this.setState({ showConfirmationDialog: true });
        this.setState({ hasWarning: true });
        this.setState({ dialogTitle: TEXT_ALERT });
        this.setState({ fromHeaderENG: true });
      }
    }

    if (this.props.location.search !== prevProps.location.search) {
      this.resetValues();
      this.forceUpdateHandler();
      this.setRecordDataValues();
      this.setState({ state: this.state });
    }

    if (
      pageUpDownData &&
      JSON.stringify(pageUpDownData) !==
      JSON.stringify(prevProps.BuyerPropertiesData.pageUpDownData)
    ) {
      this.props.setSelectedRecord(pageUpDownData, BUYERS_LIST_PAGE);
      this.setState({ fromPage: BUYERS_LIST_PAGE });
      this.setHeaderAndSendAPI(pageUpDownData, BUYERS_LIST_PAGE);
      const modifiedData = {
        data: JSON.parse(JSON.stringify(pageUpDownData)),
        fromPage: BUYERS_LIST_PAGE,
        rowIndex: this.props.BuyerPropertiesData.rowIndex,
        totalCount: this.state.totalCount,
        fromParent: false,
        columnDefs: this.state.columnDefs,
      };
      this.props.setDataInTabs('recordData', modifiedData);
    }

    if (
      isSaveSuccess &&
      isSaveSuccess !== prevProps.BuyerPropertiesData.isSaveSuccess
    ) {
      this.setState({ isSaveDataDisabled: true });
      this.setHeaderAndSendAPI(this.state.stateData, this.state.fromPage);
    }

    if (
      prevProps.authorizedComponentsList !== this.props.authorizedComponentsList
    ) {
      const canUpdateComponent = getUpdateRestrictionOnComponent(
        capitalizeFirstLetter(BUYERS_LIST_PAGE),
        this.props.authorizedComponentsList,
      );
      this.setState({ canUpdateComponent });
    }

    const { buyerDeleted, pageProps, errorId } = this.props.BuyerPropertiesData;
    if (
      buyerDeleted != prevProps.BuyerPropertiesData.buyerDeleted &&
      buyerDeleted
    ) {
      const valueData = prepareValueDataForBuyers(
        DEFAULT_VALUE_URL_DATA,
        currentRecordData,
        'buyers',
      );
      this.props.getValueList(
        this.getApiObj(
          valueData,
          currentRecordData,
          BUYER_PROPERTIES,
          pageProps,
        ),
      );
      this.props.resetBuyerDeleteFlag();
    }
    if (errorId && errorId !== prevProps.BuyerPropertiesData.errorId) {
      if (errorId == '14029') {
        this.setState({
          showConfirmationDialog: true,
          dialogTitle: '52891',
          dialogBody: 'E14029',
          hasWarning: true,
        });
      } else
        this.setState(
          { hasError: true, errorId, errorMessage: false },
          () => { },
        );
    }
    if (prevProps.ServerError !== '') this.props.InitializeVar();
    if (this.state.hasError) {
      this.setState({ hasError: false });
    }

    if (
      this.props.BuyerPropertiesData.formattedValues &&
      prevProps.BuyerPropertiesData.buyerPropertiesDetailsLabelsData &&
      this.props.BuyerPropertiesData.buyerPropertiesDetailsLabelsData
    ) {
      if (
        prevProps.BuyerPropertiesData.buyerPropertiesDetailsLabelsData
          .tabcards !=
        this.props.BuyerPropertiesData.buyerPropertiesDetailsLabelsData.tabcards
      ) {
        this.props.formatBuyerPropertiesValues(
          this.props.globalNumberFormat,
          this.props.globalNumberSeparator,
          this.props.globalDecimalSeparator,
        );
      }
    }

    if (
      !this.props.BuyerPropertiesData.formattedValues &&
      this.props.BuyerPropertiesData.formattedValues !==
      prevProps.BuyerPropertiesData.formattedValues
    ) {
      this.props.changeFormattedValuesFlag();
    }
  }

  onSaveData = () => {
    const { newValueData, valueData } = this.props.BuyerPropertiesData;
    const detailValues = newValueData;
    const buyer = valueData;
    if (this.onValid(detailValues, buyer)) {
      const data = this.props.buyer;
      detailValues.BNAME = this.state.buyerName;
      if (JSON.stringify(newValueData) !== JSON.stringify(valueData)) {
        const updatedBuyerObj = { ...data, ...detailValues };
        this.props.sendValuesToServer({ ...updatedBuyerObj, BSTAT: 'C' });
      }
      this.prepareHeaderDataJSON(valueData);
    }
  };

  getApiObjForPageUpDown(filterData, record, currentPage, pageProps, pageType) {
    let recordObj = false;
    if (record) {
      recordObj = record;
    }
    const apiObj = {
      filterProps: filterData,
      pageProps,
      direction: pageProps.isForwardDirection,
      record: recordObj,
      currentPage,
      parentPage: BUYERS_LIST_PAGE,
      pageType,
    };
    return apiObj;
  }

  getApiObjForPageUpDownFlags = (
    filterData,
    record,
    currentPage,
    pageProps,
    pageType,
  ) => {
    let recordObj = false;
    if (record) {
      recordObj = {
        record,
        flagsOnly: true,
      };
    }
    const apiObj = {
      filterProps: filterData,
      pageProps,
      direction: pageProps.isForwardDirection,
      record: recordObj,
      currentPage,
      parentPage: BUYERS_LIST_PAGE,
      pageType,
    };
    return apiObj;
  };

  makeAPICallForPageUpDown(type, currentRecordData) {
    const { filterProps } = this.props.BuyerPropertiesData;
    const data = JSON.parse(JSON.stringify(INITIAL_PAGE_PROPS));
    if (type == 'up') {
      data.isForwardDirection = false;
    } else {
      data.isForwardDirection = true;
    }
    const filterData = JSON.parse(JSON.stringify(filterProps));
    this.props.pageUpDownAPI(
      this.getApiObjForPageUpDown(
        filterData,
        currentRecordData,
        BUYERS_LIST_PAGE,
        data,
      ),
    );
  }

  handleBuyerHeaderLeftArrowClick() {
    const { currentRecordData } = this.props.BuyerPropertiesData;
    this.props.setCurrentType('down');
    this.makeAPICallForPageUpDown('down', currentRecordData);
    this.setState({ isSaveDataDisabled: true });
  }

  handleBuyerHeaderRightArrowClick() {
    const { currentRecordData } = this.props.BuyerPropertiesData;
    this.props.setCurrentType('up');
    this.makeAPICallForPageUpDown('up', currentRecordData);
    this.setState({ isSaveDataDisabled: true });
  }

  onValid = () =>
    // Add validation logic here
    true;

  updateBuyerName = val => {
    this.setState({ buyerName: val });
  };

  sethaserror = val => {
    this.setState({ hasError: val });
  };

  updatedBracketListData = () => {
    this.setState({ updatedBrackets: true });
  };

  updatedNotesData = () => {
    this.setState({ updatedNotes: true });
  };

  handleItemSelection = val => {
    const type = val ? val.toLowerCase() : '';
    switch (type) {
      case 'delete':
        this.setState({ deleteDialog: true });
        break;
      //~~~CreateNewFramework--JVK
      case 'newnote':
        this.setState({ isOpenNote: true });
        break;
      //~~~CreateNewFramework--JVK
    }
  };

  closeDialog = dialog => {
    this.setState({ [dialog]: false });
  };

  onFieldValueChange(key, val) {
    this.setState({ updatedFieldValues: { key, val } });
  }

  onRowSelectedChange(selectedRow) {
    this.setState({ selectedRow });
  }

  setValueData(data, flag) {
    this.props.setValueData(
      data,
      this.props.globalNumberFormat,
      this.props.globalNumberSeparator,
      this.props.globalDecimalSeparator,
    );
    if (!flag) {
      this.setState({ changeDataAPI: false });
    } else {
      this.setState({ changeDataAPI: true });
    }
  }

  handleClose = bodyId => {
    this.setState({ showConfirmationDialog: false });
    switch (bodyId) {
      case 'E14029':
        // need to close the current Tab
        this.closeCurrentTab();
        break;
    }
  };

  closeCurrentTab = () => {
    this.props.setNoDataCallBackValue(true);
    const paramsString = window.location.search;
    if (paramsString && paramsString.length) {
      const paramsArray = paramsString.split('?');
      if (paramsArray && paramsArray.length && paramsArray.length > 1) {
        const params = paramsArray[1].split('&');
        const tabId = params[0].split('=')[1];
        const breadCrumbId = params[1].split('=')[1];
        this.props.removeCurrentRecordObj(tabId, breadCrumbId);
      }
    }
  };

  handleCopyDeletePopup = (popup, val) => {
    const type = popup ? popup.toLowerCase() : '';
    switch (type) {
      case 'delete':
        this.setState({ deleteDialog: val });
        break;
    }
  };
  onContextMenuChange = (e, value, check = false, filters = false, title = false) => {
		let defaultFilters = false;
		let toPage = value;
		let displayName = title;
		onChangeContextMenu(this.props, e, toPage, defaultFilters, displayName);
		this.props.setSelectedValueForTabs('Show Me');
	}
  render() {
    const cp = BUYER_PROPERTIES_PAGE;
    const {
      classes,
      globalDateFormat,
      filterCriteriaDetails,
      pageFilterOptions,
      globalFilterOptions,
    } = this.props;

    const {
      rowIndex,
      currentRecordData,
      loading,
      buyerPropertiesDetailsLabelsData,
      valueData,
      bracketLabelJson,
      hasNext,
      hasPrevious,
      buyerColumnDefs,
      deleteBuyerDetailsLabelData,
      newBuyerDetailsLabelData,
      trimCommonLabelJson,
      apiInProgress,//E3C-32871, J Vamshi:
    } = this.props.BuyerPropertiesData;

    const { tabcards } = buyerPropertiesDetailsLabelsData;
    const hideLoader = !loading && tabcards && tabcards.length
      && !apiInProgress;//E3C-32871, J Vamshi:
    const { deleteDialog } = this.state;
    
    let contextMenu=updateBreadCrumbContextMenu(this.props) || [];
    
    return (
      <div>
        {this.state.hasError ? (
          <div>
            <GridErrorMessages
              errorMessageLabels={this.props.errorMessageLabels}
              popUp
              sethaserror={this.sethaserror}
              id={
                this.state.errorId ? this.state.errorId : this.props.ServerError
              }
            />
          </div>
        ) : (
            ''
          )}
        {tabcards && tabcards.length && this.state.fromPage ? (//E3C-32871, J Vamshi:
          <div>
            <Formik
              initialValues={this.props.holdData}
              render={({ values, handleChange }) => (
                <form>
                  <Header
                    filters={this.props.filters}
                    parentSubPage={BUYER_PROPERTIES}
                    handleSubmitDataCallBack={this.handleSubmitDataCallBack}
                    contextMenu={contextMenu}
                    onContextMenuChange={this.onContextMenuChange}
                    fromListPage={this.state.fromListPage}
                    rowIndex={rowIndex}
                    BuyerPropertiesData={this.props.BuyerPropertiesData}
                    handleBuyerHeaderFilterClick={
                      this.handleBuyerHeaderFilterClick
                    }
                    hasNext={hasNext}
                    hasPrevious={hasPrevious}
                    buyerData={this.state.headerData}
                    currentRecordData={currentRecordData}
                    headerFieldJson={this.state.buyerDataJSON}
                    handleBuyerHeaderSaveClick={() => this.onSaveData(values)}
                    handleBuyerHeaderLeftArrowClick={
                      this.handleBuyerHeaderLeftArrowClick
                    }
                    handleBuyerHeaderRightArrowClick={
                      this.handleBuyerHeaderRightArrowClick
                    }
                    saveDisabled={this.state.isSaveDataDisabled}
                    updateBuyerName={this.updateBuyerName}
                    setSaveData={val => {
                      this.setState({ isSaveDataDisabled: !val });
                    }}
                    globalDateFormat={globalDateFormat}
                    filterCriteriaDetails={filterCriteriaDetails}
                    pageFilterOptions={pageFilterOptions}
                    globalFilterOptions={globalFilterOptions}
                    columnDefs={this.state.columnDefs}
                    currentPage={BUYERS_LIST_PAGE}
                    valuesArray={{ BNAME: this.state.buyerName }}
                    parentPage={BUYERS_LIST_PAGE}
                    
                    handleBuyerHeaderActionItemSelection={
                      this.handleItemSelection
                    }
                    canUpdateComponent={this.state.canUpdateComponent}
                    notesCount={this.state.notesCount}
                    notesCountWidth={this.state.notesCountWidth}
                    selectedValue={this.props.selectedValue}
                    removeChildCutdownTab={this.props.removeChildCutdownTab}
                  >
                    {' '}
                  </Header>

                  {deleteDialog && (
                    <DeleteDialog
                      openDeletePopup={deleteDialog}
                      handleCopyDeletePopup={this.handleCopyDeletePopup}
                      deleteLabels={deleteBuyerDetailsLabelData} // can use this in future
                      onSubmit={this.props.buyerDetailsDelete}
                      onDeleteAll={this.props.buyerDetailsDeleteAll}
                      buyerDetailData={this.props.BuyerPropertiesData}
                      currentOwnerName={this.props.currentOwnerName}
                      globalDateFormat={globalDateFormat}
                      filterCriteriaDetails={filterCriteriaDetails}
                      pageFilterOptions={pageFilterOptions}
                      globalFilterOptions={globalFilterOptions}
                      columnDefs={this.state.columnDefs}
                      currentPage={BUYERS_LIST_PAGE}
                      canUpdateComponent={this.state.canUpdateComponent}
                    />
                  )}

                  <BuyerPropertiesDetails
                    BuyerPropertiesData={this.props.BuyerPropertiesData}
                    rowIndex={rowIndex}
                    holdData={currentRecordData}
                    handleChange={handleChange}
                    values={values}
                    updatedFieldValues={this.state.updatedFieldValues}
                    setValueData={data =>
                      this.props.setValueData(
                        data,
                        this.props.globalNumberFormat,
                        this.props.globalNumberSeparator,
                        this.props.globalDecimalSeparator,
                      )
                    }
                    setSaveData={val => {
                      this.setState({ isSaveDataDisabled: !val });
                    }}
                    globalDateFormat={globalDateFormat}
                    filterCriteriaDetails={filterCriteriaDetails}
                    pageFilterOptions={pageFilterOptions}
                    globalFilterOptions={globalFilterOptions}
                    columnDefs={this.state.columnDefs}
                    currentPage={BUYERS_LIST_PAGE}
                    onFieldValueChange={this.onFieldValueChange}
                    selectedRow={this.state.selectedRow}
                    canUpdateComponent={this.state.canUpdateComponent}
                    handleSubmitDataCallBack={this.handleSubmitDataCallBack}
                    authorizedComponentsList={
                      this.props.authorizedComponentsList
                    }
                    messages={this.props.messages} //Fix for E3C-33046
                  />
         
                  <div id="buyerNotes"><BuyerNotes currentPage={BUYERS_LIST_PAGE}
                            noteLabelJson={trimCommonLabelJson}
                            bracketsNotesFilterObj={this.state.bracketsNotesFilterObj}

                            fromPage={BUYERS_LIST_PAGE}
                            currentRecordData={valueData}
                            updatedNotesData={this.updatedNotesData}
                            canUpdateComponent={this.state.canUpdateComponent}
                            //Security
                            /* Dispatch notes count from child to Parent to show it on header */
                            setNotesCount={this.setNotesCount}
                            //~~~CreateNewFramework--JVK
                            isOpenNote={this.state.isOpenNote}
                            closeNote={(flag) => this.setState({ isOpenNote: flag })}
                            //~~~CreateNewFramework--JVK
                            columnDefs={this.state.columnDefs || buyerColumnDefs}></BuyerNotes>
                        </div>
                </form>
              )}
            />
          </div>
        ) : null}
        {!hideLoader ? <Spinner loading type="list" /> : null}

        {this.state.openFilterPopup && (
          <Filter
            filterCriteriaDetails={this.props.filterCriteriaDetails}
            pageFilterOptions={this.props.pageFilterOptions}
            globalFilterOptions={this.props.globalFilterOptions}
            globalSecurityFilterList={this.props.globalSecurityFilterList}
            currentPage={cp}
            isOpen={Boolean(this.state.openFilterPopup)}
            ownerName={this.props.currentOwnerName}
            columnDefs={buyerColumnDefs}
            clearPopupComponent={this.handleBuyerHeaderFilterClick}
          />
        )}

        {this.state.showConfirmationDialog && (
          <ConfirmationDialog
            hasError={this.state.hasWarning}
            isOpen={this.state.showConfirmationDialog}
            dialogTitle={this.state.dialogTitle}
            submitText={TEXT_OK}
            handleClose={() => this.handleClose(false)}
            handleCancel={() => this.handleClose(false)}
            handleSubmit={() => this.handleClose(this.state.dialogBody)}
          >
            <div>
              {this.state.fromHeaderENG && (
                <FormattedMessageComponent id="28648" />
              )}
              {(this.props.errorMessageLabels &&
                this.props.errorMessageLabels[this.state.dialogBody] &&
                this.props.errorMessageLabels[this.state.dialogBody].MTEXT) ||
                'Warning'}
            </div>
          </ConfirmationDialog>
        )}
        {this.state.showValueConfirmationDialog && (
          <ConfirmationDialog
            hasError={this.state.hasWarning}
            isOpen={this.state.showValueConfirmationDialog}
            dialogTitle={this.state.dialogTitle}
            submitText={TEXT_OK}
            handleClose={() => this.closeValueDialog(false)}
            handleCancel={() => this.closeValueDialog(false)}
            handleSubmit={() => this.closeValueDialog(this.state.dialogBody)}
          >
            <div>{this.state.dialogContent}</div>
          </ConfirmationDialog>
        )}
      </div>
    );
  }
}

BuyerProperties.propTypes = {};

export default compose(
  withRouter,
  withStyles(style),
)(BuyerProperties);

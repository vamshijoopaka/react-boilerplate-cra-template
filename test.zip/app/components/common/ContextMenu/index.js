import React from 'react';
import { withStyles } from '@material-ui/core/styles';
import MenuList from '@material-ui/core/MenuList';
import MenuItem from '@material-ui/core/MenuItem';
import { Box, Checkbox } from '@material-ui/core';
import ClickAwayListener from '@material-ui/core/ClickAwayListener';
import Popper from "@material-ui/core/Popper";
import Paper from "@material-ui/core/Paper";
import './styles.css';
import FormattedMessageComponent from '../FormattedMessageComponent';
import ChevronRightRoundedIcon from '@material-ui/icons/ChevronRightRounded';
import PropTypes from 'prop-types';
const propTypes = {
    menuList: PropTypes.array.isRequired,
    handleItemSelection: PropTypes.func.isRequired,
    handleMenuClose: PropTypes.func.isRequired,
    menuRef: props => props.isOpen && !props.menuRef ? new Error('menuRef is required when isOpen is true') : null,
    isLabelAvailabel: PropTypes.bool,
    isSubMenu: PropTypes.bool,
}
const styles = () => ({
    MenusWrapper: {
        width: 'max-content',
        backgroundColor: '#fff !important',
        '& li': {
            color: '#3F4756',
        },
        '& ul': {
            backgroundColor: '#fff !important'
        }
    },
    zIndex: {
        zIndex: '1300',
    },
    justifySpaceBetween: {
        justifyContent: 'space-between',
    }
})

class ContextMenu extends React.Component {
    static propTypes = propTypes;
    state = {};
    componentDidUpdate = (prevProps) => {
        if (prevProps.isOpen !== this.props.isOpen && !this.props.isOpen) {
            this.setSubMenuRef(null);
        }
    }
    handleItemSelection = (menuObj, event) => {
        if (menuObj.hasSubMenu) {
            this.setSubMenuRef(event.currentTarget);
            return;
        }
        this.props.handleItemSelection(menuObj.key);
    }
    handleMenuClose = val => {
        this.props.handleMenuClose(false);
        this.setSubMenuRef(null);
    }
    setSubMenuRef = (subMenuRef) => this.setState({ subMenuRef });
    render() {
        const { classes, menuList, isLabelAvailabel, isSubMenu } = this.props;
        if (this.props.isOpen) {
            return (
                <Popper anchorEl={this.props.menuRef}
                    open={Boolean(this.props.menuRef)}
                    placement={isSubMenu ? 'left' : 'bottom'}
                    className={classes.zIndex}>
                    <Paper id="menu-list-grow">
                        <Box className={classes.MenusWrapper}>
                            <ClickAwayListener onClickAway={() => this.handleMenuClose(false)}>
                                <MenuList onClose={() => this.handleMenuClose(false)}>
                                    {menuList && menuList.map((value, index) => {
                                        return (
                                            !value.isHide &&
                                            <MenuItem disabled={value.isDisable} key={value.label + index}
                                                onClick={(event) => { this.handleItemSelection(value, event) }}
                                                onMouseEnter={(event) => { value.hasSubMenu ? this.setSubMenuRef(event.currentTarget) : null }}
                                                onMouseLeave={() => { value.hasSubMenu ? this.setSubMenuRef(null) : null }}
                                                className={value.hasSubMenu ? classes.justifySpaceBetween : ""}
                                            >
                                                {value.hasCheckbox ? <Checkbox checked={value.isChecked} disabled={value.isDisable}/> : null}
                                                {!isLabelAvailabel && (Boolean(Number(value.label)) ? <FormattedMessageComponent id={value.label} /> : value.label)}
                                                {isLabelAvailabel && value.label}
                                                {value.hasSubMenu ? <ChevronRightRoundedIcon /> : null}
                                                {value.hasSubMenu && this.state.subMenuRef && value?.subMenuList?.length ?
                                                    <ContextMenu
                                                        {...this.props}
                                                        menuRef={this.state.subMenuRef}
                                                        isSubMenu
                                                        parentMenuKey={value.key}
                                                        menuList={value.subMenuList}
                                                    />
                                                    : null}
                                            </MenuItem>
                                        )
                                    })}
                                </MenuList>
                            </ClickAwayListener>
                        </Box>
                    </Paper>
                </Popper>
            )
        }
        return null;
    }
}

export default withStyles(styles)(ContextMenu);
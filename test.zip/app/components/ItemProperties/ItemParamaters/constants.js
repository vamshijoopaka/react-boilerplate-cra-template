// export const ITEM_DETAIL_USER_DEFINED_FIELDS = '50387';

// export const DEFAULT_VALUE_ITEM_URL_DATA = [
//     { accessor: 'COMP', operator: '=', fieldValue: '', prefixFlag: 0 },
//   ];
export const DEFAULT_VALUE_URL_DATA = [
    { accessor: 'COMP', operator: '=', fieldValue: '', prefixFlag: 0 },
    { accessor: 'WHSE', operator: '=', fieldValue: '', prefixFlag: 0 },
    { accessor: 'VNDR', operator: '=', fieldValue: '', prefixFlag: 0 },
    { accessor: 'ITEM', operator: '=', fieldValue: '', prefixFlag: 0 }
  ];
export const MENU_DAILY_PROFILES = [
  {
      label: '2812',
      key: 'showHide',
      hasSubMenu: false,
      isDisable: false
  },
  {
      label: '25536',
      key: 'selectAll',
      hasSubMenu: false,
      isDisable: false
  },
  {
      label: '50278',
      key: 'deselectAll',
      hasSubMenu: false,
      isDisable: false
  },
  {
      label: '2857',
      key: 'resetDefaults',
      hasSubMenu: false,
      isDisable: false
  },
];

export const MENU_PROFILES = [
    {
        label: '2812',
        key: 'showHide',
        hasSubMenu: false,
        isDisable: false
    },
    {
        label: '25536',
        key: 'selectAll',
        hasSubMenu: false,
        isDisable: false
    },
    {
        label: '50278',
        key: 'deselectAll',
        hasSubMenu: false,
        isDisable: false
    },
    {
        label: '2857',
        key: 'resetDefaults',
        hasSubMenu: false,
        isDisable: false
    },
];
  

export const ITEM_PROPERTIES = 'itemProperties';
export const ITEM_BRACKET_PRICES = 'itemBracketPrices'
// export const ITEM_DISCOUNTS = "itemDiscounts";
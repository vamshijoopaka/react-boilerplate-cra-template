import { createSelector } from "reselect";

const selectData = (state) => state.get('ArchexcepTab');

export {
    selectData
};

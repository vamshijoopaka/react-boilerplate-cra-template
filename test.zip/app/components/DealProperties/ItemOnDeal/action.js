import {
	GET_ITEM_ON_DEAL_LIST,
	GET_ITEM_ON_DEAL_LIST_SUCCESS,
	GET_ITEM_ON_DEAL_LIST_FAILURE,
	GET_ITEM_ON_DEAL_COLUMN_DEFINITION,
	GET_ITEM_ON_DEAL_COLUMN_DEFINITION_SUCCESS,
	GET_ITEM_ON_DEAL_COLUMN_DEFINITION_FAILURE,
	GET_ITEM_ON_DEAL_UPDATE_COLUMN_DEFINITION,
	GET_ITEM_ON_DEAL_UPDATE_COLUMN_DEFINITION_SUCCESS,
	GET_ITEM_ON_DEAL_UPDATE_COLUMN_DEFINITION_FAILURE,
	RESET_DEFAULTS,
	RESET_DEFAULTS_SUCCESS,
	RESET_DEFAULTS_FAILURE,
	SET_FILTER_VALUES,
	SET_COLUMN_DEFS_LOADED,
	SET_PAGEPROPS,
	SET_APICALL_COUNT,
	RESET_DATA,
	LABEL_DATA_FLAGS,
	GET_ITEMS_LIST,
	GET_ITEMS_LIST_SUCCESS,
	GET_ITEMS_LIST_FAILURE,

	GET_DEAL_COLUMN_DEFS,
	GET_DEAL_COLUMN_DEFS_SUCCESS,
	GET_DEAL_COLUMN_DEFS_FAILURE,

	GET_DEAL_ALLOWANCE_DETAIL,
	GET_DEAL_ALLOWANCE_DETAIL_SUCCESS,
	GET_DEAL_ALLOWANCE_DETAIL_FAILURE,

	ITEM_ON_DEAL_DETAIL,
	ITEM_ON_DEAL_DETAIL_SUCCESS,
	ITEM_ON_DEAL_DETAIL_ERROR,
	ADD_RECORD,
	ADD_RECORD_SUCCESS,
	ADD_RECORD_FAILURE,
	REMOVE_RECORD,
	REMOVE_RECORD_SUCCESS,
	REMOVE_RECORD_FAILURE,
	UPDATE_RECORD,
	UPDATE_RECORD_SUCCESS,
	UPDATE_RECORD_FAILURE,
	SET_UPDATE_RECORD_FLAG,
	UPDATE_VALUE_ON_EDIT,
	ITEM_ON_DEAL_UPDATE,
	ITEM_ON_DEAL_UPDATE_SUCCESS,
	ITEM_ON_DEAL_UPDATE_ERROR,
	ITEM_ON_DEAL_UPDATE_ON_EDIT
} from './constants';

export function getItemOnDealList(namespace, data) {
	return {
		type: GET_ITEM_ON_DEAL_LIST,
		data
	}
}

export function setItemOnDealListSuccess(data) {
	return {
		type: GET_ITEM_ON_DEAL_LIST_SUCCESS,
		data
	}
}

export function setItemOnDealListFailure(data) {
	return {
		type: GET_ITEM_ON_DEAL_LIST_FAILURE,
		data
	}
}


export function getItemOnDealColumnDefs(namespace, data) {
	return {
		type: GET_ITEM_ON_DEAL_COLUMN_DEFINITION,
		data
	}
}

export function setItemOnDealListColumnDefs(data) {
	return {
		type: GET_ITEM_ON_DEAL_COLUMN_DEFINITION_SUCCESS,
		data
	}
}

export function setItemOnDealListColumnDefsFailure(data) {
	return {
		type: GET_ITEM_ON_DEAL_COLUMN_DEFINITION_FAILURE,
		data
	}
}

export function updateShowHide(namespace, data) {
	return {
		type: GET_ITEM_ON_DEAL_UPDATE_COLUMN_DEFINITION,
		data
	}
}

export function updateColumnDefsSuccess(data) {
	return {
		type: GET_ITEM_ON_DEAL_UPDATE_COLUMN_DEFINITION_SUCCESS,
		data
	}
}

export function updateColumnDefsFailure(data) {
	return {
		type: GET_ITEM_ON_DEAL_UPDATE_COLUMN_DEFINITION_FAILURE,
		data
	}
}

export function resetDefault(data) {
	return {
		type: RESET_DEFAULTS,
		data
	}
}

export function resetDefaultSuccess(data) {
	return {
		type: RESET_DEFAULTS_SUCCESS,
		data
	}
}

export function resetDefaultFailure(data) {
	return {
		type: RESET_DEFAULTS_FAILURE,
		data
	}
}

export function setFilterValues(namespace, data) {
	return {
		type: SET_FILTER_VALUES,
		data
	}
}

export function setColumnDefsLoaded(namespace, data) {
	return {
		type: SET_COLUMN_DEFS_LOADED,
		data
	}
}

export function resetStateData(namespace, data) {
	return {
		type: RESET_DATA,
		data
	}
}


export function setApiCallCount(namespace, data) {
	return {
		type: SET_APICALL_COUNT,
		data
	}
}

export function onSetPageProps(namespace, data) {
	return {
		type: SET_PAGEPROPS,
		data
	}
}
export function setLabelDataFlags(namespace, data) {
	return {
		type: LABEL_DATA_FLAGS,
		data
	}
}

export function getItemsList(namespace, data) {
	return {
		type: GET_ITEMS_LIST,
		data,
	}
}

export function setItemsListSuccess(data) {
	return {
		type: GET_ITEMS_LIST_SUCCESS,
		data
	}
}

export function setItemsListFailure(data) {
	return {
		type: GET_ITEMS_LIST_FAILURE,
		data
	}
}
export function getLabelsList(namespace, data) {
	return {
		type: GET_DEAL_COLUMN_DEFS,
		data
	}
}

export function getLabelListSucess(data) {
	return {
		type: GET_DEAL_COLUMN_DEFS_SUCCESS,
		data,
	}
}

export function getLabelListFailure(data) {
	return {
		type: GET_DEAL_COLUMN_DEFS_FAILURE,
		data
	}
}
export function getValueList(namespace, data) {
	return {
		type: ITEM_ON_DEAL_DETAIL,
		data
	}
}

export function getValueListSucess(data) {
	return {
		type: ITEM_ON_DEAL_DETAIL_SUCCESS,
		data,
	}
}

export function getValueListFailure(data) {
	return {
		type: ITEM_ON_DEAL_DETAIL_ERROR,
		data
	}
}

export function getDealAllowanceValueList(namespace, data) {
	return {
		type: GET_DEAL_ALLOWANCE_DETAIL,
		data
	}
}

export function getDealAllowanceValueListSucess(data) {
	return {
		type: GET_DEAL_ALLOWANCE_DETAIL_SUCCESS,
		data,
	}
}

export function getDealAllowanceValueListFailure(data) {
	return {
		type: GET_DEAL_ALLOWANCE_DETAIL_FAILURE,
		data
	}
}

export function onAddRec(data) {
	return {
		type: ADD_RECORD,
		data
	}
}

export function onAddRecSuccess(data) {
	return {
		type: ADD_RECORD_SUCCESS,
		data
	}
}

export function onAddRecFailure(error) {
	return {
		type: ADD_RECORD_FAILURE,
		error
	}
}
export function onRemoveRec(data) {
	return {
		type: REMOVE_RECORD,
		data
	}
}

export function onRemoveRecSuccess(data) {
	return {
		type: REMOVE_RECORD_SUCCESS,
		data
	}
}

export function onRemoveRecFailure(error) {
	return {
		type: REMOVE_RECORD_FAILURE,
		error
	}
}
export function onUpdateRec(data) {
	return {
		type: UPDATE_RECORD,
		data
	}
}

export function onUpdateRecSuccess(data) {
	return {
		type: UPDATE_RECORD_SUCCESS,
		data
	}
}

export function onUpdateRecFailure(error) {
	return {
		type: UPDATE_RECORD_FAILURE,
		error
	}
}
export function setUpdateRecordsFlag(data) {
	return {
		type: SET_UPDATE_RECORD_FLAG,
		data
	}
}
export function onSetDataValueChange(data) {
	return {
		type: UPDATE_VALUE_ON_EDIT,
		data
	}
}
export function itemOnDealUpdate(data) {
	return {
		type: ITEM_ON_DEAL_UPDATE,
		data
	}
}
export function itemOnDealUpdateSuccess(data) {
	return {
		type: ITEM_ON_DEAL_UPDATE_SUCCESS,
		data
	}
}
export function itemOnDealUpdateFailure(data) {
	return {
		type: ITEM_ON_DEAL_UPDATE_ERROR,
		data
	}
}
export function setValueData(data) {
	return {
		type: ITEM_ON_DEAL_UPDATE_ON_EDIT,
		data
	}
}
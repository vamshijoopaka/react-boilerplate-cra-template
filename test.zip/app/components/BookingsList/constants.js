import {
    COLUMN_HEADER_ACCESSOR, 
    COLUMN_VALUE_ACCESSOR,
    COLUMN_SHOW_HIDE_FLAG,
    COLUMN_POSITION,
    COLUMN_HEADER_PREFIX_FLAG
} from '../common/constants';


export const DEFAULT_ACTION = 'app/BookingsListPage/DEFAULT_ACTION';
export const LOAD_BOOKINGS = 'app/BookingsListPage/LOAD_BOOKINGS';
export const LOAD_BOOKINGS_ERROR = 'app/BookingsListPage/LOAD_BOOKINGS_ERROR';
export const LOAD_BOOKINGS_SUCCESS = 'app/BookingsListPage/LOAD_BOOKINGS_SUCCESS';
export const LOAD_BOOKINGS_COUNT = 'app/BookingsListPage/LOAD_BOOKINGS_COUNT';
export const LOAD_BOOKINGS_COUNT_ERROR = 'app/BookingsListPage/LOAD_BOOKINGS_COUNT_ERROR';
export const LOAD_BOOKINGS_COUNT_SUCCESS = 'app/BookingsListPage/LOAD_BOOKINGS_COUNT_SUCCESS';
export const SET_SEARCHPROPS = 'app/BookingsListPage/SET_SEARCHPROPS';
export const SET_SORTPROPS = 'app/BookingsListPage/SET_SORTPROPS';
export const SET_FILTERID = 'app/BookingsListPage/SET_FILTERID';
export const SET_ADVANCED_FILTERS = 'app/BookingsListPage/SET_ADVANCED_FILTERS';
export const SET_FILTERPROPS = 'app/BookingsListPage/SET_FILTERPROPS';
export const SET_PAGEPROPS = 'app/BookingsListPage/SET_PAGEPROPS';
export const SET_PROPERTIESPROPS = 'app/BookingsListPage/SET_PROPERTIESPROPS';
export const SET_BOOKING_COLUMN_DEF = 'app/BookingsListPage/SET_BOOKING_COLUMN_DEF';
export const LOAD_HEADER = 'app/LOAD_HEADER';
export const GET_BOOKING_COLUMN_DEF = 'app/BookingsListPage/GET_BOOKING_COLUMN_DEF';

export const BOOKING_COLUMN_HEADER_ACCESSOR = "TLLAB";
export const BOOKING_COLUMN_VALUE_ACCESSOR = "FDFNAM";
export const BOOKING_COLUMN_POSITION = "FLDPOS";
export const BOOKING_COLUMN_SHOW_HIDE_FLAG = "FLDSHW"
export const BOOKING_COLUMN_HEADER_PREFIX_FLAG = "FDPRFX";

export const BOOKING_PROPERTIES = {
    "headerName": COLUMN_HEADER_ACCESSOR,
    "field": COLUMN_VALUE_ACCESSOR,
    "showHideFlag": COLUMN_SHOW_HIDE_FLAG,
    "columnPosition": COLUMN_POSITION,
    "prefixFlag": COLUMN_HEADER_PREFIX_FLAG
}

export const PAGE_SIZES = [10, 20, 30];

export const BOOKING_LIST_PAGE = "bookingsListPage";

export const SET_BOOKING_GLOBAL_FILTER_PROPS = "SET_BOOKING_GLOBAL_FILTER_PROPS";

export const INITIAL_PAGE_PROPS = {
    actualPage: 0,
    currentPage: 0,
    totalCount: 10,
    actualPageSize: 10,
    pageSize: 100,
    isPageSizeChanged: false,
    isForwardDirection: true
}

export const HAS_PAGINATION = true;
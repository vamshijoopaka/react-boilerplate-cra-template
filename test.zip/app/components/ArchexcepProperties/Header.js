import React from 'react';
import { withStyles, Tab, AppBar, Tabs, Button, Box } from '@material-ui/core';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import { injectIntl } from 'react-intl';
import KeyboardArrowUpIcon from '@material-ui/icons/KeyboardArrowUp';
import KeyboardArrowDownIcon from '@material-ui/icons/KeyboardArrowDown';
import MoreVertIcon from '@material-ui/icons/MoreVert';
import SaveIcon from '@material-ui/icons/Save';
import PropTypes from 'prop-types';
import { getDateFromJulian } from 'utils/util';
import withFixedPosition from 'containers/common/withFixedPosition';
import {
    KEY_VENDOR_NAME, KEY_VENDOR_ID, KEY_ITEM_NAME, KEY_ITEM_ID, KEY_WAREHOUSE_NAME, KEY_WAREHOUSE_ID, KEY_BUYER_ID,
    KEY_ITEMGRP_1, KEY_ITEMGRP_2, KEY_ITEMGRP_3, KEY_ITEMGRP_4, KEY_SUPER, KEY_UPC, KEY_MFG_ID, KEY_REGION_ID, KEY_TIEHI,
    LABEL_ARCHEXCEP_LIST, LABEL_VENDOR_NAME, LABEL_VENDOR_ID, LABEL_ITEM_NAME, LABEL_ITEM_ID, LABEL_WAREHOUSE_NAME, LABEL_WAREHOUSE_ID,
    LABEL_BUYER_ID, LABEL_ITEMGRP_1, LABEL_ITEMGRP_2, LABEL_ITEMGRP_3, LABEL_ITEMGRP_4, LABEL_SUPER, LABEL_UPC, LABEL_MFG_ID,
    LABEL_REGION_ID, LABEL_TIEHI, LABEL_SUB_VENDOR_ID, KEY_SUB_VENDOR_ID
} from './constants';
import { getDateFormatted } from '../common/Form/dateTimeUtils';
import FormattedMessageComponent from '../common/FormattedMessageComponent';
import FilterIcon from "../../images/icon_filter.png";
import SortIcon from "../../images/icon_sort.svg";

import ContextMenuCreateNew from '../common/ContextMenuCreateNew';
import FieldInput from 'components/common/Form/FieldInput';
import { TYPE_TEXT, TEXT_CLOSE } from '../../containers/common/constants';
import FormFieldsGenerator from '../common/FormFieldsGenerator';
import BreadcrumbContextMenu from 'components/common/BreadcrumbContextMenu';
import DialogComponent from '../common/DialogComponent';
import { ARCHEXCEPS_LIST_PAGE } from 'components/common/constants';
import CustomizedTooltip from '../common/CustomizedTooltip';

const defaultProps = {
    archexcepData: [],
    saveDisabled: true
};

const propTypes = {
    archexcepData: PropTypes.array.isRequired,
    saveDisabled: PropTypes.bool.isRequired,
    handleArchexcepHeaderFilterClick: PropTypes.func,
    // handleArchexcepHeaderSaveClick: PropTypes.func,
    handleArchexcepHeaderLeftArrowClick: PropTypes.func,
    handleArchexcepHeaderRightArrowClick: PropTypes.func,
    // handleArchexcepHeaderActionItemSelection: PropTypes.func
};

const style = theme => ({
    propertiesHeaderContainer: {
        width: '100%',
        marginBottom: '1.5rem',
        backgroundColor: 'var(--background-app)',
        borderRadius: '4px',
        borderTopLeftRadius: '0px',
        borderTopRightRadius: '0px',
        overflow: 'hidden',
        boxShadow: '0 4px 4px var(--secondary-s10)',
        overflowX: 'auto'
    },
    archexcepContainer: {
        display: 'flex',
        width: '100%',
        backgroundColor: 'var(--background-content)',
        fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
        alignItems: 'center',
        padding: '0 0 0 24px',
        position: 'relative',
        minWidth: '630px'
    },
    archexcepDetailsWrapper: {
        width: '100%',
        display: 'flex',
    },
    archexcepDetailRow: {
        width: '85%',
        display: 'flex',
        flexWrap: 'wrap',
        padding: '0px 0 24px 0',
        paddingLeft: '15px'
    },
    archexcepDetail: {
        padding: '0px 0px 0 0px',
        lineHeight: '1.1',
    },

    archexcepDetailWarehouse: {
    },
    archexcepLabel: {
        color: 'var(--header-label-color)',
        paddingBottom: '6px',
        width: '15ch',
    },
    vendorActions: {
        top: '0px',
        // paddingBottom:'24px',
        padding: '0px 0px 20px 20px',
        right: '16px',
        display: 'flex',
        position: 'absolute',
        alignItems: 'center',
        justifyContent: 'space-between',
        '@media (max-width: 150px)': {
            flexWrap: 'wrap',
            width: '150px'
        }
    },
    vendorValue: {
        color: 'var(--value)',
    },
    archexcepValue: {
        display: 'inline-block',
        color: 'var(--value)',
        overflow: 'hidden',
        whiteSpace: 'nowrap',
        textOverflow: 'ellipsis',
        width: '80%',
    },
    archexcepID: {
        width: '100%',
        display: 'flex',
        paddingLeft: '45px',
    },
    archexcepName: {
        marginRight: '50px',
        paddingTop: '8px'
        // fontWeight: '500',
    },
    archexcepNameInput: {
        // marginLeft: '-17px',
        padding: '5px 0 5px 0',
        height: '42px',
        '& .MuiFormControlLabel-label': {
            padding: '10px 17px 10px 0px'
        },
        '& input': {
            width: '30ch',
            // fontSize: '32px'
        },
        '& svg': {
            top: '4px'
        },
        '& span': {
            // width: '0'
        }
    },
    archexcepArrowIcon: {
        height: '16px',
        width: '12px',
        borderRadius: '4px',
        fontSize: '10px',
        backgroundColor: 'var(--background-app)',
        margin: '0 4px',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        color: 'var(--secondary-s21)',
        lineHeight: '40px',
        cursor: 'pointer',
    },
    archexcepActions: {
        top: '24px',
        // paddingBottom:'24px',
        padding: '0px 20px 20px 20px',
        right: '16px',
        display: 'flex',
        position: 'absolute',
        alignItems: 'center',
        justifyContent: 'space-between',
        '@media (max-width: 1220px)': {
            flexWrap: 'wrap',
            width: '250px'
        }
    },
    archexcepRightLables: {
        top: '80px',
        // paddingBottom:'24px',
        padding: '10px 90px 20px 20px',
        right: '16px',
        display: 'flex',
        position: 'absolute',
        alignItems: 'center',
        justifyContent: 'space-between',
        '@media (max-width: 1220px)': {
            flexWrap: 'wrap',
            width: '250px'
        }
    },
    // archexcepActions: {
    //     top: '24px',
    //     right: '16px',
    //     display: 'flex',
    //     position: 'absolute',
    //     alignItems: 'center',
    //     justifyContent: 'space-between'
    // },
    archexcepActionsFilter: {
        minWidth: '20px',
        border: '1px solid var(--primary-default)',
        height: '32px',
        marginLeft: '5px',
        marginTop: '24px',
        // marginRight: '15px',
        '@media (max-width: 1220px)': {
            marginLeft: '0px'
        },
        '& img': {
            width: '14px',
            height: '14px'
        },
        '& svg': {
            width: '18px',
            height: '18px'
        }
    },
    archexcepActionsButton: {
        border: '1px solid var(--logo)',
        color: 'var(--logo)',
        '&:hover': {
            border: '1px solid var(--link-button)'
        }
    },
    archexcepArrow: {
        padding: '0 !important',
        margin: '0',
        minWidth: '16px',
        background: 'none',
        height: '16px',
        width: '16px',
    },
    archexcepArrowWrapper: {
        display: 'flex',
        flexDirection: 'column',
        border: '1px solid var(--primary-default)',
        borderRadius: '4px',
        justifyContent: 'center',
        alignItems: 'baseline',
        height: '38px',
        marginTop: '24px',
        padding: '2px',
    },
    ActionsContextMenu: {
    },
    ArchexcepReferences: {
        position: 'absolute',
        right: '3rem',
        bottom: '0px',
    },
    archexcepIDBlock: {
        display: 'flex',
    },
    subArchexcepId: {
        marginLeft: '20px'
    },
    idLabel: {
        paddingRight: '8px',
        width: '35px'
    },
    archexcepSubArchexcepDetails: {
        display: 'flex',
        flexDirection: 'column',
        width: '16ch',
        padding: '0 30px 0 0px',
        lineHeight: '1.1'
    },
    archexcepIdDetails: {
        width: '15ch',
        padding: '0 30px 0 0px',
        lineHeight: '1.1'
    },
    archexcepNameLabel: {
        paddingBottom: '0'
    },
    buttonActions: {
        display: 'flex',
        alignItems: 'center',
        // position: 'absolute',
        // top: '12px',
        // right: '105px',

        '@media (max-width: 1220px)': {
            marginBottom: '20px'
        },
        '& .MuiButton-root': {
            borderRadius: '4px',
            fontSize: '14px',
            width: '120px',
            lineHeight: '14px',
        },
        '& .MuiButton-sizeLarge': {
            fontSize: '18px',
        },
        '& .MuiButton-sizeSmall': {
            fontSize: '12px',
            padding: '8px 16px',
        },
        '& .MuiButton-containedPrimary': {
            backgroundColor: theme.palette.primary.default,
            border: '1px solid rgba(0, 0, 0, 0)',
            boxShadow: 'none',
            color: 'var(--background-content)',
            '&:hover': {
                backgroundColor: theme.palette.primary.hover,
                color: 'var(--background-content)',
                border: '1px solid rgba(0, 0, 0, 0)',
            },
            '&:focus': {
                backgroundColor: theme.palette.primary.focus,
                color: 'var(--background-content)',
                border: '1px solid rgba(0, 0, 0, 0)',
            },
            '&:active': {
                backgroundColor: theme.palette.primary.active,
                color: 'var(--background-content)',
                border: '1px solid rgba(0, 0, 0, 0)',
            }
        },
        '& .MuiButton-containedSecondary': {
            backgroundColor: 'var(--background-content)',
            border: '1px solid var(--button-tertiary-color)',
            color: 'var(--button-tertiary-color)',
            boxShadow: '0px 4px 14px rgba(0, 0, 0, 0.05)',
            '&:hover': {
                backgroundColor: 'var(--background-content)',
                color: 'var(--button-tertiary-hover-color)',
                border: '1px solid var(--button-tertiary-hover-color)',
            },
            '&:focus': {
                backgroundColor: 'var(--background-content)',
                color: 'var(--button-tertiary-focused)',
                border: '1px solid var(--button-tertiary-focused)',
            },
            '&:active': {
                backgroundColor: 'var(--background-content)',
                color: 'var(--button-tertiary-hover-color)',
                border: '1px solid var(--button-tertiary-hover-color)',
            },
            '&.Mui-disabled': {
                color: theme.palette.primary.disabled,
                textDecoration: 'unset',
                backgroundColor: 'unset',
                textShadow: 'unset'
            }
        },
        '& .MuiButton-outlinedPrimary': {
            border: `${'1px solid '}${theme.palette.primary.default}`,
            boxShadow: '0px 4px 14px rgba(0, 0, 0, 0.05)',
            backgroundColor: 'var(--background-content)',
            color: theme.palette.primary.default,
            '&:hover': {
                backgroundColor: 'var(--background-content)',
                border: '1px solid var(--button-secondary-hover-border)',
                color: 'var(--button-secondary-hover-border)',
            },
            '&:focus': {
                backgroundColor: 'var(--background-content)',
                border: `${'1px solid '}${theme.palette.primary.default}`,
                color: theme.palette.primary.default
            },
            '&:active': {
                backgroundColor: 'var(--background-content)',
                border: '1px solid var(--primary-button-pressed)',
                color: 'var(--primary-button-pressed)'
            },
            '&.Mui-disabled': {
                color: theme.palette.primary.disabled,
                textDecoration: 'unset',
                backgroundColor: 'unset',
                textShadow: 'unset'
            }
        },
        '& .MuiButton-outlinedSecondary': {
            backgroundColor: 'var(--background-content)',
            border: '1px solid var(--button-tertiary-color)',
            color: 'var(--button-tertiary-color)',
            boxShadow: '0px 4px 14px rgba(0, 0, 0, 0.05)',
            '&:hover': {
                backgroundColor: 'var(--background-content)',
                color: 'var(--button-tertiary-hover-color)',
                border: '1px solid var(--button-tertiary-hover-color)',
            },
            '&:focus': {
                backgroundColor: 'var(--background-content)',
                color: 'var(--button-tertiary-focused)',
                border: '1px solid var(--button-tertiary-focused)',
            },
            '&:active': {
                backgroundColor: 'var(--background-content)',
                color: 'var(--button-tertiary-hover-color)',
                border: '1px solid var(--button-tertiary-hover-color)',
            },
            '&.Mui-disabled': {
                color: theme.palette.primary.disabled,
                textDecoration: 'unset',
                backgroundColor: 'unset',
                textShadow: 'unset'
            }
        },
    },
    buttonActionsSecondChild: {
        marginRight: '15px',
        '& .MuiButton-outlinedPrimary': {
            width: '100px',
            height: '28px'
        }
    },
    IdNameBlock: {
        paddingRight: '1px',
        paddingTop: '24px',
        whiteSpace: 'break-spaces'
    },

    poAlign: {
        alignSelf: 'flex-end',
    },


    IdNameBlockShowMe: {
        paddingRight: '1px',
        // paddingLeft: '10px',
        paddingTop: '24px',
        whiteSpace: 'break-spaces'
    },

    hideArrows: {
        display: 'none'
    },
    nameField: {
        paddingBottom: '24px'
    },
    archexcepIDSubID: {
        paddingTop: '24px'
    },
    menuButton: {
        minWidth: '32px',
        border: '1px solid var(--primary-default)',
        height: '32px',
        marginLeft: '15px',
        borderRadius: '4px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        '@media (max-width: 1220px)': {
            marginLeft: '0px'
        },
        marginTop: 24,
    }
});

class Header extends React.Component {
    constructor(props) {
        super();
        this.state = {
            archexcepName: false,
            tabValue: 1,
            archexcepDetailsArray: false,
            // contextMenuList: CONTEXT_MENU_ARCHEXCEP_HEADER,
            // isOpenActionsContextMenu: false,
            // menuRef: null,

            // actionList: CONTEXT_MENU_ARCHEXCEP_ACTIONS,
            // isOpenActions: false,
            // actionMenuRef: null,
            // popupComponent: null,
            // open: false,
            // subArchexcep: false,
        }
        this.getDatefromArchexcepData = this.getDatefromArchexcepData.bind(this);
        this.getArchexcepLabels = this.getArchexcepLabels.bind(this);
        this.getHeaderDetails = this.getHeaderDetails.bind(this);
        // this.setIsOpenActionsContextMenu = this.setIsOpenActionsContextMenu.bind(this);
        // this.setIsOpenActionsButtonContextMenu = this.setIsOpenActionsButtonContextMenu.bind(this);
        this.onClickDownArrow = this.onClickDownArrow.bind(this);
        this.onClickUpArrow = this.onClickUpArrow.bind(this);
        // this.setVendorName = this.setVendorName.bind(this);
        this.getLabelValue = this.getLabelValue.bind(this);
        // this.handleDisableUpArrow = this.handleDisableUpArrow.bind(this);
        // this.handleDisableDownArrow = this.handleDisableDownArrow.bind(this);
    }

    getLabelValue(id) {
        return <FormattedMessageComponent id={id}></FormattedMessageComponent>;
    }

    handleDisableUpArrow = () => {
        const { rowIndex, ArchexcepPropertiesData, upFlag, hasPrevious, fromListPage } = this.props;
        return !hasPrevious || fromListPage != ARCHEXCEPS_LIST_PAGE;
    };

    handleDisableDownArrow = () => {
        const { rowIndex, totalCount, ArchexcepPropertiesData, downFlag, hasNext, fromListPage } = this.props;
        return !hasNext || fromListPage != ARCHEXCEPS_LIST_PAGE;
    };

    getDatefromArchexcepData(archexcepData, tabValue, key) {
        let date = archexcepData[tabValue - 1][key];

        if (date == '0' || !date || (date && date.trim() == ""))
            return ' '
        date = getDateFormatted(getDateFromJulian(date));
        return date;

    }

    getArchexcepLabels(key) {
        switch (key) {
            case KEY_VENDOR_NAME: return '33989';
            case KEY_VENDOR_ID: return '34433';
            case KEY_SUB_VENDOR_ID: return '34435';
            case KEY_ITEM_NAME: return '33990';
            case KEY_ITEM_ID: return '33670';
            case KEY_WAREHOUSE_NAME: return '36479';
            case KEY_WAREHOUSE_ID: return '33161';
            case KEY_BUYER_ID: return '33174';
            case KEY_ITEMGRP_1: return '38423';
            case KEY_ITEMGRP_2: return '38424';
            case KEY_ITEMGRP_3: return '38425';
            case KEY_ITEMGRP_4: return '38426';
            case KEY_SUPER: return '33682';
            case KEY_UPC: return '33676';
            case KEY_MFG_ID: return '33674';
            case KEY_REGION_ID: return '33169';
            case KEY_TIEHI: return '33677';
            default:
        }
    }

    getHeaderDetails(detail) {
        let arr = [];
        // detail = this.props.currentRecordData;
        detail = this.props.ArchexcepPropertiesData.detailCallData;
        if (detail && detail.length) {
            detail.forEach((ele, index) => {
                let element = [];
                Object.keys(ele).forEach(key => {
                    let obj = {
                        key: key,
                        label: this.getArchexcepLabels(key),
                        value: detail[index][key]
                    }
                    element.push(obj);
                })
                arr.push(element);
            })
            this.setState({ archexcepDetailsArray: arr });
        }
    }

    setIsOpenActionsContextMenu = event => {
        this.setState({ isOpenActionsContextMenu: Boolean(event) });
        this.setState({ menuRef: event.currentTarget ? event.currentTarget : event });
    }


    // setIsOpenActionsButtonContextMenu = event => {
    //     this.setState({ isOpenActions: Boolean(event) });
    //     this.setState({ actionMenuRef: event.currentTarget ? event.currentTarget : event });
    // }


    componentDidMount() {
        this.getHeaderDetails(this.props.archexcepData);
    }

    onClickDownArrow() {
        const { rowIndex, totalCount } = this.props;
        this.props.handleArchexcepHeaderLeftArrowClick(rowIndex, totalCount);
    }

    onClickUpArrow() {
        const { rowIndex, totalCount } = this.props;
        this.props.handleArchexcepHeaderRightArrowClick(rowIndex, totalCount);
    }

    handleClickOpen = name => {
        this.setState({ [name]: true });
    };

    handleClose = name => {
        this.setState({ [name]: false })
    };


    render() {
        const { classes, archexcepData, ArchexcepPropertiesData, handleArchexcepHeaderFilterClick,
            saveDisabled, handleArchexcepHeaderLeftArrowClick, handleArchexcepHeaderRightArrowClick,
            setSaveData, globalDateFormat, pageFilterOptions, isShowContextMenu, onContextMenuChange, contextMenu,
            globalFilterOptions, columnDefs, currentPage, valuesArray, parentPage, headerFieldJson, rowIndex,
            selectedValue, removeChildCutdownTab, fromListPage, freezeComponentStyle } = this.props;

        const { tabValue, archexcepDetailsArray } = this.state;

        let vendorname = archexcepData[tabValue - 1][KEY_VENDOR_NAME];
        if (ArchexcepPropertiesData.currentRecordData.ESUBV !== "") {
            vendorname = ArchexcepPropertiesData.currentRecordData.ESUBV + '      ' + archexcepData[tabValue - 1][KEY_VENDOR_NAME];
        }

        return (
            <div className={classes.propertiesHeaderContainer} style={freezeComponentStyle}>
                {archexcepData && archexcepData.length && currentPage &&
                    <div className={classes.archexcepContainer}>
                        <Box className={classes.archexcepDetailsWrapper}>
                            <Box className={classes.archexcepArrowWrapper}>
                                <Button color="primary" onClick={() => this.onClickUpArrow()} className={classes.archexcepArrow} disabled={this.handleDisableUpArrow()}>
                                    <KeyboardArrowUpIcon />
                                </Button>
                                <Button color="primary" onClick={() => this.onClickDownArrow()} className={classes.archexcepArrow} disabled={this.handleDisableDownArrow()}>

                                    <KeyboardArrowDownIcon />
                                </Button>
                            </Box>
                            <Box className={classes.archexcepDetailRow}>

                                <div className={classes.IdNameBlock}>
                                    <div className={`${classes.archexcepDetail} ${classes.nameField}`}>
                                        <div className={classes.archexcepLabel}>
                                            {this.getLabelValue(LABEL_VENDOR_ID)}
                                        </div>
                                        <div className={classes.archexcepValue}>{archexcepData[tabValue - 1][KEY_VENDOR_ID]} </div>
                                    </div>

                                    <div className={`${classes.archexcepDetail} ${classes.nameField}`}>
                                        <div className={classes.archexcepLabel}>
                                            {this.getLabelValue(LABEL_ITEM_ID)}
                                        </div>
                                        <div className={classes.archexcepValue}>{archexcepData[tabValue - 1][KEY_ITEM_ID]} </div>
                                    </div>

                                    <div className={`${classes.archexcepDetail} ${classes.nameField}`}>
                                        <div className={classes.archexcepLabel}>
                                            {this.getLabelValue(LABEL_WAREHOUSE_ID)}
                                        </div>
                                        <div className={classes.archexcepValue}>{archexcepData[tabValue - 1][KEY_WAREHOUSE_ID]} </div>
                                    </div>


                                </div>

                                <div className={classes.IdNameBlock}>

                                <div className={`${classes.archexcepDetail} ${classes.nameField}`}>
                                        <div className={classes.archexcepLabel}>
                                            {this.getLabelValue(LABEL_VENDOR_NAME)}
                                        </div>
                                        <CustomizedTooltip title={vendorname}>
                                            <div className={classes.archexcepValue}>{vendorname}</div>
                                        </CustomizedTooltip>
                                    </div>


                                    <div className={`${classes.archexcepDetail} ${classes.nameField}`}>
                                        <div className={classes.archexcepLabel}>
                                            {this.getLabelValue(LABEL_ITEM_NAME)}
                                        </div>
                                        <CustomizedTooltip title={archexcepData[tabValue - 1][KEY_ITEM_NAME]}>
                                            <div className={classes.archexcepValue} >{archexcepData[tabValue - 1][KEY_ITEM_NAME]}</div>
                                        </CustomizedTooltip>
                                    </div>


                                    <div className={`${classes.archexcepDetail} ${classes.nameField}`}>
                                        <div className={classes.archexcepLabel}>
                                            {this.getLabelValue(LABEL_WAREHOUSE_NAME)}
                                        </div>
                                        <CustomizedTooltip title={archexcepData[tabValue - 1][KEY_WAREHOUSE_NAME]}>
                                            <div className={classes.archexcepValue}>{archexcepData[tabValue - 1][KEY_WAREHOUSE_NAME]}</div>
                                        </CustomizedTooltip>
                                    </div>


                                </div>

                                <div className={classes.IdNameBlock}>


                                <div className={`${classes.archexcepDetail} ${classes.nameField}`}>
                                        <div className={classes.archexcepLabel}>
                                            {this.getLabelValue(LABEL_SUB_VENDOR_ID)}
                                        </div>
                                        <div className={classes.archexcepValue}>{archexcepData[tabValue - 1][KEY_SUB_VENDOR_ID]} </div>
                                    </div>


                                    <div className={`${classes.archexcepDetail} ${classes.nameField}`}>
                                        <div className={classes.archexcepLabel}>
                                            {this.getLabelValue(LABEL_SUPER)}
                                        </div>
                                        <div className={classes.archexcepValue}>{archexcepData[tabValue - 1][KEY_SUPER]} </div>
                                    </div>


                                    <div className={`${classes.archexcepDetail} ${classes.nameField}`}>
                                        <div className={classes.archexcepLabel}>
                                            {this.getLabelValue(LABEL_BUYER_ID)}
                                        </div>
                                        <div className={classes.archexcepValue}>{archexcepData[tabValue - 1][KEY_BUYER_ID]} </div>
                                    </div>

                                </div>

                                <div className={classes.IdNameBlock}>

                                    <div className={`${classes.archexcepDetail} ${classes.nameField}`}>
                                        <div className={classes.archexcepLabel}>
                                            {this.getLabelValue(LABEL_UPC)}
                                        </div>
                                        
                                    <CustomizedTooltip title={archexcepData[tabValue - 1][KEY_UPC]}>
                                        <div className={classes.archexcepValue} >{archexcepData[tabValue - 1][KEY_UPC]}</div>
                                    </CustomizedTooltip>
                                    </div>


                                    <div className={`${classes.archexcepDetail} ${classes.nameField}`}>
                                        <div className={classes.archexcepLabel}>
                                            {this.getLabelValue(LABEL_MFG_ID)}
                                        </div>
                                    <CustomizedTooltip title={archexcepData[tabValue - 1][KEY_MFG_ID]}>
                                        <div className={classes.archexcepValue} >{archexcepData[tabValue - 1][KEY_MFG_ID]}</div>
                                    </CustomizedTooltip>
                                    </div>

                                    <div className={`${classes.archexcepDetail} ${classes.nameField}`}>
                                        <div className={classes.archexcepLabel}>
                                            {this.getLabelValue(LABEL_REGION_ID)}
                                        </div>
                                        <div className={classes.vendorValue}>{archexcepData[tabValue - 1][KEY_REGION_ID]} </div>
                                    </div>


                                </div>


                                <div className={classes.IdNameBlock}>

                                    <div className={`${classes.archexcepDetail} ${classes.nameField}`}>
                                        <div className={classes.archexcepLabel}>
                                            {this.getLabelValue(LABEL_ITEMGRP_1)}
                                        </div>
                                        <div className={classes.archexcepValue}>{archexcepData[tabValue - 1][KEY_ITEMGRP_1]} </div>
                                    </div>

                                    <div className={`${classes.archexcepDetail} ${classes.nameField}`}>
                                        <div className={classes.archexcepLabel}>
                                            {this.getLabelValue(LABEL_ITEMGRP_2)}
                                        </div>
                                        <div className={classes.archexcepValue}>{archexcepData[tabValue - 1][KEY_ITEMGRP_2]} </div>
                                    </div>

                                    <div className={`${classes.archexcepDetail} ${classes.nameField}`}>
                                        <div className={classes.archexcepLabel}>
                                            {this.getLabelValue(LABEL_ITEMGRP_3)}
                                        </div>
                                        <div className={classes.archexcepValue}>{archexcepData[tabValue - 1][KEY_ITEMGRP_3]} </div>
                                    </div>

                                </div>

                                <div className={classes.IdNameBlock}>

                                    <div className={`${classes.archexcepDetail} ${classes.nameField}`}>
                                        <div className={classes.archexcepLabel}>
                                            {this.getLabelValue(LABEL_ITEMGRP_4)}
                                        </div>
                                        <div className={classes.archexcepValue}>{archexcepData[tabValue - 1][KEY_ITEMGRP_4]} </div>
                                    </div>

                                    <div className={`${classes.archexcepDetail} ${classes.nameField}`}>
                                        <div className={classes.archexcepLabel}>
                                            {this.getLabelValue(LABEL_TIEHI)}
                                        </div>
                                        <div className={classes.vendorValue}>{archexcepData[tabValue - 1][KEY_TIEHI]} </div>
                                    </div>

                                </div>

                            </Box>

                        </Box>

                        <Box className={classes.vendorActions}>

                            <div className={classes.IdNameBlockShowMe}>
                                <div className={isShowContextMenu ? 'showContextMenu' : 'hideContextMenu'}>
                                    <BreadcrumbContextMenu
                                        onOptionChange={(e, val) => onContextMenuChange(e, val)} menuItems={contextMenu}
                                        removeChildCutdownTab={removeChildCutdownTab}
                                        selectedValue={selectedValue} />
                                </div>
                            </div>

                            <Button component="div" color="primary" onClick={handleArchexcepHeaderFilterClick} className={classes.archexcepActionsFilter}>
                                <img src={FilterIcon} alt="Filter Icon" />
                            </Button>
                            <Box className={classes.menuButton}>
                                <div
                                    onMouseEnter={(event) => this.setIsOpenActionsContextMenu(event)}
                                    onMouseLeave={(event) => this.setIsOpenActionsContextMenu(false)}>
                                    <MoreVertIcon color="primary" className="cPointer"></MoreVertIcon>
                                    <ContextMenuCreateNew
                                        className={classes.ActionsContextMenu}
                                        menuList={[]}
                                        isOpen={this.state.isOpenActionsContextMenu}
                                        menuRef={this.state.menuRef}
                                        handleItemSelection={(val) => { }}
                                        handleMenuClose={(val) => this.setIsOpenActionsContextMenu(val)}
                                        currentPage={currentPage}
                                        currentRecord={ArchexcepPropertiesData.currentRecordData}
                                    >
                                    </ContextMenuCreateNew>
                                </div>
                            </Box>

                        </Box>


                    </div>
                }
            </div>
        );
    }
}

Header.defaultProps = defaultProps;
Header.propTypes = propTypes;

export default injectIntl(withStyles(style)(withFixedPosition(Header)));

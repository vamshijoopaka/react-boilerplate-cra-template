import React from 'react';
import PropTypes from 'prop-types';
import Drawer from '@material-ui/core/Drawer';
import { withStyles } from '@material-ui/core/styles';
import CloseIcon from '@material-ui/icons/Close';
import { Box } from '@material-ui/core';
import Button from '@material-ui/core/Button';
import { DialogTitle } from '@material-ui/core';
import FormattedMessageComponent from '../FormattedMessageComponent';

const styles = theme => ({
    sidePanelBox: {
        position: 'relative',
        height: '100%',
        '& .MuiTypography-h6':{
            fontWeight: '600'
        }
    },
    closeIcon: {
        position: 'absolute',
        top: '10px',
        right: '20px',
        color: 'var(--background-content)',
        '& svg':{
            cursor: 'pointer',
        }
    },
    sideDrawerControls: {
        display: 'flex',
        justifyContent: 'flex-end',
        paddingRight: 16
    },
    submitButton: {
        marginLeft: '10px',
    }
})

class SideDrawer extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
        }
        this.toggleDrawer = this.toggleDrawer.bind(this);
    }

    toggleDrawer = (open) => event => {
        if (event.type === 'keydown' && (event.key === 'Tab' || event.key === 'Shift'))
            return;
        this.props.handleClose();
    };

    render() {
        const { classes } = this.props;
        return (
            <div>
                <Drawer anchor={this.props.sideToOpen || "right"} open={this.props.isOpen}>
                    <div
                        className={classes.sidePanelBox + ' ' + this.props.className}
                        style={{ width: this.props.width || 400 }}
                    >
                        <DialogTitle><FormattedMessageComponent id={this.props.dialogTitle}></FormattedMessageComponent></DialogTitle>
                        <div className={classes.closeIcon}>
                            <CloseIcon onClick={this.toggleDrawer(false)} ></CloseIcon>
                        </div>
                        {this.props.children}
                        {this.props.submitText && <Box className={classes.sideDrawerControls}>
                            <Button size="large" color="primary" variant="outlined" onClick={this.props.handleCancel}>
                                <FormattedMessageComponent id={this.props.cancelText}></FormattedMessageComponent>
                            </Button>
                            <Button className={classes.submitButton} size="large" variant="contained" color="primary" onClick={this.props.handleSubmit} disabled={this.props.disableSubmit || false}>
                                <FormattedMessageComponent id={this.props.submitText}></FormattedMessageComponent> 
                            </Button>
                        </Box>}
                    </div>
                </Drawer>
            </div>
        );
    }
}

SideDrawer.propTypes = {
    sideToOpen: PropTypes.string, //default right
    dialogTitle: PropTypes.string,
    cancelText: PropTypes.string,
    submitText: PropTypes.string,
    width: PropTypes.any, //default 400px
    isOpen: PropTypes.bool,
    handleClose: PropTypes.func, //To close the panel
};

export default withStyles(styles)(SideDrawer);
export const HeaderAPIValuesJSON = [
    {
        "EFREFN": "",//Reference Number     
        "EFDESC": "",//Description
        "EFOWNR": "",//Owner      
        "EFTYPE": "",//Type 
        "EFLOCK": "" // Lock
    }
];

// PLEASE NOTE THAT THE KEYS USED FOR HEADER VALUES MAY NOT BE SAME FOR FUTURE WORK.
// PLEASE CHANGE THE KEY VALUES TO REQUIRED KEYS AS NECCESSARY.
export const KEY_EFREFN = "EFREFN";
export const KEY_EFDESC = "EFDESC";
export const KEY_EFOWNR = "EFOWNR";
export const KEY_EFTYPE = "EFTYPE";
export const KEY_EFLOCK = "EFLOCK";

export const LABEL_EXPFIELD_LIST = "25728"; // ! needs to be included in Header_ENG.json
export const LABEL_EXF_REFERENCE = "39952";// ! needs to be included in Header_ENG.json
export const LABEL_EXF_DESCRIPTION = "41377"; // ! needs to be included in Header_ENG.json
export const LABEL_EXF_OWNER = "39948";// ! needs to be included in Header_ENG.json
export const LABEL_EXF_TYPE = "33577";// ! needs to be included in Header_ENG.json
export const LABEL_EXF_LOCK = "39950";// ! needs to be included in Header_ENG.json

export const LABEL_ACTIONS = '28310';

export const DESC_KEY = '2098';
export const descFieldArray = [{
FDDATR: "M                                                 ",
FDDDIV: "0",
FDDECP: "0",
FDDEFN: " IDF_EFDESC                                       ",
FDDPRN: "0",
FDFCLS: "F",
FDFILD: "2098",
FDFLEN: "30",
FDFNAM: "EFDESC    ",
FDFTYP: "C",
FDLTRL: "                                                  ",
FDMASK: "                                                  ",
FDMAXV: ".0000",
FDMINV: ".0000",
FDPRFX: "0",
FDPROD: " ",
FDVLDT: "N",
FDZAPO: "N",
FLDLEN: " 20",
FLDNUM: "2098",
FLDPOS: "  2",
FLDSHW: "1",
FLDVLD: "",
TDEFN: "IDX_2298                                          ",
TIDNO: "2298",
TLANG: "ENG",
TLLAB: "Description                                                                                         ",
TPROD: " ",
TSLAB: "                    ",
TULLB: "                                                                                                    ",
TUSLB: "                    ",
dataType: "text",
defaultValue: "",
isCheckWildCard: false,
isColumnEditable: false,
key: "EFDESC",
labelPlacement: "start",
maxLength: 30,
prefixFlag: 1,
toUppercase: false,
validationType: "LZM",
width: 285,
disabled: false,
}];

export const DEFAULT_FIELD_URL_DATA = [
    { "accessor": "DSNAME", "operator": "=", "fieldValue": "DSXPFD", "prefixFlag": 1 },
    { "accessor": "BONAME", "operator": "=", "fieldValue": "SIMExportFieldsBusObj", "prefixFlag": 1 }
]


export const DEFAULT_VALUE_URL_DATA = 
[
    { "accessor": "REFN", "operator": "=", "fieldValue": "", "prefixFlag": 0 },
    { "accessor": "COMP", "operator": "=", "fieldValue": "", "prefixFlag": 0 },
    { "accessor": "DESC", "operator": "=", "fieldValue": "", "prefixFlag": 0 },
    { "accessor": "TYPE", "operator": "=", "fieldValue": "", "prefixFlag": 0 }
 
]


export const LABEL_LIST_URL_DATA = [
    { "accessor": "TRIMBO", "operator": "=", "fieldValue": "SIMExportFieldsBusObj", "prefixFlag": 0 },    
    { "accessor": "LANGID", "operator": "=", "fieldValue": "ENG", "prefixFlag": 0 }
]


export const BRACKET_LABEL_URL_DATA = [
    { "accessor": "TRIMBO", "operator": "=", "fieldValue": "SIMExportFieldsBusObj", "prefixFlag": 0 },
    { "accessor": "LANGID", "operator": "=", "fieldValue": "ENG", "prefixFlag": 0 }
]


export const EXPFIELD_PROPERTIES = 'expfieldProperties';

export const CONTEXT_MENU_HEADER_EXPFIELD_ACTIONS = [
    {
        label: '2856',
        key: 'delete',
        hasSubMenu: false,
        isDisable: false
    }
];

export const EQUALS_TO = '2869' //'Equals to';
export const GREATER_THAN = '2871' //'Greater than';
export const GREATER_THAN_OR_EQUALS_TO = '2873'//'Greater than or Equals to';
export const LESS_THAN = '2872'//'Less than';
export const LESS_THAN_OR_EQUALS_TO = '2874' //'Less than or equals to';
export const NOT_EQUALS_TO = '2870'//'Less than or Equals to';

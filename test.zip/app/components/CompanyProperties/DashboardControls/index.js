/** Change Log
 * LogStart --  E3C-33195 - Kumar A- 16 September,2021 - 2022.1.0.0 Unified Product
 *              Story: E3C-33195 --Code Cleanup
*/
import React from 'react';
import { connect } from 'react-redux';
import { compose } from 'redux';
import { withStyles } from '@material-ui/core/styles';
import injectReducer from 'utils/injectReducer';
import injectSaga from 'utils/injectSaga';
import PropTypes from 'prop-types';

import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import Button from '@material-ui/core/Button';
import { Grid } from '@material-ui/core';

import FormFieldsGenerator from '../../common/FormFieldsGenerator';
import Spinner from '../../common/Spinner';
import { selectData } from './selector';
import reducer from './reducer';
import saga from './saga';
import {
    COMPANY_GRAPH_CONTROL_FACTORS,
    COMPANY_PROJECTION_CONTROL_FACTORS,
    COMPANY_CLEANUP_CONTROLFACTORS,
    DASHBOARD_CONTROL,
} from './constants';
import './style.scss';
import {
    getFieldList,
    setGlobalCurrentPage,
} from './actions';
import { COMPANYS_LIST_PAGE } from 'components/common/constants';
import CardComponent from '../../common/CardComponent';

const propTypes = {
    setSaveData: PropTypes.func,
}

const style = theme => ({
    pageContainer: {
        display: 'flex',
        backgroundColor: 'var(--background-app)',
        borderTop: 'none',
        padding: '10px 20px',
    },
    pageContainerSeventy: {
        width: '70%',
        flexFlow: 'wrap',
        display: 'flex',
    },
    pageContainerThirty: {
        width: '30%',
        flexFlow: 'wrap',
        display: 'flex',
    },
    cardWithborder: {
        border: '1px solid var(--secondary-s3)',
        borderRadius: '4px',
        padding: '10px',
        margin: '10px',
        width: '100%',
        backgroundColor: 'var(--secondary-s5)',
    },
    card: {
        padding: '0px',
        backgroundColor: 'var(--background-content)',
        borderRadius: '4px',
        width: '100%',
        margin: '10px',
        '& .MuiCardHeader-root': {
            padding: '22px 10px 0 20px'
        },
        '& .MuiCardContent-root': {
            padding: '16px 15px 10px 15px'
        }
    },
    card1: {
        padding: '0px',
        backgroundColor: 'var(--background-content)',
        borderRadius: '4px',
        width: '90%',
        margin: '10px',
        marginLeft: '0px',
        '& .MuiCardHeader-root': {
            padding: '16px 32px'
        },
        '& .MuiCardContent-root': {
            padding: '16px 32px'
        }
    },
    card2: {
        padding: '0px',
        backgroundColor: 'var(--background-content)',
        borderRadius: '4px',
        width: '100%',
        margin: '10px',
        marginLeft: '0px',
        '& .MuiCardHeader-root': {
            padding: '16px 32px'
        },
        '& .MuiCardContent-root': {
            padding: '16px 32px'
        }
    },
    cardName: {
        fontWeight: '500',
        margin: '10px 0 20px 5px',
    },
    simpleCardGroup: {
        width: '100%',
        display: 'flex',
        justifyContent: 'space-around',
    },
    dashedBottomBorder: {
        borderBottom: '1px dashed var(--secondary-s21)',
        marginBottom: '20px',
    },
    marginLeftZero: {
        marginLeft: '0',
    },
    marginRightZero: {
        marginRight: '0',
    },
    card3: {
        height: '725px',
        width: '900px',
        marginLeft: '-20px',
    },
    cardHeader1: {
        color: 'white',
        height: '34px',
        marginBottom: 0,
        fontSize: '16px'
    },
    button1: {
        margin: '50px',
        height: '40px',
        width: 190,
        marginLeft: theme.spacing.unit * 100,
    },
    button2: {
        margin: '110px',
        height: '40px',
        width: 190,
        marginLeft: '-239px',
    },
    button3: {
        margin: '180px',
        height: '40px',
        width: 190,
        marginLeft: '-300px',
    },
})

class DashboardControls extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            fields: false,
            values: false,
            hasError: false,
            errorId: false,
            valueDashboardData: false,
        };
        this.handleChangeValue = this.handleChangeValue.bind(this);
        this.setGlobalProps = this.setGlobalProps.bind(this);
    }

    setGlobalProps() {
        this.props.setGlobalCurrentPage(DASHBOARD_CONTROL)
    }

    handleChangeValue(key, val, field) {
        if (field.FDPRFX == '0') {
            if (key.includes("undefined")) {
                key = key.replace("undefined", "");
            }
            key = 'CS' + key;
        }
        let valueDashboardDataD = this.state.valueDashboardData
        this.props.setValueDashboardData({ key, val, valueDashboardDataD });
        this.props.onFieldValueChange(key, val);
    }

    getValueData(valueData, newValueData) {
        if (this.state.valueDashboardData == false) {
            this.setState({ valueDashboardData: valueData });
        }
        if (Object.keys(valueData).length && Object.keys(newValueData).length &&
            (JSON.parse(JSON.stringify(valueData)) !== JSON.parse(JSON.stringify(newValueData)))) {
            return newValueData;
        }
        return valueData;
    }


    componentDidMount() {
        this.setGlobalProps();
    }

    render() {
        const { classes, globalDateFormat, filterCriteriaDetails, pageFilterOptions,
            globalFilterOptions, columnDefs, currentPage } = this.props;
        const { loading, dashboardLabelsData } = this.props.CompanyPropertiesData;
        const { tabcards } = dashboardLabelsData;
        const valueData = this.props.companyDashboardData;
        const newValueData = this.props.companyDashboardData;
        return (
            <div>
                {(!loading && tabcards && tabcards.length) ? (
                    <div className={classes.pageContainer}>
                        <div className={classes.pageContainerSeventy}>
                            {!loading && tabcards.map(formCard => {
                                if (formCard.cardkey == COMPANY_GRAPH_CONTROL_FACTORS) {
                                    return <CardComponent title={formCard.cardtitle} className={classes.card + ' ' + classes.marginLeftZero}>
                                        <FormFieldsGenerator
                                            cardHasDotsBtn={false}
                                            cardHasCheckBox={false}
                                            noMassMaintenance
                                            labelDisplayCharacters={38}
                                            valueDisplayCharacters={20}
                                            handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                                            key={formCard.cardkey}
                                            parentPage={COMPANYS_LIST_PAGE}
                                            className={'COMPANY_GRAPH_CONTROL_FACTORS'}
                                            fieldsArray={formCard.cardfields}
                                            valuesArray={this.getValueData(valueData, newValueData)}
                                            handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                            globalDateFormat={globalDateFormat}
                                            filterCriteriaDetails={filterCriteriaDetails}
                                            pageFilterOptions={pageFilterOptions}
                                            globalFilterOptions={globalFilterOptions}
                                            columnDefs={columnDefs}
                                            currentPage={currentPage}
                                            parentData={this.props.companyData}
                                        />
                                    </CardComponent>
                                }
                            })}
                            {!loading && tabcards.map(formCard => {
                                if (formCard.cardkey == COMPANY_PROJECTION_CONTROL_FACTORS) {
                                    return <CardComponent title={formCard.cardtitle} className={classes.card + ' ' + classes.marginLeftZero}>
                                        <FormFieldsGenerator
                                            cardHasDotsBtn={false}
                                            cardHasCheckBox={false}
                                            noMassMaintenance
                                            labelDisplayCharacters={40}
                                            valueDisplayCharacters={20}
                                            handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                                            key={formCard.cardkey}
                                            parentPage={COMPANYS_LIST_PAGE}
                                            className={'COMPANY_PROJECTION_CONTROL_FACTORS'}
                                            fieldsArray={formCard.cardfields}
                                            valuesArray={this.getValueData(valueData, newValueData)}
                                            handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                            globalDateFormat={globalDateFormat}
                                            filterCriteriaDetails={filterCriteriaDetails}
                                            pageFilterOptions={pageFilterOptions}
                                            globalFilterOptions={globalFilterOptions}
                                            columnDefs={columnDefs}
                                            currentPage={currentPage}
                                            parentData={this.props.companyData}
                                        />
                                    </CardComponent>
                                }
                            })}
                        </div>
                        <div className={classes.pageContainerSeventy}>
                            {!loading && tabcards.map(formCard => {
                                if (formCard.cardkey == COMPANY_CLEANUP_CONTROLFACTORS) {
                                    return <CardComponent title={formCard.cardtitle} className={classes.card + ' ' + classes.marginRightZero}>
                                        <FormFieldsGenerator
                                            cardHasDotsBtn={false}
                                            cardHasCheckBox={false}
                                            noMassMaintenance
                                            labelDisplayCharacters={40}
                                            valueDisplayCharacters={20}
                                            handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                                            key={formCard.cardkey}
                                            parentPage={COMPANYS_LIST_PAGE}
                                            className={'COMPANY_CLEANUP_CONTROLFACTORS'}
                                            fieldsArray={formCard.cardfields}
                                            valuesArray={this.getValueData(valueData, newValueData)}
                                            handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                            globalDateFormat={globalDateFormat}
                                            filterCriteriaDetails={filterCriteriaDetails}
                                            pageFilterOptions={pageFilterOptions}
                                            globalFilterOptions={globalFilterOptions}
                                            columnDefs={columnDefs}
                                            currentPage={currentPage}
                                        />
                                    </CardComponent>
                                }
                            })}
                        </div>
                    </div>
                ) : (<Spinner loading type="list" />)
                }
                {(!loading && tabcards && tabcards.length) ? (
                    <div className={classes.pageContainer}>
                        <div className={classes.root} style={{ padding: 2 }}>
                            <Grid container>
                                <div className={classes.pageContainer}>
                                    <Card className={classes.card3}>
                                        <CardHeader className={classes.cardHeader1}
                                            title='Graph Hierarchies'
                                        />
                                    </Card>
                                    <Button variant="contained" color="primary" className={classes.button1}>
                                        Add Hierarchy
                                            </Button>
                                    <Button variant="contained" color="tertiary" className={classes.button2}>
                                        Detail...
                                            </Button>
                                    <Button variant="contained" color="secondary" className={classes.button3}>
                                        Remove
                                            </Button>
                                </div>
                            </Grid>
                        </div>
                    </div>
                ) : (<Spinner loading type="list" />)
                }
            </div>
        );
    }
}

function mapDispatchToProps(dispatch) {
    return {
        dispatch,
        getFieldList: (data) => {
            dispatch(getFieldList(data));
        },
        setGlobalCurrentPage: (pageName) => {
            dispatch(setGlobalCurrentPage(pageName));
        }
    }
}

const mapStateToProps = function (state) {
    return {
        CompanyControlFactorsData: selectData(state)
    }
}

const withReducer = injectReducer({ key: 'DashboardControls', reducer });
const withSaga = injectSaga({ key: 'CompanyControlFactorsSaga', saga });

const withConnect = connect(
    mapStateToProps,
    mapDispatchToProps,
);

DashboardControls.propTypes = propTypes;

export default compose(
    withReducer,
    withConnect,
    withSaga,
    withStyles(style)
)(DashboardControls);
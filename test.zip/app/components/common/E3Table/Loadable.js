/**
 *
 * Asynchronously loads the component for E3Table
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));

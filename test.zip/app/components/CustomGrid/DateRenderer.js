import React, { Component } from 'react';
import Form from 'components/common/Form/Form';
import FieldInput from 'components/common/Form/FieldInput';
import { getDateFormatted } from 'components/common/Form/dateTimeUtils';
import { getDateFromJulian, getJulianValue } from '../../utils/util';
import { COLUMN_HEADER_ACCESSOR } from 'components/common/constants';

class DateRenderer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      currentDate: false,
      errorMessageLabel: false,
    };
    this.onDateChanged = this.onDateChanged.bind(this);
    this.updateAndNotifyAgGrid = this.updateAndNotifyAgGrid.bind(this);
  }

  componentDidMount() {
    let { props, onCellValueChanged, value, colDef } = this.props;
    this.setState({
      errorMessageLabel: colDef[COLUMN_HEADER_ACCESSOR],
    });
    if (value) {
      this.setState({
        currentDate: this.props.value,
      });
    }
  }

  updateAndNotifyAgGrid(dataValue) {
    const { rowIndex, column, colDef, agGridReact, data } = this.props;
    let dataRender = !colDef.prefixFlag
      ? agGridReact.props.listPredecessor + colDef['FDFNAM'].trim()
      : colDef['FDFNAM'].trim();
    let updatedData = data;
    if (data[dataRender] != new Date(getDateFromJulian(this.state.currentDate))) {
      updatedData[dataRender] = this.state.currentDate;
      agGridReact.props.onValueChanged(
        dataValue,
        rowIndex,
        column.colId.trim(),
        'date',
        updatedData,
        colDef,
        dataRender, this.state.currentDate
      );
    }
  }

  onDateChanged(selectedDates, value) {
    const { currentDate } = this.state;
    let date = new Date(getDateFromJulian(value));
    if (date instanceof Date && !isNaN(date)) {
      this.setState({ currentDate: value }, () => {
        this.updateAndNotifyAgGrid(value);
      });
    }
  }

  render() {
    const { rowIndex, column, value, agGridReact, gridCallBack, colDef } = this.props;
    let key = 'gridDate' + rowIndex + column.colId;
    return (
      <div>
        <Form>
          {form => (
            <FieldInput
              gridCallBack={agGridReact.props.gridCallBack}
              errorMessageLabel={this.state.errorMessageLabel}
              errorMessageLabels={agGridReact.props.errorMessageLabels}
              isFromGrid={true}
              value={this.state.currentDate}
              disabled={colDef.disabled}
              field={{
                type: 'date',
                key: key,
              }}
              disabled={colDef.disabled}
              onKeyDown={() => {}}
              onChange={(key, val) => this.onDateChanged(key, val)}
            />
          )}
        </Form>
      </div>
    );
  }
}
export default DateRenderer;

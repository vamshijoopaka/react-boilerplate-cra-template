import React from "react";
import MenuItem from "@material-ui/core/MenuItem";
import ArrowRightIcon from "@material-ui/icons/KeyboardArrowRight";
import MenuListComponent from 'components/common/MenuComponent/MenuListComponent'
import { Box } from '@material-ui/core';

class SubMenuItem extends React.Component {
  constructor(props) {
      super(props);
      this.state = {
          menuOpen: false,
          anchorElement: null
      }
      this.handleItemHover = this.handleItemHover.bind(this);
      this.setAnchorElement = this.setAnchorElement.bind(this);
      this.onMouseHover = this.onMouseHover.bind(this);
  }

  setAnchorElement(node) {
      this.setState({anchorElement: node});
      this.setState({menuOpen: Boolean(node)});
  };

  handleItemHover(event) {
      this.setAnchorElement(event.currentTarget);
  }

  onMouseHover(event) {
    this.handleItemHover(event);
  }
  onMouseOut(event) {
    this.setAnchorElement(null);
  }
  render() {
    return (
      <React.Fragment
      >
        <Box onMouseLeave  ={(event) => {this.onMouseOut(event)}}>
        <MenuItem
          onMouseEnter  ={(event) => this.onMouseHover(event)}
          >
          {this.props.title}
          <ArrowRightIcon />
        </MenuItem>
        <MenuListComponent
          open={this.state.menuOpen}
          menuitems={this.props.menuitems}
          anchorEl={this.state.anchorElement}
          menuRef={this.state.anchorElement}
          itemselect={(val) => { this.props.itemselect(val)}}
        />
        </Box>
      </React.Fragment>
    );
  }
}

export default SubMenuItem;

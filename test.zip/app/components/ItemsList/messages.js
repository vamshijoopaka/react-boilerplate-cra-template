/*
 * ItemsList Messages
 *
 * This contains all the text for the ItemsList component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.ItemsList';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'This is the ItemsList component!',
  },
});

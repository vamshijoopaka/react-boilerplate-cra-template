import React from 'react';
import { SUMMARIZATION_KEY_ID_MAP, FILTER_KEY_ID_MAP } from '../../containers/GroupHistoryPropertiesPage/constants';
import DialogComponent from '../common/DialogComponent';
import FilterCriteria from '../../containers/common/FilterCriteria';
import { TEXT_CANCEL, TEXT_APPLY } from '../common/constants';
import FormFieldsGenerator from '../common/FormFieldsGenerator';
import BoxBorder from '../../containers/common/BoxBorder';
import { makeStyles } from '@material-ui/core/styles';
import { FormControlLabel, FormLabel } from '@material-ui/core';
import { connect } from 'react-redux';
import { compose } from 'redux';
import { ASSIGN_ITEMS_MENUITEMS } from './constants';

const NAMESPACE = "embeddedListFilterCriteria";

const useStyles = makeStyles(theme => ({
    formField: {
        display: "grid",
        gridTemplateColumns: "auto auto",
        /* Override switch removed, for later use
        // '& > div:nth-child(odd) label': {
        //     maxWidth: '12ch',
        //     minWidth: '12ch',
        // },*/
    },
    margin: {
        margin: "1rem",
    },
    simpleCardField: {
        paddingLeft: '1rem',
        '& label': {
            color: 'var(--text)',
        }
    },
}));
function AssignItems(props) {
    const classes = useStyles();
    const [state, setState] = React.useState({
        menuItems: false,
        assignItemFilterProps: [],
        formObj: {
            INPROF: "",
            INSBMN: "1",
        },
        selectAllFlag: false,
    })
    React.useEffect(() => {
        setState(prevState => ({
            ...prevState,
            assignItemFilterProps: prepareAssignFilters(),
            menuItems: JSON.parse(JSON.stringify(ASSIGN_ITEMS_MENUITEMS)),
        }))
    }, []);
    React.useEffect(() => {
        if (props.assignItemSuccess) {
            props.setIsOpenAssignItems(false);
            props.setStoreKeyValue({ key: "assignItemSuccess", value: null });
        }
    }, [props.assignItemSuccess]);
    const prepareAssignFilters = () => {
        const { currentRecordData, currentDetailRecord } = props;
        const filterProps = [];
        for (const [key, meta] of Object.entries(SUMMARIZATION_KEY_ID_MAP)) {
            if (currentDetailRecord[key]?.trim?.() && !!+currentRecordData?.[meta.dependency]) {
                filterProps.push({
                    accessor: meta.accessor,
                    fieldValue: currentDetailRecord[key].trim(),
                    operator: "=",
                });
            }
        }
        for (const [key, meta] of Object.entries(FILTER_KEY_ID_MAP)) {
            if (currentRecordData[key]?.trim?.()) {
                filterProps.push({
                    accessor: meta.accessor,
                    fieldValue: currentRecordData[key].trim(),
                    operator: "=",
                });
            }
        }
        filterProps.push({
            accessor: "ITMCL",
            fieldValue: "A",
            operator: "=",
        })
        return filterProps;
    }

    const setEnableAssignSubmit = enableAssignSubmit => setState(prevState => ({ ...prevState, enableAssignSubmit }));

    const setSelectedRows = selectedRows => setState(prevState => ({ ...prevState, selectedRows }));

    const handleChange = (key, value) => {
        if ([undefined, null].includes(value)) return;
        setState(prevState => {
            return { ...prevState, formObj: { ...prevState.formObj, [key]: value } };
        });
    }

    const handleSubmit = () => {
        const { currentDetailRecord: { GDMPRF } } = props;
        const { formObj, selectedRows, selectAllFlag } = state;
        if (!selectedRows?.length) return;
        const payloadArray = [];
        let items = selectAllFlag ? [selectedRows[0]] : selectedRows;

        items.forEach(item => {
            const payload = {
                "INCOMP": "",
                "INWHSE": "",
                "INVNDR": "",
                "INVGP1": "",
                "INVGP2": "",
                "INBUYR": "",
                "INLGP1": "",
                "INLGP2": "",
                "INLGP3": "",
                "INLGP4": "",
                "INLGP5": "",
                "INLGP6": "",
                "INIGP1": "",
                "INIGP2": "",
                "INIGP3": "",
                "INIGP4": "",
                "INIGP5": "",
                "INIGP6": "",
                "INITEM": "",
            };
            for (let key in payload) {
                let itemKey = key.replace('IN', "I");
                if (/I(V)?GP\d/.test(itemKey)) {
                    itemKey = itemKey.replace('I', "")
                                     .replace("GP", "GRP");
                }
                payload[key] = item[itemKey];
            }
            payload.IDMPRF = item.IDMPRF;
            payload.INREGO = item.IREGON || "";
            payload.INMFGD = item.IMFGID;
            payload.INPRFO = GDMPRF;
            payload.INPROF = formObj.INPROF;
            payload.INALL = +formObj.INALL ? "Y" : "N";
            payload.INSBMN = formObj.INSBMN;
            // payload.INPGM = "";
            payloadArray.push(payload);
        });
        let finalPayload = { records: payloadArray, selectAllFlag };
        if (selectAllFlag) {
            const filterPayload = {
                filterProps: props.appliedFilters,
                pageProps: { pageSize: 1 },
                direction: true,
                currentPage: 'items',
            };
            finalPayload = { ...finalPayload, ...filterPayload };
        }
        props.assignItems(finalPayload);
    }

    const setSelectAllFlag = selectAllFlag => setState(prevState => ({ ...prevState, selectAllFlag }));

    return <DialogComponent
        isOpen={true}
        dialogTitle={"55302"}
        cancelText={TEXT_CANCEL}
        submitText={TEXT_APPLY}
        handleClose={() => props.setIsOpenAssignItems(false)}
        handleCancel={() => props.setIsOpenAssignItems(false)}
        handleSubmit={handleSubmit}
        disableSubmit={!state.enableAssignSubmit || !state.selectedRows?.length}
    >
        <FormControlLabel
            className={classes.simpleCardField}
            control={<FormLabel>{props.currentDetailRecord?.GDMPRF || " "}</FormLabel>}
            label={props.getLabelFromId('39686')}
            labelPlacement={'start'}
        />
        <FilterCriteria
            currentPage={"items"}
            filterCriteria={{
                open: true,
                parentFlag: 'embeddedList',
                apiFlag: "grouphistoryassignitems"
            }}
            updateSelectAllFlag={setSelectAllFlag}
            // onFilterCriteriaReady={onFilterCriteriaReady}
            onFilterCriteriaReady={() => null}
            menuItems={state.menuItems}
            listTitle={props.getLabelFromId("65610")}
            gridRowSelection={"multiple"}
            hasSort={true}
            updateMenuItems={() => { }}
            parentFilterProps={state.assignItemFilterProps}
            disableRows={["COMP", "ITMCL"]}
            namespace={NAMESPACE}
            sendSelectedRows={setSelectedRows}
            listPredecessor={"I"}
            enableSubmit={setEnableAssignSubmit}
            companyDetails={props.companyDetails}
        />
        {
            props.assignItemsLabelsArray?.length ?
                <BoxBorder
                    className={classes.margin}
                    title={props.getLabelFromId("52565")}
                >
                    <FormFieldsGenerator
                        fieldsArray={props.assignItemsLabelsArray[0].cardfields}
                        valuesArray={state.formObj}
                        currentPage={"grouphistory"}
                        noMassMaintenance
                        className={classes.formField}
                        valueDisplayCharacters={15}
                        // labelDisplayCharacters={35}// Override switch removed, for later use
                        labelDisplayCharacters={15}
                        handleChangeValue={handleChange}
                    />
                </BoxBorder>
                : null
        }
    </DialogComponent>
}

const mapStateToProps = state => ({
    appliedFilters: state.get(NAMESPACE).appliedFilter || [],
})
const withConnect = connect(
    mapStateToProps,
    null
);

export default compose(withConnect)(AssignItems);
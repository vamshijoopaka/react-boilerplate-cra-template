import React, { Component } from 'react';
import { Box, withStyles, Typography } from '@material-ui/core';
import { getDateFormatted } from 'components/common/Form/dateTimeUtils';

const style = () => ({
    timeWrapper: {
        display: 'flex',
        flexWrap: 'wrap',
        justifyContent: 'space-around',
        height: '4rem',
        alignSelf: 'flex-end',
        marginRight: '0.5rem',
    },
    timeLabel: {
        display: 'inline-block',
        width: '100%',
        textAlign: 'center',
        padding: '0 !important',
        color: 'var(--header-label-color)',
        margin: '5px',
    },
    datesWrapper: {
        width: '210px'
    },
    headerWrapper: {
        display: 'flex',
        backgroundColor: 'var(--background-content)',
        width: '100%',
        '@media (max-width: 880px)': {
            width: '100%'
        }
    },
    eventIdDescriptionWrapper: {
        width: '35ch'
    },
    eventIdDescValues: {
        display: 'flex',
        '& > :first-child': {
            width: '10ch'
        }
    },
    flexWrapper: {
        display: 'flex',
        flexWrap: 'wrap',
        padding: '8px 16px',
        width: '28rem',
    },
    fieldLabel: {
        color: 'var(--header-label-color)',
        padding: '0 30px 0px 0',
        width: '15ch',
    },
    fieldWrapper: {
        padding: '8px 8px 8px 0',
        display: 'flex',
    },
    fieldValue: {
        color: 'var(--value)'
    }
})
class Header extends Component {

    render() {
        const { getLabelValue, classes, eventItemData, globalDateFormat } = this.props;

        return (

            <div>


                <Box className={classes.headerWrapper}>

                    <Box className={classes.flexWrapper} style={{ flexDirection: 'column' }}>
                        <Box className={classes.childBlock}>
                            <div className={classes.fieldWrapper}>
                                <div className={classes.fieldLabel}>{getLabelValue('53313')}</div>
                                <Typography className={classes.fieldValue}>{eventItemData['EHCOMP']}</Typography>
                            </div>
                            <div className={classes.fieldWrapper}>
                                <div className={classes.fieldLabel}>{getLabelValue('33078')}</div>
                                <div className={classes.eventIdDescValues}>
                                    <Typography className={classes.fieldValue}>{eventItemData['EHEVNT']}</Typography>
                                    <Typography className={classes.fieldValue}>{eventItemData['EHDESC']}</Typography>
                                </div>
                            </div>
                            <div className={classes.fieldWrapper}>
                                <div className={classes.fieldLabel}>{getLabelValue('33004')}</div>
                                <Typography className={classes.fieldValue}>{eventItemData['EHREFN']}</Typography>
                            </div>
                        </Box>
                    </Box>

                    <Box display="flex">
                        <div className={classes.timeWrapper + ' ' + classes.datesWrapper}>
                            <div className={classes.timeLabel}>{getLabelValue('52777')}</div>
                            <Typography>{eventItemData['EHBGDT'] ? getDateFormatted(eventItemData['EHBGDT'], globalDateFormat) : ''}</Typography>
                            <Typography>{eventItemData['EHENDT'] ? getDateFormatted(eventItemData['EHENDT'], globalDateFormat) : ''}</Typography>
                            {/* <Typography>{eventItemData['EHBGDT'] ? getDateFormatValue(eventItemData['EHBGDT']) : ''}</Typography>
                            <Typography>{eventItemData['EHENDT'] ? getDateFormatValue(eventItemData['EHENDT']) : ''}</Typography> */}
                        </div>
                        <div className={classes.timeWrapper}>
                            <div className={classes.timeLabel}>{getLabelValue('52778')}</div>
                            <Typography>{eventItemData['EHBGPD']}</Typography>
                            <Typography>{eventItemData['EHEDPD']}</Typography>
                        </div>
                    </Box>

                </Box>

            </div>

        );
    }
}

export default withStyles(style)(Header);
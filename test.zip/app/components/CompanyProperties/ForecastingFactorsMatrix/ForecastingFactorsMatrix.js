/** Change Log
 * LogStart --  E3C-33195 - Kumar A- 16 September,2021 - 2022.1.0.0 Unified Product
 *              Story: E3C-33195 --Code Cleanup
 * LogStart --  E3C-33359 - Kumar A- 7 December,2021 - 2022.1.0.0 Unified Product
 *              Story: E3C-33359 --Company: 'Forecast Max Percent Decrease' in Enable Forecast Matrix card is not correctly aligned
*/
import React from 'react';
import { Grid, Paper } from '@material-ui/core';
import {
  withStyles,
} from '@material-ui/core/styles';
import Input from '@material-ui/core/Input';
import Card from '@material-ui/core/Card';
import TableContainer from '@material-ui/core/TableContainer';

import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableRow from '@material-ui/core/TableRow';
import FieldInput from '../../common/Form/FieldInput';
import FormattedMessageComponent from 'components/common/FormattedMessageComponent';
import {
  LABEL_COMPANY_ENABLE_FORECAST_MATRIX, LABEL_COMPANY_MWF,
  LABEL_COMPANY_RECORD_COUNT, LABEL_COMPANY_BYPASS_CONDITIONS,
  LABEL_COMPANY_PERIODS_DEMAND_BF, LABEL_COMPANY_BYPASS_ZERO_ONHAND,
  LABEL_COMPANY_BYPASS_ON_PROMOTION, LABEL_COMPANY_BYPASS_NWBP,
  LABEL_COMPANY_BYPASS_NWAP, LABEL_COMPANY_MIT,
  LABEL_COMPANY_DFC, LABEL_COMPANY_DFH,
  LABEL_COMPANY_DS, LABEL_COMPANY_UPD,
  LABEL_COMPANY_DFL, LABEL_COMPANY_FF,
  LABEL_COMPANY_TSL, LABEL_COMPANY_BAF,
  LABEL_COMPANY_UL, LABEL_COMPANY_FMPI,
  LABEL_COMPANY_FMPD
}
  from './constants';
import PropTypes from 'prop-types';

const propTypes = {
  setSaveData: PropTypes.func,
};

const styles = theme => ({
  pageContainer: {
    display: 'flex',
    backgroundColor: 'var(--background-app)',
    borderTop: 'none',
    padding: '10px 20px',
    marginTop: '-12px',
  },
  root: {
    flexGrow: 1,
    width: '100%',
  },
  card: {
    marginTop: '8px',
  },
  table: {
    marginLeft: theme.spacing(100),
    width: '100%',
  },
  input: {
    width: '60%',
    fontSize: '12px',
    marginBottom: theme.spacing(1),
    textAlignLast: 'center',
  },
  border: {
    textAlign: 'center',
  },
  border1: {
    borderRight: '1px solid black',
    borderLeft: '1px solid black',
    paddingLeft: '20px',
  },
  border2: {
    borderTop: '1px solid black',
    textAlign: 'center',
  },
  border3: {
    borderRight: '1px solid black',
    borderLeft: '1px solid black',
    borderTop: '1px solid black',
    textAlign: 'center',
  },
  border4: {
    borderRight: '1px solid black',
    borderTop: '1px solid black',
    textAlign: 'center',
  },
  border5: {
    borderRight: '1px solid black',
    textAlign: 'center',
  },
  border6: {
    borderBottom: '1px solid black',
    textAlign: 'center',
  },
  border7: {
    borderRight: '1px solid black',
    borderBottom: '1px solid black',
    textAlign: 'center',
  },
  border8: {
    borderRight: '1px solid black',
    borderLeft: '1px solid black',
    borderBottom: '1px solid black',
  },
  simpleCardGroup: {
    width: '100%',
    display: 'flex',
    justifyContent: 'space-around',
  },
  simpleCardInput: {
    margin: '0',
    width: '50%',
    textAlignLast: 'center',

    '& input': {
    },
    '&.error-input:after': {
      borderBottom: '2px solid var(--card-error-border) !important'
    },
    '&.error-input:hover::after': {
      borderBottom: '2px solid var(--card-error-border) !important'
    },
  },
  simpleCardInput1: {
    margin: '0',
    width: '50%',
    textAlignLast: 'center',
    marginTop: '-50px',

    '& input': {
    },
    '&.error-input:after': {
      borderBottom: '2px solid var(--card-error-border) !important'
    },
    '&.error-input:hover::after': {
      borderBottom: '2px solid var(--card-error-border) !important'
    },
  },
});

class ForecastingFactorsMatrix extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      isTrue: this.props.values['CFCFMX'] == 0 ? true : false,
      values: this.props.values,
    };
  }

  getLabelValue(id) {
    return <FormattedMessageComponent id={id} />;
  }

  commaFormatted = (value) => {
    var delimiter = ","; // replace comma if desired
    var a = value.split('.', 2)
    var d = a[1];
    var i = parseInt(a[0]);
    if (isNaN(i)) { return ''; }
    var minus = '';
    if (i < 0) { minus = '-'; }
    i = Math.abs(i);
    var n = new String(i);
    var a = [];
    while (n.length > 3) {
      var nn = n.substr(n.length - 3);
      a.unshift(nn);
      n = n.substr(0, n.length - 3);
    }
    if (n.length > 0) { a.unshift(n); }
    n = a.join(delimiter);
    if (d.length < 1) { value = n; }
    else { value = n + '.' + d; }
    value = minus + value;
    return value;
  }

  handleChangeValue(key, val) {
    const { values } = this.state;
    if (val != undefined) {
      if (key == 'CFCFMX') {
        this.setState({ isTrue: val == 0 ? true : false });
      }
      let temp = { ...values, [key]: val }
      this.setState({ values: temp });
    }
  }

  setValueDataOnFocutOut = (key) => {
    const { values } = this.state;
    let val = null;
    if (key.includes('CFBKWF')) {
      val = parseFloat(values[key]).toFixed(2);
    }
    if (key.includes('CFIPCT') || key.includes('CFDPCT')) {
      val = parseFloat(values[key]).toFixed(1);
    }
    if (val != null) {
      let temp = { ...values, [key]: val }
      this.setState({ values: temp });
    }
  }

  //E3C-30006, 6/29/21, Kumar:Start
  getMessageText = id => {
    const { messages } = this.props;
    if (messages && messages['H' + id]) {
      return messages['H' + id].TLLAB;
    }
    else return '';
  }
  //E3C-30006, 6/29/21, Kumar:End

  render() {
    const { classes, setSaveData } = this.props;
    const { values } = this.state;
    this.props.changeForecastFactorsMatrixData(values);
    return (
      <div className={classes.pageContainer}>
        <div className={classes.simpleCardGroup}>
          <Grid container spacing={0}>
            <Grid item xs={12}>
              <div style={{ padding: 0 }}>
                <div className={classes.root}>
                  <Card className={classes.card}>
                    <label style={{ fontSize: '16px', fontWeight: 'bold' }}>{this.getLabelValue(
                      LABEL_COMPANY_ENABLE_FORECAST_MATRIX,
                    )}</label>
                    <FieldInput
                      className={classes.simpleCardInput1}
                      value={values.CFCFMX}
                      field={{ type: "checkbox", key: "CFCFMX" }}
                      numberType={"integer"}
                      isCheckWildCard={true}
                      toUppercase={false}
                      disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                      prefixFlag={1}
                      defaultValue={"0"}
                      onChange={(key, val) => this.handleChangeValue(key, val)}
                      enableAddButton={e => setSaveData(e)}
                      isColumnEditable={true}
                      errorMessageLabel={this.getMessageText(
                        LABEL_COMPANY_ENABLE_FORECAST_MATRIX,
                      )} //E3C-30006, 6/29/21, Kumar
                    />
                    <TableContainer component={Paper}>
                      <Table
                        className={classes.table}
                        aria-label="simple table"
                      >
                        <TableBody>
                          <TableRow>
                            <TableCell
                              className={classes.border3}
                              width="17%"
                            />
                            <TableCell
                              className={classes.border2}
                              align="centre"
                              width="10%"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CFBKDS1}
                                field={{ key: "CFBKDS1" }}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={15}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                defaultValue={""}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                globalDecimalSeparator={"."}
                                errorMessageLabel={''}
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border2}
                              align="centre"
                              width="10%"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CFBKDS2}
                                field={{ key: "CFBKDS2" }}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={15}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                defaultValue={""}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                globalDecimalSeparator={"."}
                                errorMessageLabel={''}
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border2}
                              align="centre"
                              width="10%"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CFBKDS3}
                                field={{ key: "CFBKDS3" }}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={15}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                defaultValue={""}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                globalDecimalSeparator={"."}
                                errorMessageLabel={''}
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border2}
                              align="centre"
                              width="10%"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CFBKDS4}
                                field={{ key: "CFBKDS4" }}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={15}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                defaultValue={""}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                globalDecimalSeparator={"."}
                                errorMessageLabel={''}
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border4}
                              align="centre"
                              width="10%"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CFBKDS5}
                                field={{ key: "CFBKDS5" }}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={15}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                defaultValue={""}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                globalDecimalSeparator={"."}
                                errorMessageLabel={''}
                              />
                            </TableCell>
                          </TableRow>
                          <TableRow>
                            <TableCell
                              className={classes.border1}
                              component="th"
                              scope="row"
                            >
                              {this.getLabelValue(
                                LABEL_COMPANY_MWF,
                              )}
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CFBKWF1}
                                field={{ type: "number", key: "CFBKWF1", Attr: ' ' }}
                                numberType={"decimal"}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={9}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"0.01"}
                                maxValue={9999999.99}
                                isNegative={false}
                                precisionLength={2}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                prefixFlag={1}
                                defaultValue={"0.0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onFocusOut={() => this.setValueDataOnFocutOut('CFBKWF1')}
                                isColumnEditable={true}
                                globalDecimalSeparator={"."}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_MWF,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CFBKWF2}
                                field={{ type: "number", key: "CFBKWF2", Attr: ' ' }}
                                numberType={"decimal"}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={9}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"0.01"}
                                maxValue={9999999.99}
                                isNegative={false}
                                precisionLength={2}
                                prefixFlag={1}
                                defaultValue={"0.0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onFocusOut={() => this.setValueDataOnFocutOut('CFBKWF2')}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                globalDecimalSeparator={"."}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_MWF,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CFBKWF3}
                                field={{ type: "number", key: "CFBKWF3", Attr: ' ' }}
                                numberType={"decimal"}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={9}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"0.01"}
                                maxValue={9999999.99}
                                isNegative={false}
                                precisionLength={2}
                                prefixFlag={1}
                                defaultValue={"0.0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onFocusOut={() => this.setValueDataOnFocutOut('CFBKWF3')}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                globalDecimalSeparator={"."}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_MWF,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CFBKWF4}
                                field={{ type: "number", key: "CFBKWF4", Attr: ' ' }}
                                numberType={"decimal"}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={9}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"0.01"}
                                maxValue={9999999.99}
                                isNegative={false}
                                precisionLength={2}
                                prefixFlag={1}
                                defaultValue={"0.0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onFocusOut={() => this.setValueDataOnFocutOut('CFBKWF4')}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                globalDecimalSeparator={"."}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_MWF,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border5}
                              align="centre"
                            >
                              <Input
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                readOnly={true}
                                className={classes.input}
                                value={"9,999,999.99"}
                              />
                            </TableCell>
                          </TableRow>
                          <TableRow>
                            <TableCell
                              className={classes.border1}
                              component="th"
                              scope="row"
                            >
                              {this.getLabelValue(
                                LABEL_COMPANY_RECORD_COUNT,
                              )}
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >{parseInt(values.CFBKRC1)}</TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >{parseInt(values.CFBKRC2)}</TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >{parseInt(values.CFBKRC3)}</TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >{parseInt(values.CFBKRC4)}</TableCell>
                            <TableCell
                              className={classes.border5}
                              align="centre"
                            >{parseInt(values.CFBKRC5)}</TableCell>
                          </TableRow>
                          <TableRow>
                            <TableCell
                              className={classes.border1}
                              component="th"
                              scope="row"
                            >
                              {this.getLabelValue(
                                LABEL_COMPANY_BYPASS_CONDITIONS,
                              )}
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            />
                            <TableCell
                              className={classes.border}
                              align="centre"
                            />
                            <TableCell
                              className={classes.border}
                              align="centre"
                            />
                            <TableCell
                              className={classes.border}
                              align="centre"
                            />
                            <TableCell
                              className={classes.border5}
                              align="centre"
                            />
                          </TableRow>
                          <TableRow>
                            <TableCell
                              className={classes.border1}
                              component="th"
                              scope="row"
                            >
                              {this.getLabelValue(
                                LABEL_COMPANY_PERIODS_DEMAND_BF,
                              )}
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CFAXPD1}
                                field={{ type: "number", key: "CFAXPD1", Attr: ' ' }}
                                numberType={"integer"}
                                globalDecimalSeparator={"."}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={3}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"0"}
                                maxValue={999}
                                isNegative={false}
                                precisionLength={0}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_PERIODS_DEMAND_BF,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CFAXPD2}
                                field={{ type: "number", key: "CFAXPD2", Attr: ' ' }}
                                numberType={"integer"}
                                globalDecimalSeparator={"."}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={3}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"0"}
                                maxValue={999}
                                isNegative={false}
                                precisionLength={0}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                globalDecimalSeparator={"."}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_PERIODS_DEMAND_BF,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CFAXPD3}
                                field={{ type: "number", key: "CFAXPD3", Attr: ' ' }}
                                numberType={"integer"}
                                globalDecimalSeparator={"."}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={3}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"0"}
                                maxValue={999}
                                isNegative={false}
                                precisionLength={0}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_PERIODS_DEMAND_BF,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CFAXPD4}
                                field={{ type: "number", key: "CFAXPD4", Attr: ' ' }}
                                numberType={"integer"}
                                globalDecimalSeparator={"."}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={3}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"0"}
                                maxValue={999}
                                isNegative={false}
                                precisionLength={0}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_PERIODS_DEMAND_BF,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border5}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CFAXPD5}
                                field={{ type: "number", key: "CFAXPD5", Attr: ' ' }}
                                numberType={"integer"}
                                globalDecimalSeparator={"."}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={3}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"0"}
                                maxValue={999}
                                isNegative={false}
                                precisionLength={0}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_PERIODS_DEMAND_BF,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                          </TableRow>
                          <TableRow>
                            <TableCell
                              className={classes.border1}
                              component="th"
                              scope="row"
                            >
                              {this.getLabelValue(
                                LABEL_COMPANY_BYPASS_ZERO_ONHAND,
                              )}
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CBPZOH1}
                                field={{ type: "checkbox", key: "CBPZOH1" }}
                                numberType={"integer"}
                                isCheckWildCard={true}
                                toUppercase={false}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_BYPASS_ZERO_ONHAND,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CBPZOH2}
                                field={{ type: "checkbox", key: "CBPZOH2" }}
                                numberType={"integer"}
                                isCheckWildCard={true}
                                toUppercase={false}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_BYPASS_ZERO_ONHAND,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CBPZOH3}
                                field={{ type: "checkbox", key: "CBPZOH3" }}
                                numberType={"integer"}
                                isCheckWildCard={true}
                                toUppercase={false}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_BYPASS_ZERO_ONHAND,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CBPZOH4}
                                field={{ type: "checkbox", key: "CBPZOH4" }}
                                numberType={"integer"}
                                isCheckWildCard={true}
                                toUppercase={false}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_BYPASS_ZERO_ONHAND,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border5}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CBPZOH5}
                                field={{ type: "checkbox", key: "CBPZOH5" }}
                                numberType={"integer"}
                                isCheckWildCard={true}
                                toUppercase={false}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_BYPASS_ZERO_ONHAND,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                          </TableRow>
                          <TableRow>
                            <TableCell
                              className={classes.border1}
                              component="th"
                              scope="row"
                            >
                              {this.getLabelValue(
                                LABEL_COMPANY_BYPASS_ON_PROMOTION,
                              )}
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CBPOPR1}
                                field={{ type: "checkbox", key: "CBPOPR1" }}
                                numberType={"integer"}
                                isCheckWildCard={true}
                                toUppercase={false}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_BYPASS_ON_PROMOTION,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CBPOPR2}
                                field={{ type: "checkbox", key: "CBPOPR2" }}
                                numberType={"integer"}
                                isCheckWildCard={true}
                                toUppercase={false}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_BYPASS_ON_PROMOTION,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CBPOPR3}
                                field={{ type: "checkbox", key: "CBPOPR3" }}
                                numberType={"integer"}
                                isCheckWildCard={true}
                                toUppercase={false}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_BYPASS_ON_PROMOTION,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CBPOPR4}
                                field={{ type: "checkbox", key: "CBPOPR4" }}
                                numberType={"integer"}
                                isCheckWildCard={true}
                                toUppercase={false}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_BYPASS_ON_PROMOTION,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border5}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CBPOPR5}
                                field={{ type: "checkbox", key: "CBPOPR5" }}
                                numberType={"integer"}
                                isCheckWildCard={true}
                                toUppercase={false}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_BYPASS_ON_PROMOTION,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                          </TableRow>
                          <TableRow>
                            <TableCell
                              className={classes.border1}
                              align="right"
                              component="th"
                              scope="row"
                            >
                              {this.getLabelValue(
                                LABEL_COMPANY_BYPASS_NWBP,
                              )}
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CBPWBP1}
                                field={{ type: "number", key: "CBPWBP1", Attr: ' ' }}
                                numberType={"integer"}
                                globalDecimalSeparator={"."}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={2}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"0"}
                                maxValue={52}
                                isNegative={false}
                                precisionLength={0}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_BYPASS_NWBP,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CBPWBP2}
                                field={{ type: "number", key: "CBPWBP2", Attr: ' ' }}
                                numberType={"integer"}
                                globalDecimalSeparator={"."}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={2}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"0"}
                                maxValue={52}
                                isNegative={false}
                                precisionLength={0}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_BYPASS_NWBP,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CBPWBP3}
                                field={{ type: "number", key: "CBPWBP3", Attr: ' ' }}
                                numberType={"integer"}
                                globalDecimalSeparator={"."}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={2}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"0"}
                                maxValue={52}
                                isNegative={false}
                                precisionLength={0}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_BYPASS_NWBP,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CBPWBP4}
                                field={{ type: "number", key: "CBPWBP4", Attr: ' ' }}
                                numberType={"integer"}
                                globalDecimalSeparator={"."}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={2}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"0"}
                                maxValue={52}
                                isNegative={false}
                                precisionLength={0}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_BYPASS_NWBP,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border5}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CBPWBP5}
                                field={{ type: "number", key: "CBPWBP5", Attr: ' ' }}
                                numberType={"integer"}
                                globalDecimalSeparator={"."}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={2}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"0"}
                                maxValue={52}
                                isNegative={false}
                                precisionLength={0}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_BYPASS_NWBP,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                          </TableRow>
                          <TableRow>
                            <TableCell
                              className={classes.border1}
                              align="right"
                              component="th"
                              scope="row"
                            >
                              {this.getLabelValue(
                                LABEL_COMPANY_BYPASS_NWAP,
                              )}
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CBPWAP1}
                                field={{ type: "number", key: "CBPWAP1", Attr: ' ' }}
                                numberType={"integer"}
                                globalDecimalSeparator={"."}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={2}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"0"}
                                maxValue={52}
                                isNegative={false}
                                precisionLength={0}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_BYPASS_NWAP,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CBPWAP2}
                                field={{ type: "number", key: "CBPWAP2", Attr: ' ' }}
                                numberType={"integer"}
                                globalDecimalSeparator={"."}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={2}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"0"}
                                maxValue={52}
                                isNegative={false}
                                precisionLength={0}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_BYPASS_NWAP,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CBPWAP3}
                                field={{ type: "number", key: "CBPWAP3", Attr: ' ' }}
                                numberType={"integer"}
                                globalDecimalSeparator={"."}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={2}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"0"}
                                maxValue={52}
                                isNegative={false}
                                precisionLength={0}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_BYPASS_NWAP,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CBPWAP4}
                                field={{ type: "number", key: "CBPWAP4", Attr: ' ' }}
                                numberType={"integer"}
                                globalDecimalSeparator={"."}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={2}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"0"}
                                maxValue={52}
                                isNegative={false}
                                precisionLength={0}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_BYPASS_NWAP,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border5}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CBPWAP5}
                                field={{ type: "number", key: "CBPWAP5", Attr: ' ' }}
                                numberType={"integer"}
                                globalDecimalSeparator={"."}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={2}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"0"}
                                maxValue={52}
                                isNegative={false}
                                precisionLength={0}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_BYPASS_NWAP,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                          </TableRow>
                          <TableRow>
                            <TableCell
                              className={classes.border1}
                              component="th"
                              scope="row"
                            >
                              {this.getLabelValue(
                                LABEL_COMPANY_MIT,
                              )}
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CMINIX1}
                                field={{ type: "number", key: "CMINIX1", Attr: ' ' }}
                                numberType={"decimal"}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={3}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"0.01"}
                                maxValue={0.99}
                                isNegative={false}
                                precisionLength={2}
                                prefixFlag={1}
                                defaultValue={"0.0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                globalDecimalSeparator={"."}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_MIT,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CMINIX2}
                                field={{ type: "number", key: "CMINIX2", Attr: ' ' }}
                                numberType={"decimal"}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={3}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"0.01"}
                                maxValue={0.99}
                                isNegative={false}
                                precisionLength={2}
                                prefixFlag={1}
                                defaultValue={"0.0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                globalDecimalSeparator={"."}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_MIT,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CMINIX3}
                                field={{ type: "number", key: "CMINIX3", Attr: ' ' }}
                                numberType={"decimal"}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={3}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"0.01"}
                                maxValue={0.99}
                                isNegative={false}
                                precisionLength={2}
                                prefixFlag={1}
                                defaultValue={"0.0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                globalDecimalSeparator={"."}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_MIT,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CMINIX4}
                                field={{ type: "number", key: "CMINIX4", Attr: ' ' }}
                                numberType={"decimal"}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={3}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"0.01"}
                                maxValue={0.99}
                                isNegative={false}
                                precisionLength={2}
                                prefixFlag={1}
                                defaultValue={"0.0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                globalDecimalSeparator={"."}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_MIT,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border5}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CMINIX5}
                                field={{ type: "number", key: "CMINIX5", Attr: ' ' }}
                                numberType={"decimal"}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={3}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"0.01"}
                                maxValue={0.99}
                                isNegative={false}
                                precisionLength={2}
                                prefixFlag={1}
                                defaultValue={"0.0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                globalDecimalSeparator={"."}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_MIT,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                          </TableRow>
                          <TableRow>
                            <TableCell
                              className={classes.border1}
                              component="th"
                              scope="row"
                            >
                              {this.getLabelValue(
                                LABEL_COMPANY_DFC,
                              )}
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            />
                            <TableCell
                              className={classes.border}
                              align="centre"
                            />
                            <TableCell
                              className={classes.border}
                              align="centre"
                            />
                            <TableCell
                              className={classes.border}
                              align="centre"
                            />
                            <TableCell
                              className={classes.border5}
                              align="centre"
                            />
                          </TableRow>
                          <TableRow>
                            <TableCell
                              className={classes.border1}
                              component="th"
                              scope="row"
                            >
                              {this.getLabelValue(
                                LABEL_COMPANY_DFH,
                              )}
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CDEMHI1}
                                field={{ type: "number", key: "CDEMHI1", Attr: ' ' }}
                                numberType={"integer"}
                                globalDecimalSeparator={"."}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={1}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"3"}
                                maxValue={9}
                                isNegative={false}
                                precisionLength={0}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_DFH,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CDEMHI2}
                                field={{ type: "number", key: "CDEMHI2", Attr: ' ' }}
                                numberType={"integer"}
                                globalDecimalSeparator={"."}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={1}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"3"}
                                maxValue={9}
                                isNegative={false}
                                precisionLength={0}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_DFH,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CDEMHI3}
                                field={{ type: "number", key: "CDEMHI3", Attr: ' ' }}
                                numberType={"integer"}
                                globalDecimalSeparator={"."}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={1}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"3"}
                                maxValue={9}
                                isNegative={false}
                                precisionLength={0}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_DFH,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CDEMHI4}
                                field={{ type: "number", key: "CDEMHI4", Attr: ' ' }}
                                numberType={"integer"}
                                globalDecimalSeparator={"."}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={1}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"3"}
                                maxValue={9}
                                isNegative={false}
                                precisionLength={0}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_DFH,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border5}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CDEMHI5}
                                field={{ type: "number", key: "CDEMHI5", Attr: ' ' }}
                                numberType={"integer"}
                                globalDecimalSeparator={"."}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={1}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"3"}
                                maxValue={9}
                                isNegative={false}
                                precisionLength={0}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_DFH,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                          </TableRow>
                          <TableRow>
                            <TableCell
                              className={classes.border1}
                              align="right"
                              component="th"
                              scope="row"
                            >
                              {this.getLabelValue(
                                LABEL_COMPANY_DS,
                              )}
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CNDFLH1}
                                field={{ type: "number", key: "CNDFLH1", Attr: ' ' }}
                                numberType={"integer"}
                                globalDecimalSeparator={"."}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={2}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"0"}
                                maxValue={52}
                                isNegative={false}
                                precisionLength={0}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_DS,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CNDFLH2}
                                field={{ type: "number", key: "CNDFLH2", Attr: ' ' }}
                                numberType={"integer"}
                                globalDecimalSeparator={"."}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={2}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"0"}
                                maxValue={52}
                                isNegative={false}
                                precisionLength={0}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_DS,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CNDFLH3}
                                field={{ type: "number", key: "CNDFLH3", Attr: ' ' }}
                                numberType={"integer"}
                                globalDecimalSeparator={"."}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={2}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"0"}
                                maxValue={52}
                                isNegative={false}
                                precisionLength={0}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_DS,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CNDFLH4}
                                field={{ type: "number", key: "CNDFLH4", Attr: ' ' }}
                                numberType={"integer"}
                                globalDecimalSeparator={"."}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={2}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"0"}
                                maxValue={52}
                                isNegative={false}
                                precisionLength={0}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_DS,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border5}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CNDFLH5}
                                field={{ type: "number", key: "CNDFLH5", Attr: ' ' }}
                                numberType={"integer"}
                                globalDecimalSeparator={"."}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={2}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"0"}
                                maxValue={52}
                                isNegative={false}
                                precisionLength={0}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_DS,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                          </TableRow>
                          <TableRow>
                            <TableCell
                              className={classes.border1}
                              align="right"
                              component="th"
                              scope="row"
                            >
                              {this.getLabelValue(
                                LABEL_COMPANY_UPD,
                              )}
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CUHDPF1}
                                field={{ type: "checkbox", key: "CUHDPF1" }}
                                numberType={"integer"}
                                isCheckWildCard={true}
                                toUppercase={false}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_UPD,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CUHDPF2}
                                field={{ type: "checkbox", key: "CUHDPF2" }}
                                numberType={"integer"}
                                isCheckWildCard={true}
                                toUppercase={false}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_UPD,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CUHDPF3}
                                field={{ type: "checkbox", key: "CUHDPF3" }}
                                numberType={"integer"}
                                isCheckWildCard={true}
                                toUppercase={false}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_UPD,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CUHDPF4}
                                field={{ type: "checkbox", key: "CUHDPF4" }}
                                numberType={"integer"}
                                isCheckWildCard={true}
                                toUppercase={false}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_UPD,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border5}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CUHDPF5}
                                field={{ type: "checkbox", key: "CUHDPF5" }}
                                numberType={"integer"}
                                isCheckWildCard={true}
                                toUppercase={false}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_UPD,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                          </TableRow>
                          <TableRow>
                            <TableCell
                              className={classes.border1}
                              component="th"
                              scope="row"
                            >
                              {this.getLabelValue(
                                LABEL_COMPANY_DFL,
                              )}
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CDEMLO1}
                                field={{ type: "number", key: "CDEMLO1", Attr: ' ' }}
                                numberType={"integer"}
                                globalDecimalSeparator={"."}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={1}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"3"}
                                maxValue={9}
                                isNegative={false}
                                precisionLength={0}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_DFL,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CDEMLO2}
                                field={{ type: "number", key: "CDEMLO2", Attr: ' ' }}
                                numberType={"integer"}
                                globalDecimalSeparator={"."}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={1}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"3"}
                                maxValue={9}
                                isNegative={false}
                                precisionLength={0}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_DFL,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CDEMLO3}
                                field={{ type: "number", key: "CDEMLO3", Attr: ' ' }}
                                numberType={"integer"}
                                globalDecimalSeparator={"."}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={1}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"3"}
                                maxValue={9}
                                isNegative={false}
                                precisionLength={0}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_DFL,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CDEMLO4}
                                field={{ type: "number", key: "CDEMLO4", Attr: ' ' }}
                                numberType={"integer"}
                                globalDecimalSeparator={"."}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={1}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"3"}
                                maxValue={9}
                                isNegative={false}
                                precisionLength={0}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_DFL,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border5}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CDEMLO5}
                                field={{ type: "number", key: "CDEMLO5", Attr: ' ' }}
                                numberType={"integer"}
                                globalDecimalSeparator={"."}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={1}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"3"}
                                maxValue={9}
                                isNegative={false}
                                precisionLength={0}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_DFL,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                          </TableRow>
                          <TableRow>
                            <TableCell
                              className={classes.border1}
                              align="right"
                              component="th"
                              scope="row"
                            >
                              {this.getLabelValue(
                                LABEL_COMPANY_DS,
                              )}
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CNDFLL1}
                                field={{ type: "number", key: "CNDFLL1", Attr: ' ' }}
                                numberType={"integer"}
                                globalDecimalSeparator={"."}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={2}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"0"}
                                maxValue={52}
                                isNegative={false}
                                precisionLength={0}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_DS,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CNDFLL2}
                                field={{ type: "number", key: "CNDFLL2", Attr: ' ' }}
                                numberType={"integer"}
                                globalDecimalSeparator={"."}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={2}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"0"}
                                maxValue={52}
                                isNegative={false}
                                precisionLength={0}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_DS,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CNDFLL3}
                                field={{ type: "number", key: "CNDFLL3", Attr: ' ' }}
                                numberType={"integer"}
                                globalDecimalSeparator={"."}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={2}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"0"}
                                maxValue={52}
                                isNegative={false}
                                precisionLength={0}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_DS,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CNDFLL4}
                                field={{ type: "number", key: "CNDFLL4", Attr: ' ' }}
                                numberType={"integer"}
                                globalDecimalSeparator={"."}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={2}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"0"}
                                maxValue={52}
                                isNegative={false}
                                precisionLength={0}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_DS,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border5}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CNDFLL5}
                                field={{ type: "number", key: "CNDFLL5", Attr: ' ' }}
                                numberType={"integer"}
                                globalDecimalSeparator={"."}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={2}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"0"}
                                maxValue={52}
                                isNegative={false}
                                precisionLength={0}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_DS,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                          </TableRow>
                          <TableRow>
                            <TableCell
                              className={classes.border1}
                              align="right"
                              component="th"
                              scope="row"
                            >
                              {this.getLabelValue(
                                LABEL_COMPANY_UPD,
                              )}
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CULDPF1}
                                field={{ type: "checkbox", key: "CULDPF1" }}
                                numberType={"integer"}
                                isCheckWildCard={true}
                                toUppercase={false}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_UPD,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CULDPF2}
                                field={{ type: "checkbox", key: "CULDPF2" }}
                                numberType={"integer"}
                                isCheckWildCard={true}
                                toUppercase={false}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_UPD,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CULDPF3}
                                field={{ type: "checkbox", key: "CULDPF3" }}
                                numberType={"integer"}
                                isCheckWildCard={true}
                                toUppercase={false}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_UPD,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CULDPF4}
                                field={{ type: "checkbox", key: "CULDPF4" }}
                                numberType={"integer"}
                                isCheckWildCard={true}
                                toUppercase={false}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_UPD,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border5}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CULDPF5}
                                field={{ type: "checkbox", key: "CULDPF5" }}
                                numberType={"integer"}
                                isCheckWildCard={true}
                                toUppercase={false}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_UPD,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                          </TableRow>
                          <TableRow>
                            <TableCell
                              className={classes.border1}
                              component="th"
                              scope="row"
                            >
                              {this.getLabelValue(
                                LABEL_COMPANY_FF,
                              )}
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            />
                            <TableCell
                              className={classes.border}
                              align="centre"
                            />
                            <TableCell
                              className={classes.border}
                              align="centre"
                            />
                            <TableCell
                              className={classes.border}
                              align="centre"
                            />
                            <TableCell
                              className={classes.border5}
                              align="centre"
                            />
                          </TableRow>
                          <TableRow>
                            <TableCell
                              className={classes.border1}
                              component="th"
                              scope="row"
                            >
                              {this.getLabelValue(
                                LABEL_COMPANY_TSL,
                              )}
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CTSPNT1}
                                field={{ type: "number", key: "CTSPNT1", Attr: ' ' }}
                                numberType={"integer"}
                                globalDecimalSeparator={"."}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={2}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"30"}
                                maxValue={60}
                                isNegative={false}
                                precisionLength={0}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_TSL,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CTSPNT2}
                                field={{ type: "number", key: "CTSPNT2", Attr: ' ' }}
                                numberType={"integer"}
                                globalDecimalSeparator={"."}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={2}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"30"}
                                maxValue={60}
                                isNegative={false}
                                precisionLength={0}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_TSL,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CTSPNT3}
                                field={{ type: "number", key: "CTSPNT3", Attr: ' ' }}
                                numberType={"integer"}
                                globalDecimalSeparator={"."}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={2}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"30"}
                                maxValue={60}
                                isNegative={false}
                                precisionLength={0}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_TSL,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CTSPNT4}
                                field={{ type: "number", key: "CTSPNT4", Attr: ' ' }}
                                numberType={"integer"}
                                globalDecimalSeparator={"."}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={2}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"30"}
                                maxValue={60}
                                isNegative={false}
                                precisionLength={0}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_TSL,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border5}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CTSPNT5}
                                field={{ type: "number", key: "CTSPNT5", Attr: ' ' }}
                                numberType={"integer"}
                                globalDecimalSeparator={"."}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={2}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"30"}
                                maxValue={60}
                                isNegative={false}
                                precisionLength={0}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_TSL,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                          </TableRow>
                          <TableRow>
                            <TableCell
                              className={classes.border1}
                              component="th"
                              scope="row"
                            >
                              {this.getLabelValue(
                                LABEL_COMPANY_BAF,
                              )}
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CBALFA1}
                                field={{ type: "number", key: "CBALFA1", Attr: ' ' }}
                                numberType={"integer"}
                                globalDecimalSeparator={"."}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={2}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"5"}
                                maxValue={30}
                                isNegative={false}
                                precisionLength={0}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_BAF,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CBALFA2}
                                field={{ type: "number", key: "CBALFA2", Attr: ' ' }}
                                numberType={"integer"}
                                globalDecimalSeparator={"."}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={2}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"5"}
                                maxValue={30}
                                isNegative={false}
                                precisionLength={0}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_BAF,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CBALFA3}
                                field={{ type: "number", key: "CBALFA3", Attr: ' ' }}
                                numberType={"integer"}
                                globalDecimalSeparator={"."}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={2}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"5"}
                                maxValue={30}
                                isNegative={false}
                                precisionLength={0}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_BAF,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CBALFA4}
                                field={{ type: "number", key: "CBALFA4", Attr: ' ' }}
                                numberType={"integer"}
                                globalDecimalSeparator={"."}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={2}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"5"}
                                maxValue={30}
                                isNegative={false}
                                precisionLength={0}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_BAF,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border5}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CBALFA5}
                                field={{ type: "number", key: "CBALFA5", Attr: ' ' }}
                                numberType={"integer"}
                                globalDecimalSeparator={"."}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={2}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"5"}
                                maxValue={30}
                                isNegative={false}
                                precisionLength={0}
                                prefixFlag={1}
                                defaultValue={"0"}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                isColumnEditable={true}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_BAF,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                          </TableRow>
                          <TableRow>
                            <TableCell
                              className={classes.border1}
                              component="th"
                              scope="row"
                            >
                              {this.getLabelValue(
                                LABEL_COMPANY_UL,
                              )}
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            />
                            <TableCell
                              className={classes.border}
                              align="centre"
                            />
                            <TableCell
                              className={classes.border}
                              align="centre"
                            />
                            <TableCell
                              className={classes.border}
                              align="centre"
                            />
                            <TableCell
                              className={classes.border5}
                              align="centre"
                            />
                          </TableRow>
                          <TableRow>
                            <TableCell
                              className={classes.border1}
                              component="th"
                              scope="row"
                            >
                              {this.getLabelValue(
                                LABEL_COMPANY_FMPI,
                              )}
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CFIPCT1}
                                field={{ type: "number", key: "CFIPCT1", Attr: ' ' }}
                                numberType={"decimal"}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={4}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"0.0"}
                                maxValue={999.9}
                                isNegative={false}
                                precisionLength={1}
                                prefixFlag={1}
                                defaultValue={"0.0"}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onFocusOut={() => this.setValueDataOnFocutOut('CFIPCT1')}
                                isColumnEditable={true}
                                globalDecimalSeparator={"."}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_FMPI,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CFIPCT2}
                                field={{ type: "number", key: "CFIPCT2", Attr: ' ' }}
                                numberType={"decimal"}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={4}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"0.0"}
                                maxValue={999.9}
                                isNegative={false}
                                precisionLength={1}
                                prefixFlag={1}
                                defaultValue={"0.0"}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onFocusOut={() => this.setValueDataOnFocutOut('CFIPCT2')}
                                isColumnEditable={true}
                                globalDecimalSeparator={"."}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_FMPI,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CFIPCT3}
                                field={{ type: "number", key: "CFIPCT3", Attr: ' ' }}
                                numberType={"decimal"}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={4}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"0.0"}
                                maxValue={999.9}
                                isNegative={false}
                                precisionLength={1}
                                prefixFlag={1}
                                defaultValue={"0.0"}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onFocusOut={() => this.setValueDataOnFocutOut('CFIPCT3')}
                                isColumnEditable={true}
                                globalDecimalSeparator={"."}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_FMPI,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CFIPCT4}
                                field={{ type: "number", key: "CFIPCT4", Attr: ' ' }}
                                numberType={"decimal"}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={4}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"0.0"}
                                maxValue={999.9}
                                isNegative={false}
                                precisionLength={1}
                                prefixFlag={1}
                                defaultValue={"0.0"}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onFocusOut={() => this.setValueDataOnFocutOut('CFIPCT4')}
                                isColumnEditable={true}
                                globalDecimalSeparator={"."}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_FMPI,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border5}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CFIPCT5}
                                field={{ type: "number", key: "CFIPCT5", Attr: ' ' }}
                                numberType={"decimal"}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={4}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"0.0"}
                                maxValue={999.9}
                                isNegative={false}
                                precisionLength={1}
                                prefixFlag={1}
                                defaultValue={"0.0"}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onFocusOut={() => this.setValueDataOnFocutOut('CFIPCT5')}
                                isColumnEditable={true}
                                globalDecimalSeparator={"."}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_FMPI,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                          </TableRow>
                          <TableRow>
                            <TableCell
                              className={classes.border8}
                              align="right" //E3C-33359, 12/7/21, Kumar
                              component="th"
                              scope="row"
                            >
                              {this.getLabelValue(
                                LABEL_COMPANY_FMPD,
                              )}
                            </TableCell>
                            <TableCell
                              className={classes.border6}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CFDPCT1}
                                field={{ type: "number", key: "CFDPCT1", Attr: ' ' }}
                                numberType={"decimal"}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={3}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"0.0"}
                                maxValue={99.9}
                                isNegative={false}
                                precisionLength={1}
                                prefixFlag={1}
                                defaultValue={"0.0"}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onFocusOut={() => this.setValueDataOnFocutOut('CFDPCT1')}
                                isColumnEditable={true}
                                globalDecimalSeparator={"."}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_FMPD,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border6}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CFDPCT2}
                                field={{ type: "number", key: "CFDPCT2", Attr: ' ' }}
                                numberType={"decimal"}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={3}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"0.0"}
                                maxValue={99.9}
                                isNegative={false}
                                precisionLength={1}
                                prefixFlag={1}
                                defaultValue={"0.0"}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onFocusOut={() => this.setValueDataOnFocutOut('CFDPCT2')}
                                isColumnEditable={true}
                                globalDecimalSeparator={"."}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_FMPD,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border6}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CFDPCT3}
                                field={{ type: "number", key: "CFDPCT3", Attr: ' ' }}
                                numberType={"decimal"}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={3}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"0.0"}
                                maxValue={99.9}
                                isNegative={false}
                                precisionLength={1}
                                prefixFlag={1}
                                defaultValue={"0.0"}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onFocusOut={() => this.setValueDataOnFocutOut('CFDPCT3')}
                                isColumnEditable={true}
                                globalDecimalSeparator={"."}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_FMPD,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border6}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CFDPCT4}
                                field={{ type: "number", key: "CFDPCT4", Attr: ' ' }}
                                numberType={"decimal"}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={3}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"0.0"}
                                maxValue={99.9}
                                isNegative={false}
                                precisionLength={1}
                                prefixFlag={1}
                                defaultValue={"0.0"}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onFocusOut={() => this.setValueDataOnFocutOut('CFDPCT4')}
                                isColumnEditable={true}
                                globalDecimalSeparator={"."}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_FMPD,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                            <TableCell
                              className={classes.border7}
                              align="centre"
                            >
                              <FieldInput
                                className={classes.simpleCardInput}
                                value={values.CFDPCT5}
                                field={{ type: "number", key: "CFDPCT5", Attr: ' ' }}
                                numberType={"decimal"}
                                isCheckWildCard={true}
                                toUppercase={false}
                                maxLength={3}
                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.isTrue}
                                minValue={"0.0"}
                                maxValue={99.9}
                                isNegative={false}
                                precisionLength={1}
                                prefixFlag={1}
                                defaultValue={"0.0"}
                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                enableAddButton={e => setSaveData(e)}
                                onChange={(key, val) => this.handleChangeValue(key, val)}
                                onFocusOut={() => this.setValueDataOnFocutOut('CFDPCT5')}
                                isColumnEditable={true}
                                globalDecimalSeparator={"."}
                                errorMessageLabel={this.getMessageText(
                                  LABEL_COMPANY_FMPD,
                                )} //E3C-30006, 6/29/21, Kumar
                              />
                            </TableCell>
                          </TableRow>
                        </TableBody>
                      </Table>
                    </TableContainer>
                  </Card>
                </div>
              </div>
            </Grid>
          </Grid>
        </div>
      </div>
    );
  }
}

export default withStyles(styles)(ForecastingFactorsMatrix);

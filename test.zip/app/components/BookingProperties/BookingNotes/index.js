/** Change Log
 * LogStart --  Story: E3C-33260 --Note is not getting saved. Check after some time, the note is not there.
*/
import React from 'react';
import { connect } from 'react-redux';
import { compose } from 'redux';
import { withStyles } from '@material-ui/core/styles';
import injectReducer from 'utils/injectReducer';
import injectSaga from 'utils/injectSaga';
import PropTypes from 'prop-types';

import { ExpansionPanel, ExpansionPanelSummary, ExpansionPanelDetails, createMuiTheme, MuiThemeProvider, Box, Typography } from '@material-ui/core';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import theme from '../../../jda-gcp-theme';

import reducer from './reducer';
import saga from './saga';
import FormattedMessageComponent from '../../common/FormattedMessageComponent';
import {
    LABEL_NOTE, BOOKING_NOTES_FILTER_PROPS,
    BOOKING_NOTES,
    NO_NOTES_TO_SHOW_TEXT,
    FILTER_DATA,
    NOTES_TEXT_ACCESSOR,
    MENU_ITEMS,
    NOTES_KEY_ACCESSOR
} from './constants';
import {
    getBookingNotes, clearNotesData, getNoteDetails, setSelectedNoteDetails, controlNoteCreation, setControlNoteCount,
    removeNoteByKey, clearAllBookingNotes, setIsEmbeddedList, clearStateValues
} from './action';
import { selectData, makeSelectCompanyDetails } from './selector';
import AccordionComponent from '../../common/AccordionComponent';
import {
    COLUMN_HEADER_ACCESSOR,
    COLUMN_FIELD_LEN,
    COLUMN_VALUE_ACCESSOR
} from '../../common/constants';

import {
    getListPredecessor,
    handleFieldValuesByLength,
    prepareValueWithSpaces
} from 'utils/util';
import NoteProperties from '../../../containers/common/NoteProperties/index';
import GarbageIcon from '../../../images/garbage.png';
import ContextMenu from '../../common/ContextMenu';
import MoreVertIcon from '@material-ui/icons/MoreVert';
import { NOTE_DETAILS_FILTER, NOTE_TEXT_KEY } from '../../../containers/common/NoteProperties/constants';
import { isEqual } from 'lodash';
import { leftPad } from '../../../utils/util';
import Spinner from '../../common/Spinner';
import { getNewNoteCreationControlBody } from '../../../utils/noteUtils';

const propTypes = {

}

const themes = createMuiTheme(theme);

themes.overrides = {

    MuiExpansionPanelSummary: {
        root: {
            borderRadius: '4px',
            borderBottom: '0px solid var(--divider-line)',
            padding: '0 30px',
            minHeight: '40px',
            background: 'var(--secondary-s5)',
            color: 'var(--text)',
            fontSize: '1rem',
            minHeight: '40px',
            '&.Mui-expanded': {
                minHeight: '50px',
                borderBottom: '1.5px solid var(--divider-line)',
                backgroundColor: 'var(--secondary-s5)',
                borderRadius: '4px 4px 0 0'
            }
        },
        content: {
            margin: '0 !important',
            alignItems: 'baseline',
        },
    },
    MuiExpansionPanelDetails: {
        root: {
            borderRadius: '0 0 4px 4px',
            background: 'var(--secondary-s5)',
            padding: '16px',
        },
    },
    MuiButton: {
        root: {
            [theme.breakpoints.up('md')]: {
                fontSize: '14px',
            },
        },
        sizeLarge: {
            padding: '7px 16px'
        },
        // For contained type buttons configuration
        contained: {
            boxShadow: theme.shadows[5],
            color: '#ffffff',
        },
        containedPrimary: {
            backgroundColor: '#0066D0'
        },
        containedSecondary: {
            backgroundColor: '#9A9A9A',
            '&:hover': {
                backgroundColor: '#9A9A9A',
                opacity: 0.9
            }
        },

        // For outlined type buttons configuration
        outlined: {
        },
        outlinedPrimary: {
            color: '#0066D0',
            border: '1px solid #0066D0'
        },
        outlinedSecondary: {
            color: '#9A9A9A',
            border: '1px solid #9A9A9A'
        },

        // For text type buttons configuration
        text: {},
        textPrimary: {},
        textSecondary: {},
    },
    MuiAutocomplete: {
        listbox: {
            backgroundColor: '#ffffff'
        },
        clearIndicator: {
            display: 'none'
        },
        input: {
            color: '#000000',
        },
        inputRoot: {
            paddingRight: 10,
            paddingLeft: 5,
            'input': {
                padding: 0
            }
        },
        popupIndicator: {
            marginTop: 3,
            marginRight: '-5px'
        }
    },
    MuiInput: {
        root: {
            height: 25,
            maxWidth: '13rem'
        },
        input: {
        },
        underline: {
            '&:after': {
                borderBottom: '1px solid #3F4756',
            },
            '&:before': {
                borderBottom: '1px solid #3F4756',
            },
            '&:hover:after': {
                borderBottom: '2px solid ' + theme.palette.primary.default,
            },
            '&.Mui-disabled:before': {
                borderBottom: '1px solid ' + theme.palette.primary.disabled,
                borderBottomStyle: 'solid',
            }
        }
    },
    MuiList: {
        root: {
            backgroundColor: '#ffffff'
        }
    },
    MuiTable: {
        root: {
            [theme.breakpoints.up('md')]: {
                width: '698px'
            }
        }
    },
    MuiTableCell: {
        root: {
            padding: '.3rem .6rem .3rem 0',
        },
        head: {
            fontSize: '1rem',
            color: theme.palette.common.smokeWhite,
        },
        body: {
            border: 'none'
        }
    },
    MuiFormControlLabel: {
        root: {
            marginRight: 0,
        },
        labelPlacementTop: {
            alignItems: 'flex-start',
            marginLeft: 0,
        },
        label: {
            fontSize: '12px',
            color: theme.palette.common.label,
            padding: '10px 10px 10px 0',
        }
    },
    MuiInputBase: {
        root: {
            fontSize: 14,
            fontWeight: 400
        },
        input: {
            color: theme.palette.common.inputTextValue
        }
    },
    MuiTableHead: {
        root: {
            backgroundColor: theme.palette.common.starCommandBlue,
        },
    },
    MuiTabs: {
        root: {
            position: 'relative',
            backgroundColor: 'var(--backgournd-app)',
            minHeight: 35,
            borderRadius: '16px',
            width: 'fit-content',
            border: '1px solid var(--secondary-s5)',
        },
        indicator: {
            backgroundColor: '#0066D0'
        }
    },
    MuiTabIndicator: {
        root: {
            height: '4px',
        },
    },
    MuiTab: {
        root: {
            fontSize: '12px',
            fontWeight: '500',
            [theme.breakpoints.up('md')]: {
                minWidth: 50,
                padding: '0 20px',
                margin: '0',
                fontSize: '14px',
                fontWeight: '500',
                minHeight: 32
            },
        },
        textColorPrimary: {
            color: '#000000',
            backgroundColor: 'var(--background-app)',
            '&.Mui-selected': {
                backgroundColor: 'var(--inputText-value)',
                color: 'var(--background-app)',
            }
        }
    },
    MuiIconButton: {
        // root currently only being used in the error notifications, or any MuiIconButton with no color specified.
        root: {
            color: '#412f2f',
        },
        // colorPrimary: {
        //   color: '#0e0e0e',
        // },
    },
    MuiAppBar: {
        root: {
            boxShadow: 'none',
        },
        colorPrimary: {
            backgroundColor: theme.palette.common.darkOliveGreen,
        }
    },
    MuiMenu: {
        paper: {
            borderRadius: 4,
        },
        list: {
            '& > *': {
                padding: '0.6rem'
            }
        }
    },
    MuiFormLabel: {
        root: {
            color: 'black',
        },
    },
    MuiFormHelperText: {
        root: {
            color: 'gray',
        },
    },
    MuiSelect: {
        root: {
            // color: 'black',
        },
        selectMenu: {
            height: '100%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'inherit'
        }
    },
    MuiCard: {
        root: {
            padding: '1rem',
        },
    },
    MuiOutlinedInput: {
        root: {
            padding: '.5rem',
            height: '100%',
            alignItems: 'flex-start'
        },
        input: {
            padding: '0'
        }
    },
    MuiDialogContent: {
        root: {
            backgroundColor: theme.palette.common.white,
            padding: '8px 0'
        }
    },
    MuiDialogActions: {
        root: {
            padding: '8px 16px',
            backgroundColor: theme.palette.common.white
        }
    },
    MuiDialogTitle: {
        root: {
            backgroundColor: '#ffffff',
            borderBottom: '1px solid #d8d8d8',
            padding: '9px 16px'
        }
    },
    MuiPaper: {
        root: {
            backgroundColor: theme.palette.common.white
        },
        elevation1: {
            boxShadow: '0 2px 4px 0 rgba(148,148,148,0.5)'
        },
        rounded: {
            borderRadius: 0
        }
    },
    MuiDialog: {
        paperWidthSm: {
            [theme.breakpoints.up('sm')]: {
                maxWidth: '767px',
                height: 'calc(100% - 96px)',
            },
            [theme.breakpoints.up('md')]: {
                height: 'calc(100% - 96px)',
                minWidth: '768px'
            }
        },
        paper: {
            margin: 0
        },
        paperFullScreen: {
            width: '93vw',
            height: '90vh',
        }
    },
    MuiTooltip: {
        tooltip: {
            lineHeight: 1.4,
            backgroundColor: '#929292',
            padding: '4px 8px 4px 8px',
            color: '#fff',// theme.palette.common.white,
            fontSize: '10px',
            borderRadius: '0',
            fontWeight: theme.typography.fontWeightLight,
        }
    }
}

const style = theme => ({
    BookingNotesPanelWrapper: {
        borderRadius: '4px',
        overflow: 'hidden',
        border: '1.5px solid var(--divider-line)',
        fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
        marginBottom: '1rem',
    },
    BookingNotesPanelDetails: {
        display: 'flex',
        flexDirection: 'column',
        width: '100%',
        maxHeight: '300px',
        overflowY: 'auto'
    },
    BookingNotesCount: {
        padding: '2px 10px 1px 10px',
        border: '1.5px solid var(--divider-line)',
        borderRadius: '10px',
        margin: '0 16px',
        backgroundColor: 'var(--secondary-s5)',
    },
    BookingNotesNote: {
        padding: '1rem',
        border: '1px',
        borderBottom: '1px solid var(--divider-line)',
        '&:last-child': {
            borderBottom: 'none',
        },
        '&:hover': {
            backgroundColor: 'var(--list-hover)',
        }
    },
    NoNotesToShow: {
        display: 'flex',
        width: '100%',
        justifyContent: 'center',
        alignItems: 'center',
        padding: '1rem'
    },
    selectedNote: {
        backgroundColor: 'var(--list-hover)'
    },
    notesActionWrapper: {
        display: 'flex',
        alignSelf: 'flex-end',
        paddingBottom: '10px'
    },
    notesParent: {
        display: 'flex',
        flexDirection: 'column',
        width: '100%'
    }
});

class BookingNotes extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            isBookingNotesPanelExpanded: true,
            notesCount: 0,
            notesArray: false,
            isOpenProperties: false,
            isOpenContextMenu: false,
            menuRef: null,
            isUpdateType: false,
            selectedIndex: -1,
            hasToDeleteAll: false,
            hasToDelete: false,
            noteKeyForDetails: false,
            menuList: MENU_ITEMS,
            allowUpdateSecurity: true,
            notesCount: 0,
        }
        this.prepareKeyValue = this.prepareKeyValue.bind(this);
        this.prepareFilterProps = this.prepareFilterProps.bind(this);
    }

    getApiObj(filterProps, currentPage, pageProps) {

        let apiObj = {
            filterProps,
            pageProps: pageProps,
            direction: pageProps.isForwardDirection,
            currentPage: currentPage,
            parentPage: BOOKING_NOTES
        };
        return apiObj;
    }

    prepareKeyValue(jsonData) {
        const { columnDefs, currentPage } = this.props;
        let headerKey = COLUMN_VALUE_ACCESSOR;
        let fieldLenKey = COLUMN_FIELD_LEN;
        let filterValues = FILTER_DATA;
        if (columnDefs && columnDefs.length) {
            let filterData = '';
            filterValues.forEach((filter) => {
                let columnData = columnDefs.find((column) => {
                    let columnKey = column[headerKey].trim();
                    return columnKey == filter;
                });
                if (columnData && Object.keys(columnData) && Object.keys(columnData).length) {
                    let fieldLen = Number(columnData[fieldLenKey].trim());
                    if (columnData.FDFNAM.trim() === "CSID") { // this is because though the field len is 10 thick client sends 8 char
                        fieldLen = 8;
                    }
                    let columnKey = columnData.prefixFlag ? (columnData[headerKey].trim()) : (getListPredecessor(currentPage) + columnData[headerKey].trim());
                    let dataValue = jsonData[columnKey] ? jsonData[columnKey].trim() : jsonData[columnKey];
                    let str = handleFieldValuesByLength(dataValue, fieldLen);
                    filterData = filterData + str;
                }
            })
            filterData = filterData + prepareValueWithSpaces("", 22);
            return filterData;
        }
        return '';
    }

    prepareFilterProps(data) {
        let filterData = JSON.parse(JSON.stringify(data));
        const { currentPage, currentRecordData, fromPage } = this.props;
        filterData[0]["fieldValue"] = getListPredecessor('bookings'); 
        filterData[1]["fieldValue"] = this.prepareKeyValue(currentRecordData);
        return filterData;
    }

    componentWillUnmount(){
        this.props.clearStateValues();
    }

    componentDidMount() {
        const { filterProps, columnDefs, canUpdateComponent } = this.props;
        const { pageProps, notesArray } = this.props.BookingNotesData;
        this.props.clearNotesData();
        this.props.setNotesCount(0); //E3C30273_RRUDRA_Set counts to zero when switching from one tab to other
        if (columnDefs && columnDefs.length) {
            this.loadBookingNotes();
        }
        //E3C30273_RRUDRA_Disable removeAll if Notes count is zero
        let menuList = this.state.menuList;
        menuList[0].isDisable = true;
        this.setState({ menuList: menuList });
        //Disable, notes menu items based security restrictions
        if (canUpdateComponent && !canUpdateComponent.update) {
            this.state.menuList[0]['isDisable'] = true;
            this.state.menuList[1]['isDisable'] = true;
            this.state.allowUpdateSecurity = false
        }

    }

    loadBookingNotes = () => {
        const { bracketsNotesFilterObj, currentRecordData } = this.props;
        if (bracketsNotesFilterObj && currentRecordData) {
            this.prepareChangedFilterObj();
        } else{
            let filterData = this.prepareFilterProps(BOOKING_NOTES_FILTER_PROPS);
            //RRUDRA_send company date along with reach request for notes list
            let record = {CJDATE : this.props.companyDetails['CJDATE']}
            if (record.CJDATE != undefined) { //E3C-33260, 10/14/21, Kumar:Start
                this.props.getBookingNotes({body: this.getApiObj(filterData, BOOKING_NOTES, this.props.BookingNotesData.pageProps), record});
            } //E3C-33260, 10/14/21, Kumar:End
        }
    }

    changeJSONObjectValues = (key, value, jsonObj) => {
        let headerKey = COLUMN_VALUE_ACCESSOR;
        let fieldLenKey = COLUMN_FIELD_LEN;
        const { bracketsNotesFilterObj, currentPage, currentRecordData, fromPage, columnDefs } = this.props;
        let filterData = FILTER_DATA;
        if (columnDefs && columnDefs.length && jsonObj) {
            let columnData = columnDefs.find((column) => {
                let columnKey = column[headerKey].trim();
                return columnKey == key;
            });
            if (columnData && Object.keys(columnData) && Object.keys(columnData).length) {
                let columnKey = columnData.prefixFlag ? (columnData[headerKey].trim()) : (getListPredecessor(currentPage) + columnData[headerKey].trim());
                jsonObj[columnKey] = value;
            }
        }
        return jsonObj;
    }

    prepareChangedFilterObj = () => {
        const { pageProps } = this.props.BookingNotesData;
        const { bracketsNotesFilterObj, currentPage, currentRecordData, fromPage, columnDefs } = this.props;
        let jsonObj = JSON.parse(JSON.stringify(currentRecordData));
        let filterValues = FILTER_DATA;
        if (bracketsNotesFilterObj) {
            if (bracketsNotesFilterObj.warehouseId) {
                jsonObj = this.changeJSONObjectValues(filterValues[3], bracketsNotesFilterObj.warehouseId, jsonObj);
            }
            if (bracketsNotesFilterObj.itemId) {
                jsonObj = this.changeJSONObjectValues(filterValues[1], bracketsNotesFilterObj.itemId, jsonObj);
            }
            if (bracketsNotesFilterObj.custId) {
                jsonObj = this.changeJSONObjectValues(filterValues[2], bracketsNotesFilterObj.custId, jsonObj);
            }
            if (bracketsNotesFilterObj.shipDt) {
                jsonObj = this.changeJSONObjectValues(filterValues[4], bracketsNotesFilterObj.shipDt, jsonObj);
            }
        }

        let filterData = JSON.parse(JSON.stringify(BOOKING_NOTES_FILTER_PROPS));
        filterData[0]["fieldValue"] = getListPredecessor('bookings');
        filterData[1]["fieldValue"] = this.prepareKeyValue(jsonObj);
        //RRUDRA_send company date along with each request for notes list
        let record = {CJDATE : this.props.companyDetails['CJDATE']}
        if (record.CJDATE != undefined) { //E3C-33260, 10/14/21, Kumar:Start
            this.props.getBookingNotes({body: this.getApiObj(filterData, BOOKING_NOTES, pageProps), record});
        } //E3C-33260, 10/14/21, Kumar:End
    }

    componentDidUpdate(prevProps) {
        const { notesArray, pageProps, selectedNoteDetails, controlCount, allNotesDetails, combinedNotes, isSetEmbeddedList } = this.props.BookingNotesData;
        const { columnDefs, currentRecordData, bracketsNotesFilterObj, companyDetails } = this.props; //E3C-33260, 10/14/21, Kumar

        if (!isEqual(isSetEmbeddedList, prevProps.BookingNotesData.isSetEmbeddedList ) && isSetEmbeddedList) {
            if (this.props.updatedNotesData)
                this.props.updatedNotesData();
            this.props.setIsEmbeddedList();
        }

        if (bracketsNotesFilterObj && (JSON.stringify(bracketsNotesFilterObj) != JSON.stringify(prevProps.bracketsNotesFilterObj))) {
            this.props.clearNotesData(); //E3C30273
            this.loadBookingNotes();
        }

        if (notesArray && !isEqual(notesArray, prevProps.BookingNotesData.notesArray )) {
            if(notesArray['listArray'])
              this.setState({ notesCount: notesArray.listArray.length });
            else 
              this.setState({ notesCount: notesArray.length });
        }
        if (columnDefs && (JSON.stringify(columnDefs) != JSON.stringify(prevProps.columnDefs))) {
            this.loadBookingNotes();
        }
        if ((JSON.stringify(currentRecordData) != JSON.stringify(prevProps.currentRecordData)) && currentRecordData) {
            this.props.clearNotesData(); //E3C30273
            this.loadBookingNotes();
        }
        if ((controlCount == 0) && (prevProps.BookingNotesData.controlCount != 0) && (this.state.hasToDelete || this.state.hasToDeleteAll)) {
            this.setState({ hasToDelete: false, hasToDeleteAll: false });
            this.loadBookingNotes();
        }
        if (companyDetails && !isEqual(companyDetails,  prevProps.companyDetails)) { //E3C-33260, 10/14/21, Kumar:Start
            this.props.clearNotesData(); //E3C30273
            this.loadBookingNotes();
        } //E3C-33260, 10/14/21, Kumar:End
        if (!this.state.noteKeyForDetails && combinedNotes && combinedNotes.length && !isEqual(combinedNotes, prevProps.BookingNotesData.combinedNotes) && (!allNotesDetails.length)) {
            this.setState({ noteKeyForDetails: false });
            combinedNotes.forEach((note, index) => {
                this.getNoteDetails(note[0][NOTES_KEY_ACCESSOR], true, true);
            })
        }
        // After adding new node or updating
        if (this.state.noteKeyForDetails && combinedNotes && combinedNotes.length && (!isEqual(combinedNotes, prevProps.BookingNotesData.combinedNotes) || !isEqual(allNotesDetails, prevProps.BookingNotesData.allNotesDetails))) {
            this.setState({ noteKeyForDetails: false });
            this.getNoteDetails(this.state.noteKeyForDetails, false, true);
        }
        
        if (allNotesDetails && !isEqual(allNotesDetails, prevProps.BookingNotesData.allNotesDetails)) {
            //update notes in Header
            this.props.setNotesCount(allNotesDetails.length);

            //Disable or Enable right menu 'Remove All' options of Notes based on notes count  
            if (allNotesDetails.length == 0 && this.state.menuList[0].isDisable == false) {
                let menuList = this.state.menuList;
                menuList[0].isDisable = true;
                this.setState({ menuList: menuList });
            }

            if (allNotesDetails.length > 0 && this.state.menuList[0].isDisable == true) {
                let menuList = this.state.menuList;
                menuList[0].isDisable = false;
                this.setState({ menuList: menuList });
            }

        }

        //~~~CreateNewFramework--JVK
        if (this.props.isOpenNote && this.props.isOpenNote !== prevProps.isOpenNote) {
            this.setNotePropertiesOpen(true, false);
        }
        //~~~CreateNewFramework--JVK
    }

    setNotePropertiesOpen = (val, noteType) => {
        this.props.setSelectedNoteDetails(false);
        if (!val) {
            this.setState({ hasToDelete: false, hasToDeleteAll: false });
        }
        this.setState({ isOpenProperties: val });
        this.setState({ isUpdateType: noteType ? noteType : false });
        //~~~CreateNewFramework--JVK
        if (typeof this.props.closeNote === 'function' && (noteType && noteType == false)) {
            this.props.closeNote(val);
        }
        //~~~CreateNewFramework--JVK
    }

    // Close or open context menu
    setIsOpenContextMenu(val) {
        this.setState({ isOpenContextMenu: Boolean(val) });
        this.setState({ menuRef: val.currentTarget ? val.currentTarget : val });
    }

    handleItemSelection = (val) => {
        switch (val) {
            case this.state.menuList[1].key: this.setNotePropertiesOpen(true); break;
            case this.state.menuList[0].key: this.deleteAllNotes(); break;
        }
        this.setIsOpenContextMenu(false);
    }
    deleteAllNotes = () => {
        this.setState({ hasToDeleteAll: true });
        this.props.clearAllBookingNotes();
        this.props.BookingNotesData.allNotesDetails.forEach((note, index) => {
            this.deleteNote(note[0]);
        })
    }
    getNoteDetails = (indexOrKey, allFlag, isKey) => {
        const { combinedNotes, pageProps, allNotesDetails } = this.props.BookingNotesData;
        let filters = JSON.parse(JSON.stringify(NOTE_DETAILS_FILTER));
        let key = isKey ? indexOrKey : allNotesDetails[indexOrKey][0][NOTES_KEY_ACCESSOR];
        key = leftPad(key, 7, '0');
        filters[0].fieldValue = key;
        let record = {CJDATE:this.props.companyDetails['CJDATE'] }
        if (record.CJDATE != undefined) { //E3C-33260, 10/14/21, Kumar:Start
            this.props.getNoteDetails({ body: this.getApiObj(filters, BOOKING_NOTES, pageProps), allFlag, record })
        } //E3C-33260, 10/14/21, Kumar:End
    }

    getApiObj(filterProps, currentPage, pageProps) {

        let apiObj = {
            filterProps,
            pageProps: pageProps,
            direction: pageProps.isForwardDirection,
            currentPage: currentPage,
        };
        return apiObj;
    }

    onClickRemove = () => {
        // delete selectedIndex row
        this.setState({ hasToDelete: true });
        let data = this.props.BookingNotesData.allNotesDetails[this.state.selectedIndex][0]
        this.deleteNote(data);
        this.props.removeNoteByKey({ key: data[NOTES_KEY_ACCESSOR], filterAllNotes: true, filterCombined: true });
    }

    noteSelection = (index) => {
        this.setState({ selectedIndex: index });
    }

    deleteNote = (data) => {
        const { currentRecordData, currentPage } = this.props;
        let body = getNewNoteCreationControlBody(data, 'D', currentPage, BOOKING_NOTES, currentRecordData, data[NOTES_KEY_ACCESSOR]);
        this.props.controlNoteCreation({ body });
    }

    reloadNotes = (noteKey, isFutureDate) => {
        let key = leftPad(noteKey, 7, '0');
        if (!isFutureDate) {
            if (this.state.isUpdateType) {
                this.props.removeNoteByKey({ key, filterAllNotes: true });
            } else {
                this.loadBookingNotes();
            }
            this.setState({ noteKeyForDetails: key });
        } else {
            if (this.state.isUpdateType)  this.props.removeNoteByKey({ key, filterAllNotes: true, filterCombined: true });
        }
    }

    render() {

        const { classes, noteLabelJson } = this.props;
        const { isBookingNotesPanelExpanded, notesCount } = this.state;
        const { notesArray, combinedNotes, selectedNoteDetails, allNotesDetails } = this.props.BookingNotesData;
        return (
            <div className={classes.BookingNotesPanelWrapper}>
                <AccordionComponent
                    isPanelExpanded={isBookingNotesPanelExpanded}
                    onChange={(event, expanded) => this.setState({ isBookingNotesPanelExpanded: expanded })}
                    label={LABEL_NOTE}
                    count={allNotesDetails.length}
                    badgeWidth = {allNotesDetails.length < 10 ? '22px': '27px'}
                >
                    <div className={classes.notesParent}>
                        <div className={classes.notesActionWrapper}>
                            {(notesCount > 0) && (this.state.selectedIndex > -1) && (this.state.allowUpdateSecurity) && <Box mr={theme.spacing(1)}><Typography onClick={() => { this.setNotePropertiesOpen(true, true) }} className={'cPointer'}>{<FormattedMessageComponent id={'51182'}></FormattedMessageComponent>}</Typography></Box>}
                            {(notesCount > 0) && (this.state.selectedIndex > -1) && (this.state.allowUpdateSecurity) && <Box mr={theme.spacing(1)}><Typography onClick={() => this.onClickRemove()} className={'cPointer'}>{<FormattedMessageComponent id={'25303'}></FormattedMessageComponent>}</Typography> </Box>}
                            {MENU_ITEMS && MENU_ITEMS.length &&
                                <div onMouseEnter={(event) => this.setIsOpenContextMenu(event)}
                                    onMouseLeave={(event) => this.setIsOpenContextMenu(false)}>
                                    <MoreVertIcon className={'cPointer'}></MoreVertIcon>
                                    <ContextMenu menuList={this.state.menuList} isOpen={this.state.isOpenContextMenu} handleItemSelection={(val) => this.handleItemSelection(val)} handleMenuClose={(val) => this.setIsOpenContextMenu(val)} menuRef={this.state.menuRef}></ContextMenu>
                                </div>
                            }
                        </div>
                        {combinedNotes && allNotesDetails && allNotesDetails.length && (combinedNotes.length == allNotesDetails.length) ? <Box className={classes.BookingNotesPanelDetails}>
                            {combinedNotes && allNotesDetails && allNotesDetails.length && (combinedNotes.length == allNotesDetails.length) ? allNotesDetails.map((note, index) => {
                                return (<div onClick={() => this.noteSelection(index)} key={"noteslist" + index} className={classes.BookingNotesNote + ' ' + (this.state.selectedIndex == index ? classes.selectedNote : "")}>
                                    <span>{note.length > 1 ? (note[0][NOTES_TEXT_ACCESSOR] + '...') : note[0][NOTES_TEXT_ACCESSOR]}</span>
                                </div>);
                            }) : (
                                    <div className={classes.NoNotesToShow}>{NO_NOTES_TO_SHOW_TEXT}</div>
                                )}
                        </Box> : ""}
                    </div>
                </AccordionComponent>
                {this.state.isOpenProperties && (!this.state.isUpdateType || (this.state.isUpdateType && allNotesDetails[this.state.selectedIndex])) && <NoteProperties
                    reloadNotes={(noteKey, isFutureDate) => { this.reloadNotes(noteKey, isFutureDate) }}
                    currentRecordData={this.props.currentRecordData}
                    notesCurrentPage={BOOKING_NOTES}
                    isUpdateType={this.state.isUpdateType}
                    noteKey={this.state.isUpdateType ? allNotesDetails[this.state.selectedIndex][0][NOTES_KEY_ACCESSOR] : false}
                    noteDetails={this.state.isUpdateType ? allNotesDetails[this.state.selectedIndex] : false}
                    currentPage={this.props.currentPage}
                    isOpen={this.state.isOpenProperties}
                    noteLabelJson={noteLabelJson}
                    clearPopupComponent={(val) => this.setNotePropertiesOpen(false)}>
                </NoteProperties>}
            </div>
        );
    }
}

BookingNotes.propTypes = propTypes;

function mapDispatchToProps(dispatch) {
    return {
        dispatch,
        getBookingNotes: (data) => {
            dispatch(getBookingNotes(data));
        },
        clearNotesData: () => {
            dispatch(clearNotesData());
        },
        getNoteDetails: (data) => {
            dispatch(getNoteDetails(data))
        },
        setSelectedNoteDetails: (data) => {
            dispatch(setSelectedNoteDetails(data))
        },
        controlNoteCreation: (data) => {
            dispatch(controlNoteCreation(data))
        },
        setControlNoteCount: (data) => {
            dispatch(setControlNoteCount(data))
        },
        removeNoteByKey: (data) => dispatch(removeNoteByKey(data)),
        clearAllBookingNotes: () => dispatch(clearAllBookingNotes()),
        setIsEmbeddedList: () => dispatch(setIsEmbeddedList()),
        clearStateValues: () => dispatch(clearStateValues())
    }
}

const mapStateToProps = function (state) {
    return {
        BookingNotesData: selectData(state),
        //RRUDRA_get company details from Global App selector
        companyDetails: makeSelectCompanyDetails(state)
        //RRUDRA_end
    }
}

const withReducer = injectReducer({ key: 'BookingNotes', reducer });
const withSaga = injectSaga({ key: 'BookingNotesSaga', saga });

const withConnect = connect(
    mapStateToProps,
    mapDispatchToProps
);

export default compose(
    withReducer,
    withConnect,
    withSaga,
    withStyles(style)
)(BookingNotes);
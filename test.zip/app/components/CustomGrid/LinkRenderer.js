import React from 'react';
import { connect } from 'react-redux';
import { compose } from 'redux';
import { injectIntl } from 'react-intl';

import Form from 'components/common/Form/Form';
import FieldInput from 'components/common/Form/FieldInput';
import {
    COLUMN_HEADER_ACCESSOR,
    COLUMN_VALUE_ACCESSOR
} from 'components/common/constants';
import ErrorMessageComponent from '../../components/common/ErrorMessageComponent';

class LinkRenderer extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            nameInput: false,
            inputValue: false,
            errorMessageLabel: null
        }
        this.onClickLink = this.onClickLink.bind(this);
    }

    onClickLink(value) {
        const { rowIndex, column, data } = this.props;
        if(this.props.agGridReact.props.onClickLink){
            this.props.agGridReact.props.onClickLink(data, rowIndex, column.colId.trim(), 'link');
        }
    }


    render() {
        let { rowIndex, column, colDef, value, agGridReact, gridCallBack } = this.props;
        let key = 'gridNumber' + rowIndex + column.colId;
        return (
            <div key={key} id={key} onClick={(value) => this.onClickLink(value)} className={'link-header'}>
                <div>{value}</div>
            </div>
        );
    }
}


export default LinkRenderer;
const { NEW_MENU_ITEMS } = require('components/common/constants');
export const valueDisplayCharacters = 15 //E3C-32619:Ajit
export const labelDisplayCharacters = 20 //E3C-32619:Ajit
export const HeaderAPIValuesJSON =
{
  'INAME': '', // VENDOR NAME
  'IVNDR': '', // VENDOR ID
  'WNAME': '', // WAREHOUSE NAME
  'IWHSE': '', // WAREHOUSE ID
  'IUPC#': '',
  'MFGID': '',
  'OPCDT': '',
  'LSODT': '',
  'SUPER': '',
}




export const BRACKET_LABEL_URL_DATA = [
  { "accessor": "TRIMBO", "operator": "=", "fieldValue": "TrimCommon", "prefixFlag": 0 },
  { "accessor": "LANGID", "operator": "=", "fieldValue": "ENG", "prefixFlag": 0 }
]

// PLEASE NOTE THAT THE KEYS USED FOR HEADER VALUES MAY NOT BE SAME FOR FUTURE WORK.
// PLEASE CHANGE THE KEY VALUES TO REQUIRED KEYS AS NECCESSARY.

export const KEY_VENDOR_ID = 'IVNDR';
export const KEY_ITEM_NAME = 'INAME';
export const KEY_WAREHOUSE_NAME = 'IWNAME';
export const KEY_WAREHOUSE_ID = 'IWHSE';
export const KEY_LAST_ORDER_DATE = 'ILSODT';
export const KEY_LAST_OS_DATE = 'IOPCDT';
export const KEY_UPC_CODE = 'IUPC#';
export const KEY_SUPER_ITEM_TYPE = 'ISUPER';
export const KEY_MFG_ID = 'IMFGID';
// export const KEY_AUX_DESC ="INAUXD";
// export const KEY_LAST_ORDER_DATE ="ILSODT";
export const KEY_LAST_ACCEPTED_OPA = 'VASLSU';
export const KEY_LAST_CALCULATED_OPA = 'VBIRDT';
export const KEY_CURRENT_ORDER_CYCLE = 'VORCYC';
export const KEY_SUB_VENDOR_ID = 'VSUBV';

export const LABEL_ITEM_LIST = '25160'; // ! needs to be included in Header_ENG.json
export const LABEL_VENDOR_ID = '34433'; // ! needs to be included in Header_ENG.json
export const LABEL_SUB_VENDOR_ID = '34435';
export const LABEL_VENDOR_NAME = '36593';
export const LABEL_ITEM_NAME = '33990';
export const LABEL_ITEM = '50875';
export const LABEL_WAREHOUSE_NAME = '36479'; // ! needs to be included in Header_ENG.json
export const LABEL_WAREHOUSE_ID = '33161'; // ! needs to be included in Header_ENG.json
export const LABEL_LAST_ORDER_DATE = '34454';
export const LABEL_LAST_OS_DATE = '33858';
export const LABEL_UPC_CODE = '33676';
export const LABEL_SUPER_ITEM_TYPE = '33682';
export const LABEL_MFG_ID = '33674';
export const LABEL_LAST_ACCEPTED_OPA = '34431'; // ! needs to be included in Header_ENG.json
export const LABEL_LAST_CALCULATED_OPA = '34432'; // ! needs to be included in Header_ENG.json
export const LABEL_CURRENT_ORDER_CYCLE = '40170'; // ! needs to be included in Header_ENG.json
export const LABEL_AUX_DESCRIPTION = '37238';
export const LABEL_ORDER_TYPE = '37147';
export const LABEL_CURRENCY_MODE = '51216';
export const LABEL_LOCAL = '51215';
export const LABEL_TRSFR_WHSE = '33882';

export const LABEL_ITEM_DETAIL = '51049'; //E3C-31202 previously '25174' (Item Detail) Now renamed to 'Ordering'
export const LABEL_ITEM_PARAMETERS = '25162';
export const LABEL_MOVEMENT_ACCUMULATION = '25168';
export const LABEL_STOCK_STATUS = '25163';
export const LABEL_FORECAST_HISTORY = '25739';
export const LABEL_VENDOR_ADDRESS = '25102';
export const LABEL_DEMAND_FORECASTING = '65546'; //E3C-31202 previously '25137' (Demand Forecasting) Now renamed to 'Forecasting'

export const LABEL_REFORECAST_NPERIOD = '50295';

export const LABEL_AWRASR_FORECAST = '28284';

export const LABEL_ACTIONS = '28310';
export const LABEL_SAVE = '28650';

export const KEY_NEW = 'New';
export const KEY_COPY = 'Copy';
export const KEY_POSITION_TO = 'PositionTo';
export const KEY_DELETE = 'Delete';
export const FREEZE = 'Freeze';
export const ACTUAL_DAYS = 'Actual days';
export const WORK_DAYS = 'Work days';

export const THAW = 'Thaw';
export const WAREHOUSE_TRANSFER = 'WarehouseTransfer';
export const UNDO_WAREHOUSE_TRANSFER = 'UndoWarehouseTransfer';
export const MULTISOURCE_ASSIGNMENT = 'MultiSourceAssignment';
export const MULTISOURCE_DISTRIBUTION = 'MultiSourceDistribution';
export const VENDOR_TRANSFER = 'vendorTransfer';
export const MULTISOURCE_REASSIGN = 'multiSourceReassign';
export const SUPER_TYPE = 'Super Type'

export const NO_DATA_TO_DISPLAY = '28648';

export const REFORECAST = "Reforecast";
export const REFORECAST_NPERIODS = "Reforecast for N Periods";
export const REFORECAST_MULT_ITEMS = "Reforecast Multiple Items";
export const ADD_NEW_SPECIAL_ACCOUNT_ID = 'Add New Special Account ID';
export const HISTORY_MULTIPLY = 'History Multiply';
export const MATCH_PROFILE = 'Match Profile';
export const DELETE_EXCEPTION = 'Delete Exception';
export const MANAGE_WHSE_DEMAND_HISTORY = 'manageWhseDemandHist';

export const SUPERSEDE_TO = "Supersede To";
export const SUPERSEDE_FROM = "Supersede From";
export const SUBSTITUTE_TO = "Substitute To";
export const SUBSTITUTE_FROM = "Substitute From";
export const CONSIST_OF = "Consists Of";
export const PART_OF = "Part Of"

export const AWRASR_FORECAST = 'AWR Forecast Allocation to ASR'

export const LABEL_PROJECTIONS = '28280';
export const CONTEXT_MENU_ITEM_HEADER = [
  {
    label: '25250',
    key: KEY_NEW,
    hasSubMenu: true,
    isDisable: false,
    subMenuList: NEW_MENU_ITEMS
  },
  {
    label: '2910',
    key: KEY_COPY,
    hasSubMenu: false,
  },
  {
    label: '28642',
    key: KEY_DELETE,
    hasSubMenu: false,
  },
];
export const SUPERTYPE_MENU = [
  {
    label: '51089',
    key: SUPERSEDE_TO,
    hasSubMenu: false,
    isDisable: false,
  },
  {
    label: '51090',
    key: SUPERSEDE_FROM,
    hasSubMenu: false,
    isDisable: false,
  },
  {
    label: '51091',
    key: SUBSTITUTE_TO,
    hasSubMenu: false,
    isDisable: false,
  },
  {
    label: '51092',
    key: SUBSTITUTE_FROM,
    hasSubMenu: false,
    isDisable: false,
  },
  {
    label: '51093',
    key: CONSIST_OF,
    hasSubMenu: false,
    isDisable: false,
  },
  {
    label: '51094',
    key: PART_OF,
    hasSubMenu: false,
    isDisable: false,
  },
];
export const ACTIONS_CONTEXT_MENU_ITEM_HEADER = [
  {
    label: '52864',
    key: ACTUAL_DAYS,
    hasSubMenu: false,
    isHide: false,
  },

  {
    label: '28283',
    key: AWRASR_FORECAST,
    hasSubMenu: false,
    isHide: false,
  },
  {
    label: '52865',
    key: WORK_DAYS,
    hasSubMenu: false,
    isHide: false,
  },
  {
    label: '50170',
    key: FREEZE,
    hasSubMenu: false,
  },
  {
    label: '50292',
    key: THAW,
    hasSubMenu: false,
  },
  {
    label: '50100',
    key: WAREHOUSE_TRANSFER,
    hasSubMenu: false,
  },
  {
    label: '27572',
    key: UNDO_WAREHOUSE_TRANSFER,
    hasSubMenu: false,
  },
  {
    label: '52840',
    key: MULTISOURCE_DISTRIBUTION,
    hasSubMenu: false,
  },
  {
    label: '52842',
    key: MULTISOURCE_ASSIGNMENT,
    hasSubMenu: false,
  },
  {
    label: '25351',
    key: VENDOR_TRANSFER,
    hasSubMenu: false,
  },
  {
    label: '52854',
    key: MULTISOURCE_REASSIGN,
    hasSubMenu: false,
  },
  {
    label: '50097',
    key: REFORECAST,
    hasSubMenu: false,
    isDisable: false,
  },
  {
    label: '50295',
    key: REFORECAST_NPERIODS,
    hasSubMenu: false,
    isDisable: false,
  },
  {
    label: '25685',
    key: REFORECAST_MULT_ITEMS,
    hasSubMenu: false,
    isDisable: false,
  },
  {
    label: '25642',
    key: SUPER_TYPE,
    hasSubMenu: true,
    isDisable: false,
    subMenuList: SUPERTYPE_MENU
  },
  {
    label: '52729',
    key: ADD_NEW_SPECIAL_ACCOUNT_ID,
    hasSubMenu: false,
    isDisable: false,
  },
  {
    label: '28114',
    key: HISTORY_MULTIPLY,
    hasSubMenu: false,
    isDisable: false,
  },
  {
    label: '50096',
    key: MATCH_PROFILE,
    hasSubMenu: false,
    isDisable: false,
  },
  {
    label: '28268',
    key: MANAGE_WHSE_DEMAND_HISTORY,
  },
];

export const DAYS_CONTEXT_MENU = [
  {
    label: '52864',
    key: ACTUAL_DAYS,
    hasSubMenu: false,
    isHide: false,
  },
  {
    label: '52865',
    key: WORK_DAYS,
    hasSubMenu: false,
    isHide: false,
  },
];

export const DEFAULT_VALUE_URL_DATA = [
  { accessor: 'COMP', operator: '=', fieldValue: '', prefixFlag: 0 },
  { accessor: 'WHSE', operator: '=', fieldValue: '', prefixFlag: 0 },
  { accessor: 'VNDR', operator: '=', fieldValue: '', prefixFlag: 0 },
  { accessor: 'SUBV', operator: '=', fieldValue: '', prefixFlag: 0 },
  { accessor: 'SUPV', operator: '=', fieldValue: '', prefixFlag: 0 },
  { accessor: 'ITEM', operator: '=', fieldValue: '', prefixFlag: 0 },
  { accessor: 'PERDF', operator: '=', fieldValue: '', prefixFlag: 0 }
];

export const DEFAULT_AWRASR_FILTER_PROPS = [
  { "accessor": "COMP", 'prefixFlag': 0, "key": "COMP", "operator": "=", "fieldValue": "", "jOpr": 'and' },
  { "accessor": "WHSE", 'prefixFlag': 0, "key": "WHSE", "operator": "=", "fieldValue": "", "jOpr": 'and' },
  { "accessor": "ITEM", 'prefixFlag': 0, "key": "ITEM", "operator": "=", "fieldValue": "", "jOpr": 'and' },
]

export const LABEL_LIST_URL_DATA = [
  {
    accessor: 'TRIMBO',
    operator: '=',
    fieldValue: 'TrimItemUI',
    prefixFlag: 0,
  },
  { accessor: 'LANGID', operator: '=', fieldValue: 'ENG', prefixFlag: 0 },
];
export const LABEL_ITEM_PRICES_DATA = [
  { accessor: 'TRIMBO', operator: '=', fieldValue: 'SIMItemUI', prefixFlag: 0 },
  { accessor: 'LANGID', operator: '=', fieldValue: 'ENG', prefixFlag: 0 },
];

export const ITEM_PROPERTIES = 'itemProperties';

//Add Keys here which are set incase of API Failure in reducer//~~~~JVK
export const FAILURE_MESSAGES = {
  'itemDetailAPIFailure': 'Failed To Fetch Item Detail Data',
  'itemMiscDetailAPIFailure': 'Failed To Fetch Item Misc. Detail Data',
  'previousNextAPIFailure': 'Failed To Fetch Data',
  'labelsDataAPIFailure': 'Failed To Fetch Labels Data',
  'itemUpdateAPIFailure': 'Failed To Update Item Data',
  'salesDataAPIFailure': 'Failed To Fetch Sales Graph Data',
  'depletionDataAPIFailure': 'Failed To Fetch Depletion Graph Data',
  'loadUserDefinedLabelsAPIFailure': 'Failed To Fetch User Defined Labels',
  'loadUserDefinedDataAPIFailure': 'Failed To Fetch User Defined Data',
  'itemDeleteAPIFailure': 'Failed To Delete Item(s)',
  'itemCopyAPIFailure': 'Failed To Copy Item(s)',
  'previousNextFlagAPIFailure': 'Failed To Activate Previous Next Arrows',
  'itemSimulationAPIFailure': 'Failed To Simulate Item',
}

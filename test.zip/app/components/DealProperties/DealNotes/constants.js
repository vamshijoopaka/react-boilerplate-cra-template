export const LABEL_NOTE = '25297';
export const DEAL_NOTES = 'dealnotes';
export const DEAL_NOTES_FILTER_PROPS = [
    {"accessor":"FLID","operator":"=","jOpr":"and","key":"FLID","fieldValue":""},
    {"accessor":"FKEY","operator":"=","jOpr":"and","key":"FKEY","fieldValue":""}
]

export const FILTER_DATA = ["COMP","VNDR", "WHSE", "DEAL"];

export const GET_DEAL_NOTES = 'GET_DEAL_NOTES';
export const GET_DEAL_NOTES_SUCCESS = 'GET_DEAL_NOTES_SUCCESS';
export const GET_DEAL_NOTES_FAILURE = 'GET_DEAL_NOTES_FAILURE';
export const CLEAR_NOTES_DATA = 'CLEAR_NOTES_DATA';
export const GET_DEAL_NOTE_DETAILS = 'GET_DEAL_NOTE_DETAILS';
export const GET_DEAL_NOTE_DETAILS_SUCCESS = 'GET_DEAL_NOTE_DETAILS_SUCCESS';
export const GET_DEAL_NOTE_DETAILS_FAILURE = 'GET_DEAL_NOTE_DETAILS_FAILURE';
export const GET_DEAL_NOTES_ALL_SUCCESS = 'GET_DEAL_NOTES_ALL_SUCCESS';
export const SET_DEAL_SELECTED_NOTE_DETAILS = 'SET_DEAL_SELECTED_NOTE_DETAILS';
export const CONTROL_DEAL_NOTE_CREATION = 'CONTROL_DEAL_NOTE_CREATION';
export const CONTROL_DEAL_NOTE_CREATION_SUCCESS = 'CONTROL_DEAL_NOTE_CREATION_SUCCESS';
export const CONTROL_DEAL_NOTE_CREATION_FAILURE = 'CONTROL_DEAL_NOTE_CREATION_FAILURE';
export const SET_DEAL_NOTE_CONTROL_COUNT = 'SET_DEAL_NOTE_CONTROL_COUNT';
export const REMOVE_DEAL_NOTE_OF_KEY = 'REMOVE_DEAL_NOTE_OF_KEY';
export const CLEAR_DEAL_NOTES = 'CLEAR_DEAL_NOTES';
export const SET_IS_EMBEDDED_LIST = 'SET_IS_EMBEDDED_LIST';
export const CLEAR_STATE_VALUES = "CLEAR_STATE_VALUES";

export const NOTES_TEXT_ACCESSOR = 'MFTEXT';
export const NOTES_KEY_ACCESSOR = 'MFKEY';
export const NO_NOTES_TO_SHOW_TEXT = 'No Notes To Show'


export const MENU_DEALS = [
    {
        label: '51170',
        key: 'Remove All',
        hasSubMenu: false
    },
    {
        label: '25651',
        key: 'note',
        hasSubMenu: false
    }
]


/** Change Log
 * LogStart --  Story: E3C-33253 --Selecting an existing Filter with ‘*Blank’, the ‘*Blank’ is not populated and needs to be reentered before executing the Filter
 *              
*/
import React, { Component } from 'react'
import { capitalizeFirstLetter, getFilterDataFromLocalStorage, getUpdateRestrictionOnComponent } from '../../utils/util';
import { COLUMN_VALUE_ACCESSOR, GLOBAL_FILTER_OPTIONS, INITIAL_PAGE_PROPS, TEXT_ALERT, TEXT_CANCEL, TEXT_OK, FILTERCRITERIA_LIST_PAGE, FILTERCRITERIA_PROPERTIES_PAGE } from '../common/constants';
import Header from './header'
import { getDBSelectorFilterValues, prepareTooltipValues } from 'utils/filterData';
import { updateBreadCrumbContextMenu } from 'utils/contextMenu';
import { isEqual } from 'lodash';
import Spinner from '../common/Spinner';
import {
    LABEL_HEADER_URL_DATA, LABEL_HEADER_URL_DATA_ITEM, LABEL_HEADER_URL_DATA_VENDOR,
    LABEL_HEADER_URL_DATA_ORDER, LABEL_HEADER_URL_DATA_AE
} from '../../containers/FilterCriteriaPropertiesPage/constants';
import { Box, withStyles } from '@material-ui/core';
import {
    onChangeContextMenu,
} from 'utils/contextMenu';

import { COLUMNDEFS } from './constants';

import TableGrid from '../TableGrid';
import ConfirmationDialog from 'components/common/ConfirmationDialog';

const style = theme => ({
    pageContainer: {
        display: 'flex',
        backgroundColor: 'var(--background-app)',
        borderTop: 'none',
        padding: '24px 24px 0px 24px',
    },
    table: {
        marginLeft: theme.spacing(100),
        width: '100%',
    },
})

class FilterCriteriaProperties extends Component {
    constructor(props) {
        super(props);
        this.state = {
            locationData: {},
            isSaveEnabled: false,
            valueDataFailureMessages: [],
            showConfirmationDialog: false,
            hasWarning: false,
            fromHeaderENG: false,
            openFilterPopup: false,
            doApprove: false,
            isOpenCopy: false,
            filtercriteriaList: [],
            previousFilterValues: [],
        }
        this.onContextMenuChange = this.onContextMenuChange.bind(this);

    }
    onContextMenuChange = (e, value, check = false, filters = false, title = false) => {
        let defaultFilters = filters;
        defaultFilters = this.state.previousFilterValues;
        let toPage = value;
        let displayName = title;
        onChangeContextMenu(this.props, e, toPage, defaultFilters, displayName);
        this.props.setSelectedValueForTabs('Show Me');
    }
    componentDidMount() {
        const { filterCriteriaRecord, filterCriteriaDetails } = this.props.FilterCriteriaData;
        this.setCurrentTabRecord()
        this.props.setCurrentPage(FILTERCRITERIA_PROPERTIES_PAGE)
        this.props.setIsShowContextMenu(true)
        let canUpdateComponent = getUpdateRestrictionOnComponent(capitalizeFirstLetter(FILTERCRITERIA_LIST_PAGE), this.props.authorizedComponentsList);
        this.setState({ canUpdateComponent });
        this.props.getHeaderLabels({ recordData: LABEL_HEADER_URL_DATA, currentPage: FILTERCRITERIA_PROPERTIES_PAGE })
        if (filterCriteriaRecord && Object.keys(filterCriteriaRecord) && Object.keys(filterCriteriaRecord).length) {
            this.props.setSelectedRecord(filterCriteriaRecord, 'filtercriteria');
        }
    }

    setCurrentTabRecord = () => {
        let isFound = this.setRecordDataValues();
        if (!isFound) {
            if (this.props.location?.state) {
                this.setState({ locationData: JSON.parse(JSON.stringify(this.props.location.state)) });
                this.props.setSelectedRecord(JSON.parse(JSON.stringify(this.props.location.state)), FILTERCRITERIA_LIST_PAGE)
            }
            this.getPrevNextApiFlags(this.props.location.state?.data)
            this.setState({ hasData: true });
            this.columnDefs = this.props.location.state.columnDefs
            this.rowIndex = this.props.location.state.rowIndex;
            this.totalCount = this.props.location.state.totalCount;
        }
    }

    setRecordDataValues = () => {
        const { history } = this.props;
        this.setState({ hasData: false });
        let isRecordValuesExists = false, isLocalStorageValuesExists = false,
            isFilterValuesExists = false, dbSelectorValues = [];
        var paramsString = window.location.search;
        if (paramsString && paramsString.length) {
            let paramsArray = paramsString.split("?");
            if (paramsArray && paramsArray.length && paramsArray.length > 1) {
                let params = paramsArray[1].split("&");
                let tabId = params[0].split("=")[1];
                let breadCrumbId = params[1].split("=")[1];
                let localStorageValues = getFilterDataFromLocalStorage(tabId, breadCrumbId);
                if (localStorageValues && Object.keys(localStorageValues) && Object.keys(localStorageValues).length) {
                    isLocalStorageValuesExists = true;
                    let itemData = localStorageValues.item_data;
                    if (itemData && itemData.recordData && localStorageValues.childType) {
                        isRecordValuesExists = true;
                        this.columnDefs = JSON.parse(JSON.stringify(itemData.recordData.columnDefs));
                        this.setState({ locationData: JSON.parse(JSON.stringify(itemData.recordData)) });
                        this.getPrevNextApiFlags(itemData.recordData?.data)
                        setTimeout(() => {
                            this.setState({ hasData: true });
                        }, 1000);
                        this.props.setSelectedRecord(itemData.recordData?.data, 'filtercriteria');
                        this.props.getFilterCriteriaDetail(itemData.recordData?.data['FVREFN']);
                        this.props.getFilterCriteriaDetailFilter(itemData.recordData?.data['FVREFN']);
                        this.props.setSelectedRecordObj(itemData.recordData.data);
                        this.rowIndex = itemData.recordData.rowIndex;
                        this.totalCount = itemData.recordData.totalCount;
                    }
                    if (itemData && itemData.dbSelector && itemData.dbSelector.length) {
                        dbSelectorValues = JSON.parse(JSON.stringify(itemData.dbSelector));
                    }
                    if (itemData && itemData.filterProps && itemData.filterProps.length) {
                        isFilterValuesExists = true;
                        let values = getDBSelectorFilterValues(dbSelectorValues, itemData.filterProps);
                        this.setFilterValuesFromState(values);
                    } else if (dbSelectorValues && dbSelectorValues.length) {
                        isFilterValuesExists = true;
                        let dbValues = getDBSelectorFilterValues(dbSelectorValues, []);
                        this.setFilterValuesFromState(dbValues);
                    }

                }
                if (!isLocalStorageValuesExists && tabId && breadCrumbId) {
                    history.push({ pathname: '/Dashboard' });
                }
            }
        }

        let filterOptions = GLOBAL_FILTER_OPTIONS;
        const { dbSelector } = this.props;
        if (!isFilterValuesExists) {
            let gbValues = getDBSelectorFilterValues(dbSelector, filterOptions);
            this.setState({ currentFilterProps: JSON.parse(JSON.stringify(gbValues)) });
            this.setFilterValuesFromState(gbValues);
        }

        return isRecordValuesExists;
    }

    setFilterValuesFromState = (values) => {
        let filterValues = [];
        const { columnDefs } = this;
        if (columnDefs && columnDefs.length) {
            values.forEach((value) => {
                let isExists = columnDefs.find((column) => column[COLUMN_VALUE_ACCESSOR].trim() == value.accessor);
                if (isExists) {
                    filterValues.push(value)
                }
            });
            if (filterValues && filterValues.length) {
                this.props.onSetFilterProps(filterValues);
                this.props.setGlobalFilterProps(filterValues);
                this.setState({ previousFilterValues: filterValues })
                return filterValues;
            } else {
                this.props.onSetFilterProps([]);
                this.props.setGlobalFilterProps([]);
                this.setState({ previousFilterValues: [] })
                return [];
            }
        } else {
            const filters = values ? values : []
            this.props.onSetFilterProps(filters);
            this.props.setGlobalFilterProps(filters);
            this.setState({ previousFilterValues: filters })
            return filters;
        }
    }

    makeAPICallForPageUpDown = (type, data) => {
        const { filterProps } = this.props.FilterCriteriaData;
        const pageProps = JSON.parse(JSON.stringify(INITIAL_PAGE_PROPS));
        if (type == 'up') {
            pageProps.isForwardDirection = false;
        } else {
            pageProps.isForwardDirection = true;
        }
        const filterData = JSON.parse(JSON.stringify(filterProps));
        this.props.getpageUpDownRecord({
            filterProps: filterData,
            pageProps,
            direction: pageProps.isForwardDirection,
            record: data ? data : false,
            currentPage: FILTERCRITERIA_LIST_PAGE,
            parentPage: FILTERCRITERIA_LIST_PAGE
        })
    }


    handleHeaderUpArrowClick = (data) => {
        this.makeAPICallForPageUpDown('up', data);
        this.setState({ isSaveEnabled: false });
    }
    handleHeaderDownArrowClick = (data) => {
        this.makeAPICallForPageUpDown('down', data);
        this.setState({ isSaveEnabled: false });
    }


    getPrevNextApiFlags = (record) => {
        const { filterProps } = this.props.FilterCriteriaData;
        const data = JSON.parse(JSON.stringify(INITIAL_PAGE_PROPS));
        data.isForwardDirection = true;
        data.pageSize = 1;
        if (record.TDFEXP && record.TDFEXP.substr(1, record.TDFEXP.length - 2))
            record.TFIELD = record.TDFEXP.substr(1, record.TDFEXP.length - 2)
        this.props.getPageUpDownFlagAPI({
            filterProps,
            pageProps: data,
            direction: data.isForwardDirection,
            record: { record: record, flagsOnly: true },
            currentPage: FILTERCRITERIA_LIST_PAGE,
            parentPage: FILTERCRITERIA_LIST_PAGE
        },
        );
    }

    resetValues() {
        this.props.setInitialState();
        this.setState({
            locationData: {},
            isSaveEnabled: false,
            callOnFilterChange: false
        })
    }

    forceUpdateHandler() {
        this.forceUpdate();
    }

    prepareTooltipData = () => {
        const { filterCriteriaRecord } = this.props.FilterCriteriaData;
        const tooltipData = prepareTooltipValues(
            FILTERCRITERIA_LIST_PAGE,
            filterCriteriaRecord,
            this.columnDefs,
            'filtercriteriaproperties',
        );
        this.props.setDataInTabs(
            'toolTipData',
            JSON.parse(JSON.stringify(tooltipData)),
        );
    };

    componentDidUpdate(prevProps, prevState) {
        const { saveSuccess, filterCriteriaRecord, pageUpDownData, prevNextApiFailed, filterProps, prevNextApiSuccess,
            deleteSuccess, filterCriteriaDetails,
            filterCriteriaDetailsFilter } = this.props.FilterCriteriaData
        if (this.props.location.search != prevProps.location.search) {
            this.resetValues();
            this.forceUpdateHandler();
            this.setCurrentTabRecord();
        }

        if (prevProps.authorizedComponentsList !== this.props.authorizedComponentsList) {
            const canUpdateComponent = getUpdateRestrictionOnComponent(
                capitalizeFirstLetter(FILTERCRITERIA_LIST_PAGE),
                this.props.authorizedComponentsList,
            );
            this.setState({ canUpdateComponent });
        }

        if (saveSuccess && (prevProps.FilterCriteriaData?.saveSuccess !== saveSuccess)) {
            this.setState({ isSaveEnabled: false })
        }
        if (filterCriteriaRecord && !isEqual(filterCriteriaRecord, prevProps.FilterCriteriaData?.filterCriteriaRecord) && Object.keys(filterCriteriaRecord).length) {
            if (this.columnDefs && this.columnDefs.length) {
                this.prepareTooltipData();
                const modifiedData = {
                    data: JSON.parse(JSON.stringify(filterCriteriaRecord)),
                    fromPage: FILTERCRITERIA_LIST_PAGE,
                    rowIndex: this.props.FilterCriteriaData.rowIndex,
                    totalCount: this.totalCount,
                    fromParent: false,
                    columnDefs: this.columnDefs,
                };
                this.props.setDataInTabs('recordData', modifiedData);
            }
            this.props.setSelectedRecord(filterCriteriaRecord, FILTERCRITERIA_LIST_PAGE);
            this.setState({ locationData: { ...this.state.locationData, data: filterCriteriaRecord } });
        }

        if (pageUpDownData && !isEqual(pageUpDownData, prevProps.FilterCriteriaData.pageUpDownData) && Object.keys(pageUpDownData).length) {
            this.props.setSelectedRecord(pageUpDownData, FILTERCRITERIA_LIST_PAGE)
            const modifiedData = {
                data: JSON.parse(JSON.stringify(pageUpDownData)),
                fromPage: FILTERCRITERIA_LIST_PAGE,
                rowIndex: this.props.FilterCriteriaData.rowIndex,
                totalCount: this.totalCount,
                fromParent: false,
                columnDefs: this.columnDefs,
            };
            this.props.setDataInTabs('recordData', modifiedData);
            this.setState({ locationData: { ...this.state.locationData, data: pageUpDownData } });

        }

        if (prevNextApiFailed && (prevProps.FilterCriteriaData?.prevNextApiFailed !== prevNextApiFailed)) {
            let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
            if (!this.state.isFiltersChanged) {
                values.push('Failed to update the previous & next flags data from the server')
            }
            this.setState({ valueDataFailureMessages: values, showConfirmationDialog: true, hasWarning: true, fromHeaderENG: true });
        }

        if (this.state.locationData?.data?.FVREFN && (this.state.locationData?.data?.FVREFN !== prevState.locationData?.data?.FVREFN)) {
            this.getPrevNextApiFlags(this.state.locationData?.data)
        }

        if (saveSuccess && (saveSuccess !== prevProps.FilterCriteriaData.saveSuccess)) {
            this.setState({ isSaveEnabled: false })
        }

        if (!isEqual(filterProps, prevProps.FilterCriteriaData.filterProps) && filterProps && Array.isArray(filterProps) && this.state.callOnFilterChange) {
            this.setState({ isFiltersChanged: true });
            this.makeAPICallForPageUpDown('down', {});
        }

        if (this.state.isFiltersChanged && filterCriteriaRecord && prevNextApiSuccess && (prevNextApiSuccess !== prevProps.FilterCriteriaData.prevNextApiSuccess)) {
            this.setState({ openFilterPopup: false });
            this.setState({ isFiltersChanged: false });
            this.props.setGlobalFilterProps(filterProps);
            this.props.setChildTabFilterProps(filterProps)
            this.setState({ previousFilterValues: filterProps, isSaveEnabled: false })
            // If current and filtered record is same
            if (this.state.locationData?.data?.FVREFN === filterCriteriaRecord?.FVREFN) {
                this.getPrevNextApiFlags(this.state.locationData?.data)
            }
        }
        if (this.state.valueDataFailureMessages && this.state.valueDataFailureMessages.length
            && !isEqual(this.state.valueDataFailureMessages, prevState.valueDataFailureMessages)) {
            this.setState({ dialogTitle: TEXT_ALERT });
            this.setState({ dialogBody: this.state.valueDataFailureMessages[0] });
            this.setState({ isComponentMsg: true })
        }
        if (deleteSuccess && (prevProps.FilterCriteriaData.deleteSuccess !== deleteSuccess)) {
            if (this.props.FilterCriteriaData.hasNext) {
                this.handleHeaderDownArrowClick(this.state.locationData.data)
            } else {
                this.props.updateStateValue({ key: 'loading', value: false })
                this.setState({
                    dialogBody: 'E14029', showConfirmationDialog: true, dialogTitle: TEXT_ALERT,
                    fromHeaderENG: false
                })
            }
        }
        if (filterCriteriaRecord && !isEqual(filterCriteriaRecord, prevProps.FilterCriteriaData.filterCriteriaRecord)) {
            if (Object.keys(filterCriteriaRecord) && Object.keys(filterCriteriaRecord).length) {
                this.props.setSelectedRecord(filterCriteriaRecord, 'filtercriteria');
                this.props.getFilterCriteriaDetail(filterCriteriaRecord['FVREFN']);
                this.props.getFilterCriteriaDetailFilter(filterCriteriaRecord['FVREFN']);
                this.setState({ filtercriteriaList: [] });
            }
        }
        let array = [];
        if (filterCriteriaDetails && !isEqual(filterCriteriaDetails, prevProps.FilterCriteriaData.filterCriteriaDetails)) {
            array = filterCriteriaDetails['FVDEFN'].split("AND");
            for (let i in array) {
                if (i > 0) {
                    let operator = '';
                    switch (array[i].substr(10, 2)) {
                        case 'EQ':
                            operator = this.props.messages['H2869']['TLLAB'].trim();
                            break;
                        case 'NE':
                            operator = this.props.messages['H2870']['TLLAB'].trim();
                            break;
                        case 'GE':
                            operator = this.props.messages['H2873']['TLLAB'].trim();
                            break;
                        case 'GT':
                            operator = this.props.messages['H2871']['TLLAB'].trim();
                            break;
                        case 'LE':
                            operator = this.props.messages['H2874']['TLLAB'].trim();
                            break;
                        case 'LT':
                            operator = this.props.messages['H2872']['TLLAB'].trim();
                            break;
                    }
                    //Fix for E3C-32990
                    let finalfieldId='33303'
                    if(array[i].trim().length>6)
                    {
                        let fieldid=parseInt(array[i].trim().substr(0, 6))? parseInt(array[i].trim().substr(0, 6)):3303
                        finalfieldId=30000+fieldid
                    }
                    //End
                    this.setState(prevState => ({
                        filtercriteriaList: [...prevState.filtercriteriaList, {
                            FIELD: this.props.messages['H' + finalfieldId.toString()]['TLLAB'].trim(),//this.props.messages['H3' + array[i].substr(3, 4)]['TLLAB'].trim(),//
                            OPERATOR: operator,
                            VALUE: array[i].substr(12).trim() == "" ? "*BLANK" : array[i].substr(12).trim(), //E3C-33253, 10/13/21, Kumar
                        }]
                    }))
                }
            }

        }

        let filterInitalValue = [];
        if (filterCriteriaDetailsFilter && !isEqual(filterCriteriaDetailsFilter, prevProps.FilterCriteriaData.filterCriteriaDetailsFilter)) {
            for (let k in filterCriteriaDetailsFilter['FVDEFN']) {
                filterInitalValue.push({ accessor: filterCriteriaDetailsFilter['FVDEFN'][k]['key'].substr(1), fieldValue: filterCriteriaDetailsFilter['FVDEFN'][k]['val'], operator: filterCriteriaDetailsFilter['FVDEFN'][k]['opr'] })
            }
            this.setState({ previousFilterValues: filterInitalValue })
            this.props.onSetFilterProps(filterInitalValue);
            this.props.setGlobalFilterProps(filterInitalValue);
        }
    }

    componentWillUnmount() {
        this.resetValues()
    }

    handleFilterClose() {
        if (this.state.isFiltersChanged) {
            this.setState({ isFiltersChanged: false });
            this.props.setGlobalFilterProps(this.state.previousFilterValues);
            this.props.setChildTabFilterProps(this.state.previousFilterValues);
            this.props.onSetFilterProps(this.state.previousFilterValues)
            this.setState({ callOnFilterChange: false })
        }
        this.setState({ openFilterPopup: false })
    }

    closeCurrentTab = () => {
        this.props.setNoDataCallBackValue(true);
        const paramsString = window.location.search;
        if (paramsString && paramsString.length) {
            const paramsArray = paramsString.split('?');
            if (paramsArray && paramsArray.length && paramsArray.length > 1) {
                const params = paramsArray[1].split('&');
                const tabId = params[0].split('=')[1];
                const breadCrumbId = params[1].split('=')[1];
                this.props.removeCurrentRecordObj(tabId, breadCrumbId);
            }
        }
    };

    handleDialogClose = (value) => {
        if (this.state.isComponentMsg) {
            if (this.state.valueDataFailureMessages && this.state.valueDataFailureMessages.length) {
                let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
                values.shift();
                this.setState({ valueDataFailureMessages: values });
            }
            this.setState({ isComponentMsg: false })
        } else if (value) {
            switch (this.state.dialogBody) {
                case 'E14029':
                    //need to close the current Tab
                    this.closeCurrentTab();
                    break;
                case '52956': this.deleteFilterCriteria()
            }
        }
        this.setState({ showConfirmationDialog: false, isComponentMsg: false, dialogBody: false });
    }


    handleActionItemSelection(key) {
        switch (key) {
            default: return ''
        }
    }

    deleteFilterCriteria = () => {
        this.setState({ isConfirmation: false, dialogBody: false, fromHeaderENG: false })
        const { TLVL, FVREFN } = this.state.locationData?.data
        this.props.deleteFilterCriteria({
            filterProps: [],
            record: {
                data: {
                    "RHTBID": FVREFN,
                    "RHSBMB": "0",
                    "RHLVL": TLVL
                },
                currentRecord: { ...this.state.locationData?.data, "TSTAT": "" }
            },
            pageProps: INITIAL_PAGE_PROPS,
            direction: INITIAL_PAGE_PROPS.isForwardDirection,
            currentPage: FILTERCRITERIA_LIST_PAGE
        })
    }

    updateFilterCriteriaRecordData = (data) => {
        this.props.updateStateValue({ key: 'filterCriteriaRecord', value: data })
    }

    handleSendData(selectedDataFrom) {
        console.log(selectedDataFrom);
    }

    handleSendSelectedRow(rowNumberSelect) {
        console.log(rowNumberSelect);
    }
    handleItemSelection = val => {
        const type = val ? val.toLowerCase() : '';
        switch (type) {
            case 'delete':
                this.setState({ showConfirmationDialog: true });
                break;
        }
        //~~~CreateNewFramework--JVK
        if (val.startsWith('new')) {
            if (val === 'newnote') {
                this.setState({ isOpenNote: true });
                return;
            }
        }
        //~~~CreateNewFramework--JVK
    };
    getErrorMessage = (id, replaceValues = false) => {
        const { errorMessageLabels } = this.props;
        if (errorMessageLabels && errorMessageLabels['E' + id]) {
            let errorText = errorMessageLabels['E' + id].MTEXT;
            if (replaceValues && replaceValues.length && errorText.indexOf('%') != -1) {
                replaceValues.forEach((item, index) => {
                    index += 1;
                    errorText = errorText.replace(`%${index}`, item);
                });
            }
            return errorText;
        }
        else return '';
    }
    handleClose = bodyId => {
        if (bodyId){
            this.props.saveHeaderDetails({ ...this.state.locationData.data, FVSTAT: 'D' })
        }
        this.setState({ showConfirmationDialog: false });
    }
    render() {
        const { isShowContextMenu, classes, selectedRecordObj } = this.props
        const { hasNext, hasPrevious, loading, filterCriteriaDetails } = this.props.FilterCriteriaData


        let contextMenu = updateBreadCrumbContextMenu(this.props) || [];
        let identification = '';
        let contextMenuNew = [];
        if (contextMenu.length > 0 && selectedRecordObj) {
            switch (selectedRecordObj['FVTYPE']) {
                case 'IT':
                    identification = 'items';
                    break;
                case 'VN':
                    identification = 'vendors';
                    break;
                case 'OR':
                    identification = 'orders';
                    break;
                case 'EX':
                    identification = 'expfields';
                    break;
                case 'AX':
                    identification = 'archived exceptions';
                    break;
            }
            for (let count in contextMenu) {
                if (contextMenu[count]['id'] == identification) {
                    contextMenuNew.push(contextMenu[count]);
                    break;
                }
            }
        }
        return (<>
            {loading ? <Spinner loading type="list" /> : null}
            <>
                <Header headerDetails={this.state.locationData} isShowContextMenu={isShowContextMenu}
                    isSaveEnabled={this.state.isSaveEnabled} contextMenu={contextMenuNew}
                    handleActionSelection={(key) => this.handleActionItemSelection(key, this)}
                    enableAddButton={(val) => this.setState({ isSaveEnabled: val })}
                    handleHeaderDownArrowClick={() => this.handleHeaderDownArrowClick(this.state.locationData.data)}
                    handleHeaderUpArrowClick={() => this.handleHeaderUpArrowClick(this.state.locationData.data)}
                    hasNext={hasNext}
                    onContextMenuChange={this.onContextMenuChange}
                    hasPrevious={hasPrevious}
                    handleHeaderSaveClick={this.props.saveHeaderDetails}
                    filterCriteriaDetails={filterCriteriaDetails}
                    handleHeaderFilterClick={() => {
                        this.setState({ openFilterPopup: true });
                        this.setState({ callOnFilterChange: true })
                    }}
                    currentOwnerName={this.props.currentOwnerName}
                    selectedRecordObj={this.props.selectedRecordObj}
                    handleHeaderActionItemSelection={this.handleItemSelection}
                />

                <Box >
                    <div className={classes.propertiesContentWrapper}>
                        <div className={classes.pageContainer}>
                            {filterCriteriaDetails && <TableGrid
                                className={classes.table}
                                columnDefs={COLUMNDEFS}
                                rowSlectionCustom='single'
                                handleSendData={this.handleSendData}
                                handleSendSelectedRow={this.handleSendSelectedRow}
                                rowData={this.state.filtercriteriaList}
                                disableColumns={false}
                                style={{ height: '300px', width: '1300px' }} />}

                        </div>
                    </div>
                </Box>
                {this.state.showConfirmationDialog && <ConfirmationDialog
                    hasWarning={true}
                    isOpen={this.state.showConfirmationDialog}
                    dialogTitle={this.state.dialogTitle}
                    submitText={TEXT_OK}
                    handleClose={e => this.handleClose(false)}
                    handleCancel={e => this.handleClose(false)}
                    handleSubmit={e => this.handleClose(true)}
                >
                    <div>
                        {this.getErrorMessage("21658", [this.state.locationData?.data?.FVREFN])}
                        </div>
                </ConfirmationDialog>
                }
            </>
        </>)
    }
}

export default withStyles(style)(FilterCriteriaProperties)
import React from 'react';
import PropTypes from 'prop-types';
import HightchartsReact from 'highcharts-react-official';
// import Highcharts from 'highcharts/highstock';
import Highcharts from "highcharts";
import more from "highcharts/highcharts-more";
import draggable from "highcharts/modules/draggable-points";

if (typeof Highcharts === "object") {
    more(Highcharts);
    draggable(Highcharts);
}

import ContextMenu from 'components/common/ContextMenu';
import MoreVertIcon from '@material-ui/icons/MoreVert';
import Badge from '@material-ui/core/Badge';
class SeasonalityGraph extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      rollTo13: false,
      includePromo: false,
    };
    this.seriesVisible = {}
  }
  componentDidMount() {
    const { rolledTo13, promoIncluded } = this.props;
    this.setState({
      rollTo13: !!rolledTo13,
      includePromo: !!promoIncluded,
    })
  }
  onRollTo13 = () => {
    this.setState(prevState => {
      const rollTo13 = !prevState.rollTo13;
      return {
        rollTo13,
      };
    });
    this.updateGraph();
  };

  onIncludePromo = () => {
    this.setState(prevState => {
      const includePromo = !prevState.includePromo;
      return {
        includePromo,
      };
    });
    this.updateGraph();
  };

  updateGraph = () => {
    if (!this.state.rollTo13) {
      if (this.state.includePromo) {
        this.props.showWeeklyDataWithPromo();
      } else {
        this.props.showWeeklyData();
      }
    } else if (this.state.includePromo) {
      this.props.rollGraphTo13WithPromo();
    } else {
      this.props.rollGraphTo13();
    }
  };
  setIsOpenContextMenu = (evnt = false) => {
    this.setState({
      isSimProfileOpen: evnt ? true : false,
      menuRef: evnt.currentTarget ? evnt.currentTarget : evnt,
    });
  };
  setVisibleLegends = event => {
    const key = event.target?.userOptions?.key;
    if (['Roll to 13', 'Include Promo'].includes(key)) return;
    this.seriesVisible[key] = !event.target.visible;
  }
  getSeries = series => {
    const { rolledTo13, promoIncluded, getLabelFromId, simInProgress } = this.props;
    return series.map(ele => {
      ele = { ...ele };
      if (ele.key in this.seriesVisible) {
        ele.visible = this.seriesVisible[ele.key];
      }
      if (ele.key === 'Roll to 13') {
        ele.visible = !!rolledTo13
      }
      if (ele.key === 'Include Promo') {
        ele.visible = !!promoIncluded
      }
      ele.name = getLabelFromId(ele.displayId) || ele.name;
      if (ele.key === 'Composite') {
        if (simInProgress) {
          ele.dragDrop = {
            dragMinY: 0,
            draggableY: true,
            dragPrecisionY: 2,
          };
          ele.point = {
            events: {
              drop: this.setComposite.bind(this)
            }
          };
          ele.stickyTracking = false;
          ele.minPointLength = 5;
          ele.zIndex = 8;
        } else {
          ele.dragDrop = false;
        }
      }
      return ele;
    })
  }
  setComposite = e => {
    let key = e.target?.index;
    let value = e.newPoint?.y || 0;
    if (
      key
      && typeof value === 'number'
      && typeof this.props.handleCompositeChange === 'function'
    ) {
      value = value.toFixed(2);
      this.props.handleCompositeChange(key, value);
    }
  }
  render() {
    const { series, categories, hideLegends, show3Dots, simInProgress, getLabelFromId } = this.props;
    const { onRollTo13, onIncludePromo, setVisibleLegends } = this;
    const rollTo13S = series.find(s => s.key === 'Roll to 13');
    const includePromo = series.find(s => s.key === 'Include Promo');
    if (rollTo13S) {
      rollTo13S.visible = this.state.rollTo13;
    }
    if (includePromo) {
      includePromo.visible = this.state.includePromo;
    }
    const options = {
      title: {
        text: getLabelFromId('50753') || 'Seasonality Graph',
      },
      yAxis: {
        title: {
          text: '',
        },
        min: 0,
      },
      xAxis: {
        categories,
      },
      legend: {
        enabled: !hideLegends,
        layout: 'vertical',
        align: 'right',
        verticalAlign: 'middle',
      },
      plotOptions: {
        series: {
          label: {
            connectorAllowed: false,
          },
          marker: {
            radius: 2,
          }
        },
        line: {
          events: {
            legendItemClick(e) {
              if (simInProgress && ['Roll to 13', 'Include Promo'].includes(this.userOptions.key)) {
                e.preventDefault();
                return;
              }
              if (this.userOptions.key === 'Roll to 13') {
                onRollTo13();
              }
              if (this.userOptions.key === 'Include Promo') {
                onIncludePromo();
              }
              setVisibleLegends(e);
            },
          },
        },
        column: {
          events: {
            legendItemClick(e) {
              if (this.userOptions.key === 'Composite') {
                setVisibleLegends(e);
              }
            }
          },
        }
      },
      credits: {
        enabled: false,
      },
      series: this.getSeries(series),
      responsive: {
        rules: [
          {
            condition: {
              maxWidth: 500,
            },
            chartOptions: {
              legend: {
                layout: 'horizontal',
                align: 'center',
                verticalAlign: 'bottom',
              },
            },
          },
        ],
      },
    };
    return (
      <>
        <div
          onMouseEnter={(event) => this.setIsOpenContextMenu(event)}
          onMouseLeave={(event) => this.setIsOpenContextMenu(false)}
          style={{
            width: 10,
            height: 10,
            float: 'right',
            display: show3Dots ? 'block' : 'none',
          }}
        >
          <Badge color="secondary" variant="dot" invisible={!simInProgress}>
            <MoreVertIcon color="primary" className="cPointer"></MoreVertIcon>
          </Badge>
          <ContextMenu
            menuList={this.props.simProfileMenuList}
            isOpen={this.state.isSimProfileOpen}
            menuRef={this.state.menuRef}
            handleItemSelection={val =>
              this.props.handleSimProfileMenuClick(val)
            }
            handleMenuClose={val => this.setIsOpenContextMenu(val)}
          />
        </div>
        <HightchartsReact highcharts={Highcharts} options={options} />
      </>
    );
  }
}

SeasonalityGraph.propTypes = {
  series: PropTypes.array,
  categories: PropTypes.array,
  showWeeklyData: PropTypes.func,
  rollGraphTo13: PropTypes.func,
  showWeeklyDataWithPromo: PropTypes.func,
  rollGraphTo13WithPromo: PropTypes.func,
  show3Dots: PropTypes.bool,
};

export default SeasonalityGraph;

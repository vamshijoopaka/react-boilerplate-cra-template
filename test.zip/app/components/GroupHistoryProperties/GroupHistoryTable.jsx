import React, { } from 'react';
import { Table, TableBody, TableHead, TableRow, Box, makeStyles } from '@material-ui/core/';
import { CustomTableCell } from '../OrderProperties/OrderSummary';
import { FieldInput } from '../common/Form';
import { getFormattedNumber } from '../../utils/util';
const emptyCell = <span>&nbsp;</span>
const useStyles = makeStyles({
    tableRow: {
        '&:nth-of-type(even)': {
            backgroundColor: 'var(--list-alternate-row)',
            color: 'var(--text) !important'
        }
    },
    table: {
        width: 'inherit',
        marginRight: '0.5rem',
    },
    fixedTable: {
        width: '8rem',
    },
    tableHeight: {
        height: 'calc(100% - 2px)',//to compensate horizantal scrollbar
    },
    tableCellBorder: {
        border: '1px solid var(--list-divider-line)',
        minWidth: 100,
    },
})
const GroupHistoryTable = (props) => {
    const classes = useStyles();
    const [state, setState] = React.useState({})
    const dummy13Obj = () => Object.fromEntries(Array(13).fill(0).map((_, key) => [`PD${key + 1}`, Math.round(Math.random() * 50)]));
    let rowData = props.rowData;
    rowData = rowData?.length ? rowData.map(e => ({ ...e })) : [];
    rowData.push(Array(13).fill({}));
    const columnDefs = [
        {
            key: 'title',
            label: '',
            pinned: true,
        },
        ...(() => {
            return Array(13).fill(0).map((_, i) => ({
                key: `PD${i + 1}`,
                label: `${props.periodLabel} ${i + 1}`,
            }));
        })(),
    ]
    const handleChange = (key, value) => {
        let [weekKey, periodKey] = key.split('-');
        const extractNumber = str => +str.match(/(\d+)/)[0];
        let dataKey = extractNumber(weekKey) + (4 * (extractNumber(periodKey) - 1));
        dataKey = `${dataKey}`.padStart(2, "0");
        const prefix = "H521";
        props.handleInputChange({ key: prefix + dataKey, value });
    }
    return (
        <Box display="flex" marginX="0.5rem">
            {props.title ? <label style={{ padding: '0 13px' }}>{props.title}</label> : ''}
            <Table className={`${classes.fixedTable} ${props.simInProgress ? "" : classes.tableHeight}`}>
                <TableHead>
                    <TableRow className={classes.tableRow}>
                        {!!columnDefs?.length && columnDefs.map(ele => (ele.pinned &&
                            <CustomTableCell className={classes.tableCellBorder}>{ele.label || emptyCell}</CustomTableCell>
                        ))}
                    </TableRow>
                </TableHead>
                <TableBody>
                    {rowData?.length && rowData.map((row, i) => (
                        <TableRow
                            key={'RowFixed' + i}
                            className={classes.tableRow}
                        >
                            {columnDefs?.length && columnDefs.map((col, colIndex) => (col.pinned &&
                                <CustomTableCell className={classes.tableCellBorder}>
                                    {col.key === 'title' || !row.key ? row[col.key] || emptyCell : emptyCell}
                                </CustomTableCell>
                            ))}
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
            <Box /* width="130vh" */ flex={1} overflow="auto">
                <Table className={classes.table}>
                    <TableHead>
                        <TableRow className={classes.tableRow}>
                            {!!columnDefs?.length && columnDefs.map(ele => (!ele.pinned &&
                                <CustomTableCell className={classes.tableCellBorder}>{ele.label || emptyCell}</CustomTableCell>
                            ))}
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {rowData?.length && rowData.map((row, rowIndex) => (
                            <TableRow
                                key={'Row' + rowIndex}
                                className={classes.tableRow}
                            >
                                {columnDefs?.length && columnDefs.map((col, colIndex) => (!col.pinned &&
                                    <CustomTableCell className={classes.tableCellBorder}>
                                        {col.key === 'title' || !row.key ? row[col.key] || emptyCell :
                                            (props.simInProgress ?
                                                <FieldInput
                                                    field={{
                                                        type: 'number', key: row.key + "-" + col.key, Attr: ' '
                                                    }}
                                                    maxLength={9}
                                                    numberType={'integer'}
                                                    onChange={handleChange}
                                                    value={row[col.key]}
                                                    enableAddButton={() => { }}
                                                    disabled={row.key ? row.key.includes('P') : false}
                                                    errorMessageLabel={props.demandLabel}
                                                    errorMessageLabels={props.errorMessageLabels}
                                                    globalNumberFormat={props.globalNumberFormat}
                                                    globalNumberSeparator={props.globalNumberSeparator}
                                                    globalDecimalSeparator={props.globalDecimalSeparator}
                                                />
                                                : getFormattedNumber(row[col.key], props.globalNumberFormat, props.globalNumberSeparator, 0, props.globalDecimalSeparator)
                                            )
                                        }
                                    </CustomTableCell>
                                ))}
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </Box>
        </Box>
    );
}

export default GroupHistoryTable;

/*
* * //==========================================================================
*
* * // Copyright 2021-2021, Blue Yonder Group, Inc.
*
* * // All Rights Reserved
*
* * //
*
* * // THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF
*
* * // BLUE YONDER GROUP, INC.
*
* * //
*
* * //
*
* * // The copyright notice above does not evidence any actual
*
* * // or intended publication of such source code.
*
* * //
*
* * // ===========================================================================
*/
import React from 'react';
import PropTypes from 'prop-types';
import { selectMessages } from './selector';
import { connect } from 'react-redux';
import { compose } from 'redux';
import { injectIntl, intlShape, FormattedMessage } from 'react-intl';

const defaultProps = {
    id: null
};

const propTypes = {
    id: PropTypes.string.isRequired,
    from: PropTypes.array,
    to: PropTypes.array,
    toUpperCase: PropTypes.bool
};

class FormattedMessageComponent extends React.Component {
    constructor(props) {
        super(props);
    }

    getDispalyLabel = (label, id) => {
        const { toUpperCase, from, to, messages, strLen } = this.props;
        if (toUpperCase)
            label = label.toUpperCase();
        if (from && from.length && to && to.length) {
            to.forEach((item, index) => {
                item = 'H' + item;
                label = label.replace(from[index], messages[item]['TLLAB'].trim());
            })
        }
        if (strLen) {
            strLen(id, label.length, label)
        }
        return label;
    }

    render() {
        const { messages, id } = this.props;

        let key = 'H' + id, label = '';
        if (messages && messages[key] && messages[key]['TLLAB']) {
            label = messages ? this.getDispalyLabel(messages[key]['TLLAB'].trim(), id) : '';
        }
        return (
            <div>
                {messages ? <FormattedMessage id={id}
                    defaultMessage={label}
                    value={label} /> : ''}
            </div>
        )
    }
}

const mapStateToProps = function (state) {
    return {
        messages: selectMessages(state)
    }
}

const withConnect = connect(
    mapStateToProps,
    null,
);

FormattedMessageComponent.defaultProps = defaultProps;
FormattedMessageComponent.propTypes = propTypes;

export default compose(
    withConnect,
    injectIntl
)(FormattedMessageComponent);
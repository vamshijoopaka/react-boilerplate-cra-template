//CARD HEADERS
export const BUYER_PERSONAL_DATA = '25522';
export const BUYER_BUYER_TOTALS = '25524';
export const BUYER_EXCEPTION_TOTALS = '25523';

export const BUYER_CONTROL_FACTORS_DATA = 'buyerPropertiesDetails';

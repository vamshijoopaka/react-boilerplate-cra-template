import React from 'react';
import Form from 'components/common/Form/Form';
import FieldInput from 'components/common/Form/FieldInput';
import {
    COLUMN_HEADER_ACCESSOR,
    COLUMN_VALUE_ACCESSOR
} from '../common/constants';

class TextRenderer extends React.Component {

    constructor(props) {
        super(props)
        this.state = {
            inputValue: null,
            errorMessageLabel: null,
        }
        this.setOnChangeValue = this.setOnChangeValue.bind(this);
        this.onFocusOut = this.onFocusOut.bind(this);
    }

    setOnChangeValue(value) {
        const { rowIndex, column, data, colDef } = this.props;
        let columnName = !colDef.prefixFlag ? this.props.agGridReact.props.listPredecessor + colDef[COLUMN_VALUE_ACCESSOR].trim() : colDef[COLUMN_VALUE_ACCESSOR].trim();
        let newData = JSON.parse(JSON.stringify(data));
        this.setState({
            inputValue: value
        })
        newData[columnName] = value;
        this.props.agGridReact.props.onValueChanged(data, rowIndex, column.colId.trim(), 'text', newData, colDef, columnName, value);
    }

    componentDidMount() {
        let { props, onCellValueChanged, value, colDef } = this.props;
        this.setState({
            inputValue: value.toString(),
            errorMessageLabel: colDef[COLUMN_HEADER_ACCESSOR]
        })
    }

    onFocusOut() {
        const { rowIndex, column, data, colDef } = this.props;
        let columnName = !colDef.prefixFlag ? this.props.agGridReact.props.listPredecessor + colDef[COLUMN_VALUE_ACCESSOR].trim() : colDef[COLUMN_VALUE_ACCESSOR].trim();
        let newData = JSON.parse(JSON.stringify(data));
        if ((data[columnName] != this.state.inputValue) && this.props.agGridReact.props.sendAPIcallOnChange) {
            newData[columnName] = this.state.inputValue;
            this.props.agGridReact.props.sendAPIcallOnChange(this.state.inputValue, rowIndex, column.colId, 'text', newData, colDef, columnName, this.state.inputValue);
        }
    }

    render() {
        let { rowIndex, column, colDef, value, agGridReact, gridCallBack } = this.props;
        let key = 'gridNumber' + rowIndex + column.colId;

        return (
            <div>
                <FieldInput
                    gridCallBack={agGridReact.props.gridCallBack}
                    isFromGrid={true}
                    errorMessageLabels={agGridReact.props.errorMessageLabels}
                    errorMessageLabel={this.state.errorMessageLabel}
                    isCheckWildCard={this.props.colDef.isCheckWildCard}
                    toUppercase={this.props.colDef.toUppercase}
                    fieldType={this.props.colDef.validationType}
                    maxLength={this.props.colDef.maxLength}
                    value={this.state.inputValue}
                    field={{
                        type: 'text',
                        key: key
                    }}
                    disabled={colDef.disabled}
                    onKeyDown={() => { }}
                    onFocusOut={() => this.onFocusOut()}
                    onChange={(key, val) => {
                        this.setOnChangeValue(val);
                    }}
                />
            </div>
        );
    }
}


export default TextRenderer;
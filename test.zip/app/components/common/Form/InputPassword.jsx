
/*
* * //==========================================================================
*
* * // Copyright 2021-2021, Blue Yonder Group, Inc.
*
* * // All Rights Reserved
*
* * //
*
* * // THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF
*
* * // BLUE YONDER GROUP, INC.
*
* * //
*
* * //
*
* * // The copyright notice above does not evidence any actual
*
* * // or intended publication of such source code.
*
* * //
*
* * // ===========================================================================
*/
import classNames from 'classnames';
import PropTypes from 'prop-types';
import React, { Component } from 'react';
import TextField from '@material-ui/core/TextField';

const defaultProps = {
  className: '',
  autoComplete: true,
  autoFocus: false,
};

const propTypes = {
  className: PropTypes.string,
  field: PropTypes.shape({}).isRequired,
  onChange: PropTypes.func.isRequired,
  onKeyDown: PropTypes.func.isRequired,
  value: PropTypes.any,
  autoComplete: PropTypes.bool,
  autoFocus: PropTypes.bool,
};

class InputPassword extends Component {
  constructor() {
    super();
    this.onChange = this.onChange.bind(this);
  }

  onChange(e) {
    const { field, onChange } = this.props;
    const { key } = field;
    onChange(key, e.currentTarget.value);
  }

  render() {
    const { className, field, value, autoComplete, autoFocus, onKeyDown, maxLength } = this.props;
    const { key, placeholder, type } = field;
    const { fieldStyle } = this.props;
    let mL = maxLength ? Number(maxLength) : undefined;

    return (
      <TextField
        className={classNames({
          input: true,
          'input-number': true,
          [className]: className,
        })}
        autoFocus={autoFocus}
        id={key}
        onChange={this.onChange}
        onKeyDown={onKeyDown}
        placeholder={placeholder}
        type={type}
        value={value}
        inputProps={{
          maxLength: mL,
        }}
        {...fieldStyle}
        {...(autoComplete ? {} : { autoComplete: 'off' })}
      >
      </TextField>
    );
  }
}

InputPassword.defaultProps = defaultProps;
InputPassword.propTypes = propTypes;

export default InputPassword;

import React, { Component } from 'react';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import { withStyles, Box, Typography } from '@material-ui/core';
import DialogComponent from 'components/common/DialogComponent';
import theme from '../../../jda-gcp-theme';
import FormattedMessageComponent from '../../common/FormattedMessageComponent';
import FormFieldsGenerator from '../../common/FormFieldsGenerator';
import EmbeddedList from 'containers/common/EmbeddedList';
import Spinner from 'components/Common/Spinner';
import ItemOnDealDetail from './detailDialog'
import FieldInput from 'components/common/Form/FieldInput';
import {
	ITEM_ON_DEAL, MENU_ITEMS, LABEL_ITEM_ON_DEAL, LABEL_CLOSE, LABEL_NEXT,
	LABEL_PREVIOUS, VENDOR_ID, ITEM, WAREHOUSE, LABEL_DEAL, REGULAR_COST,
	DEAL_COST, DEFAULT_VALUE_URL_DATA, TEXT_YES, TEXT_NO,DEFAULT_VALUE_URL_DATA_ITEM
} from "./constants";
import { LABEL_LIST_URL_DATA } from './../constants'
import { TEXT_CANCEL, TEXT_ALERT, TEXT_OK, DEAL_PROPERTIES_PAGE } from '../../common/constants';
import { INITIAL_PAGE_PROPS } from 'components/common/constants';
import { getListPredecessor, getDateFormatValue, prepareValueDataForItemonDeal,prepareValueDataForItems } from 'utils/util';
import reducer from './reducer';
import saga from './saga';
import ConfirmationDialog from 'components/common/ConfirmationDialog';
import {
	errorMessageLabels,
	makeSelectItemOnDealList
} from './selectors';
import {
	getItemOnDealList,
	setApiCallCount,
	onSetPageProps,
	getItemOnDealColumnDefs,
	setFilterValues,
	setColumnDefsLoaded,
	updateShowHide,
	resetStateData,
	resetDefault,
	getItemsList,
	setLabelDataFlags,
	getLabelsList,
	getValueList,
	getDealAllowanceValueList,
	onAddRec,
	onRemoveRec,
	onUpdateRec,
	setUpdateRecordsFlag,
	onSetDataValueChange,
	itemOnDealUpdate,
	setValueData
} from './action';

const styles = theme => ({
	pageContainer: {
		backgroundColor: 'var(--background-app)',
		borderTop: 'none',
	},
	PageWrapper: {
		borderTop: 'none',
		display: 'flex',
	},
	pageContainerThirty: {
		width: '33.3%',
		display: 'flex',
		flexDirection: 'column',
	},
	rightMargin: {
		paddingRight: '10px',
	},
	notesForBlock: {
		display: 'flex',
		flexDirection: 'column',
		marginTop: '10px',
		border: '1px solid var(--divider-line)',
		padding: '10px 10px 0 10px',
		position: 'relative'
	},
	notesForLabel: {
		position: 'absolute',
		top: '-7px',
		left: '10px',
		background: 'var(--background-content)',
		padding: '0 8px',
	},
	fieldLabel: {
		color: 'var(--header-label-color)',
		padding: '0 0px 8px 0',
		width: '22ch',
	},
	childBlock: {
		display: 'flex',
		padding: '6px'
	},
	fieldValue: {
		color: 'var(--value)'
	},
	fieldValuesParent: {
		display: 'flex'
	},
	idValue: {
		marginRight: '20px',
		minWidth: '15ch'
	},
	adjustDialog1: {
		maxHeight: '100vh',
		maxWidth: '200vh',
		'& .MuiDialogContent-root': {
			padding: '12px'
		},
	},
	simpleCardGroup: {
		width: '100%',
		display: 'flex',
		height: '14rem',
		justifyContent: 'space-around',
	},
})
class ItemOnDeal extends Component {
	constructor(props) {
		super(props);
		this.state = {
			rowSelection: 'multiple',
			selectedRows: false,
			menuItems: [...MENU_ITEMS],
			removeRecordNumber: false,
			updateAPICount: 0,
			disable: true,
			detailButton: false,
			selectedRowIndex: false,
			currentRowIndex: false,
			hasPrevious: false,
			hasNext: false,
			showDeleteDialog: false
		}
		this.onRowSelected = this.onRowSelected.bind(this);
		this.onGridReady = this.onGridReady.bind(this);
		this.onValueChanged = this.onValueChanged.bind(this);
		this.handleChangeValue = this.handleChangeValue.bind(this);
		this.getLabelValue = this.getLabelValue.bind(this);
	}
	componentDidMount() {
		this.props.setColumnDefsLoaded(false);
		this.props.getItemOnDealColumnDefs({ type: ITEM_ON_DEAL });
		let labelFilters = LABEL_LIST_URL_DATA;
		this.props.getLabelsList({ recordData: labelFilters, currentPage: 'vendorproperties' });
	}
	componentDidUpdate(prevProps, prevState) {
		const { currentRecordData } = this.props.dealPropertiesPage
		const { itemOnDealIsSaveSuccess, updateColumnsList,resetDefaultsCols,columnDefs } = this.props.itemOnDealListPage
		if (itemOnDealIsSaveSuccess && itemOnDealIsSaveSuccess != prevProps.itemOnDealListPage.itemOnDealIsSaveSuccess) {
			let filters = [{ "accessor": "DSCOMP", "operator": "=", "jOpr": "and", "fieldValue": "E3T", "prefixFlag": 1 },
			{ "accessor": "DSWHSE", "operator": "=", "jOpr": "and", "fieldValue": currentRecordData["DHWHSE"], "prefixFlag": 1 },
			{ "accessor": "DSDEAL", "operator": "=", "jOpr": "and", "fieldValue": currentRecordData["DHDEAL"], "prefixFlag": 1 }];
			this.props.getItemOnDealValueList(filters);
		}
		if (updateColumnsList && updateColumnsList != prevProps.itemOnDealListPage.updateColumnsList) {
			this.props.setColumnDefsLoaded(false);
			this.props.getItemOnDealColumnDefs({ type: ITEM_ON_DEAL });
		}
		if ((resetDefaultsCols != prevProps.itemOnDealListPage.resetDefaultsCols) && resetDefaultsCols) {
			this.props.setLabelDataFlags({ key: 'resetDefaultsCols', value: false });
			this.props.updateShowHide({ type: ITEM_ON_DEAL, actionCode:"D",record:columnDefs });
		}
	}
	handleItemSelection = type => {
		if (type === 'manageItems') {
			this.props.handleManageItems(true)
		}
		if (type === 'detail') {
			const { selectedRows } = this.state;
			this.setState({ detailButton: true })
			if (selectedRows && selectedRows.length) {
				this.sendAPICallForValues(selectedRows[0])
			}
		}
		if (type === 'remove') {
			this.setState({ showDeleteDialog: true })
		}
	}
	getApiObj(recordData, record, currentPage, pageProps) {
		let recordObj = false;
		if (record) {
			recordObj = record;
		}
		const apiObj = {
			recordData,
			pageProps,
			direction: pageProps.isForwardDirection,
			record: recordObj,
			currentPage,
			parentPage: ITEM_ON_DEAL,
		};
		return apiObj;
	}
	sendAPICallForValues(jsonData) {
		const { pageProps } = this.props.dealPropertiesPage;
		let valueData = prepareValueDataForItemonDeal(DEFAULT_VALUE_URL_DATA, jsonData, ITEM_ON_DEAL);
		this.props.getValueList(this.getApiObj(valueData, null, ITEM_ON_DEAL, pageProps));
		this.props.getDealAllowanceValueList(this.getApiObj(valueData, null, DEAL_PROPERTIES_PAGE, pageProps));
		
		let data = {
			'ICOMP': jsonData["DSCOMP"],
			'IWHSE': jsonData["DSWHSE"],
			'IVNDR': jsonData["DSVNDR"],
			'ISUBV': '',
			'ISUPV': '',
			'IITEM':jsonData["DSITEM"]
		}
		let valueDataForItem = prepareValueDataForItems(DEFAULT_VALUE_URL_DATA_ITEM,data)
		this.props.getItemsList(this.getApiObj(valueDataForItem, null, 'itemProperties', pageProps));
	}
	handleChangeValue(key, val, field) {
		const selectedRows = [...this.state.selectedRows]
		let selectedObject = { ...selectedRows[0] }
		selectedObject[key] = val;
		selectedRows[0] = selectedObject;
		this.setState({ selectedRows });
	}
	onValueChanged(data, rowIndex, colId, type, updatedData, columnName) {
		const selectedRows = [...this.state.selectedRows];
		if (selectedRows && selectedRows.length > 0) {
			selectedRows[0] = updatedData;
			this.setState({ selectedRows })
		}
	}
	onRowSelected(e) {
		const { rowdataforItemOnDeal } = this.props;
		if (this.grid && this.grid.api) {
			let selectedRows = this.grid.api.getSelectedRows();
			let selectedRowIndex = e.rowIndex;
			let currentRowIndex = selectedRowIndex;
			let hasPrevious = false;
			let hasNext = false;
			if (rowdataforItemOnDeal && Array.isArray(rowdataforItemOnDeal)) {
				hasPrevious = currentRowIndex > 0 ? true : false;
				hasNext = currentRowIndex < rowdataforItemOnDeal.length - 1 ? true : false;
			}
			this.setState({ selectedRows: selectedRows, selectedRowIndex, currentRowIndex, hasPrevious, hasNext });
		}
	}
	onGridReady(params) {
		this.grid = params;
	}
	getLabelValue(id) {
		return <FormattedMessageComponent id={id} />;
	}
	handleClose = (val = false) => {
		const { valueData, newValueData, rowDataAllowance } = this.props.itemOnDealListPage
		if (val) {
			if (Object.keys(valueData).length && Object.keys(newValueData).length &&
				(JSON.stringify(valueData) != JSON.stringify(newValueData))) {
				this.props.itemOnDealUpdate(newValueData)
			}
			let rowdata = [...rowDataAllowance]
			rowdata.forEach(row => {
				var addDefaultAllowance = row;
				addDefaultAllowance.DADEAL = this.props.stateData.DHDEAL;
				addDefaultAllowance.DAVNDR = this.props.stateData.DHVNDR;
				addDefaultAllowance.DAWHSE = this.props.stateData.DHWHSE;
				addDefaultAllowance.DAITEM = this.state.selectedRows[0]["DSITEM"];
				addDefaultAllowance.DAXCLD = row == "X" ? "X" : "";
				row = addDefaultAllowance
			})
			this.props.onUpdateRec(rowdata)
		}
		this.setState({ detailButton: false, selectedRows:false})
	}
	handlePreviousNext = action => {
		const { currentRowIndex } = this.state
		const { rowdataforItemOnDeal } = this.props;
		let updatedRowIndex;
		switch (action) {
			case LABEL_PREVIOUS:
				updatedRowIndex = currentRowIndex - 1
				this.sendAPICallForValues(rowdataforItemOnDeal[updatedRowIndex])
				break;
			case LABEL_NEXT:
				updatedRowIndex = currentRowIndex + 1
				this.sendAPICallForValues(rowdataforItemOnDeal[updatedRowIndex])
				break;

			default:
				break;
		}
		let hasPrevious = updatedRowIndex > 0 ? true : false;
		let hasNext = updatedRowIndex < rowdataforItemOnDeal.length - 1 ? true : false;
		this.setState({ currentRowIndex: updatedRowIndex, hasPrevious, hasNext })

	}
	yesDeleteDialog = () => {
		this.setState({ showDeleteDialog: false });
		let items = [...this.state.selectedRows];
		if (items && items.length) {
			let body = this.prepareTransferBody(items);
			this.props.itemOnDealDelete(body)
		}
		this.setState({selectedRows:false})
	}
	prepareTransferBody = (list) => {
		const { currentRecordData } = this.props.dealPropertiesPage
		let finalArray = [];
		if (currentRecordData && list && list.length) {
			list.forEach(row => {
				let obj = {
					"DTCOMP": currentRecordData["DHCOMP"],
					"DTDEAL": currentRecordData["DHDEAL"],
					"DTWHSE": currentRecordData["DHWHSE"],
					"DTITEM": row["DSITEM"],
				}
				finalArray.push(obj);
			})
		}
		return finalArray;
	}
	getUpdatedEmbeddedList = (menuList) => {
        if (this.enableActionItems()) {
            return menuList
        }
        menuList.forEach(ele => {
            if (ele.key !== 'showHide' && ele.key !== 'resetDefaults')
                ele['isDisable'] = true;
        });

        return menuList;
    }
	enableActionItems = () => {
        const { canUpdateComponent } = this.props;
        if (canUpdateComponent && Object.keys(canUpdateComponent) && Object.keys(canUpdateComponent).length) {
            if (canUpdateComponent.update)
                return true;
            else
                return false;
        } else
            return true;
    }
	render() {
		const { classes, rowdataforItemOnDeal, currentPage, currentOwnerName, filterCriteriaDetails,
			globalDateFormat, globalFilterOptions, pageFilterOptions, canUpdateComponent, columnDefination } = this.props;

		const { columnDefs, loading, pageProps, removeRecordFlag, rowData, itemListArray, itemsOnDealLabelsData, columnInfo } = this.props.itemOnDealListPage;

		return (<React.Fragment>
			<div className={classes.pageContainer}>
				{(!loading && columnDefs && columnDefs.length && !removeRecordFlag) ?
					<EmbeddedList
						embeddedListTitle={this.getLabelValue(LABEL_ITEM_ON_DEAL)}
						onValueChanged={this.onValueChanged}
						columnInfo={columnInfo}
						singleClickEdit={true}
						gridAPI={this.grid}
						rowData={rowdataforItemOnDeal}
						columnDefs={columnDefs}
						pageProps={pageProps}
						selectedRows={this.state.selectedRows}
						onGridReady={this.onGridReady}
						listProps={this.props}
						rowSelection={this.state.rowSelection}
						onRowSelected={(e) => this.onRowSelected(e)}
						menuItems={this.getUpdatedEmbeddedList(this.state.menuItems)}
						listPredecessor={'DS'}
						sendApi={() => { }}
						dataKey={"embeddedList"}
						currentPage={'itemondeal'}
						namespace={'itemondeal'}
						updateShowHide={(data, currentPage) => this.props.updateShowHide(data, currentPage)}
						resetDefault={(data) => this.props.resetDefault(data)}
						hasRowActions={true}
						isEnableSaveButton={false}
						hasGridActions={true}
						handleItemSelection={this.handleItemSelection}
						menuItemsHandled={['manageItems', 'detail', 'remove']}
						detailRowAction={this.props.canUpdateComponent.update && true}
					    deleteRowAction={this.props.canUpdateComponent.update && true}
						disableColumns={!this.enableActionItems()}
					/>
					: <Spinner loading type="list" />
				}
			</div>
			{this.state.selectedRows && this.state.selectedRows.length && <ItemOnDealDetail
				loading={loading}
				getLabelValue={this.getLabelValue}
				handleClose={this.handleClose}
				detailButton={this.state.detailButton}
				filterCriteriaDetails={filterCriteriaDetails}
				globalDateFormat={globalDateFormat}
				globalFilterOptions={globalFilterOptions}
				pageFilterOptions={pageFilterOptions}
				currentPage={currentPage}
				currentOwnerName={currentOwnerName}
				itemOnDealListPage={this.props.itemOnDealListPage}
				columnDefination={columnDefination}
				canUpdateComponent={canUpdateComponent}
				itemsOnDealLabelsData={itemsOnDealLabelsData}
				setValueData={this.props.setValueData}
				hasPrevious={this.state.hasPrevious}
				hasNext={this.state.hasNext}
				handlePreviousNext={this.handlePreviousNext}
				onAddRec={this.props.onAddRec}
				onRemoveRec={this.props.onRemoveRec}
				onUpdateRec={this.props.onUpdateRec}
				deal={this.props.stateData}
				setUpdateRecordsFlag={this.props.setUpdateRecordsFlag}
				onSetDataValueChange={this.props.onSetDataValueChange}
				errorMessageLabels={this.props.errorMessageLabels}
				valueData={this.props.valueData}
				newValueData={this.props.newValueData}
				item={this.state.selectedRows[0]["DSITEM"]}
			/>}
			{this.state.showDeleteDialog && <ConfirmationDialog
				hasWarning={true}
				isOpen={this.state.showDeleteDialog}
				dialogTitle={"52891"}
				submitText={TEXT_YES}
				cancelText={TEXT_NO}
				handleClose={() => this.setState({ showDeleteDialog: false })}
				handleCancel={() => this.setState({ showDeleteDialog: false })}
				handleSubmit={() => this.yesDeleteDialog()}>
				<div>
					{this.props.errorMessageLabels["E10183"].MTEXT}
				</div>
			</ConfirmationDialog>}
		</React.Fragment>)

	}
}

const mapStateToProps = createStructuredSelector({
	itemOnDealListPage: makeSelectItemOnDealList(),
	errorMessages: errorMessageLabels(),
})

function mapDispatchToProps(dispatch, ownProps) {
	return {
		dispatch,
		//getItemOnDealList: (data) => dispatch(getItemOnDealList(ownProps.nameSpace, data)),
		setApiCallCount: (data) => dispatch(setApiCallCount(ownProps.nameSpace, data)),
		onSetPageProps: (data) => dispatch(onSetPageProps(ownProps.namespace, data)),
		getItemOnDealColumnDefs: (data) => dispatch(getItemOnDealColumnDefs(ownProps.nameSpace, data)),
		setFilterValues: (data) => dispatch(setFilterValues(ownProps.nameSpace, data)),
		setColumnDefsLoaded: (data) => dispatch(setColumnDefsLoaded(ownProps.nameSpace, data)),
		updateShowHide: (data) => dispatch(updateShowHide(ownProps.nameSpace, data)),
		resetStateData: (data) => dispatch(resetStateData(ownProps.nameSpace, data)),
		resetDefault: (data) => dispatch(resetDefault(data)),
		getItemsList: (data) => dispatch(getItemsList(ownProps.nameSpace, data)),
		setLabelDataFlags: (data) => dispatch(setLabelDataFlags(ownProps.nameSpace, data)),
		getLabelsList: (data) => dispatch(getLabelsList(ownProps.nameSpace, data)),
		getValueList: (data) => dispatch(getValueList(ownProps.nameSpace, data)),
		getDealAllowanceValueList: (data) => dispatch(getDealAllowanceValueList(ownProps.nameSpace, data)),
		onAddRec: (data) => dispatch(onAddRec(data)),
		onRemoveRec: (data) => dispatch(onRemoveRec(data)),
		onUpdateRec: (data) => dispatch(onUpdateRec(data)),
		setUpdateRecordsFlag: (data) => dispatch(setUpdateRecordsFlag(data)),
		onSetDataValueChange: (data) => dispatch(onSetDataValueChange(data)),
		itemOnDealUpdate: (data) => dispatch(itemOnDealUpdate(data)),
		setValueData: (data) => dispatch(setValueData(data)),
	}
}

const withConnect = connect(
	mapStateToProps,
	mapDispatchToProps,
);
const withReducer = injectReducer({ key: 'itemOnDealReducer', reducer });
const withSaga = injectSaga({ key: 'itemOnDealSaga', saga });
export default compose(
	withReducer,
	withSaga,
	withConnect,
	withStyles(styles),
)(ItemOnDeal);
// import { withStyles } from '@material-ui/core/styles';
import { connect } from 'react-redux';
import { compose } from 'redux';
import React from 'react';
import HighchartsReact from 'highcharts-react-official';
import Highcharts from 'highcharts/highstock';
import PropTypes from 'prop-types';
import { selectMessages } from './selector';

const propTypes = {
    data: PropTypes.shape({
        DEMND: PropTypes.object,
        PROMO: PropTypes.object,
        ONBAC: PropTypes.object,
        BOOKN: PropTypes.object,
    }).isRequired,
}
class StockClass extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            options: {
                chart: {
                    type: 'column',
                        minWidth: 80,
                    scrollbar: {
                        enabled: false
                    },
                },
                accessibility: {
                    description: ''
                },
                title: {
                    text: null,
                    
                    align: 'left',
                    fontSize: '18px',
                    fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
                    fontWeight: '700',
                    padding: '22px 20px 0 20px',
                    
                },
                credits: {
                    enabled: false
                },
                xAxis: {
                    categories: null, //no label for x-axis
                    scrollbar: {
                        enabled: false
                    },
                },
                yAxis: {
                    min: 0,
                    title: {
                        text: '% Distribution'
                    },
                    stackLabels: {
                        enabled: true,
                        style: {
                            fontWeight: 'bold',
                            color:  'gray'
                        }
                    }
                },

                legend:{
                    layout: 'vertical',
                     align: 'right',
                    verticalAlign: 'middle',
                    labelFormatter: function() {
                       
                        return '<span style="color:' + this.color + '">' + this.name + ': </span>(<b>' + this.yData + '%)<br/>'; 
                    }
                },

                tooltip: {
                    headerFormat: '<b>{point.x}</b><br/>',
                    pointFormat: '{series.name}: {point.y}<br/>Total: {point.stackTotal}'
                },
                plotOptions: {
                    column: {
                        stacking: 'normal',
                        dataLabels: {
                            enabled: true
                        }
                    }
                },
                series: [{
                    name: 'Overstock', 
                    data: [props.graphData.IOVUNT_PCT],
                    color: '#048BD0',
                },
                {
                    name: 'Promotional Overstock', 
                    data: [props.graphData.IPOUNT_PCT],
                    color:  'FBC02D' 
                },
                {
                    name: 'Promotional', 
                    data: [props.graphData.IPRUNT_PCT],
                    color: '#E91E63',
                },
                {
                    name: 'Forward Buy', 
                    data: [props.graphData.IFBUNT_PCT],
                    color: '#8E29BF'
                },
                {
                    name: 'Deal', 
                    data: [props.graphData.IDLUNT_PCT],
                    color: '#27AE60',
                },
                {
                    name: 'Replenishment', 
                    data: [props.graphData.IRPUNT_PCT],
                    color: '#F2994A'
                },
                {
                    name: 'Safety Stock', 
                    data: [props.graphData.ISSUNT_PCT],
                    color: '#C0CA33'
                },
                ]
            }
        }
        this.getDispalyLabel = this.getDispalyLabel.bind(this);
    }

    componentDidMount(){
        const{graphData} = this.props; 

        if(graphData) {
            
            let stateObj = JSON.parse(JSON.stringify(this.state.options));

            stateObj.series[0].name = this.getDispalyLabel(33213) ;
            stateObj.series[1].name = this.getDispalyLabel(33700) ;
            stateObj.series[2].name = this.getDispalyLabel(33701) ;
            stateObj.series[3].name = this.getDispalyLabel(33702) ;
            stateObj.series[4].name = this.getDispalyLabel(33703) ;
            stateObj.series[5].name = this.getDispalyLabel(33705) ;
            stateObj.series[6].name = this.getDispalyLabel(33706) ;
            
            stateObj.yAxis.title.text = this.props.getMessageText('50890')
            this.setState({options: JSON.parse(JSON.stringify(stateObj))});
            
        }
    }

    getDispalyLabel(id){
        const {messages} = this.props;
        let key = 'H'+ id, label = '';
        if(messages && messages[key] && messages[key]['TLLAB'])
            label = messages[key]['TLLAB'].trim();
        else 
            label = id;

        return label;
        
    }

    render() {
        return (
            <div style={{ maxWidth: '100%', width: '100%' }}>
                <HighchartsReact options={this.state.options} highcharts={Highcharts} />
            </div>
        );
    }
}


const mapStateToProps = function (state) {
    return {
        messages: selectMessages(state)
    }
}

const withConnect = connect(
    mapStateToProps,
    null,
);

StockClass.propTypes = propTypes;
export default compose(
    withConnect
)
(StockClass);
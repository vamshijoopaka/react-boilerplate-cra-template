import React from 'react';
import './styles.scss';
import {
  getPathname,
  getPropertiesPathName
} from 'utils/util';

import {
  hasLocalStorageValues
} from 'utils/filterData';

import {
  MAX_CHILD_CHARACTERS_SIZE
} from 'components/common/constants';
import { IconButton } from '@material-ui/core';
import ShowHidden from '../../../images/show_all.png';
import CloseImage from '../../../images/close_icon.png';
import DownArrowImage from '-!react-svg-loader!../../../images/down_single_arrow.svg';
import TabClear from '-!react-svg-loader!../../../images/tab_clear.svg';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';

import CustomizedTooltip from '../CustomizedTooltip';
import FormattedMessageComponent from '../FormattedMessageComponent';
import { getUpdateRestrictionOnComponent, capitalizeFirstLetter } from '../../../utils/util';

class Breadcrumb extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      showChildTabCutDownItems: false,
      keyValueLength: {},
      selectedBreadcrumbIndex: 0
    }
    this.onBreadCrumbSelect = this.onBreadCrumbSelect.bind(this);
    this.closeBreadCrumb = this.closeBreadCrumb.bind(this);
    this.getLastIndex = this.getLastIndex.bind(this);
    this.updateHistory = this.updateHistory.bind(this);
    this.toggleCdItems = this.toggleCdItems.bind(this);
    this.onClickChildCutDownTab = this.onClickChildCutDownTab.bind(this);
    this.getDisplayName = this.getDisplayName.bind(this);
    this.onRemoveChildDownTab = this.onRemoveChildDownTab.bind(this);
    this.handleClick = this.handleClick.bind(this);
    this.getTitleToDisplay = this.getTitleToDisplay.bind(this);
    this.getLabelValue = this.getLabelValue.bind(this);
    this.findStrLen = this.findStrLen.bind(this);
  }

  componentWillMount() {
    document.addEventListener('mousedown', this.handleClick, false)
  }

  componentWillUnmount() {
    document.removeEventListener('mousedown', this.handleClick, false)
  }

  onRemoveChildDownTab(e, tab, index) {
    e.stopPropagation();
    e.preventDefault();
    this.props.removeChildCutdownTab(tab, index);
  }

  toggleCdItems() {
    this.setState({ showChildTabCutDownItems: !this.state.showChildTabCutDownItems })
  }

  onClickChildCutDownTab(breadCrumb, index) {
    const { breadCrumbList } = this.props;
    let selectedIndex = breadCrumbList.length - 1;
    this.setState({ showChildTabCutDownItems: false });
    this.setState({ selectedBreadcrumbIndex: selectedIndex });
    let pathname = '';
    if (breadCrumb.childType) {
      this.props.setIsShowContextMenu(true);
      pathname = getPropertiesPathName(breadCrumb.name);
    } else {
      this.props.setIsShowContextMenu(false);
      pathname = getPathname(breadCrumb.name);
    }
    this.props.history.push({ pathname: pathname, search: `?tab_id=${this.props.activeTabId}&item_id=${breadCrumb.id}` });
    // this.props.setSelectedBreadcrumb(selectedIndex);
    this.props.setCutdownChildTab(breadCrumb, index)
  }

  // To select breadcrumb item
  onBreadCrumbSelect(breadCrumb, index, e) {
    if (!hasLocalStorageValues()) {
      this.props.setTabsData([], -1);
      return;
    }
    if (this.props.activeBreadcrumbId !== breadCrumb.id)
      this.props.clearUserErrorMessage();
    this.setState({ selectedBreadcrumbIndex: index });
    let pathname = '';
    if (breadCrumb.childType) {
      this.props.setIsShowContextMenu(true);
      pathname = getPropertiesPathName(breadCrumb.name);
    } else {
      this.props.setIsShowContextMenu(false);
      pathname = getPathname(breadCrumb.name);
    }
    this.props.history.push({ pathname: pathname, search: `?tab_id=${this.props.activeTabId}&item_id=${breadCrumb.id}` });
    this.props.setSelectedBreadcrumb(index);
  }

  // close breadcrum item and update history
  closeBreadCrumb = (event, breadcrumb, index) => {
    event.stopPropagation();

    // this.props.closeBreadcrumb(index);//E3C-31939:Ajit

    if (this.props.activeBreadcrumbId === breadcrumb.id) {
      let lastVisibleIndex;
      lastVisibleIndex = this.getLastIndex(this.props.breadCrumbList, this.props.breadCrumbList.length - 1);
      if (lastVisibleIndex === index) { // closing last active Item
        lastVisibleIndex = this.getLastIndex(this.props.breadCrumbList, lastVisibleIndex - 1);
      }
      if (lastVisibleIndex != -1) {  // Not the last Item in Tab
        const activeBreadcrumb = this.props.breadCrumbList[lastVisibleIndex];
        let pathname = '', activeName = activeBreadcrumb.name ? activeBreadcrumb.name : breadcrumb.type;
        if (activeBreadcrumb.childType) {
          pathname = getPropertiesPathName(activeName);
        } else {
          pathname = getPathname(activeName)
        }
        const historyObj = {
          pathname: pathname,
          search: `?tab_id=${this.props.activeTabId}&item_id=${activeBreadcrumb.id}`
        };
        this.props.setSelectedBreadcrumb(lastVisibleIndex);
        this.props.closeBreadcrumb(index);///E3C-31939:Ajit
        this.props.history.push(historyObj);
      } else {  // Last item in the tab

        const tabs = this.props.tabs.filter((tab) => tab.show == true);
        if (lastVisibleIndex == -1 && tabs.length == 0) { // Only shown tab
          this.props.history.push({ pathname: '/Dashboard' });
        } else {
          let lastIndex;
          if (index != 0) {
            lastIndex = this.getLastIndex(this.props.tabs, this.props.tabs.length - 1);
          } else {
            lastIndex = this.getLastIndex(this.props.tabs, this.props.tabs.length - 2);
          }
          this.props.closeBreadcrumb(index);//E3C-31939:Ajit  
          if (lastIndex != -1) {
            // this.props.setSelectedTab(lastIndex);
            breadcrumb = this.props.tabs[lastIndex].items.find((item) => item.id == this.props.tabs[lastIndex].selectedBreadcrumbId);
          }
          if (lastIndex === this.props.tabs.findIndex(tab => tab.tab_id === this.props.activeTabId)) { // make last tab active
            this.props.setSelectedTab({ index: lastIndex - 1 });//E3C-31939:Ajit
            this.updateHistory(this.getLastIndex(this.props.tabs, lastIndex - 1), breadcrumb);
          } else { // make previous tab active
            this.props.setSelectedTab({ index: lastIndex });//E3C-31939:Ajit
            this.updateHistory(lastIndex, breadcrumb);
          }
        }
      }
    } else {
      this.props.closeBreadcrumb(index);//E3C-31939:Ajit
    }
  }

  handleClick(e) {
    if (this.node && this.node.contains(e.target)) {
      return;
    }
    this.setState({ showChildTabCutDownItems: false });
  }

  // get last visible tab or breadcrum item index from index
  getLastIndex(list, index) {
    for (let i = index; i > -1; i--) {
      if (list[i].show) {
        return i;
      }
    }
    return -1;
  }

  /**
   * Update history on breadcrumb index
   */
  updateHistory = (lastIndex, breadcrumb) => {
    const selectedBreadcrumbId = this.props.tabs[lastIndex].selectedBreadcrumbId;
    const breadCrumbData = this.props.tabs[lastIndex].items.filter((item) => item.id == selectedBreadcrumbId)[0];
    let pathname = '', activeName = breadCrumbData.name ? breadCrumbData.name : breadcrumb.name;;
    if (breadcrumb?.childType) {
      pathname = getPropertiesPathName(activeName);
    } else {
      pathname = getPathname(activeName)
    }
    const historyObj = {
      pathname: pathname,
      search: `?tab_id=${this.props.tabs[lastIndex].tab_id}&item_id=${this.props.tabs[lastIndex].selectedBreadcrumbId}`
    };
    this.props.history.push(historyObj);
  }

  getLabelValue(key) {
    return <FormattedMessageComponent id={key} strLen={this.findStrLen}></FormattedMessageComponent>;
  }

  findStrLen(key, len, str) {
    let obj = this.state.keyValueLength;
    obj[key] = {
      length: len,
      str: str
    };
    this.setState({ keyValueLength: JSON.parse(JSON.stringify(obj)) });
  }

  getDisplayName(displayName, id) {
    if (displayName == "28317" || displayName == "28316")
      return this.getLabelValue("65563")
    let name = this.getLabelValue(displayName);
    //Commneted to display complete tabName
    // let keyValueName = this.state.keyValueLength[displayName];
    // let maxchars = MAX_CHILD_CHARACTERS_SIZE;
    // const { activeBreadcrumbId } = this.props;
    // if (keyValueName && keyValueName.length && keyValueName.length > maxchars && id != activeBreadcrumbId) {
    //   let values = keyValueName.str.split('');
    //   let firstStr = values.splice(0, maxchars).join('');
    //   return firstStr + '...';
    // }
    return name;
  }

  getTitleToDisplay(breadCrumb) {
    const { breadCrumbList, cutdownItemsList, activeBreadcrumbId } = this.props;
    if (breadCrumb.id !== activeBreadcrumbId) {
      if (breadCrumb.item_data && breadCrumb.item_data.toolTipData && breadCrumb.item_data.toolTipData.length) {
        return <React.Fragment>
          {
            breadCrumb.item_data.toolTipData.map((data) => {
              return <div style={{ display: 'block' }}>
                <div style={{ display: 'block', marginRight: 10 }}>
                  {this.getLabelValue(data.key)} {data.value}
                </div>
              </div>
            })
          }
        </React.Fragment>
      } else {
        return this.getLabelValue(breadCrumb.displayName);
      }
    }
    return "";
  }

  getReadOnlyText = (breadcrumbName, item_data) => {
    if (item_data && item_data.isReadOnly) {
      return this.getLabelValue('2960');
    }
    let componentAuthority = {};
    let componentName = breadcrumbName?.replace(/ /g, '')?.toLowerCase();
    componentAuthority = getUpdateRestrictionOnComponent(capitalizeFirstLetter(breadcrumbName), this.props.authorizedComponentsList);
    if (/filtercriteria|sortcriteria|exportfields|expfieldproperties/.test(componentName)) {
      return '';
    }
    if (Object.keys(componentAuthority).length) {
      if (componentAuthority.update)
        return '';
      else
        return this.getLabelValue('2960');
    }
    return '';
  }


  getDisplayNameForOrderType = item_data => {

    switch (item_data && item_data.recordData && item_data.recordData.data["ROTYP"]) {
      case 'A': return "38109"; //Altenate Source
      case 'B': return "36800"; //Due Order
      case 'C': return "33184"; //Forwardbuy
      case 'D': return "33191"; //Planned
      case 'E': return "33247"; //Booked
      case 'F': return "50952"; //Transfer
      case 'G': return "33137"; //Backorder
      case 'H': return "33188"; //A-Order Point
      case 'I': return "50961"; //Order Point
      case 'J': return "33216"; //Buyer Order Point
      case 'L': return "33138"; //Accepted
      case 'M': return "33139"; //Purged
      case 'Z': return "38109"; //Deactivated
      default: return "39723"; //Order
    }

  };



  render() {
    const { breadCrumbList, cutdownItemsList } = this.props;
    return (
      <div className={'breadcrumbs'}>
        <div className={'breadcrumb__wrapper'} id="breadcrumb_wrapper">
          <div className="breadcrumbs__list" id="breadcrumb_rendered">
            {(breadCrumbList && breadCrumbList.length) ? breadCrumbList.map((breadCrumb, index) => {
              return (
                <CustomizedTooltip title={this.getTitleToDisplay(breadCrumb)}>
                  <div key={index} className={[
                    breadCrumb.id === this.props.activeBreadcrumbId
                      ? 'breadcrumb__selected' : 'breadcrumb__unselected', 'breadcrumb',
                    !breadCrumb.show ? 'hide__breadcrumb' : 'show__breacrumb'
                  ].join(' ')} onClick={(e) => this.onBreadCrumbSelect(breadCrumb, index, e)}>
                    <div>
                      {this.getDisplayName(breadCrumb.name !== "OrdersProperties" ? breadCrumb.displayName : this.getDisplayNameForOrderType(breadCrumb.item_data), breadCrumb.id)}
                      {breadCrumb.name !== "OrdersProperties" ? '' : this.getLabelValue('27084')}
                      {breadCrumb.displayName && breadCrumb.displayName.toLowerCase() == '25458' ? '' : this.getReadOnlyText(breadCrumb.name, breadCrumb.item_data)}
                    </div>
                    <TabClear className={breadCrumb.displayName && breadCrumb.displayName.toLowerCase() == '25458' ? 'breadcrumb__close__hide' : 'breadcrumb__close'} onClick={(event) => this.closeBreadCrumb(event, breadCrumb, index)} />

                    {/* <img className={breadCrumb.displayName.toLowerCase() == 'to do ordering' ? 'breadcrumb__close__hide' : 'breadcrumb__close'} src={CloseImage} onClick={(event) => this.closeBreadCrumb(event, breadCrumb, index)} /> */}
                  </div>
                </CustomizedTooltip>
              )
            }) : null}
          </div>
        </div>
        <div className="child__tabs__section">
          {
            ((cutdownItemsList && cutdownItemsList.length) ?
              <div className={"show__icon_wrapper"} ref={node => this.node = node}>
                <div onClick={this.toggleCdItems} className={'more_tabs'}>
                  <div className={'b_cutdown_length'}>+{cutdownItemsList.length}</div>
                  <ExpandMoreIcon className={"child__tabs_show_icon"} />
                </div>
                {this.state.showChildTabCutDownItems ? <div className={'show__hidden__children'}>
                  <div class={'show__hidden__children_wrapper'}>
                    {cutdownItemsList.map((item, index) => {
                      return (
                        <div className={'hidden__children'} onClick={() => this.onClickChildCutDownTab(item, index)}>
                          {this.getLabelValue(item.displayName)}
                          <TabClear className="breadcrumb__close" onClick={(e) => this.onRemoveChildDownTab(e, item, index)} />
                        </div>
                      )
                    })}
                  </div>
                </div> : null}
              </div> : null)
          }
        </div>
      </div>
    )
  }
}

export default Breadcrumb;
import React from 'react';

import { withStyles, Button, Box, Typography } from '@material-ui/core';
import {
    CONTEXT_MENU_PLANPROPERTIES_ACTIONS,
    CONTEXT_MENU_PLANS_HEADER
} from './constants';
import { injectIntl } from 'react-intl';
import {
    LABEL_VENDOR_ID,
    LABEL_WAREHOUSE,
    LABEL_COMMENT
} from './constants';
import FormattedMessageComponent from '../../common/FormattedMessageComponent';
import FormFieldsGenerator from '../../common/FormFieldsGenerator';


import theme from 'jda-gcp-theme';

const style = () => ({

    vendorNameInput: {
        // marginLeft: '-17px',
        padding: '5px 0 5px 0',
        height: '42px',
        '& .MuiFormControlLabel-label': {
            padding: '10px 17px 10px 0px'
        },
        '& input': {
            width: '30ch',
            // fontSize: '32px'
        },
        '& svg': {
            top: '4px'
        },
        '& span': {
            // width: '0'
        }
    },



    value: {
        color: 'var(--value)',
        height: '1rem'
    },
    notesForBlock: {
        display: 'flex',
        flexDirection: 'column',
        marginTop: '25px',
        border: '1px solid var(--divider-line)',
        padding: '10px 10px 0 10px',
        position: 'relative'
    },
    notesForLabel: {
        position: 'absolute',
        top: '-7px',
        left: '10px',
        background: 'var(--background-content)',
        padding: '0 8px',
    },
    Width: {
        paddingLeft: '20px',
        paddingRight: '20px'
    },
    fieldLabel: {
        color: 'var(--header-label-color)',
        padding: '0 0px 8px 0',
        width: '22ch',
    },
    childBlock: {
        display: 'flex',
        padding: '6px'
    },
    fieldValue: {
        color: 'var(--value)'
    },
    fieldValuesParent: {
        display: 'flex'
    },
    idValue: {
        marginRight: '20px',
        minWidth: '15ch'
    },
    deleteRowIcon2: {
        position: 'absolute',
        // top: 327,
        left: '65%',
        '& > *': {
            // marginRight: 16
        }
    },
    numericLeftAlignment: {
        '& div.ag-cell': {
            '& div.input-number': {
                '& > div': {
                    width: '100%'
                },
                '& input': {
                    textAlign: 'right',
                    paddingRight: 10
                }
            }
        }
    },
    notesForBlockAdd: {
        display: 'flex',
        flexDirection: 'column',
        marginTop: '10px',
        padding: '10px 0px 0 10px',
        position: 'relative'
    },
});

class Header extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            actionList: CONTEXT_MENU_PLANPROPERTIES_ACTIONS,
            isOpenActions: false,
            actionMenuRef: null,

            contextMenuList: CONTEXT_MENU_PLANS_HEADER,

            dialogTitle: '',
            hasWarning: false,
            filedArray: [],
            isOpenActionsContextMenu: false,
            menuRef: null,
            hasError:false
        }
        this.getLabelValue = this.getLabelValue.bind(this);
        this.handleActionSelection = this.handleActionSelection.bind(this);
        this.setIsActionClose = this.setIsActionClose.bind(this);
        this.handleSubmitAction = this.handleSubmitAction.bind(this);
    }




    getLabelValue(id) {
        return <FormattedMessageComponent id={id}></FormattedMessageComponent>;
    }

    handleSubmitAction = () => {
        if (this.props.onValid(this.props.projectionValues) == true) {// this.formatObject(this.props.projectionValues);
            this.props.onUpdateValues(this.formatObject(this.props.projectionValues), 1);
        }
    };

    handleActionSelection = action => {
        switch (action) {
            case "RecalQty":
                if (this.onRecalcValid(this.props.valuesArray, this.props.headerData)) {
                    this.props.plansRecalcQty(this.prepareData(this.props.headerData,this.props.valuesArray))
                }
                break;
        }
    };
    prepareData = data => {
        let obj = {}
        obj.KQCOMP = "E3T",
            obj.KQWHSE = data.PDWHSE,
            obj.KQVNDR = data.PDVNDR,
            obj.KQITEM = data.PDITEM,
            obj.KQRDAT = data.PDRDAT,
            obj.KQLT = data.PDLT,
            obj.KQLTV = data.PDLTV,
            obj.KQPCT = data.PDPCT,
            obj.KQPCTD = data.PDPCTD,
            obj.KQPCTP = data.PDPCTP,
            obj.KQPDAT = data.PDPDAT,
            obj.KQQTY = data.PDQTY,
            obj.KQPACT = data.PDACCT
        return obj
    };

    setIsActionClose = () => {
        this.setState({ isOpenActions: false });
    };
    getwarehouseName = () => {
        const { warehouse } = this.props.plansData;
        if (warehouse != undefined && warehouse != "undefined") return warehouse.WNAME;
        return " ";
    };
    handleDisableSubmit = () => {
        const { valuesArray } = this.props
        if (valuesArray.EICLOD != "0" || (valuesArray.EIPCT != "0.000" )) return false;
        return true
    };
    prepareData = (headerData,data) => {
        let obj = {}
        obj.KQCOMP = data.EICOMP,
            obj.KQWHSE = headerData.EIWHSE,
            obj.KQVNDR = headerData.EIVNDR,
            obj.KQITEM = headerData.EIITEM,
            obj.KQRDAT = data.EIRDAT,
            obj.KQLT = data.EILT,
            obj.KQLTV = data.EILTV,
            obj.KQPCT = data.EIPCT,
            obj.KQPCTD = data.EIPCTD,
            obj.KQPCTP = data.EIPCTP,
            obj.KQPDAT = data.EIPDAT,
            obj.KQQTY = data.EIQTY,
            obj.KQPACT = data.EIACCT
        return obj
    };
    onRecalcValid = (valuesArray, headervalues) => {
        let validOutput = true;
        if (headervalues.EIWHSE == "" || headervalues.EIITEM == "") {
            this.props.setGridError('10721');
            this.props.setError(false);
            validOutput = false;
        }
        if (headervalues.EIWHSE == "" || headervalues.EIVNDR == "" || headervalues.EIITEM == "" || (valuesArray.EIRDAT == "0" && valuesArray.EIPCT == "0.000")) {
            this.props.setGridError('10707');
            this.props.setError(false);
            validOutput = false;
        }
        return validOutput
    };
    setGridError = errorId => {
        this.setState({ hasError: true, errorId }, () => {
            setTimeout(() => {
                this.setState({ hasError: false, errorId: false });
            }, 3e3);
        });
    };

    render() {
        const { classes, headerData, commentFieldArray, valuesArray,itemDetails } = this.props;
        return (
            <div className={classes.Width}>
                <div className={classes.notesForBlock}>
                    <Box mb={theme.spacing(0.5)} className={classes.notesForLabel}></Box>
                    <Box className={classes.childBlock}>
                        <div className={classes.fieldLabel}>{this.getLabelValue(LABEL_VENDOR_ID)}</div>
                        <div className={classes.fieldValuesParent}>
                            <Typography className={`${classes.fieldValue} ${classes.idValue}`}>{headerData.EIVNDR}</Typography>
                            <Typography className={`${classes.fieldValue} ${classes.idValue}`}>{itemDetails.EIVNAM}</Typography>
                            <Typography className={`${classes.fieldValue} ${classes.idValue}`}>{headerData.EISUBV}</Typography>

                        </div>
                    </Box>
                    <Box className={classes.childBlock}>
                        <div className={classes.fieldLabel}>{this.getLabelValue('33115')}</div>
                        <div className={classes.fieldValuesParent}>
                            <Typography className={`${classes.fieldValue} ${classes.idValue}`}>{headerData.EIITEM}</Typography>
                            <Typography className={`${classes.fieldValue} ${classes.idValue}`}>{headerData.EIINAM}</Typography>
                        </div>
                    </Box>

                    <Box className={classes.childBlock}>
                        <div className={classes.fieldLabel}>{this.getLabelValue(LABEL_WAREHOUSE)}</div>
                        <div className={classes.fieldValuesParent}>
                            <Typography className={`${classes.fieldValue} ${classes.idValue}`}>{headerData.EIWHSE}</Typography>
                            <Typography className={`${classes.fieldValue} ${classes.idValue}`}>{headerData.EIWNAM}</Typography>
                        </div>
                    </Box>
                    <Box className={classes.childBlock}>
                        <div className={classes.fieldLabel}>{this.getLabelValue(LABEL_COMMENT)}</div>
                        <div className={classes.fieldValuesParent}>
                            <FormFieldsGenerator
                                key="header"
                                className={classes.vendorNameInput}
                                isHeader
                                fieldsArray={commentFieldArray}
                                valuesArray={valuesArray}
                                handleChangeValue={(key, val, field) =>
                                    this.props.handleChangeValue(key, val, field)
                                }
                                enableAddButton={() => { }}
                                currentPage="eventitems"
                                noMassMaintenance
                                hideLabels></FormFieldsGenerator>
                        </div>
                    </Box>
                    <div className={classes.deleteRowIcon2}>
                        <div className={`${classes.notesForBlockAdd} ${classes.blockWidth} ${classes.blockMargin}`}>
                            <Button color="primary" size="small" variant="outlined" disabled={this.handleDisableSubmit()} className={classes.submitButton} onClick={() => this.handleActionSelection('RecalQty')} >
                                <div >{this.getLabelValue('25574')}</div>
                            </Button>

                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
export default injectIntl(withStyles(style)(Header));

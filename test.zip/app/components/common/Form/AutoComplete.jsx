
/*
* * //==========================================================================
*
* * // Copyright 2021-2021, Blue Yonder Group, Inc.
*
* * // All Rights Reserved
*
* * //
*
* * // THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF
*
* * // BLUE YONDER GROUP, INC.
*
* * //
*
* * //
*
* * // The copyright notice above does not evidence any actual
*
* * // or intended publication of such source code.
*
* * //
*
* * // ===========================================================================
/* *******************************PATCH HISTORY******************************** */

/* E3C-30241 - SRK - Field Dropdown showing entries that were not part of character
                     typed. This is because Options being passed includes "value" 
                     field which is also being searched besides "label". So, passed
                     only "label" in the Options being passed to AutoComplete.
                     
* * // ===========================================================================
*/
import PropTypes from 'prop-types';
import React, { Component } from 'react';
import Select from 'react-select'
import { Autocomplete } from '@material-ui/lab';
import TextField from '@material-ui/core/TextField';
import { getSelectionReplaceString } from '../../../utils/fieldValidations';
import FormattedMessageComponent from '../FormattedMessageComponent';
import { KEYBOARD_SPECIAL_KEYS } from '../constants';
import { isEqual } from 'lodash';
import SearchIcon from '@material-ui/icons/Search';
import { withStyles } from '@material-ui/core/styles';
import theme from '../../../jda-gcp-theme';
import CustomizedTooltip from '../CustomizedTooltip';

const defaultProps = {
  className: '',
  value: '',
};

const propTypes = {
  className: PropTypes.string,
  field: PropTypes.shape({}).isRequired,
  onChange: PropTypes.func.isRequired,
  value: PropTypes.any,
};

const styles = theme => ({
  inputWrapper: {
    display: 'flex',
    position: 'relative',
  },
  searchIcon: {
    position: 'absolute',
    bottom: '5px'
  },
  crossIcon: {
    right: '15px',
    bottom: '8px',
    position: 'absolute',
    width: '10px',
  }
})

class AutoComplete extends Component {
  constructor() {
    super();
    this.state = {
      filteredOptions: [],
      filteredLabels: [],
      hasOverflowingChildren: false,
      tooltipText: false
    }
    this.onChange = this.onChange.bind(this);
  }

  onChange(e, val) {
    const { field, onChange } = this.props;
    const { key, options } = field;
    let optionSelected = val ? options.find(option => option.value.trim() === val.value.trim()) : val;
    onChange(key, optionSelected);
  }

  isEllipsisActive = (e) => {
    return (e.offsetWidth < e.scrollWidth);
  }

  onKeyDown = (e) => {
    const { value, field } = this.props;
    let id = field.id ? field.id : field.key;
    let docValue = document.getElementById(id).value;
    let str = getSelectionReplaceString(e, docValue ? docValue : '');
    if (e.altKey || e.shiftKey || e.ctrlKey) {
      return true;
    }
    if (docValue && (docValue.length < str.length) && (docValue != str) && value.label && (docValue == value.label)) {
      e.preventDefault();
    }
  }

  getIntlLabel = (id) => {
    return <FormattedMessageComponent id={id}></FormattedMessageComponent>;
  }
  setFilteredOptions = () => {
    let filteredOptions = this.props.field.options.map(item => {
      let obj = {}
      obj['label'] = item.isIntlText ? this.getIntlLabel(item.label) : item.label;
      obj['value'] = item.value.trim();
      return obj;
    });
    this.setState({ filteredOptions: filteredOptions });

    let filteredLabels = this.props.field.options.map(item => {
      let obj = {}
      obj['label'] = item.isIntlText ? this.getIntlLabel(item.label) : item.label;
      return obj;
    });
    this.setState({ filteredLabels: filteredLabels });
  }
  componentDidMount() {
    this.setFilteredOptions();
  }
  componentDidUpdate(prevProps) {
    const { options, id, key } = this.props.field;
    if (options && !isEqual(options, prevProps.field.options)) {
      this.setFilteredOptions();
    }

    if (prevProps.value != this.props.value) {
      let element = document.getElementById(id || key);
      const hasOverflowingChildren = this.isEllipsisActive(element);
      if (this.props.value && this.props.value.label)
        this.setState({ hasOverflowingChildren, tooltipText: this.props.value.label });
      else
        this.setState({ hasOverflowingChildren: false, tooltipText: false });

    }
  }
  render() {
    const { className, tabindex, field, value, onFocus, disabled, classes } = this.props;
    const { options, placeholder, key, defaultValue, id } = field;
    const { hasOverflowingChildren, tooltipText, filteredOptions, filteredLabels } = this.state;
    return (
      <CustomizedTooltip title={hasOverflowingChildren && tooltipText ? tooltipText : ''}>
        <Autocomplete
          ref={e => this.fieldRef = e}
          options={filteredLabels}
          getOptionLabel={option => option.label ? option.label : ''}
          className={className}
          id={id || key}
          disabled={disabled}
          // inputValue={value && value.label || ''}
          value={value}
          onChange={(e, val) => this.onChange(e,filteredOptions.find(element => element.label === val.label))}
          onFocus={onFocus}
          onKeyDown={(e) => this.onKeyDown(e)}
          renderInput={params => {
            // if (value && value.label) {
            //   return <TextField  {...params}
            //   fullWidth value={value.label} onChange={this.onChange} />
            // } else {
            return <div className={classes.inputWrapper}>
              <SearchIcon className={classes.searchIcon}></SearchIcon>
              <TextField
                {...params}
                fullWidth
                {...(params.autoComplete ? {} : { autoComplete: 'off' })}
              // inputProps={{
              //   ...params.inputProps,
              //   autoComplete: 'disabled', // disable autocomplete and autofill
              // }}
              />
            </div>
            // }
          }}
        />
      </CustomizedTooltip>
    );
  }
}

AutoComplete.defaultProps = defaultProps;
AutoComplete.propTypes = propTypes;

export default withStyles(styles)(AutoComplete);

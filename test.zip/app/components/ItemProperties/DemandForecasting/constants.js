export const ACTIONS_CONTEXT_MENU = [
    {
      label: '50766',
      key: 'simprofile',
      hasSubMenu: false,
      isDisable: true,
    },
    {
      label: '51084',
      key: 'simitem',
      hasSubMenu: false,
      isDisable: true,
    },
    {
      label: '50773',
      key: 'acceptprofile',
      hasSubMenu: false,
      isDisable: true,
    },
    {
      label: '2',
      key: 'cancel',
      hasSubMenu: false,
      isDisable: true,
    },
  ];
import React from 'react';
import classNames from 'classnames';
import './style.scss';
import CloseImage from '../../../images/close_icon.png';
import ErrorImage from '-!react-svg-loader!../../../images/error_outline.svg';
import WarningIcon from '-!react-svg-loader!../../../images/warning_icon.svg';
import { POPUP_TIMEOUT } from '../../../utils/constants';
import CloseIcon from '@material-ui/icons/Close';

class ServerErrorMessageComponent extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      popUp: true,
      animationStatus: false
    };
    this.handleClose = this.handleClose.bind(this);
  }

  componentDidMount() {
    this.index = 0;
  }

  componentDidUpdate(prevProps) {
    const { messageList } = this.props.serverErrorMessageData;
    if (prevProps.serverErrorMessageData.messageList !== messageList) {
      if (!prevProps.serverErrorMessageData.messageList.length)
        this.index = 1;
      if (messageList && messageList.length) {
        this.index += 1;
        this.setState({ animationStatus: true, popUp: true }, () => {
          setTimeout(
            function () {
              this.setState({ animationStatus: false, popUp: false }, () => {
                this.handleClose(null, messageList);
              });
            }.bind(this), POPUP_TIMEOUT * this.index);
        });
      }
    }
  }

  handleClose(keyEvent, messageList) {
    const { removeUserErrorMessage } = this.props;
    if (messageList.length) {
      removeUserErrorMessage();
      this.setState({ popUp: true });
    } else {
      this.index = 1;
      this.setState({ popUp: false });
    }
  }

  render() {
    const { messageList } = this.props.serverErrorMessageData;
    const { isError } = this.props;
    const { animationStatus } = this.state;
    return (
      <div className="server__error__message__popup">
        {messageList &&
          !!messageList.length &&
          Object.keys(messageList[0]) &&
          this.state.popUp && (
            <div
              className={classNames({
                server__error__message: true,
                error__background: isError,
                warning__background: !isError,
                'animation--comes__in': animationStatus,
                'animation--goes__out': !animationStatus
              })}
            >
              <div className="server__error__message__left__section">
                <div className="error__message__icon">
                  <div>
                    {isError && (
                      <ErrorImage className="server__error__message__icon" />
                    )}
                    {!isError && (
                      <WarningIcon className="server__error__message__icon" />
                    )}
                  </div>
                </div>
                <div className="server__error__message__text">
                  <div>{messageList[0].messageText}</div>
                </div>
              </div>
              <div className="server__error__message__close__icon">
                <CloseIcon className="error-icon-close"
                  onClick={e => this.handleClose(e, messageList)} />
                {/* <img
                  className="error-icon-close"
                  src={CloseImage}
                  onClick={e => this.handleClose(e, messageList)}
                /> */}
              </div>
            </div>
          )}
      </div>
    );
  }
}
export default ServerErrorMessageComponent;

import React, { Component } from 'react';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import { withStyles, Box, Typography } from '@material-ui/core';
import DialogComponent from 'components/common/DialogComponent';
import FormattedMessageComponent from 'components/common/FormattedMessageComponent';
import FormFieldsGenerator from 'components/common/FormFieldsGenerator';
import EmbeddedList from 'containers/common/EmbeddedList';
import Spinner from 'components/Common/Spinner';
import FieldInput from 'components/common/Form/FieldInput';
import {
	LABEL_APPLY_CHANGES_TO_ITEMS, TEXT_COPY,
	SELECT_WAREHOUSES,
	ITEM, UPDATE_HEADERS, VALUE_ARRAY, CUSTOMER_ID,
	MENU_ITEMS, APPLY_CHANGES_TO_ITEMS_FILTER_VALUES, APPLY_CHANGES_TO_ITEMS,
	TO_WAREHOUSES, WAREHOUSE_PAGE, DEALS_PAGE
} from "./constants";
import { TEXT_CANCEL, TEXT_ALERT, TEXT_OK, DEAL_PROPERTIES_PAGE } from 'components/common/constants';
import { INITIAL_PAGE_PROPS } from 'components/common/constants';
import { getListPredecessor, getDateFormatValue } from 'utils/util';
import reducer from './reducer';
import saga from './saga';
import ConfirmationDialog from 'components/common/ConfirmationDialog';
import {
	rowDataSelector,
	columnDefsSelector,
	loadingSelector,
	columnFlagSelector,
	pagePropsSelector,
	filterPropsSelector,
	columnInfoSelector,
	isAPIProgressSelector,
	totalCountSelector,
	moreRecordsSelector,
	apiCallCountSelector,
	updateColumnsListSelector,
	errorMessageLabels,
	dealsListSelector,
	makeSelectApplyChangestoItems
} from './selectors';
import {
	getApplyChangestoItemsList,
	setApiCallCount,
	onSetPageProps,
	getApplyChangestoItemsColumnDefs,
	setFilterValues,
	setColumnDefsLoaded,
	updateShowHide,
	resetStateData,
	resetDefault,
	getDealHeaderList,
	setLabelDataFlags
} from './action';

const styles = theme => ({
	adjustUpdateHeader: {
		display: 'flex',
		bottom: '10px',
		left: '22px',
		position: 'fixed'
	},
	updateHeader: {
		paddingTop: '10px',
	}
});

class ApplyChangestoItems extends Component {
	constructor(props) {
		super(props);
		this.state = {
			selectAllFlag: false,
			selectedCount: 0,
			selectedRecordsObject: {},
			menuItems: [...MENU_ITEMS],
			rowSelection: 'multiple',
			selectedRows: false,
			valueDataFailureMessages: [],
			valueArray: { ...VALUE_ARRAY },
			showValueConfirmationDialog: false,
		}
		this.handleValueDataErrorMessages = this.handleValueDataErrorMessages.bind(this);
		this.getLabelValue = this.getLabelValue.bind(this);
	}
	getLabelValue(id) {
		return <FormattedMessageComponent id={id} />;
	}
	setAssociativeArrayObject = (rowData) => {
		const { apiCallCount, pageProps } = this.props;
		let str = apiCallCount + "buffer";
		let data = this.state.selectedRecordsObject;
		if (data && Object.keys(data) && rowData && rowData.length) {
			for (let key in data) {
				let recordData = data[key];
				if (recordData && recordData.length && (key == str)) {
					recordData.forEach((record, index) => {
						rowData[index]["isSelected"] = record.isSelected;
					})
				}
			}
		}
		data[str] = rowData;
		this.setState({ selectedRecordsObject: data })
	}
	updateSelectAllFlag = (flag) => {
		const { rowData = [] } = this.props;
		this.setState({ selectAllFlag: flag, selectedCount: flag ? rowData.length : 0 });
	}
	changeValuesOnSelectDeselect = (flag) => {
		let recordObj = this.state.selectedRecordsObject;
		if (recordObj && Object.keys(recordObj)) {
			for (let key in recordObj) {
				if (recordObj[key] && recordObj[key].length) {
					recordObj[key].forEach((record, index) => {
						record.isSelected = flag;
					})
				}
			}
		}
		this.setState({ selectedRecordsObject: recordObj })
	}

	onRowSelected = (event) => {
		if (this.grid && this.grid.api) {
			const { apiCallCount, pageProps, rowData, dealHeaderListArray } = this.props;
			const { actualPageSize, actualPage } = pageProps;
			let data = this.state.selectedRecordsObject;
			if (data && Object.keys(data) && Object.keys(data).length) {
				let key = apiCallCount + "buffer";
				let rowIndex = (event.rowIndex + (actualPageSize * actualPage)) % 100;
				const { selected } = event.node;
				data[key][rowIndex]['isSelected'] = selected;
				this.setState({ selectedRecordsObject: data });
				let count =this.grid.api.getSelectedRows().length || 0
				this.setState((state) => ({ selectedCount: count }))
				let totalCount = apiCallCount * 100 + (rowData.filter(row => dealHeaderListArray.find(deal => deal.DHWHSE === row.WWHSE)).length)
				this.setState({selectAllFlag :(count == totalCount)})
			}
		}
	}
	getApiObj = (filterProps, record, pageProps, currentPage) => {
		let apiObj = {
			filterProps, filterProps,
			pageProps: pageProps,
			direction: pageProps.isForwardDirection,
			record: record,
			currentPage: currentPage
		};
		return apiObj;
	}

	setPageForwardDirection = (flag) => {
		let initialPageData = {
			...INITIAL_PAGE_PROPS,
			actualPage: 0,
			currentPage: 0,
			totalCount: 10,
			isForwardDirection: flag
		};
		this.setState({ initialPageData: initialPageData });
		this.props.onSetPageProps(initialPageData);
	}

	componentWillUnmount() {
		this.props.setColumnDefsLoaded(false);
		this.props.resetStateData(false)
	}

	componentDidMount() {
		let filterData = [...APPLY_CHANGES_TO_ITEMS_FILTER_VALUES];
		this.props.setFilterValues(filterData);
		this.setPageForwardDirection(true);
		this.props.getApplyChangestoItemsColumnDefs({ type: APPLY_CHANGES_TO_ITEMS });
	}

	componentDidUpdate(prevProps, prevState) {
		const { columnDefs, rowData, isColumnDefsLoaded, filterProps, pageProps, updateColumnsList } = this.props;
		const {
			isAPIforApplyChangestoItemsList,
			isAPIforColumns,
			isAPIforColumnsUpdate,
			isAPIforResetColumns,
			isAPIforItemList,
			resetDefaultsCols
		} = this.props.applyChangestoItemsPage

		if (this.state.valueDataFailureMessages && this.state.valueDataFailureMessages.length
			&& (JSON.stringify(this.state.valueDataFailureMessages) != JSON.stringify(prevState.valueDataFailureMessages))) {
			this.handleValueDataErrorMessages(this.state.valueDataFailureMessages[0]);
		}
		if (isAPIforApplyChangestoItemsList && (isAPIforApplyChangestoItemsList != prevProps.applyChangestoItemsPage.isAPIforApplyChangestoItemsList)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to fetch Warehouse List");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isAPIforApplyChangestoItemsList', value: false });
		}

		if (isAPIforColumns && (isAPIforColumns != prevProps.applyChangestoItemsPage.isAPIforColumns)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to fetch columns For Warehouse Embeddedlist");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isAPIforColumns', value: false });
		}

		if (isAPIforColumnsUpdate && (isAPIforColumnsUpdate != prevProps.applyChangestoItemsPage.isAPIforColumnsUpdate)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to update columns For Warehouse Embeddedlist");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isAPIforColumnsUpdate', value: false });
		}

		if (isAPIforResetColumns && (isAPIforResetColumns != prevProps.applyChangestoItemsPage.isAPIforResetColumns)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to Rest columns For Warehouse Embeddedlist");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isAPIforResetColumns', value: false });
		}

		if (isAPIforItemList && (isAPIforItemList != prevProps.applyChangestoItemsPage.isAPIforItemList)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to fetch Items List");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isAPIforItemList', value: false });
		}

		let filterData = [...APPLY_CHANGES_TO_ITEMS_FILTER_VALUES];
		filterData.push({ "accessor": "DEAL", "operator": "=", "jOpr": "and", "fieldValue": this.props.valueData.DHDEAL, "prefixFlag": 0 });
		
		if ((pageProps != prevProps.pageProps) && pageProps.isPageSizeChanged) {
			let initialPageData = {
				...pageProps,
				actualPage: 0,
				currentPage: 0,
				totalCount: 10,
				isForwardDirection: true,
			};
			this.props.onSetPageProps({
				...pageProps,
				isPageSizeChanged: false
			});
			this.props.setApiCallCount(0);
			this.props.getApplyChangestoItemsList(this.getApiObj(filterProps, false, initialPageData, WAREHOUSE_PAGE));
			this.props.getDealHeaderList(this.getApiObj(filterData, false, initialPageData, DEALS_PAGE));
		}

		if (columnDefs != prevProps.columnDefs && isColumnDefsLoaded != prevProps.isColumnDefsLoaded) {
			if (isColumnDefsLoaded) {
				this.props.getApplyChangestoItemsList(this.getApiObj(filterProps, false, pageProps, WAREHOUSE_PAGE));
				this.props.getDealHeaderList(this.getApiObj(filterData, false, pageProps, DEALS_PAGE));
			}
		}

		if (rowData != prevProps.rowData) {
			this.setAssociativeArrayObject(rowData)
		}

		if ((updateColumnsList != prevProps.updateColumnsList) && updateColumnsList) {
			this.props.getApplyChangestoItemsColumnDefs({ type: APPLY_CHANGES_TO_ITEMS });
		}
		if ((prevState.selectAllFlag != this.state.selectAllFlag) || prevState.selectedCount != this.state.selectedCount) {
			if (this.state.selectAllFlag) {
                let deselectAllDisable = false, selectAllDisable = true;
                this.disableMenuItem(deselectAllDisable, selectAllDisable);
            }
            else if (!this.state.selectedCount) {
                let deselectAllDisable = true, selectAllDisable = false;
                this.disableMenuItem(deselectAllDisable, selectAllDisable);
            }
            else {
                this.disableMenuItem(false);
            }
		}
		if ((resetDefaultsCols != prevProps.applyChangestoItemsPage.resetDefaultsCols) && resetDefaultsCols) {
			this.props.setLabelDataFlags({ key: 'resetDefaultsCols', value: false });
			this.props.updateShowHide({ type: APPLY_CHANGES_TO_ITEMS, actionCode:"D",record:columnDefs });
		}
	}
    disableMenuItem = (deselectAllDisable, selectAllDisable) => {
        this.setState({
            menuItems: MENU_ITEMS.map(row => {
                let item = { ...row };
                if (item.key == 'deselectAll')
                    item.isDisable = deselectAllDisable;
                else if (item.key == 'selectAll' && selectAllDisable != undefined)
                    item.isDisable = selectAllDisable;
                return item;
            })
        })
    }

	getSelectedRowsForAPI = () => {
		let selectedRows = [];
		let recordObj = this.state.selectedRecordsObject;
		if (recordObj && Object.keys(recordObj)) {
			for (let key in recordObj) {
				let dataRecord = recordObj[key];
				if (dataRecord && dataRecord.length) {
					dataRecord.forEach((record) => {
						if (record.isSelected) {
							selectedRows.push(record);
						}
					})
				}
			}
		}
		return selectedRows;
	}

	handleSubmit = () => {
		let rowdata = this.getSelectedRowsForAPI();
		const { dealHeaderListArray, currentRecordData } = this.props;
		let selectedRows = rowdata.filter(row => dealHeaderListArray.find(deal => deal.DHWHSE === row.WWHSE));
		let data;
		let filters = [{ "accessor": "DHCOMP", "operator": "=", "jOpr": "and", "fieldValue": "E3T", "prefixFlag": 1 },
		{ "accessor": "DHDEAL", "operator": "=", "jOpr": "and", "fieldValue": currentRecordData["DHDEAL"], "prefixFlag": 1 }];

		if (this.state.selectAllFlag) {
			data = this.prepareBodyMM(new Array(selectedRows[0]));
			this.props.getMassMaintenanceAllData(data,filters)
			this.props.saveData()
			this.handleClose();
		} else {
			data = this.prepareBodyMM(selectedRows);
			this.props.getMassMaintenanceData(data)
			this.props.saveData()
			this.handleClose();
		}
	}
	prepareBodyMM = (selectedRows) => {
		const { valueData, newValueData } = this.props;
		const { valueArray } = this.state;
		let updateHeaderOnlyFlag = Boolean(Number(valueArray['updateHeader']));
		let addFieldData = [];
		let queryData = [];
		selectedRows.forEach(row => {
			let data = [];
			data.push({ "key": "DHCOMP", "opr": "=", "jOpr": "and", "val": newValueData['DHCOMP'] });
			data.push({ "key": "DHWHSE", "opr": "=", "jOpr": "and", "val": row['WWHSE'] });
			data.push({ "key": "DHDEAL", "opr": "=", "jOpr": "and", "val": newValueData['DHDEAL'] });
			queryData.push(data)
		})

		if (newValueData && Object.keys(newValueData) && Object.keys(newValueData).length) {
			Object.keys(newValueData).forEach(key => {
				if (newValueData[key] != valueData[key]) {
					addFieldData.push({ "key": key, "val": newValueData[key] });
				}
			})
		}
		return {
			updateHeaderOnlyFlag, addFieldData, queryData
		}

	}

	handleClose = () => {
		this.props.handleApplyChangestoItems(false)
	}

	onGridReady = (params) => {
		this.grid = params;
	}
	handleChangeValue = (key, val) => {
		const valueArray = { ...this.state.valueArray };
		valueArray[key] = val;
		this.setState({ valueArray });
	}

	closeValueDialog = () => {
		this.setState({ showValueConfirmationDialog: false });
		if (this.state.valueDataFailureMessages && this.state.valueDataFailureMessages.length) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.shift();
			this.setState({ valueDataFailureMessages: values });
			if (values && values.length == 0) {
				this.handleClose();
			}
		}
	}
	handleValueDataErrorMessages(content) {
		this.setState({ showValueConfirmationDialog: true, dialogContent: content });
	}

	render() {
		const { columnDefs, loading, rowData, apiCallCount, pageProps, dealHeaderListArray } = this.props;
		const { classes } = this.props
		const { valueArray } = this.state
		return (<DialogComponent
			isOpen={this.props.applyChangestoItems}
			dialogTitle={this.getLabelValue(LABEL_APPLY_CHANGES_TO_ITEMS)}
			cancelText={TEXT_CANCEL}
			submitText={TEXT_OK}
			handleClose={e => this.handleClose()}
			handleCancel={e => this.handleClose()}
			handleSubmit={() => this.handleSubmit()}
			disableSubmit={(this.getSelectedRowsForAPI() && this.getSelectedRowsForAPI().length) ? false : true}>
			<React.Fragment>
				{!loading && columnDefs && columnDefs.length && rowData && rowData.length ?
					<EmbeddedList
						embeddedListTitle={this.getLabelValue(SELECT_WAREHOUSES)}
						pageProps={pageProps}
						columnInfo={this.props.columnInfo}
						selectAllFlag={this.state.selectAllFlag}
						updateSelectAllFlag={this.updateSelectAllFlag}
						selectedRecordsObject={this.state.selectedRecordsObject}
						hasSelectDeselectAll={true}
						changeValuesOnSelectDeselect={this.changeValuesOnSelectDeselect}
						updateMenuItems={() => { }}
						suppressRowClickSelection={true}
						onRowSelected={this.onRowSelected}
						currentPage={APPLY_CHANGES_TO_ITEMS}
						listPredecessor={getListPredecessor("warehouses")}
						rowSelection={this.state.rowSelection}
						suppressSizeToFit={true}
						nameSpace={APPLY_CHANGES_TO_ITEMS}
						onGridReady={this.onGridReady}
						props={this.props}
						listProps={this.props}
						rowData={rowData.filter(row => dealHeaderListArray.find(deal => deal.DHWHSE === row.WWHSE))}
						updateShowHide={(data, currentPage) => this.props.updateShowHide(data, currentPage)}
						menuItems={this.state.menuItems}
						onSelectAll={(data) => this.onSelectAll(data)}
						columnDefs={columnDefs}
						gridHeight={'280px'}
						totalCount={apiCallCount * 100 + (rowData.filter(row => dealHeaderListArray.find(deal => deal.DHWHSE === row.WWHSE)).length)}
						resetDefault={(data) => this.props.resetDefault(data)}
						hasPagination={true}
						hasGridActions={true}>
					</EmbeddedList> : <Spinner loading type="list" />}
				<Box className={classes.adjustUpdateHeader}>
					<FieldInput field={{ type: 'checkbox', key: 'updateHeader' }} value={Number(valueArray["updateHeader"])}
						onChange={(key, val) => this.handleChangeValue(key, val)} />
					<div className={classes.updateHeader}>{this.getLabelValue(UPDATE_HEADERS)}</div>
				</Box>
				{this.state.showValueConfirmationDialog && <ConfirmationDialog
					hasError={true}
					isOpen={this.state.showValueConfirmationDialog}
					dialogTitle={TEXT_ALERT}
					submitText={TEXT_OK}
					handleClose={e => this.closeValueDialog()}
					handleCancel={e => this.closeValueDialog()}
					handleSubmit={e => this.closeValueDialog()}
				>
					<div>
						{this.state.dialogContent}
					</div>
				</ConfirmationDialog>}
			</React.Fragment>
		</DialogComponent>)
	}
}
const mapStateToProps = createStructuredSelector({
	applyChangestoItemsPage: makeSelectApplyChangestoItems(),
	rowData: rowDataSelector(),
	columnDefs: columnDefsSelector(),
	loading: loadingSelector(),
	pageProps: pagePropsSelector(),
	isColumnDefsLoaded: columnFlagSelector(),
	filterProps: filterPropsSelector(),
	columnInfo: columnInfoSelector(),
	isAPIProgress: isAPIProgressSelector(),
	totalCount: totalCountSelector(),
	moreRecordsAvailable: moreRecordsSelector(),
	apiCallCount: apiCallCountSelector(),
	updateColumnsList: updateColumnsListSelector(),
	errorMessages: errorMessageLabels(),
	dealHeaderListArray: dealsListSelector(),
})

function mapDispatchToProps(dispatch, ownProps) {
	return {
		dispatch,
		getApplyChangestoItemsList: (data) => dispatch(getApplyChangestoItemsList(ownProps.nameSpace, data)),
		setApiCallCount: (data) => dispatch(setApiCallCount(ownProps.nameSpace, data)),
		onSetPageProps: (data) => dispatch(onSetPageProps(ownProps.namespace, data)),
		getApplyChangestoItemsColumnDefs: (data) => dispatch(getApplyChangestoItemsColumnDefs(ownProps.nameSpace, data)),
		setFilterValues: (data) => dispatch(setFilterValues(ownProps.nameSpace, data)),
		setColumnDefsLoaded: (data) => dispatch(setColumnDefsLoaded(ownProps.nameSpace, data)),
		updateShowHide: (data) => dispatch(updateShowHide(ownProps.nameSpace, data)),
		resetStateData: (data) => dispatch(resetStateData(ownProps.nameSpace, data)),
		resetDefault: (data) => dispatch(resetDefault(data)),
		getDealHeaderList: (data) => dispatch(getDealHeaderList(ownProps.nameSpace, data)),
		setLabelDataFlags: (data) => dispatch(setLabelDataFlags(ownProps.nameSpace, data)),
	}
}
const withConnect = connect(
	mapStateToProps,
	mapDispatchToProps,
);
const withReducer = injectReducer({ key: 'applyChangestoItemsReducer', reducer });
const withSaga = injectSaga({ key: 'applyChangestoItemsSaga', saga });

export default compose(
	withReducer,
	withSaga,
	withConnect,
	withStyles(styles),
)(ApplyChangestoItems);
import PropTypes from 'prop-types';
import { Component } from 'react';

const defaultProps = {
  activeIndex: 0,
};

const propTypes = {
  activeIndex: PropTypes.number,
  children: PropTypes.func.isRequired,
};

class Tabs extends Component {
  constructor(props) {
    super(props);
    const index = props.activeIndex || 0;
    this.onChange = this.onChange.bind(this);
    this.state = {
      activeIndex: index,
    };
  }

  componentDidUpdate(prevProps) {
    if (this.props.activeIndex !== prevProps.activeIndex) {
      this.onChange(this.props.activeIndex);
    }
  }

  onChange(activeIndex) {
    this.setState({ activeIndex });
  }

  render() {
    const { children } = this.props;
    const { activeIndex } = this.state;
    return children({ activeIndex, onChange: this.onChange });
  }
}

Tabs.defaultProps = defaultProps;
Tabs.propTypes = propTypes;

export default Tabs;

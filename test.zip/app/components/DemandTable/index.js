/**
 *
 * DemandTable
 *
 */

import React, { useState, useEffect } from 'react';
// import PropTypes from 'prop-types';
// import styled from 'styled-components';

import { FormattedMessage } from 'react-intl';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';
import { get } from 'https';
import PaginationGrid from '../PaginationGrid';
import {
    COLUMN_VALUE_ACCESSOR,
    COLUMN_HEADER_ACCESSOR,
    COLUMN_SHOW_HIDE_FLAG,
    COLUMN_HEADER_PREFIX_FLAG
} from 'components/common/constants';
import {
    DEMAND_TABLE
} from './constants';
import {
    getListPredecessor
} from 'utils/util';
import CustomGrid from 'components/CustomGrid';

class DemandTable extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            showFocusCell: false,
            focusCellValue: '',
            rowValue: false
        }
        this.onRowSelected = this.onRowSelected.bind(this);
        this.cellFocused = this.cellFocused.bind(this);
    }

    componentDidMount() {
        this.setState({ showFocusCell: false });
        this.props.setColumnData();
        this.props.setRowData();
    }

    onGridReady = () => {

    }

    onRowSelected(e) {
        const { columnDefs, rowData } = this.props.demandTableData;
        if (e && e.data && e.data.year && e.node.selected) {
            this.setState({ rowValue: 'ignore ' + e.data.year })
        }
    }

    cellFocused(e) {
        const { columnDefs, rowData } = this.props.demandTableData;
        if (rowData && rowData.length && e.column && e.column.colId && e.column.colId != 'year') {
            this.setState({ showFocusCell: true });
            let value1 = rowData[e.rowIndex]['year'];
            let value2 = rowData[e.rowIndex][e.column.colId];
            let finalValue = 'ignore ' + e.column.colDef[COLUMN_HEADER_ACCESSOR] + '/' + value1;
            this.setState({ focusCellValue: finalValue });
        } else {
            this.setState({ focusCellValue: '' });
            this.setState({ showFocusCell: false })
        }
    }

    render() {
        const { columnDefs, rowData } = this.props.demandTableData;
        return (
            <div>
                <div class="ignore-cell-values">
                    {
                        this.state.rowValue && this.state.rowValue.length &&
                        <div class="ignore-cell-value">
                            {this.state.rowValue}
                        </div>
                    }
                    {
                        this.state.showFocusCell ? <div>
                            {this.state.focusCellValue}
                        </div> : ''
                    }
                </div>

                {
                    columnDefs && columnDefs.length && rowData && rowData.length &&
                    <div>
                        <CustomGrid
                            hasNoFocusClass={true}
                            focusClass={'ag-grid-focus'}
                            onCellFocused={(e) => this.cellFocused(e)}
                            rowSelection={'single'}
                            headerHeight={45}
                            height={'calc(100vh - 200px)'}
                            props={this.props}
                            listPredecessor={getListPredecessor(DEMAND_TABLE)}
                            columnKey={COLUMN_VALUE_ACCESSOR}
                            titleKey={COLUMN_HEADER_ACCESSOR}
                            columnShowFlag={COLUMN_SHOW_HIDE_FLAG}
                            prefixFlag={COLUMN_HEADER_PREFIX_FLAG}
                            columnData={columnDefs}
                            totalCount={4}
                            onGridReady={this.onGridReady}
                            rowData={rowData}
                            onRowSelected={(e) => this.onRowSelected(e)}
                            isColumnResize={true} />
                    </div>
                }
            </div>
        )
    }
}

DemandTable.propTypes = {

};

export default DemandTable;
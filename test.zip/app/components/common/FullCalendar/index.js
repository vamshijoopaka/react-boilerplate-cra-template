import React from 'react';
import PropTypes from 'prop-types';
import FullCalendar from '@fullcalendar/react';

import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import interactionPlugin from '@fullcalendar/interaction'; // needed for dayClick

import './style.scss';
// must manually import the stylesheets for each plugin
import '@fullcalendar/core/main.css';
import '@fullcalendar/daygrid/main.css';
import '@fullcalendar/timegrid/main.css';

const propTypes = {
    defaultDate: PropTypes.any,
    onFullCalendarReady: PropTypes.func,
    clickOnOutsideCalendar: PropTypes.func,
    selectedDateCellArea: PropTypes.func,
    calendarEvents: PropTypes.array,
    dayRender: PropTypes.any,
    dateClick: PropTypes.any
};

class FullCalendars extends React.Component {
    calendarComponentRef = React.createRef();

    constructor(props) {
        super(props);
        this.state = {}
    }

    componentDidMount() {
        document.addEventListener('mousedown', this.handleClickOutside);
        this.props.onFullCalendarReady(this.calendarComponentRef.current);
    }

    componentWillUnmount() {
        document.removeEventListener('mousedown', this.handleClickOutside);
    }

    handleClickOutside = (event) => {
      if (this.calendarComponentRef.current)
        if ((!event.target.classList.contains('MuiIconButton-root') && !event.target.classList.contains('MuiSvgIcon-root'))
          && !this.calendarComponentRef.current.elRef.current.contains(event.target)) {
          this.props.clickOnOutsideCalendar(true);
        }
    }

    //This is used to color the font for cell value for past date & current/future date
    eventDataTransform = (eventData) => {
        let newDate = new Date();
        if(this.props.canUpdateComponent) {
            if(!this.props.canUpdateComponent.update)
                eventData.textColor = "var(--primary-disabled)";
        }
        else {
            if (new Date(newDate.setHours(0, 0, 0, 0)).getTime() > eventData.start.getTime()) {
                eventData.textColor = "var(--primary-disabled)";
            } else {
                eventData.textColor = "var(--primary-default)";
            }
        }
        return eventData;
    }

    render() {
        return (
            <FullCalendar
                defaultView="dayGridMonth"
                showNonCurrentDates={false}
                plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin]}
                selectable={true}
                ref={this.calendarComponentRef}
                firstDay={0}
                aspectRatio={2}
                selectable={true}
                defaultDate={this.props.defaultDate}
                select={e => this.props.selectedDateCellArea(e)}
                eventBackgroundColor='transparent'
                eventBorderColor='transparent'
                events={this.props.calendarEvents}
                eventDataTransform={this.eventDataTransform}
                dayRender={this.props.dayRender}
                dateClick={this.props.dateClick}>
                    
            </FullCalendar>
        )
    }
}

FullCalendar.propTypes = propTypes;

export default FullCalendars;
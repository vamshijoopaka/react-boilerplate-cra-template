/*
 * EventitemProperties Messages
 *
 * This contains all the text for the EventitemProperties component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.EventitemProperties';

export default defineMessages({
    header: {
        id: `${scope}.header`,
        defaultMessage: 'This is the EventitemProperties component!',
    },
});


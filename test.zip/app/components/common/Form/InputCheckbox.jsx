
/*
* * //==========================================================================
*
* * // Copyright 2021-2021, Blue Yonder Group, Inc.
*
* * // All Rights Reserved
*
* * //
*
* * // THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF
*
* * // BLUE YONDER GROUP, INC.
*
* * //
*
* * //
*
* * // The copyright notice above does not evidence any actual
*
* * // or intended publication of such source code.
*
* * //
*
* * // ===========================================================================
*/
import PropTypes from 'prop-types';
import React, { Component } from 'react';
import Checkbox from '@material-ui/core/Checkbox';

const defaultProps = {
  className: '',
  value: false,
};

const propTypes = {
  className: PropTypes.string,
  field: PropTypes.shape({}).isRequired,
  onChange: PropTypes.func.isRequired,
  value: PropTypes.any,
  enableAddButton: PropTypes.any
};

class FieldInputCheckbox extends Component {
  constructor() {
    super();
    this.onChange = this.onChange.bind(this);
  }

  onChange(e) {
    const { checked } = e.currentTarget;
    const { field, onChange, enableAddButton } = this.props;
    const { key } = field;
    let value;
    if (checked) {
      value = "1";
    } else {
      value = '0';
    }
    onChange(key, value);
    if (enableAddButton) {
      enableAddButton(true);
    }
  }

  render() {
    const { className, field, value, color, disabled } = this.props;
    const { key } = field;

    return (
      <Checkbox
        className={className}
        checked={Boolean(Number(value))}
        id={key}
        disabled={disabled}
        onChange={this.onChange}
        // onKeyPress={(e) => this.props.onKeyPress(e)}
        color={color || "primary"}
      />
    );
  }
}

FieldInputCheckbox.defaultProps = defaultProps;
FieldInputCheckbox.propTypes = propTypes;

export default FieldInputCheckbox;

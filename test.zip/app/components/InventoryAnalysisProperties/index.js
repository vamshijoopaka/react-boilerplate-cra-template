/*** ChangeLog
*LogStart - 2021.1.0.2 AWR
    E3C-33266 - SRK 16-Nov-2021 : AWR WEB UI graphs have hardcoded English labels
                                  Removed hardcoding and retrieved label based on ID.
                                  reducer uses INVENTORY_ANALYSIS_PURCHASE_SUMMARY_BY_MONTH_COLUMNS defined in 
                                  containers constants.js which has hardcoded labels to build embeddedList.columnDefs
                                  So, here softcoding those labels.
***/

import React from 'react';
import PropTypes from 'prop-types';
import { getFilterDataFromLocalStorage, getUpdateRestrictionOnComponent, capitalizeFirstLetter } from 'utils/util';
import { getDBSelectorFilterValues } from 'utils/filterdata';
import { Grid, withStyles } from '@material-ui/core';
import Spinner from 'components/common/Spinner';
import CardComponent from 'components/common/CardComponent';
import {
  HeaderAPIValuesJSON,
  LABEL_LIST_URL_DATA,
  DEFAULT_VALUE_URL_DATA,
} from './constants';
import {
  COLUMN_VALUE_ACCESSOR,
  GLOBAL_FILTER_OPTIONS,
  INITIAL_PAGE_PROPS,
  TEXT_ALERT,
  TEXT_OK,
  INVENTORY_ANALYSIS_PROPERTIES,
} from '../common/constants';
import Header from './Header';
import PurchaseSummaryByMonthChart from './PurchaseSummaryByMonthChart';
import { getListPredecessor, prepareValueDataForItems } from '../../utils/util';
import { isEqual } from 'lodash';
import PurchaseSummaryByMonthEmbeddedList from './PurchaseSummaryByMonthEmbeddedList';
import Filter from '../../containers/common/Filter';
import { onChangeContextMenu } from '../../utils/contextMenu';
import FormattedMessageComponent from '../common/FormattedMessageComponent';
import ConfirmationDialog from '../common/ConfirmationDialog';

const style = () => ({
  propertiesContentWrapper: {
    margin: '10px auto',
    fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
    borderRadius: '4px',
    overflow: 'hidden',
    padding: 20,
    boxShadow: '0 2px 4px var(--secondary-s10)',
    backgroundColor: 'var(--background-app)',
  },
  card: {
    padding: '0px 0px 30% 0px',
    backgroundColor: 'var(--background-content)',
    borderRadius: '4px',
    margin: '10px',
    height: '100%',
    '& .MuiCardHeader-root': {
      padding: '16px',
    },
    '& .MuiCardContent-root': {
      padding: '16px',
    },
  },
});

class InventoryAnalysisProperties extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      isFiltersChanged: false,
      openFilterPopup: false,
      canUpdateComponent: false,
      isInitialAPICall: true,
    };
  }

  componentDidMount = () => {
    const {
      location,
      onLoadCurrentPage,
      setIsShowContextMenu,
      setCurrentRecord,
    } = this.props;
    if (onLoadCurrentPage) {
      onLoadCurrentPage(INVENTORY_ANALYSIS_PROPERTIES);
    }
    if (setIsShowContextMenu) {
      setIsShowContextMenu(true);
    }
    const isFound = this.setRecordDataValues();
    if (!isFound) {
      if (location && location.state) {
        const { data, columnDefs } = location.state;
        setCurrentRecord(data);
        this.setState({
          columnDefs,
          itemDataJson: columnDefs,
        });
      }
    }
    if (this.props.inventoryAnalysisPropertiesPage.currentRecordData) {
      this.sendAPICallForValues();
      this.props.setSelectedRecord(
        this.props.inventoryAnalysisPropertiesPage.currentRecordData,
        'inventoryAnalysis',
      );
    }
    let canUpdateComponent = getUpdateRestrictionOnComponent(capitalizeFirstLetter(INVENTORY_ANALYSIS_PROPERTIES), this.props.authorizedComponentsList);
    this.setState({ canUpdateComponent: {...canUpdateComponent} });

  };

  componentDidUpdate = prevProps => {
    const { inventoryAnalysisPropertiesPage } = this.props;
    const { currentRecordData, filterProps, hasNoPrevNext, prevNextApiSuccess, isValueDataAPICall } = inventoryAnalysisPropertiesPage;
    if (
      currentRecordData &&
      !isEqual(
        currentRecordData,
        prevProps.inventoryAnalysisPropertiesPage.currentRecordData,
      )
    ) {
      this.sendAPICallForValues();
      this.props.setSelectedRecord(currentRecordData, 'inventoryAnalysis');
      this.setState({ previousFilterValues: prevProps.inventoryAnalysisPropertiesPage.filterProps || this.props.inventoryAnalysisPropertiesPage.filterProps})
    }

    if (
      filterProps &&
      !this.state.isInitialAPICall &&
      !isEqual(
        filterProps,
        prevProps.inventoryAnalysisPropertiesPage.filterProps,
      )
    ) {
      this.sendAPICallForValues();
      this.makeUpDownCall({});
      this.setState({ isFiltersChanged: true });
      this.props.setChildTabFilterProps(filterProps);
    }
    if (isValueDataAPICall && (prevProps.inventoryAnalysisPropertiesPage.isValueDataAPICall !== isValueDataAPICall)) {
      this.setState({ previousFilterValues: prevProps.inventoryAnalysisPropertiesPage.filterProps || this.props.inventoryAnalysisPropertiesPage.filterProps})
      this.setState({ isInitialAPICall: false });
      if (this.state.isFiltersChanged) {
        this.setState({ openFilterPopup: false });
        this.setState({ isFiltersChanged: false });
      }
    }
    if (hasNoPrevNext && (prevProps.inventoryAnalysisPropertiesPage.hasNoPrevNext !== hasNoPrevNext)) {
      if (this.state.isFiltersChanged) {
        this.openNoDataPopUp(true)
      }
    }
    if (prevNextApiSuccess && (prevProps.inventoryAnalysisPropertiesPage.prevNextApiSuccess !== prevNextApiSuccess)) {
      this.setState({ openFilterPopup: false });
      this.setState({ isFiltersChanged: false });
    }
    if (this.props.location.search != prevProps.location.search) {
      this.props.setInitialState();
      this.setRecordDataValues();
      this.setState({ isInitialAPICall: true });
    }
  };
  componentWillUnmount() {
    this.props.setInitialState();
  }
  makeUpDownCall = (recordData) => {
    const { filterProps, sortProps } = this.props.inventoryAnalysisPropertiesPage;
    const data = { ...INITIAL_PAGE_PROPS };
    data.isForwardDirection = true;
    data.pageSize = 3;
    const postObject = this.getApiObjForPageUpDown(
      filterProps,
      recordData,
      'inventoryAnalysis',
      data,
      sortProps,
      true,
      false,
    );
    this.props.pageUpDownAPI(postObject);
  }
  getApiObjForPageUpDown = (
    filterData,
    record,
    currentPage,
    pageProps,
    sortData,
    pageType,
    flagsOnly,
  ) => {
    let recordObj = false;
    if (record) {
      recordObj = record;
      if (flagsOnly) {
        recordObj = {
          record,
          flagsOnly: true,
        };
      }
    }
    const apiObj = {
      sortProps: sortData,
      filterProps: filterData.filter(filter => filter.accessor !== 'BTOTL'),
      pageProps,
      direction: pageProps.isForwardDirection,
      record: recordObj,
      currentPage,
      parentPage: 'inventoryAnalysis',
      pageType,
    };
    return apiObj;
  };
  getApiObj = () => {
    const { currentRecordData } = this.props.inventoryAnalysisPropertiesPage;
    const filterProps = [
      {
        accessor: 'PSCOMP',
        fieldValue: currentRecordData.VCOMP||currentRecordData.PSCOMP,
        operator: '=',
        prefixFlag: false,
      },
      {
        accessor: 'PSVNDR',
        fieldValue: currentRecordData.VVNDR||currentRecordData.PSVNDR,
        operator: '=',
        prefixFlag: false,
      },
      {
        accessor: 'PSWHSE',
        fieldValue: currentRecordData.VWHSE||currentRecordData.PSWHSE,
        operator: '=',
        prefixFlag: false,
      },

    ];
    const apiObj = {
      currentPage: INVENTORY_ANALYSIS_PROPERTIES,
      direction: true,
      exportFields: null,
      exportFilterProps: null,
      filterProps,
      pageProps: INITIAL_PAGE_PROPS,
      record: {},
      searchReplaceValues: null,
      showHideColumns: null,
      sortProps: null,
    };
    return apiObj;
  };

  setRecordDataValues = () => {
    let isRecordValuesExists = false;
    let isLocalStorageValuesExists = false;
    let isFilterValuesExists = false;
    const { history } = this.props;
    const paramsString = window.location.search;
    if (paramsString && paramsString.length) {
      const paramsArray = paramsString.split('?');
      if (paramsArray && paramsArray.length && paramsArray.length > 1) {
        const params = paramsArray[1].split('&');
        const tabId = params[0].split('=')[1];
        const breadCrumbId = params[1].split('=')[1];
        const localStorageValues = getFilterDataFromLocalStorage(
          tabId,
          breadCrumbId,
        );
        const keys = localStorageValues ? Object.keys(localStorageValues) : [];
        if (localStorageValues && keys.length) {
          isLocalStorageValuesExists = true;
          const recordData = localStorageValues.item_data;
          let dbSelector = [];
          if (recordData && recordData.recordData) {
            this.columnDefData = { ...recordData.recordData.columnDefs };
            this.props.setCurrentRecord(recordData.recordData.data);
            const {
              columnDefs,
              data,
              totalCount,
              fromPage,
            } = recordData.recordData;
            this.setState({
              columnDefs,
              totalCount,
              fromPage,
              formListPage: fromPage,
            });
            isRecordValuesExists = true;
            this.props.setSelectedRecord(false, false);
            if (recordData) {
              if (recordData.dbSelector && recordData.dbSelector.length) {
                dbSelector = [...recordData.dbSelector];
              }
              if (recordData.filterProps && recordData.filterProps.length) {
                this.setState({ hasFilterChanged: false });
                isFilterValuesExists = true;
                const values = getDBSelectorFilterValues(
                  dbSelector,
                  recordData.filterProps,
                );
                this.setFilterValuesFromState(values);
              } else if (dbSelector && dbSelector.length) {
                this.setState({ hasFilterChanged: false });
                isFilterValuesExists = true;
                const dbValues = getDBSelectorFilterValues(dbSelector, []);
                this.setFilterValuesFromState(dbValues);
              }
              if (recordData.sortProps) {
                this.setState({ hasSortChanged: false });
                this.props.sendPageSortProps(recordData.sortProps);
                this.props.onSetSortProps(recordData.sortProps);
              }
              if (
                recordData.defaultFilterProps &&
                Object.keys(recordData.defaultFilterProps) &&
                Object.keys(recordData.defaultFilterProps).length
              ) {
                this.props.setDefaultFilterpropsForTabs(
                  recordData.defaultFilterProps,
                );
              }
              if (
                recordData.defaultSortProps &&
                Object.keys(recordData.defaultSortProps) &&
                Object.keys(recordData.defaultSortProps).length
              ) {
                this.props.setDefaultSortpropsForTabs(
                  recordData.defaultSortProps,
                );
              }
            }
          }
        }
        if (!isLocalStorageValuesExists && tabId && breadCrumbId) {
          history.push({ pathname: '/Dashboard' });
        }
      }
    }
    const filterOptions = [...GLOBAL_FILTER_OPTIONS];
    const { dbSelector } = this.props;
    if (!isFilterValuesExists) {
      const gbValues = getDBSelectorFilterValues(dbSelector, filterOptions);
      this.setFilterValuesFromState(gbValues);
    }
    return isRecordValuesExists;
  };

  setFilterValuesFromState = values => {
    const filterValues = [];
    const { columnDefs } = this.state;
    if (
      (columnDefs && columnDefs.length) ||
      (this.columnDefData && this.columnDefData.length)
    ) {
      const colData =
        columnDefs && columnDefs.length ? columnDefs : this.columnDefData;
      values.forEach(value => {
        const isExists = colData.find(
          column => column[COLUMN_VALUE_ACCESSOR].trim() === value.accessor,
        );
        if (isExists) {
          filterValues.push(value);
        }
      });
      if (filterValues && filterValues.length) {
        const filters = this.addInventoryAnalysisFilterIfNotPresent(filterValues);
        this.props.onSetFilterProps(filters);
        this.props.setGlobalFilterProps(filters);
        return filterValues;
      }
    } else {
      const filters = this.addInventoryAnalysisFilterIfNotPresent(values);
      this.props.onSetFilterProps(filters);
      this.props.setGlobalFilterProps(filters);
      return values;
    }
    return filterValues;
  };

  setHeaderAndSendAPI = jsonData => {
    const data = this.prepareHeaderDataJSON(jsonData);
    this.setState({ stateData: jsonData, headerData: data });
  };

  prepareHeaderDataJSON = obj => {
    const headerValues = { ...HeaderAPIValuesJSON };
    const prefix = 'PS';
    const keys = Object.keys(headerValues);
    keys.forEach(key => {
      headerValues[key] = obj[prefix + key] ? obj[prefix + key].trim() : '';
    });

    return headerValues;
  };

  sendAPICallForValues = () => {
    const {
      loadInventoryDetails,
      inventoryAnalysisPropertiesPage,
    } = this.props;
    const { currentRecordData } = inventoryAnalysisPropertiesPage;
    loadInventoryDetails(this.getApiObj(), currentRecordData.VWHSE||currentRecordData.PSWHSE);
  };

  handleItemHeaderFilterClick = () => {
    if (
      this.state.isFiltersChanged &&
      this.props.inventoryAnalysisPropertiesPage.hasNoPrevNext
    ) {
      this.props.onSetFilterProps(this.addInventoryAnalysisFilterIfNotPresent(this.state.previousFilterValues || this.props.inventoryAnalysisPropertiesPage.filterProps));
      this.props.setGlobalFilterProps(this.state.previousFilterValues);
      this.props.setChildTabFilterProps(this.state.previousFilterValues);
      this.setState({ isFiltersChanged: false });
    }
    this.setState(prevState => {
      const { openFilterPopup } = prevState;
      return {
        openFilterPopup: !openFilterPopup,
        noRecordForFilter: false,
      };
    });
  };


  addInventoryAnalysisFilterIfNotPresent = list => {
    let found = false;
    list = list.map(i => {
      if (i.accessor === "IAFLTR") {
        found = true;
        i.prefixFlag = 1;
      }
      return i;
    });
    if (!found) list.push(
      { accessor: "IAFLTR", fieldValue: "1", operator: "=", prefixFlag: 1 }
    );
    return list;
  }

  openNoDataPopUp = (val) => {
    this.setState({ showConfirmationDialog: val });
    this.setState({ hasWarning: val });
    this.setState({ dialogTitle: val ? TEXT_ALERT : '' });
    this.setState({ fromHeaderENG: val });
    this.setState({ dialogBody: val ? 'E28648' : '' });
    this.setState({ noRecordForFilter: true })
  }
  handleClose = bodyId => {
    this.setState({ showConfirmationDialog: false });
  }
  render() {
    const {
      inventoryAnalysisPropertiesPage,
      pageUpDownAPI,
    } = this.props;
    const {
      loading,
      currentRecordData,
      graphData,
      embeddedList,
      hasNext,
      hasPrevious,
    } = inventoryAnalysisPropertiesPage;

    embeddedList.columnDefs = embeddedList.columnDefs.map(field => {                                                          /* E3C-33266 */
      switch (field["TLLAB"]) {                                                                                               /* E3C-33266 */
        case 'Year': field["TLLAB"] = JSON.parse(localStorage["messageLabels"])["H39806"]["TLLAB"]; break;                    /* E3C-33266 */
        case 'Month': field["TLLAB"] = JSON.parse(localStorage["messageLabels"])["H51061"]["TLLAB"]; break;                   /* E3C-33266 */
        case 'Regular Purchases': field["TLLAB"] = JSON.parse(localStorage["messageLabels"])["H35263"]["TLLAB"]; break;       /* E3C-33266 */
        case 'Promotional Purchases': field["TLLAB"] = JSON.parse(localStorage["messageLabels"])["H35264"]["TLLAB"]; break;   /* E3C-33266 */
        case 'Forward Buy Purchases': field["TLLAB"] = JSON.parse(localStorage["messageLabels"])["H35265"]["TLLAB"]; break;   /* E3C-33266 */
        case 'Inner Margin': field["TLLAB"] = JSON.parse(localStorage["messageLabels"])["H35266"]["TLLAB"]; break;            /* E3C-33266 */
        case 'Projected to Actual %': field["TLLAB"] = JSON.parse(localStorage["messageLabels"])["H36840"]["TLLAB"]; break;   /* E3C-33266 */
      }                                                                                                                       /* E3C-33266 */
      return field;                                                                                                           /* E3C-33266 */      
    });  
    
    const { classes, ...otherThanClasses } = this.props;
    return (
      <div>
        {currentRecordData ? (
          <>
            <Header
              currentRecordData={currentRecordData}
              {...otherThanClasses}
              pageUpDownAPI={pageUpDownAPI}
              handleItemHeaderFilterClick={this.handleItemHeaderFilterClick}
              hasNext={hasNext}
              hasPrevious={hasPrevious}
              companyDetails ={this.props.companyDetails}
              canUpdateComponent = {this.state.canUpdateComponent}
              getApiObjForPageUpDown={this.getApiObjForPageUpDown}
            />
            <div className={classes.propertiesContentWrapper}>
              <Grid container>
                <Grid item xs={12} sm={12} md={12} lg={6} xl={6}>
                  <CardComponent className={classes.card}>
                    <PurchaseSummaryByMonthChart
                      series={graphData ? graphData.series : []}
                      categories={graphData ? graphData.categories : []}
                    />
                  </CardComponent>
                </Grid>
                <Grid item xs={12} sm={12} md={12} lg={6} xl={6}>
                  <CardComponent className={classes.card}>
                    <PurchaseSummaryByMonthEmbeddedList {...embeddedList} />
                  </CardComponent>
                </Grid>
              </Grid>
            </div>
            <Spinner loading={loading} type="list" />
          </>
        ) : (
          <Spinner loading type="list" />
        )}
        {this.state.openFilterPopup && (
          <Filter
            filterCriteriaDetails={this.props.filterCriteriaDetails}
            pageFilterOptions={this.props.pageFilterOptions}
            globalFilterOptions={this.props.globalFilterOptions}
            globalSecurityFilterList={this.props.globalSecurityFilterList}
            currentPage={INVENTORY_ANALYSIS_PROPERTIES}
            isOpen={Boolean(this.state.openFilterPopup)}
            ownerName={this.props.currentOwnerName}
            columnDefs={this.props.inventoryAnalysisPropertiesPage.columnDefs}
            clearPopupComponent={this.handleItemHeaderFilterClick}
            hasRecordsForFilter={!this.state.noRecordForFilter}
            showNoDataPopUp={(val) => this.openNoDataPopUp(val)}
          />
        )}
        {this.state.showConfirmationDialog && <ConfirmationDialog
          hasError={this.state.hasWarning}
          isOpen={this.state.showConfirmationDialog}
          dialogTitle={this.state.dialogTitle}
          submitText={TEXT_OK}
          handleClose={e => this.handleClose(false)}
          handleCancel={e => this.handleClose(false)}
          handleSubmit={e => this.handleClose(this.state.dialogBody)}
        >
          <div>
            {this.state.fromHeaderENG && <FormattedMessageComponent id="28648" />}
          </div>
        </ConfirmationDialog>
        }
      </div>
    );
  }
}

InventoryAnalysisProperties.propTypes = {
  inventoryAnalysisPropertiesPage: PropTypes.object,
  loadInventoryDetails: PropTypes.func,
  onLoadCurrentPage: PropTypes.func,
  history: PropTypes.object,
  setCurrentRecord: PropTypes.func,
  setSelectedRecord: PropTypes.func,
  sendPageSortProps: PropTypes.func,
  onSetSortProps: PropTypes.func,
  setDefaultFilterpropsForTabs: PropTypes.func,
  setDefaultSortpropsForTabs: PropTypes.func,
  dbSelector: PropTypes.func,
  setIsShowContextMenu: PropTypes.func,
  location: PropTypes.object,
  pageUpDownAPI: PropTypes.func,
  onSetFilterProps: PropTypes.func,
  setGlobalFilterProps: PropTypes.func,
  setChildTabFilterProps: PropTypes.func,
  classes: PropTypes.object,
  filterCriteriaDetails: PropTypes.array,
  pageFilterOptions: PropTypes.array,
  globalFilterOptions: PropTypes.array,
  globalSecurityFilterList: PropTypes.array,
  currentOwnerName: PropTypes.string,
};

export default withStyles(style)(InventoryAnalysisProperties);

import { withStyles } from '@material-ui/core/styles';
import { COLUMN_FIELD_TYPE, COLUMN_VALUE_ACCESSOR, DROPDOWN_FIELD, ITEMS_LIST_PAGE } from 'components/common/constants';
import PropTypes from 'prop-types';
import React from 'react';
import { getListPredecessor, getSortableColumns, setNumberFields } from '../../../utils/util';
import CardComponent from '../../common/CardComponent';
import FormFieldsGenerator from '../../common/FormFieldsGenerator';
import Spinner from '../../common/Spinner';
import './style.scss';
import { Box, Grid } from '@material-ui/core';
import { DEFAULT_VALUE_URL_DATA } from './constants.js';
import { prepareValueDataForItems } from 'utils/util';

import { MuiThemeProvider, createMuiTheme } from '@material-ui/core/styles';
import theme from '../../../jda-gcp-theme';
import ForecastTable from './ForecastTable';
import ForecastGraph from './ForecastGraph';
import { getDateFormatted } from '../../common/Form/dateTimeUtils';
const themes = createMuiTheme(theme);
themes.overrides = {
  MuiCardHeader: {
    root: {
      padding: '0rem 0.5rem',
    }
  },
  MuiTableCell: {
    head: {
      color: 'black',
      paddingLeft: '12px',
      fontSize: '12px'
    },
    root: {
      padding: '5px',
    },
    body: {
      color: 'rgba(0, 0, 0, 0.87)',
      paddingLeft: '14px',
      fontSize: '12px',
      paddingRight: "14px",
      // minWidth: "158px"
    },
    alignLeft: {
      // borderRight:'1px solid black !important',
      // borderLeft:'1px solid black !important',
      // borderTop:'1px solid black !important',
      // borderBottom:'1px solid black !important',
      // minWidth: '158px'
    }
  },
  MuiPaper: {
    root: {
      backgroundColor: "#ffffff",
    }
  },
  MuiInputBase: {
    input: {
      fontSize: '12px'
    }
  }
}
const propTypes = {
  setSaveData: PropTypes.func,
  ItemPropertiesData: PropTypes.object.isRequired,
  getApiObj: PropTypes.func.isRequired,
  getLabelValue: PropTypes.func.isRequired,
  loadItemHistDemRecDetails: PropTypes.func.isRequired,
};

const style = (theme) => ({
   pageContainer: {
    // display: 'flex',
    backgroundColor: 'var(--background-app)',
    borderTop: 'none',
    padding: '24px 20px',
  },
  pageContainerFifty: {
    width: '50%',
  },
  pageContainerThirty: {
    width: '30%',
    marginLeft: '20px',
  },
  cardWithborder: {
    border: '1px solid var(--secondary-s3)',
    borderRadius: '4px',
    padding: '10px',
    margin: '10px',
    width: '100%',
    backgroundColor: 'var(--secondary-s5)',
  },
  card: {
    padding: '0px',
    backgroundColor: 'var(--background-content)',
    borderRadius: '4px',
    width: '100%',
    '& .MuiCardHeader-root': {
      padding: '16px 10px'
    },
    '& .MuiCardContent-root': {
      padding: '16px 10px'
    }
  },
  cardName: {
    fontWeight: '500',
    margin: '10px 0 20px 5px',
  },
  simpleCardGroup: {
    width: '100%',
    justifyContent: 'space-around',
    overflow: "auto"
  },
  simpleCardGroup1: {
    paddingRight: '16px',
    width: '70%',
    display: 'flex',
    justifyContent: 'space-around',
  },
  simpleCardGroup2: {
    width: '30%',
    display: 'flex',
    justifyContent: 'space-around',
  },
  simpleCardGroup33: {
    paddingRight: '16px',
    width: '33%',
    display: 'flex',
    justifyContent: 'space-around',
  },
  simpleCardGroup333: {
    width: '34%',
    display: 'flex',
    justifyContent: 'space-around',
  },
  dashedBottomBorder: {
    borderBottom: '1px dashed var(--secondary-s21)',
    marginBottom: '20px',
  },
  marginLeftZero: {
    marginLeft: '0',
  },
  marginRightZero: {
    marginRight: '0',
  },
  unitDaysHeading: {
    display: 'grid',
    gridTemplateColumns: '50% 50%',
    gridGap: '2ch',
    padding: '0 1rem',
    '& #days': {
      paddingLeft: '120pt'
    },
  },
  tablecard: {
    padding: '0px',
    backgroundColor: 'var(--background-content)',
    borderRadius: '4px',
    width: '100%',
    margin: '10px',
    '& .MuiCardHeader-root': {
      padding: '8px 16px'
    },
    '& .MuiCardContent-root': {
      padding: '16px 32px'
    }
  },
  tableRow: {
    '&:nth-of-type(even)': {
      backgroundColor: 'var(--list-alternate-row)',
      color: 'var(--text) !important'
    }
  },
  tableWidth: {
    width: 'auto'
  },
  tableCellBorder: {
    border: '2px solid var(--list-divider-line)'
  },
  ignoreChecks: {
    display: "inline-block",
    position: "absolute",
    left: "36%",
    paddingTop: 5,
    [theme.breakpoints.down('sm')]: {
      left: '66%'
    }
  },
  cardHeight: {
    height: '96%'
  },
  floatTableParent: {
    position: 'absolute',
    top: '30%',
    width: '100%',
    marginLeft: '0.5rem'
  },
  floatTableChild: {
    width: '50%',
    float: 'right',
  },
  cardWrapperForFloatTable: {
    position: 'relative'
  },
  tableHead: {
    fontSize: "12px",
    color: 'black',
  },
  pageContainerSeventy: {
    width: "100%",
  },
  reforecastButton: {
    position: 'relative',
    top: '-1rem',
    left: '1%',
    marginBottom: '-1rem'
  },
  pageContainerNew: {
    display: 'flex',
    backgroundColor: 'var(--background-app)',
    borderTop: 'none',
    padding: '8px 0px',
  },
  notesForBlock: {
    display: 'flex',
    marginTop: '12px',
    border: '1px solid var(--divider-line)',
    padding: '15px 10px 10px 10px',
    position: 'relative',
    width:'100%'
  },
  notesForLabel: {
    position: 'absolute',
    top: '-7px',
    left: '10px',
    background: 'rgb(240,242,250)',
    padding: '0 8px',
    fontSize: '19px',
    fontWeight: 'bold',
    color:'var(--text)'
  },
  label: {
    fontSize: '14px',
    fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
    color: 'var(--text)',
    float: 'right',
    padding: '0.5rem',
  },
});

class ForecastHistory extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      fields: false,
      values: false,
      hasError: false,
      errorId: false,
      customCards: false,
      hasHardError: false,
      dates: false
    };
  }
  componentDidMount() {
    const { valueData } = this.props.ItemPropertiesData;
    const query = prepareValueDataForItems(DEFAULT_VALUE_URL_DATA, valueData);
    this.sendAPICallForValues(query, valueData);
   }
  componentDidUpdate(prevProps, prevState) {

    const { valueData, pageUpDownData } = this.props.ItemPropertiesData;
    const query = prepareValueDataForItems(DEFAULT_VALUE_URL_DATA, valueData);
    if (this.props.ItemPropertiesData.massSuccess != prevProps.ItemPropertiesData.massSuccess && this.props.tab == 4 ) {
      this.props.resetMassMaintenance()
      this.sendAPICallForValues(query, valueData);
    }
    if (pageUpDownData && JSON.stringify(pageUpDownData) != JSON.stringify(prevProps.ItemPropertiesData.pageUpDownData)) {
      this.sendAPICallForValues(query, valueData);
    }

  }

  componentDidCatch() {
    this.setState({ hasHardError: true })
  }
  handleChangeValue = (key, val) => {
    this.props.setValueData({ key, val });
  }
  sendAPICallForValues = (valueData, jsonData) => {
    const { pageProps } = this.props.ItemPropertiesData;
    this.props.loadItemHistDemRecDetails(this.getApiObj(valueData, null, 'itemProperties', pageProps));
    this.props.loadItemHistForRecDetails(this.getApiObj(valueData, null, 'itemProperties', pageProps));
    this.props.loadItemHistForFctDetails(this.getApiObj(valueData, null, 'itemProperties', pageProps));
    this.props.loadItemHistForOvrDetails(this.getApiObj(valueData, null, 'itemProperties', pageProps));
    this.props.loadCompanyForecastMatrixData('CCOMP=E3T');
  }

  getApiObj = (recordData, record = false, currentPage = ITEM_PROPERTIES, pageProps = false) => {
    let recordObj = false;
    if (record) {
      recordObj = record;
    }
    const apiObj = {
      recordData,
      pageProps,
      direction: pageProps.isForwardDirection,
      record: recordObj,
      currentPage,
      parentPage: ITEMS_LIST_PAGE,
    };
    return apiObj;
  }

  getValueData = (valueData, newValueData) => {
    if (Object.keys(valueData).length && Object.keys(newValueData).length &&
      (JSON.parse(JSON.stringify(valueData)) !== JSON.parse(JSON.stringify(newValueData)))) {
      return newValueData;
    }
    return valueData;
  }

  getRoundedNumbers = data => {
    if (data && Object.keys(data).length) {
      for (let key in data) {
        data[key] = isNaN(+data[key]) ? data[key] : (+data[key]).toString();
        if (['ILTFOR', 'ISSDYS'].includes(key)) {
          data[key] = Math.round(data[key])
        }
      }
    }
    return data;
  }

  getBaseForecast = (data, period) => {
    const { valueData } = this.props.ItemPropertiesData;
    let periodicty = parseInt(valueData["IPERDH"]);
    let values = { ...data };
    let dates = { ...period };
    let dateArray = [];
    if (periodicty == 12) {
      for (let i = 0; i < 12; i++) {
        if (dates[`MFPER${i + 1}`] !== '0') {
          dateArray.push(Number(values[`MFBF${i + 1}`]));
        }
      }
      return dateArray;
    } else if (periodicty == 52) {
      for (let i = 0; i < 52; i++) {
        if (dates[`FPER${i + 1}`] !== '0') {
          dateArray.push(Number(values[`FBF${i + 1}`]));
        }
      }
      return dateArray;
    } else if (periodicty == 13) {
      for (let i = 0; i < 13; i++) {
        if (dates[`PFPER${i + 1}`] !== '0') {
          dateArray.push(Number(values[`PFBF${i + 1}`]));
        }
      }
      return dateArray;
    }
  }

  getDateForGraph = (data) => {
    const { valueData } = this.props.ItemPropertiesData;
    let periodicty = parseInt(valueData["IPERDH"]);
    let values = { ...data };
    let dateArray = [];
    if (periodicty == 12) {
      for (let i = 0; i < 12; i++) {
        if (values[`MFPER${i + 1}`] !== '0') {
          dateArray.push(this.getDatefromHistData(values[`MFPER${i + 1}`]));
        }
      }
      return dateArray;
    } else if (periodicty == 52) {
      for (let i = 0; i < 52; i++) {
        if (values[`FPER${i + 1}`] !== '0') {
          dateArray.push(this.getDatefromHistData(values[`FPER${i + 1}`]));
        }
      }
      return dateArray;
    } else if (periodicty == 13) {
      for (let i = 0; i < 13; i++) {
        if (values[`PFPER${i + 1}`] !== '0') {
          dateArray.push(this.getDatefromHistData(values[`PFPER${i + 1}`]));
        }
      }
      return dateArray;
    }
  }
  getDemandFilterRange = (data, period) => {
    const { valueData } = this.props.ItemPropertiesData;
    let periodicty = parseInt(valueData["IPERDH"]);
    let values = { ...data };
    let dates = { ...period };
    let dateArray = [];
    if (periodicty == 12) {
      for (let i = 0; i < 12; i++) {
        if (dates[`MFPER${i + 1}`] !== '0') {
          dateArray.push([Number(values[`MFDFL${i + 1 <= 9 ? "0" + (i + 1) : (i + 1)}`]), Number(values[`MFDFH${i + 1 <= 9 ? "0" + (i + 1) : (i + 1)}`])]);
        }
      }
      return dateArray;
    } else if (periodicty == 52) {
      for (let i = 0; i < 52; i++) {
        if (dates[`FPER${i + 1}`] !== '0') {
          dateArray.push([Number(values[`FDFL${i + 1 <= 9 ? "0" + (i + 1) : (i + 1)}`]), Number(values[`FDFH${i + 1 <= 9 ? "0" + (i + 1) : (i + 1)}`])]);
        }
      }
      return dateArray;
    } else if (periodicty == 13) {

      for (let i = 0; i < 13; i++) {
        if (dates[`PFPER${i + 1}`] !== '0') {
          dateArray.push(Number(values[`PFDFL${i + 1 <= 9 ? "0" + (i + 1) : (i + 1)}`]), Number(values[`PFDFH${i + 1 <= 9 ? "0" + (i + 1) : (i + 1)}`]));
        }
      }
      return dateArray;
    }

  }
  getDatefromHistData = (data) => {
    let date;
    if (data !== '0') {
      date = getDateFormatted(data, this.props.globalDateFormat);//E3C-32862, J Vamshi
      return date;
    }
    else
      return date;
  }
  getTableDataWithDate = (data, key12, key52, key13, dates) => {
    const { valueData } = this.props.ItemPropertiesData;
    let periodicty = parseInt(valueData["IPERDH"]);
    let values = { ...data };
    let dateArray = [];
    if (periodicty == 12) {
      for (let i = 0; i < 12; i++) {
        if (values[`MFPER${i + 1}`] !== '0') {
          dateArray.push(Number(values[key12 + `${i + 1}`]));
        }
      }
      return dateArray;
    } else if (periodicty == 52) {
      for (let i = 0; i < 52; i++) {
        if (values[`FPER${i + 1}`] !== '0') {
          dateArray.push(Number(values[key52 + `${i + 1}`]));
        }
      }
      return dateArray;
    } else if (periodicty == 13) {
      for (let i = 0; i < 13; i++) {
        if (values[`PFPER${i + 1}`] !== '0') {
          dateArray.push(Number(values[key13 + `${i + 1}`]));
        }
      }
      return dateArray;
    }
  }

  setCardData = () => {
    let { valueData, companyForecastMatrix } = this.props.ItemPropertiesData;
    let cardData = {};
    for (let i = 0; i < 5; i++) {
      if (Number(valueData["IDEM52"]) < Number(companyForecastMatrix[`CFBKWF${i + 1}`])) {
        cardData = {
          "title": companyForecastMatrix[`CFBKDS${i + 1}`],
          "CFAXPD": companyForecastMatrix[`CFAXPD${i + 1}`],
          "CBPZOH": companyForecastMatrix[`CBPZOH${i + 1}`],
          "CBPOPR": companyForecastMatrix[`CBPOPR${i + 1}`],
          "CBPWBP": companyForecastMatrix[`CBPWBP${i + 1}`],
          "CBPWAP": companyForecastMatrix[`CBPWAP${i + 1}`],
          "CDEMHI": companyForecastMatrix[`CDEMHI${i + 1}`],
          "CNDFLH": companyForecastMatrix[`CNDFLH${i + 1}`],
          "CUHDPF": companyForecastMatrix[`CUHDPF${i + 1}`],
          "CDEMLO": companyForecastMatrix[`CDEMLO${i + 1}`],
          "CNDFLL": companyForecastMatrix[`CNDFLL${i + 1}`],
          "CULDPF": companyForecastMatrix[`CULDPF${i + 1}`],
          "CFIPCT": companyForecastMatrix[`CFIPCT${i + 1}`],
          "CFDPCT": companyForecastMatrix[`CFDPCT${i + 1}`],
          "CFBKDS": companyForecastMatrix[`CFBKDS${i + 1}`],
        }
      }
    }
    return cardData;
  }
  getDemands = (fields) => {
    const { valueData: { IPERDF } = {} } = this.props.ItemPropertiesData;
    if (!fields) return fields;
    if (typeof this.props.appendConditionalASR === "function") {
      fields = this.props.appendConditionalASR(fields);
    }
    return fields.filter(field => {
      if (field.FDFILD === '3760' && IPERDF !== '12')
        return false;
      if (field.FDFILD === '3761' && IPERDF === '12')
        return false;
      return true;
    })
  }
  getForecastTitle = () => {
    const { companyDetails: { CFCVAV }, ItemPropertiesData: { valueData }, forecastMethodMetaData } = this.props;
    let forecastMethod = "E3 Regular AVS Forecast";
    if (forecastMethodMetaData) {
      const forecast = valueData.IXFLG2 !== '0' ? valueData.IXFLG2 : valueData.IXFLG1;
      let label = forecastMethodMetaData.valueSuggestionList?.find(ele => ele.value === forecast)?.label;
      if (label) {
        label = label.split('-')[1]?.trim();
        forecastMethod = label;
      }
    }
    const seasonalForecastString = CFCVAV === '1' ? '(S)' : '';
    const date = this.getDatefromHistData(valueData.IACTDT) || '';
    return `${forecastMethod}  ${date} ${seasonalForecastString}`;
  }
  render() {
    const { classes, setSaveData, globalDateFormat, filterCriteriaDetails, pageFilterOptions,
      globalFilterOptions, columnDefs, currentPage, canUpdateComponent } = this.props;
    const { loading, valueData, newValueData, forecastHistoryLabelsData, itemMiscData, histDemRec, histForFct, histForOvr, histForRec, companyForecastMatrix } = this.props.ItemPropertiesData;
    const { tabcards } = forecastHistoryLabelsData;
    const { companyDetails } = this.props;
    let dates = histDemRec ? this.getDateForGraph(histDemRec) : null;
    let expectedDemand = histDemRec ? this.getTableDataWithDate(histDemRec, `MFED`, `FED`, `PFED`, dates) : null;
    let baseForecast = histDemRec && histForRec ? this.getBaseForecast(histForRec, histDemRec) : null;
    let actualDemand = histDemRec ? this.getTableDataWithDate(histDemRec, `MFAD`, `FAD`, `PFAD`, dates) : null;
    let filteredDemand = histDemRec ? this.getTableDataWithDate(histDemRec, `MFFD`, `FFD`, `PFFD`, dates) : null;
    let demandFilterRange = histForOvr && histDemRec ? this.getDemandFilterRange(histForOvr, histDemRec) : null;
    let cardData = companyForecastMatrix ? this.setCardData() : null;
    const forecastSource = (() => {
      const { itemMiscData: { CFCFSRC } = {}} = this.props.ItemPropertiesData;
      if (/C|R/.test(CFCFSRC)) {
        return this.props.getLabelFromId('41587');
      }
      if (CFCFSRC === 'W') 
        return this.props.getLabelFromId('41588');
      return this.props.getLabelFromId('41589');
    })();
    if (this.state.hasHardError) {
      return <h2> Oops Something Went Wrong </h2>
    }
    return (
      <div>
        {(!loading && expectedDemand && baseForecast && companyForecastMatrix && histDemRec && histForOvr && tabcards && tabcards.length && currentPage) ? (
          <div className={classes.pageContainer}>
            <div className={classes.pageContainerHundred}>
              <div className={classes.simpleCardGroup3}>
                <CardComponent className={classes.card1}>
                  <div className={classes.simpleCardGroup}>
                    {histDemRec && dates && baseForecast && demandFilterRange && <ForecastGraph demandFilterRange={demandFilterRange} filteredDemand={filteredDemand} expectedDemand={expectedDemand} baseForecast={baseForecast} actualDemand={actualDemand} dates={dates} />}
                  </div>
                </CardComponent>
              </div>
              <div className={classes.simpleCardGroup3}>
                <MuiThemeProvider theme={themes}>
                  <CardComponent className={classes.card1}>
                    <div className={classes.simpleCardGroup}>
                      {histDemRec && dates && <ForecastTable dates={dates} {...this.props} />}
                    </div>
                  </CardComponent>
                </MuiThemeProvider>
              </div>
            </div>


            <div className={classes.pageContainerNew}>


              <div className={classes.simpleCardGroup1}>

                {!loading && tabcards.map(formCard => {
                  if (formCard.cardkey == "50888") {
                    return <CardComponent title={this.getForecastTitle()} className={classes.card + ' ' + classes.marginLeftZero + ' ' + classes.marginRightZero}>
                      {+valueData.IACSLS ?
                        <Grid item xs={12}>
                          <label className={classes.label}>
                            {this.props.getLabelFromId('25248')} : {this.getDatefromHistData(valueData.IACSLS)}
                          </label>
                        </Grid>
                        : null
                      }
                      <FormFieldsGenerator
                        handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                        key={formCard.cardkey}
                        parentPage={ITEMS_LIST_PAGE}
                        fieldsArray={this.getDemands(formCard.cardfields)}
                        valuesArray={{ ...newValueData }}
                        handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                        enableAddButton={(e) => { setSaveData(e) }}
                        className={"REFORECAST"}
                        handleFocusOut={(key, val, field) => this.setValueDataOnFocutOut(key, val, field)}
                        globalDateFormat={globalDateFormat}
                        filterCriteriaDetails={filterCriteriaDetails}
                        pageFilterOptions={pageFilterOptions}
                        globalFilterOptions={globalFilterOptions}
                        columnDefs={columnDefs}
                        currentPage={currentPage}
                        parentData={newValueData}
                        labelDisplayCharacters={18}
                        valueDisplayCharacters={17}
                        canUpdateComponent = {canUpdateComponent}
                      />
                    </CardComponent>

                  }
                })}
              </div>
              <div className={classes.simpleCardGroup2} >
                {!loading && tabcards.map(formCard => {
                  if (formCard.cardkey == "28363") {
                    return <CardComponent title={formCard.cardtitle} className={classes.card}>
                      <FormFieldsGenerator
                        handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                        key={formCard.cardkey}
                        parentPage={ITEMS_LIST_PAGE}
                        fieldsArray={formCard.cardfields}
                        valuesArray={{ ...newValueData, ...companyDetails }}
                        handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                        enableAddButton={(e) => { setSaveData(e) }}
                        className={"PROFILE_BYPASS_CONDITIONS"}
                        handleFocusOut={(key, val, field) => this.props.setValueDataOnFocutOut({ key, val, field })}
                        handleFocusOut={(key, val, field) => this.setValueDataOnFocutOut(key, val, field)}
                        globalDateFormat={globalDateFormat}
                        filterCriteriaDetails={filterCriteriaDetails}
                        pageFilterOptions={pageFilterOptions}
                        globalFilterOptions={globalFilterOptions}
                        columnDefs={columnDefs}
                        currentPage={currentPage}
                        parentData={newValueData}
                        labelDisplayCharacters={27}
                        canUpdateComponent = {canUpdateComponent}
                      />
                    </CardComponent>
                  }
                })}
              </div>
            </div>
            
            <div className={classes.pageContainerNew}>
                <div className={classes.notesForBlock}>
              <div className={classes.simpleCardGroup33}>
                  <Box mb={theme.spacing(0.5)} className={classes.notesForLabel}>{`${forecastSource} ${itemMiscData.CFBKDS}`}</Box>
                {!loading && tabcards.map(formCard => {
                  if (formCard.cardkey == "28354") {
                    
                    return <CardComponent title={formCard.cardtitle} className={classes.card}>
                      <FormFieldsGenerator
                        handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                        key={formCard.cardkey}
                        parentPage={ITEMS_LIST_PAGE}
                        fieldsArray={formCard.cardfields}
                        valuesArray={{ ...newValueData, ...itemMiscData }}
                        enableAddButton={(e) => { setSaveData(e) }}
                        className={"PROFILE_BYPASS_CONDITIONS"}
                        handleFocusOut={(key, val, field) => this.setValueDataOnFocutOut(key, val, field)}
                        globalDateFormat={globalDateFormat}
                        filterCriteriaDetails={filterCriteriaDetails}
                        pageFilterOptions={pageFilterOptions}
                        globalFilterOptions={globalFilterOptions}
                        columnDefs={columnDefs}
                        currentPage={currentPage}
                        parentData={newValueData}
                        labelDisplayCharacters={36}
                        noMassMaintenance={true}
                        isCheckWildCard={formCard.isCheckWildCard}
                        valueDisplayCharacters={6}
                        canUpdateComponent = {canUpdateComponent}
                      />
                    </CardComponent>
                  }
                })}
              </div>
              <div className={classes.simpleCardGroup33}>
                {!loading && tabcards.map(formCard => {
                  if (formCard.cardkey == "28356") {
                    return <CardComponent title={formCard.cardtitle} className={classes.card}>
                      <FormFieldsGenerator
                        handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                        key={formCard.cardkey}
                        parentPage={ITEMS_LIST_PAGE}
                        fieldsArray={formCard.cardfields}
                        valuesArray={{ ...newValueData, ...itemMiscData }}
                        handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                        enableAddButton={(e) => { setSaveData(e) }}
                        className={"PROFILE_BYPASS_CONDITIONS"}
                        handleFocusOut={(key, val, field) => this.setValueDataOnFocutOut(key, val, field)}
                        globalDateFormat={globalDateFormat}
                        filterCriteriaDetails={filterCriteriaDetails}
                        pageFilterOptions={pageFilterOptions}
                        globalFilterOptions={globalFilterOptions}
                        columnDefs={columnDefs}
                        currentPage={currentPage}
                        parentData={newValueData}
                        labelDisplayCharacters={35}
                        valueDisplayCharacters={6}
                        canUpdateComponent = {canUpdateComponent}
                      />
                    </CardComponent>
                  }
                })}
              </div>
              <div className={classes.simpleCardGroup333}>
                {!loading && tabcards.map(formCard => {
                  if (formCard.cardkey == "28358") {
                    return <CardComponent title={formCard.cardtitle} className={classes.card}>
                      <FormFieldsGenerator
                        handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                        key={formCard.cardkey}
                        parentPage={ITEMS_LIST_PAGE}
                        fieldsArray={formCard.cardfields}
                        valuesArray={{ ...newValueData, ...itemMiscData }}
                        handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                        enableAddButton={(e) => { setSaveData(e) }}
                        className={"PROFILE_BYPASS_CONDITIONS"}
                        handleFocusOut={(key, val, field) => this.setValueDataOnFocutOut(key, val, field)}
                        globalDateFormat={globalDateFormat}
                        filterCriteriaDetails={filterCriteriaDetails}
                        pageFilterOptions={pageFilterOptions}
                        globalFilterOptions={globalFilterOptions}
                        columnDefs={columnDefs}
                        currentPage={currentPage}
                        parentData={newValueData}
                        labelDisplayCharacters={37}
                        valueDisplayCharacters={6}
                        canUpdateComponent = {canUpdateComponent}
                      />
                    </CardComponent>
                  }
                })}
              </div>
                </div>
            </div>
          </div>
        ) : (<Spinner loading type="ForecastHistoryTab" />)}


      </div>
    );
  }
}

ForecastHistory.propTypes = propTypes;

export default withStyles(style)(ForecastHistory);

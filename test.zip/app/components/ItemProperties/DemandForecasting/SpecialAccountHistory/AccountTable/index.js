import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import EmbeddedList from '../../../../../containers/common/EmbeddedList';
import { MENU_ITEMS, MENU_ITEMS_HANDLED } from './constants';

const styles = () => ({
  embeddedList: {
    '& > div': {
      '& > div': {
        '& > div': {
          '&:nth-child(2)': {
            '& > div': {
              '&:first-child': {
                '& > div': {
                  height: '360px !important',
                },
              },
              '&:last-child': {
                display: 'none',
              },
            },
          },
        },
      },
    },
  },
});

class AccountTable extends React.PureComponent {
  constructor(props) {
    super(props);
    const { rowData } = this.props;
    this.state = {
      selectedRows: rowData && rowData.length ? [rowData[0]] : [],
      selectedRowId: rowData && rowData.length ? rowData[0].WACCT : null,
      menuItems: MENU_ITEMS,
    };
  }

  componentDidMount(){
    const { canUpdateComponent } = this.props;
    let menuItems = this.state.menuItems;
    if (canUpdateComponent && Object.keys(canUpdateComponent) && Object.keys(canUpdateComponent).length) {
        menuItems.forEach((menuItem) => {
          menuItem.isDisable = canUpdateComponent.update ? false : true; //E3C30659-apply security restrictions in addition to field check 
        });
      this.setState({ menuItems });
    }
    if(this.state.selectedRows.length)this.props.getSelectedSpclAccount(this.state.selectedRows);


  }
  componentDidUpdate(prevProps,prevState){
    const{selectedRows}=this.state
    if(selectedRows && selectedRows != prevState.selectedRows){
      this.props.getSelectedSpclAccount(selectedRows);
    }
  }

  onGridReady = (params) => {
    this.grid = params;
    params.api.selectIndex(0);

  };
    

  onRowSelected = () => {
    const selectedRows = this.grid.api.getSelectedRows();
    const selectedRowId =
      selectedRows && selectedRows.length ? selectedRows[0].WACCT : null;
    this.setState(prevState => {
      const included = selectedRows[0].WINCD;
      const { menuItems } = prevState;
      menuItems[0].isDisable = included === 'Y';
      menuItems[1].isDisable = included === 'N';
      return {
        menuItems,
        selectedRows,
        selectedRowId,
      };
    });
    this.props.selectSpecialAccountHistory(selectedRowId);
  };

  removeRecord = () => {};

  handleItemSelection = value => {
    switch (value) {
      case 'addToTotalDemand':
        this.props.onAction(value);
        break;
      case 'subtractFromTotalDemand':
        this.props.onAction(value);
        break;
      default:
        break;
    }
  };

  render() {
    const { classes } = this.props;
    const { columnDefs, columnInfo, pageProps, rowData ,canUpdateComponent } = this.props;
    if (rowData && pageProps && rowData.length > pageProps.pageSize) {
      pageProps.pageSize = 100;
      pageProps.totalCount = rowData.length;
      pageProps.actualPageSize = 100;
    }
    return (
      <div className={classes.embeddedList}>
        {columnDefs && rowData ? (
          <EmbeddedList
            columnDefs={columnDefs}
            rowColumnID="WACCT"
            rowData={rowData}
            columnInfo={columnInfo}
            columnKey="WACCT"
            gridAPI={this.grid}
            frameworkComponents={{}}
            menuItems={this.state.menuItems}
            pageProps={{
              ...pageProps,
              pageSize: rowData.length > 100 ? rowData.length : 100,
              totalCount: rowData.length,
              actualPageSize: rowData.length > 100 ? rowData.length : 100,
            }}
            selectedRows={this.state.selectedRows}
            selectedRowId={this.state.selectedRowId}
            onGridReady={this.onGridReady}
            hasPagination={false}
            hasDeleteRowAction
            hasDeleteConfimation
            rowSelection="single"
            onRowSelected={this.onRowSelected}
            removeRecord={this.removeRecord}
            hasGridActions
            menuItemsHandled={MENU_ITEMS_HANDLED}
            handleItemSelection={this.handleItemSelection}
          />
        ) : null}
      </div>
    );
  }
}

AccountTable.propTypes = {
  classes: PropTypes.object,
  columnDefs: PropTypes.array,
  columnInfo: PropTypes.object,
  pageProps: PropTypes.object,
  rowData: PropTypes.array,
  selectSpecialAccountHistory: PropTypes.func,
  onAction: PropTypes.func,
};

export default withStyles(styles)(AccountTable);

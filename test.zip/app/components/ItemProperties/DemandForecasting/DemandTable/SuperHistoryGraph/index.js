import React from 'react';
import PropTypes from 'prop-types';
import HightchartsReact from 'highcharts-react-official';

const SuperHistoryGraph = ({ series, categories, getLabelFromId, isMonthly }) => {
    const options = {
        chart: {
            type: 'column',
            scrollablePlotArea: {
                minWidth: isMonthly ? 4000 : 8000,
                scrollPositionX: 1,
            },
            scrollbar: {
                enabled: true,
            },
        },
        title: {
            text: getLabelFromId('25401') || 'Super Item History Graph',
        },
        xAxis: {
            categories,
        },
        plotOptions: {
            series: {
                scrollbar: {
                    enabled: true
                },
                marker: {
                    enabledThreshold: 1,
                    radius: 1
                },
                animation: true,
            },
            column: {
                stacking: 'normal',
            }
        },
        credits: {
            enabled: false,
        },
        series,
    };
    return <HightchartsReact options={options} />;
}

SuperHistoryGraph.propTypes = {
    series: PropTypes.array,
    categories: PropTypes.array,
    getLabelFromId: PropTypes.func,
    isMonthly: PropTypes.bool,
};

export default SuperHistoryGraph;


/** Change Log
 * LogStart --  E3C-33195 - Kumar A- 16 September,2021 - 2022.1.0.0 Unified Product
 *              Story: E3C-33195 --Code Cleanup
*/
import React from 'react';
import { withStyles, Button, Box } from '@material-ui/core';
import { injectIntl } from 'react-intl';
import MoreVertIcon from '@material-ui/icons/MoreVert';
import SaveIcon from '@material-ui/icons/Save';
import PropTypes from 'prop-types';
import Modal from '@material-ui/core/Modal';
import withFixedPosition from 'containers/common/withFixedPosition';
import FieldInput from '../common/Form/FieldInput';
import {
    LABEL_COMPANY_ID,
    CONTEXT_MENU_COMPANY_HEADER,
    JOB_SUBMITTED_WARNING,
} from './constants';
import FormattedMessageComponent from '../common/FormattedMessageComponent';
import StepperComponent from '../common/Form/StepperComponent';
import GridErrorMessages from '../common/GridErrorMessages';
import DialogComponent from '../common/DialogComponent';
import BreadcrumbContextMenu from 'components/common/BreadcrumbContextMenu';
import ForecastCalculation from './CompanyDialogs/ForecastCalculation';
//company_notes_create hyperlink
import { LABEL_NOTE } from './CompanyNotes/constants';
import { TEXT_ALERT, TEXT_OK, BADGE_MAX_COUNT, COMPANYS_LIST_PAGE } from '../common/constants';
import ContextMenuCreateNew from '../common/ContextMenuCreateNew';
import ConfirmationDialog from 'components/common/ConfirmationDialog';
import { Badge } from '@material-ui/core'; //E3C30273: Display badge for notes count

const defaultProps = {
    companyData: [],
    saveDisabled: false
};

const propTypes = {
    companyData: PropTypes.array.isRequired,
    saveDisabled: PropTypes.bool.isRequired,
    handleCompanyHeaderFilterClick: PropTypes.func,
    handleCompanyHeaderSaveClick: PropTypes.func,
    handleCompanyHeaderLeftArrowClick: PropTypes.func,
    handleCompanyHeaderRightArrowClick: PropTypes.func,
    handleCompanyHeaderActionItemSelection: PropTypes.func
};

const style = theme => ({
    propertiesHeaderContainer: {
        width: '100%',
        marginBottom: '1.5rem',
        backgroundColor: 'var(--background-app)',
        borderRadius: '4px',
        borderTopLeftRadius: '0px',
        borderTopRightRadius: '0px',
        overflow: 'hidden',
        boxShadow: '0 4px 4px var(--secondary-s10)',
        overflowX: 'auto'
    },
    companyContainer: {
        display: 'flex',
        width: '100%',
        height: '80px',
        backgroundColor: 'var(--background-content)',
        fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
        alignItems: 'center',
        padding: '0 0 0 24px',
        position: 'relative',
        minWidth: '630px'
    },
    companyDetailsWrapper: {
        width: '100%',
        display: 'flex',
    },
    companyDetailRow: {
        width: '75%',
        display: 'flex',
        flexWrap: 'wrap',
        padding: '0px 0 24px 0',
        paddingLeft: '15px'
    },
    companyDetail: {
        padding: '0px 0px 0 0px',
        lineHeight: '1.1',
        marginTop: '-20px',
    },
    companyDetailx: {
        padding: '0px 0px 0 0px',
        lineHeight: '1.1',
    },
    companyDetailWarehouse: {
    },
    companyLabel: {
        color: 'var(--header-label-color)',
        paddingBottom: '6px',
        width: '20ch',
    },
    companyValue: {
        color: 'var(--value)',
    },
    companyID: {
        width: '100%',
        display: 'flex',
        paddingLeft: '45px',
    },
    companyName: {
        marginRight: '50px',
        paddingTop: '8px'
    },
    companyNameInput: {
        padding: '5px 0 5px 0',
        height: '42px',
        '& .MuiFormControlLabel-label': {
            padding: '10px 17px 10px 0px'
        },
        '& input': {
            width: '30ch',
        },
        '& svg': {
            top: '4px'
        },
        '& span': {
        }
    },
    companyArrowIcon: {
        height: '16px',
        width: '12px',
        borderRadius: '4px',
        fontSize: '10px',
        backgroundColor: 'var(--background-app)',
        margin: '0 4px',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        color: 'var(--secondary-s21)',
        lineHeight: '40px',
        cursor: 'pointer',
    },
    companyActions: {
        top: '24px',
        marginTop: '-22px',
        padding: '0px 20px 20px 20px',
        right: '16px',
        display: 'flex',
        position: 'absolute',
        alignItems: 'center',
        justifyContent: 'space-between',
        '@media (max-width: 1220px)': {
            flexWrap: 'wrap',
            width: '250px'
        }
    },
    companyRightLables: {
        top: '80px',
        padding: '10px 90px 20px 20px',
        right: '16px',
        display: 'flex',
        position: 'absolute',
        alignItems: 'center',
        justifyContent: 'space-between',
        '@media (max-width: 1220px)': {
            flexWrap: 'wrap',
            width: '250px'
        }
    },
    companyActionsFilter: {
        minWidth: '37px',
        border: '1px solid var(--primary-default)',
        height: '32px',
        marginLeft: '15px',
        '@media (max-width: 1220px)': {
            marginLeft: '0px'
        },
        '& img': {
            width: '14px',
            height: '14px'
        },
        '& svg': {
            width: '18px',
            height: '18px'
        }
    },
    companyActionsButton: {
        border: '1px solid var(--logo)',
        color: 'var(--logo)',
        '&:hover': {
            border: '1px solid var(--link-button)'
        }
    },
    companyArrow: {
        padding: '0 !important',
        margin: '0',
        minWidth: '16px',
        background: 'none',
        height: '16px',
        width: '16px',
    },
    companyArrowWrapper: {
        display: 'flex',
        flexDirection: 'column',
        border: '1px solid var(--primary-default)',
        borderRadius: '4px',
        justifyContent: 'center',
        alignItems: 'baseline',
        height: '38px',
        marginTop: '24px',
        padding: '2px',
    },
    ActionsContextMenu: {
    },
    CompanyReferences: {
        position: 'absolute',
        right: '3rem',
        bottom: '0px',

        '&& .MuiBadge-root': {              //E3C30273_Styling for Badge
            '& .MuiBadge-badge': {
                fontSize: '0.6 rem',
                padding: '2px 5px',
                height: '13.5px',
                minWidth: props => (props.notesCountWidth || '21px'),
            }
        }
    },
    companyIDBlock: {
        display: 'flex',
    },
    subCompanyId: {
        marginLeft: '20px'
    },
    idLabel: {
        paddingRight: '8px',
        width: '35px'
    },
    companySubCompanyDetails: {
        display: 'flex',
        flexDirection: 'column',
        width: '36ch',
        padding: '0 30px 0 0px',
        lineHeight: '1.1'
    },
    companyIdDetails: {
        width: '15ch',
        padding: '0 30px 0 0px',
        lineHeight: '1.1'
    },
    companyNameLabel: {
        paddingBottom: '0'
    },
    buttonActions: {
        display: 'flex',
        alignItems: 'center',
        '@media (max-width: 1220px)': {
            marginBottom: '20px'
        },
        '& .MuiButton-root': {
            borderRadius: '4px',
            fontSize: '14px',
            width: '120px',
            lineHeight: '14px',
        },
        '& .MuiButton-sizeLarge': {
            fontSize: '18px',
        },
        '& .MuiButton-sizeSmall': {
            fontSize: '12px',
            padding: '8px 16px',
        },
        '& .MuiButton-containedPrimary': {
            backgroundColor: theme.palette.primary.default,
            border: '1px solid rgba(0, 0, 0, 0)',
            boxShadow: 'none',
            color: 'var(--background-content)',
            '&:hover': {
                backgroundColor: theme.palette.primary.hover,
                color: 'var(--background-content)',
                border: '1px solid rgba(0, 0, 0, 0)',
            },
            '&:focus': {
                backgroundColor: theme.palette.primary.focus,
                color: 'var(--background-content)',
                border: '1px solid rgba(0, 0, 0, 0)',
            },
            '&:active': {
                backgroundColor: theme.palette.primary.active,
                color: 'var(--background-content)',
                border: '1px solid rgba(0, 0, 0, 0)',
            }
        },
        '& .MuiButton-containedSecondary': {
            backgroundColor: 'var(--background-content)',
            border: '1px solid var(--button-tertiary-color)',
            color: 'var(--button-tertiary-color)',
            boxShadow: '0px 4px 14px rgba(0, 0, 0, 0.05)',
            '&:hover': {
                backgroundColor: 'var(--background-content)',
                color: 'var(--button-tertiary-hover-color)',
                border: '1px solid var(--button-tertiary-hover-color)',
            },
            '&:focus': {
                backgroundColor: 'var(--background-content)',
                color: 'var(--button-tertiary-focused)',
                border: '1px solid var(--button-tertiary-focused)',
            },
            '&:active': {
                backgroundColor: 'var(--background-content)',
                color: 'var(--button-tertiary-hover-color)',
                border: '1px solid var(--button-tertiary-hover-color)',
            },
            '&.Mui-disabled': {
                color: theme.palette.primary.disabled,
                textDecoration: 'unset',
                backgroundColor: 'unset',
                textShadow: 'unset'
            }
        },
        '& .MuiButton-outlinedPrimary': {
            border: `${'1px solid '}${theme.palette.primary.default}`,
            boxShadow: '0px 4px 14px rgba(0, 0, 0, 0.05)',
            backgroundColor: 'var(--background-content)',
            color: theme.palette.primary.default,
            '&:hover': {
                backgroundColor: 'var(--background-content)',
                border: '1px solid var(--button-secondary-hover-border)',
                color: 'var(--button-secondary-hover-border)',
            },
            '&:focus': {
                backgroundColor: 'var(--background-content)',
                border: `${'1px solid '}${theme.palette.primary.default}`,
                color: theme.palette.primary.default
            },
            '&:active': {
                backgroundColor: 'var(--background-content)',
                border: '1px solid var(--primary-button-pressed)',
                color: 'var(--primary-button-pressed)'
            },
            '&.Mui-disabled': {
                color: theme.palette.primary.disabled,
                textDecoration: 'unset',
                backgroundColor: 'unset',
                textShadow: 'unset'
            }
        },
        '& .MuiButton-outlinedSecondary': {
            backgroundColor: 'var(--background-content)',
            border: '1px solid var(--button-tertiary-color)',
            color: 'var(--button-tertiary-color)',
            boxShadow: '0px 4px 14px rgba(0, 0, 0, 0.05)',
            '&:hover': {
                backgroundColor: 'var(--background-content)',
                color: 'var(--button-tertiary-hover-color)',
                border: '1px solid var(--button-tertiary-hover-color)',
            },
            '&:focus': {
                backgroundColor: 'var(--background-content)',
                color: 'var(--button-tertiary-focused)',
                border: '1px solid var(--button-tertiary-focused)',
            },
            '&:active': {
                backgroundColor: 'var(--background-content)',
                color: 'var(--button-tertiary-hover-color)',
                border: '1px solid var(--button-tertiary-hover-color)',
            },
            '&.Mui-disabled': {
                color: theme.palette.primary.disabled,
                textDecoration: 'unset',
                backgroundColor: 'unset',
                textShadow: 'unset'
            }
        },
    },
    buttonActionsSecondChild: {
        marginRight: '15px',
        '& .MuiButton-outlinedPrimary': {
            width: '100px',
            height: '28px'
        }
    },
    IdNameBlock: {
        paddingRight: '40px',
        paddingTop: '24px',
        whiteSpace: 'break-spaces'
    },
    IdNameBlockBuyer: {
        paddingTop: '24px',
        whiteSpace: 'break-spaces',
        width: '40ch'
    },
    companyIdNameBlock: {
        paddingRight: '50px'
    },
    hideArrows: {
        display: 'none'
    },
    nameField: {
        paddingTop: '32px'
    },
    companyIDSubID: {
        paddingTop: '24px'
    },
    menuButton: {
        minWidth: '37px',
        border: '1px solid var(--primary-default)',
        height: '32px',
        marginLeft: '15px',
        borderRadius: '4px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        '@media (max-width: 1220px)': {
            marginLeft: '0px'
        },
    },
    simpleCardInput: {
        margin: '0',
        width: '100%',
        textAlignLast: 'left',
        marginLeft: '-30px',

        '& input': {
        },
        '&.error-input:after': {
            borderBottom: '2px solid var(--card-error-border) !important'
        },
        '&.error-input:hover::after': {
            borderBottom: '2px solid var(--card-error-border) !important'
        },
    },
});

const steps = ['step 1', 'step 2', 'step 3'];

class Header extends React.Component {
    constructor(props) {
        super();
        this.state = {
            companyName: false,
            tabValue: 1,
            companyDetailsArray: false,
            contextMenuList: CONTEXT_MENU_COMPANY_HEADER,
            isOpenActionsContextMenu: false,
            menuRef: null,

            isOpenActions: false,
            actionMenuRef: null,
            popupComponent: null,
            open: true,
            subCompany: false,
            openNewPlan: false,
            activeStep: 0,
            lastActiveStep: 0,
            isOpen: true,
            disableSubmit: true,
            disableNext: true,
            disableSubmit: true,

            // error messaging
            hasError: false,
            errorId: false,
            parameterValues: [],
            companyNameData: '',
            forecastKey: {
                "CCOMP": "E3T",
                "TKMETH": "W",
                "CSKFRZ": "0",
                "CSKMNL": "0",
                "CFUONL": "0",
                "CMANUL": "0",
                "CDISC": "0",
                "CWHSE": "",
            }
        }
        this.setIsOpenActionsContextMenu = this.setIsOpenActionsContextMenu.bind(this);
        this.handleStepChange = this.handleStepChange.bind(this);
        this.handleSendData = this.handleSendData.bind(this);
        this.getLabelValue = this.getLabelValue.bind(this);
        this.handleChangeCompanyName = this.handleChangeCompanyName.bind(this);
    }

    handleStepChange = val => {
        this.setState({ activeStep: val });
    };

    getLabelValue(id) {
        return <FormattedMessageComponent id={id}></FormattedMessageComponent>;
    }

    setIsOpenActionsContextMenu = event => {
        this.setState({ isOpenActionsContextMenu: Boolean(event) });
        this.setState({ menuRef: event.currentTarget ? event.currentTarget : event });
    };

    componentDidMount() {
        this.setState({ companyNameData: this.props.CompanyPropertiesData.newValueData.CNAME });
    }

    componentDidUpdate(prevProps) {
        const { canUpdateComponent } = this.props;
        if (canUpdateComponent && canUpdateComponent.update == false) {
            this.state.contextMenuList[0]['isDisable'] = true;
        } else {
            this.state.contextMenuList[0]['isDisable'] = false;
        }
    }

    sethaserror = val => {
        this.setState({ hasError: val });
    };

    handleCloseWarning = (flag) => {
        this.props.showConfirmationDialog(flag);
    }
    onSaveCompanyData = (
        values,
        constrainValues,
        dashboardValues,
        companyRecordRetentionValues,
        companyRecordRetentionDashboardValues,
        companyForecastFactorsMatrixChangedData, companyExceptionControlChangedData, companyPurchaseOrderControlData,
        companyUdfIDSFields, companyUdfOSSFields, companyOrderControlChangedData, companyOrderControlSSChangedData, companySystemSetupData, oldValueData, companyClassificationData) => {
        if (this.onValid(values, companyForecastFactorsMatrixChangedData, companyClassificationData)) {
            values.CNAME = this.state.companyNameData;
            //Item Classification Values
            values.CICC1 = companyClassificationData['CICC1'];
            values.CICC2 = companyClassificationData['CICC2'];
            values.CICC3 = companyClassificationData['CICC3'];
            values.CICC4 = companyClassificationData['CICC4'];
            values.CICC5 = companyClassificationData['CICC5'];
            values.CICC6 = companyClassificationData['CICC6'];
            values.CICC7 = companyClassificationData['CICC7'];
            values.CICC8 = companyClassificationData['CICC8'];
            values.CISO1 = companyClassificationData['CISO1'];
            values.CISO2 = companyClassificationData['CISO2'];
            values.CISO3 = companyClassificationData['CISO3'];
            values.CISO4 = companyClassificationData['CISO4'];
            values.CISO5 = companyClassificationData['CISO5'];
            values.CISO6 = companyClassificationData['CISO6'];
            values.CISO7 = companyClassificationData['CISO7'];
            values.CISO8 = companyClassificationData['CISO8'];
            values.CICP1 = companyClassificationData['CICP1'];
            values.CICP2 = companyClassificationData['CICP2'];
            values.CICP3 = companyClassificationData['CICP3'];
            values.CICP4 = companyClassificationData['CICP4'];
            values.CICP5 = companyClassificationData['CICP5'];
            values.CICP6 = companyClassificationData['CICP6'];
            values.CICP7 = companyClassificationData['CICP7'];
            values.CICP8 = companyClassificationData['CICP8'];
            let calendarSaveData = this.props.calendarDataSaveArray;
            for (var calData in calendarSaveData) {
                this.props.onCalendarAjsutmentModify(calendarSaveData[calData]);
            }
            if (Object.keys(companyUdfIDSFields).length !== 0) {
                companyUdfIDSFields = this.formatObject(companyUdfIDSFields);
                this.props.onSaveCompanyPurchaseOrderControlIDData({ ...companyUdfIDSFields });
            }
            if (Object.keys(companyUdfOSSFields).length !== 0) {
                companyUdfOSSFields = this.formatObject(companyUdfOSSFields);
                this.props.onSaveCompanyPurchaseOrderControlOSData({ ...companyUdfOSSFields });
            }
            if (Object.keys(constrainValues).length !== 0) {
                constrainValues = this.formatObject(constrainValues);
                this.props.onSaveCompanyConstarinedControlData({ ...constrainValues });
            }
            if (Object.keys(values).length !== 0) {
                values = this.formatObject(values);
                if (Object.keys(companyRecordRetentionValues).length !== 0 || Object.keys(companyPurchaseOrderControlData).length !== 0
                    || Object.keys(companySystemSetupData).length !== 0) {
                    companyRecordRetentionValues = this.formatObject(companyRecordRetentionValues);
                    companyPurchaseOrderControlData = this.formatObject(companyPurchaseOrderControlData);
                    companySystemSetupData = this.formatObject(companySystemSetupData);
                    values = this.mergeCompanyData(values, companyRecordRetentionValues, companyPurchaseOrderControlData, companySystemSetupData);
                }
                this.props.onSaveCompanyData({ ...values });

            }
            if (Object.keys(companyOrderControlChangedData).length !== 0 || Object.keys(companyOrderControlSSChangedData).length !== 0) {
                companyOrderControlChangedData = this.formatObject(companyOrderControlChangedData);
                companyOrderControlChangedData = this.mergeCompanyControlDataFor2Fields(companyOrderControlChangedData, values);
                if (Object.keys(companyOrderControlSSChangedData).length !== 0) {
                    companyOrderControlSSChangedData = this.formatObject(companyOrderControlSSChangedData);
                    companyOrderControlChangedData = this.mergeCompanyControlData(companyOrderControlChangedData, companyOrderControlSSChangedData);
                }
                this.props.onSaveCompanyOrderControlData({ ...companyOrderControlChangedData });
            }
            if (Object.keys(dashboardValues).length !== 0) {
                dashboardValues = this.formatObject(dashboardValues);
                if (Object.keys(companyRecordRetentionValues).length !== 0) {
                    companyRecordRetentionDashboardValues = this.formatObject(companyRecordRetentionDashboardValues);
                    dashboardValues = this.mergeDashboardData(dashboardValues, companyRecordRetentionDashboardValues);
                }
                this.props.onSaveCompanyDashboardControlData({ ...dashboardValues });
            }
            if (Object.keys(companyExceptionControlChangedData).length !== 0) {
                companyExceptionControlChangedData = this.formatExceptionControlObject(companyExceptionControlChangedData);
                this.props.onSaveCompanyExceptionControlData({ ...companyExceptionControlChangedData });
            }
            if (Object.keys(companyForecastFactorsMatrixChangedData).length !== 0) {
                companyForecastFactorsMatrixChangedData = this.formatObject(companyForecastFactorsMatrixChangedData);
                this.props.onSaveCompanyForecastFactorsMatrixData({ ...companyForecastFactorsMatrixChangedData });
            }
            if (values.CFCTDL != oldValueData.CFCTDL) {
                this.props.showConfirmationDialog(true);
            }
        }

    };

    onValid = (values, companyForecastFactorsMatrixChangedData, companyClassificationData) => {
        let bValid = true
        if ((parseInt(values.CCAPRT) + parseInt(values.CPHYRT) + parseInt(values.COTHRT)) > 99) {
            this.setState({ hasError: true })
            this.setState({ errorId: '5015' })
            bValid = false
        }
        if (values.CDSCSQ.length > 2 || values.CDSCOP.length > 2) {
            this.setState({ hasError: true })
            this.setState({ errorId: '5006' })
            bValid = false
        }
        if (values.CDSCSQ.charAt(0) == values.CDSCSQ.charAt(1)) {
            this.setState({ hasError: true })
            this.setState({ errorId: '5004' })
            bValid = false
        }
        if (values.CDSCSQ.charAt(0) > 5 || values.CDSCSQ.charAt(1) > 5) {
            this.setState({ hasError: true })
            this.setState({ errorId: '5005' })
            bValid = false
        }
        if (values.CDSCOP.charAt(0) > 3 || values.CDSCOP.charAt(1) > 3) {
            this.setState({ hasError: true })
            this.setState({ errorId: '5007' })
            bValid = false
        }
        if (values.CJTQUE.trim() == '') {
            this.setState({ hasError: true })
            this.setState({ errorId: '5014' })
            bValid = false
        }
        if (parseFloat(companyForecastFactorsMatrixChangedData.CFBKWF1) > parseFloat(companyForecastFactorsMatrixChangedData.CFBKWF2)) {
            this.setState({ hasError: true })
            this.setState({ errorId: '5016' })
            this.setState({ parameterValues: [1, 2] })
            bValid = false
        }
        if (parseFloat(companyForecastFactorsMatrixChangedData.CFBKWF2) > parseFloat(companyForecastFactorsMatrixChangedData.CFBKWF3)) {
            this.setState({ hasError: true })
            this.setState({ errorId: '5016' })
            this.setState({ parameterValues: [2, 3] })
            bValid = false
        }
        if (parseFloat(companyForecastFactorsMatrixChangedData.CFBKWF3) > parseFloat(companyForecastFactorsMatrixChangedData.CFBKWF4)) {
            this.setState({ hasError: true })
            this.setState({ errorId: '5016' })
            this.setState({ parameterValues: [3, 4] })
            bValid = false
        }
        if (parseFloat(companyForecastFactorsMatrixChangedData.CFBKWF4) > parseFloat(companyForecastFactorsMatrixChangedData.CFBKWF5)) {
            this.setState({ hasError: true })
            this.setState({ errorId: '5016' })
            this.setState({ parameterValues: [4, 5] })
            bValid = false
        }

        // Need to implement later
        // if (parseFloat(companyForecastFactorsMatrixChangedData.CFBKWF1) != 9999999.99) {
        //   if (parseFloat(companyForecastFactorsMatrixChangedData.CFBKWF2) != 9999999.99) {
        //     if (parseFloat(companyForecastFactorsMatrixChangedData.CFBKWF3) != 9999999.99) {
        //       if (parseFloat(companyForecastFactorsMatrixChangedData.CFBKWF4) != 9999999.99) {
        //         if (parseFloat(companyForecastFactorsMatrixChangedData.CFBKWF5) != 9999999.99) {
        //           this.setState({ hasError: true })
        //           this.setState({ errorId: '5017' })
        //           bValid = false
        //         }
        //       }
        //     }
        //   }
        // }

        if ((parseFloat(companyForecastFactorsMatrixChangedData.CFBKWF1) > 0 && companyForecastFactorsMatrixChangedData.CFBKDS1.trim() == '')) {
            this.setState({ hasError: true })
            this.setState({ errorId: '5018' })
            this.setState({ parameterValues: [1] })
            bValid = false
        }

        if ((parseFloat(companyForecastFactorsMatrixChangedData.CFBKWF2) > 0 && companyForecastFactorsMatrixChangedData.CFBKDS2.trim() == '')) {
            this.setState({ hasError: true })
            this.setState({ errorId: '5018' })
            this.setState({ parameterValues: [2] })
            bValid = false
        }

        if ((parseFloat(companyForecastFactorsMatrixChangedData.CFBKWF3) > 0 && companyForecastFactorsMatrixChangedData.CFBKDS3.trim() == '')) {
            this.setState({ hasError: true })
            this.setState({ errorId: '5018' })
            this.setState({ parameterValues: [3] })
            bValid = false
        }

        if ((parseFloat(companyForecastFactorsMatrixChangedData.CFBKWF4) > 0 && companyForecastFactorsMatrixChangedData.CFBKDS4.trim() == '')) {
            this.setState({ hasError: true })
            this.setState({ errorId: '5018' })
            this.setState({ parameterValues: [4] })
            bValid = false
        }

        if ((parseFloat(companyForecastFactorsMatrixChangedData.CFBKWF5) > 0 && companyForecastFactorsMatrixChangedData.CFBKDS5.trim() == '')) {
            this.setState({ hasError: true })
            this.setState({ errorId: '5018' })
            this.setState({ parameterValues: [5] })
            bValid = false
        }

        if (parseInt(values.CWRDDY) > 0 && parseInt(values.CWRDCP) > 0 && parseInt(values.CWRDCU) == 0) {
            this.setState({ hasError: true })
            this.setState({ errorId: '5022' })
            bValid = false
        }

        if (parseInt(values.CWRDDY) == 0 && parseInt(values.CWRDCP) > 0) {
            this.setState({ hasError: true })
            this.setState({ errorId: '5023' })
            bValid = false
        }

        if (parseInt(values.CWRDCP) == 0 && parseInt(values.CWRDCU) > 0) {
            this.setState({ hasError: true })
            this.setState({ errorId: '5024' })
            bValid = false
        }
        if (this.props.pgmAppError1) {
            this.setState({ hasError: true })
            this.setState({ errorId: '5009' })
            bValid = false
        }
        if (this.props.pgmAppError2) {
            this.setState({ hasError: true })
            this.setState({ errorId: '5010' })
            bValid = false
        }
        //Classification tab related error messages
        var CSKU_CLASS = [];
        let duplicateItemClass = false;
        if (companyClassificationData['CICC1'].trim() != '') {
            CSKU_CLASS.push(companyClassificationData['CICC1']);
        }
        if (companyClassificationData['CICC2'].trim() != '') {
            CSKU_CLASS.push(companyClassificationData['CICC2']);
        }
        if (companyClassificationData['CICC3'].trim() != '') {
            CSKU_CLASS.push(companyClassificationData['CICC3']);
        }
        if (companyClassificationData['CICC4'].trim() != '') {
            CSKU_CLASS.push(companyClassificationData['CICC4']);
        }
        if (companyClassificationData['CICC5'].trim() != '') {
            CSKU_CLASS.push(companyClassificationData['CICC5']);
        }
        if (companyClassificationData['CICC6'].trim() != '') {
            CSKU_CLASS.push(companyClassificationData['CICC6']);
        }
        if (companyClassificationData['CICC7'].trim() != '') {
            CSKU_CLASS.push(companyClassificationData['CICC7']);
        }
        if (companyClassificationData['CICC8'].trim() != '') {
            CSKU_CLASS.push(companyClassificationData['CICC8']);
        }
        duplicateItemClass = this.findDuplicateInArray(CSKU_CLASS);
        if (duplicateItemClass) {
            this.setState({ hasError: true })
            this.setState({ errorId: '5019' })
            bValid = false
        }
        if ((parseInt(companyClassificationData['CICP1'].trim() == '' ? 0 : companyClassificationData['CICP1']) != 0 && companyClassificationData['CICC1'].trim() == '') || (parseInt(companyClassificationData['CICP2'].trim() == '' ? 0 : companyClassificationData['CICP1']) != 0 && companyClassificationData['CICC2'].trim() == '') ||
            (parseInt(companyClassificationData['CICP3'].trim() == '' ? 0 : companyClassificationData['CICP3']) != 0 && companyClassificationData['CICC3'].trim() == '') || (parseInt(companyClassificationData['CICP4'].trim() == '' ? 0 : companyClassificationData['CICP4']) != 0 && companyClassificationData['CICC4'].trim() == '') ||
            (parseInt(companyClassificationData['CICP5'].trim() == '' ? 0 : companyClassificationData['CICP5']) != 0 && companyClassificationData['CICC5'].trim() == '') || (parseInt(companyClassificationData['CICP6'].trim() == '' ? 0 : companyClassificationData['CICP6']) != 0 && companyClassificationData['CICC6'].trim() == '') ||
            (parseInt(companyClassificationData['CICP7'].trim() == '' ? 0 : companyClassificationData['CICP7']) != 0 && companyClassificationData['CICC7'].trim() == '') || (parseInt(companyClassificationData['CICP8'].trim() == '' ? 0 : companyClassificationData['CICP8']) != 0 && companyClassificationData['CICC8'].trim() == '')) {
            this.setState({ hasError: true })
            this.setState({ errorId: '5020' })
            bValid = false
        }
        if ((parseInt(companyClassificationData['CICP1'].trim() == '' ? 0 : companyClassificationData['CICP1']) != 0 && (parseFloat(companyClassificationData['CISO1']) < 80.0 || parseFloat(companyClassificationData['CISO1']) > 99.9 || companyClassificationData['CISO1'].trim() == '')) ||
            (parseInt(companyClassificationData['CICP2'].trim() == '' ? 0 : companyClassificationData['CICP2']) != 0 && (parseFloat(companyClassificationData['CISO2']) < 80.0 || parseFloat(companyClassificationData['CISO2']) > 99.9 || companyClassificationData['CISO2'].trim() == '')) ||
            (parseInt(companyClassificationData['CICP3'].trim() == '' ? 0 : companyClassificationData['CICP3']) != 0 && (parseFloat(companyClassificationData['CISO3']) < 80.0 || parseFloat(companyClassificationData['CISO3']) > 99.9 || companyClassificationData['CISO3'].trim() == '')) ||
            (parseInt(companyClassificationData['CICP4'].trim() == '' ? 0 : companyClassificationData['CICP4']) != 0 && (parseFloat(companyClassificationData['CISO4']) < 80.0 || parseFloat(companyClassificationData['CISO4']) > 99.9 || companyClassificationData['CISO4'].trim() == '')) ||
            (parseInt(companyClassificationData['CICP5'].trim() == '' ? 0 : companyClassificationData['CICP5']) != 0 && (parseFloat(companyClassificationData['CISO5']) < 80.0 || parseFloat(companyClassificationData['CISO5']) > 99.9 || companyClassificationData['CISO5'].trim() == '')) ||
            (parseInt(companyClassificationData['CICP6'].trim() == '' ? 0 : companyClassificationData['CICP6']) != 0 && (parseFloat(companyClassificationData['CISO6']) < 80.0 || parseFloat(companyClassificationData['CISO6']) > 99.9 || companyClassificationData['CISO6'].trim() == '')) ||
            (parseInt(companyClassificationData['CICP7'].trim() == '' ? 0 : companyClassificationData['CICP7']) != 0 && (parseFloat(companyClassificationData['CISO7']) < 80.0 || parseFloat(companyClassificationData['CISO7']) > 99.9 || companyClassificationData['CISO7'].trim() == '')) ||
            (parseInt(companyClassificationData['CICP8'].trim() == '' ? 0 : companyClassificationData['CICP8']) != 0 && (parseFloat(companyClassificationData['CISO8']) < 80.0 || parseFloat(companyClassificationData['CISO8']) > 99.9 || companyClassificationData['CISO8'].trim() == ''))) {
            this.setState({ hasError: true })
            this.setState({ errorId: '5021' })
            this.setState({ parameterValues: [80.0, 99.9] })
            bValid = false
        }
        if ((parseInt(companyClassificationData['CICP1'].trim() == '' ? 0 : companyClassificationData['CICP1']) + parseInt(companyClassificationData['CICP2'].trim() == '' ? 0 : companyClassificationData['CICP2']) +
            parseInt(companyClassificationData['CICP3'].trim() == '' ? 0 : companyClassificationData['CICP3']) + parseInt(companyClassificationData['CICP4'].trim() == '' ? 0 : companyClassificationData['CICP4']) +
            parseInt(companyClassificationData['CICP5'].trim() == '' ? 0 : companyClassificationData['CICP5']) + parseInt(companyClassificationData['CICP6'].trim() == '' ? 0 : companyClassificationData['CICP6']) +
            parseInt(companyClassificationData['CICP7'].trim() == '' ? 0 : companyClassificationData['CICP7']) + parseInt(companyClassificationData['CICP8'].trim() == '' ? 0 : companyClassificationData['CICP8'])) != 100) {
            this.setState({ hasError: true })
            this.setState({ errorId: '5053' })
            bValid = false
        }
        if (this.props.calendarList.length != 0) {
            let foundFlag = false;
            for (var count in this.props.calendarList) {
                if (values.CSDYY == this.props.calendarList[count]['AYEAR']) {
                    foundFlag = true;
                    break;
                }
            }
            if (!foundFlag) {
                const sendData =
                    { 'ACOMP': 'E3T', 'AYEAR': values.CSDYY.toString(), 'AADJMT': values.CCALA0.toString(), 'ANAME': 'AWR 16E' }
                const data = 'CCOMP=E3T';
                this.props.getValueListReload(data);
                this.props.onCalendarAjsutmentSubmit({ sendData });
                this.setState({ hasError: true })
                this.setState({ errorId: '5011' })
                bValid = false
            }
        }

        let calendarSaveData = this.props.calendarDataSaveArray;
        for (let val in calendarSaveData) {
            if (parseInt(calendarSaveData[val].AADJMT) < -6 || parseInt(calendarSaveData[val].AADJMT) > 7) {
                this.setState({ hasError: true })
                this.setState({ errorId: '506' })
                this.setState({ parameterValues: ['Calendar Adjustment', -6, 7, ''] })
                bValid = false
            }
        }
        return bValid
    };

    findDuplicateInArray = (array) => {
        var object = {};
        array.forEach(function (item) {
            if (!object[item])
                object[item] = 0;
            object[item] += 1;
        })

        for (var prop in object) {
            if (object[prop] >= 2) {
                return true;
            }
        }
        return false;
    }

    formatObject = object => {
        let newObject = { ...object };
        for (const key in newObject) {
            if (typeof newObject[key] === 'boolean') {
                newObject[key] = newObject[key] ? "1" : "0";
            }
            if (typeof newObject[key] === 'number') {
                newObject[key] = newObject[key].toString();
            }
            if (key === 'CMINIX') {
                newObject[key] = newObject[key].substring(newObject[key].indexOf('.'));
            }
        }
        return newObject;
    };

    formatExceptionControlObject = object => {
        const newObject = { ...object };
        for (const key in newObject) {
            if (typeof newObject[key] === 'boolean') {
                if (key.length > 3) {
                    newObject[key] = newObject[key] ? "1" : "0";
                } else {
                    newObject[key] = newObject[key] ? "Y" : "N";
                }
            }
            if (typeof newObject[key] === 'number') {
                newObject[key] = newObject[key].toString();
            }
        }
        return newObject;
    };

    mergeCompanyData = (company, rrCompany, pocCompany, ssCompany) => {
        let newCompany = { ...company };
        for (let key in newCompany) {
            if (key == 'CPLKDY' || key == 'CTBPGD' || key == 'CHSAUT' || key == 'CHSEXT' || key == 'CK4RRS' || key == 'CPUNDO' || key == 'CLTDAY' ||
                key == 'CPJCTL' || key == 'CNSHST' || key == 'CBKDLT' || key == 'CPODAY' || key == 'CDLDAY' || key == 'CMSDAY' || key == 'CPRDAY' || key == 'CDLFLV' ||
                key == 'CDEMHI' || key == 'CFWDBY' || key == 'CSDY52' || key == 'CPOGRP' || key == 'CPOSTR' || key == 'CPOEND' || key == 'CPOINC' || key == 'CPONXT' ||
                key == 'CPOACT' || key == 'CUPDPO' || key == 'CRCPRT' || key == 'CRDPRT' || key == 'CVORCV' || key == 'CCSOSW' || key == 'CCSTSW' ||
                key == 'CCUST' || key == 'CXLIBN' || key == 'CXFRMT' || key == 'CTAPNM' || key == 'CTAPDN' || key == 'CCNTRY' || key == 'CDAYWK' || key == 'CHSROL' ||
                key == 'CRPL52' || key == 'CRPL26' || key == 'CRPL13' || key == 'CRPL12' || key == 'CFR0DY' || key == 'CJTNUM' || key == 'CJTQUE' || key == 'CJTWTT' ||
                key == 'CJTWTF' || key == 'CSDYY' || key == 'CSDMM' || key == 'CSDDD' || key == 'CSDJD' || key == 'CPER52' || key == 'CPER26' || key == 'CPER13' ||
                key == 'CPER12' || key == 'CPER04' || key == 'CCALA0' || key == 'CDTUPD' || key == 'CDTNTJ' || key == 'CPMWAV' || key == 'CPMWAU' || key == 'CRBBKS' ||
                key == 'CCOFMN' || key == 'CPOWHG' || key == 'CHSDIV' || key == 'CPRCNV' || key == 'CCSPRC' || key == 'CCSSOQ' || key == 'CSVTSS' || key == 'CFCVAV' ||
                key == 'CWFACT' || key == 'CDECCH' || key == 'CVIDNM' || key == 'CVIDLH' || key == 'CVDSEQ' || key == 'CIIDNM' || key == 'CIIDLH' || key == 'CIDSEQ' ||
                key == 'CUWGHT' || key == 'CUICL' || key == 'CUGRP6' || key == 'CUCUBE' || key == 'CCNVBP' || key == 'CUGRP7' || key == 'CUCASE' || key == 'CUGRP1' ||
                key == 'CUGRP8' || key == 'CULAYR' || key == 'CUGRP2' || key == 'CUGRP9' || key == 'CUPALT' || key == 'CUGRP3' || key == 'CUGRP10' || key == 'CUUNIT' ||
                key == 'CUGRP4' || key == 'CUGRP11' || key == 'CUBMLT' || key == 'CUGRP5' || key == 'CUGRP12' || key == 'CHSAUT' || key == 'CUBMLT' || key == 'CUMINQ' ||
                key == 'CVORCV' || key == 'CITRPT') {
                for (let key1 in rrCompany) {
                    if (key1 == 'CPLKDY' || key1 == 'CTBPGD' || key1 == 'CHSAUT' || key1 == 'CHSEXT' || key1 == 'CK4RRS' || key1 == 'CPUNDO' || key1 == 'CLTDAY' ||
                        key1 == 'CPJCTL' || key1 == 'CNSHST' || key1 == 'CBKDLT' || key1 == 'CPODAY' || key1 == 'CDLDAY' || key1 == 'CMSDAY' || key1 == 'CPRDAY' || key1 == 'CDLFLV') {
                        if (key === key1) {
                            newCompany[key] = rrCompany[key1]
                        }
                    }
                }
                for (let key2 in pocCompany) {
                    if (key2 == 'CDEMHI' || key2 == 'CFWDBY' || key2 == 'CSDY52' || key2 == 'CPOGRP' || key2 == 'CPOSTR' || key2 == 'CPOEND' || key2 == 'CPOINC' || key2 == 'CPONXT' ||
                        key2 == 'CPOACT' || key2 == 'CUPDPO' || key2 == 'CRCPRT' || key2 == 'CRDPRT' || key2 == 'CVORCV' || key2 == 'CCSOSW' || key2 == 'CCSTSW') {
                        if (key === key2) {
                            newCompany[key] = pocCompany[key2]
                        }
                    }
                }
                for (let key3 in ssCompany) {
                    if (key3 == 'CCUST' || key3 == 'CXLIBN' || key3 == 'CXFRMT' || key3 == 'CTAPNM' || key3 == 'CTAPDN' || key3 == 'CCNTRY' || key3 == 'CDAYWK' || key3 == 'CHSROL' ||
                        key3 == 'CRPL52' || key3 == 'CRPL26' || key3 == 'CRPL13' || key3 == 'CRPL12' || key3 == 'CFR0DY' || key3 == 'CJTNUM' || key3 == 'CJTQUE' || key3 == 'CJTWTT' ||
                        key3 == 'CJTWTF' || key3 == 'CSDYY' || key3 == 'CSDMM' || key3 == 'CSDDD' || key3 == 'CSDJD' || key3 == 'CPER52' || key3 == 'CPER26' || key3 == 'CPER13' ||
                        key3 == 'CPER12' || key3 == 'CPER04' || key3 == 'CCALA0' || key3 == 'CDTUPD' || key3 == 'CDTNTJ' || key3 == 'CPMWAV' || key3 == 'CPMWAU' || key3 == 'CRBBKS' ||
                        key3 == 'CCOFMN' || key3 == 'CPOWHG' || key3 == 'CHSDIV' || key3 == 'CPRCNV' || key3 == 'CCSPRC' || key3 == 'CCSSOQ' || key3 == 'CSVTSS' || key3 == 'CFCVAV' ||
                        key3 == 'CWFACT' || key3 == 'CDECCH' || key3 == 'CVIDNM' || key3 == 'CVIDLH' || key3 == 'CVDSEQ' || key3 == 'CIIDNM' || key3 == 'CIIDLH' || key3 == 'CIDSEQ' ||
                        key3 == 'CUWGHT' || key3 == 'CUICL' || key3 == 'CUGRP6' || key3 == 'CUCUBE' || key3 == 'CCNVBP' || key3 == 'CUGRP7' || key3 == 'CUCASE' || key3 == 'CUGRP1' ||
                        key3 == 'CUGRP8' || key3 == 'CULAYR' || key3 == 'CUGRP2' || key3 == 'CUGRP9' || key3 == 'CUPALT' || key3 == 'CUGRP3' || key3 == 'CUGRP10' || key3 == 'CUUNIT' ||
                        key3 == 'CUGRP4' || key3 == 'CUGRP11' || key3 == 'CUBMLT' || key3 == 'CUGRP5' || key3 == 'CUGRP12' || key3 == 'CHSAUT' || key3 == 'CUBMLT' || key3 == 'CUMINQ' ||
                        key3 == 'CVORCV' || key3 == 'CITRPT') {
                        if (key === key3) {
                            newCompany[key] = ssCompany[key3]
                        }
                    }
                }
            }
        }
        return newCompany;
    }

    mergeDashboardData = (dashboard, rrDashboard) => {
        let newDashboard = { ...dashboard };
        for (const key in newDashboard) {
            if (key == 'CSPRGD' || key == 'CSDKPD' || key == 'CSPRGH' || key == 'CSDKPH' || key == 'CSYKPH') {
                for (const key1 in rrDashboard) {
                    if (key1 == 'CSPRGD' || key1 == 'CSDKPD' || key1 == 'CSPRGH' || key1 == 'CSDKPH' || key1 == 'CSYKPH') {
                        if (key === key1) {
                            newDashboard[key] = rrDashboard[key1]
                        }
                    }
                }
            }
        }
        return newDashboard;
    };

    mergeCompanyControlData = (orderControl, ssOrderControl) => {
        let newOrderControl = { ...orderControl };
        if (Object.keys(newOrderControl).length !== 0) {
            for (const key in newOrderControl) {
                if (key == 'OCFAXF' || key == 'OCPKUP' || key == 'OCCONF' || key == 'OCDT1X' || key == 'OCDT2X') {
                    for (const key1 in ssOrderControl) {
                        if (key1 == 'OCFAXF' || key1 == 'OCPKUP' || key1 == 'OCCONF' || key1 == 'OCDT1X' || key1 == 'OCDT2X') {
                            if (key === key1) {
                                newOrderControl[key] = ssOrderControl[key1]
                            }
                        }
                    }
                }
            }
        } else {
            for (const key1 in ssOrderControl) {
                if (key1 == 'OCFAXF' || key1 == 'OCPKUP' || key1 == 'OCCONF' || key1 == 'OCDT1X' || key1 == 'OCDT2X') {
                    if (key === key1) {
                        newOrderControl[key] = ssOrderControl[key1]
                    }
                }
            }
        }
        return newOrderControl;
    };

    mergeCompanyControlDataFor2Fields = (orderControl, values) => {
        let newOrderControl = { ...orderControl };
        newOrderControl.OCWRDCP = values.CWRDCP;
        newOrderControl.OCWRDCU = values.CWRDCU;
        newOrderControl.OCWRDDY = values.CWRDDY;
        return newOrderControl;
    };

    handleSendData = openClose => {
        this.setState({ open: openClose });
    };

    handleClose = () => {
        this.setState({ open: false });
    };

    handleCloseNewPlan = () => {
        this.setState({ openNewPlan: false });
    };

    handleSendDataNewPlan = openClose => {
        this.setState({ openNewPlan: openClose });
    };

    handleNext = () => {
        if ((this.state.activeStep + 1) > this.state.lastActiveStep) {
            this.setState({ lastActiveStep: this.state.activeStep + 1 });
        }
        if ((this.state.activeStep + 1) === steps.length - 1) {
            this.setState({ completed: true });
        }
        this.setState({ activeStep: this.state.activeStep + 1 });
    };
    handleCloseNewPlanAgain = () => {
        this.setState({ isOpen: false });
    };
    handleCancel = () => {
        this.setState({ isOpen: false });
    };
    handleSubmit = () => {
        this.setState({ isOpen: false });
    };

    handleActionSelection = action => {
        switch (action) {
            case "ForecastCalculation":
                this.handleSendData(false);
                break;
            case "NewPlan":
                this.handleSendDataNewPlan(true);
                break;
            //~~~CreateNewFramework--JVK
            case 'newnote':
                this.props.setisOpenNote(); break;
            //~~~CreateNewFramework--JVK
        }
    };

    handleChangeCompanyName(key, val) {
        this.setState({
            companyNameData: val,
        });
    }

    handleChangeValue = (key, value, field, setEnableDisable = true) => {
        if (field.FDPRFX == '0') {
            if (key.includes("undefined")) {
                key = key.replace("undefined", "");
            }
            key = 'C' + key;
        }
        let temp = { ...this.state.forecastKey, [key]: value }
        this.setState({ forecastKey: temp });
        if (key == 'CWHSE') {
            if (value.trim() == '') {
                this.setState({ disableSubmit: true })
            } else {
                this.setState({ disableSubmit: false })
            }
        }
        if (key == 'TKMETH') {
            if (value == 'A') {
                this.setState({ disableSubmit: false })
                let tempD = { ...this.state.forecastKey, ['CWHSE']: '', [key]: value }
                this.setState({ forecastKey: tempD });
            } else {
                this.setState({ disableSubmit: true })
            }
        }
    }

    onForecastCalculationSubmit = (values) => {
        let updatedValues = {};
        updatedValues['CFCOMP'] = values.CCOMP;
        updatedValues['CFSKFR'] = values.CSKFRZ;
        updatedValues['CFSKMN'] = values.CSKMNL;
        updatedValues['CFUONL'] = values.CFUONL;
        updatedValues['CFIMAN'] = values.CMANUL;
        updatedValues['CFIDIS'] = values.CDISC;
        updatedValues['CFWHSE'] = values.CWHSE;
        updatedValues['TKMETH'] = values.TKMETH;

        updatedValues = this.formatObject(updatedValues);
        const warehouseList = this.props.warehouseDataList;
        const warehouseMList = warehouseList.listArray;
        let warehouseExist = false;
        for (let key in warehouseMList) {
            if (updatedValues.CFWHSE.trim() == warehouseMList[key]['WWHSE'].trim()) {
                warehouseExist = true;
                break;
            }
        }
        if (!warehouseExist && updatedValues['TKMETH'] == 'W') {
            this.setState({ hasError: true })
            this.setState({ errorId: '5163' })
            this.setState({ parameterValues: [updatedValues.CFWHSE.trim()] })
        } else {
            this.props.onForecastCalculationSubmit({ ...updatedValues });
            this.handleSendData(true);
        }
    }

    render() {
        const { classes, saveDisabled, setSaveData, currentPage,
            companyRecordRetentionData, companyRecordRetentionDashboardData, companyForecastFactorsMatrixChangedData,
            companyExceptionControlChangedData, companyPurchaseOrderControlData, companyUdfIDSFields, companyUdfOSSFields,
            companyOrderControlChangedData, companySystemSetupData, companyClassificationData, forecastCalculationLabelsData,
            isShowContextMenu, onContextMenuChange, removeChildCutdownTab, selectedValue, contextMenu, notesCount, freezeComponentStyle } = this.props;
        const { newValueData, newConstrainData, newDashboardData, newOrderDetailData, valueData, showConfirm } = this.props.CompanyPropertiesData;
        return (
            <div className={classes.propertiesHeaderContainer} style={freezeComponentStyle}>
                {(this.state.hasError) ? <div>
                    <GridErrorMessages
                        errorMessageLabels={this.props.errorMessageLabels}
                        popUp
                        sethaserror={this.sethaserror}
                        replaceValues={this.state.parameterValues}
                        id={this.state.errorId ? this.state.errorId : this.props.ServerError}
                    />
                </div> : ''}
                <div className={classes.companyContainer}>
                    <Box className={classes.companyDetailsWrapper}>
                        <Box className={classes.companyDetailRow}>
                            <div className={classes.companyIDSubID}>
                                <div className={classes.companyDetail}>
                                    <div className={classes.companyIDBlock}>
                                        <div className={`${classes.companyDetail} ${classes.companyIdDetails}`}>
                                            <div className={classes.companyLabel}>
                                                {this.getLabelValue(LABEL_COMPANY_ID)}
                                            </div>
                                        </div>
                                        <div className={`${classes.companyDetail} ${classes.companySubCompanyDetails}`}>
                                            <div>{newValueData.CCOMP}</div>
                                        </div>
                                        <div className={`${classes.companyDetail} ${classes.companySubCompanyDetails}`}>
                                            <FieldInput
                                                className={classes.simpleCardInput}
                                                value={this.state.companyNameData}
                                                field={{ key: "CNAME" }}
                                                isCheckWildCard={true}
                                                toUppercase={false}
                                                maxLength={30}
                                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                                                prefixFlag={1}
                                                defaultValue={"0"}
                                                onChange={(key, val) => this.handleChangeCompanyName("CNAME", val)}
                                                isColumnEditable={true}
                                                enableAddButton={e => setSaveData(e)}
                                            />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </Box>
                    </Box>
                    <Box className={classes.companyActions}>
                        <div className={classes.buttonActions}>
                            <div className={isShowContextMenu ? 'showContextMenu' : 'hideContextMenu'}>
                                <BreadcrumbContextMenu
                                    onOptionChange={(e, val) => onContextMenuChange(e, val)} menuItems={contextMenu}
                                    removeChildCutdownTab={removeChildCutdownTab}
                                    selectedValue={selectedValue} />
                            </div>
                        </div>
                        <Button
                            component="div" color="primary" onClick={() => this.onSaveCompanyData(newValueData, newConstrainData, newDashboardData, companyRecordRetentionData,
                                companyRecordRetentionDashboardData, companyForecastFactorsMatrixChangedData, companyExceptionControlChangedData, companyPurchaseOrderControlData,
                                companyUdfIDSFields, companyUdfOSSFields, companyOrderControlChangedData, newOrderDetailData, companySystemSetupData, valueData, companyClassificationData)} disabled={saveDisabled} className={classes.companyActionsFilter}>
                            <SaveIcon fontSize="large" />
                        </Button>
                        <Box className={classes.menuButton}>
                            <div
                                onMouseEnter={(event) => this.setIsOpenActionsContextMenu(event)}
                                onMouseLeave={(event) => this.setIsOpenActionsContextMenu(false)}>
                                <MoreVertIcon color="primary" className="cPointer"></MoreVertIcon>
                                <ContextMenuCreateNew
                                    className={classes.ActionsContextMenu}
                                    menuList={this.state.contextMenuList}
                                    isOpen={this.state.isOpenActionsContextMenu}
                                    menuRef={this.state.menuRef}
                                    handleItemSelection={(val) => this.handleActionSelection(val)}
                                    handleMenuClose={(val) => this.setIsOpenActionsContextMenu(val)}
                                    currentPage={COMPANYS_LIST_PAGE}
                                    currentRecord={valueData}
                                >
                                </ContextMenuCreateNew>
                            </div>
                        </Box>
                        <ConfirmationDialog
                            isOpen={showConfirm}
                            dialogTitle={TEXT_ALERT}
                            submitText={TEXT_OK}
                            handleClose={e => this.handleCloseWarning(false)}
                            handleCancel={e => this.handleCloseWarning(false)}
                            handleSubmit={e => this.handleCloseWarning(false)}>
                            <div>
                                {this.getLabelValue(JOB_SUBMITTED_WARNING)}
                            </div>
                        </ConfirmationDialog>
                    </Box>
                    <Box className={classes.CompanyReferences}>
                        <Button component="div" color="primary" size="small" onClick={e => { document.getElementById("companyNotes").scrollIntoView(); }}>
                            {this.getLabelValue(LABEL_NOTE)}
                        </Button>
                        <Badge color="error" overlap="circle" anchorOrigin={{ vertical: "top", horizontal: "right" }} max={BADGE_MAX_COUNT} badgeContent={notesCount}>
                        </Badge>
                    </Box>
                    {!this.state.open && forecastCalculationLabelsData &&
                        <ForecastCalculation
                            fieldData={forecastCalculationLabelsData.tabcards}
                            valueForm={this.state.forecastKey}
                            currentPage={currentPage}
                            handleChangeValue={this.handleChangeValue}
                            handleDialogClose={(value) => this.handleSendData(value)}
                            errorMessageLabels={this.props.errorMessageLabels}
                            disableSubmit={this.state.disableSubmit}
                            onForecastCalculationSubmit={this.onForecastCalculationSubmit}
                        />
                    }
                    <Modal
                        open={this.state.openNewPlan}
                        onClose={this.handleCloseNewPlan}
                    >
                        <DialogComponent
                            dialogTitle="New Plan"
                            handleCancel={this.handleCancel}
                            handleSubmit={this.handleSubmit}
                            handleNext={this.handleNext}
                            handleClose={this.handleCloseNewPlanAgain}
                            disableSubmit={this.state.disableSubmit}
                            disableNext={this.state.disableNext}
                            isOpen={this.state.isOpen}>

                            <StepperComponent
                                steps={steps}
                                lastActiveStep={this.state.lastActiveStep}
                                activeStep={this.state.activeStep}
                                handleStepChange={this.handleStepChange}
                            >
                            </StepperComponent>
                        </DialogComponent>
                    </Modal>
                </div>
            </div>
        );
    }
}

Header.defaultProps = defaultProps;
Header.propTypes = propTypes;

export default injectIntl(withStyles(style)(withFixedPosition(Header)));

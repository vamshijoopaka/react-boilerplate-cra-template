/** Change Log
 * LogStart --  E3C-33195 - Kumar A- 16 September,2021 - 2022.1.0.0 Unified Product
 *              Story: E3C-33195 --Code Cleanup
*/
export const PURCHASE_ORDER_FACTORS = '50394';
export const COMPANY_RECEIVING_FACTORS = '50395';
export const JOB_CONTROL_FACTORS = '50385';

export const PO_CONTROL_GET_FIELD_LIST = 'PO_CONTROL_GET_FIELD_LIST';
export const PO_CONTROL_GET_FIELD_LIST_SUCCESS = 'PO_CONTROL_GET_FIELD_LIST_SUCCESS';
export const PO_CONTROL_GET_FIELD_LIST_FAILURE = 'PO_CONTROL_GET_FIELD_LIST_FAILURE';

export const PO_CONTROL = 'companyControlFactors';
export const COMPANY_DATA_RESERVED = "VRSRVD";

export const CUSTOM_CARD_ONE = "4434";
export const CUSTOM_CARD_TWO = "4501";
export const CUSTOM_CARD_THREE = "3331";
export const CUSTOM_CARD_FOUR = "4452";

export const LABEL_COMPANY_UDF = "50387";
export const LABEL_COMPANY_OAF = "53377";
export const LABEL_COMPANY_DESCRIPTION = "41377";
export const LABEL_COMPANY_NCF = "33616";
export const LABEL_COMPANY_LENGTH = "33564";
export const LABEL_COMPANY_PRECISION = "33588";
export const LABEL_COMPANY_DV = "50801";
export const LABEL_COMPANY_UOSF = "41394";
export const LABEL_COMPANY_UIDF = "41376";

export const CUSTOM_CARD_KEY = "50916";
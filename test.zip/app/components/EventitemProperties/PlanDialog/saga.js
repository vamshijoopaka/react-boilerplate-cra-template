import { call, put, takeLatest, takeEvery } from 'redux-saga/effects';
import request from 'utils/request';
import UrlFormatUtils from 'utils/sagaUrlFormatter';
import { urlEndPoints } from 'utils/urlJson';
import { OPTIONS } from 'components/common/constants';
import {
  API_URI,
} from 'utils/url';
import {
  getcolumnDefsSuccess,
  getcolumnDefsError,
  updateShowHideSuccess,
  updateShowHideFailure,
  resetDefaultSuccess,
  resetDefaultFailure,
  getVendorListSuccess,
  getVendorListFailure,
  getItemsListSuccess,
  getItemsListFailure,
  getWarehouseListSuccess,
  getWarehouseListFailure,
  getHoldoutsListSuccess,
  getHoldoutsListFailure,
  plansRecalcQtyFailure,
  plansRecalcQtySuccess,
} from './action';
import {
  GET_COLUMN_DEFS,
  UPDATE_SHOW_HIDE_COLUMNS,
  RESET_DEFAULTS,
  GET_WAREHOUSE_LIST,
  GET_VENDOR_LIST,
  GET_ITEMS_LIST,
  GET_HOLDOUTS_LIST,
  PLANS_RECALC,
  PLANS_UPDATE
} from './constants';

// Get header columns
export function* getHeaderCols(action) {
  const url = `${API_URI}/${urlEndPoints.listHeader}`;
  const headerUrl = UrlFormatUtils.formalHeaderUrl(url, action.data.type);
  try {
    const headerCols = yield call(request, headerUrl);
    yield put(getcolumnDefsSuccess(headerCols));
  } catch (err) {
    yield put(getcolumnDefsError(err));
  }
}

export function* updateColumnDefs(action) {
  const url = `${API_URI}/${urlEndPoints.updateListHeader}`;
  const headerUrl = UrlFormatUtils.formalHeaderUrl(
    url,
    action.data.type,
    action.data.userId,
  );
  const postOptions = OPTIONS;
  let headerCols;
  let postData = {};
  if (action.data && action.data.record) {
    postData = action.data.record;
  }
  try {
    postOptions.body = JSON.stringify(postData);
    headerCols = yield call(request, headerUrl, postOptions);
    if (headerCols.ok) {
      const jsonResponse = yield headerCols.text();
      yield put(updateShowHideSuccess(JSON.parse(jsonResponse)));
    }
  } catch (err) {
    yield put(updateShowHideFailure(err));
  }
}

export function* resetDefaults(action) {
  const url = `${API_URI}/${urlEndPoints.listColDefault}`;
  const headerUrl = UrlFormatUtils.formalHeaderUrl(
    url,
    action.data.type,
    action.data.userId,
  );
  let headerCols;
  try {
    headerCols = yield call(request, headerUrl);
    yield put(resetDefaultSuccess(headerCols));
  } catch (err) {
    yield put(resetDefaultFailure(err));
  }
}

export function* getVendorList(action) {
  let url = `${API_URI}/${urlEndPoints.vendorsList}`;
  url = UrlFormatUtils.formatUrlWithFilterAndSortOptions(url, action);
  try {
    let vendors;
    const postOptions = OPTIONS;
    const postData = {};
    if (action.filterProps) {
      postOptions.body = JSON.stringify(postData);
      vendors = yield call(request, url, postOptions);
    }
    if (vendors.ok) {
      const jsonResponse = yield vendors.text();
      const vendorJsonResponse = JSON.parse(jsonResponse);
      yield put(getVendorListSuccess(vendorJsonResponse));
    }
  } catch (err) {
    yield put(getVendorListFailure(err));
  }
}

export function* getItemsList(action) {
  let url = `${API_URI}/${urlEndPoints.itemsList}`;
  url = UrlFormatUtils.formatUrlWithFilterAndSortOptions(url, action);
  try {
    let items;
    const postOptions = OPTIONS;
    const postData = {};
    if (action.filterProps) {
      postOptions.body = JSON.stringify(postData);
      items = yield call(request, url, postOptions);
    }
    if (items.ok) {
      const jsonResponse = yield items.text();
      const itemsJsonResponse = JSON.parse(jsonResponse);
      yield put(getItemsListSuccess(itemsJsonResponse));
    }
  } catch (err) {
    yield put(getItemsListFailure(err));
  }
}
export function* getHoldOutList(action) {
  let url = `${API_URI}/holdouts/list`;
  url = UrlFormatUtils.formatUrlWithFilterAndSortOptions(
    url,
    action.filterProps,
  );
  // let url = `${API_URI}/holdouts/list?listDirection="F"&filterStr='[{"key":"HOCOMP","opr":"=","jOpr":"and","val":"E3T"},{"key":"HOSTOR","opr":"=","jOpr":"and","val":"001"}]'&numberOfRecords="100"`;
  // url = UrlFormatUtils.formatUrlWithFilterAndSortOptions(url, action);
  // url=http://10.0.14.111:4022/AWR/holdouts/list?listDirection="F"&filterStr='[{"key":"HOCOMP","opr":"=","jOpr":"and","val":"E3T"},{"key":"HOSTOR","opr":"=","jOpr":"and","val":"001"}]'&numberOfRecords="100";
  try {
    let holdout;
    const postOptions = OPTIONS;
    const postData = {};
    if (action.filterProps) {
      postOptions.body = JSON.stringify(postData);
      holdout = yield call(request, url, postOptions);
    }
    if (holdout.ok) {
      const jsonResponse = yield holdout.text();
      const holdoutJsonResponse = JSON.parse(jsonResponse);
      yield put(getHoldoutsListSuccess(holdoutJsonResponse));
    }
  } catch (err) {
    yield put(getHoldoutsListFailure(err));
  }
}
export function* getWarehousesList(action) {
  let url = `${API_URI}/${urlEndPoints.warehousesList}`;
  url = `${API_URI}/warehouses/listrpg?listDirection="F"&filterStr='[{"key":"WCOMP","opr":"=","jOpr":"and","val":"E3T"},{"key":"WWHSE","opr":"=","jOpr":"and","val":"${action.value
    }"}]'&numberOfRecords="100"`;
  try {
    let items;
    const postOptions = OPTIONS;
    const postData = {};
    postOptions.body = JSON.stringify(postData);
    items = yield call(request, url, postOptions);
    if (items.ok) {
      const jsonResponse = yield items.text();
      yield put(getWarehouseListSuccess(JSON.parse(jsonResponse)));
    }
  } catch (err) {
    yield put(getWarehouseListFailure(err));
  }
}

export function* plansRecalcQtyData(action) {
  const url = `${API_URI}/plans/recalcQty`;
  try {
    let data;
    const postOptions = OPTIONS;
    const postData = action.data;
    if (action.data) {
      postOptions.body = JSON.stringify(postData);
      data = yield call(request, url, postOptions);
    }
    if (data.ok) {
      const jsonResponse = yield data.text();
      const recalcQtyJsonResponse = JSON.parse(jsonResponse);
      yield put(plansRecalcQtySuccess(recalcQtyJsonResponse));
    }
  } catch (err) {
    yield put(plansRecalcQtyFailure(err));
  }
}

export function* plansDataUpdate(action) {
	let url = `${API_URI}/plans/update`;
	try {
		let data;
		let postOptions = OPTIONS;
		url = UrlFormatUtils.formatUrlWithFilterAndSortOptions(url, action.data);
		let updateRecord = { ...action.data.updateRecord }
    updateRecord['PLPDAT'] = updateRecord['PLPDAT'] ;
    // && getJulianValue(new Date(updateRecord['PLPDAT']));

		let currentRecord = { ...action.data.currentRecord }
    currentRecord['PLPDAT'] = currentRecord['PLPDAT'];
    //  && getJulianValue(new Date(currentRecord['PLPDAT']));
		// currentRecord['BKVNDR'] = '';

		const payload = {
			addAndDeleteFlag: action.data.addAndDeleteFlag,
			updateRecord: updateRecord,
			currentRecord: currentRecord,
		};

		if (action.data) {
			postOptions.body = JSON.stringify(payload);
			data = yield call(request, url, postOptions);
		}
		if (data.ok) {
			const jsonResponse = yield data.text();
			yield put(plansUpdateSuccess(jsonResponse));
		}
	} catch (err) {
		yield put(plansUpdateFailure(err));
	}
}
export default function* detailDialogSaga() {
  yield takeLatest(GET_COLUMN_DEFS, getHeaderCols);
  yield takeLatest(GET_VENDOR_LIST, getVendorList);
  yield takeLatest(GET_ITEMS_LIST, getItemsList);
  yield takeLatest(GET_WAREHOUSE_LIST, getWarehousesList);
  yield takeLatest(GET_HOLDOUTS_LIST, getHoldOutList);
  yield takeLatest(UPDATE_SHOW_HIDE_COLUMNS, updateColumnDefs);
  yield takeLatest(RESET_DEFAULTS, resetDefaults);
  yield takeLatest(PLANS_RECALC, plansRecalcQtyData);
  yield takeLatest(PLANS_UPDATE, plansDataUpdate);

}

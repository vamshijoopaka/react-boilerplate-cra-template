import React from 'react';
import { compose } from 'redux';
import { connect } from 'react-redux';
import { injectIntl } from 'react-intl';
import { withStyles } from '@material-ui/core/styles';
import Form from '../Form/Form';
import { FormControlLabel, Box } from '@material-ui/core';
import FieldInput from '../Form/FieldInput';
import { COLUMN_HEADER_ACCESSOR, COLUMN_USER_SHORT_LABEL, COLUMN_USER_LONG_LABEL, COLUMN_SHORT_LABEL } from '../constants';
import { VENDOR_DATA_RESERVED } from '../../VendorProperties/VendorControlFactors/constants';
// import {MASSMAINTENANCEJOB_DATA_RESERVED} from '../../MassmaintenancejobProperties/constants';
import { getDateFromJulian, getListPredecessor, getJulianValue, checkUpdateRestrictionOnField } from '../../../utils/util';
import { getDateFormatted } from '../Form/dateTimeUtils';
import { createStructuredSelector } from 'reselect';
import MassMaintenance from 'containers/common/MassMaintenance';
import OpenInNewIcon from '@material-ui/icons/OpenInNew';
import { isValidDate } from 'components/common/Form/dateTimeUtils';
import './style.css';
import {
    selectGlobal,
    makeFilterCriteriaDetails,
    makeSelectCurrentUser,
    makeSelectCurrentPage,
    makeColumnDefinitions,
    makeFilterOptions,
    makeGridOptions,
    makePageFilterOptions,
    selectGlobalNumberFormat,
    selectGlobalNumberSeparator,
    selectGlobalDecimalSeparator,
    selectGlobalDateFormat// E3C-30525-Ajit
} from '../Form/selectors';

import {
    GLOBAL_FILTER_OPTIONS,
    COLUMN_VALUE_ACCESSOR
} from 'components/common/constants';
import { isEqual } from 'lodash';
import { getUnformattedValue, getFormattedNumber } from '../../../utils/util';
import PropTypes from 'prop-types';
import CustomizedTooltip from '../CustomizedTooltip';


const defaultProps = {
    noMassMaintenance: false,
    cardHasCheckBox: false,
    labelDisplayCharacters: 20,
    valueDisplayCharacters: 10,
    cardHasDotsBtn: false
};

const propTypes = {
    currentPage: PropTypes.any,
    labelDisplayCharaters: PropTypes.number, // Label character length eg: '10',
    cardHasCheckBox: PropTypes.bool, // true, if card has any field with extra checkbox
    valueDisplayCharacters: PropTypes.number,
    cardHasDotsBtn: PropTypes.bool
};

const labels = [COLUMN_USER_SHORT_LABEL, COLUMN_USER_LONG_LABEL, COLUMN_SHORT_LABEL, COLUMN_HEADER_ACCESSOR];

const style = theme => ({
    fieldExtraActions: {
        display: 'flex',
        alignItems: 'baseline',
        alignSelf: 'flex-end',
    },
    formControl: {
        display: 'flex',
        padding: '5px',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'baseline',
        maxWidth: '28vw',
    },
    simpleCardInput: {
        margin: '0',
        width: '100%',
        '& input': {
            overflow: 'hidden',
            whiteSpace: 'nowrap',
            textOverflow: 'ellipsis',
        },
        '&.error-input:after': {
            borderBottom: '2px solid var(--card-error-border) !important'
        },
        '&.error-input:hover::after': {
            borderBottom: '2px solid var(--card-error-border) !important'
        },
    },
    inputErrorClass: {
        '&.error-icon-pure-css': {
            border: '2px solid var(--card-error-border) !important'
        },
        '&.error-icon-pure-css:after': {
            color: 'var(--card-error-border) !important'
        }
    },
    simpleCardCheckbox: {
        padding: '0'
    },
    simpleCardSelect: {
        width: '100%',
        overflow: 'hidden',
        // paddingRight: '15px',
        '& [class*="MuiSelect-select"]': {
            display: 'inline-block'
        }
    },
    simpleCheckboxCardField: {
        // justifyContent: 'flex-end !important',
    },
    simpleCardField: {
        // width: '100%',
        display: 'flex',
        justifyContent: 'flex-end',
        alignItems: 'center',
        // margin: '0 10px 0 0',
        // maxWidth: '22vw',
        // '@media (max-width : 1024px)': {
        //     flexDirection: 'column-reverse',
        //     alignItems: 'baseline !important',
        //     padding: ' 10px !important',
        // },
        '& label': {
            fontSize: '14px',
            fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
            color: 'var(--text)',
            marginRight: '15px'
        }
    },
    fieldRightMargin: {
        marginRight: '10px !important'
    },
    FormFieldWithMM: {
        position: 'relative',
        display: 'flex',
        alignItems: 'baseline',
        padding: '0 30px 10px 0',
        width: '100%',
    },
    // FormFieldWithoutMM: {
    //     position: 'relative',
    //     display: 'flex',
    //     alignItems: 'baseline',
    //     width: '100%',
    //     paddingBottom: '20px'
    // },
    MassMaintenance: {
        // position: 'absolute',
        cursor: 'pointer',
        height: '18px',
        width: '18px',
        alignSelf: 'flex-end',
        // right: '10px',
        // top: '7px
    },
    simpleCardLabel: {
        minWidth: props => props.labelDisplayCharaters ? ((Number(props.labelDisplayCharaters) + 3) + 'ch') : '23ch',
        maxWidth: props => props.labelDisplayCharaters ? ((Number(props.labelDisplayCharaters) + 3) + 'ch') : '23ch',
    },
    simpleCardLabelEmpty: {
        width: '0',
    },
    simpleCardFieldWithCheckBox: {
        width: '90% !important'
    },
    fieldAdditionalCheckBox: {
        top: '4px',
        marginRight: '8px'
    },
    fieldWrapper: {
        display: 'flex'
    },
    fieldLabel: {
        maxWidth: props => props.labelDisplayCharacters ? props.labelDisplayCharacters + 'ch' : '20ch',
        minWidth: props => props.labelDisplayCharacters ? props.labelDisplayCharacters + 'ch' : '20ch',
        overflow: 'hidden',
        whiteSpace: 'nowrap',
        textOverflow: 'ellipsis',
    },
    fieldInputWithoutLabel: {
        width: '100%',
        '& input': {
            color: 'var(--card-field-value) !important'
        },
        '& [class*="MuiInputBase-input"]': {
            color: 'var(--card-field-value)'
        },
        '& [class*="MuiInput-underline"]:before': {
            borderBottom: '1px solid var(--card-field-value) !important'
        },
        '& [class*="MuiInput-underline"]:hover::before': {
            borderBottom: '2px solid var(--text) !important'
        },
        '& [class*="MuiInput-underline"]:after': {
            borderBottom: '2px solid var(--inputText-value) !important'
        },
    },
    fieldSelect: {
        width: '0'
    },
    fieldInput: {
        // maxWidth: props => 'calc(100% - ' + (props.labelDisplayCharacters ? props.labelDisplayCharacters + 'ch' : '20ch') + ' - 15px' + ')',
        // minWidth: props => 'calc(100% - ' + (props.labelDisplayCharacters ? props.labelDisplayCharacters + 'ch' : '20ch') + ' - 15px' + ')',
        width: props => (props.valueDisplayCharacters + 'ch'),
        '& input': {
            color: 'var(--card-field-value) !important'
        },
        '& [class*="MuiInputBase-input"]': {
            color: 'var(--card-field-value)',
        },
        '& [class*="MuiInput-underline"]:before': {
            borderBottom: '1px solid var(--card-field-value) !important'
        },
        '& [class*="MuiInput-underline"]:hover::before': {
            borderBottom: '2px solid var(--text) !important'
        },
        '& [class*="MuiInput-underline"]:after': {
            borderBottom: '2px solid var(--inputText-value) !important'
        },
        '& [class*="MuiInput-root"]': {
            maxWidth: 'inherit'
        }
    },
    disabledField: {
        '& [class*="MuiInputBase-input"]': {
            color: 'var(--primary-disabled) !important',
        },
        '& [class*="MuiInput-underline"]': {
            pointerEvents: 'none !important'
        },
        // '& label': {
        //     color: 'var(--primary-disabled) !important'
        // },
        '& [class*="MuiInput-underline"]:before': {
            borderBottom: '1px solid var(--primary-disabled) !important'
        },
        '& [class*="MuiInput-underline"]:hover::before': {
            borderBottom: '1px solid var((--primary-disabled) !important'
        },
    },
    width80: {
        // width: '80% !important'
    },
});

class FormFieldComponent extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            showMassMaintenance: false,
            isOpenMassMaintainance: false,
            selectedField: false,
            currentField: false,
            showValueTooltip: false,
            displayValue: {}
        }
        this.getFieldValue = this.getFieldValue.bind(this);
        this.openMassMaintainance = this.openMassMaintainance.bind(this);
        this.clearPopupComponent = this.clearPopupComponent.bind(this);
        this.onValueFocusOut = this.onValueFocusOut.bind(this);
        this.clearMassMaintenance = this.clearMassMaintenance.bind(this);
        this.updateFieldError = this.updateFieldError.bind(this);
        this.handleOnChangeDateValues = this.handleOnChangeDateValues.bind(this);
        this.updatecomponent = this.updatecomponent.bind(this);
        this.clearMMField = this.clearMMField.bind(this);
    }

    componentDidMount() {
        const { field } = this.props;
        this.setState({ currentField: field })
    }

    updateFieldError(field, value) {
        field.hasFormError = value;
        if (!value) {
            setTimeout(() => {
                field.showMassMaintenance = value;
                this.updatecomponent();
            }, 1000);
        } else {
            field.showMassMaintenance = value;
        }
        if (this.props.noMassMaintenance) {
            field.showMassMaintenance = false;
        }
        this.updatecomponent();
        // let fields = this.state.fieldsArray;
        // fields = fields.map(field => {
        //     if (isEqual(field, currentField)) {
        //         field.showMassMaintenance = value;
        //         field['hasFormError'] = value;
        //     }
        //     return field;
        // });
        // this.setState({ fieldsArray: fields });
    }

    getFieldValue(field, dataType) {
        const { valuesArray, globalDateFormat } = this.props;
        // let key = field.key;
        let valueAccessor = COLUMN_VALUE_ACCESSOR;
        if (field[valueAccessor]) {
            let keyValue = field[valueAccessor].trim();
            let key = field.prefixFlag ? keyValue : getListPredecessor(this.props.currentPage) + keyValue;
            // if(valuesArray[key] == '') return valuesArray[key];
            if (key == VENDOR_DATA_RESERVED && valuesArray && valuesArray[key]) {//THIS IS TEMPORARY, DISCUSS FOR RESERVED FIELDS
                return Object.values(valuesArray[key])[0];
            }

            if (dataType == 'number') {
                if (this.state.displayValue[key])
                    return this.state.displayValue[key];
            }


            // if(dataType == 'number'){
            //     if(valuesArray[key]){
            //         if(field.precisionLength){
            //             return (Number(valuesArray[key]).toFixed(field.precisionLength)).toString();
            //         }
            //         return Number(valuesArray[key]).toString();
            //     }
            // }

            // if(field.precisionLength)
            //     return dataType === 'number' ?  Number(valuesArray[key]).toFixed(field.precisionLength) : valuesArray[key];
            // if(valuesArray[key] == undefined) return '';

            return valuesArray[key];
        }
    }

    updatecomponent() {
        this.forceUpdate();
    }

    onValueFocusOut(field, val) {
        this.clearMMField(field);
        let key = field.key;
        let value;
        if (val == '' || !val) {
            value = val;
            if (field.dataType == 'number') {
                if (field.minValue != undefined) {
                    value = field.minValue.toString();
                } else {
                    value = '0';
                }
                if (field.precisionLength) {
                    value = Number(value).toFixed(field.precisionLength);
                    value = getUnformattedValue(value, this.props.globalNumberFormat, this.props.globalNumberSeparator, this.props.globalDecimalSeparator);
                }
            }
            this.handleChangeValue(field.key, value, field, this.props.handleFocusOut);
            return;
        }
        if (key == VENDOR_DATA_RESERVED && val) {//THIS IS TEMPORARY, DISCUSS FOR RESERVED FIELDS
            value = Object.values(val)[0];
            this.handleChangeValue(field.key, value, field, this.props.handleFocusOut);
            return;
        }
        if (field.dataType == 'date' && val) {
            value = JSON.parse(JSON.stringify(getDateFromJulian(val)));
            if (isValidDate(val)) {
                value = getJulianValue(val);
            } else {
                return;
            }
            this.handleChangeValue(field.key, value, field, this.props.handleFocusOut);
            return;
        }
        if (field.precisionLength) {
            if (Number(val).toString() == 'NaN') {
                this.handleChangeValue(field.key, val, field, this.props.handleFocusOut);
                return;
            }
            value = field.dataType === 'number' ? Number(val).toFixed(field.precisionLength) : val;
            this.handleChangeValue(field.key, value, field, this.props.handleFocusOut);
            return;
        }
        if (field.dataType === 'checkbox') {
            value = Number(val);
            this.handleChangeValue(field.key, value, field, this.props.handleFocusOut);
            return;
        }
        if (val == undefined) {
            value = '';
            this.handleChangeValue(field.key, value, field, this.props.handleFocusOut);
            return;
        }
        if (this.props.handleFocusOut) {
            this.props.handleFocusOut(field.key, val, field);
        }
    }

    handleChangeValue = (key, value, field, method) => {
        this.props.handleChangeValue(key, value, field);
        if (method) {
            method(key, value, field)
        }
    }

    clearMMField(field) {
        setTimeout(() => {
            field.showMassMaintenance = false;
            this.updatecomponent();
        }, 1000);
    }

    clearMassMaintenance(currentField, onFocusOut) {
        if (this.props.noMassMaintenance) {
            return;
        }
        if (onFocusOut) {
            this.clearMMField(currentField);
        } else {
            currentField.showMassMaintenance = true;
            this.updatecomponent();
        }
    }

    onFocus(field) {
        this.clearMassMaintenance(field);
        if (!field.hasFormError) {
            this.setState({ selectedField: field });
        }
    }

    openMassMaintainance() {
        this.setState({ isOpenMassMaintainance: true });
    }

    clearPopupComponent() {
        this.setState({ isOpenMassMaintainance: false });

    }

    handleOnChangeDateValues(key, val, field, isCheckBoxValue) {
        let value = val, displayValue = this.state.displayValue;

        if (field.dataType == 'number') {
            //comma seperator code
            // displayValue[key] = val;
            // this.setState({ displayValue });
            // value = getUnformattedValue(val, this.props.globalNumberFormat, this.props.globalNumberSeparator, this.props.globalDecimalSeparator);

            // displayValue[key] = val;
            if (!val.includes(this.props.globalDecimalSeparator) && field.numberType == 'decimal')
                val = val.replaceAll(this.props.globalNumberSeparator, '')
            value = getUnformattedValue(val, this.props.globalNumberFormat, this.props.globalNumberSeparator, this.props.globalDecimalSeparator);
            displayValue[key] = value;
            this.setState({ displayValue });
            //value = getUnformattedValue(val, this.props.globalNumberFormat, this.props.globalNumberSeparator, this.props.globalDecimalSeparator);
            //comma seperator code
        } else {
            displayValue[key] = null;
        }
        this.setState({ displayValue });
        let fieldKey = key;
        if (field.dataType === 'checkbox') {
            value = Number(val);
            this.clearMassMaintenance(field);
            this.setState({ selectedField: field });
        }
        if (field.dataType === 'date') {
            // if (isValidDate(val)) value = getJulianValue(val);
            // if (!isValidDate(val)) return '';
            this.clearMMField(field);
        }

        if (isCheckBoxValue) {
            fieldKey = fieldKey;
        }
        this.props.handleChangeValue(fieldKey, value, field)
    }


    getFieldCheckValue = (field, dataType) => {
        let prefix = getListPredecessor(this.props.currentPage);
        let key = !field.prefixFlag ? prefix + field[COLUMN_VALUE_ACCESSOR].trim() : field[COLUMN_VALUE_ACCESSOR].trim();
        // key = key + 'CB';
        return this.props.valuesArray[key] || false;
    }

    isEllipsisActive = (el) => {
        if (!el) return false;
        return el.offsetWidth < el.scrollWidth
    }
    setShowValueTooltip = (val) => {
        this.setState({ showValueTooltip: val });
    }

    getValueForTooltip = (field, dataType) => {
        const { valuesArray, globalDateFormat } = this.props;
        // let key = field.key;
        let valueAccessor = COLUMN_VALUE_ACCESSOR;
        if (field[valueAccessor]) {
            let keyValue = field[valueAccessor].trim();
            let key = field.prefixFlag ? keyValue : getListPredecessor(this.props.currentPage) + keyValue;
            if (!valuesArray[key]) return "";
            if (dataType == 'date' && valuesArray) {
                let val = getDateFormatted(valuesArray[key], globalDateFormat);
                return val;
            } else if (dataType == 'select') {
                let option = field.valueSuggestionList.find(opt => opt.value === valuesArray[key]);
                return option.label
            } else if (dataType == 'number') {
                return getFormattedNumber(valuesArray[key], this.props.globalNumberFormat, this.props.globalNumberSeparator, field.precisionLength, this.props.globalDecimalSeparator);
            }
            return valuesArray[key];
        }
    }
    getLabelToDisplay = (field, forTooltip) => {
        const { labelDisplayCharacters } = this.props;
        let displayLabel = "";
        for (const label in labels) {
            if (field[labels[label]] && (field[labels[label]].trim() !== '') && !displayLabel.length)
                displayLabel = field[labels[label]].trim();
        }
        if (forTooltip) {
            displayLabel = displayLabel.length > labelDisplayCharacters ? displayLabel : "";
        } else {
            displayLabel = displayLabel.length > labelDisplayCharacters ? displayLabel.substr(0, labelDisplayCharacters) + '...' : displayLabel;
        }
        return displayLabel;
    }

    showHideMassMaintainence = (field) => {
        const { canUpdateComponent } = this.props;
        if (canUpdateComponent && Object.keys(canUpdateComponent) && Object.keys(canUpdateComponent).length) {
            if (canUpdateComponent.update)
                return field.showMassMaintenance && !Boolean(field.disabled);
            else
                return false;
        } else
            return field.showMassMaintenance && !Boolean(field.disabled);
    }

    render() {
        const { classes, className, handleChangeValue,
            enableAddButton, hideLabels, propertiesData, field, globalNumberFormat, globalNumberSeparator, noMassMaintenance, canUpdateComponent,
            cardHasCheckBox, cardHasDotsBtn, globalDecimalSeparator, globalDateFormat } = this.props;
        return (
            <div>
                <Form>
                    {({ errors, onChange, validate, values }) => (
                        <div className={classes.formControl + ' ' + className}>
                            <div className={(classes.FormFieldWithMM) + " formField"}>
                                {/* <FormControlLabel
                                    hasError={field.hasFormError}
                                    className={(hideLabels ? classes.simpleCardLabelEmpty : classes.simpleCardLabel) + ' ' + classes.simpleCardField + ' ' + (field.dataType == 'checkbox' ? classes.simpleCheckboxCardField : "") + ' ' + (this.props.cardHasCheckBox ? classes.simpleCardFieldWithCheckBox : "")}
                                    control={<FieldInput
                                        updateFieldError={(fieldVal, val) => this.updateFieldError(field, val)}
                                        className={field.dataType == 'checkbox' ? classes.simpleCardCheckbox : field.dataType == 'select' ? classes.simpleCardSelect : classes.simpleCardInput}
                                        value={this.getFieldValue(field, field.dataType)}
                                        field={{
                                            type: field.dataType,
                                            options: field.valueSuggestionList ? field.valueSuggestionList : [],
                                            key: field.key
                                        }}
                                        isCheckWildCard={field.isCheckWildCard}
                                        toUppercase={field.toUppercase}
                                        isNegative={field.isNegative}
                                        numberType={field.numberType}
                                        precisionLength={field.precisionLength}
                                        maxLength={field.maxLength}
                                        minValue={field.minValue}
                                        maxValue={field.maxValue}
                                        disabled={Boolean(field.disabled)}
                                        onChange={(key, val) => {
                                            onChange(key, val)
                                                this.handleOnChangeDateValues(key, val, field)
                                        }}
                                        errorMessageLabel={field[COLUMN_HEADER_ACCESSOR]}
                                        onFocus={() => this.onFocus(field)}
                                        onFocusOut={() => this.onValueFocusOut(field, this.getFieldValue(field, field.dataType))}
                                        onBlurMinValidate={(obj) => { enableAddButton(obj.isMinMaxConditionValid) }}
                                        enableAddButton={e => enableAddButton(e)}
                                        globalNumberFormat={globalNumberFormat}
                                        globalNumberSeparator={globalNumberSeparator}
                                    ></FieldInput>}
                                    label={hideLabels ? '' : field[COLUMN_HEADER_ACCESSOR]}
                                    labelPlacement={field.labelPlacement}
                                    title={field[COLUMN_HEADER_ACCESSOR]}
                                /> */}
                                <Box className={classes.fieldWrapper + ' ' + classes.simpleCardField + ' ' + (!noMassMaintenance || cardHasDotsBtn || cardHasCheckBox ? classes.fieldRightMargin : "") + " " + (field.dataType == 'checkbox' ? classes.simpleCheckboxCardField : "")
                                    + " " + ((canUpdateComponent && Object.keys(canUpdateComponent) && Object.keys(canUpdateComponent).length ? !canUpdateComponent.update : Boolean(field.disabled)) ? classes.disabledField : "")}>
                                    {!hideLabels ? <CustomizedTooltip title={this.getLabelToDisplay(field, true)}>
                                        <label className={classes.fieldLabel + " " + (hideLabels ? classes.simpleCardLabelEmpty : classes.simpleCardLabel)}>{this.getLabelToDisplay(field, false)}</label>
                                    </CustomizedTooltip> : ""}
                                    <CustomizedTooltip title={this.isEllipsisActive(document.getElementById(field.key ? field.key : (field[COLUMN_VALUE_ACCESSOR] ? field[COLUMN_VALUE_ACCESSOR].trim() : false))) ? this.getValueForTooltip(field, field.dataType) : ""}>
                                        <div onMouseOver={() => this.setShowValueTooltip(true)}
                                            onMouseOut={() => this.setShowValueTooltip(false)}
                                            className={(hideLabels ? classes.fieldInputWithoutLabel : classes.fieldInput) + ' ' + (field.dataType === 'select' ? classes.fieldSelect : "")}
                                        >
                                            <FieldInput
                                                parentErrorClass={classes.inputErrorClass}
                                                updateFieldError={(fieldVal, val) => this.updateFieldError(field, val)}
                                                className={field.dataType == 'checkbox' ? classes.simpleCardCheckbox : field.dataType == 'select' ? classes.simpleCardSelect : classes.simpleCardInput}
                                                value={this.getFieldValue(field, field.dataType)}
                                                field={{
                                                    type: field.dataType,
                                                    options: field.valueSuggestionList ? field.valueSuggestionList : [],
                                                    key: field.key ? field.key : (field[COLUMN_VALUE_ACCESSOR] ? field[COLUMN_VALUE_ACCESSOR].trim() : ""),
                                                    Attr: field.FDDATR ? field.FDDATR : ' '
                                                }}
                                                isCheckWildCard={field.isCheckWildCard}
                                                toUppercase={field.toUppercase}
                                                isNegative={field.isNegative}
                                                numberType={field.numberType}
                                                precisionLength={field.precisionLength}
                                                maxLength={Number(field.maxLength)}
                                                minValue={field.minValue}
                                                maxValue={field.maxValue}
                                                disabled={canUpdateComponent && Object.keys(canUpdateComponent) && Object.keys(canUpdateComponent).length ? checkUpdateRestrictionOnField(field, this.props.authorizedComponentsList, canUpdateComponent.update) : Boolean(field.disabled)}
                                                onChange={(key, val) => {
                                                    onChange(key, val),
                                                        this.handleOnChangeDateValues(key, val, field)
                                                }}
                                                errorMessageLabel={field[COLUMN_HEADER_ACCESSOR]}
                                                onFocus={() => this.onFocus(field)}
                                                onFocusOut={() => this.onValueFocusOut(field, this.getFieldValue(field, field.dataType))}
                                                onBlurMinValidate={(obj) => { enableAddButton(obj.isMinMaxConditionValid) }}
                                                enableAddButton={e => enableAddButton(e)}
                                                globalNumberFormat={globalNumberFormat}
                                                globalNumberSeparator={globalNumberSeparator}
                                                globalDecimalSeparator={globalDecimalSeparator}
                                                globalDateFormat={globalDateFormat}// E3C-30525
                                            ></FieldInput>
                                        </div>
                                    </CustomizedTooltip>
                                </Box>
                                <div className={classes.fieldExtraActions}>
                                    {field.hasCheckbox ? <FieldInput
                                        className={classes.simpleCardCheckbox + ' ' + classes.fieldAdditionalCheckBox}
                                        value={this.getFieldCheckValue(field, field.dataType)}
                                        field={{
                                            type: 'checkbox',
                                            key: field.key
                                        }}
                                        disabled={canUpdateComponent && Object.keys(canUpdateComponent) && Object.keys(canUpdateComponent).length ? !canUpdateComponent.update : Boolean(field.disabled)}
                                        onChange={(key, val) => {
                                            this.handleOnChangeDateValues(key, val, field, true)
                                        }}
                                    ></FieldInput> : ""}
                                    {this.showHideMassMaintainence(field) && !field.noMassMaintenance ?
                                        (<OpenInNewIcon className={classes.MassMaintenance} onClick={this.openMassMaintainance} />)
                                        : (<div className={classes.MassMaintenance} />)
                                    }
                                </div>
                            </div>
                        </div>
                    )}
                </Form>
                {this.state.isOpenMassMaintainance && this.state.selectedField &&
                    <MassMaintenance
                        handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                        filterCriteriaDetails={this.props.filterCriteriaDetails}
                        pageFilterOptions={this.props.pageFilterOptions}
                        globalFilterOptions={this.props.globalFilterOptions}
                        columnDefs={this.props.columnDefs}
                        currentPage={this.props.currentPage}
                        parentPage={this.props.parentPage}
                        ownerName={this.props.currentOwnerName}
                        isOpen={this.state.isOpenMassMaintainance}
                        field={this.state.selectedField}
                        parentData={this.props.parentData}
                        clearPopupComponent={(val) => this.clearPopupComponent()}
                    >
                    </MassMaintenance>
                }
            </div>
        );
    }
}

const mapStateToProps = createStructuredSelector({
    // currentPage: makeSelectCurrentPage(),
    columnDefs: makeColumnDefinitions(),
    globalFilterOptions: makeFilterOptions(),
    pageFilterOptions: makePageFilterOptions(),
    gridOptions: makeGridOptions(),
    filterCriteriaDetails: makeFilterCriteriaDetails(),
    globalNumberFormat: selectGlobalNumberFormat(),
    globalNumberSeparator: selectGlobalNumberSeparator(),
    globalDecimalSeparator: selectGlobalDecimalSeparator(),
    globalDateFormat: selectGlobalDateFormat()// E3C-30525-Ajit
});

const withConnect = connect(mapStateToProps, null);

FormFieldComponent.propTypes = propTypes;
FormFieldComponent.defaultProps = defaultProps;
export default compose(withConnect, withStyles(style))(FormFieldComponent);
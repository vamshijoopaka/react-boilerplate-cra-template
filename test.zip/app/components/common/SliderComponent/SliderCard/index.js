import React from 'react';
import { Card, Typography } from '@material-ui/core';

const cardStyle = {
  color: '#000000',
  boxShadow: '#aaa',
  opacity: 1,
  textAlign: 'center',
  maxWidth: 400,
  cursor: 'not-allowed',
  background: 'none',
  position: 'relative',
  top: null,
  transform: 'translateY(7%)',
  marginTop: '0px',
  marginBottom: '0px',
  fontWeight: 'bold',
  // ...style,
  width: '100%',
};

class SliderCard extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    return (
      <Card id="testItem" style={cardStyle} className="filterCard">
        <Typography variant="h4" align="center" style={{ color: '#000' }}>
          Test123
        </Typography>
      </Card>
    );
  }
}

export default SliderCard;

/**
 *
 * ItemProperties
 *
 */
/*Changelog
* LogStart -- E3C-33396, 06-Dec-2021, Vamshi - 2022.1.0.0
              Creating Special Account History Option doesnt get refreshed and published on its own;
*/
import { withStyles } from '@material-ui/core';
import AppBar from '@material-ui/core/AppBar';
import Tab from '@material-ui/core/Tab';
import Tabs from '@material-ui/core/Tabs';
import FormattedMessageComponent from 'components/common/FormattedMessageComponent';
import { isEqual } from 'lodash';
import React from 'react';
import { getFilterDataFromLocalStorage, getListPredecessor, prepareValueDataForItems } from 'utils/util';
import { getUpdateRestrictionOnComponent, capitalizeFirstLetter } from 'utils/util';
import { COLUMN_VALUE_ACCESSOR, INITIAL_PAGE_PROPS, ITEMS_LIST_PAGE, GLOBAL_FILTER_OPTIONS, TEXT_ALERT, TEXT_OK, ITEM_PROPERTIES } from '../common/constants';
import {
  DEFAULT_VALUE_URL_DATA, HeaderAPIValuesJSON, LABEL_FORECAST_HISTORY, LABEL_ITEM_DETAIL, LABEL_ITEM_PARAMETERS, LABEL_LIST_URL_DATA, LABEL_MOVEMENT_ACCUMULATION, LABEL_STOCK_STATUS, LABEL_DEMAND_FORECASTING, KEY_DELETE,
  NO_DATA_TO_DISPLAY,
  MULTISOURCE_REASSIGN,
  VENDOR_TRANSFER,
  LABEL_REFORECAST_NPERIOD,
  REFORECAST,
  REFORECAST_NPERIODS,
  REFORECAST_MULT_ITEMS,
  KEY_COPY,
  FAILURE_MESSAGES,
  LABEL_PROJECTIONS,
  BRACKET_LABEL_URL_DATA,
  SUPERSEDE_TO,
  SUPERSEDE_FROM,
  SUBSTITUTE_TO,
  SUBSTITUTE_FROM,
  CONSIST_OF,
  PART_OF,
  ADD_NEW_SPECIAL_ACCOUNT_ID,
  HISTORY_MULTIPLY,
  KEY_POSITION_TO,
  ACTUAL_DAYS,
  WORK_DAYS,
  MATCH_PROFILE,
  KEY_NEW,
  DELETE_EXCEPTION,
  MANAGE_WHSE_DEMAND_HISTORY,
  AWRASR_FORECAST,
  SUPER_TYPE
} from './constants';
import ItemDetail from './ItemDetail';
import StockStatus from './StockStatus';
import ItemParamaters from './ItemParamaters';
import ForecastHistory from './ForecastHistory';
import MovementAccumulation from './MovementAccumulation';
import ItemNotes from './ItemNotes';
import Header from './Header';
import DemandForecasting from './DemandForecasting';
import {
  getDBSelectorFilterValues,
  prepareTooltipValues
} from 'utils/filterData';
import Spinner from '../common/Spinner';
import WarehouseTransfer from 'containers/ItemEmbeddedListContainers/WarehouseTransfer';
import VendorTransferDialog from './ItemDialogs/VendorTransfer';
import MultiSourceVendorAssignDialog from './ItemDialogs/MultiSourceVendorAssignDialog';
import MultiSourceDistributionDialog from './ItemDialogs/MultiSourceDistributionDialog';
import DeleteDialog from './ItemDialogs/DeleteDialog';
import CopyDialog from './ItemDialogs/CopyDialog';
import MultiSourceReassignDialog from 'containers/ItemEmbeddedListContainers/MultiSourceReassign';
import Filter from 'containers/common/Filter';
import ConfirmationDialog from 'components/common/ConfirmationDialog';
import ReforecastNperiod from './ItemDialogs/ReforecastNperiod';
import CreateSpecialAccountHistoryDialog from './DemandForecasting/SpecialAccountHistory/CreateSpecialAccountHistoryDialog';
import HistoryMultiplyPopup from './DemandForecasting/DemandTable/HistoryMultiplyPopup';
import ReforecastMultipleDialog from './ItemDialogs/ReforecastMultiple';
import ItemProjection from './ItemProjection';
import ItemsSuperTypeDialog from './ItemDialogs/SuperType';
import { onChangeContextMenu, updateBreadCrumbContextMenu } from 'utils/contextMenu';
import GridErrorMessages from 'components/common/GridErrorMessages';
import ExceptionDelete from './ItemDialogs/ExceptionDelete';
import ManageWhseDemandHistory from '../../containers/ManageWhseDemandHistory';
import AwrAsrForecastDialog from './ItemDialogs/AwrAsrForecast';
import { getErrorByErrorLevel } from '../../utils/util'; //E3C-33251, 19-Oct-2021, J Vamshi

const style = theme => ({
  propertiesContentWrapper: {
    margin: '10px auto',
    fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
    borderRadius: '4px',
    overflow: 'hidden',
    boxShadow: '0 2px 4px var(--secondary-s10)',
  },
  headerWrapper: {

  },
  showStep: {
		display: 'block'
	},
	hideStep: {
		display: 'none'
	},
});

class ItemProperties extends React.Component {
  constructor() {
    super();
    this.state = {
      tab: 0,
      isSaveDataDisabled: true,
      headerData: false,
      isDataUpdated: false,
      itemName: '',
      columnDefs: {},
      itemDataJSON: [],
      updatedNotes: false,
      notesFilterObj: {},
      canUpdateComponent: false,
      notesCount: 0,
      notesCountWidth: '22px',
      stateData: false,
      graphChecks: {
        salesGraphCheck: "0",
        depletionGraphCheck: "0",
      },
      vendorTransferDialog: false,
      multiSourceReassignDialog: false,
      openWarehousePopup: false,
      openWarehousePopup: false,
      reforecastNPeriod: false,
      newAccountId: null,
      saveSpecialAccount: false,
      historyMultiplyPopupOpen: false,
      isInitialAPICall: true,
      reforecastMultiple: false,
      apiFailureMessages: [],
      reforecastMultiple: false,
      itemSpecialRestrictionsAreSet: false,
      workOrActualDaysLabels: false,
      deleteException: false,
      unCondDiscounts: false,
      currentExcPage: 'items',
      awrasrforecast:false,
    };

    this.setNotesCount = this.setNotesCount.bind(this); //item_notes update notes count
    this.onUpdateItemBrackets = this.onUpdateItemBrackets.bind(this) //Update Item brackets if there is a change
    this.onUpdateItemDiscount = this.onUpdateItemDiscount.bind(this)
    this.toggleActualWorkDays = this.toggleActualWorkDays.bind(this)
    this.isCalendarActive = this.isCalendarActive.bind(this)
    this.unCondDiscounts = this.unCondDiscounts.bind(this)
  }
  //Divami fix for labels
  handleNoDataSets = () => {
    const { history } = this.props;
    const { valueData } = this.props.ItemPropertiesData;
    if (this.state.isDataLoaded) {
      if (valueData && Object.keys(valueData) && Object.keys(valueData).length) {
        //do nothing here
      } else {
        this.closeCurrentTab();
      }
    }
  }
  //Divami fix for labels
  componentDidMount() {
    this.resetValues();
    let currentPage = ITEM_PROPERTIES;
    const {pathname='/items'}=window.location;
    this.setState({currentExcPage:pathname.slice(1)});
    this.props.onLoadCurrentPage(currentPage);
    let currentExcPage = pathname.slice(1) || ITEMS_LIST_PAGE;
    this.props.setIsShowContextMenu(true);
    const isFound = this.setRecordDataValues();
    if (!isFound) {
      if (this.props.location && this.props.location.state) {
        this.props.setCurrentRecord(this.props.location.state.data);
        this.setState({ columnDefs: this.props.location.state.columnDefs });
        const data = this.props.location.state.columnDefs
        if (data) {
          this.setState({ itemDataJSON: data });
        }
        this.setHeaderAndSendAPI(this.props.location.state.data);
      }
    }
    const labelFilters = LABEL_LIST_URL_DATA;
    const simLabelFilters = LABEL_LIST_URL_DATA.map(filter => {
      let row = { ...filter };
      if (row.accessor == 'TRIMBO') {
        row.fieldValue = 'SIMItemUI';
      }
      return row;
    })
    //Divami Fix for loading labels for Items and Orders from labels container
    const { labelsDataFailure, itemPropertiesLabels, itemPropertiesSimLabels, commonLabelsDataFailure } = this.props.commonItemPropertiesData;
    const { trimcommonLabels, trimcommonlabelsDataFailure } = this.props.trimcommonLabelsData;
    if (!itemPropertiesLabels) {
      this.props.getLabelsList({ recordData: labelFilters, currentPage: 'itemproperties', });
    } else {
      this.props.getLabelListSucess(itemPropertiesLabels, 'TrimItemUI');
    }
    if (!itemPropertiesSimLabels) {
      this.props.getLabelsList({ recordData: simLabelFilters, currentPage: 'itemproperties', }, 'SIMItemUI');
    } else {
      this.props.getLabelListSucess(itemPropertiesSimLabels, 'SIMItemUI');
    }
    //Divami Fix for loading labels for Items and Orders from labels container
    this.setState({ isSaveDataDisabled: true });
    const { valueData, pageProps } = this.props.ItemPropertiesData;
    const data = prepareValueDataForItems(DEFAULT_VALUE_URL_DATA, {
      ...valueData,
    });
    const apiObj = this.getApiObj(data, null, ITEM_PROPERTIES, pageProps);
    if (valueData) {
      if (valueData.IPERDF === '12') {
        this.props.getSeasonalityGraphData12({
          data: apiObj,
          profileFraction: valueData.IDEM12,
          profileId: valueData.IDMPRF,
          includePromo: false,
        })
      }
      else
        this.props.getSeasonalityGraphData(apiObj, null, null, null, `${valueData.IDMPRF}`, valueData.IDEM52);
      this.props.getSpecialAccountHistoryData(apiObj);
    }
    //Divami Fix for loading labels for Items and Orders from labels container
    if (!trimcommonLabels) {
      this.props.getTrimCommonJson({ recordData: BRACKET_LABEL_URL_DATA, currentPage: 'itemproperties' });
    } else {
      this.props.getTrimCommonJsonSuccess(trimcommonLabels)
    }
    //Divami Fix for loading labels for Items and Orders from labels container
    let canUpdateComponent = getUpdateRestrictionOnComponent(capitalizeFirstLetter(currentExcPage), this.props.authorizedComponentsList);
    this.setState({ canUpdateComponent })

    if (this.state.canUpdateComponent && this.props.authorizedComponentsList) {
      this.setItemSpecialRestrictions();
    }
    //Divami Fix for loading labels for Items and Orders from labels container
    if (labelsDataFailure || commonLabelsDataFailure || trimcommonlabelsDataFailure) {
      this.setState({ isDataLoaded: true })
      this.handleNoDataSets();
    }
    //Divami Fix for loading labels for Items and Orders from labels container

  }

  //item_notes get Notes count
  setNotesCount(count) {
    if (this.state.notesCount != count) {
      this.setState({ notesCount: count })
      if (count == 9)
        this.setState({ notesCountWidth: '28px' })

      else if (count < 9 && this.notesCountWidth != '22px')
        this.setState({ notesCountWidth: '22px' })
    }
  }

  updatedNotesData = () => {
    this.setState({ updatedNotes: true });
  }

  componentDidUpdate(prevProps, prevState) {
    const { currentRecordData, pageUpDownData, isSaveSuccess, valueData, isValueDataAPICall,
      isValueDataAPIFailure,
      filterProps,
      filterCriteriaDetails,
      itemColumnDefs,
      itemDeleted,
      errorId,
      itemCopied,
      pageProps,
      hasNoPrevNext,
      prevNextApiSuccess,
      currencyConversion,
    } = this.props.ItemPropertiesData;
    //Api Failure Check and Display
    this.setAPIFailureMessages(prevProps, prevState);
    if (currentRecordData && !isEqual(prevProps.ItemPropertiesData.currentRecordData, currentRecordData)) {
      this.setState({ headerData: this.prepareHeaderDataJSON(currentRecordData), });
    }
     //E3C-33251, 19-Oct-2021, J Vamshi: Begin
    if (currentRecordData && +currentRecordData?.EXDATE && currentRecordData?.EXTYPE !== prevProps.ItemPropertiesData.currentRecordData?.EXTYPE) {
      const exceptionType = getErrorByErrorLevel(currentRecordData.EXTYPE);
      exceptionType && this.props.setDataInTabs("displayName", exceptionType);
    }
     //E3C-33251, 19-Oct-2021, J Vamshi: End
    if (this.props.location.search != prevProps.location.search) {
      this.resetValues();
      this.forceUpdateHandler();
      this.setRecordDataValues();
    }


    if (prevProps.authorizedComponentsList !== this.props.authorizedComponentsList) {
      let canUpdateComponent = getUpdateRestrictionOnComponent(capitalizeFirstLetter(ITEMS_LIST_PAGE), this.props.authorizedComponentsList);
      this.setState({ canUpdateComponent });
    }

    if (pageUpDownData && !isEqual(pageUpDownData, prevProps.ItemPropertiesData.pageUpDownData)) {
      this.props.setSelectedRecord(pageUpDownData, ITEMS_LIST_PAGE);
      this.setState({ fromPage: ITEMS_LIST_PAGE });
      this.setHeaderAndSendAPI(pageUpDownData);
      let modifiedData = {
        data: JSON.parse(JSON.stringify(pageUpDownData)),
        fromPage: ITEMS_LIST_PAGE,
        fromParent: false,
        columnDefs: this.state.columnDefs,
      };
      this.props.setDataInTabs('recordData', modifiedData);
      this.props.setStoreKeyValue('pageUpDownData', false);
    }
    if (isSaveSuccess && isSaveSuccess !== prevProps.ItemPropertiesData.isSaveSuccess) {
      this.setState({ isSaveDataDisabled: true });
      this.setHeaderAndSendAPI(currentRecordData);
      this.props.setStoreKeyValue('isSaveSuccess', false);
    }
    if (valueData && !isEqual(valueData, prevProps.ItemPropertiesData.valueData)) {
      this.setState({ headerData: this.prepareHeaderDataJSON(valueData) });
      this.props.setSelectedRecord(valueData, ITEMS_LIST_PAGE);
      this.prepareTooltipData(); //E3C-33251, 19-Oct-2021, J Vamshi
    }

    const keyFields = ['IITEM', 'IWHSE', 'IVNDR', 'ISUBV', 'ICOMP', 'IPERDF', 'IPERDH', 'ISUPER'];
    if (
      valueData &&
      keyFields.some(key => valueData[key] !== prevProps.ItemPropertiesData.valueData[key])) {
      if (valueData?.ICURCD?.trim?.()) {
        const filterProps = [{ accessor: 'CRCD', fieldValue: valueData.ICURCD, prefixFlag: false, operator: '=', }];
        this.props.loadCurrencyConversion({
          filterProps,
          pageProps: { pageSize: 2 },
          direction: true,
          currentPage: 'multicurrency',
        });
      }
      if (!valueData?.ICURCD?.trim?.()) {
        this.props.setStoreKeyValue('currencyConversion', false);
      }
    }
    if (currencyConversion && this.props.companyDetails?.CMCSYS === '0') {
      this.props.setStoreKeyValue('currencyConversion', false);
    }

    if (isValueDataAPICall != prevProps.ItemPropertiesData.isValueDataAPICall && isValueDataAPICall) {
      this.makePrevNextFlagsAPICall(true);
      this.props.setApiValueDataFlag(false);
      if (!this.state.isFiltersChanged) {
        this.setState({
          previousFilterValues: prevProps.ItemPropertiesData.filterProps,
          isInitialAPICall: false,
          bracketsNotesFilterObj: {},
        });
      }
      if (this.state.isFiltersChanged) {
        this.setState({
          openFilterPopup: false,
          isFiltersChanged: false,
          previousFilterValues: prevProps.ItemPropertiesData.filterProps,
          isInitialAPICall: false,
          bracketsNotesFilterObj: {},
        });
      }
    }
    if (isValueDataAPIFailure != prevProps.ItemPropertiesData.isValueDataAPIFailure && isValueDataAPIFailure) {
      if (this.state.isInitialAPICall) {
        this.setState({
          showConfirmationDialog: true,
          hasWarning: true,
          dialogTitle: TEXT_ALERT,
          fromHeaderENG: true,
          dialogBodyId: NO_DATA_TO_DISPLAY,
        })
      }
      this.setState({ isInitialAPICall: false });
      if (this.state.isFiltersChanged) {
        this.setState({ showConfirmationDialog: true });
        this.setState({ hasWarning: true });
        this.setState({ dialogTitle: TEXT_ALERT });
        this.setState({ fromHeaderENG: true });
        this.setState({ dialogBodyId: NO_DATA_TO_DISPLAY });
      }
    }
    if ((JSON.stringify(filterProps) != JSON.stringify(prevProps.ItemPropertiesData.filterProps)) && filterProps && filterProps.length) {
      this.setState({ isFiltersChanged: true });
      this.props.setChildTabFilterProps(filterProps);
      if (!this.state.isInitialAPICall) {
        if (this.state.fromPage != ITEMS_LIST_PAGE && !this.state.hasFiltersChanged) {
          this.setHeaderAndSendAPI(this.state.stateData, this.state.fromPage)
        } else {
          this.makeAPICallForPageUpDown('down', {});
        }
      }
    }
    if (filterCriteriaDetails && (filterCriteriaDetails != prevProps.ItemPropertiesData.filterCriteriaDetails)) {
      this.props.setDataInTabs("defaultFilterInfo", JSON.parse(JSON.stringify(filterCriteriaDetails)));
      if (filterCriteriaDetails && Object.keys(filterCriteriaDetails) && Object.keys(filterCriteriaDetails).length && vendorColumnDefs && vendorColumnDefs.length) {
        let list = getFilterDataFromCriteriaDetails(filterCriteriaDetails, itemColumnDefs, ITEMS_LIST_PAGE);
        if (list && list.length) {
          this.props.setGlobalFilterProps(list);
          this.props.onSetFilterProps(list);
        }
      }
    }
    if (itemDeleted != prevProps.ItemPropertiesData.itemDeleted && itemDeleted) {
      this.props.resetItemDeleteFlag();
    }
    if (errorId && errorId != prevProps.ItemPropertiesData.errorId) {
      this.props.setStoreKeyValue('errorId', false);
      if (['14029', '14030'].includes(errorId)) {
        this.setState({ showConfirmationDialog: true, dialogTitle: '52891', dialogBodyId: 'E' + errorId, hasWarning: true });
      }
      else
        this.setState({ hasError: true, errorId, errorMessage: false });
    }
    if (itemCopied && itemCopied != prevProps.ItemPropertiesData.itemCopied) {
      this.setState({ showConfirmationDialog: true, dialogText: "Item Copied", hasWarning: false, dialogTitle: '52891' });
      this.props.setStoreKeyValue('itemCopied', false);
    }

    if (this.props.ItemPropertiesData.massSuccess != prevProps.ItemPropertiesData.massSuccess) {
      if(this.state.tab!=4 && this.state.tab!=5)
        this.props.resetMassMaintenance()
      this.setHeaderAndSendAPI(this.state.stateData, this.state.fromPage);
    }

    if (!this.state.itemSpecialRestrictionsAreSet && this.state.canUpdateComponent && Object.keys(this.state.canUpdateComponent).length && this.props.authorizedComponentsList.actionsNotAllowed) {
      this.setItemSpecialRestrictions();
    }
    if(this.props.ItemPropertiesData.spclacctActionSuccess != prevProps.ItemPropertiesData.spclacctActionSuccess){
      this.setHeaderAndSendAPI(valueData, this.state.fromPage);
      const data = prepareValueDataForItems(DEFAULT_VALUE_URL_DATA, {
        ...valueData,
      });
      const apiObj = this.getApiObj(data, null, ITEM_PROPERTIES, pageProps);
      this.props.getSeasonalityGraphData(apiObj, null, null, null, `${valueData.IDMPRF}`, valueData.IDEM52);
      this.props.getSpecialAccountHistoryData(apiObj);
    }

    if (hasNoPrevNext && (prevProps.ItemPropertiesData.hasNoPrevNext !== hasNoPrevNext)) {
      this.updatedBracketListData();
      if (this.state.isFiltersChanged
        || this.state.listResetToBegin //E3C-33251, 19-Oct-2021, J Vamshi
      ) {
        this.openNoDataPopUp(true)
        this.state.listResetToBegin && this.setState({ listResetToBegin: false }); //E3C-33251, 19-Oct-2021, J Vamshi
      }
       //E3C-33251, 19-Oct-2021, J Vamshi
      if (this.state.exceptionDeleted) {
        this.makeAPICallForPageUpDown("down", {});
        this.setState({
          listResetToBegin: true,
          exceptionDeleted: false,
        });
      }
    }
    if (prevNextApiSuccess && (prevProps.ItemPropertiesData.prevNextApiSuccess !== prevNextApiSuccess)) {
      this.setState({ openFilterPopup: false });
      this.setState({ isFiltersChanged: false });
    }
  }

  componentDidCatch() {
    this.setState({ hasHardError: true })
  }

  setItemSpecialRestrictions() {
    this.setState({ itemSpecialRestrictionsAreSet: true });
    let canUpdateComponent = { ... this.state.canUpdateComponent }
    this.props.authorizedComponentsList.actionsNotAllowed.forEach(moduleName => {
      if (moduleName == 'ITEMUI_IDA_RESTRICT_FIELDS') {
        canUpdateComponent['ITEMUI_IDA_RESTRICT_FIELDS'] = true; //Attach restrict fields to canUpdateComponent
        return;
      }
      if (moduleName == 'HISTORY_IDS_HISTORY_MULTIPLY') {
        canUpdateComponent['HISTORY_IDS_HISTORY_MULTIPLY'] = true; //Attach restrict fields to canUpdateComponent
        return;
      }
      if (moduleName == 'ITEMUI_IDA_REFORECAST_MULTIPLE') {
        canUpdateComponent['ITEMUI_IDA_REFORECAST_MULTIPLE'] = true; //Attach restrict fields to canUpdateComponent
        return;
      }

    })
    this.setState({ canUpdateComponent });

  }
  getLabelValue = (id) => {
    return <FormattedMessageComponent id={id} />;
  }
  handleChangeTab = (event, value) => {
    this.setState({ tab: value });
    this.props.setDataInTabs("selectedPropertiesTab", value);//Ajit Saving previously visitedtab
  };

  getApiObj = (recordData, record = false, currentPage = ITEM_PROPERTIES, pageProps = false) => {
    let recordObj = false;
    if (record) {
      recordObj = record;
    }
    const apiObj = {
      recordData,
      pageProps,
      direction: pageProps.isForwardDirection,
      record: recordObj,
      currentPage,
      parentPage: ITEMS_LIST_PAGE,
    };
    return apiObj;
  }

  prepareHeaderDataJSON = (obj) => {
    const headerValues = { ...HeaderAPIValuesJSON };
    const prefix = getListPredecessor('items');
    for (let key in headerValues) {
      headerValues[key] = obj[prefix + key] ? obj[prefix + key].trim() : '';
    }
    return headerValues;
  }

  forceUpdateHandler = () => {
    this.forceUpdate();
  }

  setHeaderAndSendAPI = (jsonData) => {
    const data = this.prepareHeaderDataJSON(jsonData);
    this.setState({ headerData: data });
    this.setState({ stateData: jsonData });
    const valueData = prepareValueDataForItems(DEFAULT_VALUE_URL_DATA, jsonData);
    this.sendAPICallForValues(valueData, jsonData);
  }
  sendAPICallForValues = (valueData, jsonData) => {
    const { pageProps } = this.props.ItemPropertiesData;
    this.props.loadItemDetails(this.getApiObj(valueData, null, ITEM_PROPERTIES, pageProps));
    this.props.loadItemMiscDetails(this.getApiObj(valueData, null, ITEM_PROPERTIES, pageProps));
    if (+this.props.companyDetails?.CCSTSW) {
      this.props.loadUserDefinedData(this.getApiObj(valueData, null, ITEM_PROPERTIES, pageProps));
      this.props.loadUserDefinedLabels("UCOMP=E3T");
    }
  }

  setRecordDataValues = () => {
    let isRecordValuesExists = false, isLocalStorageValuesExists = false, isFilterValuesExists = false;
    const { history } = this.props;
    var paramsString = window.location.search;
    if (paramsString && paramsString.length) {
      let paramsArray = paramsString.split("?");
      if (paramsArray && paramsArray.length && paramsArray.length > 1) {
        let params = paramsArray[1].split("&");
        let tabId = params[0].split("=")[1];
        let breadCrumbId = params[1].split("=")[1];
        let localStorageValues = getFilterDataFromLocalStorage(tabId, breadCrumbId);
        if (localStorageValues && Object.keys(localStorageValues) && Object.keys(localStorageValues).length) {
          isLocalStorageValuesExists = true;
          let itemData = localStorageValues.item_data, dbSelectorValues = [];
          if (itemData && itemData.recordData && localStorageValues.childType) {
            this.columnDefData = JSON.parse(JSON.stringify(itemData.recordData.columnDefs))
            this.props.setCurrentRecord(itemData.recordData.data);
            this.setState({ columnDefs: itemData.recordData.columnDefs });
            this.setState({ totalCount: itemData.recordData.totalCount });
            this.setState({ fromPage: itemData.recordData.fromPage });
            this.props.setFromListPage(itemData.recordData.fromPage);
            this.setHeaderAndSendAPI(itemData.recordData.data, itemData.recordData.fromPage);
            isRecordValuesExists = true;
            this.props.setSelectedRecord(false, false);
            if (itemData) {
              if (itemData.dbSelector && itemData.dbSelector.length) {
                dbSelectorValues = JSON.parse(JSON.stringify(itemData.dbSelector));
              }
              if (itemData.filterProps && itemData.filterProps.length) {
                this.setState({ hasFiltersChanged: false });
                isFilterValuesExists = true;
                let values = getDBSelectorFilterValues(dbSelectorValues, itemData.filterProps);
                this.setFilterValuesFromState(values);
              } else if (dbSelectorValues && dbSelectorValues.length) {
                this.setState({ hasFiltersChanged: false });
                isFilterValuesExists = true;
                let dbValues = getDBSelectorFilterValues(dbSelectorValues, []);
                this.setFilterValuesFromState(dbValues);
              }
              if (itemData.sortProps && itemData.sortProps.length) {
                this.setState({ hasSortChanged: false });
                this.props.sendPageSortProps(itemData.sortProps);
                this.props.onSetSortProps(itemData.sortProps);
              } else {
              }
              if (itemData.defaultFilterInfo && Object.keys(itemData.defaultFilterInfo) && Object.keys(itemData.defaultFilterInfo).length) {
                this.props.setDefaultFilterpropsForTabs(itemData.defaultFilterInfo);
              }
              if (itemData.defaultSortInfo && Object.keys(itemData.defaultSortInfo) && Object.keys(itemData.defaultSortInfo).length) {
                this.props.setDefaultSortpropsForTabs(itemData.defaultSortInfo);
              }
              if (itemData.selectedPropertiesTab) {
                this.setState({ tab: itemData.selectedPropertiesTab });//Ajit Saving previously visitedtab
              }
            }
          }

        }
        if (!isLocalStorageValuesExists && tabId && breadCrumbId) {
          history.push({ pathname: '/Dashboard' });
        }
      }
    }

    let filterOptions = GLOBAL_FILTER_OPTIONS;
    const { dbSelector } = this.props;
    if (!isFilterValuesExists) {
      let gbValues = getDBSelectorFilterValues(dbSelector, filterOptions);
      this.setFilterValuesFromState(gbValues);
    }
    return isRecordValuesExists;
  }
  setFilterValuesFromState = (values) => {
    const filterValues = [];
    const { columnDefs } = this.state;
    //E3C-33012 sravanthi 13 jul begin 
    if (window.location.pathname.slice(1).includes('multitieritems')) {
      const colData = columnDefs && columnDefs.length ? columnDefs : this.columnDefData;
      values.forEach(value => {
        const isExists = colData.find(column => column[COLUMN_VALUE_ACCESSOR].trim() == value.accessor);
        //E3C-32025, 7/7/21, Kumar:Start
        const {pathname='/items'}=window.location;
        let currentExcPage = pathname.slice(1) || ITEMS_LIST_PAGE;
        if(currentExcPage.includes('Exception') && value.key == 'ALCT') {
          filterValues.push(value);
        }
        //E3C-32025, 7/7/21, Kumar:End
        if (isExists || value.accessor== "RRWH") {
          filterValues.push(value);
        }
      });
      if (filterValues && filterValues.length) {
        this.props.onSetFilterProps(filterValues);
        this.props.setGlobalFilterProps(filterValues);
        return filterValues;
      }
       //E3C-33012 sravanthi 13 jul end
    } else if ((columnDefs && columnDefs.length) || (this.columnDefData && this.columnDefData.length)) {
      const colData = columnDefs && columnDefs.length ? columnDefs : this.columnDefData;
      values.forEach(value => {
        const isExists = colData.find(column => column[COLUMN_VALUE_ACCESSOR].trim() == value.accessor);
        //E3C-32025, 7/7/21, Kumar:Start
        const {pathname='/items'}=window.location;
        let currentExcPage = pathname.slice(1) || ITEMS_LIST_PAGE;
        if(currentExcPage.includes('Exception') && value.key == 'ALCT') {
          filterValues.push(value);
        }
        //E3C-32025, 7/7/21, Kumar:End
        if (isExists) {
          filterValues.push(value);
        }
      });
      if (filterValues && filterValues.length) {
        this.props.onSetFilterProps(filterValues);
        this.props.setGlobalFilterProps(filterValues);
        return filterValues;
      }
    } else {
      this.props.onSetFilterProps(values);
      this.props.setGlobalFilterProps(values);
      return values;
    }
  }
  resetValues = () => {
    const { ItemPropertiesData } = this.props;
    const itemColumnDefsLoaded = ItemPropertiesData ? ItemPropertiesData.itemColumnDefsLoaded : false
    this.props.setInitialState();
    this.props.setApiValueDataFlag(false);
    this.setState({ isDataLoaded: false });
    this.setState({ updatedBrackets: false });
    this.setState({ updatedNotes: false });
    //Divami Fix for loading labels for Items and Orders from labels container
    if (!itemColumnDefsLoaded) {
      if (!this.props.commonItemPropertiesData?.itemColumnDefs) {
        this.props.getItemsColumnDefs({ type: 'items' });
      } else {
        this.props.getItemsColumnDefsSuccess(this.props.commonItemPropertiesData?.itemColumnDefs)
      }
      //Divami Fix for loading labels for Items and Orders from labels container
    }

    this.setState({ hasHardError: false });
    this.setState({ workOrActualDaysLabels: false });
    this.setState({ itemSpecialRestrictionsAreSet: false });
    this.setState({ listResetToBegin: false }); //E3C-33251, 19-Oct-2021, J Vamshi
  };

  onSaveData = val => {
    const { newValueData, foreignValuesForLocal } = this.props.ItemPropertiesData;
    if (this.validateItemUpdate(newValueData)) {
      for (let key in newValueData) {
        if (typeof newValueData[key] === 'number') {
          newValueData[key] = newValueData[key].toString();
        }
      }

      //validations & Modifications - before save
      //If Qty held = 0 , remove held until date 
      //SCR 6360 - this is the client fix reference no
      newValueData.IOHHDT = (parseInt(newValueData.IOHHDT) > 0 && parseInt(newValueData.IQHELD) > 0) ? newValueData.IOHHDT : "0";
      this.props.updateItemDetails({ ...newValueData, ...foreignValuesForLocal });

      this.onUpdateItemBrackets(); //Update ItemBrackets
      this.onUpdateItemDiscount(); //Update ItemDiscounts
    }
  };
  getApiObjForPageUpDown = (filterData, record, currentPage, pageProps, sortData, pageType) => {
    let recordObj = false
    if (record) {
      recordObj = record;
    }
    let apiObj = {
      sortProps: sortData,
      filterProps: filterData,
      pageProps: pageProps,
      direction: pageProps.isForwardDirection,
      record: recordObj,
      currentPage: currentPage,
      parentPage: ITEMS_LIST_PAGE,
      pageType: pageType
    };
    return apiObj;
  }
  getApiObjForPageUpDownFlags = (filterData, record, currentPage, pageProps, sortData, pageType) => {
    let recordObj = false
    if (record) {
      recordObj = {
        "record": record,
        "flagsOnly": true
      };
    }
    let apiObj = {
      sortProps: sortData,
      filterProps: filterData,
      pageProps: pageProps,
      direction: pageProps.isForwardDirection,
      record: recordObj,
      currentPage: currentPage,
      parentPage: 'items',
      pageType: pageType
    };
    return apiObj;
  }

  //E3C-32025 , 7/6/21, Kumar:Start
  getExceptionRecord = (record) => {
    if (record) {
      if (record.hasOwnProperty('EXDATE')) {
        record.IDATE = record.EXDATE;
      }
      if (record.hasOwnProperty('EXRANK')) {
        record.IRANK = record.EXRANK;
      }
      if (record.hasOwnProperty('EXTYPE')) {
        record.ITYPE = record.EXTYPE;
      }
    }
    return record;
  }
  //E3C-32025 , 7/6/21, Kumar:End

  makeAPICallForPageUpDown = (type, currentRecordData) => {
    const { filterProps, sortProps } = this.props.ItemPropertiesData;
    let data = { ...INITIAL_PAGE_PROPS, pageSize: 3 };
    data.isForwardDirection = type == 'up' ? false : true;
    this.props.pageUpDownAPI(this.getApiObjForPageUpDown(filterProps, this.getExceptionRecord(currentRecordData), ITEMS_LIST_PAGE, data, sortProps)) //E3C-32025 , 7/6/21, Kumar
  }

  makePrevNextFlagsAPICall = flag => {
    const { filterProps, currentRecordData, sortProps } = this.props.ItemPropertiesData; //E3C-32025 , 7/6/21, Kumar:Changed valueData to currentRecordData
    const data = JSON.parse(JSON.stringify(INITIAL_PAGE_PROPS));
    data.isForwardDirection = flag;
    data.pageSize = 3;
    this.props.getPageUpDownFlagApi(
      this.getApiObjForPageUpDownFlags(filterProps, this.getExceptionRecord(currentRecordData), ITEMS_LIST_PAGE, data, sortProps, flag) //E3C-32025 , 7/6/21, Kumar:Changed valueData to currentRecordData
    );
  };
  handleItemHeaderLeftArrowClick = () => {
    const { currentRecordData } = this.props.ItemPropertiesData;
    this.makeAPICallForPageUpDown('down', currentRecordData);
    this.setState({ isSaveDataDisabled: true });
  }

  handleItemHeaderRightArrowClick = () => {
    const { currentRecordData } = this.props.ItemPropertiesData;
    this.makeAPICallForPageUpDown('up', currentRecordData);
    this.setState({ isSaveDataDisabled: true });
  }

  onValid = values => {
    //save validations to be done
    return true;
  };
  validateItemUpdate = (itemDetail) => {
    const { companyDetails = {} } = this.props;
    const { unCondDiscounts } = this.state;
    //Non T/s Profile ID cannot begin with @ when OPT is installed
    if (itemDetail?.ISSPRF?.length && itemDetail.ISSPRF?.startsWith('@') && companyDetails.CTOPS === "1") {
      this.setErrorBanner(true, '6375');
      return false;
    }
    if (!(!+itemDetail.IPMAXI || (itemDetail.IPMINI <= itemDetail.IPMAXI))) {
      this.setErrorBanner(true, '6331');
      return false;
    }
    if (parseFloat(unCondDiscounts.IDSAMT) > 0 && parseFloat(unCondDiscounts.IDSPCT) > 0) {
      this.setErrorBanner(true, '6396');
      return false;
    }
    return true;
  }

  setErrorBanner = (hasError, errorId = false, replaceValues = []) => this.setState({ hasError, errorId, replaceValues })

  updateName = (val, key) => {
    this.setState({ [key]: val });
  };
  handleGraphChecks = (key, value) => {
    this.setState(state => ({ graphChecks: { ...state.graphChecks, [key]: value } }))
  }
  getErrorMessage = (id, replaceValues = false) => {
    const { errorMessageLabels } = this.props;
    if (errorMessageLabels && errorMessageLabels['E' + id]) {
      let errorText = errorMessageLabels['E' + id].MTEXT;
      if (replaceValues && replaceValues.length && errorText.indexOf('%') != -1) {
        replaceValues.forEach((item, index) => {
          index += 1;
          errorText = errorText.replace(`%${index}`, item);
        });
      }
      return errorText;
    }
    else return '';
  }
  handleDialogClose = dialog => {
    this.setState({ [dialog]: false })
  }
  closeVendorTransferDialog = transferedCurrentItem => {
    const { currentRecordData, hasNext } = this.props.ItemPropertiesData;
    let record = currentRecordData;
    if (!hasNext) {
      record = {};
    }
    this.handleDialogClose('vendorTransferDialog');
    if (transferedCurrentItem) {
      this.makeAPICallForPageUpDown('down', record);
      this.setState({ isSaveDataDisabled: true });
    }
    else {
      this.setHeaderAndSendAPI(currentRecordData);
    }
  }
  closeMultiReassignDialog = refreshItem => {
    const { currentRecordData } = this.props.ItemPropertiesData;
    this.handleDialogClose('multiSourceReassignDialog');
    if (refreshItem) {
      this.setHeaderAndSendAPI(currentRecordData);
    }
  }
  closeMultiSourceDistribution = refreshItem => {
    const { currentRecordData } = this.props.ItemPropertiesData;
    this.handleDialogClose('MultiSourceDistribution');
    if (refreshItem) {
      this.setHeaderAndSendAPI(currentRecordData);
    }
  }
  closeMultiSourceAssignment = refreshItem => {
    const { currentRecordData } = this.props.ItemPropertiesData;
    this.handleDialogClose('MultiSourceAssignment');
    if (refreshItem) {
      this.setHeaderAndSendAPI(currentRecordData);
    }
  }
  closeSuperType = refreshItem => {
    const { currentRecordData } = this.props.ItemPropertiesData;
    this.handleDialogClose('superTypeOpen');
    if (refreshItem) {
      this.setHeaderAndSendAPI(currentRecordData);
    }
  }
  handleItemHeaderFilterClick = () => {
    if (this.state.isFiltersChanged && (this.props.ItemPropertiesData.isValueDataAPIFailure || this.props.ItemPropertiesData?.hasNoPrevNext)) {
      this.props.onSetFilterProps(this.state.previousFilterValues);
      this.props.setGlobalFilterProps(this.state.previousFilterValues);
      this.props.setChildTabFilterProps(this.state.previousFilterValues);
      this.setState({ isFiltersChanged: false });
      this.props.setValueDataAPIFailureFlag(false);
    }
    this.setState({ openFilterPopup: !this.state.openFilterPopup, noRecordForFilter: false });
  }
  setSaveData = val => {
    this.setState({ isSaveDataDisabled: !val });
  }
  handleReproject = action => {
    let { valueData } = this.props.ItemPropertiesData;
    let payload = {
      "IACOMP": valueData.ICOMP,
      "IAWHSE": valueData.IWHSE,
      "IAVNDR": valueData.IVNDR,
      "IAITEM": valueData.IITEM
    }
    switch (action) {
      case 'Re-Project':
        this.props.reproject(payload);
        break;
      case 'Re-MADP':
        this.props.remadp(payload);
        break;
    }
  }

  handleReprojectAction = action => {
    switch (action) {
      case 'Re-Project':
        this.handleReproject(action);
        break;
      case 'Re-MADP':
        this.handleReproject(action);
        break;
    }
  }
  handleReforecast = () => {
    let { valueData } = this.props.ItemPropertiesData;
    let payload = {
      "IACOMP": valueData.ICOMP,
      "IAWHSE": valueData.IWHSE,
      "IAVNDR": valueData.IVNDR,
      "IAITEM": valueData.IITEM,
      "IAAPBT": "0"
    }
    this.props.reforecast(payload);
  }
  handleHeaderActionItemSelection = action => {
    const { valueData } = this.props.ItemPropertiesData;
    switch (action) {
      case 'Freeze':
        var freezeObj = { ...valueData, IREVDT: valueData.ILFIDT }
        this.props.updateItemDetails(freezeObj);
        break;
      case 'Thaw':
        var thawObj = { ...valueData, IREVDT: "0" }
        this.props.updateItemDetails(thawObj);
        break;
      case 'WarehouseTransfer':
        this.setState({ openWarehousePopup: true })
        break;
      case VENDOR_TRANSFER:
        this.setState({ vendorTransferDialog: true })
        break;
      case MULTISOURCE_REASSIGN:
        this.setState({ multiSourceReassignDialog: true })
        break;
      case KEY_COPY:
        this.setState({ copyDialog: true });
        break;
      case KEY_DELETE:
        this.setState({ deleteDialog: true });
        if (this.props.ItemPropertiesData.currentRecordData.EXDATE !== "0") {
          this.setState({ deleteException: true })
          this.setState({ deleteDialog: false });
        };
        break;
      case REFORECAST:
        this.handleReforecast();
        break;
      case REFORECAST_NPERIODS:
        this.setState({ reforecastNPeriod: true });
        break;
      case ADD_NEW_SPECIAL_ACCOUNT_ID:
        this.setState({ openSpecialAccountHistoryDialog: true });
        break;
      case MATCH_PROFILE:
        this.matchProfile();
        break;
      // case DELETE_EXCEPTION:
      //   this.setState({ deleteException: true })
      //   break;
      case HISTORY_MULTIPLY:
        this.setState({ historyMultiplyPopupOpen: true });
        break;
      case REFORECAST_MULT_ITEMS:
        this.setState({ reforecastMultiple: true });
        break;
      case AWRASR_FORECAST:
        this.setState({awrasrforecast:true})
        break;  
      case 'UndoWarehouseTransfer':
        var UndoWarehouseTransfer = {
          "IACOMP": valueData.ICOMP,
          "IAWHSE": valueData.IWHSE,
          "IAVNDR": valueData.IVNDR,
          "IAITEM": valueData.IITEM,
          "IAXWHS": "",
          "IAXQTY": "0000000"
        }
        this.props.warehouseTransfer(UndoWarehouseTransfer);
        break;
      case 'MultiSourceAssignment':
        this.setState({ MultiSourceAssignment: true })
        break;
      case 'MultiSourceDistribution':
        this.setState({ MultiSourceDistribution: true })
        break;
      case ACTUAL_DAYS:
      case WORK_DAYS:
        this.setState({ workOrActualDaysLabels: action })
        break;
      case SUPERSEDE_TO:
        this.setState({ superTypeOpen: true, superType: "U", superName: "itemSuperType", superTitle: SUPERSEDE_TO })
        break;
      case SUPERSEDE_FROM:
        this.setState({ superTypeOpen: true, superType: "U", superName: "supersedefrom", superTitle: SUPERSEDE_FROM })
        break;
      case SUBSTITUTE_TO:
        this.setState({ superTypeOpen: true, superType: "B", superName: "substituteto", superTitle: SUBSTITUTE_TO })
        break;
      case SUBSTITUTE_FROM:
        this.setState({ superTypeOpen: true, superType: "B", superName: "substituteFrom", superTitle: SUBSTITUTE_FROM })
        break;
      case CONSIST_OF:
        this.setState({ superTypeOpen: true, superType: "C", superName: "consistsof", superTitle: CONSIST_OF })
        break;
      case PART_OF:
        this.setState({ superTypeOpen: true, superType: "C", superName: "partof", superTitle: PART_OF })
        break;
      case MANAGE_WHSE_DEMAND_HISTORY: 
        this.setState({ isOpenManageWhseDemandHistory: true });break;
    }
    //~~~CreateNewFramework--JVK
    if (action.startsWith('new')) {
      if (action === 'newnote') {
        this.setState({ isOpenNote: true });
        return;
      }
    }
    //~~~CreateNewFramework--JVK
  }

  matchProfile = () => {
    const { ItemPropertiesData } = this.props;
    const { item } = ItemPropertiesData;
    const postData = {
      IACOMP: item.ICOMP,
      IAWHSE: item.IWHSE,
      IAVNDR: item.IVNDR,
      IAITEM: item.IITEM,
      IAXWHS: item.IDCWHS,
      IAXQTY: item.IASQTY,
      IAXVND: item.IORVND,
      IAXSUB: item.IORSUB,
      IAPINC: '',
      IANPER: '000',
      IAHDLT: '0',
      IAETYP: item.IEXTYP,
      IEXGRP: '',
      IAAWHS: '0',
      IAPROF: '',
      IAEVTY: '',
      IAEVNT: '',
      IAAPBT: '',
      IAJDES: '',
    };
    this.props.matchProfile(postData);
  };

  isActionDisabled = (action) => {
    const { valueData, newValueData, chartType } = this.props.ItemPropertiesData;
    const { companyDetails } = this.props;
    //if update is not allowed disable every action.
    if (!this.state.canUpdateComponent?.update)
      return true;
    //E3C30659-apply security restrictions in addition to field check 
    if (valueData) {
      switch (action) {
        case 'Freeze':
          var freeze = (this.state.tab != 0) || (valueData.IREVDT.trim() != "0" || !this.state.canUpdateComponent.update);
          return freeze;
        case 'Thaw':
          var thaw = (this.state.tab != 0) || (valueData.IREVDT.trim() == "0" || !this.state.canUpdateComponent.update);
          return thaw;
        case 'WarehouseTransfer':
          var warehouseTransfer = (this.state.tab != 0) || (valueData.ICHKTR.trim() == "1" || !this.state.canUpdateComponent.update);
          return warehouseTransfer;
        case 'UndoWarehouseTransfer':
          var undoWarehouseTransfer = (this.state.tab != 0) || (valueData.ICHKTR.trim() != "1" || !this.state.canUpdateComponent.update);
          return undoWarehouseTransfer;
        case 'MultiSourceAssignment':
          return (this.state.tab == 4) || false || !this.state.canUpdateComponent.update;
        case 'MultiSourceDistribution':
          return (!Number(valueData.IVMULT) > 0) || !this.state.canUpdateComponent.update;
        case MATCH_PROFILE:
          var matchprofile = !(this.state.tab == 5)
          return matchprofile;
        case 'multiSourceReassign': {
          return !(valueData.IVMULT && +valueData.IVMULT) || !this.state.canUpdateComponent.update;
        }
        case REFORECAST:
          var reforecast = !(this.state.tab == 4 || this.state.tab == 5) || !(newValueData.IFREEZ == '0') || !this.state.canUpdateComponent.update;
          reforecast |= !(companyDetails.CJDATE > newValueData.IFREEZ);
          reforecast |= newValueData.IXFLG1 === 'D';
          return reforecast;
        case REFORECAST_NPERIODS:
          var nPeriod = !(this.state.tab == 4 || this.state.tab == 5) || !this.state.canUpdateComponent.update;
          nPeriod |= !(companyDetails.CJDATE > newValueData.IFREEZ);
          nPeriod |= newValueData.IXFLG1 === 'D';
          return nPeriod;
        case REFORECAST_MULT_ITEMS:
          var multItems = (this.state.tab == 4 || this.state.tab == 5) ? this.state.canUpdateComponent.update ? this.state.canUpdateComponent.ITEMUI_IDA_REFORECAST_MULTIPLE ? true : false : true : true;
          return multItems;
        //Three dot menu options:
        case KEY_COPY:
        case KEY_DELETE:
          return !this.state.canUpdateComponent.update;
        case KEY_POSITION_TO:
          return false;
        case HISTORY_MULTIPLY:
          return this.state.canUpdateComponent.HISTORY_IDS_HISTORY_MULTIPLY ? true : (!this.state.canUpdateComponent.update || this.state.tab !== 5 || chartType !== 'demandtable');

        case ACTUAL_DAYS:
        case WORK_DAYS:
          let calendarActive = this.isCalendarActive();
          return !this.state.canUpdateComponent ? true
            : !this.state.canUpdateComponent.update ? true
              : !(calendarActive && this.state.tab == 0)
        //E3C30659-end
        case SUPER_TYPE:
          var superType;
          if (!valueData.IMSCID && this.state.tab == 5) {
            if (valueData["ISUPER"] == '')
              superType = !(this.state.tab == 5);
          }
          else
            superType = true;
            return superType;
        case SUPERSEDE_TO:
          var supersedeTo;
          if (!valueData.IMSCID && this.state.tab == 5) {
            if (valueData["ISUPER"] == '')
              supersedeTo = !(this.state.tab == 5);
            if (valueData["ISUPER"] == 'U')
              supersedeTo = false;
            if (valueData["ISUPER"] !== '' && valueData["ISUPER"] !== 'U')
              supersedeTo = true;
          } else
            supersedeTo = true;
          return supersedeTo;
        case SUPERSEDE_FROM:
          var supersedeFrom;
          if (!valueData.IMSCID && this.state.tab == 5) {
            if (valueData["ISUPER"] == '')
              supersedeFrom = !(this.state.tab == 5);
            if (valueData["ISUPER"] == 'R')
              supersedeFrom = false;
            if (valueData["ISUPER"] !== '' && valueData["ISUPER"] !== 'R')
              supersedeFrom = true;
          } else
            supersedeFrom = true;
          return supersedeFrom;
        case SUBSTITUTE_TO:
          var substituteTo;
          if (!valueData.IMSCID && this.state.tab == 5) {
            if (valueData["ISUPER"] == '')
              substituteTo = !(this.state.tab == 5);
            if (valueData["ISUPER"] == 'B')
              substituteTo = false;
            if (valueData["ISUPER"] !== '' && valueData["ISUPER"] !== 'B')
              substituteTo = true;
          } else
            substituteTo = true;
          return substituteTo;
        case SUBSTITUTE_FROM:
          var substituteFrom;
          if (!valueData.IMSCID && this.state.tab == 5) {
            if (valueData["ISUPER"] == '')
              substituteFrom = !(this.state.tab == 5);
            if (valueData["ISUPER"] == 'P')
              substituteFrom = false;
            if (valueData["ISUPER"] !== '' && valueData["ISUPER"] !== 'P')
              substituteFrom = true;
          } else
            substituteFrom = true;
          return substituteFrom;
        case CONSIST_OF:
          var consistOf;
          if (!valueData.IMSCID && this.state.tab == 5) {
            if (valueData["ISUPER"] == '')
              consistOf = !(this.state.tab == 5);
            if (valueData["ISUPER"] == 'C')
              consistOf = false;
            if (valueData["ISUPER"] !== '' && valueData["ISUPER"] !== 'C')
              consistOf = true;
          } else
            consistOf = true;
          return consistOf;
        case PART_OF:
          var partOf;
          if (!valueData.IMSCID && this.state.tab == 5) {
            if (valueData["ISUPER"] == '')
              partOf = !(this.state.tab == 5);
            if (valueData["ISUPER"] == 'O')
              partOf = false;
            if (valueData["ISUPER"] !== '' && valueData["ISUPER"] !== 'O')
              partOf = true;
          } else
            partOf = true;
          return partOf;
        case KEY_NEW: return false;
        case "vendorTransfer": {
          return !Boolean(valueData?.IVNDR?.trim()) || this.state.tab !== 0 || !this.state.canUpdateComponent?.update;
        }
        case MANAGE_WHSE_DEMAND_HISTORY: 
          return this.state.tab === 4;
        //E3C-32867 21-jun sravanthi begin
        case "AWR Forecast Allocation to ASR": 
          return this.props.companyDetails.CTOPS=="1"?false:true;
        //E3C-32867 21-jun sravanthi begin  
        default: return false || !this.state.canUpdateComponent.update;
      }
    }
  }

  toggleActualWorkDays = (action, prevActionDays) => {
    //Calendar must be active & Tab = Item Detail & previous Action != current Action, otherwise hide Days action
    let hideAction = action.isHide || false;
    if (action.key == ACTUAL_DAYS || action.key == WORK_DAYS) {
      const { itemMiscData = false } = this.props.ItemPropertiesData;
      hideAction = !prevActionDays ? (action.key == WORK_DAYS) :  //Maintain initial state, Hide work days
        (prevActionDays == action.key) ? true : //Disable previous action
          false; //All conditions met, Enable action 
    }

    return hideAction;
  }

  isCalendarActive = () => {
    const { itemMiscData = false } = this.props.ItemPropertiesData;

    return itemMiscData ? (parseInt(itemMiscData.IMCALI) ||       //Item Calendar Switch
      parseInt(itemMiscData.IMCALV) ||       //Vendor Calendar Switch
      parseInt(itemMiscData.IMCALW)) ? true  //Warehouse Calendar Switch
      : false : false;
  }

  closeDialog = name => () => {
    switch (name) {
      case ADD_NEW_SPECIAL_ACCOUNT_ID: {
        //E3C-33396, 06-Dec-2021, Vamshi: Start
        const { pageProps, currentRecordData, newSplActCreated } = this.props.ItemPropertiesData;
        if (newSplActCreated && this.state.openSpecialAccountHistoryDialog) {
          const valueData = prepareValueDataForItems(DEFAULT_VALUE_URL_DATA, currentRecordData);
          this.props.loadItemMiscDetails(this.getApiObj(valueData, null, ITEM_PROPERTIES, pageProps));
        }
        //E3C-33396, 06-Dec-2021, Vamshi: End
        this.setState({ openSpecialAccountHistoryDialog: false });
        break;
      }
      case HISTORY_MULTIPLY:
        this.setState({ historyMultiplyPopupOpen: false });
        break;
      default:
        break;
    }
  };

  handleItemHeaderSaveClick = () => {
    if (this.state.saveSpecialAccount) {
      const { valueData, pageProps } = this.props.ItemPropertiesData;
      const data = prepareValueDataForItems(DEFAULT_VALUE_URL_DATA, {
        ...valueData,
      });
      const apiObj = this.getApiObj(data, null, ITEM_PROPERTIES, pageProps);
      this.props.saveSpecialAccount(
        this.props.ItemPropertiesData.specialAccountID.rowData,
        apiObj,
      );
      this.setState({
        saveSpecialAccount: false,
      });
    }
  };

  createNewAccountID = accountID => {
    this.setState({
      tab: 5,
      // openSpecialAccountHistoryDialog: false,//E3C-31626 J Vamshi:
      moveToSpecialAccountHistory: true,
    });
    const { ItemPropertiesData } = this.props;
    const { pageProps, seasonalityGraphOptions, valueData } = ItemPropertiesData;
    const { categories, series } = seasonalityGraphOptions;
    const years = series
      .filter(s => !isNaN(parseInt(s.name, 10)))
      .map(s => s.name);
    const data = prepareValueDataForItems(DEFAULT_VALUE_URL_DATA, {
      ...valueData,
    });
    const apiObj = this.getApiObj(data, null, ITEM_PROPERTIES, pageProps);
    this.props.saveNewSpecialAccountID([], apiObj, years, accountID);
    this.props.getSeasonalityGraphData(apiObj, null, null, null, `${valueData.IDMPRF}`, valueData.IDEM52);
    this.props.getSpecialAccountHistoryData(apiObj);
  };

  onAccountIDChange = value => {
    this.setState({
      newAccountId: value,
    });
  };

  handleConfirmationDialog = bodyId => {
    this.setState({
      showConfirmationDialog: false,
      dialogBodyId: false,
      dialogText: false,
      hasWarning: false,
    });
    switch (bodyId) {
      case NO_DATA_TO_DISPLAY:
      case 'E14029':
        //need to close the current Tab
        this.closeCurrentTab();
        break;
    }
  }
  closeCurrentTab = () => {
    this.props.setNoDataCallBackValue(true);
    var paramsString = window.location.search;
    if (paramsString && paramsString.length) {
      let paramsArray = paramsString.split("?");
      if (paramsArray && paramsArray.length && paramsArray.length > 1) {
        let params = paramsArray[1].split("&");
        let tabId = params[0].split("=")[1];
        let breadCrumbId = params[1].split("=")[1];
        this.props.removeCurrentRecordObj(tabId, breadCrumbId);
      }
    }
  }

  openNoDataPopUp = (flag = true) => {
    this.setState({
      showConfirmationDialog: flag,
      hasWarning: flag,
      dialogTitle: flag ? TEXT_ALERT : '',
      dialogBodyId: flag ? 'E154' : '',
      noRecordForFilter: true,
    })
  }

  setChildLoading = name => loading => {
    if (this.state[name] != loading)
      this.setState({ [name]: loading });
  }

  onUpdateItemBrackets = () => {

    const { newItembrackets } = this.props.ItemPropertiesData;
    if (newItembrackets && Object.keys(newItembrackets).length && this.onValid(newItembrackets)) {
      for (let key in newItembrackets) {
        if (typeof newItembrackets[key] === 'number') {
          newItembrackets[key] = newItembrackets[key].toString();
        }
      }
      if ((!isEqual(this.props.ItemPropertiesData.itembrackets, this.props.ItemPropertiesData.newItembrackets))) {
        this.props.updateItemBrackets(newItembrackets);
      }
    }
  }

  updatedBracketListData = () => {
    this.setState({ updatedBrackets: true });
  };

  onUpdateItemDiscount = () => {
    const { itemDiscountObj, onSaveItemParameters } = this.props.ItemPropertiesData;
    let temp = itemDiscountObj;
    temp.unConditionalDiscounts = this.state.unCondDiscounts;
    if (onSaveItemParameters) {
      this.props.updateItemDiscounts(temp); //Update itemDiscounts
    }
  }

  setAPIFailureMessages = (prevProps, prevState) => {
    if (this.state.apiFailureMessages && this.state.apiFailureMessages.length
      && (JSON.stringify(this.state.apiFailureMessages) != JSON.stringify(prevState.apiFailureMessages))) {
      this.showAPIFailureErrorMessages(this.state.apiFailureMessages[0]);
    }
    for (let failureKey in FAILURE_MESSAGES) {
      if (this.props.ItemPropertiesData && this.props.ItemPropertiesData[failureKey] && this.props.ItemPropertiesData[failureKey] !== prevProps.ItemPropertiesData[failureKey]) {
        this.setState(prevState => {
          let newMessage = FAILURE_MESSAGES[failureKey];
          return { apiFailureMessages: prevState.apiFailureMessages.concat(newMessage), failureKey }
        });
        this.props.setStoreKeyValue(failureKey, false);
      }
    }
  }
  showAPIFailureErrorMessages = (message) => {
    this.setState({ showErrorMessageDialog: true });
    this.setState({ dialogTitle: TEXT_ALERT });
    this.setState({ dialogContent: message });
  }
  closeErrorDialog = (failureKey) => {
    this.setState({ showErrorMessageDialog: false, dialogContent: false });
    if (this.state.apiFailureMessages && this.state.apiFailureMessages.length) {
      this.setState(prevState => {
        let apiFailureMessages = [...prevState.apiFailureMessages];
        apiFailureMessages.shift();
        return { apiFailureMessages };
      });
    }
    switch (failureKey) {
      case 'itemDetailAPIFailure':
        this.closeCurrentTab(); break;
      case 'salesDataAPIFailure':
        this.handleGraphChecks('salesGraphCheck', "0"); break;
      case 'depletionDataAPIFailure':
        this.handleGraphChecks('depletionGraphCheck', "0"); break;
      default: break;
    }
  }
  onContextMenuChange = (e, value, check = false, filters = false, title = false) => {
    let defaultFilters = filters;
    let toPage = value;
    let displayName = title;
    onChangeContextMenu(this.props, e, toPage, defaultFilters, displayName);
    this.props.setSelectedValueForTabs('Show Me');
  }
  getLabelFromId = id => {
    const { messages } = this.props;
    if (messages && messages['H' + id]) {
      return messages['H' + id].TLLAB;
    }
    else if (+id) return id;
    else return '';
  }
  unCondDiscounts = data => {
    this.setState({unCondDiscounts: data});
  }
  appendConditionalASR = fields => {
    const { companyDetails: { CTOPS = false } = {} } = this.props;
    if (!CTOPS || CTOPS == "0" || fields?.length)
      return fields;

    const ASRField = {
      FDFNAM: 'SADMD',
      dataType: 'labels',
      TLLAB: this.getLabelFromId('25177'),
    };
    return fields.concat([ASRField]);
  }
   //E3C-33251, 19-Oct-2021, J Vamshi: Begin
  closeDeleteException = (deletedFlag = false) => {
    this.setState({ deleteException: false });
    if (deletedFlag) {
      const { currentRecordData } = this.props.ItemPropertiesData;
      this.makeAPICallForPageUpDown("down", currentRecordData);
      this.setState({ exceptionDeleted: true });
    }
  }
  prepareTooltipData = () => {
    const { valueData, itemColumnDefs } = this.props.ItemPropertiesData;
    const tooltipData = prepareTooltipValues(ITEMS_LIST_PAGE, valueData, itemColumnDefs, 'itemproperties');
    Array.isArray(tooltipData) && tooltipData[0] && this.props.setDataInTabs("toolTipData", tooltipData);
  }
   //E3C-33251, 19-Oct-2021, J Vamshi: End
  render() {
    const {
      globalDateFormat,
      filterCriteriaDetails,
      pageFilterOptions,
      globalFilterOptions,
      columnDefs,
      currentPage,
      messages,
      loadItemBrackets,
      setItemParametersSave,
      resetItemParametersSave,
      loadItemDiscounts,
      updateItemDiscounts,
      authorizedComponentsList,
      isShowContextMenu,
      companyDetails,
    } = this.props;

    const { rowIndex, currentRecordData, valueData, itemMiscData, loading, item, hasPrevious, hasNext, demandForecastingLabelsData, chartType,
      historyMultiplyLabelData,
      itemColumnDefs,
      filterProps,
      sortProps,
      apiInProgress,
      trimCommonLabelJson,
      superTypeLabelData, superDetailLabelData, deleteExceptionsLabels,
      isValueDataAPIFailure,
      apiCallCount,fromListPage,
      addSpecialAccountLabels,//E3C-31626 J Vamshi:
    } = this.props.ItemPropertiesData;
    let deleteExceptionsLabelsArray = [];
    deleteExceptionsLabelsArray.push(deleteExceptionsLabels);
    const { tab,
      vendorTransferDialog,
      multiSourceReassignDialog,
      deleteDialog,
      itemDetailTabLoading,
      itemParametersTabLoading,
      reforecastNPeriod,
      reforecastMultiple,
      copyDialog,
      superTypeOpen,
      deleteException,
    } = this.state;
    if (this.state.hasHardError) {//this enables usesr to atleast navigate to other tab
      return <h2> Oops Something Went Wrong </h2>
    }
    const masterLoader = loading || apiInProgress || itemDetailTabLoading || itemParametersTabLoading
      || !((valueData && itemMiscData) || isValueDataAPIFailure) 
      || apiCallCount;
    let contextMenu = updateBreadCrumbContextMenu(this.props) || [];
    if(currentRecordData && companyDetails){
      contextMenu = contextMenu.map(ele=>{
        if(ele.key=="dependents"){
          if(currentRecordData.IXNUM =="0")
          return {...ele,isDisable:true}
          else 
          //E3C-32866 21-jun sravanthi begin
          return {...ele,isDisable:false}
          //E3C-32866 21-jun sravanthi begin
        }else if(ele.key=="regional"){
          if(currentRecordData.VDRTYP !="W")
          return {...ele,isDisable:true}
          else 
          //E3C-32866 21-jun sravanthi begin
          return {...ele,isDisable:false}
          //E3C-32866 21-jun sravanthi begin
        }else{
          return ele
        }
      })
      if (companyDetails.CDCSYS == "0" || window.location.pathname.slice(1).includes('multitieritems') ||  window.location.pathname.slice(1).includes('outofstockitems')){
        contextMenu=contextMenu.filter(ele=> ele.id !="dependents" && ele.id!="regional" && ele.id!="vendormembers")
      }
   }
    const { classes, ...propsOtherThanClasses } = this.props;
    return (
      <div>
        {this.state.hasError && this.state.errorId ? (
          <div>
            <GridErrorMessages
              errorMessageLabels={this.props.errorMessageLabels}
              popUp
              sethaserror={this.setErrorBanner}
              id={this.state.errorId}
            />
          </div>
        ) : null}
        {(valueData && itemMiscData) ? (
          <div>
            <Header
              {...propsOtherThanClasses}
              contextMenu={contextMenu}
              onContextMenuChange={this.onContextMenuChange}
              isShowContextMenu={isShowContextMenu}
              itemData={[item]}
              handleItemHeaderFilterClick={this.handleItemHeaderFilterClick}
              handleItemHeaderSaveClick={this.onSaveData}
              saveDisabled={this.state.isSaveDataDisabled}
              updateName={() => { }}
              setSaveData={this.setSaveData}
              globalDateFormat={globalDateFormat}
              filterCriteriaDetails={filterCriteriaDetails}
              pageFilterOptions={pageFilterOptions}
              globalFilterOptions={globalFilterOptions}
              columnDefs={columnDefs}
              currentPage={'items'}
              ItemPropertiesData={this.props.ItemPropertiesData}
              hasPrevious={hasPrevious}
              hasNext={hasNext}
              handleHeaderActionItemSelection={this.handleHeaderActionItemSelection}
              isActionDisabled={this.isActionDisabled}
              toggleActualWorkDays={this.toggleActualWorkDays}
              fromListPage={fromListPage}
              handleItemHeaderLeftArrowClick={this.handleItemHeaderLeftArrowClick}
              handleItemHeaderRightArrowClick={this.handleItemHeaderRightArrowClick}
              canUpdateComponent={this.state.canUpdateComponent}
              notesCount={this.state.notesCount}
              notesCountWidth={this.state.notesCountWidth}
              authorizedComponentsList={authorizedComponentsList}
              companyDetails={this.props.companyDetails}
              getLabelFromId={this.getLabelFromId}
            />
            <div className={classes.propertiesContentWrapper}>
              <AppBar position="static" color="default">
                <Tabs
                  value={this.state.tab}
                  onChange={(evt, val) => { this.handleChangeTab(evt, val); }}
                  indicatorColor="primary"
                  textColor="primary"
                  scrollButtons="auto"
                  variant="scrollable"

                >
                  <Tab value={0} label={this.getLabelValue(LABEL_ITEM_DETAIL)} />
                  <Tab
                    value={5}
                    label={this.getLabelValue(LABEL_DEMAND_FORECASTING)}
                  />
                  <Tab value={4} label={this.getLabelValue(LABEL_FORECAST_HISTORY)} />
                  <Tab value={1} label={this.getLabelValue(LABEL_ITEM_PARAMETERS)} />
                  <Tab value={6} label={this.getLabelValue(LABEL_MOVEMENT_ACCUMULATION)} />
                  <Tab value={3} label={this.getLabelValue(LABEL_STOCK_STATUS)} />
                  <Tab value={7} label={this.getLabelValue(LABEL_PROJECTIONS)} />
                </Tabs>
              </AppBar>
              {tab == 0 && (
                <div>
                  <ItemDetail
                    color="primary"
                    ItemPropertiesData={this.props.ItemPropertiesData}
                    rowIndex={rowIndex}
                    itemData={currentRecordData}
                    setValueData={this.props.setValueData}
                    setSaveData={this.setSaveData}
                    globalDateFormat={globalDateFormat}
                    filterCriteriaDetails={filterCriteriaDetails}
                    pageFilterOptions={pageFilterOptions}
                    globalFilterOptions={globalFilterOptions}
                    columnDefs={this.state.columnDefs}
                    currentPage={"items"}
                    getLabelValue={this.getLabelValue}
                    loadItemDetailGraphData={this.props.loadItemDetailGraphData}
                    getApiObj={this.getApiObj}
                    graphChecks={this.state.graphChecks}
                    handleGraphChecks={this.handleGraphChecks}
                    companyDetails={this.props.companyDetails}
                    getErrorMessage={this.getErrorMessage}
                    setChildLoading={this.setChildLoading('itemDetailTabLoading')}
                    canUpdateComponent={this.state.canUpdateComponent}
                    workOrActualDaysLabels={this.state.workOrActualDaysLabels}
                    isCalendarActive={this.isCalendarActive} //function
                    messages={messages}
                    {...propsOtherThanClasses}
                  />
                </div>
              )}
              {tab == 7 && (
                <div>
                  <ItemProjection
                    color="primary"
                    ItemPropertiesData={this.props.ItemPropertiesData}
                    onLoadProjectionData={this.props.onLoadProjectionData}
                    handleReprojectAction={this.handleReprojectAction}
                    handleRemadpAction={this.handleRemadpAction}
                    getProjectionsGraphData={this.props.getProjectionsGraphData}
                    projection={this.props.projection}
                    rowIndex={rowIndex}
                    itemData={currentRecordData}
                    ref="itemControlFactorsReference"
                    setValueData={this.props.setValueData}
                    setSaveData={val => {
                      this.setState({ isSaveDataDisabled: !val });
                    }}
                    globalDateFormat={globalDateFormat}
                    filterCriteriaDetails={filterCriteriaDetails}
                    pageFilterOptions={pageFilterOptions}
                    globalFilterOptions={globalFilterOptions}
                    columnDefs={this.state.columnDefs}
                    currentPage={"items"}
                    canUpdateComponent={this.state.canUpdateComponent}
                    getApiObj={this.getApiObj}
                    getLabelValue={this.getLabelValue}
                    companyDetails={this.props.companyDetails}
                    updateItemDetails={this.props.updateItemDetails}
                    canUpdateComponent={this.state.canUpdateComponent}
                  />
                </div>
              )}
              {tab == 1 && (
                <div>
                  <ItemParamaters
                    color="primary"
                    ItemPropertiesData={this.props.ItemPropertiesData}
                    rowIndex={rowIndex}
                    itemData={currentRecordData}
                    ref="itemControlFactorsReference"
                    setValueData={this.props.setValueData}
                    setBracketValueData={this.props.setBracketValueData} // To set Item Bracket values 
                    setSaveData={val => {
                      this.setState({ isSaveDataDisabled: !val });
                    }}
                    setSaveDataValue={this.setSaveData}
                    globalDateFormat={globalDateFormat}
                    filterCriteriaDetails={filterCriteriaDetails}
                    pageFilterOptions={pageFilterOptions}
                    globalFilterOptions={globalFilterOptions}
                    columnDefs={this.state.columnDefs}
                    currentPage={"items"}
                    messages={messages}
                    loadItemBrackets={loadItemBrackets}
                    setItemParametersSave={setItemParametersSave}
                    resetItemParametersSave={resetItemParametersSave}
                    loadItemDiscounts={loadItemDiscounts}
                    updateItemDiscounts={updateItemDiscounts}
                    canUpdateComponent={this.state.canUpdateComponent}
                    companyDetails={this.props.companyDetails}
                    authorizedComponentsList={authorizedComponentsList}
                    setChildLoading={this.setChildLoading('itemParametersTabLoading')}
                    unCondDiscounts={this.unCondDiscounts}
                    setStoreKeyValue={this.props.setStoreKeyValue}
                  />
                </div>
              )}
              {tab == 3 && (
                <div>
                  <StockStatus
                    color="primary"
                    ItemPropertiesData={this.props.ItemPropertiesData}
                    rowIndex={rowIndex}
                    itemData={currentRecordData}
                    ref="itemControlFactorsReference"
                    setValueData={this.props.setValueData}
                    setSaveData={val => {
                      this.setState({ isSaveDataDisabled: !val });
                    }}
                    globalDateFormat={globalDateFormat}
                    filterCriteriaDetails={filterCriteriaDetails}
                    pageFilterOptions={pageFilterOptions}
                    globalFilterOptions={globalFilterOptions}
                    columnDefs={this.state.columnDefs}
                    currentPage={"items"}
                    getLabelValue={this.getLabelValue}
                    getApiObj={this.getApiObj}
                    getErrorMessage={this.getErrorMessage}
                    messages={messages}
                    canUpdateComponent={this.state.canUpdateComponent}
                    companyDetails={this.props.companyDetails}
                  />
                </div>
              )}
              {tab == 4 && <div></div>}
              {tab == 6 && <div>
                <MovementAccumulation
                  color="primary"
                  ItemPropertiesData={this.props.ItemPropertiesData}
                  rowIndex={rowIndex}
                  itemData={currentRecordData}
                  ref="itemControlFactorsReference"
                  setValueData={this.props.setValueData}
                  setSaveData={val => {
                    this.setState({ isSaveDataDisabled: !val });
                  }}
                  globalDateFormat={globalDateFormat}
                  filterCriteriaDetails={filterCriteriaDetails}
                  pageFilterOptions={pageFilterOptions}
                  globalFilterOptions={globalFilterOptions}
                  columnDefs={this.state.columnDefs}
                  currentPage={"items"}
                  getLabelValue={this.getLabelValue}
                  getApiObj={this.getApiObj}
                  canUpdateComponent={this.state.canUpdateComponent}
                />
              </div>}
              {tab == 4 && <div>
                <ForecastHistory
                  color="primary"
                  companyDetails={this.props.companyDetails}
                  ItemPropertiesData={this.props.ItemPropertiesData}
                  reforecast={this.props.reforecast}
                  rowIndex={rowIndex}
                  itemData={currentRecordData}
                  setValueData={this.props.setValueData}
                  setSaveData={val => {
                    this.setState({ isSaveDataDisabled: !val });
                  }}
                  globalDateFormat={globalDateFormat}
                  filterCriteriaDetails={filterCriteriaDetails}
                  pageFilterOptions={pageFilterOptions}
                  globalFilterOptions={globalFilterOptions}
                  columnDefs={this.state.columnDefs}
                  currentPage={"items"}
                  getLabelValue={this.getLabelValue}
                  loadItemHistDemRecDetails={this.props.loadItemHistDemRecDetails}
                  loadItemHistForRecDetails={this.props.loadItemHistForRecDetails}
                  loadItemHistForFctDetails={this.props.loadItemHistForFctDetails}
                  loadItemHistForOvrDetails={this.props.loadItemHistForOvrDetails}
                  loadCompanyForecastMatrixData={this.props.onLoadCompanyForecastMatrixData}
                  getApiObj={this.getApiObj}
                  canUpdateComponent={this.state.canUpdateComponent}
                  resetMassMaintenance={this.props.resetMassMaintenance}
                  tab={this.state.tab}
                  forecastMethodMetaData={demandForecastingLabelsData?.forecastMethodMetaData}
                  getLabelFromId={this.getLabelFromId}
                  appendConditionalASR={this.appendConditionalASR}
                />
              </div>}

              {/* {tab === 5 ? ( */}
                <div id="demandForecasting" className={tab === 5 ? classes.showStep : classes.hideStep}>
                  <DemandForecasting
                    labelsData={demandForecastingLabelsData}
                    onDemandOptionChange={this.props.onDemandOptionChange}
                    chartType={chartType}
                    openSpecialAccountHistoryDialog={
                      this.state.openSpecialAccountHistoryDialog
                    }
                    onClose={this.closeDialog(ADD_NEW_SPECIAL_ACCOUNT_ID)}
                    {...propsOtherThanClasses}
                    canUpdateComponent={this.state.canUpdateComponent}
                    onChange={name => {
                      this.setState({ isSaveDataDisabled: false, [name]: true });
                    }}
                    openSpecialAccountHistory={this.state.moveToSpecialAccountHistory
                    }
                    setValueData={this.props.setValueData}
                    setSaveData={this.setSaveData}
                    handleHeaderActionItemSelection={this.handleHeaderActionItemSelection}
                    resetMassMaintenance={this.props.resetMassMaintenance}
                    tab={this.state.tab}
                    getLabelFromId={this.getLabelFromId}
                    appendConditionalASR={this.appendConditionalASR}
                  />
                </div>
              {/* ) : null} */}
              {
                vendorTransferDialog &&
                <VendorTransferDialog
                  globalSecurityFilterList={this.props.globalSecurityFilterList}
                  isOpen={true}
                  itemData={valueData}
                  systemDate={this.props.companyDetails ? this.props.companyDetails.CJDATE : '0000000'}
                  closeDialog={this.closeVendorTransferDialog}
                  vendorTransferLabels={this.props.ItemPropertiesData ? this.props.ItemPropertiesData.vendorTransferLabelData : false}
                  getErrorMessage={this.getErrorMessage}
                  errorMessageLabels={this.props.errorMessageLabels}
                />
              }
              {
                multiSourceReassignDialog &&
                <MultiSourceReassignDialog
                  globalSecurityFilterList={this.props.globalSecurityFilterList}
                  isOpen={true}
                  itemData={valueData}
                  closeDialog={this.closeMultiReassignDialog}
                  multiSourceReassignLabels={this.props.ItemPropertiesData ? this.props.ItemPropertiesData.multiSourceReassignLabelData : false}
                  getErrorMessage={this.getErrorMessage}
                  errorMessageLabels={this.props.errorMessageLabels}
                />
              }
              {this.state.openFilterPopup && (
                <Filter
                  filterCriteriaDetails={this.props.filterCriteriaDetails}
                  pageFilterOptions={this.props.pageFilterOptions}
                  globalFilterOptions={this.props.globalFilterOptions}
                  globalSecurityFilterList={this.props.globalSecurityFilterList}
                  currentPage={ITEM_PROPERTIES}
                  isOpen={Boolean(this.state.openFilterPopup)}
                  ownerName={this.props.currentOwnerName}
                  columnDefs={itemColumnDefs}
                  clearPopupComponent={this.handleItemHeaderFilterClick}
                  hasRecordsForFilter={!this.state.noRecordForFilter}
                  showNoDataPopUp={(val) => this.openNoDataPopUp(val)}
                />
              )}
              {reforecastNPeriod &&
                <ReforecastNperiod
                  title={this.getLabelValue(LABEL_REFORECAST_NPERIOD)}
                  isOpen={reforecastNPeriod}
                  data={valueData}
                  labelData={this.props.ItemPropertiesData ? this.props.ItemPropertiesData.reforecastNperiodsData : false}
                  closeDialog={(val) => this.handleDialogClose('reforecastNPeriod')}
                  currentPage="itemProperties"
                  reforecast={this.props.reforecast}
                />}
              {reforecastMultiple &&
                <ReforecastMultipleDialog
                  period={this.props.ItemPropertiesData ? this.props.ItemPropertiesData.reforecastNperiodsData : false}
                  labelData={this.props.ItemPropertiesData ? this.props.ItemPropertiesData.reforecastMultipleLabels : false}
                  title={this.getLabelValue("25685")}
                  confirmationTitle={this.getLabelValue("52891")}
                  namespace={"items"}
                  handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                  filterCriteriaDetails={this.props.filterCriteriaDetails}
                  pageFilterOptions={this.props.pageFilterOptions}
                  globalFilterOptions={this.props.globalFilterOptions}
                  columnDefs={this.props.columnDefs}
                  currentPage={this.props.currentPage}
                  parentPage={"items"}
                  ownerName={this.props.currentOwnerName}
                  isOpen={this.state.reforecastMultiple}
                  field={this.state.selectedField}
                  parentData={valueData}
                  reforecast={this.props.reforecast}
                  reforecastSelectAll={this.props.reforecastSelectAll}
                  errorMessageLabels={this.props.errorMessageLabels}
                  getErrorMessage={this.getErrorMessage}
                  closeDialog={(val) => this.handleDialogClose('reforecastMultiple')}
                />
              }
              {superTypeOpen &&
                <ItemsSuperTypeDialog
                  getLabelValue={this.getLabelValue}
                  superTypeLabelData={superTypeLabelData}
                  superDetailLabelData={superDetailLabelData}
                  title={this.state.superTitle}
                  isOpen={this.state.superTypeOpen}
                  superName={this.state.superName}
                  superType={this.state.superType}
                  item={valueData}
                  errorMessageLabels={this.props.errorMessageLabels}
                  getErrorMessage={this.getErrorMessage}
                  closeDialog={this.closeSuperType} 
                  canUpdateComponent={this.state.canUpdateComponent}/>
              }
              {this.state.openWarehousePopup && (
                <WarehouseTransfer
                  openWarehousePopup={this.state.openWarehousePopup}
                  valueData={this.props.ItemPropertiesData.valueData}
                  closeDialog={() => this.handleDialogClose('openWarehousePopup')}
                  errorMessageLabels={this.props.errorMessageLabels}
                  warehouseTransferAction={this.props.warehouseTransfer}
                />)
              }
              {this.state.MultiSourceAssignment && this.props.ItemPropertiesData.multiSourceLabelsData && (
                <MultiSourceVendorAssignDialog
                  globalSecurityFilterList={this.props.globalSecurityFilterList}
                  isOpen={true}
                  itemData={valueData}
                  multiSourceLabelsData={this.props.ItemPropertiesData.multiSourceLabelsData}
                  getLabelValue={this.getLabelValue}
                  errorMessageLabels={this.props.errorMessageLabels}
                  valueData={this.props.ItemPropertiesData.valueData}
                  closeDialog={this.closeMultiSourceAssignment}
                  updateItemDetails={this.props.updateItemDetails}
                />)
              }
              {this.state.MultiSourceDistribution && this.props.ItemPropertiesData.multiSourceLabelsData && (
                <MultiSourceDistributionDialog
                  globalSecurityFilterList={this.props.globalSecurityFilterList}
                  isOpen={true}
                  itemData={valueData}
                  multiSourceOrderDeatailLabelsData={this.props.ItemPropertiesData.multiSourceOrderDeatailLabelsData}
                  balanceDetails={this.props.ItemPropertiesData.balanceDetails}
                  getLabelValue={this.getLabelValue}
                  errorMessageLabels={this.props.errorMessageLabels}
                  valueData={this.props.ItemPropertiesData.valueData}
                  closeDialog={this.closeMultiSourceDistribution}
                  updateItemDetails={this.props.updateItemDetails}
                  pageProps={this.props.ItemPropertiesData.pageProps}
                  loadItemDetails={this.props.loadItemDetails}
                />)
              }
              {deleteDialog && (
                <DeleteDialog
                  closeDialog={() => this.handleDialogClose('deleteDialog')}
                  namespace="itemsDelete"
                  itemData={currentRecordData}
                  deleteItems={this.props.deleteItems}
                  currentPage={ITEMS_LIST_PAGE}
                  getLabelValue={this.getLabelValue}
                  parentFilters={filterProps}
                  parentSort={sortProps}
                />
              )}

              {deleteException && (
                <ExceptionDelete
                  open={Boolean(deleteException)}
                  loading={this.props.loading}
                  closeDeleteException={this.closeDeleteException} //E3C-33251, 19-Oct-2021, J Vamshi
                  itemDataRecord={item}
                  propertiesData={deleteExceptionsLabelsArray}
                  currentRecordData={currentRecordData}
                />)}

              {copyDialog && (
                <CopyDialog
                  closeDialog={() => this.handleDialogClose('copyDialog')}
                  itemData={currentRecordData}
                  copyItems={this.props.copyItems}
                  currentPage={ITEMS_LIST_PAGE}
                  getLabelValue={this.getLabelValue}
                  isOpen={copyDialog}
                  copyLabels={this.props.ItemPropertiesData ? this.props.ItemPropertiesData.copyItemsLabelData : {}}
                />
              )}
            </div>
            <div id="itemNotes">
              {valueData && columnDefs || this.state.columnDefs?
                <ItemNotes currentPage={ITEMS_LIST_PAGE}
                  noteLabelJson={trimCommonLabelJson}
                  bracketsNotesFilterObj={this.state.bracketsNotesFilterObj}
                  fromPage={ITEMS_LIST_PAGE}
                  currentRecordData={valueData}
                  updatedNotesData={this.updatedNotesData}
                  canUpdateComponent={this.state.canUpdateComponent}
                  //Security
                  /* Dispatch notes count from child to Parent to show it on header */
                  setNotesCount={this.setNotesCount}
                  //~~~CreateNewFramework--JVK
                  isOpenNote={this.state.isOpenNote}
                  closeNote={(flag) => this.setState({ isOpenNote: flag })}
                  //~~~CreateNewFramework--JVK
                  columnDefs={columnDefs || this.state.columnDefs} />
                : null
              }
            </div>
          </div>

        ) : null}
        <Spinner loading={masterLoader} type="list" />
        <CreateSpecialAccountHistoryDialog
          open={this.state.openSpecialAccountHistoryDialog}
          onClose={this.closeDialog(ADD_NEW_SPECIAL_ACCOUNT_ID)}
          title={ADD_NEW_SPECIAL_ACCOUNT_ID}
          onSubmit={this.createNewAccountID}
          onAccountIDChange={this.onAccountIDChange}
          //E3C-31626 J Vamshi:Begin
          addSpecialAccountLabels={addSpecialAccountLabels}
          newSplActCreated={this.props.ItemPropertiesData.newSplActCreated}
          resetCreatedFlag={() => this.props.setStoreKeyValue('newSplActCreated', false)}
          //E3C-31626 J Vamshi:End
        />
        {this.state.historyMultiplyPopupOpen ?
          <HistoryMultiplyPopup
            isOpen={this.state.historyMultiplyPopupOpen}
            onClose={this.closeDialog(HISTORY_MULTIPLY)}
            card={historyMultiplyLabelData ? historyMultiplyLabelData : {}}
            historyMultiply={this.props.historyMultiply}
            valueData={valueData}
            warehouseDetails={this.props.ItemPropertiesData.warehouseDetails}
          />
          : null
        }
        {
          this.state.isOpenManageWhseDemandHistory ?
          <ManageWhseDemandHistory 
            parentPage={ITEMS_LIST_PAGE}
            currentRecord={valueData}
            closeDialog={() => this.handleDialogClose('isOpenManageWhseDemandHistory')}
            companyDetails={companyDetails}
            errorMessageLabels={this.props.errorMessageLabels}
          />
          : null
        }
        {
          this.state.awrasrforecast ?
            <AwrAsrForecastDialog
              isOpen={this.state.awrasrforecast}
              card={this.props.ItemPropertiesData.asrawrforecastLabelData ? this.props.ItemPropertiesData.asrawrforecastLabelData : {}}
              workingRowData={this.props.ItemPropertiesData.filterProps}
              filterableColumnsList={this.props.ItemPropertiesData.itemColumnDefs}
              itemData={currentRecordData}
              closeDialog={() => this.handleDialogClose('awrasrforecast')}
            />
            : null
        }
        {!masterLoader && this.state.showConfirmationDialog && <ConfirmationDialog
          hasWarning={this.state.hasWarning}
          isOpen={this.state.showConfirmationDialog}
          dialogTitle={this.state.dialogTitle}
          submitText={TEXT_OK}
          handleClose={e => this.handleConfirmationDialog(false)}
          handleCancel={e => this.handleConfirmationDialog(false)}
          handleSubmit={e => this.handleConfirmationDialog(this.state.dialogBodyId)}
        >
          <div>
            {this.state.fromHeaderENG && this.getLabelValue(this.state.dialogBodyId) /*To display Text from English_XXX.json*/}
            {!this.state.fromHeaderENG && this.state.dialogText ? this.state.dialogText : null /*To display Plain Text*/}
            {!this.state.fromHeaderENG && !this.state.dialogText && this.props.errorMessageLabels &&
              (this.props.errorMessageLabels[this.state.dialogBodyId] ?
                this.props.errorMessageLabels[this.state.dialogBodyId].MTEXT : 'Warning') /*To display Text from Error_XXX.json*/}
          </div>
        </ConfirmationDialog>
        }
        {!masterLoader && this.state.showErrorMessageDialog ?
          <ConfirmationDialog
            hasError={this.state.hasWarning}
            isOpen={this.state.showErrorMessageDialog}
            dialogTitle={this.state.dialogTitle}
            submitText={TEXT_OK}
            handleClose={e => this.closeErrorDialog(false)}
            handleCancel={e => this.closeErrorDialog(false)}
            handleSubmit={e => this.closeErrorDialog(this.state.failureKey)}
          >
            <div>
              {this.state.dialogContent}
            </div>
          </ConfirmationDialog>
          : null
        }
      </div>
    );
  }
}

ItemProperties.propTypes = {};

export default withStyles(style)(ItemProperties);
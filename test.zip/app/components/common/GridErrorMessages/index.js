import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { compose } from 'redux';
import { injectIntl, intlShape, FormattedMessage } from 'react-intl';
import './style.css';
import ErrorImage from '-!react-svg-loader!../../../images/error_outline.svg';
import CloseImage from '../../../images/close_icon.png';
import CloseIcon from '@material-ui/icons/Close';


class GridErrorMessages extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      popUp: true
    }
    this.formatDisplayLabel = this.formatDisplayLabel.bind(this);
    this.replacePercentValues = this.replacePercentValues.bind(this);
    this.handleClose = this.handleClose.bind(this);
  }

  handleClose(event) {
    this.setState({ popUp: false });
    if(this.props.sethaserror)
      this.props.sethaserror(false);
  }

  getDispalyLabel = label => {
    if (this.props.toUpperCase) return label.toUpperCase();
    label = this.formatDisplayLabel(label);
    return label;
  }
  componentDidUpdate(prevprops,prevstate){
    if(prevstate.popUp==false)
    this.setState({ popUp: true });
  }

  replacePercentValues(value) {
    const len = value.split('%');
    const charLength = len - 1;
    if (this.props.replaceValues && this.props.replaceValues.length) {
      this.props.replaceValues.forEach((item, index) => {
        index += 1;
        value = value.replace(`%${index}`, item);
      });
    }
    return value;
  }

  formatDisplayLabel(label) {
    if (label && label.indexOf('%') != -1) {
      return this.replacePercentValues(label);
    }
    return label;
  }

  render() {
    const { errorMessageLabels, id } = this.props;
    const key = 'E' + id;
    let label = ''; // errorMessageLabels ? this.getDispalyLabel(errorMessageLabels[key]['MMTYP'].trim())+"! " : '';
    label += errorMessageLabels ? this.getDispalyLabel(errorMessageLabels[key]?.MTEXT.trim()) : '';
    return (
      <div style={{ position: "relative", top: "10px", left: "0", right: "0" }}>
        {errorMessageLabels && this.state.popUp ? (
          <div className="server-error-message" >
            <div className="server-error-message-icon">
              <div className="error-icon">
                <ErrorImage className="server__error__message__icon" />
              </div>
            </div>
            <div className="server-error-message-text">
              <p>{label}</p>
            </div>
            <div className="server-error-message-close">
            <CloseIcon className="error-icon-close"
                  onClick={e => this.handleClose(e)} />
              {/* <img
                className="error-icon-close"
                src={CloseImage}
                onClick={e => this.handleClose(e)}
              /> */}
            </div>
          </div>
        ) : (
            ''
          )}
      </div>
    );
  }
}

// const mapStateToProps = function(state) {
//   return {
//     messages: selectMessages(state),
//   };
// };

// const withConnect = connect(
//   mapStateToProps,
//   null,
//   null,
//   // {context: store}
// );

// export default compose(
//   withConnect 
// )(GridErrorMessages);

export default GridErrorMessages;
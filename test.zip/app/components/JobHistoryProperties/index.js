
/*
* * //==========================================================================
*
* * // Copyright 2021-2021, Blue Yonder Group, Inc.
*
* * // All Rights Reserved
*
* * //
*
* * // THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF
*
* * // BLUE YONDER GROUP, INC.
*
* * //
*
* * //
*
* * // The copyright notice above does not evidence any actual
*
* * // or intended publication of such source code.
*
* * //
*
* * // ===========================================================================
/* *******************************PATCH HISTORY******************************** */

/** Change Log
 * LogStart --  E3C-33297 - Thanuja - 25 August,2021 - 2022.1.0.0 Unified Product
 *              Story: E3C-33297 --MM undo issue
**/


/* E3C-33266 - SRK - AWR WEB UI graphs have hardcoded English labels
                     Removed hardcoding and retrieved label based on ID. 
                     (10-Nov-2021)
* * // ===========================================================================
*/

import React from 'react';
import Typography from '@material-ui/core/Typography';
import { Paper, Box, Button } from '@material-ui/core';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import TableContainer from '@material-ui/core/TableContainer';
import FieldInput from 'components/common/Form/FieldInput';
import ConfirmationDialog from 'components/common/ConfirmationDialog';
import {
	getListPredecessor,
	prepareValueDataForMassmaintenancejobs,
	setSortDataFromSortCriteria,
	getFilterDataFromLocalStorage,
	getFilterDataFromCriteriaDetails,
	getDateFormatValue,
	getExportAPiBody,
	getUpdateRestrictionOnComponent,
	capitalizeFirstLetter
} from 'utils/util';

import { withStyles } from '@material-ui/core';
import Filter from 'containers/common/Filter';
import FormattedMessageComponent from 'components/common/FormattedMessageComponent';

import {
	getDBSelectorFilterValues,
	prepareTooltipValues
} from 'utils/filterData';

import{ MAX_LENGTH_OF_REPORT_NAME} from "containers/common/Export/constants";
import {
	HeaderAPIValuesJSON,
	DEFAULT_VALUE_URL_DATA,
	EQUALS_TO, GREATER_THAN,
	GREATER_THAN_OR_EQUALS_TO,
	LESS_THAN, LESS_THAN_OR_EQUALS_TO,
	NOT_EQUALS_TO,
	REPORT_NAME,
	MAX_JOB_STATUS_CALL_COUNT,
	JOB_STATUS_API_INTERVAL
} from './constants';

import {
	JOBHISTORY_LIST_PAGE,
	JOBHISTORY_PROPERTIES_PAGE,
	INITIAL_PAGE_PROPS,
	COLUMN_VALUE_ACCESSOR,
	GLOBAL_FILTER_OPTIONS,
	TEXT_ALERT, TEXT_OK, TEXT_CANCEL,JOBHISTORY_FILTER_OPTIONS
} from '../common/constants';

import { isEqual } from 'lodash';
import Spinner from '../common/Spinner';
import './styles.scss';
import { updateBreadCrumbContextMenu, onChangeContextMenu } from 'utils/contextMenu';
import Header from './Header';
import AppBar from '@material-ui/core/AppBar';
import Tab from '@material-ui/core/Tab';
import Tabs from '@material-ui/core/Tabs';
import LogList from 'containers/LogList';
import DialogComponent from '../common/DialogComponent';
import { preProcParseBO, postProcParseBO, planPostProcParseBO, planPreProcParseBO,} from './preprocessingBO';

function TabContainer(props) {
	return (
		<Typography className="minWidth1100" component="div">
			{props.children}
		</Typography>
	);
}

const style = () => ({
	propertiesContentWrapper: {
		margin: '10px auto',
		fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
		borderRadius: '4px',
		overflow: 'hidden',
		boxShadow: '0 2px 4px var(--secondary-s10)',
		overflowX: 'auto',
	},
	hideContent: {
		display: 'none',
	},
	showContent: {
		display: 'block',
	},
	pageContainer: {
		display: 'flex',
		backgroundColor: 'var(--background-app)',
		borderTop: 'none',
		padding: '10px 10px',
	},

	pageContainerFifty: {
		width: '50%',
		display: 'flex',
		flexDirection: 'column',
	},
	pageContainerMax: {
		paddingBottom: '10px',
	},

	simpleCardGroup: {
		width: '100%',
		display: 'flow-root',
		justifyContent: 'space-around',
	},
	card: {
		padding: '0px',
		backgroundColor: 'var(--background-content)',
		borderRadius: '4px',
		width: '100%',
		'& .MuiCardHeader-root': {
			padding: '22px 20px 0 20px'
		},
		'& .MuiCardContent-root': {
			padding: '16px 15px 10px 15px'
		}
	},
	marginLeftZero: {
		marginLeft: '10px',
	},
	marginRightZero: {
		marginRight: '10px',
	},
	table1: {
		borderRadius: '4px !important'
	},
	table: {
		width: '100%',
	},
	border1: {
		lineHeight: '2rem',
		fontWeight: '500',
		fontSize: '14px',
		paddingLeft: '22px',
		fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
		backgroundColor: 'var(--background-content)',
		color: 'var(--text)',
	},
	border: {
		paddingTop: '12px',
		paddingBottom: '12px',
		paddingLeft: '22px',
		textAlign: 'left',
		color: 'var(--text)',
		fontSize: '14px',
		width: '50%',
		fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
	},
	adjustShowDetail: {
		display: 'flex',
		padding: '10px'
	},
	showDetail: {
		paddingTop: '10px',
	},
	inlineDisplay: {
		display: 'flex',
		'& > div': {
			'& > span': {
				paddingLeft: '5px',
				paddingRight: '5px',
			}
		}
	},
	showStep: {
		display: 'block'
	},
	hideStep: {
		display: 'none'
	},
	reportNameBlock: {
		display: 'flex',
		justifyContent: 'left',   //E3C30032
		alignItems: 'left',     //E3C30032
		margin: '1rem'
	},
	reportNameLabel: {
		minWidth: '120px',
		marginRight: '20px'
	},
	reportNameInput: {
		width: '200px',
		'& [class*="MuiFormControl-root"]': {
			width: '100%'
		}
	},
});

class JobhistoryProperties extends React.Component {
	constructor() {
		super();
		this.state = {
			isSaveDataDisabled: true,
			headerData: false,
			columnDefs: [],
			stateData: false,
			totalCount: 0,
			fromPage: false,
			hasError: false,
			errorId: false,
			changeDataAPI: false,
			openFilterPopup: false,
			previousFilterValues: false,
			showConfirmationDialog: false,
			dialogTitle: '',
			hasWarning: false,
			fromListPage: null,
			hasFiltersChanged: false,
			hasSortChanged: false,
			isDataLoaded: false,
			isInitialAPICall: true,
			valueDataFailureMessages: [],
			headerValues: HeaderAPIValuesJSON[0],
			isFiltersChanged: false,
			dialogBody: false,
			parameterValues: [],
			canUpdateComponent: false,
			valueArray: { OUTL: '1',SBATCH:'1' },
			predecessor: false,
			tab: 0,
			reportName: REPORT_NAME.replace(REPORT_NAME, REPORT_NAME.toUpperCase()) ,
			jobStatusCallCount: 1,
			canUpdateComponent: false,
		};

		this.prepareHeaderDataJSON = this.prepareHeaderDataJSON.bind(this);
		this.handleJobhistoryHeaderLeftArrowClick = this.handleJobhistoryHeaderLeftArrowClick.bind(this);
		this.handleJobhistoryHeaderRightArrowClick = this.handleJobhistoryHeaderRightArrowClick.bind(this);
		this.getApiObj = this.getApiObj.bind(this);
		this.makeAPICallForPageUpDown = this.makeAPICallForPageUpDown.bind(this);
		this.getApiObjForPageUpDown = this.getApiObjForPageUpDown.bind(this);
		this.getLabelValue = this.getLabelValue.bind(this);
		this.setRecordDataValues = this.setRecordDataValues.bind(this);
		this.forceUpdateHandler = this.forceUpdateHandler.bind(this);
		this.setFilterValuesFromState = this.setFilterValuesFromState.bind(this);
		this.handleJobhistoryHeaderFilterClick = this.handleJobhistoryHeaderFilterClick.bind(this);
		this.onSaveData = this.onSaveData.bind(this);
		this.onContextMenuChange = this.onContextMenuChange.bind(this);
		this.sendAPICallForValues = this.sendAPICallForValues.bind(this);
		this.handleNoDataSets = this.handleNoDataSets.bind(this);
		this.handleValueDataErrorMessages = this.handleValueDataErrorMessages.bind(this);
		this.handleChangeValue = this.handleChangeValue.bind(this);
		this.convertAndDownloadCSV = this.convertAndDownloadCSV.bind(this);
		this.convertAndDownloadPostCSV = this.convertAndDownloadPostCSV.bind(this);
	}

	handleNoDataSets() {
		if (this.state.isDataLoaded) {
			this.props.setNoDataCallBackValue(true);
			const paramsString = window.location.search;
			if (paramsString && paramsString.length) {
				const paramsArray = paramsString.split('?');
				if (paramsArray && paramsArray.length && paramsArray.length > 1) {
					const params = paramsArray[1].split('&');
					const tabId = params[0].split('=')[1];
					const breadCrumbId = params[1].split('=')[1];
					this.props.removeCurrentRecordObj(tabId, breadCrumbId);
				}
			}
		}
	}
	getTranstletedMessage = (id) => {
		return <FormattedMessageComponent id={id}></FormattedMessageComponent>
	}
	handleJobhistoryHeaderFilterClick() {
		if (this.state.isFiltersChanged && this.props.jobhistoryPropertiesPage.isValueDataAPIFailure) {
			this.props.onSetFilterProps(this.state.previousFilterValues);
			this.props.setGlobalFilterProps(this.state.previousFilterValues);
			this.props.setChildTabFilterProps(this.state.previousFilterValues);
			this.setState({ isFiltersChanged: false });
			this.props.setValueDataAPIFailureFlag(false);
		}
		this.setState({ openFilterPopup: !this.state.openFilterPopup });
	}

	getLabelValue(id) {
		return <FormattedMessageComponent id={id} />;
	}

	setFilterValuesFromState(values) {
		const filterValues = [];
		const { columnDefs } = this.state;
		if ((columnDefs && columnDefs.length) || (this.columnDefData && this.columnDefData.length)) {
			const colData = columnDefs && columnDefs.length ? columnDefs : this.columnDefData;
			values.forEach(value => {
				const isExists = colData.find(
					column => column[COLUMN_VALUE_ACCESSOR].trim() == value.accessor,
				);
				if (isExists) {
					filterValues.push(value);
				}
			});
			if (filterValues && filterValues.length) {
				this.props.onSetFilterProps(filterValues);
				this.props.setGlobalFilterProps(filterValues);
				return filterValues;
			}
		} else {
			this.props.onSetFilterProps(values);
			this.props.setGlobalFilterProps(values);
			return values;
		}
	}

	getApiObj(recordData, record, currentPage, pageProps) {
		let recordObj = false;
		if (record) {
			recordObj = record;
		}
		const apiObj = {
			recordData,
			pageProps,
			direction: pageProps.isForwardDirection,
			record: recordObj,
			currentPage,
			parentPage: JOBHISTORY_LIST_PAGE,
		};
		return apiObj;
	}

	getApiFilterObj(filterProps, currentPage, pageProps) {

		let apiObj = {
			filterProps,
			pageProps: pageProps,
			direction: pageProps.isForwardDirection,
			currentPage: currentPage,
			parentPage: ORDER_LIST
		};
		return apiObj;
	}

	prepareHeaderDataJSON(obj) {
		const headerValues = HeaderAPIValuesJSON[0];
		const prefix = getListPredecessor(JOBHISTORY_LIST_PAGE);

		let keyJOBN = `${prefix}JOBN`;
		let JOBN = obj[keyJOBN];
		headerValues["RLJOBN"] = JOBN ? JOBN.trim() : JOBN;

		let keyJDES = `JBJDES`;
		let JDES = obj[keyJDES];
		headerValues["JBJDES"] = JDES ? JDES.trim() : JDES;

		const keyJTYP = `JBJTYP`;
		const JTYP = obj[keyJTYP];
		headerValues["JBJTYP"] = JTYP ? JTYP.trim() : JTYP;

		const keyRUND = `${prefix}ENDD`;
		const RUND = obj[keyRUND];
		headerValues["RLENDD"] = RUND ? RUND.trim() : RUND;


		const keyRUNT = `${prefix}ENDT`;
		const RUNT = obj[keyRUNT];
		headerValues["RLENDT"] = RUNT ? RUNT.trim() : RUNT;

		const keyRSTS = `${prefix}JSTS`;
		const RSTS = obj[keyRSTS];
		headerValues["RLJSTS"] = RSTS ? RSTS.trim() : RSTS;

		const keyJSTS = `${prefix}JSTS`;
		const JSTS = obj[keyJSTS];
		headerValues["RLJSTS"] = JSTS ? JSTS.trim() : JSTS;

		// const keyJSTS = `${prefix}JSTS`;
		// const JSTS = obj[keyJSTS];   check projection here
		// headerValues["JBJSTS"] = JSTS ? JSTS.trim() : JSTS;
		const { currentRecordData } = this.props.jobhistoryPropertiesPage;
		headerValues["PJPROJ"] = currentRecordData ? currentRecordData["PJPROJ"] : ''

		return [headerValues];
	}


	forceUpdateHandler() {
		this.forceUpdate();
	}

	makePrevNextAPICall = flag => {
		const { filterProps, sortProps, currentRecordData } = this.props.jobhistoryPropertiesPage;
		const data = JSON.parse(JSON.stringify(INITIAL_PAGE_PROPS));
		data.isForwardDirection = flag;
		data.pageSize = 3;
		let modifiedCurRecData = currentRecordData;
		modifiedCurRecData.RLSTRT="";
		modifiedCurRecData.RLENDT="";
		this.props.getPageUpDownFlagAPI(
			this.getApiObjForPageUpDownFlags(filterProps, modifiedCurRecData, JOBHISTORY_LIST_PAGE, data, sortProps, flag)
		);
	};

	prepareTooltipData = () => {
		const { detailCallData, jobhistoryColumnDefs } = this.props.jobhistoryPropertiesPage;
		let tooltipData = prepareTooltipValues('mmjobs', detailCallData, jobhistoryColumnDefs, JOBHISTORY_PROPERTIES_PAGE);
		this.props.setDataInTabs("toolTipData", JSON.parse(JSON.stringify(tooltipData)));
	}

	setHeaderAndSendAPI(jsonData, from) {
		let data = this.prepareHeaderDataJSON(jsonData);
		this.setState({ headerData: data });
		this.setState({ stateData: jsonData });
		let valueData = prepareValueDataForMassmaintenancejobs(DEFAULT_VALUE_URL_DATA, jsonData, from);
		this.sendAPICallForValues(valueData);
	}
	sendAPICallForValues(valueData) {

		this.props.getValueList({ KJOBN: valueData[1].fieldValue });
		this.props.loadJobHistoryParseData({ KJOBN: valueData[1].fieldValue });
	}
	handleValueDataErrorMessages(content) {
		this.setState({ showValueConfirmationDialog: true });
		this.setState({ dialogTitle: TEXT_ALERT });
		this.setState({ dialogContent: content });
		this.setState({ hasWarning: (content == 'E10184'|| content=='E192') ? true : false });//Fix for E3C-32986
	}

	//Fix for E3C-32986
	handleConfirmationUndo=()=>{
		this.handleValueDataErrorMessages('E192')
	}

	closeValueDialog = (dialogContent) => {
		this.setState({ showValueConfirmationDialog: false });
		if (this.state.valueDataFailureMessages && this.state.valueDataFailureMessages.length) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.shift();
			this.setState({ valueDataFailureMessages: values });
		}
		//Fix for E3C-32986
		if(dialogContent=='E192')
			this.handleUndo()
	}

	setRecordDataValues() {
		let isRecordValuesExists = false, isLocalStorageValuesExists = false, isFilterValuesExists = false;
		const { history } = this.props;
		var paramsString = window.location.search;
		if (paramsString && paramsString.length) {
			let paramsArray = paramsString.split("?");
			if (paramsArray && paramsArray.length && paramsArray.length > 1) {
				let params = paramsArray[1].split("&");
				let tabId = params[0].split("=")[1];
				let breadCrumbId = params[1].split("=")[1];
				let localStorageValues = getFilterDataFromLocalStorage(tabId, breadCrumbId);
				if (localStorageValues && Object.keys(localStorageValues) && Object.keys(localStorageValues).length) {
					isLocalStorageValuesExists = true;
					let itemData = localStorageValues.item_data, dbSelectorValues = [];
					if (itemData && itemData.recordData && localStorageValues.childType) {
						this.columnDefData = JSON.parse(JSON.stringify(itemData.recordData.columnDefs))
						this.setState({ columnDefs: itemData.recordData.columnDefs });
						this.props.setCurrentRecord(itemData.recordData.data);
						this.setState({ totalCount: itemData.recordData.totalCount });
						this.setState({ fromPage: itemData.recordData.fromPage });
						this.setState({ fromListPage: itemData.recordData.fromPage });
						this.props.setRowIndex(itemData.recordData.rowIndex);
						this.setHeaderAndSendAPI(itemData.recordData.data, itemData.recordData.fromPage);
						isRecordValuesExists = true;
						this.props.setSelectedRecord(false, false);
						if (itemData) {
							if (itemData.dbSelector && itemData.dbSelector.length) {
								dbSelectorValues = JSON.parse(JSON.stringify(itemData.dbSelector));
							}
							if (itemData.filterProps && itemData.filterProps.length) {
								this.setState({ hasFiltersChanged: false });
								isFilterValuesExists = true;
								let values = getDBSelectorFilterValues(dbSelectorValues, itemData.filterProps);
								this.setFilterValuesFromState(values);
							} else if (dbSelectorValues && dbSelectorValues.length) {
								this.setState({ hasFiltersChanged: false });
								isFilterValuesExists = true;
								let dbValues = getDBSelectorFilterValues(dbSelectorValues, []);
								this.setFilterValuesFromState(dbValues);
							}
							if (itemData.sortProps && itemData.sortProps.length) {
								this.setState({ hasSortChanged: false });
								this.props.sendPageSortProps(itemData.sortProps);
								this.props.onSetSortProps(itemData.sortProps);
							} else {
								//do nothing
							}
							if (itemData.defaultFilterInfo && Object.keys(itemData.defaultFilterInfo) && Object.keys(itemData.defaultFilterInfo).length) {
								this.props.setDefaultFilterpropsForTabs(itemData.defaultFilterInfo);
							}
							if (itemData.defaultSortInfo && Object.keys(itemData.defaultSortInfo) && Object.keys(itemData.defaultSortInfo).length) {
								this.props.setDefaultSortpropsForTabs(itemData.defaultSortInfo);
							}
							if (itemData.selectedPropertiesTab) {
								this.setState({ tab: itemData.selectedPropertiesTab });//Ajit Saving previously visitedtab
							}
						}
					}

				}
				if (!isLocalStorageValuesExists && tabId && breadCrumbId) {
					history.push({ pathname: '/Dashboard' });
				}
			}
		}

		let filterOptions = GLOBAL_FILTER_OPTIONS;
		const { dbSelector } = this.props;
		if (!isFilterValuesExists) {
			let gbValues = getDBSelectorFilterValues(dbSelector, filterOptions);
			this.setFilterValuesFromState(gbValues);
		}
		return isRecordValuesExists;
	}

	resetValues = () => {
		this.props.setInitialState();
		this.props.setValueDataFlag(false);
		this.props.setCurrentRecord(null);
		this.props.getJobHistorysColumnDefs({ type: JOBHISTORY_LIST_PAGE });
	};

	componentDidMount() {
		this.resetValues();
		let currentPage = JOBHISTORY_PROPERTIES_PAGE;
		this.props.onLoadCurrentPage(currentPage);
		const { detailCallData } = this.props.JobHistoryPropertiesData;
		this.props.setIsShowContextMenu(true);
		let isFound = this.setRecordDataValues();
		if (!isFound) {
			if (this.props.location && this.props.location.state) {
				this.props.setCurrentRecord(this.props.location.state.data);
				this.setState({ columnDefs: this.props.location.state.columnDefs });
				this.setState({ fromPage: this.props.location.state.fromPage });
				this.props.setRowIndex(this.props.location.state.rowIndex);
				this.setHeaderAndSendAPI(this.props.location.state.data, JOBHISTORY_LIST_PAGE);
			}
		}

		if (detailCallData && Object.keys(detailCallData) && Object.keys(detailCallData).length) {
			this.setState({ headerData: this.prepareHeaderDataJSON(detailCallData) });
			this.props.setSelectedRecord(detailCallData, JOBHISTORY_LIST_PAGE);
			const { valueArray } = this.state;
			valueArray['rerun'] = detailCallData.JDTCAT
			this.setState({ valueArray })
		}

		this.setState({ isSaveDataDisabled: true });
		let canUpdateComponent = getUpdateRestrictionOnComponent(capitalizeFirstLetter(JOBHISTORY_LIST_PAGE), this.props.authorizedComponentsList);
		this.setState({ canUpdateComponent });
	}

	componentDidUpdate(prevProps, prevState) {
		const { pageUpDownData,
			isSaveSuccess,
			filterProps,
			isValueDataAPICall,
			isValueDataAPIFailure,
			jobhistoryColumnDefs,
			sortProps,
			defaultSortProps,
			sortCriteriaDetails,
			filterCriteriaDetails,
			detailCallData,
			isApiForJobhistoryParse,
			isApiForJobhistoryColumnDefs,
			isApiForFilterableColumnDefs,
			isApiForPrevNextData,
			isApiPrevNextFlags,
			isApiForsendDataToServer,
			isApiFormassMaintenceRunNowData,
			isApiFormassMaintenceSubmitData,
			isApiFormassMaintenanceUpdateData,
			currentRecordData, jobNumber, jobStatus, filesList, fileResponse, postJobNumber, jobPostStatus, postfilesList, postfileResponse
		} = this.props.jobhistoryPropertiesPage
		if (this.state.valueDataFailureMessages && this.state.valueDataFailureMessages.length
			&& (JSON.stringify(this.state.valueDataFailureMessages) != JSON.stringify(prevState.valueDataFailureMessages))) {
			this.handleValueDataErrorMessages(this.state.valueDataFailureMessages[0]);
		}

		if (isApiForJobhistoryParse && (isApiForJobhistoryParse != prevProps.jobhistoryPropertiesPage.isApiForJobhistoryParse)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to fetch Vendor Detail");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isApiForJobhistoryParse', value: false });
		}
		if (isApiForJobhistoryColumnDefs && (isApiForJobhistoryColumnDefs != prevProps.jobhistoryPropertiesPage.isApiForJobhistoryColumnDefs)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to fetch column Definations");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isApiForJobhistoryColumnDefs', value: false });
		}
		if (isApiForFilterableColumnDefs && (isApiForFilterableColumnDefs != prevProps.jobhistoryPropertiesPage.isApiForFilterableColumnDefs)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to fetch filter Columns");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isApiForFilterableColumnDefs', value: false });
		}

		if (isApiForPrevNextData && (isApiForPrevNextData != prevProps.jobhistoryPropertiesPage.isApiForPrevNextData)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to fetch previous Next data");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isApiForPrevNextData', value: false });
		}
		if (isApiPrevNextFlags && (isApiPrevNextFlags != prevProps.jobhistoryPropertiesPage.isApiPrevNextFlags)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to fetch previous next Flags");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isApiPrevNextFlags', value: false });
		}

		if (isApiForsendDataToServer && (isApiForsendDataToServer != prevProps.jobhistoryPropertiesPage.isApiForsendDataToServer)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to fetch Save Job defination");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isApiForsendDataToServer', value: false });
		}

		if (isApiFormassMaintenceRunNowData && (isApiFormassMaintenceRunNowData != prevProps.jobhistoryPropertiesPage.isApiFormassMaintenceRunNowData)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to fetch run the Job");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isApiFormassMaintenceRunNowData', value: false });
		}
		if (isApiFormassMaintenceSubmitData && (isApiFormassMaintenceSubmitData != prevProps.jobhistoryPropertiesPage.isApiFormassMaintenceSubmitData)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to fetch Submit the job");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isApiFormassMaintenceSubmitData', value: false });

		} if (isApiFormassMaintenanceUpdateData && (isApiFormassMaintenanceUpdateData != prevProps.jobhistoryPropertiesPage.isApiFormassMaintenanceUpdateData)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to fetch Update the job");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isApiFormassMaintenanceUpdateData', value: false });
		}

		if (sortProps && sortProps.length && !isEqual(sortProps, prevProps.jobhistoryPropertiesPage.sortProps)) {
			this.props.setDataInTabs("sortProps", JSON.parse(JSON.stringify(sortProps)));
			if (!this.state.isInitialAPICall) {
				if (this.state.fromPage != JOBHISTORY_LIST_PAGE) {
					this.setHeaderAndSendAPI(this.state.stateData, this.state.fromPage)
				} else {
					this.makeAPICallForPageUpDown('down', {});
				}
			}
		}
		if ((JSON.stringify(filterProps) != JSON.stringify(prevProps.jobhistoryPropertiesPage.filterProps)) && filterProps && filterProps.length) {
			this.setState({ isFiltersChanged: true });
			this.props.setChildTabFilterProps(filterProps);
			if (!this.state.isInitialAPICall) {
				if (this.state.fromPage != JOBHISTORY_LIST_PAGE && !this.state.hasFiltersChanged) {
					this.setHeaderAndSendAPI(this.state.stateData, this.state.fromPage)
				} else {
					this.makeAPICallForPageUpDown('down', {});
				}
			}
		}
		if ((defaultSortProps != prevProps.jobhistoryPropertiesPage.defaultSortProps) && (prevProps.jobhistoryPropertiesPage.defaultSortProps === null) && (sortProps == null || !sortProps || !(sortProps && sortProps.length))) {
			let list = setSortDataFromSortCriteria(defaultSortProps, jobhistoryColumnDefs, JOBHISTORY_LIST_PAGE);
			this.props.setDataInTabs("defaultSortInfo", JSON.parse(JSON.stringify(defaultSortProps)));
			if (list && list.length) {
				this.props.sendPageSortProps(list);
				this.props.onSetSortProps(list);
			} else {
				this.props.sendPageSortProps([]);
				this.props.onSetSortProps([]);
			}
		}

		if (JSON.stringify(sortCriteriaDetails) != JSON.stringify(prevProps.jobhistoryPropertiesPage.sortCriteriaDetails)) {
			this.props.setDataInTabs("defaultSortInfo", JSON.parse(JSON.stringify(sortCriteriaDetails)));
			let list = setSortDataFromSortCriteria(sortCriteriaDetails, jobhistoryColumnDefs, JOBHISTORY_LIST_PAGE);
			if (list && list.length) {
				this.props.sendPageSortProps(list);
				this.props.onSetSortProps(list);
			}
		}

		if ((filterCriteriaDetails != prevProps.jobhistoryPropertiesPage.filterCriteriaDetails)) {
			this.props.setDataInTabs("defaultFilterInfo", JSON.parse(JSON.stringify(filterCriteriaDetails)));
			if (filterCriteriaDetails && Object.keys(filterCriteriaDetails) && Object.keys(filterCriteriaDetails).length && jobhistoryColumnDefs && jobhistoryColumnDefs.length) {
				let list = getFilterDataFromCriteriaDetails(filterCriteriaDetails, jobhistoryColumnDefs, JOBHISTORY_LIST_PAGE);
				if (list && list.length) {
					this.props.setGlobalFilterProps(list);
					this.props.onSetFilterProps(list);
				}
			}
		}

		if (detailCallData && !isEqual(detailCallData, prevProps.jobhistoryPropertiesPage.detailCallData)) {
			if (Object.keys(detailCallData) && Object.keys(detailCallData).length) {
				if (jobhistoryColumnDefs && jobhistoryColumnDefs.length) {
					this.prepareTooltipData();
				}
				this.props.setSelectedRecord(detailCallData, JOBHISTORY_LIST_PAGE);
				this.setState({ headerData: this.prepareHeaderDataJSON(detailCallData) });
				const { valueArray } = this.state;
				valueArray['rerun'] = detailCallData.JDTCAT
				this.setState({ valueArray })
			}
		}

		if (jobhistoryColumnDefs && jobhistoryColumnDefs.length && !isEqual(jobhistoryColumnDefs, prevProps.jobhistoryPropertiesPage.jobhistoryColumnDefs) &&
			(detailCallData && Object.keys(detailCallData) && Object.keys(detailCallData).length)) {
			if (!this.state.changeDataAPI) {
				this.prepareTooltipData();
			}
		}
		if (isValueDataAPICall != prevProps.jobhistoryPropertiesPage.isValueDataAPICall && isValueDataAPICall) {
			this.setState({ previousFilterValues: prevProps.jobhistoryPropertiesPage.filterProps })
			this.setState({ isInitialAPICall: false });
			this.makePrevNextAPICall(true);
			this.props.setValueDataFlag(false);
			if (this.state.isFiltersChanged) {
				this.setState({ openFilterPopup: false });
				this.setState({ isFiltersChanged: false });
			}
			const { detailCallData } = this.props.jobhistoryPropertiesPage
			if (detailCallData && detailCallData.JDDEFN) {
				const data = detailCallData.JDDEFN.substring(12, 18);
				switch (data) {
					case '007001':
						this.setState({ predecessor: 'vendors' })
						this.props.getFilterableColumnsList("vendorfiltercolumns");
						break;
					case '006301':
						this.setState({ predecessor: 'items' })
						this.props.getFilterableColumnsList("itemfiltercolumns");
						break;
					case '010104':
						this.setState({ predecessor: 'itemondeal' })
						this.props.getFilterableColumnsList("dealheaderfiltercolumns");
						break;
					case '010103':
						this.setState({ predecessor: 'deals' })
						this.props.getFilterableColumnsList("dealitemsfiltercolumns");
						break;
					default:
						break;
				}

			}
		}
		if (isValueDataAPIFailure != prevProps.jobhistoryPropertiesPage.isValueDataAPIFailure && isValueDataAPIFailure) {
			this.setState({ isInitialAPICall: false });
			if (this.state.isFiltersChanged) {
				this.setState({ showConfirmationDialog: true });
				this.setState({ hasWarning: true });
				this.setState({ dialogTitle: TEXT_ALERT });
				this.setState({ fromHeaderENG: true });
			} else {
				this.setState({ showConfirmationDialog: true });
				this.setState({ hasWarning: true });
				this.setState({ dialogTitle: TEXT_ALERT });
				this.setState({ fromHeaderENG: true });
			}
		}
		if (prevProps.authorizedComponentsList !== this.props.authorizedComponentsList) {
			let canUpdateComponent = getUpdateRestrictionOnComponent(capitalizeFirstLetter(JOBHISTORY_LIST_PAGE), this.props.authorizedComponentsList);
			this.setState({ canUpdateComponent });
		}
		if (this.props.location.search != prevProps.location.search) {
			this.resetValues();
			this.forceUpdateHandler();
			this.setRecordDataValues();
			this.setState({ state: this.state });
		}
		if (pageUpDownData && JSON.stringify(pageUpDownData) != JSON.stringify(prevProps.jobhistoryPropertiesPage.pageUpDownData)) {
			this.props.setSelectedRecord(pageUpDownData, JOBHISTORY_LIST_PAGE);
			this.setState({ fromPage: JOBHISTORY_LIST_PAGE });
			this.setHeaderAndSendAPI(pageUpDownData, JOBHISTORY_LIST_PAGE);
			let modifiedData = {
				data: JSON.parse(JSON.stringify(pageUpDownData)),
				fromPage: JOBHISTORY_LIST_PAGE,
				rowIndex: this.props.jobhistoryPropertiesPage.rowIndex,
				totalCount: this.state.totalCount,
				fromParent: false,
				columnDefs: this.state.columnDefs,
			};
			this.props.setDataInTabs('recordData', modifiedData);
		}
		if (isSaveSuccess && isSaveSuccess !== prevProps.jobhistoryPropertiesPage.isSaveSuccess) {
			this.setState({ isSaveDataDisabled: true });
		}
		if (jobNumber&&(jobNumber != prevProps.jobhistoryPropertiesPage.jobNumber) ) {
			this.props.getJobStatus({ jobNumber });
		}
		if (postJobNumber && (postJobNumber != prevProps.jobhistoryPropertiesPage.postJobNumber)) {
			this.props.getPostJobStatus({ postJobNumber });
		}
		if (jobStatus && (jobStatus != prevProps.jobhistoryPropertiesPage.jobStatus)) {
			this.checkJobStatusAndGetFileDetails(jobStatus);
			}
		if (jobPostStatus && (jobPostStatus != prevProps.jobhistoryPropertiesPage.jobPostStatus)) {
			this.checkPostJobStatusAndGetFileDetails(jobPostStatus);
		}
		if (filesList && filesList != prevProps.jobhistoryPropertiesPage.filesList) {
			this.downloadCSVFileForList(filesList);
		}
		if (postfilesList && postfilesList != prevProps.jobhistoryPropertiesPage.postfilesList) {
			this.downloadPostCSVFileForList(postfilesList);
		}
		if (fileResponse && fileResponse != prevProps.jobhistoryPropertiesPage.fileResponse) {
			this.convertAndDownloadCSV(fileResponse);
		}
		if (postfileResponse && postfileResponse != prevProps.jobhistoryPropertiesPage.postfileResponse) {
			this.convertAndDownloadPostCSV(postfileResponse);
		}
	}
	downloadCSVFileForList=(list)=> {
		if (list.length) {
			for (const file in list) {
				this.props.downloadCSVFile({
					fileName: list[file],
					currentPage: this.props.currentPage,
				});
			}
		}
	}
	downloadPostCSVFileForList = (list) => {
		if (list.length) {
			for (const file in list) {
				this.props.downloadPostCSVFile({
					fileName: list[file],
					currentPage: this.props.currentPage,
				});
			}
		}
	}


	checkJobStatusAndGetFileDetails=(jobStatus)=> {
		const { errorMessages } = this.props;
		if (jobStatus == 'PND' || jobStatus == 'RUN') {
			setTimeout(
				function () {
					if (this.state.jobStatusCallCount < MAX_JOB_STATUS_CALL_COUNT) {
						this.props.getJobStatus({ jobNumber: this.props.jobhistoryPropertiesPage.jobNumber });
						this.setState(prevState => ({ jobStatusCallCount: prevState.jobStatusCallCount + 1 }))
					}
					//RRUDRA_E3C30032
					else if (jobStatus == 'ERR') {
						this.props.addServerErrorMessage({ ERRCOD: '9907', ERRMSG: errorMessages['E9907']?.MTEXT.trim() })
					}
					else {
						this.setState({ jobStatusCallCount: 1 });
						this.props.addServerErrorMessage({
							ERRCOD: '171',
							ERRMSG: errorMessages['E171']?.MTEXT.trim(),
						});
					}
				}.bind(this),
				JOB_STATUS_API_INTERVAL,
			);
		} else {
			this.props.getFileDetails({ jobNumber: this.props.jobhistoryPropertiesPage.jobNumber });
		}
	}
	checkPostJobStatusAndGetFileDetails = (jobStatus) => {
		const { errorMessages } = this.props;
		if (jobStatus == 'PND' || jobStatus == 'RUN') {
			setTimeout(
				function () {
					if (this.state.jobStatusCallCount < MAX_JOB_STATUS_CALL_COUNT) {
						this.props.getPostJobStatus({ postJobNumber: this.props.jobhistoryPropertiesPage.postJobNumber });
						this.setState(prevState => ({ jobStatusCallCount: prevState.jobStatusCallCount + 1 }))
					}
					//RRUDRA_E3C30032
					else if (jobStatus == 'ERR') {
						this.props.addServerErrorMessage({ ERRCOD: '9907', ERRMSG: errorMessages['E9907']?.MTEXT.trim() })
					}
					else {
						this.setState({ jobStatusCallCount: 1 });
						this.props.addServerErrorMessage({
							ERRCOD: '171',
							ERRMSG: errorMessages['E171']?.MTEXT.trim(),
						});
					}
				}.bind(this),
				JOB_STATUS_API_INTERVAL,
			);
		} else {
			this.props.getPostFileDetails({ jobNumber: this.props.jobhistoryPropertiesPage.postJobNumber });
		}
	}
	onSaveData = () => {
		const { detailCallData, currentRecordData } = this.props.jobhistoryPropertiesPage;
		const { valueArray } = this.state

		let job = { ...detailCallData }
		job.JDTCAT = valueArray["rerun"].toString()
		job.JDSTAT = "C"
		this.props.massMaintenceUpdate(job);

		job = { ...currentRecordData }
		job.JBK4RR = valueArray["rerun"].toString()
		this.props.massMaintenceJobUpdate(job)
	}

	getApiObjForPageUpDown(filterData, record, currentPage, pageProps, sortData, pageType) {
		let recordObj = false
		if (record) {
			recordObj = record;
		}
		let apiObj = {
			sortProps: sortData,
			filterProps: filterData,
			pageProps: pageProps,
			direction: pageProps.isForwardDirection,
			record: recordObj,
			currentPage: currentPage,
			parentPage: JOBHISTORY_LIST_PAGE,
			pageType: pageType
		};
		return apiObj;
	}

	getApiObjForPageUpDownFlags = (filterData, record, currentPage, pageProps, sortData, pageType) => {
		let recordObj = false
		if (record) {
			recordObj = {
				"record": record,
				"flagsOnly": true
			};
		}
		let apiObj = {
			sortProps: sortData,
			filterProps: filterData,
			pageProps: pageProps,
			direction: pageProps.isForwardDirection,
			record: recordObj,
			currentPage: currentPage,
			parentPage: JOBHISTORY_LIST_PAGE,
			pageType: pageType
		};
		return apiObj;
	}

	makeAPICallForPageUpDown(type, currentRecordData) {
		const { filterProps, sortProps } = this.props.jobhistoryPropertiesPage;
		let data = JSON.parse(JSON.stringify(INITIAL_PAGE_PROPS));
		if (type == 'up') {
			data.isForwardDirection = false;
		} else {
			data.isForwardDirection = true;
		}
		let filterData = JSON.parse(JSON.stringify(filterProps));
		this.props.pageUpDownAPI(this.getApiObjForPageUpDown(filterData, currentRecordData, JOBHISTORY_LIST_PAGE, data, sortProps))
	}

	handleJobhistoryHeaderLeftArrowClick() {
		const { currentRecordData } = this.props.jobhistoryPropertiesPage;
		this.props.setCurrentType('down');
		this.makeAPICallForPageUpDown('down', currentRecordData);
		this.setState({ isSaveDataDisabled: true });
	}

	handleJobhistoryHeaderRightArrowClick() {
		const { currentRecordData } = this.props.jobhistoryPropertiesPage;
		this.props.setCurrentType('up');
		this.makeAPICallForPageUpDown('up', currentRecordData);
		this.setState({ isSaveDataDisabled: true });
	}

	sethaserror = val => {
		this.setState({ hasError: val });
	};

	onContextMenuChange = (e, value, check = false, filters = false, title = false) => {
		let defaultFilters = filters;
		let toPage = value;
		let displayName = title;
		onChangeContextMenu(this.props, e, toPage, defaultFilters, displayName);
		this.props.setSelectedValueForTabs('Show Me');
	}

	handleClose = bodyId => {
		this.setState({ showConfirmationDialog: false });
		switch (bodyId) {
			case 'E14029':
				//need to close the current Tab
				break;
		}
		this.closeCurrentTab();
	}

	closeCurrentTab = () => {
		this.props.setNoDataCallBackValue(true);
		var paramsString = window.location.search;
		if (paramsString && paramsString.length) {
			let paramsArray = paramsString.split("?");
			if (paramsArray && paramsArray.length && paramsArray.length > 1) {
				let params = paramsArray[1].split("&");
				let tabId = params[0].split("=")[1];
				let breadCrumbId = params[1].split("=")[1];
				this.props.removeCurrentRecordObj(tabId, breadCrumbId);
			}
		}
	}

	handleChangeValue = (key, val) => {
		const valueArray = { ...this.state.valueArray };
		valueArray[key] = val;
		this.setState({ valueArray });
		this.setState({ isSaveDataDisabled: false })
	}

	handleOperator = (opr) => {
		switch (opr) {
			case '=': return EQUALS_TO;

			case '>': return GREATER_THAN;

			case '>=': return GREATER_THAN_OR_EQUALS_TO;

			case '<': return LESS_THAN;

			case '<=': return LESS_THAN_OR_EQUALS_TO;

			case '!=': return NOT_EQUALS_TO;

			default:
				return ' '
		}
	}
	handleFieldName = (key) => {
		const { filterableColumns } = this.props.jobhistoryPropertiesPage;
		const { predecessor } = this.state
		let pre = predecessor ? getListPredecessor(predecessor).trim() : false;
		let field
		if (filterableColumns && filterableColumns.length && predecessor) {
			field = filterableColumns.find(field => Number(field.FDPRFX) ? field.FDFNAM.trim() == key.trim() : pre + field.FDFNAM.trim() == key)
			return field && field.TLLAB ? field.TLLAB : ' '
		} else {
			return ' ';
		}
	}

	handleFieldval = (dataField) => {
		const { filterableColumns } = this.props.jobhistoryPropertiesPage;
		const { predecessor } = this.state
		let pre = predecessor ? getListPredecessor(predecessor).trim() : false;
		let field
		if (filterableColumns && filterableColumns.length && predecessor) {
			field = filterableColumns.find(field => Number(field.FDPRFX) ? field.FDFNAM.trim() == dataField.key.trim() : pre + field.FDFNAM.trim() == dataField.key)
			return field && field.FDFTYP == "D" ? getDateFormatValue(dataField.val) : dataField.val
		} else {
			return dataField.val;
		}
	}
	handleChangeTab = (event, value) => {
		this.setState({ tab: value });
		this.props.setDataInTabs("selectedPropertiesTab", value);//Ajit Saving previously visitedtab
	};
	handleUndo = () => {
		const { currentRecordData } = this.props.jobhistoryPropertiesPage;
		let obj = {
			"KJOBN": currentRecordData.RLJOBN,
			"KLOGN": currentRecordData.RLLOGN,
			"KTYPE": this.state.valueArray.SBATCH=="1"? "B":"I"//  batch :"B"
		}
		this.props.massMaintenceRunNow(obj);
	}
	handleExportSubmit = () =>{
		let { jobNumber,currentRecordData } = this.props.jobhistoryPropertiesPage;
		let exportData = {
			exportFields: currentRecordData.RLJTYP == 'EVT' ? postProcParseBO : planPostProcParseBO,
			filterRowData: currentRecordData.RLJTYP == 'EVT' ? `?listDirection="F"&filterStr='[{"key":"EXLOGN","opr":"=","jOpr":"and","val":` + `${currentRecordData.RLLOGN}` + `}]'&numberOfRecords="100""`:
				`?listDirection="F"&filterStr='[{"key":"PXLOGN","opr":"=","jOpr":"and","val":` + `${currentRecordData.RLLOGN}` + `}]'&numberOfRecords="100""`
		};
		let exportData1 = {
			exportFields: currentRecordData.RLJTYP == 'EVT' ? preProcParseBO : planPreProcParseBO,
			filterRowData: currentRecordData.RLJTYP == 'EVT' ?`?listDirection="F"&filterStr='[{"key":"EELOGN","opr":"=","jOpr":"and","val":` + `${currentRecordData.RLLOGN}` + `}]'&numberOfRecords="100""`:
				`?listDirection="F"&filterStr='[{"key":"PELOGN","opr":"=","jOpr":"and","val":` + `${currentRecordData.RLLOGN}` + `}]'&numberOfRecords="100""`
		};
		this.props.makeExportApi(this.getExportApiData(exportData));
		this.props.makePostExportApi(this.getExportApiData(exportData1));
	}
	getExportApiData = (exportData) =>{
		let { jobNumber, currentRecordData } = this.props.jobhistoryPropertiesPage;
		if (this.props.currentPage == "buyers") {
			exportData.filterRowData.push({ accessor: 'BUYR', prefixFlag: 0, key: 'BUYR', value: '*BLANK', operator: '!=', fieldValue: '*BLANK', jOpr: 'and', serverString: '[BUYR]!=*BLANK', query: 'Buyer ID != *BLANK' })
		}
		let pageProps={
			actualPage: 0,
			actualPageSize: 10,
			currentPage: 0,
            isForwardDirection: true,
            isPageSizeChanged: false,
			pageSize: 5,
			totalCount: 10
		};
		let exportApiData = {
			apiKey: currentRecordData.RLJTYP == "EVT" ? (exportData.exportFields[0]["TABLE_NAME"] == "DSEPE" ? `exportPostError` : "exportPreError") : (exportData.exportFields[0]["TABLE_NAME"] == "DSPPE" ? `exportPlanPreError` : "exportPlanPostError"),
			pageProps: { ...pageProps, pageSize: 100 },
			exportFilterProps: exportData.filterRowData,
			currentPage: this.props.currentPage,
			direction: true,
			body: getExportAPiBody(exportData.exportFields, ((this.state.reportName).trim()).substr(0, MAX_LENGTH_OF_REPORT_NAME))
		};
		return exportApiData;
	}
	handleOpenExport = () =>{
		this.setState({openDialog:true})
	}
	changeReportName = (key, value) => {
		this.setState({ reportName: value });
	}
	convertAndDownloadCSV(fileResponse) {
		let csv = fileResponse;
		const filename = this.props.jobhistoryPropertiesPage.currentFileName.split('/');
		let exportedFilenmae = filename[filename.length - 1] || 'export.csv';
		let blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
		if (navigator.msSaveBlob) {
			// IE 10+
			navigator.msSaveBlob(blob, exportedFilenmae);
		} else {
			let link = document.createElement('a');
			if (link.download !== undefined) {
				// feature detection
				// Browsers that support HTML5 download attribute
				let url = URL.createObjectURL(blob);
				link.setAttribute('href', url);
				link.setAttribute('download', exportedFilenmae);
				link.style.visibility = 'hidden';
				document.body.appendChild(link);
				link.click();
				document.body.removeChild(link);
			}
		}
	}
	convertAndDownloadPostCSV(fileResponse) {
		let csv = fileResponse;
		const filename = this.props.jobhistoryPropertiesPage.currentPostFileName.split('/');
		let exportedFilenmae = filename[filename.length - 1] || 'export.csv';
		let blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
		if (navigator.msSaveBlob) {
			// IE 10+
			navigator.msSaveBlob(blob, exportedFilenmae);
		} else {
			let link = document.createElement('a');
			if (link.download !== undefined) {
				// feature detection
				// Browsers that support HTML5 download attribute
				let url = URL.createObjectURL(blob);
				link.setAttribute('href', url);
				link.setAttribute('download', exportedFilenmae);
				link.style.visibility = 'hidden';
				document.body.appendChild(link);
				link.click();
				document.body.removeChild(link);
			}
		}
	}
	render() {

		const {
			classes, globalDateFormat, filterCriteriaDetails, pageFilterOptions, globalFilterOptions,
			isShowContextMenu } = this.props;
		const {
			loading, valueData, rowIndex, currentRecordData, hasNext, hasPrevious, vendorData, jobhistoryColumnDefs, filterableColumns, jobhistory } = this.props.jobhistoryPropertiesPage;
		const { isSaveDataDisabled, headerData, valueArray, tab } = this.state;
		let contextMenu = updateBreadCrumbContextMenu(this.props) || [];
		let actualReportName = this.state.reportName;
		return (
			<React.Fragment>
				<Header
					filters={this.props.filters}
					parentSubPage={JOBHISTORY_PROPERTIES_PAGE}
					contextMenu={contextMenu}
					fromListPage={this.state.fromListPage}
					onContextMenuChange={this.onContextMenuChange}
					rowIndex={rowIndex}
					jobhistoryPropertiesPage={this.props.jobhistoryPropertiesPage}
					handleJobhistoryHeaderFilterClick={this.handleJobhistoryHeaderFilterClick}
					hasNext={hasNext}
					hasPrevious={hasPrevious}
					jobhistoryData={headerData}
					vendorData={vendorData}
					currentRecordData={currentRecordData}
					handleJobhistoryHeaderSaveClick={() => this.onSaveData()}
					handleJobhistoryHeaderLeftArrowClick={this.handleJobhistoryHeaderLeftArrowClick}
					handleJobhistoryHeaderRightArrowClick={this.handleJobhistoryHeaderRightArrowClick}
					saveDisabled={isSaveDataDisabled}
					setSaveData={val => { this.setState({ isSaveDataDisabled: !val }); }}
					globalDateFormat={globalDateFormat}
					filterCriteriaDetails={filterCriteriaDetails}
					pageFilterOptions={pageFilterOptions}
					globalFilterOptions={globalFilterOptions}
					columnDefs={this.state.columnDefs}
					currentPage={JOBHISTORY_LIST_PAGE}
					parentPage={JOBHISTORY_LIST_PAGE}
					canUpdateComponent={this.state.canUpdateComponent}
					isShowContextMenu={isShowContextMenu}
					massMaintenceRunNow={this.props.massMaintenceRunNow}
					massMaintenceSubmit={this.props.massMaintenceSubmit}
					handleUndo={this.handleConfirmationUndo}//Fix for E3C-32986
				/>
				<div className={classes.propertiesContentWrapper}>
					<AppBar position="static" color="default">
						<Tabs
							value={this.state.tab}
							onChange={(evt, val) => { this.handleChangeTab(evt, val); }}
							indicatorColor="primary"
							textColor="primary"
							scrollButtons="auto"
							variant="scrollable"

						>
							{(currentRecordData.RLJTYP == "PLN" || currentRecordData.RLJTYP == "EVT") ? null : <Tab value={0} label={this.getLabelValue("27502")} />}
							<Tab value={1} label={this.getLabelValue("27503")} />
						</Tabs>
					</AppBar>
					<div className={(tab === 0 ? classes.showStep : classes.hideStep) + " " + classes.pageContainer}>
						<div>
							{currentRecordData ? (<div><LogList
								valueData={currentRecordData}
							//  queryString={this.state.queryString}
							/>
								<div className={classes.card}>
									<Box className={classes.adjustShowDetail}>
										<FieldInput disabled={true} field={{ type: 'checkbox', key: 'OUTL' }} value={(valueArray['OUTL'] && Number(valueArray['OUTL'])) || 0}
											onChange={(key, val) => this.handleChangeValue(key, val)} />
										<div className={classes.showDetail}>{this.getLabelValue("2363")}</div>
									</Box>
									<Box className={classes.adjustShowDetail}>
										<FieldInput field={{ type: 'checkbox', key: 'SBATCH' }} value={(valueArray['SBATCH'] && Number(valueArray['SBATCH'])) || 0}
											onChange={(key, val) => this.handleChangeValue(key, val)} disabled={!this.state.canUpdateComponent?.update} />
										<div className={classes.showDetail}>{this.getLabelValue("41087")}</div>
									</Box>
									{/* <Box className={classes.adjustShowDetail}>
										<Button onClick={this.handleUndo} disabled={!this.state.canUpdateComponent?.update}>Undo</Button>
									</Box> */}
								</div></div>) : <Spinner loading type="loglist" />}
						</div></div>
					<div className={(tab === 1 ? classes.showStep : classes.hideStep) + " " + classes.pageContainer}>
						<TabContainer>
							<div className={classes.pageContainer}>
								<div className={classes.pageContainerFifty + ' ' + classes.marginRightZero}>
									<div className={classes.simpleCardGroup + ' ' + classes.card}>
										<table>
											<tr>
											<td style={{ padding: "0.5rem 5rem 0.5rem 5rem" }}>{JSON.parse(localStorage["messageLabels"])["H2282"]["TLLAB"] /*E3C-33266 'Log Number' */}</td>
												<td>{currentRecordData.RLLOGN}</td>
											</tr>
											<tr>
											<td style={{ padding: "0rem 5rem 0.25rem 5rem" }}>{JSON.parse(localStorage["messageLabels"])["H2329"]["TLLAB"] /*E3C-33266 'Records Processed' */}</td>
												<td>{currentRecordData.RLRCDS}</td>
											</tr>
											<tr>
											<td style={{ padding: "0rem 5rem 0.25rem 5rem" }}>{JSON.parse(localStorage["messageLabels"])["H2333"]["TLLAB"] /*E3C-33266 'Undo Log Number' */}</td>
												<td>{currentRecordData.RLULOG}</td>
											</tr>
											<tr>
											<td style={{ padding: "0rem 5rem 0.25rem 5rem" }}>{JSON.parse(localStorage["messageLabels"])["H2326"]["TLLAB"] /*E3C-33266 'End Code' */}</td>
												<td>{currentRecordData.RLCODE}</td>
											</tr>
											<tr>
											<td style={{ padding: "0rem 5rem 0.25rem 5rem" }}>{JSON.parse(localStorage["messageLabels"])["H2227"]["TLLAB"] /*E3C-33266 'Error Message ID' */}</td>
												<td></td>
											</tr>
											<tr>
											<td style={{ padding: "0rem 5rem 0.5rem 5rem" }}>{JSON.parse(localStorage["messageLabels"])["H2328"]["TLLAB"] /*E3C-33266 'Error Message Data' */}</td>
												<td></td>
											</tr>
										</table>
									</div>
								</div>

								<div className={classes.pageContainerFifty + ' ' + classes.marginRightZero}>
									<div className={classes.simpleCardGroup + ' ' + classes.card}>
										<table>
											<tr>
											<td style={{ padding: "1rem 8rem 0.75rem 7rem" }}>{JSON.parse(localStorage["messageLabels"])["H2221"]["TLLAB"] /*E3C-33266 'Submitted by' */}</td>
												<td>{currentRecordData.RLUSER}</td>
											</tr>
											<tr>
											<td style={{ padding: "0rem 8rem 0.75rem 7rem" }}>{JSON.parse(localStorage["messageLabels"])["H2330"]["TLLAB"] /*E3C-33266 'System Job Name' */}</td>
												<td>{currentRecordData.RLSNAM}</td>
											</tr>
											<tr>
											<td style={{ padding: "0rem 8rem 0.75rem 7rem" }}>{JSON.parse(localStorage["messageLabels"])["H2332"]["TLLAB"] /*E3C-33266 'System Job Number' */}</td>
												<td>{currentRecordData.RLSNUM}</td>
											</tr>
											<tr>
											<td style={{ padding: "0rem 8rem 0.75rem 7rem" }}>{JSON.parse(localStorage["messageLabels"])["H2331"]["TLLAB"] /*E3C-33266 'System Job User' */}</td>
												<td>{currentRecordData.RLSUSR}</td>
											</tr>
										</table>
									</div>
								</div>
								
							</div>{currentRecordData && (currentRecordData.RLJTYP == "EVT" || currentRecordData.RLJTYP == "PLN")&&<Button onClick={this.handleOpenExport}>Export Error</Button>}</TabContainer></div>
							<DialogComponent isOpen={this.state.openDialog}
               				 dialogTitle={"Export Error"}
               				 cancelText={'CANCEL'}
               				 submitText={'OK'}
               				 handleClose= {e => this.handleClose(false)}
               				 handleCancel={e => this.handleClose(false)}
               				 handleSubmit={e => { this.handleExportSubmit() }}
               				 className={classes.dialogClass}
                			>
						<div>
							<div className={classes.reportNameBlock}>
								<div className={classes.reportNameLabel}>{this.getTranstletedMessage('2358')}</div>
								<div className={classes.reportNameInput}>
									<FieldInput
										value={(actualReportName.trim()).substr(0, MAX_LENGTH_OF_REPORT_NAME)}
										onChange={(key, value) => this.changeReportName(key, value)}
										field={{ type: 'text', key: 'reportName' }}
										maxLength={MAX_LENGTH_OF_REPORT_NAME}
									></FieldInput>
								</div>
							</div>
							</div>
							</DialogComponent>
				</div>

				{this.state.openFilterPopup && (
					<Filter
						filterCriteriaDetails={this.props.filterCriteriaDetails}
						pageFilterOptions={this.props.pageFilterOptions}
						globalFilterOptions={this.props.globalFilterOptions}
						globalSecurityFilterList={this.props.globalSecurityFilterList}
						currentPage={JOBHISTORY_PROPERTIES_PAGE}
						isOpen={Boolean(this.state.openFilterPopup)}
						ownerName={this.props.currentOwnerName}
						columnDefs={jobhistoryColumnDefs}
						clearPopupComponent={this.handleJobhistoryHeaderFilterClick}
						disableRows={[]}
					/>
				)}
				{this.state.showConfirmationDialog && <ConfirmationDialog
					hasError={this.state.hasWarning}
					isOpen={this.state.showConfirmationDialog}
					dialogTitle={this.state.dialogTitle}
					submitText={TEXT_OK}
					handleClose={() => this.handleClose(this.state.dialogBody)}
					handleCancel={() => this.handleClose(this.state.dialogBody)}
					handleSubmit={() => this.handleClose(this.state.dialogBody)}>
					<div>
						{this.state.fromHeaderENG && this.getLabelValue("28648")}
						{!this.state.fromHeaderENG && (this.props.errorMessageLabels && this.props.errorMessageLabels[this.state.dialogBody] &&
							this.props.errorMessageLabels[this.state.dialogBody].MTEXT || 'Warning')}
					</div>
				</ConfirmationDialog>
				}
				{this.state.showValueConfirmationDialog && <ConfirmationDialog
					hasError={!this.state.hasWarning}
					hasWarning={this.state.hasWarning}
					isOpen={this.state.showValueConfirmationDialog}
					dialogTitle={this.state.dialogTitle}
					submitText={TEXT_OK}
					cancelText={TEXT_CANCEL}
					handleClose={() => this.closeValueDialog(false)}
					handleCancel={() => this.closeValueDialog(false)}
					handleSubmit={() => this.closeValueDialog(this.state.dialogContent)}>
					<div>
						{(this.props.errorMessageLabels[this.state.dialogContent] && this.props.errorMessageLabels[this.state.dialogContent].MTEXT)
							|| this.state.dialogContent}
					</div>
				</ConfirmationDialog>
				}
			</React.Fragment>
		);
	}
}

export default withStyles(style)(JobhistoryProperties);

import React, { memo } from 'react';
import { Table, TableBody, TableHead, TableRow, Box, makeStyles } from '@material-ui/core/';
import { CustomTableCell } from '../OrderProperties/OrderSummary';
const useStyles = makeStyles({
    tableRow: {
        '&:nth-of-type(even)': {
            backgroundColor: 'var(--list-alternate-row)',
            color: 'var(--text) !important'
        }
    },
    table: {
        width: 'inherit',
        margin: '0 0.5rem',
        '& tbody': {
            display: 'block',
            overflowY: props => props.rows > 4 ? 'scroll' : false,
            maxHeight: '7rem',
        },
        '& tr': {
            display: 'table',
            width: '100%'
        },
        '& thead': {
            width: props => props.rows > 4 ? 'calc(100% - 0.5rem)' : '100%',
            backgroundColor: 'none',
            display: 'table',
        }
    },
    tableCellBorder: {
        border: '1px solid var(--list-divider-line)'
    },
})
const CustomTable = (props) => {
    const classes = useStyles({ rows: props.rowData?.length || 0 });
    const rowData = props.rowData || [];
    return (
        <Box display="flex" flexDirection="column" marginX="0.5rem">
            {props.title ? <label style={{ padding: '0 13px' }}>{props.title}</label> : ''}
            <Table className={classes.table}>
                <TableHead>
                    <TableRow className={classes.tableRow}>
                        <CustomTableCell className={classes.tableCellBorder}>Field</CustomTableCell>
                        <CustomTableCell className={classes.tableCellBorder}>Value</CustomTableCell>
                    </TableRow>
                </TableHead>
                <TableBody>
                    {!!rowData?.length && rowData.map((ele, i) => (
                        <TableRow
                            key={ele.field + i}
                            className={classes.tableRow}
                        >
                            <CustomTableCell className={classes.tableCellBorder}>{ele.field}</CustomTableCell>
                            <CustomTableCell className={classes.tableCellBorder}>{ele.value}</CustomTableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </Box>
    );
}

export default memo(CustomTable);
import React, { Component } from 'react'
import { withStyles, Button, Box } from '@material-ui/core';
import CardComponent from 'components/common/CardComponent';
import {
	ITEM_ON_DEAL_LABEL_TAB_KEY,
	DEAL_SUMMARY_LABEL_TAB_KEY,
	RESTRICTIONS_CARD_KEY,
	BILL_BACK_CARD_KEY,
	SPECIAL_TERMS_CARD_KEY,
	GENERAL_CARD_KEY
} from "../constants";
import FormFieldsGenerator from 'components/common/FormFieldsGenerator';
import FormattedMessageComponent from 'components/common/FormattedMessageComponent';
import DefaultAllowanceEmbeddedList from 'containers/DealsEmbeddedListPage/DefaultAllowanceEmbeddedList'

const style = theme => ({
	pageContainer: {
		display: 'flex',
		backgroundColor: 'var(--background-app)',
		borderTop: 'none',
		padding: '10px 10px',
	},
	pageContainerThirty: {
		width: '33.3%',
		display: 'flex',
		flexDirection: 'column',
	},
	simpleCardGroup: {
		width: '100%',
		display: 'flex',
		justifyContent: 'space-around',
	},
	card: {
		padding: '0px',
		backgroundColor: 'var(--background-content)',
		borderRadius: '4px',
		width: '100%',
		margin: '10px',
		'& .MuiCardHeader-root': {
			padding: '22px 20px 0 20px'
		},
		'& .MuiCardContent-root': {
			padding: '16px 15px 10px 15px'
		}
	},
	marginLeftZero: {
		marginLeft: '0',
	},
	marginRightZero: {
		marginRight: '0',
	},
	xyz: {
		display: 'column'
	},
	adjustHeight: {
		height: '21.7rem'
	},
});
class DealSummary extends Component {
	constructor(props) {
		super(props);
		this.state = {

		}
		this.getValueData = this.getValueData.bind();
		this.getLabelValue = this.getLabelValue.bind();
	};
	getValueData(valueData, newValueData) {
		if (Object.keys(valueData).length && Object.keys(newValueData).length &&
			(JSON.parse(JSON.stringify(valueData)) !== JSON.parse(JSON.stringify(newValueData)))) {
			return newValueData;
		}
		return valueData;
	}

	getLabelValue(id) {
		return <FormattedMessageComponent id={id} />;
	}
	render() {
		const { classes, columnDefs, currentOwnerName, filterCriteriaDetails,
			globalDateFormat, globalFilterOptions, pageFilterOptions, currentPage, loading, canUpdateComponent,
			dealSummaryLabelsData, valueData, newValueData } = this.props;
		const { tabcards } = dealSummaryLabelsData;

		return (<React.Fragment>
			<div className={classes.pageContainer}>
				<div className={classes.pageContainerThirty}>
					<div className={classes.simpleCardGroup}>
						{!loading && currentPage && tabcards && tabcards.length && tabcards.map(formCard => {
							if (formCard.cardkey == RESTRICTIONS_CARD_KEY && valueData && newValueData) {
								return <CardComponent title={formCard.cardtitle} className={classes.card + ' ' + classes.marginLeftZero + ' ' + classes.adjustHeight}>
									<FormFieldsGenerator
										currentOwnerName={currentOwnerName}
										labelDisplayCharacters={20}
										valueDisplayCharacters={20}
										handleSubmitDataCallBack={() => { }}
										key={formCard.cardkey}
										fieldsArray={JSON.parse(JSON.stringify(formCard.cardfields))}
										valuesArray={this.getValueData(valueData, newValueData)}
										handleChangeValue={(key, val, field) => this.props.handleChangeValue(key, val, field)}
										enableAddButton={() => { }}
										globalDateFormat={globalDateFormat}
										filterCriteriaDetails={filterCriteriaDetails}
										pageFilterOptions={pageFilterOptions}
										globalFilterOptions={globalFilterOptions}
										columnDefs={columnDefs}
										currentPage={currentPage}
										canUpdateComponent={canUpdateComponent}
										noMassMaintenance={true}
									/>
								</CardComponent>
							}
						})}
					</div>
				</div>
				<div className={classes.pageContainerThirty}>
					<div className={classes.simpleCardGroup}>
						{!loading && currentPage && tabcards && tabcards.length && tabcards.map(formCard => {
							if (formCard.cardkey == BILL_BACK_CARD_KEY && valueData && newValueData) {
								return <CardComponent title={formCard.cardtitle} className={classes.card + ' ' + classes.marginLeftZero + ' ' + classes.adjustHeight}>
									<FormFieldsGenerator
										currentOwnerName={currentOwnerName}
										labelDisplayCharacters={20}
										valueDisplayCharacters={20}
										handleSubmitDataCallBack={() => { }}
										key={formCard.cardkey}
										fieldsArray={JSON.parse(JSON.stringify(formCard.cardfields))}
										valuesArray={this.getValueData(valueData, newValueData)}
										handleChangeValue={(key, val, field) => this.props.handleChangeValue(key, val, field)}
										enableAddButton={() => { }}
										globalDateFormat={globalDateFormat}
										filterCriteriaDetails={filterCriteriaDetails}
										pageFilterOptions={pageFilterOptions}
										globalFilterOptions={globalFilterOptions}
										columnDefs={columnDefs}
										currentPage={currentPage}
										canUpdateComponent={canUpdateComponent}
										noMassMaintenance={true}
									/>
								</CardComponent>
							}
						})}
					</div>
				</div>
				<div className={classes.pageContainerThirty}>
					<div className={classes.simpleCardGroup + classes.xyz}>
						{!loading && currentPage && tabcards && tabcards.length && tabcards.map(formCard => {
							if (formCard.cardkey == SPECIAL_TERMS_CARD_KEY && valueData && newValueData) {
								return <CardComponent title={this.getLabelValue(SPECIAL_TERMS_CARD_KEY)} className={classes.card + ' ' + classes.marginLeftZero}>
									<FormFieldsGenerator
										currentOwnerName={currentOwnerName}
										labelDisplayCharacters={20}
										valueDisplayCharacters={20}
										handleSubmitDataCallBack={() => { }}
										key={formCard.cardkey}
										fieldsArray={JSON.parse(JSON.stringify(formCard.cardfields))}
										valuesArray={this.getValueData(valueData, newValueData)}
										handleChangeValue={(key, val, field) => this.props.handleChangeValue(key, val, field)}
										enableAddButton={() => { }}
										globalDateFormat={globalDateFormat}
										filterCriteriaDetails={filterCriteriaDetails}
										pageFilterOptions={pageFilterOptions}
										globalFilterOptions={globalFilterOptions}
										columnDefs={columnDefs}
										currentPage={currentPage}
										canUpdateComponent={canUpdateComponent}
										noMassMaintenance={true}
									/>
								</CardComponent>
							}
						})}
						{!loading && currentPage && tabcards && tabcards.length && tabcards.map(formCard => {
							if (formCard.cardkey == GENERAL_CARD_KEY && valueData && newValueData) {
								return <CardComponent title={this.getLabelValue(GENERAL_CARD_KEY)} className={classes.card + ' ' + classes.marginLeftZero}>
									<FormFieldsGenerator
										currentOwnerName={currentOwnerName}
										labelDisplayCharacters={20}
										valueDisplayCharacters={20}
										handleSubmitDataCallBack={() => { }}
										key={formCard.cardkey}
										fieldsArray={JSON.parse(JSON.stringify(formCard.cardfields))}
										valuesArray={this.getValueData(valueData, newValueData)}
										handleChangeValue={(key, val, field) => this.props.handleChangeValue(key, val, field)}
										enableAddButton={() => { }}
										globalDateFormat={globalDateFormat}
										filterCriteriaDetails={filterCriteriaDetails}
										pageFilterOptions={pageFilterOptions}
										globalFilterOptions={globalFilterOptions}
										columnDefs={columnDefs}
										currentPage={currentPage}
										canUpdateComponent={canUpdateComponent}
										noMassMaintenance={true}
									/>
								</CardComponent>
							}
						})}
					</div>
				</div>
			</div>
			<DefaultAllowanceEmbeddedList
				valueData={valueData}
				newValueData={newValueData}
				filterCriteriaDetails={filterCriteriaDetails}
				globalDateFormat={globalDateFormat}
				globalFilterOptions={globalFilterOptions}
				pageFilterOptions={pageFilterOptions}
				currentPage={currentPage}
				currentOwnerName={currentOwnerName}
				dealPropertiesPage={this.props.dealPropertiesPage}
				setErrorsForApiFailure={(errorMessage) => this.setErrorsForApiFailure(errorMessage)}
				dealAllowanceUpdate={(data) => this.props.dealAllowanceUpdate(data)} 
				onAddRec ={this.props.onAddRec}
				onRemoveRec ={this.props.onRemoveRec}
				onUpdateRec ={this.props.onUpdateRec}
				deal ={this.props.stateData}
				onSetDataValueChange={this.props.onSetDataValueChange}
				setUpdateRecordsFlag={this.props.setUpdateRecordsFlag}
				errorMessageLabels={this.props.errorMessageLabels}
				canUpdateComponent={this.props.canUpdateComponent}
				/>
		</React.Fragment>
		);
	}
}

export default withStyles(style)(DealSummary);
/** Change Log
 * LogStart --  E3C-33195 - Kumar A- 16 September,2021 - 2022.1.0.0 Unified Product
 *              Story: E3C-33195 --Code Cleanup
*/
import React from 'react';
import { withStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import FormattedMessageComponent from 'components/common/FormattedMessageComponent';
import ItemClassificationEmbeddedList from '../../../containers/ItemClassificationEmbeddedList';
import { LABEL_COMPANY_IC, }
    from './constants';


const styles = theme => ({
    root: {
        flexGrow: 1,
        width: '100%'
    },
    pageContainer: {
        display: 'flex',
        backgroundColor: 'var(--background-app)',
        borderTop: 'none',
        padding: '10px 20px',
    },
    card: {
        height: '430px',
        width: '50%',
    },
    cardHeader: {
        color: 'white',
        marginTop: '-10px',
        fontSize: '16px'
    }
});

class ClassificationControl extends React.PureComponent {

    constructor(props) {
        super(props)
        this.state = {
            data: [],
        }
        this.onSetDataValueItemChange = this.onSetDataValueItemChange.bind(this);
    }

    sethaserror = (val) => {
        this.setState({ hasError: val });
    }

    getLabelValue(id) {
        return <FormattedMessageComponent id={id} />;
    }

    onSetDataValueItemChange(columnName, rowIndex, value) {
        if (columnName == 'CSKU_CLASS') {
            columnName = 'CICC' + (rowIndex + 1);
        }
        if (columnName == 'CSRVLVL') {
            columnName = 'CISO' + (rowIndex + 1);
        }
        if (columnName == 'CITMPCLS') {
            columnName = 'CICP' + (rowIndex + 1);
        }
        this.props.values.companyClassificationData[columnName] = value;
    }

    onSaveCompanyData = company => {
        this.props.onSaveItemCompanyData(company);
    }

    render() {
        const { classes, handleChange, values } = this.props;

        return (
            <div className={classes.root}>
                <div className={classes.pageContainer}>
                    <Card className={classes.card}>
                        <CardHeader className={classes.cardHeader}
                            title={this.getLabelValue(
                                LABEL_COMPANY_IC,
                            )}
                        />
                        <ItemClassificationEmbeddedList
                            values={values.itemClassificationSubmit}
                            company={this.props.values.companyClassificationData}
                            onSaveCompanyData={this.onSaveCompanyData}
                            handleChange={handleChange}
                            onItemClassificationSubmit={this.props.onItemClassificationSubmit}
                            errorMessageLabels={this.props.errorMessageLabels}
                            setSaveDataValue={this.props.setSaveDataValue}
                            submitItemLabelsData={this.props.submitItemLabelsData}
                            canUpdateComponent={this.props.canUpdateComponent}
                            onSetDataValueItemChange={this.onSetDataValueItemChange} />
                    </Card>
                </div>
            </div>
        )
    }

}

export default (withStyles(styles)(ClassificationControl));
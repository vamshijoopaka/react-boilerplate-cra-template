/**
 *
 * EventProperties
 *
 */

import React, { Component } from 'react'
import { withStyles, Button, Box } from '@material-ui/core';
import KeyboardArrowDownIcon from '@material-ui/icons/KeyboardArrowDown';
import Typography from '@material-ui/core/Typography';
import KeyboardArrowUpIcon from '@material-ui/icons/KeyboardArrowUp';
import SaveIcon from '@material-ui/icons/Save';
import MoreVertIcon from '@material-ui/icons/MoreVert';
import FilterIcon from "../../images/icon_filter.png";
import { isEqual } from 'lodash';
import FormattedMessageComponent from '../common/FormattedMessageComponent';
import AppBar from '@material-ui/core/AppBar';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import moment from 'moment';
import Spinner from 'components/Common/Spinner';
import ContextMenu from '../common/ContextMenu';
import ContextMenuCreateNew from '../common/ContextMenuCreateNew';
import ConfirmationDialog from 'components/common/ConfirmationDialog';
import BreadcrumbContextMenu from 'components/common/BreadcrumbContextMenu';
import Filter from 'containers/common/Filter';
import GridErrorMessages from 'components/common/GridErrorMessages';
import CopyDialog from "./CopyDialog";
import DeleteDialog from './DeleteDialog'
import EventEffectMaintenanceDialog from './EventEffectMaintenanceDialog'
import EventDefaults from 'containers/common/EventDefaults';
import EventItems from 'containers/common/EventItems';
import EventStatistics from 'containers/common/EventStatistics';
import Header from 'containers/common/AddEvent/header.js';
import {
	EVENTS_PROPERTIES_PAGE,
	GLOBAL_FILTER_OPTIONS,
	COLUMN_VALUE_ACCESSOR,
	INITIAL_PAGE_PROPS,
	EVENTS_LIST_PAGE,
	TEXT_OK, TEXT_ALERT,
	EVENT_BEGIN_DATE_ACCESSOR,
	EVENT_END_DATE_ACCESSOR,
	EVENT_DESCRIPTION,
} from '../common/constants';
import {
	prepareValueDataForEvents,
	getFilterDataFromLocalStorage,
	getFilterDataFromCriteriaDetails,
	getDateFromJulian,
	getJulianValue,
	getDateFormatValue,
	getUpdateRestrictionOnComponent,
	capitalizeFirstLetter,
} from 'utils/util';
import { getDBSelectorFilterValues, prepareTooltipValues } from 'utils/filterData';
import { onChangeContextMenu, updateBreadCrumbContextMenu } from 'utils/contextMenu';

import {
	LABEL_EVENT_DEFAULTS,
	LABEL_ITEMS_ON_EVENT,
	LABEL_STATISTICS,
	CONTEXT_MENU_EVENT_ACTIONS,
	LABEL_COPY, LABEL_DELETE,
	LABEL_LIST_URL_DATA,
	DEFAULT_VALUE_URL_DATA,
	LABEL_ACTIONS,
	CONTEXT_MENU_EVENT_BUTTON_ACTIONS,
	LABEL_EVENT_EFFECT_MAINTENANCE,
} from "./constants";

const style = () => ({
	propertiesContentWrapper: {
		margin: '10px auto',
		borderRadius: '4px',
		overflow: 'hidden',
		boxShadow: '0 2px 4px var(--secondary-s10)',
		overflowX: 'auto'
	},
	propertiesHeaderContainer: {
		width: '100%',
		marginBottom: '1.5rem',
		backgroundColor: 'var(--background-app)',
		borderRadius: '4px',
		borderTopLeftRadius: '0px',
		borderTopRightRadius: '0px',
		overflow: 'hidden',
		boxShadow: '0 4px 4px var(--secondary-s10)',
		overflowX: 'auto'
	},
	boookingDetailContainer: {
		display: 'flex',
		width: '100%',
		backgroundColor: 'var(--background-content)',
		fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
		alignItems: 'center',
		padding: '0 0 0 24px',
		position: 'relative',
		minWidth: '630px'
	},
	boookingDetailDetailsWrapper: {
		width: '100%',
		display: 'flex',
	},
	pageContainer: {
		display: 'flex',
		backgroundColor: 'var(--background-app)',
		borderTop: 'none',
		padding: '1.5rem 1rem',
	},
	boookingArrow: {
		padding: '0 !important',
		margin: '0',
		minWidth: '16px',
		background: 'none',
		height: '16px',
		width: '16px',
	},
	eventArrowWrapper: {
		display: 'flex',
		flexDirection: 'column',
		border: '1px solid var(--primary-default)',
		borderRadius: '4px',
		justifyContent: 'center',
		alignItems: 'baseline',
		height: '38px',
		padding: '2px',
	},
	eventDetailRow: {
		width: '75%',
		display: 'flex',
		flexWrap: 'wrap',
		padding: '0px 0 24px 0',
		paddingLeft: '15px'
	},
	eventDetail: {
		padding: '0px 0px 0 0px',
		lineHeight: '1.1',
	},
	eventActions: {
		// top: '24px',
		padding: '0px 20px 20px 20px',
		right: '16px',
		display: 'flex',
		position: 'absolute',
		alignItems: 'center',
		justifyContent: 'space-between',
		'@media (max-width: 1220px)': {
			flexWrap: 'wrap',
			width: '250px'
		}
	},
	buttonActions: {
		display: 'flex',
		alignItems: 'center',
		'@media (max-width: 1220px)': {
			marginBottom: '20px'
		},
	},
	eventActionsFilter: {
		minWidth: '37px',
		border: '1px solid var(--primary-default)',
		height: '32px',
		marginLeft: '15px',
		'@media (max-width: 1220px)': {
			marginLeft: '0px'
		},
		'& img': {
			width: '14px',
			height: '14px'
		},
		'& svg': {
			width: '18px',
			height: '18px'
		}
	},
	menuButton: {
		minWidth: '37px',
		border: '1px solid var(--primary-default)',
		height: '32px',
		marginLeft: '15px',
		borderRadius: '4px',
		display: 'flex',
		alignItems: 'center',
		justifyContent: 'center',
		'@media (max-width: 1220px)': {
			marginLeft: '0px'
		},
	},
	showStep: {
		display: 'block'
	},
	hideStep: {
		display: 'none'
	},
	errorGrid: {
		position: 'fixed',
		top: '3rem',
		left: '33%',
		zIndex: 1200
	},
	buttonActionsSecondChild: {
        marginRight: '15px',
        '& .MuiButton-outlinedPrimary': {
            width: '100px',
            height: '28px'
        }
	},
	ActionsContextMenu: {
	},
	vendorArrow: {
        padding: '0 !important',
        margin: '0',
        minWidth: '16px',
        background: 'none',
        height: '16px',
        width: '16px',
    },
});

function TabContainer(props) {
	return (
		<Typography className={'minWidth1100'} component="div">
			{props.children}
		</Typography>
	);
}

class EventProperties extends Component {
	constructor(props) {
		super(props);
		this.state = {
			tab: 0,
			isSaveDataDisabled: true,
			headerData: false,
			columnDefs: [],
			stateData: false,
			totalCount: 0,
			fromPage: false,
			hasError: false,
			errorId: false,
			canUpdateComponent: false,
			changeDataAPI: false,
			openFilterPopup: false,
			previousFilterValues: false,
			showConfirmationDialog: false,
			dialogTitle: '',
			hasWarning: false,
			fromListPage: null,
			hasFiltersChanged: false,
			isDataLoaded: false,
			isInitialAPICall: true,
			valueDataFailureMessages: [],
			saveDisabled: false,
			isOpenActionsContextMenu: false,
			menuRef: null,
			contextMenuList: [...CONTEXT_MENU_EVENT_ACTIONS],
			isFiltersChanged: false,
			openCopyPopup: false,
			openDeletePopup: false,
			dialogBody: false,
			replaceValues: [],
			isOpenActions: false,
			actionMenuRef: null,
			actionList: CONTEXT_MENU_EVENT_BUTTON_ACTIONS,


		};

		this.setIsOpenActionsButtonContextMenu = this.setIsOpenActionsButtonContextMenu.bind(this);

	}

	handleNoDataSets() {
		const { eventDetailsLabelsData, copyEventDetailsLabelsData, eventEffectMaintenanceLabelsData } = this.props.eventsProperties;
		if (this.state.isDataLoaded) {
			if ((eventDetailsLabelsData && Object.keys(eventDetailsLabelsData) && Object.keys(eventDetailsLabelsData).length) &&
				copyEventDetailsLabelsData && copyEventDetailsLabelsData.length
				(eventEffectMaintenanceLabelsData && Object.keys(eventEffectMaintenanceLabelsData) && Object.keys(eventEffectMaintenanceLabelsData).length)
			) {
				// do nothing here
			} else {
				this.closeCurrentTab();
			}
		}
	}

	handleEventHeaderFilterClick = () => {
		if (this.state.isFiltersChanged && this.props.eventsProperties.isValueDataAPIFailure) {
			this.props.onSetFilterProps(this.state.previousFilterValues);
			this.props.setGlobalFilterProps(this.state.previousFilterValues);
			this.props.setChildTabFilterProps(this.state.previousFilterValues);
			this.setState({ isFiltersChanged: false });
			this.props.setValueDataAPIFailureFlag(false);
		}
		this.setState({ openFilterPopup: !this.state.openFilterPopup });
	}

	getLabelValue = (id) => {
		return <FormattedMessageComponent id={id} />;
	}

	setFilterValuesFromState = (values) => {
		const filterValues = [];
		const { columnDefs } = this.state;
		if ((columnDefs && columnDefs.length) || (this.columnDefData && this.columnDefData.length)) {
			const colData = columnDefs && columnDefs.length ? columnDefs : this.columnDefData;
			values.forEach(value => {
				const isExists = colData.find(
					column => column[COLUMN_VALUE_ACCESSOR].trim() == value.accessor,
				);
				if (isExists) {
					filterValues.push(value);
				}
			});
			if (filterValues && filterValues.length) {
				this.props.onSetFilterProps(filterValues);
				this.props.setGlobalFilterProps(filterValues);
				return filterValues;
			}
		} else {
			this.props.onSetFilterProps(values);
			this.props.setGlobalFilterProps(values);
			return values;
		}
	}

	getApiObj = (recordData, record, currentPage, pageProps) => {
		let recordObj = false;
		if (record) {
			recordObj = record;
		}
		const apiObj = {
			recordData,
			pageProps,
			direction: pageProps.isForwardDirection,
			record: recordObj,
			currentPage,
			parentPage: EVENTS_LIST_PAGE,
		};
		return apiObj;
	}

	forceUpdateHandler = () => {
		this.forceUpdate();
	}
	makePrevNextAPICall = flag => {
		const { filterProps, valueData, sortProps } = this.props.eventsProperties;
		const data = JSON.parse(JSON.stringify(INITIAL_PAGE_PROPS));
		data.isForwardDirection = flag;
		data.pageSize = 3;
		this.props.getPageUpDownFlagAPI(
			this.getApiObjForPageUpDownFlags(filterProps, valueData, EVENTS_LIST_PAGE, data, sortProps, flag)
		);
	};

	prepareTooltipData = () => {
		const { detailCallData, eventColumnDefs } = this.props.eventsProperties;
		let tooltipData = prepareTooltipValues(EVENTS_LIST_PAGE, detailCallData, eventColumnDefs, 'eventsproperties');
		this.props.setDataInTabs("toolTipData", JSON.parse(JSON.stringify(tooltipData)));
	}

	setHeaderAndSendAPI = (jsonData, from) => {
		this.setState({ stateData: jsonData });
		let valueData = prepareValueDataForEvents(DEFAULT_VALUE_URL_DATA, jsonData, from);
		this.sendAPICallForValues(valueData, jsonData);
	}

	sendAPICallForValues = (valueData) => {
		let evntval = valueData.filter(a => a.accessor == 'EVNT');
		let compval = valueData.filter(a => a.accessor == 'COMP');
		let filterProps = [{ "accessor": "EVNT", "operator": "=", "fieldValue": evntval[0].fieldValue, "prefixFlag": 0 }];
		filterProps.push({ "accessor": "COMP", "operator": "=", "fieldValue": compval[0].fieldValue, "prefixFlag": 0 });
		let page = { pageSize: 3 };
		this.props.getValueList(filterProps, page, true, {});
	}

	handleValueDataErrorMessages = (content) => {
		this.setState({ showValueConfirmationDialog: true });
		this.setState({ dialogTitle: TEXT_ALERT });
		this.setState({ dialogContent: content });
	}

	closeValueDialog = () => {
		this.setState({ showValueConfirmationDialog: false });
		if (this.state.valueDataFailureMessages && this.state.valueDataFailureMessages.length) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.shift();
			this.setState({ valueDataFailureMessages: values });
		}
	}

	setRecordDataValues = () => {
		let isRecordValuesExists = false, isLocalStorageValuesExists = false, isFilterValuesExists = false;
		const { history } = this.props;
		var paramsString = window.location.search;
		if (paramsString && paramsString.length) {
			let paramsArray = paramsString.split("?");
			if (paramsArray && paramsArray.length && paramsArray.length > 1) {
				let params = paramsArray[1].split("&");
				let tabId = params[0].split("=")[1];
				let breadCrumbId = params[1].split("=")[1];
				let localStorageValues = getFilterDataFromLocalStorage(tabId, breadCrumbId);
				if (localStorageValues && Object.keys(localStorageValues) && Object.keys(localStorageValues).length) {
					isLocalStorageValuesExists = true;
					let itemData = localStorageValues.item_data, dbSelectorValues = [];
					if (itemData && itemData.recordData && localStorageValues.childType) {
						this.columnDefData = JSON.parse(JSON.stringify(itemData.recordData.columnDefs))
						this.setState({ columnDefs: itemData.recordData.columnDefs });
						this.props.setCurrentRecord(itemData.recordData.data);
						this.setState({ totalCount: itemData.recordData.totalCount });
						this.setState({ fromPage: itemData.recordData.fromPage });
						this.setState({ fromListPage: itemData.recordData.fromPage });
						this.props.setRowIndex(itemData.recordData.rowIndex);
						this.setHeaderAndSendAPI(itemData.recordData.data, itemData.recordData.fromPage);
						isRecordValuesExists = true;
						this.props.setSelectedRecord(false, false);
						if (itemData) {
							if (itemData.dbSelector && itemData.dbSelector.length) {
								dbSelectorValues = JSON.parse(JSON.stringify(itemData.dbSelector));
							}
							if (itemData.filterProps && itemData.filterProps.length) {
								this.setState({ hasFiltersChanged: false });
								isFilterValuesExists = true;
								let values = getDBSelectorFilterValues(dbSelectorValues, itemData.filterProps);
								this.setFilterValuesFromState(values);
							} else if (dbSelectorValues && dbSelectorValues.length) {
								this.setState({ hasFiltersChanged: false });
								isFilterValuesExists = true;
								let dbValues = getDBSelectorFilterValues(dbSelectorValues, []);
								this.setFilterValuesFromState(dbValues);
							}
							if (itemData.defaultFilterInfo && Object.keys(itemData.defaultFilterInfo) && Object.keys(itemData.defaultFilterInfo).length) {
								this.props.setDefaultFilterpropsForTabs(itemData.defaultFilterInfo);
							}
							if (itemData.selectedPropertiesTab) {
								this.setState({ tab: itemData.selectedPropertiesTab });
							}
						}
					}

				}
				if (!isLocalStorageValuesExists && tabId && breadCrumbId) {
					history.push({ pathname: '/Dashboard' });
				}
			}
		}

		let filterOptions = GLOBAL_FILTER_OPTIONS;
		const { dbSelector } = this.props;
		if (!isFilterValuesExists) {
			let gbValues = getDBSelectorFilterValues(dbSelector, filterOptions);
			this.setFilterValuesFromState(gbValues);
		}
		return isRecordValuesExists;
	}

	resetValues = () => {
		this.props.setInitialState();
		this.props.setValueDataFlag(false);
		this.props.setCurrentRecord(null);
		this.props.getEventsColumnDefs({ type: EVENTS_LIST_PAGE });
		this.setState(({ canUpdateComponentSecurity }) => ({ canUpdateComponent: canUpdateComponentSecurity }));
	};

	componentDidMount = () => {
		this.resetValues();
		let currentPage = EVENTS_PROPERTIES_PAGE;
		this.props.onLoadCurrentPage(currentPage);
		const { detailCallData } = this.props.eventsProperties;
		this.props.setIsShowContextMenu(true);
		let isFound = this.setRecordDataValues();

		if (!isFound) {
			if (this.props.location && this.props.location.state) {
				this.props.setCurrentRecord(this.props.location.state.data);
				this.setState({ columnDefs: this.props.location.state.columnDefs });
				this.setState({ fromPage: this.props.location.state.fromPage });
				this.props.setRowIndex(this.props.location.state.rowIndex);
				this.setHeaderAndSendAPI(this.props.location.state.data, EVENTS_LIST_PAGE);
			}
		}

		if (detailCallData && Object.keys(detailCallData) && Object.keys(detailCallData).length) {
			this.props.setSelectedRecord(detailCallData, EVENTS_LIST_PAGE);
		}
		let labelFilters = LABEL_LIST_URL_DATA;
		this.props.getLabelsList({ recordData: labelFilters, currentPage: 'eventproperties' });
		this.setState({ isSaveDataDisabled: true });
		let canUpdateComponent = getUpdateRestrictionOnComponent(capitalizeFirstLetter(EVENTS_LIST_PAGE), this.props.authorizedComponentsList);
		this.setState({ canUpdateComponent, canUpdateComponentSecurity: {...canUpdateComponent} });
		this.setState(({ contextMenuList }) => ({ contextMenuList: contextMenuList.map(ele => ({ ...ele, isDisable: !canUpdateComponent.update })) }));
	}
	componentDidUpdate = (prevProps, prevState) => {
		const { pageUpDownData,
			isSaveSuccess,
			filterProps,
			isValueDataAPICall,
			isValueDataAPIFailure,
			eventColumnDefs,
			filterCriteriaDetails,
			detailCallData,
			labelsDataFailure,
			isAPIforVendorList,
			isAPIforItemList,
			isAPIforWarehouseList,
			isAPIforEventUpdate,
			previousNextFlagAPIFailure,
			isAPIforEventDelete,
			isAPIforEventColums,
			isCopySuccess,
			isDeleteSuccess,
			isAPIforEventDeleteAll,
			isEffectMaintenanceSuccess,
		} = this.props.eventsProperties

		if (this.state.valueDataFailureMessages && this.state.valueDataFailureMessages.length
			&& (JSON.stringify(this.state.valueDataFailureMessages) != JSON.stringify(prevState.valueDataFailureMessages))) {
			this.handleValueDataErrorMessages(this.state.valueDataFailureMessages[0]);
		}

		if (labelsDataFailure && (labelsDataFailure != prevProps.eventsProperties.labelsDataFailure)) {
			this.setState({ isDataLoaded: true })
			this.handleNoDataSets();
			this.props.setLabelDataFlags({ key: 'labelsDataFailure', value: false });
		}

		if (isAPIforVendorList && (isAPIforVendorList != prevProps.eventsProperties.isAPIforVendorList)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to fetch Vendor List");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isAPIforVendorList', value: false });
		}

		if (isAPIforItemList && (isAPIforItemList != prevProps.eventsProperties.isAPIforItemList)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to fetch Item list");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isAPIforItemList', value: false });
		}

		if (isAPIforWarehouseList && (isAPIforWarehouseList != prevProps.eventsProperties.isAPIforWarehouseList)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to fetch Warehouse List");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isAPIforWarehouseList', value: false });
		}

		if (isAPIforEventUpdate && (isAPIforEventUpdate != prevProps.eventsProperties.isAPIforEventUpdate)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to Update Event");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isAPIforEventUpdate', value: false });
		}

		if (previousNextFlagAPIFailure && (previousNextFlagAPIFailure != prevProps.eventsProperties.previousNextFlagAPIFailure)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to fetch Previous Next Flag");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'previousNextFlagAPIFailure', value: false });
		}
		if (isAPIforEventDelete && (isAPIforEventDelete != prevProps.eventsProperties.isAPIforEventDelete)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("E11603");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isAPIforEventDelete', value: false });
		}

		if (isAPIforEventColums && (isAPIforEventColums != prevProps.eventsProperties.isAPIforEventColums)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to fetch Event Columns");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isAPIforEventColums', value: false });
		}
		if (isCopySuccess && (isCopySuccess != prevProps.eventsProperties.isCopySuccess)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("E99938");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isCopySuccess', value: false });
		}
		if (isDeleteSuccess && (isDeleteSuccess != prevProps.eventsProperties.isDeleteSuccess)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("E99939");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isDeleteSuccess', value: false });
		}

		// if (isEffectMaintenanceSuccess && (isEffectMaintenanceSuccess != prevProps.eventsProperties.isEffectMaintenanceSuccess)) {
		// 	let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
		// 	values.push("E97272");
		// 	this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
		// 	this.props.setLabelDataFlags({ key: 'isEffectMaintenanceSuccess', value: false });
		// }

	// "E97272": { >>>>>>>>>>>>>>>>>>In ENG Translations <<<<<<<<<<<<<<<<<<<<<<
    //     "MLANG": "ENG",
    //     "MPROD": " ",
    //     "MMESG": "97272   ",
    //     "MMPFX": "BOOK ",
    //     "MMSEV": "1 ",
    //     "MMTYP": "INFORMATION    ",
    //     "MTEXT": "Event Effect Maintenance completed.                                                                                                                                                                                                                                      "
    // },

		if (isAPIforEventDeleteAll && (isAPIforEventDeleteAll != prevProps.eventsProperties.isAPIforEventDeleteAll)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to Delete All Events");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isAPIforEventDeleteAll', value: false });
		}

		if ((JSON.stringify(filterProps) != JSON.stringify(prevProps.eventsProperties.filterProps)) && filterProps && filterProps.length) {
			this.setState({ isFiltersChanged: true });
			this.props.setChildTabFilterProps(filterProps);
			if (!this.state.isInitialAPICall) {
				if (this.state.fromPage != EVENTS_LIST_PAGE && !this.state.hasFiltersChanged) {
					this.setHeaderAndSendAPI(this.state.stateData, this.state.fromPage)
				} else {
					this.makeAPICallForPageUpDown('down', {});
				}
			}
		}

		if ((filterCriteriaDetails != prevProps.eventsProperties.filterCriteriaDetails)) {
			this.props.setDataInTabs("defaultFilterInfo", JSON.parse(JSON.stringify(filterCriteriaDetails)));
			if (filterCriteriaDetails && Object.keys(filterCriteriaDetails) && Object.keys(filterCriteriaDetails).length && eventColumnDefs && eventColumnDefs.length) {
				let list = getFilterDataFromCriteriaDetails(filterCriteriaDetails, eventColumnDefs, EVENTS_LIST_PAGE);
				if (list && list.length) {
					this.props.setGlobalFilterProps(list);
					this.props.onSetFilterProps(list);
				}
			}
		}

		if (detailCallData && !isEqual(detailCallData, prevProps.eventsProperties.detailCallData)) {
			if (Object.keys(detailCallData) && Object.keys(detailCallData).length) {
				if (eventColumnDefs && eventColumnDefs.length) {
					this.prepareTooltipData();
				}
				this.props.setSelectedRecord(detailCallData, EVENTS_LIST_PAGE);
				this.setReadOnly(detailCallData);

				//Effect Maintenance Action (Event End Date > E3 Date) => ENABLE Else DISABLE
				const systemDate = this.props.companyDetails ? this.props.companyDetails.CJDATE : getJulianValue(new Date());
				let actionMenuList = CONTEXT_MENU_EVENT_BUTTON_ACTIONS;
				actionMenuList[0].isDisable = detailCallData.EHENDT <= systemDate ? true : false;
				this.setState({ actionList: actionMenuList });

			}
		}

		if (eventColumnDefs && eventColumnDefs.length && !isEqual(eventColumnDefs, prevProps.eventsProperties.eventColumnDefs) &&
			(detailCallData && Object.keys(detailCallData) && Object.keys(detailCallData).length)) {
			if (!this.state.changeDataAPI) {
				this.prepareTooltipData();
			}
		}
		if (isValueDataAPICall != prevProps.eventsProperties.isValueDataAPICall && isValueDataAPICall) {
			this.setState({ previousFilterValues: prevProps.eventsProperties.filterProps })
			this.setState({ isInitialAPICall: false });
			this.makePrevNextAPICall(true);
			this.props.setValueDataFlag(false);
			if (this.state.isFiltersChanged) {
				this.setState({ openFilterPopup: false });
				this.setState({ isFiltersChanged: false });
			}
		}

		if (isValueDataAPIFailure != prevProps.eventsProperties.isValueDataAPIFailure && isValueDataAPIFailure) {
			this.setState({ isInitialAPICall: false });
			if (this.state.isFiltersChanged) {
				this.setState({ showConfirmationDialog: true });
				this.setState({ hasWarning: true });
				this.setState({ dialogTitle: TEXT_ALERT });
				this.setState({ fromHeaderENG: true });
			} else {
				this.setState({ showConfirmationDialog: true });
				this.setState({ hasWarning: true });
				this.setState({ dialogTitle: TEXT_ALERT });
				this.setState({ fromHeaderENG: true });
			}
		}

		if (this.props.location.search != prevProps.location.search) {
			this.resetValues();
			this.forceUpdateHandler();
			this.setRecordDataValues();
			this.setState({ state: this.state });
		}
		if (pageUpDownData && JSON.stringify(pageUpDownData) != JSON.stringify(prevProps.eventsProperties.pageUpDownData)) {
			this.props.setSelectedRecord(pageUpDownData, EVENTS_LIST_PAGE);
			this.setState({ fromPage: EVENTS_LIST_PAGE });
			this.setState({ isSaveDataDisabled: true });
			this.setHeaderAndSendAPI(pageUpDownData, EVENTS_LIST_PAGE);
			let modifiedData = {
				data: JSON.parse(JSON.stringify(pageUpDownData)),
				fromPage: EVENTS_LIST_PAGE,
				rowIndex: this.props.eventsProperties.rowIndex,
				totalCount: this.state.totalCount,
				fromParent: false,
				columnDefs: this.state.columnDefs,
			};
			this.props.setDataInTabs('recordData', modifiedData);
			this.setReadOnly(pageUpDownData);
		}
		if (isSaveSuccess && isSaveSuccess !== prevProps.eventsProperties.isSaveSuccess) {
			this.setState({ isSaveDataDisabled: true });
		}
	}
	setReadOnly = data => {
		let isReadOnly = !!+data?.EHOPT || false;
		this.props.setDataInTabs('isReadOnly', isReadOnly);
		this.setState(({ contextMenuList }) => ({ contextMenuList: contextMenuList.map(ele => ({ ...ele, isDisable: isReadOnly })) }))
		this.setState(({ canUpdateComponentSecurity: { update = true, view } } = false) => ({ canUpdateComponent: { update: update && !isReadOnly, view } }))
	}
	handleEventHeaderSaveClick = () => {
		const { newValueData, valueData } = this.props.eventsProperties;
		if (this.validateEventDuration()) {
			if (JSON.stringify(newValueData) != JSON.stringify(valueData)) {
				this.props.eventDetailsUpdate(newValueData);
			}
		}
	}

	getApiObjForPageUpDown = (filterData, record, currentPage, pageProps, sortData, pageType) => {
		let recordObj = false
		if (record) {
			recordObj = record;
		}
		let apiObj = {
			sortProps: sortData,
			filterProps: filterData,
			pageProps: pageProps,
			direction: pageProps.isForwardDirection,
			record: recordObj,
			currentPage: currentPage,
			parentPage: EVENTS_LIST_PAGE,
			pageType: pageType
		};
		return apiObj;
	}

	getApiObjForPageUpDownFlags = (filterData, record, currentPage, pageProps, sortData, pageType) => {
		let recordObj = false
		if (record) {
			recordObj = {
				"record": record,
				"flagsOnly": true
			};
		}
		let apiObj = {
			sortProps: sortData,
			filterProps: filterData,
			pageProps: pageProps,
			direction: pageProps.isForwardDirection,
			record: recordObj,
			currentPage: currentPage,
			parentPage: EVENTS_LIST_PAGE,
			pageType: pageType
		};
		return apiObj;
	}

	makeAPICallForPageUpDown = (type, currentRecordData) => {
		const { filterProps, sortProps } = this.props.eventsProperties;
		let data = JSON.parse(JSON.stringify(INITIAL_PAGE_PROPS));
		if (type == 'up') {
			data.isForwardDirection = false;
		} else {
			data.isForwardDirection = true;
		}
		let filterData = JSON.parse(JSON.stringify(filterProps));
		this.props.pageUpDownAPI(this.getApiObjForPageUpDown(filterData, currentRecordData, EVENTS_LIST_PAGE, data, sortProps))
	}
	handleEventHeaderLeftArrowClick = () => {
		const { currentRecordData } = this.props.eventsProperties;
		this.props.setCurrentType('down');
		this.makeAPICallForPageUpDown('down', currentRecordData);
		this.setState({ isSaveDataDisabled: true });
	}

	handleEventHeaderRightArrowClick = () => {
		const { currentRecordData } = this.props.eventsProperties;
		this.props.setCurrentType('up');
		this.makeAPICallForPageUpDown('up', currentRecordData);
		this.setState({ isSaveDataDisabled: true });
	}
	validateEventDuration = () => {
		const { newValueData: eventDefaults } = this.props.eventsProperties;
		const { companyDetails: { CJDATE = false } = false } = this.props
		if (!eventDefaults[EVENT_BEGIN_DATE_ACCESSOR] || !eventDefaults[EVENT_END_DATE_ACCESSOR]) {
			this.setGridError(true, '19702');
			return false;
		}
		let fromDate = getDateFromJulian(eventDefaults[EVENT_BEGIN_DATE_ACCESSOR]);
		let toDate = getDateFromJulian(eventDefaults[EVENT_END_DATE_ACCESSOR]);
		let toWeekMoment = moment(toDate).week()
		let fromWeekMoment = moment(fromDate).week()
		if (+eventDefaults[EVENT_END_DATE_ACCESSOR] < +CJDATE) {
			this.setGridError(true, '19711');
			return false;
		}
		if (!eventDefaults[EVENT_DESCRIPTION]) {
			this.setGridError(true, '19705');
			return false;
		}
		if (fromDate > toDate) {
			this.setGridError(true, '19703');
			return false;
		} else if (+eventDefaults[EVENT_BEGIN_DATE_ACCESSOR] < +CJDATE ||
			+eventDefaults[EVENT_END_DATE_ACCESSOR] < +CJDATE
		) {
			this.setGridError(true, '19704');
			return false;
		} else {
			let weeks = 0;
			let yearEnd = new Date('1970-12-31');
			for (let start = fromDate.getFullYear(); start <= toDate.getFullYear(); start++) {
				yearEnd.setFullYear(start);
				if ((fromDate.getFullYear() === toDate.getFullYear()) && moment(toDate).diff(moment(fromDate), 'days') > 1 && (toWeekMoment !== 1)) { // same year
					weeks = toWeekMoment - fromWeekMoment;
				} else if (fromDate.getFullYear() === toDate.getFullYear() && (toWeekMoment === 1 && fromWeekMoment)) { // same year , end week
					weeks = moment(yearEnd).weeksInYear() - fromWeekMoment + 1;
				} else if (start === fromDate.getFullYear()) {  // start year
					weeks = moment(yearEnd).weeksInYear() - fromWeekMoment;
				} else if (start !== toDate.getFullYear()) {  // neither start nor end year
					weeks = weeks + moment(yearEnd).weeksInYear();
				} else if (start === toDate.getFullYear()) {  // end year
					weeks = weeks + toWeekMoment;
				}
			}
			weeks = weeks + 1;
			if (weeks > 52) {
				let beginDate = getDateFormatValue(eventDefaults[EVENT_BEGIN_DATE_ACCESSOR]);
				let endDate = getDateFormatValue(eventDefaults[EVENT_END_DATE_ACCESSOR]);
				this.setGridError(true, '19831', [beginDate, endDate]);
				return false;
			}
		}
		return true;

	}

	setGridError = (hasError, errorId = false, replaceValues = []) => {
		this.setState({ hasError, errorId, replaceValues })
	}

	handleEventHeaderActionItemSelection = action => {
		switch (action) {
			case LABEL_COPY:
				this.handleCopyDeletePopup('openCopyPopup', true)
				break;
			case LABEL_DELETE:
				this.handleCopyDeletePopup('openDeletePopup', true)
				break;
		}
	}
	handleCopyDeletePopup = (popup, val) => {
		if (popup == 'openCopyPopup') {
			this.setState({ openCopyPopup: val })
		} else if (popup == 'openDeletePopup') {
			this.setState({ openDeletePopup: val })
		}
	}
	handleChangeValue = (key, val, field) => {
		this.props.setValueData({ key, val, field });
		this.setState({ isSaveDataDisabled: false })
	}

	onContextMenuChange = (e, value, check = false, filters = false, title = false) => {
		let defaultFilters = filters;
		let toPage = value;
		let displayName = title;
		onChangeContextMenu(this.props, e, toPage, defaultFilters, displayName);
		this.props.setSelectedValueForTabs('Show Me');
	}

	handleClose = bodyId => {
		this.setState({ showConfirmationDialog: false });
		switch (bodyId) {
			case 'E14029':
				//need to close the current Tab
				break;
		}
		this.closeCurrentTab();
	}

	closeCurrentTab = () => {
		this.props.setNoDataCallBackValue(true);
		const paramsString = window.location.search;
		if (paramsString && paramsString.length) {
			let paramsArray = paramsString.split("?");
			if (paramsArray && paramsArray.length && paramsArray.length > 1) {
				let params = paramsArray[1].split("&");
				let tabId = params[0].split("=")[1];
				let breadCrumbId = params[1].split("=")[1];
				this.props.removeCurrentRecordObj(tabId, breadCrumbId);
			}
		}
	}

	handleDisableUpArrow = () => {
		const { hasPrevious } = this.props.eventsProperties;
		const { fromListPage } = this.state;
		return !hasPrevious || fromListPage != EVENTS_LIST_PAGE;
	};

	handleDisableDownArrow = () => {
		const { hasNext } = this.props.eventsProperties;
		const { fromListPage } = this.state;
		return !hasNext || fromListPage != EVENTS_LIST_PAGE;
	};

	setIsOpenActionsContextMenu = event => {
		this.setState({ isOpenActionsContextMenu: Boolean(event) });
		this.setState({ menuRef: event.currentTarget ? event.currentTarget : event });
	}
	getValueData = (valueData, newValueData) => {
		if (Object.keys(valueData).length && Object.keys(newValueData).length &&
			(JSON.parse(JSON.stringify(valueData)) !== JSON.parse(JSON.stringify(newValueData)))) {
			return newValueData;
		}
		return valueData;
	}
	handleChangeTab = (tab) => {
		this.setState({ tab });
		this.props.setDataInTabs("selectedPropertiesTab", tab);
	}

    setIsOpenActionsButtonContextMenu = event => {
        this.setState({ isOpenActions: Boolean(event) });
        this.setState({ actionMenuRef: event.currentTarget ? event.currentTarget : event });
    }

	handleActionSelection = action => {
        switch (action) {
            case "Event Effect Maintenance":
				this.setState({ eventEffectMaintenanceDialog : true });
                break;
        }
	};
	
	setIsActionClose = () => {
        this.setState({ isOpenActions: false });
    };

	closeDialog = dialog => {
		this.setState({ [dialog]: false });
	};

	render() {
		const {
			classes, globalDateFormat, filterCriteriaDetails, pageFilterOptions, globalFilterOptions,
			columnDefs, currentPage, currentOwnerName, isShowContextMenu, removeChildCutdownTab, selectedValue, globalSecurityFilterList
		} = this.props;
		const {
			loading, eventDetailsLabelsData, copyEventDetailsLabelsData,
			valueData, newValueData, event, item, warehouse, currentRecordData, eventColumnDefs,
			eventsLabelJson,
			eventStatisticsLabelsData, eventEffectMaintenanceLabelsData,
		} = this.props.eventsProperties;

		const { canUpdateComponent, isSaveDataDisabled, eventEffectMaintenanceDialog } = this.state;
		const { tab } = this.state;
		let contextMenu = updateBreadCrumbContextMenu(this.props) || [];

		return (
			<React.Fragment>
				{loading ? <Spinner loading type="list" /> : null}
				{this.state.hasError && this.state.errorId ? (
					<div className={classes.errorGrid}>
						<GridErrorMessages
							errorMessageLabels={this.props.errorMessageLabels}
							popUp
							sethaserror={this.setGridError}
							replaceValues={this.state.replaceValues}
							id={this.state.errorId} />
					</div>) : null}
				<div className={classes.propertiesHeaderContainer}>
					<div className={classes.boookingDetailContainer}>
						<Box className={classes.boookingDetailDetailsWrapper}>
							<Box className={classes.eventArrowWrapper}>
								<Button color="primary" onClick={() => this.handleEventHeaderRightArrowClick()} className={classes.boookingArrow} disabled={this.handleDisableUpArrow()}>
									<KeyboardArrowUpIcon />
								</Button>
								<Button color="primary" onClick={() => this.handleEventHeaderLeftArrowClick()} className={classes.boookingArrow} disabled={this.handleDisableDownArrow()}>
									<KeyboardArrowDownIcon />
								</Button>
							</Box>

							<Box className={classes.eventDetailRow}>
								<Header
									getLabelValue={this.getLabelValue}
									globalDateFormat={globalDateFormat}
									eventData={valueData}
								/>
							</Box>
							<Box className={classes.eventActions}>

								<div className={classes.buttonActionsSecondChild} onClick={(event) => this.setIsOpenActionsButtonContextMenu(event)}>
									<Button color="primary" size="small" variant="outlined" className={classes.vendorArrow} /* disabled={this.handleDisableDownArrow()} */>
										<div>{this.getLabelValue(LABEL_ACTIONS)}</div>
										<KeyboardArrowDownIcon />
									</Button>
									<ContextMenu
										className={classes.ActionsContextMenu}
										menuList={this.state.actionList}
										isOpen={this.state.isOpenActions}
										menuRef={this.state.actionMenuRef}
										handleItemSelection={(val) => this.handleActionSelection(val)}
										handleMenuClose={(val) => this.setIsActionClose(val)}>
									</ContextMenu>
								</div>

								<div className={classes.buttonActions}>
									<div className={isShowContextMenu || true ? 'showContextMenu' : 'hideContextMenu'}>
										<BreadcrumbContextMenu
											onOptionChange={(e, val) => this.onContextMenuChange(e, val)} menuItems={contextMenu}
											removeChildCutdownTab={removeChildCutdownTab}
											selectedValue={selectedValue} />
									</div>
								</div>
								<Button component="div" color="primary" onClick={this.handleEventHeaderFilterClick} className={classes.eventActionsFilter}>
									<img src={FilterIcon} alt="Filter Icon" />
								</Button>
								<Button component="div" color="primary" onClick={this.handleEventHeaderSaveClick} disabled={isSaveDataDisabled} className={classes.eventActionsFilter}>
									<SaveIcon fontSize="large" />
								</Button>
								<Box className={classes.menuButton}>
									<div
										onMouseEnter={(event) => this.setIsOpenActionsContextMenu(event)}
										onMouseLeave={() => this.setIsOpenActionsContextMenu(false)}>
										<MoreVertIcon color="primary" className="cPointer"></MoreVertIcon>
										<ContextMenuCreateNew
											className={classes.ActionsContextMenu}
											menuList={this.state.contextMenuList}
											isOpen={this.state.isOpenActionsContextMenu}
											menuRef={this.state.menuRef}
											handleItemSelection={(val) => this.handleEventHeaderActionItemSelection(val)}
											handleMenuClose={(val) => this.setIsOpenActionsContextMenu(val)}
											currentPage={currentPage}
											currentRecord={currentRecordData}
											>
										</ContextMenuCreateNew>
									</div>
								</Box>
							</Box>
						</Box>
					</div>
				</div>
				<div className={classes.propertiesContentWrapper}>
					<AppBar
						position="static"
						color="default"
						className="minWidth1100"
					>
						<Tabs
							value={this.state.tab}
							onChange={(evt, val) => {
								this.handleChangeTab(val);
							}}
							indicatorColor="primary"
							textColor="primary"
						>
							<Tab value={0}
								label={this.getLabelValue(
									LABEL_EVENT_DEFAULTS,
								)}
							/>
							<Tab value={1}
								label={this.getLabelValue(
									LABEL_ITEMS_ON_EVENT,
								)}
							/>
							<Tab value={2}
								label={this.getLabelValue(
									LABEL_STATISTICS,
								)}
							/>
						</Tabs>
					</AppBar>
					<div className={(tab === 0 ? classes.showStep : classes.hideStep) + " " + classes.pageContainer}>
						<TabContainer>
							<EventDefaults
								eventData={newValueData}
								currentPage={currentPage}
								eventDefaultCardsArray={eventDetailsLabelsData ? eventDetailsLabelsData.tabcards : []}
								enableSubmitNext={this.enableSubmitNext}
								handleEventDataChange={(key, val, field) => this.handleChangeValue(key, val, field)}
								pageType={"old"}
								systemDate={this.props.companyDetails ? this.props.companyDetails.CJDATE : getJulianValue(new Date())}
								canUpdateComponent={canUpdateComponent}
							>
							</EventDefaults>
						</TabContainer>
					</div>
					<div className={(tab === 1 ? classes.showStep : classes.hideStep) + " " + classes.pageContainer}>
						<EventItems
							eventDetails={newValueData}
							hasToLoad={tab === 1}
							eventsLabelJson={eventsLabelJson}
							systemDate={this.props.companyDetails ? this.props.companyDetails.CJDATE : getJulianValue(new Date())}
							canUpdateComponent={canUpdateComponent}
						/>
					</div>
					<div className={tab === 2 ? classes.showStep : classes.hideStep}>
						<Box className={classes.pageContainer}>
							<EventStatistics
								currentPage={'eventDefaults'}
								eventData={newValueData}
								eventStatisticsCardsArray={eventStatisticsLabelsData && eventStatisticsLabelsData.tabcards || {}}
							/>
						</Box>
					</div>
					{this.state.openFilterPopup && (
						<Filter
							filterCriteriaDetails={filterCriteriaDetails}
							pageFilterOptions={pageFilterOptions}
							globalFilterOptions={globalFilterOptions}
							globalSecurityFilterList={globalSecurityFilterList}
							currentPage={currentPage}
							isOpen={Boolean(this.state.openFilterPopup)}
							ownerName={currentOwnerName}
							columnDefs={eventColumnDefs}
							clearPopupComponent={this.handleEventHeaderFilterClick}
						/>
					)}
					{this.state.openCopyPopup && copyEventDetailsLabelsData && (
						<CopyDialog
							openCopyPopup={this.state.openCopyPopup}
							handleCopyDeletePopup={this.handleCopyDeletePopup}
							onSubmit={this.props.eventDetailsCopy}
							onCopyAll={this.props.eventDetailsCopyAll}
							companyDetails = {this.props.companyDetails}
							copyLabels={copyEventDetailsLabelsData}
							headerJson={{ ...event, ...item, ...warehouse }}
							eventDetailData={this.getValueData(valueData, newValueData)}
							currentOwnerName={currentOwnerName}
							globalDateFormat={globalDateFormat}
							filterCriteriaDetails={filterCriteriaDetails}
							pageFilterOptions={pageFilterOptions}
							globalFilterOptions={globalFilterOptions}
							columnDefs={columnDefs}
							currentPage={currentPage}
							canUpdateComponent={canUpdateComponent}
						/>)}
					{this.state.openDeletePopup && (
						<DeleteDialog
							openDeletePopup={this.state.openDeletePopup}
							handleCopyDeletePopup={this.handleCopyDeletePopup}
							eventDetailsDelete={this.props.eventDetailsDelete}
							onDeleteAll={this.props.eventDetailsDeleteAll}
							headerJson={{ ...event, ...currentRecordData }}
							eventDetailData={this.getValueData(valueData, newValueData)}
							filterProps={this.props.eventsProperties.filterProps}
						/>)}
					{this.state.showConfirmationDialog && <ConfirmationDialog
						hasError={this.state.hasWarning}
						isOpen={this.state.showConfirmationDialog}
						dialogTitle={this.state.dialogTitle}
						submitText={TEXT_OK}
						handleClose={() => this.handleClose(false)}
						handleCancel={() => this.handleClose(false)}
						handleSubmit={() => this.handleClose(this.state.dialogBody)}>
						<div>
							{this.state.fromHeaderENG && this.getLabelValue("28648")}
							{this.props.errorMessageLabels && this.props.errorMessageLabels[this.state.dialogBody] &&
								this.props.errorMessageLabels[this.state.dialogBody].MTEXT || 'Warning'}
						</div>
					</ConfirmationDialog>
					}
					{this.state.showValueConfirmationDialog && <ConfirmationDialog
						hasError={this.state.hasWarning}
						isOpen={this.state.showValueConfirmationDialog}
						dialogTitle={this.state.dialogTitle}
						submitText={TEXT_OK}
						handleClose={() => this.closeValueDialog(false)}
						handleCancel={() => this.closeValueDialog(false)}
						handleSubmit={() => this.closeValueDialog(this.state.dialogBody)}>
						<div>
							{(this.props.errorMessageLabels[this.state.dialogContent] && this.props.errorMessageLabels[this.state.dialogContent].MTEXT)
								|| this.state.dialogContent}
						</div>
					</ConfirmationDialog>
					}

					{
						eventEffectMaintenanceDialog &&
						<EventEffectMaintenanceDialog
							closeDialog={() => this.closeDialog('eventEffectMaintenanceDialog')}
							namespace="eventEffectMaintenanceDialog"
							title={this.getLabelValue(LABEL_EVENT_EFFECT_MAINTENANCE)}
							headerJson={{ ...event, ...currentRecordData }}
							eventEffectMaintenance={this.props.eventEffectMaintenance}
							currentPage={currentPage}
							isOpen={eventEffectMaintenanceDialog}
							getLabelValue={this.getLabelValue}
							eventDetailData={this.getValueData(valueData, newValueData)}
							eventEffectMaintenanceLabelsData={eventEffectMaintenanceLabelsData}
							systemDate={this.props.companyDetails ? this.props.companyDetails.CJDATE : getJulianValue(new Date())}
							errorMessageLabels={this.props.errorMessageLabels}
							globalDateFormat={globalDateFormat}
						/>
					}

				</div>
			</React.Fragment>);
	}
}

export default withStyles(style)(EventProperties);
import {GET_DEAL_NOTES, GET_DEAL_NOTES_SUCCESS, GET_DEAL_NOTES_FAILURE, CLEAR_NOTES_DATA, GET_DEAL_NOTE_DETAILS, GET_DEAL_NOTE_DETAILS_SUCCESS,
     GET_DEAL_NOTE_DETAILS_FAILURE, SET_DEAL_SELECTED_NOTE_DETAILS, GET_DEAL_NOTES_ALL_SUCCESS, CONTROL_DEAL_NOTE_CREATION,
     CONTROL_DEAL_NOTE_CREATION_SUCCESS, CONTROL_DEAL_NOTE_CREATION_FAILURE, SET_DEAL_NOTE_CONTROL_COUNT,
     REMOVE_DEAL_NOTE_OF_KEY, CLEAR_DEAL_NOTES, SET_IS_EMBEDDED_LIST, CLEAR_STATE_VALUES } from './constants';

export function getDealNotes(data){
    return {
        type: GET_DEAL_NOTES,
        data
    }
}
export function getDealNotesSuccess(data){
    return {
        type: GET_DEAL_NOTES_SUCCESS,
        data
    }
}
export function getDealNotesFailure(data){
    return {
        type: GET_DEAL_NOTES_FAILURE,
        data
    }    
}

export function clearNotesData() {
    return {
        type: CLEAR_NOTES_DATA
    }
}
export function getNoteDetails(data) {
    return {
        type: GET_DEAL_NOTE_DETAILS,
        data
    }
}
export function getNoteDetailsSuccess(data) {
    return {
        type: GET_DEAL_NOTE_DETAILS_SUCCESS,
        data
    }
}
export function getNoteDetailsFailure(data) {
    return {
        type: GET_DEAL_NOTE_DETAILS_FAILURE,
        data
    }
}
export function getNoteDetailsAllSuccess(data) {
    return {
        type: GET_DEAL_NOTES_ALL_SUCCESS,
        data
    }
}
export function setSelectedNoteDetails(data) {
    return {
        type: SET_DEAL_SELECTED_NOTE_DETAILS,
        data
    }
}
export function controlNoteCreation(data) {
    return {
        type: CONTROL_DEAL_NOTE_CREATION,
        data
    }
}
export function controlNoteCreationSuccess(data) {
    return {
        type: CONTROL_DEAL_NOTE_CREATION_SUCCESS,
        data
    }
}
export function controlNoteCreationFailure(data) {
    return {
        type: CONTROL_DEAL_NOTE_CREATION_FAILURE,
        data
    }
}
export function setControlNoteCount(data) {
    return {
        type: SET_DEAL_NOTE_CONTROL_COUNT,
        data
    }
}
export function removeNoteByKey(data) {
    return {
        type: REMOVE_DEAL_NOTE_OF_KEY,
        data
    }
}
export function clearAllDealNotes() {
    return {
        type: CLEAR_DEAL_NOTES
    }
}

export function setIsEmbeddedList() {
    return {
        type: SET_IS_EMBEDDED_LIST
    }
}
export function clearStateValues(){
    return{
        type: CLEAR_STATE_VALUES
    }
}
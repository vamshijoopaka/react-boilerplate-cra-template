export const ACTIONS_CONTEXT_MENU = [
  {
    label: '50768',
    key: 'adjust',
    hasSubMenu: false,
    isDisable: false,
  },
  {
    label: '50770',
    key: 'applyEdits',
    hasSubMenu: false,
    isDisable: true,
  },
  {
    label: '50771',
    key: 'cancelEdits',
    hasSubMenu: false,
    isDisable: true,
  },
  {
    label: '50759',
    key: 'yearToYearAdjustment',
    hasSubMenu: false,
    isDisable: true,
  },
  {
    label: '50760',
    key: 'sideBySideAdjustment',
    hasSubMenu: false,
    isDisable: false,
  },
];

export const YEAR_TO_YEAR_ADJUSTMENTS_GRAPH = 'Year to Year Adjustments Graph';
export const SIDE_BY_SIDE_ADJUSTMENTS_GRAPH = 'Side by Side Adjustments Graph';

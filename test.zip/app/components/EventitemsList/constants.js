import {
    COLUMN_HEADER_ACCESSOR,
    COLUMN_VALUE_ACCESSOR,
    COLUMN_SHOW_HIDE_FLAG,
    COLUMN_POSITION,
    COLUMN_HEADER_PREFIX_FLAG,
  } from '../common/constants';
   
  export const EVENTITEM_PROPERTIES = {
    headerName: COLUMN_HEADER_ACCESSOR,
    field: COLUMN_VALUE_ACCESSOR,
    showHideFlag: COLUMN_SHOW_HIDE_FLAG,
    columnPosition: COLUMN_POSITION,
    prefixFlag: COLUMN_HEADER_PREFIX_FLAG,
  };
  
  export const PAGE_SIZES = [10, 20, 30];
  
  export const EVENTITEM_LIST_PAGE = 'eventitemsListPage';  
  export const INITIAL_PAGE_PROPS = {
    actualPage: 0,
    currentPage: 0,
    totalCount: 10,
    actualPageSize: 10,
    pageSize: 100,
    isPageSizeChanged: false,
    isForwardDirection: true,
  };
 
/**
 *
 * SelectComponent
 *
 */

import React from 'react';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import PropTypes from 'prop-types';
import Typography from '@material-ui/core/Typography';
import { withStyles } from '@material-ui/core/styles';
import { FormattedMessage } from 'react-intl';
import ArrowDropDownIcon from '@material-ui/icons/ArrowDropDown';
import messages from './messages';

const styles = () => ({
  textField: {
    margin: `0px 8px 0px`,
    width: 220,
  },
  textFieldMaterialType: {
    margin: `0px 8px 0px`,
  },
  header: {
    margin: '9px 9px',
    fontSize: '11pt',
    color: 'grey',
    whiteSpace: 'nowrap',
  },
  type: {
    display: 'inline-flex',
    height: 32,
    float: 'right',
    paddingTop: 9,
  },
  menu: {
    maxWidth: 300,
  },
  select: {
    fontSize: '14px',
    fontWeight: 500,
    fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
    lineHeight: '18px',
    marginTop: -6,
    background: 'transparent',
    height: 32,
    padding: '13px 13px 13px 10px',
    textAlign: 'left',
    borderRadius: '4px',
    paddingRight: '13px',
    cursor: 'pointer',
    border: `1px solid #dedede`,
    '& .selectItem': {
      color: '#000',
    },
  },
  selectItem: {
    fontSize: '14px',
    fontWeight: 500,
    fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
    lineHeight: '18px',
    letterSpacing: '0.01em',
    paddingRight: '0.73em',
    marginTop: -6,
    color: '#000',
    '& p': {
      position: 'relative',
      top: 3,
    },
  },
  input: {
    fontSize: 12,
    background: 'transparent',
    height: 32,
    padding: 0,
    borderRadius: '4px',
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
  },
  icon: {
    color: '#5e747e',
    top: 'calc(50% - 12px)',
    right: 0,
    position: 'absolute',
    // margin-right: 2px,
    pointerEvents: 'none',
  },
});

class SelectComponent extends React.Component {
  // eslint-disable-line react/prefer-stateless-function
  formatOptionLabel(option) {
    let formattedLabel =
      option.label === undefined
        ? option.name
          .replace(/([A-Z])/g, ' $1')
          .replace(/^./, str => str.toUpperCase())
        : option.label;
    if (option.count) {
      formattedLabel = `${formattedLabel} (${option.count})`;
    }
    return formattedLabel;
  }

  isNonEmptyArray = array =>
    array !== null && array !== undefined && array.length !== 0;

  render() {
    const {
      classes,
      optionList,
      label,
      materialTypeDropDown,
      containerCustomStyle,
    } = this.props;
    if (!this.isNonEmptyArray(optionList)) {
      return null;
    }
    const textFieldProps = {
      id: this.props.id ? `${this.props.id}-input` : 'select-option',
      select: true,
      defaultValue: optionList[0],
      className: materialTypeDropDown
        ? classes.textFieldMaterialType
        : classes.textField,
      value: this.props.selectedOption,
      onChange: event => this.props.handleChange(event.target.value),
      SelectProps: {
        IconComponent: () => (
          <ArrowDropDownIcon
            className={classes.icon}
            style={{
              ...(containerCustomStyle &&
                containerCustomStyle.iconColor && {
                color: containerCustomStyle.iconColor,
              }),
            }}
          />
        ),
        MenuProps: {
          id: 'menu-props',
          className: classes.menu,
        },
        SelectDisplayProps: {
          id: this.props.id
            ? `${this.props.id}-select`
            : 'select-display-props',
          className: classes.select,
          style: {
            ...(containerCustomStyle &&
              containerCustomStyle.backgroundColor && {
              backgroundColor: containerCustomStyle.backgroundColor,
            }),
          },
        },
      },
      InputProps: {
        disableUnderline: true,
        classes: {
          input: classes.input,
        },
      },
      margin: 'none',
    };
    return (
      <div
        id={this.props.id ? `${this.props.id}-dropdown` : 'Type-Dropdown'}
        className={classes.type}
      >
        {!materialTypeDropDown && (
          <Typography className={classes.header}>
            {label || <FormattedMessage {...messages.default} />}
          </Typography>
        )}
        <TextField {...textFieldProps}>
          {optionList.map(option => (
            <MenuItem
              key={option.name}
              value={option.name}
              style={{ width: '100%' }}
              disabled={option.disabled}
            >
              <Typography
                id={option.name}
                className={classes.selectItem}
                noWrap
              >
                {this.formatOptionLabel(option)}
              </Typography>
            </MenuItem>
          ))}
        </TextField>
      </div>
    );
  }
}

SelectComponent.propTypes = {
  id: PropTypes.string,
  classes: PropTypes.object.isRequired,
  optionList: PropTypes.array,
  handleChange: PropTypes.func,
  selectedOption: PropTypes.string,
  label: PropTypes.string,
  materialTypeDropDown: PropTypes.bool,
  adminPageTypeDropDown: PropTypes.bool,
  containerCustomStyle: PropTypes.object,
  deliveryTypeDropdown: PropTypes.bool,
};

export default withStyles(styles)(SelectComponent);
export { SelectComponent };

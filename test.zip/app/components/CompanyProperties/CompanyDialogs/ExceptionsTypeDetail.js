/** Change Log
 * LogStart --  E3C-33195 - Kumar A- 16 September,2021 - 2022.1.0.0 Unified Product
 *              Story: E3C-33195 --Code Cleanup
*/
import { Box } from '@material-ui/core';
import { withStyles } from '@material-ui/core/styles';
import { TEXT_CANCEL, TEXT_OK } from 'components/common/constants';
import DialogComponent from 'components/common/DialogComponent';
import FormFieldsGenerator from 'components/common/FormFieldsGenerator';
import theme from 'jda-gcp-theme';
import React from 'react';

const styles = theme => ({
    notesForBlock: {
        display: 'flex',
        flexDirection: 'column',
        border: '1px solid var(--divider-line)',
        padding: '10px 10px 0 10px',
        position: 'relative',
        width: '100%'
    },
    notesForLabel: {
        position: 'absolute',
        top: '-7px',
        left: '10px',
        background: 'var(--background-content)',
        padding: '0 8px',
    },
    pageContainer: {
        display: 'flex',
        borderTop: 'none',
        padding: '10px 20px',
    },
    card: {
        padding: '0 0px 0 0',
        backgroundColor: 'var(--background-content)',
        borderRadius: '4px',
    },
    dialogClass: {
        minWidth: '35% !important',
        maxWidth: '35% !important',
        height: '45rem'
    }
});
class ExceptionsTypeDetail extends React.Component {
    handleClose = (value) => {
        this.props.handleDialogClose(value);
    }
    handleChangeValue = (key, value, field) => {
        this.props.setValueForm({ key, val: value, field });
    }
    handleExceptionsTypeDetail = () => {
        const { valueForm } = this.props;
        this.props.onExceptionSubmit({ ...valueForm });
    }
    render() {
        const { classes, fieldData, valueForm, columnDefs, globalDateFormat } = this.props;
        let fieldDataMod = JSON.parse(JSON.stringify(fieldData));
        fieldDataMod[0]['cardfields'][3].disabled = false;
        fieldDataMod[0]['cardfields'][4].disabled = false;
        if (valueForm['EXTYPE'] == '120' || valueForm['EXTYPE'] == '130' || valueForm['EXTYPE'] == '150'
            || valueForm['EXTYPE'] == '160') {
            fieldDataMod[0]['cardfields'][3].disabled = true;
            fieldDataMod[0]['cardfields'][4].disabled = true;
        }
        if (valueForm['EXTYPE'] == '170') {
            fieldDataMod[0]['cardfields'][4].disabled = true;
        }
        return (
            <DialogComponent dialogTitle={'28036'}
                cancelText={TEXT_CANCEL}
                submitText={TEXT_OK}
                disableSubmit={this.props.disableSubmit}
                handleCancel={(val) => { this.handleClose(true) }}
                handleSubmit={() => { this.handleExceptionsTypeDetail() }}
                handleClose={(val) => { this.handleClose(true) }}
                className={classes.dialogClass}
                isOpen={true}>
                <div className={classes.pageContainer}>
                    {fieldDataMod && fieldDataMod.length && fieldDataMod.map((object) => {
                        return <div className={classes.notesForBlock}>
                            <Box mb={theme.spacing(0.5)} className={classes.notesForLabel}>{" "}</Box>
                            <FormFieldsGenerator
                                labelDisplayCharacters={26}
                                valueDisplayCharacters={18}
                                noMassMaintenance={true}
                                key={object.cardkey}
                                fieldsArray={object.cardfields}
                                valuesArray={valueForm}
                                handleChangeValue={(key, val, field) => this.props.handleChangeValue(key, val, field)}
                                enableAddButton={(e) => { }}
                                columnDefs={columnDefs}
                                currentPage={"exceptionMaintenance"}
                                canUpdateComponent={false}
                                globalDateFormat={globalDateFormat}
                            />
                        </div>
                    })}
                </div>

            </DialogComponent>
        );
    }
}
export default withStyles(styles)(ExceptionsTypeDetail);
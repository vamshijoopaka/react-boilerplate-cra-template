/****************************************************************** 
*                            PTR LOG                              
*  DT    Pgmr                                                     
* Numbr  Init  Description of change                              
* -----  ----  -------------------------------------------------  
*                                                                 
* E3C-32817 SRK Company changes for AR Unified product            
*               E3C-32828 - 
                  Constrained Controls Tab:       
*                   - Exclude Presentation from Allocation
*                   - Label Change to incl PS for Time Supply Include SS
*                   - Label Change to incl PS for Fill SS
*                 Process Controls Tab/Update Switches:       
*                   - OUTL Hard Max Switch
*                   - Min Pres Stk Switch
*                                                                 
*======================== END OF PTR LOG ======================== 
 * LogStart --  E3C-33195 - Kumar A- 16 September,2021 - 2022.1.0.0 Unified Product
 *              Story: E3C-33195 --Code Cleanup
*/


import React from 'react';
import { connect } from 'react-redux';
import { compose } from 'redux';
import { withStyles } from '@material-ui/core/styles';
import PropTypes from 'prop-types';

import FormFieldsGenerator from '../../common/FormFieldsGenerator';
import Spinner from '../../common/Spinner';
import { selectData } from './selector';
import {
    COMPANY_CONSTRAINED_CONTROLS,
    COMPANY_BUYER_CLASS,
    COMPANY_INTERFACE_OPTIONS,
    COMPANY_CONSTRAINED_PHASES,
} from './constants';
import './style.scss';
import { COMPANYS_LIST_PAGE, COLUMN_VALUE_ACCESSOR } from 'components/common/constants';
import CardComponent from '../../common/CardComponent';

const propTypes = {
    setSaveData: PropTypes.func,
};

const style = theme => ({
    pageContainer: {
        display: 'flex',
        backgroundColor: 'var(--background-app)',
        borderTop: 'none',
        padding: '10px 20px',
    },
    pageContainerSeventy: {
        width: '70%',
        flexFlow: 'wrap',
        display: 'flex',
    },
    pageContainerThirty: {
        width: '30%',
        flexFlow: 'wrap',
        display: 'flex',
    },
    cardWithborder: {
        border: '1px solid var(--secondary-s3)',
        borderRadius: '4px',
        padding: '10px',
        margin: '10px',
        width: '100%',
        backgroundColor: 'var(--secondary-s5)',
    },
    card: {
        padding: '0px',
        backgroundColor: 'var(--background-content)',
        borderRadius: '4px',
        width: '100%',
        margin: '8px',
        '& .MuiCardHeader-root': {
            padding: '22px 10px 0 20px'
        },
        '& .MuiCardContent-root': {
            padding: '16px 15px 10px 15px'
        }
    },
    card1: {
        padding: '0px',
        backgroundColor: 'var(--background-content)',
        borderRadius: '4px',
        width: '90%',
        margin: '10px',
        marginLeft: '0px',
        '& .MuiCardHeader-root': {
            padding: '16px 32px'
        },
        '& .MuiCardContent-root': {
            padding: '16px 32px'
        }
    },
    card2: {
        padding: '0px',
        backgroundColor: 'var(--background-content)',
        borderRadius: '4px',
        width: '100%',
        margin: '10px',
        marginLeft: '0px',
        '& .MuiCardHeader-root': {
            padding: '16px 32px'
        },
        '& .MuiCardContent-root': {
            padding: '16px 32px'
        }
    },
    cardName: {
        fontWeight: '500',
        margin: '10px 0 20px 5px',
    },
    simpleCardGroup: {
        width: '100%',
        display: 'flex',
        justifyContent: 'space-around',
    },
    dashedBottomBorder: {
        borderBottom: '1px dashed var(--secondary-s21)',
        marginBottom: '20px',
    },
    marginLeftZero: {
        marginLeft: '0',
    },
    marginRightZero: {
        marginRight: '0',
    }
});

class ConstrainedControls extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            fields: false,
            values: false,
            hasError: false,
            errorId: false,
            valueConstraintData: false,
            tabcards: false,
        };
        this.handleChangeValue = this.handleChangeValue.bind(this);
    }

    handleChangeValue(key, val, field, setEnableDisable = true) {
        if (field.FDPRFX == '0') {
            if (key.includes("undefined")) {
                key = key.replace("undefined", "");
            }
            key = 'CC' + key;
        }
        let valueConstraintDataC = this.state.valueConstraintData
        if (val != null) {
            this.props.setValueConstraintData({ key, val, valueConstraintDataC });
            if (field.dataType == "checkbox" || field.dataType == 'select' || field.dataType == 'date') {
                if (setEnableDisable) {
                    let tabsData = this.setFieldEnableDisable(key, val, field, this.state.tabcards);
                    this.setState({ tabcards: tabsData });
                }
            }
        }
    }

    setFieldEnableDisable = (key, value, field, tabsData, isInitialLoad = false) => {
        const valueData = this.props.CompanyPropertiesData.newConstrainData ? this.getValueData(this.props.companyConstrainedControlsData, this.props.CompanyPropertiesData.newConstrainData) : this.props.companyConstrainedControlsData; /*32817*/
        let valueDataUpdated = JSON.parse(JSON.stringify(valueData));
        valueDataUpdated = Object.assign({}, valueDataUpdated, { [key]: value });
        // fieldKey --- field changed
        // cardFieldKey --- field to be disabled
        let cardFieldKey, fieldKey = field[COLUMN_VALUE_ACCESSOR].trim();
        let tabcards = JSON.parse(JSON.stringify(tabsData));
        tabcards = tabcards.map(card => {
            card.cardfields = card.cardfields.map(cardField => {
                cardFieldKey = cardField[COLUMN_VALUE_ACCESSOR] ? cardField[COLUMN_VALUE_ACCESSOR].trim() : "";
                if (fieldKey === 'CCTSP' && cardFieldKey === 'CCTSP') {
                    cardField['disabled'] = true;
                }
                if (fieldKey === 'CCPLPH' && cardFieldKey === 'CCPREA' && !isInitialLoad) {
                    if (valueData['CCPLPH'] == '0') {
                        cardField['disabled'] = true;
                        this.handleChangeValue(cardField.key, "0", cardField, false);
                    } else {
                        cardField['disabled'] = false;
                    }
                }
                return cardField;
            })
            return card;
        })
        return tabcards;
    }

    setValueDataOnFocutOut = (key, value, field) => {
        if (value != null) {
            let tabsData = this.setFieldEnableDisable(key, value, field, this.state.tabcards);
            this.setState({ tabcards: tabsData });
        }

    }

    getValueData(valueData, newValueData) {
        if (this.state.valueConstraintData == false) {
            this.setState({ valueConstraintData: valueData });
        }
        if (Object.keys(valueData).length && Object.keys(newValueData).length &&
            (JSON.parse(JSON.stringify(valueData)) !== JSON.parse(JSON.stringify(newValueData)))) {
            return newValueData;
        }
        return valueData;
    }

    componentDidMount() {
        let tabsData = this.props.CompanyPropertiesData.constrainedControlLabelsData.tabcards;
        let valueForm = this.props.companyConstrainedControlsData;
        tabsData.forEach(card => {
            card.cardfields.forEach(field => {
                if (field.key) {
                    tabsData = this.setFieldEnableDisable(field.key, valueForm[field.key], field, tabsData, true);
                    if (field.hasCheckbox) {
                        tabsData = this.setFieldEnableDisable(field.checkfieldJson.key, valueForm[field.checkfieldJson.key], field.checkfieldJson, tabsData, true);
                    }
                }
            })
        })
        this.setState({ tabcards: tabsData });
    }

    render() {
        const { classes, setSaveData, globalDateFormat, filterCriteriaDetails, pageFilterOptions,
            globalFilterOptions, columnDefs, currentPage } = this.props;
        const { loading, newConstrainData } = this.props.CompanyPropertiesData; /*32817*/
        const { tabcards } = this.state;
        const valueData = this.props.companyConstrainedControlsData;
        const newValueData = newConstrainData ? newConstrainData : this.props.companyConstrainedControlsData; /*32817*/
        return (
            <div>
                {(!loading && tabcards && tabcards.length) ? (
                    <div className={classes.pageContainer}>
                        <div className={classes.pageContainerSeventy}>
                            {!loading && tabcards.map(formCard => {
                                if (formCard.cardkey == COMPANY_CONSTRAINED_CONTROLS) {
                                    return <CardComponent title={formCard.cardtitle} className={classes.card}>
                                        <FormFieldsGenerator
                                            cardHasDotsBtn={false}
                                            cardHasCheckBox={false}
                                            noMassMaintenance
                                            labelDisplayCharacters={26}
                                            valueDisplayCharacters={17}
                                            handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                                            key={formCard.cardkey}
                                            parentPage={COMPANYS_LIST_PAGE}
                                            enableAddButton={(e) => { setSaveData(e) }}
                                            className="COMPANY_CONSTRAINED_CONTROLS"
                                            fieldsArray={formCard.cardfields}
                                            valuesArray={this.getValueData(valueData, newValueData)}
                                            handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                            handleFocusOut={(key, val, field) => this.setValueDataOnFocutOut(key, val, field)}
                                            globalDateFormat={globalDateFormat}
                                            filterCriteriaDetails={filterCriteriaDetails}
                                            pageFilterOptions={pageFilterOptions}
                                            globalFilterOptions={globalFilterOptions}
                                            columnDefs={columnDefs}
                                            currentPage={currentPage}
                                            canUpdateComponent={this.props.canUpdateComponent}
                                        />
                                    </CardComponent>
                                }
                            })}
                        </div>
                        <div className={classes.pageContainerSeventy}>
                            {!loading && tabcards.map(formCard => {
                                if (formCard.cardkey == COMPANY_BUYER_CLASS) {
                                    return <CardComponent title={formCard.cardtitle} className={classes.card}>
                                        <FormFieldsGenerator
                                            cardHasDotsBtn={false}
                                            cardHasCheckBox={false}
                                            noMassMaintenance
                                            labelDisplayCharacters={25}
                                            valueDisplayCharacters={15}
                                            handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                                            key={formCard.cardkey}
                                            parentPage={COMPANYS_LIST_PAGE}
                                            enableAddButton={(e) => { setSaveData(e) }}
                                            className="COMPANY_BUYER_CLASS"
                                            fieldsArray={formCard.cardfields}
                                            valuesArray={this.getValueData(valueData, newValueData)}
                                            handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                            handleFocusOut={(key, val, field) => this.setValueDataOnFocutOut(key, val, field)}
                                            globalDateFormat={globalDateFormat}
                                            filterCriteriaDetails={filterCriteriaDetails}
                                            pageFilterOptions={pageFilterOptions}
                                            globalFilterOptions={globalFilterOptions}
                                            columnDefs={columnDefs}
                                            currentPage={currentPage}
                                            parentData={this.props.companyData}
                                            canUpdateComponent={this.props.canUpdateComponent}
                                        />
                                    </CardComponent>
                                }
                            })}
                            {!loading && tabcards.map(formCard => {
                                if (formCard.cardkey == COMPANY_INTERFACE_OPTIONS) {
                                    return <CardComponent title={formCard.cardtitle} className={classes.card}>
                                        <FormFieldsGenerator
                                            cardHasDotsBtn={false}
                                            cardHasCheckBox={false}
                                            noMassMaintenance
                                            labelDisplayCharacters={22}
                                            valueDisplayCharacters={20}
                                            handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                                            key={formCard.cardkey}
                                            parentPage={COMPANYS_LIST_PAGE}
                                            enableAddButton={(e) => { setSaveData(e) }}
                                            className="COMPANY_INTERFACE_OPTIONS"
                                            fieldsArray={formCard.cardfields}
                                            valuesArray={this.getValueData(valueData, newValueData)}
                                            handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                            handleFocusOut={(key, val, field) => this.setValueDataOnFocutOut(key, val, field)}
                                            globalDateFormat={globalDateFormat}
                                            filterCriteriaDetails={filterCriteriaDetails}
                                            pageFilterOptions={pageFilterOptions}
                                            globalFilterOptions={globalFilterOptions}
                                            columnDefs={columnDefs}
                                            currentPage={currentPage}
                                            parentData={this.props.companyData}
                                            canUpdateComponent={this.props.canUpdateComponent}
                                        />
                                    </CardComponent>
                                }
                            })}
                        </div>
                        <div className={classes.pageContainerThirty}>
                            {!loading && tabcards.map(formCard => {
                                if (formCard.cardkey == COMPANY_CONSTRAINED_PHASES) {
                                    return <CardComponent title={formCard.cardtitle} className={classes.card}>
                                        <FormFieldsGenerator
                                            cardHasDotsBtn={false}
                                            cardHasCheckBox={false}
                                            noMassMaintenance
                                            labelDisplayCharacters={22}
                                            valueDisplayCharacters={15}
                                            handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                                            key={formCard.cardkey}
                                            parentPage={COMPANYS_LIST_PAGE}
                                            enableAddButton={(e) => { setSaveData(e) }}
                                            className="COMPANY_CONSTRAINED_PHASES"
                                            fieldsArray={formCard.cardfields}
                                            valuesArray={this.getValueData(valueData, newValueData)}
                                            handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                            handleFocusOut={(key, val, field) => this.setValueDataOnFocutOut(key, val, field)}
                                            globalDateFormat={globalDateFormat}
                                            filterCriteriaDetails={filterCriteriaDetails}
                                            pageFilterOptions={pageFilterOptions}
                                            globalFilterOptions={globalFilterOptions}
                                            columnDefs={columnDefs}
                                            currentPage={currentPage}
                                            canUpdateComponent={this.props.canUpdateComponent}
                                        />
                                    </CardComponent>
                                }
                            })}
                        </div>
                    </div>
                ) : (<Spinner loading type="list" />)
                }
            </div>
        );
    }
}

const mapStateToProps = function (state) {
    return {
        CompanyControlFactorsData: selectData(state)
    }
};

const withConnect = connect(
    mapStateToProps,
);

ConstrainedControls.propTypes = propTypes;

export default compose(
    withConnect,
    withStyles(style)
)(ConstrainedControls);

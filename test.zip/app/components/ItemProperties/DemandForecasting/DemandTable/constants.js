export const ACTIONS_CONTEXT_MENU = [
  {
    label: '50767',
    key: 'includePromo',
    hasSubMenu: false,
    isDisable: false,
    hasCheckbox: true,
    isChecked: false,
  },
  {
    label: '50749',
    key: 'rollTo13',
    hasSubMenu: false,
    isDisable: false,
    hasCheckbox: true,
    isChecked: false,
  },
];
export const superHistoryMenuItem = {
  label: '25394',
  key: 'superItemHistory',
  isDisable: false,
  hasCheckbox: true,
  isChecked: false,
};
export const RADIO_OPTIONS = [
  { key: '25395', fieldValue: 'graph' },
  { key: '25396', fieldValue: 'detail' },
];

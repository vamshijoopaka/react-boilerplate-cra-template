import produce from "immer";
import { INITIAL_PAGE_PROPS } from "../../common/constants";
import {
    GET_BUYER_NOTES_FAILURE, GET_BUYER_NOTES_SUCCESS, GET_BUYER_NOTES, NOTES_TEXT_ACCESSOR, CLEAR_NOTES_DATA, GET_BUYER_NOTE_DETAILS,
    SET_BUYER_SELECTED_NOTE_DETAILS,
    GET_BUYER_NOTES_ALL_SUCCESS,
    GET_BUYER_NOTE_DETAILS_SUCCESS,
    CONTROL_BUYER_NOTE_CREATION_SUCCESS,
    SET_BUYER_NOTE_CONTROL_COUNT,
    NOTES_KEY_ACCESSOR,
    CLEAR_BUYER_NOTES,
    REMOVE_BUYER_NOTE_OF_KEY,
    CONTROL_BUYER_NOTE_CREATION_FAILURE,
    GET_BUYER_NOTE_DETAILS_FAILURE, SET_IS_EMBEDDED_LIST,
    CLEAR_STATE_VALUES
} from "./constants";
import { leftPad } from "../../../utils/util";


export const InitialState = {
    pageProps: INITIAL_PAGE_PROPS,
    loading: false,
    notesArray: false,
    selectedNoteDetails: false,
    allNotesDetails: [],
    controlCount: false,
    combinedNotes: false,
    isSetEmbeddedList: false
}

function sortNotesBasedOnPriority(allNotes) {
    return allNotes.sort((a, b) =>
        Number(a[0]['MCPRTY']) - Number(b[0]['MCPRTY'])
    );
}
function getNotesArray(notesArray) {
    let notes = [];
    notesArray.forEach((note) => {
        note.forEach(subnote => {
            notes.push(subnote);
        })
    });
    return notes;
}

function checkAllValuesExists(data) {
    let count = 0;
    if (data && data.length) {
        for (let i = 0; i < data.length; i++) {
            let value = data[i][0];
            if (value && Object.keys(value) && Object.keys(value).length) {
                count++;
            }
        }
        if (data.length = count) {
            return true;
        }
    }
    return false;
}

const BuyerNotes = (state = InitialState, action) => {
    // produce(state, draft => {
    switch (action.type) {

        case GET_BUYER_NOTES:
            return Object.assign({}, state, { loading: true, combinedNotes: false });
        case GET_BUYER_NOTES_SUCCESS:
            let note, list = [], notesList = action.data && JSON.parse(action.data) ? JSON.parse(action.data) : [];

            let result = notesList.listArray.reduce((r, a) => {
                r[a['MFKEY']] = r[a['MFKEY']] || [];
                r[a['MFKEY']].push(a);
                return r;
            }, Object.create(null));
            let resultList = [];
            Object.keys(result).forEach(key => {
                resultList.push(result[key]);
            })
            //RRUDRA_Fixes related to empty list 
            if (notesList.listArray.length == 0) //If response is empty, clear allNotesDetails to diplay the count correctly
                return Object.assign({}, state, { loading: false, notesArray: notesList, combinedNotes: resultList, isSetEmbeddedList: true, allNotesDetails: [] });
            else
                return Object.assign({}, state, { loading: false, notesArray: notesList, combinedNotes: resultList, isSetEmbeddedList: true });
        case GET_BUYER_NOTES_FAILURE:
            return Object.assign({}, state, { loading: false, isSetEmbeddedList: true });;
        case CLEAR_NOTES_DATA:
            return Object.assign({}, state, { loading: false, notesArray: [], allNotesDetails: [] });
        case GET_BUYER_NOTE_DETAILS:
            return Object.assign({}, state, {})
        case GET_BUYER_NOTE_DETAILS_SUCCESS:
            let resDetails = action.data && JSON.parse(action.data) ? JSON.parse(action.data) : false;
            if (resDetails && resDetails.listArray) {
                let noteDetails = JSON.parse(action.data);
                let allDetails = JSON.parse(JSON.stringify(state.allNotesDetails));
                allDetails.push(noteDetails.listArray);
                allDetails = sortNotesBasedOnPriority(allDetails);
                return Object.assign({}, state, { selectedNoteDetails: noteDetails.listArray, allNotesDetails: allDetails, notesArray: getNotesArray(allDetails) });
            } else {
                return { ...state };
            }
        case GET_BUYER_NOTE_DETAILS_FAILURE:
            return { ...state };
        case SET_BUYER_SELECTED_NOTE_DETAILS:
            return Object.assign({}, state, { selectedNoteDetails: false });
        case GET_BUYER_NOTES_ALL_SUCCESS:
            let allNotes = JSON.parse(JSON.stringify(state.allNotesDetails));
            let notesArrayDetailsAll = [];
            if (state.notesArray.listArray)
                notesArrayDetailsAll = JSON.parse(JSON.stringify(state.notesArray.listArray));
            else
                notesArrayDetailsAll = JSON.parse(JSON.stringify(state.notesArray));

            if (action.data.listArray && action.data.listArray.length) {
                let index = notesArrayDetailsAll.findIndex((note) => Number(action.data.listArray[0]["MCKEY"]) == Number(note["MFKEY"]));
                allNotes.splice(index, 0, action.data.listArray);
                if (allNotes.length == state.combinedNotes.length && checkAllValuesExists(allNotes)) {
                    allNotes = sortNotesBasedOnPriority(allNotes);
                    notesArrayDetailsAll = getNotesArray(allNotes);
                }
            }
            return Object.assign({}, state, { allNotesDetails: allNotes, notesArray: notesArrayDetailsAll });
        case SET_BUYER_NOTE_CONTROL_COUNT:
            return Object.assign({}, state, { controlCount: action.data });
        case CLEAR_BUYER_NOTES:
            return Object.assign({}, state, { allNotesDetails: [], combinedNotes: [], notesArray: [] });
        case CONTROL_BUYER_NOTE_CREATION_SUCCESS:
            let controlCount = state.controlCount - 1;
            return Object.assign({}, state, { controlCount: controlCount });
        case CONTROL_BUYER_NOTE_CREATION_FAILURE:
            return Object.assign({}, state, { controlCount: state.controlCount - 1 });
        case REMOVE_BUYER_NOTE_OF_KEY:
            let combinedNotesFiltred = action.data.filterCombined ? state.combinedNotes.filter(note => leftPad(note[0][NOTES_KEY_ACCESSOR], 7, '0') != leftPad(action.data.key, 7, '0')) : state.combinedNotes;
            let noteDetailsFiltered = action.data.filterAllNotes ? state.allNotesDetails.filter(note => leftPad(note[0][NOTES_KEY_ACCESSOR], 7, '0') != leftPad(action.data.key, 7, '0')) : state.allNotesDetails;
            return Object.assign({}, state, { allNotesDetails: noteDetailsFiltered, combinedNotes: combinedNotesFiltred, notesArray: getNotesArray(combinedNotesFiltred) });
        case SET_IS_EMBEDDED_LIST:
            return Object.assign({}, state, { isSetEmbeddedList: false });
        case CLEAR_STATE_VALUES:
            return Object.assign({}, state, {
                pageProps: INITIAL_PAGE_PROPS,
                loading: false,
                notesArray: false,
                selectedNoteDetails: false,
                allNotesDetails: [],
                controlCount: false,
                combinedNotes: false,
                isSetEmbeddedList: false
            });
        default: return { ...state }
    }
    // })
}

export default BuyerNotes;
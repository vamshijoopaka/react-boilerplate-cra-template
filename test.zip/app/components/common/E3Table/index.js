/* eslint-disable no-prototype-builtins */
import Paper from '@material-ui/core/Paper';
import axios from 'axios';
import Divider from '@material-ui/core/Divider';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import Toolbar from '@material-ui/core/Toolbar';
import IconButton from '@material-ui/core/IconButton';
import Typography from '@material-ui/core/Typography';
import FilterListIcon from '@material-ui/icons/FilterList';
import FilterList from '@material-ui/icons/Filter';
// import E3FilterDialog from '../E3FilterDialog';
import { withStyles } from '@material-ui/core/styles';
import TablePagination from '@material-ui/core/TablePagination';
// import LoadingOverlay from 'react-loading-overlay';
import { withRouter } from 'react-router-dom';
import {
  FilteringState, PagingState,
  SortingState, SelectionState
} from '@devexpress/dx-react-grid';
import {
  Grid,
  VirtualTable,
  TableColumnVisibility,
  TableView,
  TableHeaderRow,
  TableSelection
} from '@devexpress/dx-react-grid-material-ui';

import Slide from '@material-ui/core/Slide';
// import E3FilterDialog from './E3FilterDialog';
// import CheckboxContainer from './E3ShowHideCols';
import React from 'react';

import { limit, offset } from 'utils/constants';
import CustomizedTooltip from '../CustomizedTooltipzedTooltip';

// const currentPage = limit;
// const pageSize = offset;

let userDoubleClickedRow = [];
const styles = theme => ({
  icon: {
    margin: theme.spacing(2),
  },
  spacer: {

    marginLeft: 'auto'
  },
})

function Transition(props) {
  return <Slide direction="left" {...props} />;
}

var onCLick = function () {
  return
}

const URL = "http://10.0.14.111:3006/AWR/";
const Root = props => <Grid.Root {...props} style={{ height: '100%' }} />;



class E3Table extends React.Component {
  firstTimeLoad = true;
  previousFilters = null;
  isFilterChanged = true;

  findPrefix = (key) => {
    var regexRevsArray = /KCOMP|KWHSE|KWGRP|KVNDR|KSUBV|KTRUK|KVNAME|KSEQ#|KSTUS|KBRKT|KODEL|KTOT1F|KTOT2F|KTOT3F|KTOT4F|KTOT5F|KTOT6F|KTOT7F|KTOT8F|KTOT9F/
    var regexVndrArray = /KVGRP1|KVGRP2|KVGRP3|KVGRP4|KVGRP5|KVGRP6|KVFCSTD|KVORMON|KVORWEK|KVNXTDT|KRXDRT|KRGCNT|KRDLSTS|KWREGON/ /*|KRPINM|*/
    // var regexWhseArray = //


    // } else if (regexWhseArray.test(key)) {
    //     return 'W';
    // }
    if (this.props.tableComponent == 'Items') {
      return 'I';
    }
    if (this.props.tableComponent == 'Vendors') {
      return 'V';
    }
    if (this.props.tableComponent == 'Ordans') {
      return 'ON';
    }
    if (this.props.tableComponent == 'Openpos') {
      return 'M';
    }

    if (this.props.tableComponent == 'POLines') {
      return 'N';
    }

    if (this.props.tableComponent == 'Expfields') {
      return 'EF';
    }

    if (this.props.tableComponent != 'Items') {
      if (regexRevsArray.test(key)) {
        return 'R';
      } else if (regexVndrArray.test(key)) {
        return '';
      }
    }
    return 'R';
  }
  TableRow = ({ row, history, ...restProps }) => {
    let self = this;
    return (
      <VirtualTable.Row
        {...restProps}

        onDoubleClick={() => {
          let boKeys = self.props.keys;
          console.log(boKeys);
          let boObj = row;
          let filterQuery = '';
          let iter = 0;
          Object.keys(boKeys).forEach(
            function (key) {
              Object.keys(boKeys[key]).forEach(

                function (keyMeta) {

                  if (keyMeta == 'COLUMN_NAME') {
                    if (iter < 7) {
                      let newKey = self.findPrefix(boKeys[key][keyMeta]) + boKeys[key][keyMeta].substring(1);
                      // console.log(boKeys[key][keyMeta]);
                      if (boObj[newKey].trim().length != 0) {
                        filterQuery = filterQuery + boKeys[key][keyMeta] + '=' + boObj[newKey].trim() + '&'
                        // console.log(newKey, boKeys[key][keyMeta], boObj[newKey]);
                      }

                    }
                    iter++;
                  }

                }


              )


            })
          console.log(filterQuery);
          self.props.onSetPropertiesProps(filterQuery);

          // self.props.history.push('/' + self.props.tableComponent + 'Properties', { filter: filterQuery, search: filterQuery });
          self.props.history.push({
            pathname: '/' + self.props.tableComponent + 'Properties',
            search: filterQuery
          });
        }}

      />


    )
  };


  handleFilterDlgQuery(str) {
    console.log(str);
    this.setState({
      loading: true,
      openDialog: false,
      filterQuery: "[" + str + "]"
    }, function () {
      const queryString = this.queryString();
      if (queryString !== this.lastQueryApply) {
        this.getCountandData();
      } else {
        return;
      }
      this.lastQueryApply = queryString;
      this.setState({
        loading: false
      });
    }.bind(this));


  }
  changeSorting(sorting) {
    console.log(sorting);
    let sortingQuery = sorting.reduce((acc, { columnName, direction }) => {
      acc.push(`"${columnName}", "${direction}"`);
      return acc;
    }, []).join("and");//generating sortquery ex:sort="["VCOMP":"asc"],["VVNDR":desc]"
    this.setState({ sortingQuery }, function () {
      this.getCountandData();
    }.bind(this))
  }
  changeCurrentPage(event, currentPageNo) {

    this.props.onSetPageProps({
      pageSize: this.props.pageSize,
      currentPage: currentPageNo
    })

  }
  changeRowsPerPage = event => {

    this.props.onSetPageProps({
      pageSize: event.target.value,
      currentPage: this.props.currentPage
    })
  };

  getCountandData() {
    let newURL = URL + '/' + this.props.tableComponent;
    let urlString = this.queryString();
    let urlStringCount = this.queryString(false);
    // this.fetchData(newURL + '/list' + urlString);
    // this.getCount(newURL + '/listCount' + urlStringCount);

  }

  queryString(bWithPage = true) {
    let newURL = URL + '/' + this.props.tableComponent;
    console.log(newURL);
    const { filterQuery, pageSize, currentPage, sortingQuery } = this.state;
    let queryStrURL = "";
    if (bWithPage) {
      if (filterQuery.length === 0) {
        queryStrURL = `?pagesize=${pageSize}&pagenumber=${currentPage + 1}`;
      }
      else {
        queryStrURL = `?pagesize=${pageSize}&pagenumber=${currentPage}&filter=${this.state.filterQuery}`;
      }
    } else {
      if (filterQuery.length !== 0) {
        queryStrURL = `&filter=${this.state.filterQuery}`;
      }
      return queryStrURL;

    }
    if (sortingQuery != null && sortingQuery.length != 0) {
      queryStrURL = queryStrURL + "&sort=" + sortingQuery;
    }
    console.log(queryStrURL);

    return queryStrURL;
  }
  fetchData(queryString) {
    console.log('queryString at fetchdata' + queryString);
    var self = this;
    // axios.get(queryString).then(
    //   response => {
    //     console.log("Response from sever" + response);
    //     return self.setState({
    //       rows: response.data,
    //       loading: false,
    //       openDialog: false
    //     });
    //   })
    //   .catch(() => this.setState({ loading: false }));
  }
  getCount(url) {
    var self = this;
    // axios.get(url).then(response => {
    //   self.setState({ totalCount: parseInt(response.data[0].TOTALCOUNT, 10) });
    // })
  }

  loadData() {
    this.getCountandData();
  }

  openDialog() {

    this.setState({ openDialog: true });

  }

  openShowHideColsDialog() {

    this.setState({ openShowHideColsDialog: true });

  }
  handleClose() {
    this.setState({ openDialog: false });
    this.setState({ openShowHideColsDialog: false });

  }
  componentDidMount() {

    this.loadData();
    // this.props.onSetPageProps({      
    //     pageSize:this.pageSize,
    //     currentPage:currentPage      
    // });
    window.addEventListener('resize', this.updateWindowDimensions);

  }
  componentWillUnmount() {
    window.removeEventListener("resize", this.updateDimensions);
    console.log(userDoubleClickedRow);
  }
  componentDidUpdate() {
    // window.removeEventListener('resize', this.updateWindowDimensions);
    console.log('hellowy');
  }

  updateWindowDimensions() {
    this.setState({ width: window.innerWidth, tableHeight: window.innerHeight });
    console.log('hellowz');
  }


  changeSelection(selection) {
    // this.props.history.push('/Items');
    console.log(this.props.keys);
    let boKeys = this.props.keys;
    let boObj = this.state.rows[selection];
    console.log(selection);

    Object.keys(boKeys).forEach(
      function (key) {
        Object.keys(boKeys[key]).forEach(
          function (keyMeta) {
            if (keyMeta == 'COLUMN_NAME') {
              let newKey = 'R' + boKeys[key][keyMeta].substring(1);
              // console.log(boKeys[key][keyMeta]);
              if (boObj[newKey].trim().length != 0) {
                console.log(newKey, boObj[newKey]);
              }

            }
          }
        )


      }
    )

  }
  //methods needs to be developed in future
  changeFilters(filters) {
    this.setState({
      loading: true,
      filters,
    });
  }
  formatData(dataObj) {
    var colArr = this.props.cols;

    for (var key in colArr) {
      if (colArr.hasOwnProperty(key)) {
        if (colArr[key].dataType === "Date") {
          dataObj.forEach((data) => {
            // if (data)
            // data[colArr[key].name] = convertToJullian(data[colArr[key].name]);

          })
        }
      }
    }
  }

  setOperator(operator) {
    if (operator === 'equal') {
      return '=';
    }
  }
  //methods needs to be developed in future


  constructor(props) {

    super(props);

    this.state = {
      // filters: [],
      // loading: true,
      // // currentPage: 0,
      // // totalCount: 10,
      // // pageSize: 8,
      openDialog: false,
      tableHeight: window.innerHeight,
      filterQuery: '',
      selection: []


    };

    this.changeFilters = this.changeFilters.bind(this);
    this.openDialog = this.openDialog.bind(this);
    this.handleClose = this.handleClose.bind(this);
    this.handleFilterDlgQuery = this.handleFilterDlgQuery.bind(this)
    this.getCount = this.getCount.bind(this);
    this.loadData = this.loadData.bind(this);
    this.fetchData = this.fetchData.bind(this);
    this.queryString = this.queryString.bind(this);
    this.changeCurrentPage = this.changeCurrentPage.bind(this);
    this.changeSorting = this.changeSorting.bind(this);
    this.changeRowsPerPage = this.changeRowsPerPage.bind(this);
    this.changeSelection = this.changeSelection.bind(this);
    this.updateWindowDimensions = this.updateWindowDimensions.bind(this);
    this.openShowHideColsDialog = this.openShowHideColsDialog.bind(this);

  };
  openDialog() {

    this.setState({ openDialog: true });

  }

  render() {
    const { classes } = this.props;
    const { /*pageSize, currentPage, totalCount,*/ pageSizes, sorting, selection } = this.state;

    return (
      <div style={{}}>
        {/* <Dialog
          open={this.state.openDialog}
          TransitionComponent={Transition}
          keepMounted
          onClose={this.handleClose}
          aria-labelledby="alert-dialog-slide-title"
          aria-describedby="alert-dialog-slide-description"
          maxWidth={false}
        >
          <DialogTitle id="alert-dialog-slide-title">
            {"Filter Dialog"}
          </DialogTitle>
          <DialogContent>
            <E3FilterDialog columnData={this.state.columns} filterDlgQuery={(str) => this.handleFilterDlgQuery(str)} />
            <DialogContentText id="alert-dialog-slide-description">

            </DialogContentText>
          </DialogContent>
          <DialogActions>

          </DialogActions>
        </Dialog> */}
        <Paper style={{ position: 'relative', height: '100%', width: '100%' }}>

          <Toolbar>
            <Typography variant="h6" color="inherit">
              {this.props.tableComponent + ' List '}
            </Typography>


            <div className={classes.spacer} >

            <CustomizedTooltip title="Filter list">
                <IconButton aria-label="Filter list" onClick={this.openDialog}>
                  <FilterList />
                </IconButton>
              </CustomizedTooltip>
              <CustomizedTooltip title="Filter list">
                <IconButton aria-label="Filter list" onClick={this.openShowHideColsDialog}>
                  <FilterListIcon />
                </IconButton>
              </CustomizedTooltip>
            </div>


          </Toolbar>
          <Divider />

          <Grid
            rows={this.props.data || []}
            columns={this.props.cols}
            rootComponent={Root}

          >
            <FilteringState
              onFiltersChange={this.changeFilters}
            />
            <PagingState
              currentPage={this.props.currentPage}
              onCurrentPageChange={this.changeCurrentPage}
              pageSize={this.props.pageSize}
            />

            <SortingState
              sorting={sorting}
              onSortingChange={this.changeSorting}
            />
            <SelectionState
              selection={selection}
              onSelectionChange={this.changeSelection}
            />

            <VirtualTable height={this.state.tableHeight - 210} rowComponent={this.TableRow} ></VirtualTable>
            <TableHeaderRow />

          </Grid>

        </Paper>
        <TablePagination
          rowsPerPageOptions={[8, 16, 24]}
          component="div"
          count={this.props.totalCount}
          rowsPerPage={this.props.pageSize}
          page={this.props.currentPage}
          backIconButtonProps={{
            'aria-label': 'Previous Page',
          }}
          nextIconButtonProps={{
            'aria-label': 'Next Page',
          }}
          onChangePage={this.changeCurrentPage}
          onChangeRowsPerPage={this.changeRowsPerPage}

        />

      </div>


    )
  }
}

export default withRouter(withStyles(styles)(E3Table));



/** Change Log
 * LogStart --  E3C-33195 - Kumar A- 16 September,2021 - 2022.1.0.0 Unified Product
 *              Story: E3C-33195 --Code Cleanup
*/
import React from 'react';
import { Grid, Paper } from '@material-ui/core';
import {
  withStyles,
} from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';

import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import TableContainer from '@material-ui/core/TableContainer';
import FormattedMessageComponent from 'components/common/FormattedMessageComponent';
import {
  LABEL_COMPANY_ET, LABEL_COMPANY_ACTIVE,
  LABEL_COMPANY_ARCHIVE, LABEL_COMPANY_CE,
  LABEL_COMPANY_L5E, LABEL_COMPANY_DFH,
  LABEL_COMPANY_DFL, LABEL_COMPANY_TSH,
  LABEL_COMPANY_TSL, LABEL_COMPANY_SLC,
  LABEL_COMPANY_IC, LABEL_COMPANY_WI,
  LABEL_COMPANY_SI, LABEL_COMPANY_NI,
  LABEL_COMPANY_MI, LABEL_COMPANY_DI,
  ITEMCLASS_LABELS,
}
  from './constants';
import FieldInput from '../../common/Form/FieldInput';

const styles = theme => ({
  pageContainer: {
    display: 'flex',
    backgroundColor: 'var(--background-app)',
    borderTop: 'none',
    padding: '10px 20px',
    marginTop: '-12px',
  },
  root: {
    flexGrow: 1,
    width: '100%',
  },
  card: {
    marginTop: '8px',
  },
  table: {
    marginLeft: theme.spacing(100),
    width: '100%',
  },
  border: {
    borderRight: '1px solid black',
    borderBottom: '1px solid black',
    borderLeft: '1px solid black',
    borderTop: '1px solid black',
    textAlign: 'center',
    backgroundColor: 'white',
    color: '#3F4756',
  },
  border1: {
    borderRight: '1px solid black',
    borderBottom: '1px solid black',
    borderLeft: '1px solid black',
    paddingLeft: '20px',
  },
  simpleCardInput: {
    margin: '0',
    width: '50%',
    textAlignLast: 'center',

    '& input': {
    },
    '&.error-input:after': {
      borderBottom: '2px solid var(--card-error-border) !important'
    },
    '&.error-input:hover::after': {
      borderBottom: '2px solid var(--card-error-border) !important'
    },
  },
  tableHeader: {
    paddingLeft: theme.spacing(0),
    whiteSpace: 'nowrap',
  },
});

const isChecked = (values, field) => {
  if (values.hasOwnProperty(field)) {
    if (typeof values[field] === 'string') {
      if (values[field] === 'Y' || values[field] === 'N') {
        return values[field] === 'Y' ? 1 : 0;
      }
      return parseInt(values[field]);
    }
    if (typeof values[field] === 'boolean') return values[field];
  } else return false;
};

class ExceptionControl extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      values: this.props.values,
    };
  }

  getLabelValue(id) {
    return <FormattedMessageComponent id={id} />;
  }

  handleChangeValue(key, val) {
    const { values } = this.state;
    if (val != undefined) {
      let temp = { ...values, [key]: val }
      this.setState({ values: temp });
    }
  }

  render() {
    const { classes, setSaveData } = this.props;
    const { values } = this.state;
    this.props.changeExceptionControlData(values);
    return (
      <div className={classes.pageContainer}>
        <Grid container spacing={0}>
          <Grid item xs={12}>
            <div style={{ padding: 0 }}>
              <div className={classes.root}>
                <Card className={classes.card}>
                  <TableContainer component={Paper}>
                    <Table className={classes.table} aria-label="simple table">
                      <TableHead>
                        <TableRow>
                          <TableCell
                            className={classes.border}
                            align="left"
                            width="20%"
                          >
                            {this.getLabelValue(
                              LABEL_COMPANY_ET,
                            )}
                          </TableCell>
                          <TableCell
                            className={classes.border}
                            align="centre"
                            width="8%"
                          >
                            {this.getLabelValue(
                              LABEL_COMPANY_ACTIVE,
                            )}
                          </TableCell>
                          <TableCell
                            className={classes.border}
                            align="centre"
                            width="8%"
                          >
                            {this.getLabelValue(
                              LABEL_COMPANY_ARCHIVE,
                            )}
                          </TableCell>
                          {
                            !!ITEMCLASS_LABELS?.length && ITEMCLASS_LABELS.map(fieldId => (
                              <TableCell
                                className={`${classes.border} ${classes.tableHeader}`}
                                align="centre"
                                width="8%"
                                key={fieldId}
                              >
                                {this.getLabelValue(fieldId)}
                              </TableCell>
                            ))
                          }
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        <TableRow>
                          <TableCell
                            className={classes.border1}
                            component="th"
                            scope="row"
                          >
                            {this.getLabelValue(
                              LABEL_COMPANY_CE,
                            )}
                          </TableCell>
                          <TableCell
                            className={classes.border}
                            align="centre"
                          />
                          <TableCell
                            className={classes.border}
                            align="centre"
                          />
                          <TableCell className={classes.border} align="centre">
                            <FieldInput
                              className={classes.simpleCardInput}
                              value={values.FAA}
                              field={{ type: "number", key: "FAA", Attr: ' ' }}
                              numberType={"integer"}
                              isCheckWildCard={true}
                              toUppercase={false}
                              maxLength={1}
                              disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                              minValue={"0"}
                              maxValue={5}
                              isNegative={false}
                              precisionLength={0}
                              prefixFlag={1}
                              defaultValue={"0"}
                              onChange={(key, val) => this.handleChangeValue(key, val)}
                              onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                              enableAddButton={e => setSaveData(e)}
                              isColumnEditable={true}
                              errorMessageLabel={'Consecutive Exceptions'}
                            />
                          </TableCell>
                          <TableCell className={classes.border} align="centre">
                            <FieldInput
                              className={classes.simpleCardInput}
                              value={values.FAB}
                              field={{ type: "number", key: "FAB", Attr: ' ' }}
                              numberType={"integer"}
                              isCheckWildCard={true}
                              toUppercase={false}
                              maxLength={1}
                              disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                              minValue={"0"}
                              maxValue={5}
                              isNegative={false}
                              precisionLength={0}
                              prefixFlag={1}
                              defaultValue={"0"}
                              onChange={(key, val) => this.handleChangeValue(key, val)}
                              onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                              enableAddButton={e => setSaveData(e)}
                              isColumnEditable={true}
                              errorMessageLabel={'Consecutive Exceptions'}
                            />
                          </TableCell>
                          <TableCell className={classes.border} lign="centre">
                            <FieldInput
                              className={classes.simpleCardInput}
                              value={values.FAC}
                              field={{ type: "number", key: "FAC", Attr: ' ' }}
                              numberType={"integer"}
                              isCheckWildCard={true}
                              toUppercase={false}
                              maxLength={1}
                              disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                              minValue={"0"}
                              maxValue={5}
                              isNegative={false}
                              precisionLength={0}
                              prefixFlag={1}
                              defaultValue={"0"}
                              onChange={(key, val) => this.handleChangeValue(key, val)}
                              onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                              enableAddButton={e => setSaveData(e)}
                              isColumnEditable={true}
                              errorMessageLabel={'Consecutive Exceptions'}
                            />
                          </TableCell>
                          <TableCell className={classes.border} align="centre">
                            <FieldInput
                              className={classes.simpleCardInput}
                              value={values.FAD}
                              field={{ type: "number", key: "FAD", Attr: ' ' }}
                              numberType={"integer"}
                              isCheckWildCard={true}
                              toUppercase={false}
                              maxLength={1}
                              disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                              minValue={"0"}
                              maxValue={5}
                              isNegative={false}
                              precisionLength={0}
                              prefixFlag={1}
                              defaultValue={"0"}
                              onChange={(key, val) => this.handleChangeValue(key, val)}
                              onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                              enableAddButton={e => setSaveData(e)}
                              isColumnEditable={true}
                              errorMessageLabel={'Consecutive Exceptions'}
                            />
                          </TableCell>
                          <TableCell className={classes.border} align="centre">
                            <FieldInput
                              className={classes.simpleCardInput}
                              value={values.FAE}
                              field={{ type: "number", key: "FAE", Attr: ' ' }}
                              numberType={"integer"}
                              isCheckWildCard={true}
                              toUppercase={false}
                              maxLength={1}
                              disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                              minValue={"0"}
                              maxValue={5}
                              isNegative={false}
                              precisionLength={0}
                              prefixFlag={1}
                              defaultValue={"0"}
                              onChange={(key, val) => this.handleChangeValue(key, val)}
                              onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                              enableAddButton={e => setSaveData(e)}
                              isColumnEditable={true}
                              errorMessageLabel={'Consecutive Exceptions'}
                            />
                          </TableCell>
                          <TableCell className={classes.border} lign="centre">
                            <FieldInput
                              className={classes.simpleCardInput}
                              value={values.FAF}
                              field={{ type: "number", key: "FAF", Attr: ' ' }}
                              numberType={"integer"}
                              isCheckWildCard={true}
                              toUppercase={false}
                              maxLength={1}
                              disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                              minValue={"0"}
                              maxValue={5}
                              isNegative={false}
                              precisionLength={0}
                              prefixFlag={1}
                              defaultValue={"0"}
                              onChange={(key, val) => this.handleChangeValue(key, val)}
                              onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                              enableAddButton={e => setSaveData(e)}
                              isColumnEditable={true}
                              errorMessageLabel={'Consecutive Exceptions'}
                            />
                          </TableCell>
                          <TableCell className={classes.border} align="centre">
                            <FieldInput
                              className={classes.simpleCardInput}
                              value={values.FAG}
                              field={{ type: "number", key: "FAG", Attr: ' ' }}
                              numberType={"integer"}
                              isCheckWildCard={true}
                              toUppercase={false}
                              maxLength={1}
                              disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                              minValue={"0"}
                              maxValue={5}
                              isNegative={false}
                              precisionLength={0}
                              prefixFlag={1}
                              defaultValue={"0"}
                              onChange={(key, val) => this.handleChangeValue(key, val)}
                              onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                              enableAddButton={e => setSaveData(e)}
                              isColumnEditable={true}
                              errorMessageLabel={'Consecutive Exceptions'}
                            />
                          </TableCell>
                          <TableCell className={classes.border} align="centre">
                            <FieldInput
                              className={classes.simpleCardInput}
                              value={values.FAH}
                              field={{ type: "number", key: "FAH", Attr: ' ' }}
                              numberType={"integer"}
                              isCheckWildCard={true}
                              toUppercase={false}
                              maxLength={1}
                              disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                              minValue={"0"}
                              maxValue={5}
                              isNegative={false}
                              precisionLength={0}
                              prefixFlag={1}
                              defaultValue={"0"}
                              onChange={(key, val) => this.handleChangeValue(key, val)}
                              onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                              enableAddButton={e => setSaveData(e)}
                              isColumnEditable={true}
                              errorMessageLabel={'Consecutive Exceptions'}
                            />
                          </TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell
                            className={classes.border1}
                            component="th"
                            scope="row"
                          >
                            {this.getLabelValue(
                              LABEL_COMPANY_L5E,
                            )}
                          </TableCell>
                          <TableCell
                            className={classes.border}
                            align="centre"
                          />
                          <TableCell
                            className={classes.border}
                            align="centre"
                          />
                          <TableCell className={classes.border} align="centre">
                            <FieldInput
                              className={classes.simpleCardInput}
                              value={values.FBA}
                              field={{ type: "number", key: "FBA", Attr: ' ' }}
                              numberType={"integer"}
                              isCheckWildCard={true}
                              toUppercase={false}
                              maxLength={1}
                              disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                              minValue={"0"}
                              maxValue={5}
                              isNegative={false}
                              precisionLength={0}
                              prefixFlag={1}
                              defaultValue={"0"}
                              onChange={(key, val) => this.handleChangeValue(key, val)}
                              onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                              enableAddButton={e => setSaveData(e)}
                              isColumnEditable={true}
                              errorMessageLabel={'Last 5 Exceptions'}
                            />
                          </TableCell>
                          <TableCell className={classes.border} align="centre">
                            <FieldInput
                              className={classes.simpleCardInput}
                              value={values.FBB}
                              field={{ type: "number", key: "FBB", Attr: ' ' }}
                              numberType={"integer"}
                              isCheckWildCard={true}
                              toUppercase={false}
                              maxLength={1}
                              disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                              minValue={"0"}
                              maxValue={5}
                              isNegative={false}
                              precisionLength={0}
                              prefixFlag={1}
                              defaultValue={"0"}
                              onChange={(key, val) => this.handleChangeValue(key, val)}
                              onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                              enableAddButton={e => setSaveData(e)}
                              isColumnEditable={true}
                              errorMessageLabel={'Last 5 Exceptions'}
                            />
                          </TableCell>
                          <TableCell className={classes.border} lign="centre">
                            <FieldInput
                              className={classes.simpleCardInput}
                              value={values.FBC}
                              field={{ type: "number", key: "FBC", Attr: ' ' }}
                              numberType={"integer"}
                              isCheckWildCard={true}
                              toUppercase={false}
                              maxLength={1}
                              disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                              minValue={"0"}
                              maxValue={5}
                              isNegative={false}
                              precisionLength={0}
                              prefixFlag={1}
                              defaultValue={"0"}
                              onChange={(key, val) => this.handleChangeValue(key, val)}
                              onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                              enableAddButton={e => setSaveData(e)}
                              isColumnEditable={true}
                              errorMessageLabel={'Last 5 Exceptions'}
                            />
                          </TableCell>
                          <TableCell className={classes.border} align="centre">
                            <FieldInput
                              className={classes.simpleCardInput}
                              value={values.FBD}
                              field={{ type: "number", key: "FBD", Attr: ' ' }}
                              numberType={"integer"}
                              isCheckWildCard={true}
                              toUppercase={false}
                              maxLength={1}
                              disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                              minValue={"0"}
                              maxValue={5}
                              isNegative={false}
                              precisionLength={0}
                              prefixFlag={1}
                              defaultValue={"0"}
                              onChange={(key, val) => this.handleChangeValue(key, val)}
                              onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                              enableAddButton={e => setSaveData(e)}
                              isColumnEditable={true}
                              errorMessageLabel={'Last 5 Exceptions'}
                            />
                          </TableCell>
                          <TableCell className={classes.border} align="centre">
                            <FieldInput
                              className={classes.simpleCardInput}
                              value={values.FBE}
                              field={{ type: "number", key: "FBE", Attr: ' ' }}
                              numberType={"integer"}
                              isCheckWildCard={true}
                              toUppercase={false}
                              maxLength={1}
                              disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                              minValue={"0"}
                              maxValue={5}
                              isNegative={false}
                              precisionLength={0}
                              prefixFlag={1}
                              defaultValue={"0"}
                              onChange={(key, val) => this.handleChangeValue(key, val)}
                              onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                              enableAddButton={e => setSaveData(e)}
                              isColumnEditable={true}
                              errorMessageLabel={'Last 5 Exceptions'}
                            />
                          </TableCell>
                          <TableCell className={classes.border} lign="centre">
                            <FieldInput
                              className={classes.simpleCardInput}
                              value={values.FBF}
                              field={{ type: "number", key: "FBF", Attr: ' ' }}
                              numberType={"integer"}
                              isCheckWildCard={true}
                              toUppercase={false}
                              maxLength={1}
                              disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                              minValue={"0"}
                              maxValue={5}
                              isNegative={false}
                              precisionLength={0}
                              prefixFlag={1}
                              defaultValue={"0"}
                              onChange={(key, val) => this.handleChangeValue(key, val)}
                              onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                              enableAddButton={e => setSaveData(e)}
                              isColumnEditable={true}
                              errorMessageLabel={'Last 5 Exceptions'}
                            />
                          </TableCell>
                          <TableCell className={classes.border} align="centre">
                            <FieldInput
                              className={classes.simpleCardInput}
                              value={values.FBG}
                              field={{ type: "number", key: "FBG", Attr: ' ' }}
                              numberType={"integer"}
                              isCheckWildCard={true}
                              toUppercase={false}
                              maxLength={1}
                              disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                              minValue={"0"}
                              maxValue={5}
                              isNegative={false}
                              precisionLength={0}
                              prefixFlag={1}
                              defaultValue={"0"}
                              onChange={(key, val) => this.handleChangeValue(key, val)}
                              onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                              enableAddButton={e => setSaveData(e)}
                              isColumnEditable={true}
                              errorMessageLabel={'Last 5 Exceptions'}
                            />
                          </TableCell>
                          <TableCell className={classes.border} align="centre">
                            <FieldInput
                              className={classes.simpleCardInput}
                              value={values.FBH}
                              field={{ type: "number", key: "FBH", Attr: ' ' }}
                              numberType={"integer"}
                              isCheckWildCard={true}
                              toUppercase={false}
                              maxLength={1}
                              disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                              minValue={"0"}
                              maxValue={5}
                              isNegative={false}
                              precisionLength={0}
                              prefixFlag={1}
                              defaultValue={"0"}
                              onChange={(key, val) => this.handleChangeValue(key, val)}
                              onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                              enableAddButton={e => setSaveData(e)}
                              isColumnEditable={true}
                              errorMessageLabel={'Last 5 Exceptions'}
                            />
                          </TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell
                            className={classes.border1}
                            component="th"
                            scope="row"
                          >
                            {this.getLabelValue(
                              LABEL_COMPANY_DFH,
                            )}
                          </TableCell>
                          <TableCell className={classes.border} align="centre">
                            <FieldInput
                              className={classes.simpleCardInput}
                              value={values.FCSTS}
                              field={{ type: "checkbox", key: "FCSTS" }}
                              numberType={"integer"}
                              isCheckWildCard={true}
                              toUppercase={false}
                              disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                              prefixFlag={1}
                              defaultValue={"0"}
                              onChange={(key, val) => this.handleChangeValue(key, val)}
                              enableAddButton={e => setSaveData(e)}
                              isColumnEditable={true}
                              errorMessageLabel={''}
                            />
                          </TableCell>
                          <TableCell className={classes.border} align="centre">
                            <FieldInput
                              className={classes.simpleCardInput}
                              value={values.FCARCH}
                              field={{ type: "checkbox", key: "FCARCH" }}
                              numberType={"integer"}
                              isCheckWildCard={true}
                              toUppercase={false}
                              disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                              prefixFlag={1}
                              defaultValue={"0"}
                              onChange={(key, val) => this.handleChangeValue(key, val)}
                              enableAddButton={e => setSaveData(e)}
                              isColumnEditable={true}
                              errorMessageLabel={''}
                            />
                          </TableCell>
                          <TableCell className={classes.border} align="centre">
                            <FieldInput
                              className={classes.simpleCardInput}
                              value={isChecked(values, 'FCA')}
                              field={{ type: "checkbox", key: "FCA" }}
                              numberType={"integer"}
                              isCheckWildCard={true}
                              toUppercase={false}
                              disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                              prefixFlag={1}
                              defaultValue={"0"}
                              onChange={(key, val) => this.handleChangeValue(key, val)}
                              enableAddButton={e => setSaveData(e)}
                              isColumnEditable={true}
                              errorMessageLabel={''}
                            />
                          </TableCell>
                          <TableCell className={classes.border} align="centre">
                            <FieldInput
                              className={classes.simpleCardInput}
                              value={isChecked(values, 'FCB')}
                              field={{ type: "checkbox", key: "FCB" }}
                              numberType={"integer"}
                              isCheckWildCard={true}
                              toUppercase={false}
                              disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                              prefixFlag={1}
                              defaultValue={"0"}
                              onChange={(key, val) => this.handleChangeValue(key, val)}
                              enableAddButton={e => setSaveData(e)}
                              isColumnEditable={true}
                              errorMessageLabel={''}
                            />
                          </TableCell>
                          <TableCell className={classes.border} align="centre">
                            <FieldInput
                              className={classes.simpleCardInput}
                              value={isChecked(values, 'FCC')}
                              field={{ type: "checkbox", key: "FCC" }}
                              numberType={"integer"}
                              isCheckWildCard={true}
                              toUppercase={false}
                              disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                              prefixFlag={1}
                              defaultValue={"0"}
                              onChange={(key, val) => this.handleChangeValue(key, val)}
                              enableAddButton={e => setSaveData(e)}
                              isColumnEditable={true}
                              errorMessageLabel={''}
                            />
                          </TableCell>
                          <TableCell className={classes.border} align="centre">
                            <FieldInput
                              className={classes.simpleCardInput}
                              value={isChecked(values, 'FCD')}
                              field={{ type: "checkbox", key: "FCD" }}
                              numberType={"integer"}
                              isCheckWildCard={true}
                              toUppercase={false}
                              disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                              prefixFlag={1}
                              defaultValue={"0"}
                              onChange={(key, val) => this.handleChangeValue(key, val)}
                              enableAddButton={e => setSaveData(e)}
                              isColumnEditable={true}
                              errorMessageLabel={''}
                            />
                          </TableCell>
                          <TableCell className={classes.border} align="centre">
                            <FieldInput
                              className={classes.simpleCardInput}
                              value={isChecked(values, 'FCE')}
                              field={{ type: "checkbox", key: "FCE" }}
                              numberType={"integer"}
                              isCheckWildCard={true}
                              toUppercase={false}
                              disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                              prefixFlag={1}
                              defaultValue={"0"}
                              onChange={(key, val) => this.handleChangeValue(key, val)}
                              enableAddButton={e => setSaveData(e)}
                              isColumnEditable={true}
                              errorMessageLabel={''}
                            />
                          </TableCell>
                          <TableCell className={classes.border} align="centre">
                            <FieldInput
                              className={classes.simpleCardInput}
                              value={isChecked(values, 'FCF')}
                              field={{ type: "checkbox", key: "FCF" }}
                              numberType={"integer"}
                              isCheckWildCard={true}
                              toUppercase={false}
                              disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                              prefixFlag={1}
                              defaultValue={"0"}
                              onChange={(key, val) => this.handleChangeValue(key, val)}
                              enableAddButton={e => setSaveData(e)}
                              isColumnEditable={true}
                              errorMessageLabel={''}
                            />
                          </TableCell>
                          <TableCell className={classes.border} align="centre">
                            <FieldInput
                              className={classes.simpleCardInput}
                              value={isChecked(values, 'FCG')}
                              field={{ type: "checkbox", key: "FCG" }}
                              numberType={"integer"}
                              isCheckWildCard={true}
                              toUppercase={false}
                              disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                              prefixFlag={1}
                              defaultValue={"0"}
                              onChange={(key, val) => this.handleChangeValue(key, val)}
                              enableAddButton={e => setSaveData(e)}
                              isColumnEditable={true}
                              errorMessageLabel={''}
                            />
                          </TableCell>
                          <TableCell className={classes.border} align="centre">
                            <FieldInput
                              className={classes.simpleCardInput}
                              value={isChecked(values, 'FCH')}
                              field={{ type: "checkbox", key: "FCH" }}
                              numberType={"integer"}
                              isCheckWildCard={true}
                              toUppercase={false}
                              disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                              prefixFlag={1}
                              defaultValue={"0"}
                              onChange={(key, val) => this.handleChangeValue(key, val)}
                              enableAddButton={e => setSaveData(e)}
                              isColumnEditable={true}
                              errorMessageLabel={''}
                            />
                          </TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell
                            className={classes.border1}
                            component="th"
                            scope="row"
                          >
                            {this.getLabelValue(
                              LABEL_COMPANY_DFL,
                            )}
                          </TableCell>
                          <TableCell className={classes.border} align="centre">
                            <FieldInput
                              className={classes.simpleCardInput}
                              value={values.FDSTS}
                              field={{ type: "checkbox", key: "FDSTS" }}
                              numberType={"integer"}
                              isCheckWildCard={true}
                              toUppercase={false}
                              disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                              prefixFlag={1}
                              defaultValue={"0"}
                              onChange={(key, val) => this.handleChangeValue(key, val)}
                              enableAddButton={e => setSaveData(e)}
                              isColumnEditable={true}
                              errorMessageLabel={''}
                            />
                          </TableCell>
                          <TableCell className={classes.border} align="centre">
                            <FieldInput
                              className={classes.simpleCardInput}
                              value={values.FDARCH}
                              field={{ type: "checkbox", key: "FDARCH" }}
                              numberType={"integer"}
                              isCheckWildCard={true}
                              toUppercase={false}
                              disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                              prefixFlag={1}
                              defaultValue={"0"}
                              onChange={(key, val) => this.handleChangeValue(key, val)}
                              enableAddButton={e => setSaveData(e)}
                              isColumnEditable={true}
                              errorMessageLabel={''}
                            />
                          </TableCell>
                          <TableCell className={classes.border} align="centre">
                            <FieldInput
                              className={classes.simpleCardInput}
                              value={isChecked(values, 'FDA')}
                              field={{ type: "checkbox", key: "FDA" }}
                              numberType={"integer"}
                              isCheckWildCard={true}
                              toUppercase={false}
                              disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                              prefixFlag={1}
                              defaultValue={"0"}
                              onChange={(key, val) => this.handleChangeValue(key, val)}
                              enableAddButton={e => setSaveData(e)}
                              isColumnEditable={true}
                              errorMessageLabel={''}
                            />
                          </TableCell>
                          <TableCell className={classes.border} align="centre">
                            <FieldInput
                              className={classes.simpleCardInput}
                              value={isChecked(values, 'FDB')}
                              field={{ type: "checkbox", key: "FDB" }}
                              numberType={"integer"}
                              isCheckWildCard={true}
                              toUppercase={false}
                              disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                              prefixFlag={1}
                              defaultValue={"0"}
                              onChange={(key, val) => this.handleChangeValue(key, val)}
                              enableAddButton={e => setSaveData(e)}
                              isColumnEditable={true}
                              errorMessageLabel={''}
                            />
                          </TableCell>
                          <TableCell className={classes.border} align="centre">
                            <FieldInput
                              className={classes.simpleCardInput}
                              value={isChecked(values, 'FDC')}
                              field={{ type: "checkbox", key: "FDC" }}
                              numberType={"integer"}
                              isCheckWildCard={true}
                              toUppercase={false}
                              disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                              prefixFlag={1}
                              defaultValue={"0"}
                              onChange={(key, val) => this.handleChangeValue(key, val)}
                              enableAddButton={e => setSaveData(e)}
                              isColumnEditable={true}
                              errorMessageLabel={''}
                            />
                          </TableCell>
                          <TableCell className={classes.border} align="centre">
                            <FieldInput
                              className={classes.simpleCardInput}
                              value={isChecked(values, 'FDD')}
                              field={{ type: "checkbox", key: "FDD" }}
                              numberType={"integer"}
                              isCheckWildCard={true}
                              toUppercase={false}
                              disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                              prefixFlag={1}
                              defaultValue={"0"}
                              onChange={(key, val) => this.handleChangeValue(key, val)}
                              enableAddButton={e => setSaveData(e)}
                              isColumnEditable={true}
                              errorMessageLabel={''}
                            />
                          </TableCell>
                          <TableCell className={classes.border} align="centre">
                            <FieldInput
                              className={classes.simpleCardInput}
                              value={isChecked(values, 'FDE')}
                              field={{ type: "checkbox", key: "FDE" }}
                              numberType={"integer"}
                              isCheckWildCard={true}
                              toUppercase={false}
                              disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                              prefixFlag={1}
                              defaultValue={"0"}
                              onChange={(key, val) => this.handleChangeValue(key, val)}
                              enableAddButton={e => setSaveData(e)}
                              isColumnEditable={true}
                              errorMessageLabel={''}
                            />
                          </TableCell>
                          <TableCell className={classes.border} align="centre">
                            <FieldInput
                              className={classes.simpleCardInput}
                              value={isChecked(values, 'FDF')}
                              field={{ type: "checkbox", key: "FDF" }}
                              numberType={"integer"}
                              isCheckWildCard={true}
                              toUppercase={false}
                              disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                              prefixFlag={1}
                              defaultValue={"0"}
                              onChange={(key, val) => this.handleChangeValue(key, val)}
                              enableAddButton={e => setSaveData(e)}
                              isColumnEditable={true}
                              errorMessageLabel={''}
                            />
                          </TableCell>
                          <TableCell className={classes.border} align="centre">
                            <FieldInput
                              className={classes.simpleCardInput}
                              value={isChecked(values, 'FDG')}
                              field={{ type: "checkbox", key: "FDG" }}
                              numberType={"integer"}
                              isCheckWildCard={true}
                              toUppercase={false}
                              disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                              prefixFlag={1}
                              defaultValue={"0"}
                              onChange={(key, val) => this.handleChangeValue(key, val)}
                              enableAddButton={e => setSaveData(e)}
                              isColumnEditable={true}
                              errorMessageLabel={''}
                            />
                          </TableCell>
                          <TableCell className={classes.border} align="centre">
                            <FieldInput
                              className={classes.simpleCardInput}
                              value={isChecked(values, 'FDH')}
                              field={{ type: "checkbox", key: "FDH" }}
                              numberType={"integer"}
                              isCheckWildCard={true}
                              toUppercase={false}
                              disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                              prefixFlag={1}
                              defaultValue={"0"}
                              onChange={(key, val) => this.handleChangeValue(key, val)}
                              enableAddButton={e => setSaveData(e)}
                              isColumnEditable={true}
                              errorMessageLabel={''}
                            />
                          </TableCell>
                        </TableRow>
                      </TableBody>
                      <TableRow>
                        <TableCell
                          className={classes.border1}
                          component="th"
                          scope="row"
                        >
                          {this.getLabelValue(
                            LABEL_COMPANY_TSH,
                          )}
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={values.FESTS}
                            field={{ type: "checkbox", key: "FESTS" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={values.FEARCH}
                            field={{ type: "checkbox", key: "FEARCH" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={isChecked(values, 'FEA')}
                            field={{ type: "checkbox", key: "FEA" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={isChecked(values, 'FEB')}
                            field={{ type: "checkbox", key: "FEB" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={isChecked(values, 'FEC')}
                            field={{ type: "checkbox", key: "FEC" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={isChecked(values, 'FED')}
                            field={{ type: "checkbox", key: "FED" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={isChecked(values, 'FEE')}
                            field={{ type: "checkbox", key: "FEE" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={isChecked(values, 'FEF')}
                            field={{ type: "checkbox", key: "FEF" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={isChecked(values, 'FEG')}
                            field={{ type: "checkbox", key: "FEG" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={isChecked(values, 'FEH')}
                            field={{ type: "checkbox", key: "FEH" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell
                          className={classes.border1}
                          component="th"
                          scope="row"
                        >
                          {this.getLabelValue(
                            LABEL_COMPANY_TSL,
                          )}
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={values.FFSTS}
                            field={{ type: "checkbox", key: "FFSTS" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={values.FFARCH}
                            field={{ type: "checkbox", key: "FFARCH" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={isChecked(values, 'FFA')}
                            field={{ type: "checkbox", key: "FFA" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={isChecked(values, 'FFB')}
                            field={{ type: "checkbox", key: "FFB" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={isChecked(values, 'FFC')}
                            field={{ type: "checkbox", key: "FFC" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={isChecked(values, 'FFD')}
                            field={{ type: "checkbox", key: "FFD" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={isChecked(values, 'FFE')}
                            field={{ type: "checkbox", key: "FFE" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={isChecked(values, 'FFF')}
                            field={{ type: "checkbox", key: "FFF" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={isChecked(values, 'FFG')}
                            field={{ type: "checkbox", key: "FFG" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={isChecked(values, 'FFH')}
                            field={{ type: "checkbox", key: "FFH" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell
                          className={classes.border1}
                          component="th"
                          scope="row"
                        >
                          {this.getLabelValue(
                            LABEL_COMPANY_SLC,
                          )}
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={values.FGSTS}
                            field={{ type: "checkbox", key: "FGSTS" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={values.FGARCH}
                            field={{ type: "checkbox", key: "FGARCH" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={isChecked(values, 'FGA')}
                            field={{ type: "checkbox", key: "FGA" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={isChecked(values, 'FGB')}
                            field={{ type: "checkbox", key: "FGB" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={isChecked(values, 'FGC')}
                            field={{ type: "checkbox", key: "FGC" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={isChecked(values, 'FGD')}
                            field={{ type: "checkbox", key: "FGD" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={isChecked(values, 'FGE')}
                            field={{ type: "checkbox", key: "FGE" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={isChecked(values, 'FGF')}
                            field={{ type: "checkbox", key: "FGF" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={isChecked(values, 'FGG')}
                            field={{ type: "checkbox", key: "FGG" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={isChecked(values, 'FGH')}
                            field={{ type: "checkbox", key: "FGH" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell
                          className={classes.border1}
                          component="th"
                          scope="row"
                        >
                          {this.getLabelValue(
                            LABEL_COMPANY_IC,
                          )}
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={values.FHSTS}
                            field={{ type: "checkbox", key: "FHSTS" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={values.FHARCH}
                            field={{ type: "checkbox", key: "FHARCH" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={isChecked(values, 'FHA')}
                            field={{ type: "checkbox", key: "FHA" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={isChecked(values, 'FHB')}
                            field={{ type: "checkbox", key: "FHB" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={isChecked(values, 'FHC')}
                            field={{ type: "checkbox", key: "FHC" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={isChecked(values, 'FHD')}
                            field={{ type: "checkbox", key: "FHD" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={isChecked(values, 'FHE')}
                            field={{ type: "checkbox", key: "FHE" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={isChecked(values, 'FHF')}
                            field={{ type: "checkbox", key: "FHF" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={isChecked(values, 'FHG')}
                            field={{ type: "checkbox", key: "FHG" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={isChecked(values, 'FHH')}
                            field={{ type: "checkbox", key: "FHH" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell
                          className={classes.border1}
                          component="th"
                          scope="row"
                        >
                          {this.getLabelValue(
                            LABEL_COMPANY_WI,
                          )}
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={isChecked(values, 'FISTS')}
                            field={{ type: "checkbox", key: "FISTS" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={isChecked(values, 'FIARCH')}
                            field={{ type: "checkbox", key: "FIARCH" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre" />
                        <TableCell className={classes.border} align="centre" />
                        <TableCell className={classes.border} align="centre" />
                        <TableCell className={classes.border} align="centre" />
                        <TableCell className={classes.border} align="centre" />
                        <TableCell className={classes.border} align="centre" />
                        <TableCell className={classes.border} align="centre" />
                        <TableCell className={classes.border} align="centre" />
                      </TableRow>
                      <TableRow>
                        <TableCell
                          className={classes.border1}
                          component="th"
                          scope="row"
                        >
                          {this.getLabelValue(
                            LABEL_COMPANY_SI,
                          )}
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={isChecked(values, 'FJSTS')}
                            field={{ type: "checkbox", key: "FJSTS" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={isChecked(values, 'FJARCH')}
                            field={{ type: "checkbox", key: "FJARCH" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre" />
                        <TableCell className={classes.border} align="centre" />
                        <TableCell className={classes.border} align="centre" />
                        <TableCell className={classes.border} align="centre" />
                        <TableCell className={classes.border} align="centre" />
                        <TableCell className={classes.border} align="centre" />
                        <TableCell className={classes.border} align="centre" />
                        <TableCell className={classes.border} align="centre" />
                      </TableRow>
                      <TableRow>
                        <TableCell
                          className={classes.border1}
                          component="th"
                          scope="row"
                        >
                          {this.getLabelValue(
                            LABEL_COMPANY_NI,
                          )}
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={isChecked(values, 'FKSTS')}
                            field={{ type: "checkbox", key: "FKSTS" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={isChecked(values, 'FKARCH')}
                            field={{ type: "checkbox", key: "FKARCH" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre" />
                        <TableCell className={classes.border} align="centre" />
                        <TableCell className={classes.border} align="centre" />
                        <TableCell className={classes.border} align="centre" />
                        <TableCell className={classes.border} align="centre" />
                        <TableCell className={classes.border} align="centre" />
                        <TableCell className={classes.border} align="centre" />
                        <TableCell className={classes.border} align="centre" />
                      </TableRow>
                      <TableRow>
                        <TableCell
                          className={classes.border1}
                          component="th"
                          scope="row"
                        >
                          {this.getLabelValue(
                            LABEL_COMPANY_MI,
                          )}
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={isChecked(values, 'FLSTS')}
                            field={{ type: "checkbox", key: "FLSTS" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={isChecked(values, 'FLARCH')}
                            field={{ type: "checkbox", key: "FLARCH" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre" />
                        <TableCell className={classes.border} align="centre" />
                        <TableCell className={classes.border} align="centre" />
                        <TableCell className={classes.border} align="centre" />
                        <TableCell className={classes.border} align="centre" />
                        <TableCell className={classes.border} align="centre" />
                        <TableCell className={classes.border} align="centre" />
                        <TableCell className={classes.border} align="centre" />
                      </TableRow>
                      <TableRow>
                        <TableCell
                          className={classes.border1}
                          component="th"
                          scope="row"
                        >
                          {this.getLabelValue(
                            LABEL_COMPANY_DI,
                          )}
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={isChecked(values, 'FMSTS')}
                            field={{ type: "checkbox", key: "FMSTS" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre">
                          <FieldInput
                            className={classes.simpleCardInput}
                            value={isChecked(values, 'FMARCH')}
                            field={{ type: "checkbox", key: "FMARCH" }}
                            numberType={"integer"}
                            isCheckWildCard={true}
                            toUppercase={false}
                            disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                            prefixFlag={1}
                            defaultValue={"0"}
                            onChange={(key, val) => this.handleChangeValue(key, val)}
                            enableAddButton={e => setSaveData(e)}
                            isColumnEditable={true}
                            errorMessageLabel={''}
                          />
                        </TableCell>
                        <TableCell className={classes.border} align="centre" />
                        <TableCell className={classes.border} align="centre" />
                        <TableCell className={classes.border} align="centre" />
                        <TableCell className={classes.border} align="centre" />
                        <TableCell className={classes.border} align="centre" />
                        <TableCell className={classes.border} align="centre" />
                        <TableCell className={classes.border} align="centre" />
                        <TableCell className={classes.border} align="centre" />
                      </TableRow>
                    </Table>
                  </TableContainer>
                </Card>
              </div>
            </div>
          </Grid>
        </Grid>
      </div>
    );
  }
}

export default withStyles(styles)(ExceptionControl);

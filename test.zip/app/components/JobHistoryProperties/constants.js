export const HeaderAPIValuesJSON = [
    {
        "RLJOBN": "",//Job Number     
        "JBJDES": "",//Job Description
        "JBJTYP": "",//Job Type      
        "RLJSTS": "",//Current Status 
        "RLENDD": "",//Last Run Date
        "RLENDT": "",//Last Run Time
		"RLJSTS": "",//Last Run Status 
		"PJPROJ" :"" //Projecton id
    }
];

// PLEASE NOTE THAT THE KEYS USED FOR HEADER VALUES MAY NOT BE SAME FOR FUTURE WORK.
// PLEASE CHANGE THE KEY VALUES TO REQUIRED KEYS AS NECCESSARY.
export const KEY_JBJOBN = "JBJOBN";
export const KEY_JBJDES = "JBJDES";
export const KEY_JBJTYP = "JBJTYP";
export const KEY_JBJSTS = "JBJSTS";
export const KEY_JBRUND = "JBRUND";
export const KEY_JBRUNT = "JBRUNT";
export const KEY_JBRSTS = "JBRSTS";

export const LABEL_JOBHISTORY_LIST = "25725"; // ! needs to be included in Header_ENG.json
export const LABEL_JOB_NUMBER = "2320";// ! needs to be included in Header_ENG.json
export const LABEL_JOB_DESCRIPTION = "2303"; // ! needs to be included in Header_ENG.json
export const LABEL_JOB_TYPE = "2304";// ! needs to be included in Header_ENG.json
export const LABEL_JOB_STATUS = "2308";// ! needs to be included in Header_ENG.json
export const LABEL_JOB_RUNDATE = "2306";// ! needs to be included in Header_ENG.json
export const LABEL_JOB_RUNTIME = "2307";// ! needs to be included in Header_ENG.json
export const LABEL_JOB_RERUN_STATUS = "2308";// ! needs to be included in Header_ENG.json

export const LABEL_ACTIONS = '28310';

export const DEFAULT_FIELD_URL_DATA = [
    { "accessor": "DSNAME", "operator": "=", "fieldValue": "DSJOBS", "prefixFlag": 1 },
    { "accessor": "BONAME", "operator": "=", "fieldValue": "SIMJobsUI", "prefixFlag": 1 }
]


export const DEFAULT_VALUE_URL_DATA = 
[
    { "accessor": "JTYP", "operator": "=", "fieldValue": "", "prefixFlag": 0 },
    { "accessor": "JOBN", "operator": "=", "fieldValue": "", "prefixFlag": 0 }
 
]


export const LABEL_LIST_URL_DATA = [
    { "accessor": "TRIMBO", "operator": "=", "fieldValue": "SIMJobsUI", "prefixFlag": 0 },    
    { "accessor": "LANGID", "operator": "=", "fieldValue": "ENG", "prefixFlag": 0 }
]


export const BRACKET_LABEL_URL_DATA = [
    { "accessor": "TRIMBO", "operator": "=", "fieldValue": "SIMJobsUI", "prefixFlag": 0 },
    { "accessor": "LANGID", "operator": "=", "fieldValue": "ENG", "prefixFlag": 0 }
]


export const JOBHISTORY_PROPERTIES = 'jobhistoryProperties';

export const LABEL_VENDOR_ID = '41157';
export const LABEL_ITEM_ID = '41157';
export const LABEL_WAREHOUSE_ID = '41157';
export const LABEL_BUYER_ID = '41157';
export const LABEL_VENDOR_NAME = '41157';
export const LABEL_ITEM_NAME = '41157';
export const LABEL_WAREHOUSE_NAME = '41157';
export const LABEL_ITEMGRP_1 = '41157';
export const LABEL_ITEMGRP_2 = '41157';
export const LABEL_ITEMGRP_3 = '41157';
export const LABEL_ITEMGRP_4 = '41157';
export const LABEL_SUPER = '41157';
export const LABEL_UPC = '41157';
export const LABEL_MFG_ID = '41157';
export const LABEL_REGION_ID = '41157';
export const LABEL_TIEHI = '41157';


export const CONTEXT_MENU_HEADER_JOBHISTORY_ACTIONS = [
    {
        //Fix for E3C-32986
        label: '2919',
        key: 'undo',
        hasSubMenu: false,
        isDisable: false
    },
];

export const EQUALS_TO = '2869' //'Equals to';
export const GREATER_THAN = '2871' //'Greater than';
export const GREATER_THAN_OR_EQUALS_TO = '2873'//'Greater than or Equals to';
export const LESS_THAN = '2872'//'Less than';
export const LESS_THAN_OR_EQUALS_TO = '2874' //'Less than or equals to';
export const NOT_EQUALS_TO = '2870'//'Less than or Equals to';

export const REPORT_NAME = "Export Error";
export const MAX_JOB_STATUS_CALL_COUNT = 10;  //10 Iterations
export const JOB_STATUS_API_INTERVAL = 30000;
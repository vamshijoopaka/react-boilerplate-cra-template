import React from 'react';
import InputLabel from '@material-ui/core/InputLabel';
import { withStyles } from '@material-ui/core/styles';
import InputText from 'components/common/Form/InputText';
import { Box } from '@material-ui/core';
import TextField from '@material-ui/core/TextField';

const styles = theme => ({
    label: {
        padding: '.3rem 0'
    }
})
class TextInput extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
        }
        this.onKeyDown = this.onKeyDown.bind(this);
    }
    onKeyDown(val) {
    }
    render() {
        const { classes } = this.props;
        return (
            <Box>
                <InputLabel className={classes.label}>{this.props.label}</InputLabel>
                <TextField
                value={this.props.form.values[this.props.accessor] || ''}
                onChange={(e) => this.props.form.onChange(this.props.accessor, e.currentTarget.value)}
                type={this.props.type}
                id={this.props.accessor}
                ></TextField>
            </Box>
        )
    }
}

export default (withStyles(styles)(TextInput));
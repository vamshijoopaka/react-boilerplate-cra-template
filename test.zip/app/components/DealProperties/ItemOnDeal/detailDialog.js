import React, { Component } from 'react';
import DialogComponent from 'components/common/DialogComponent';
import { withStyles, Box, Typography } from '@material-ui/core';
import theme from '../../../jda-gcp-theme';
import FormattedMessageComponent from '../../common/FormattedMessageComponent';
import FormFieldsGenerator from '../../common/FormFieldsGenerator';
import EmbeddedList from 'containers/common/EmbeddedList';
import Spinner from 'components/Common/Spinner';
import SKUDefaultAllowanceEmbeddedList from 'containers/DealsEmbeddedListPage/SKUDefaultAllowanceEmbeddedList'
import {
	ITEM_ON_DEAL, MENU_ITEMS, LABEL_ITEM_ON_DEAL, LABEL_CLOSE, LABEL_NEXT,
	LABEL_PREVIOUS, VENDOR_ID, ITEM, WAREHOUSE, LABEL_DEAL, REGULAR_COST,
	DEAL_COST
} from "./constants";
import {
	ITEM_ON_DEAL_LABEL_TAB_KEY,
	DEAL_SUMMARY_LABEL_TAB_KEY,
	RESTRICTIONS_CARD_KEY,
	BILL_BACK_CARD_KEY,
	SPECIAL_TERMS_CARD_KEY,
	GENERAL_CARD_KEY,
} from "../constants";
import { TEXT_CANCEL, TEXT_ALERT, TEXT_OK } from '../../common/constants';

const styles = theme => ({
	pageContainer: {
		backgroundColor: 'var(--background-app)',
		borderTop: 'none',
		padding: '10px 10px',
	},
	PageWrapper: {
		borderTop: 'none',
		display: 'flex',
	},
	pageContainerThirty: {
		width: '33.3%',
		display: 'flex',
		flexDirection: 'column',
	},
	rightMargin: {
		paddingRight: '10px',
	},
	notesForBlock: {
		display: 'flex',
		flexDirection: 'column',
		marginTop: '10px',
		border: '1px solid var(--divider-line)',
		padding: '10px 10px 0 10px',
		position: 'relative'
	},
	notesForLabel: {
		position: 'absolute',
		top: '-7px',
		left: '10px',
		background: 'var(--background-content)',
		padding: '0 8px',
	},
	fieldLabel: {
		color: 'var(--header-label-color)',
		padding: '0 0px 8px 0',
		width: '22ch',
	},
	childBlock: {
		display: 'flex',
		padding: '6px'
	},
	fieldValue: {
		color: 'var(--value)'
	},
	fieldValuesParent: {
		display: 'flex'
	},
	idValue: {
		marginRight: '20px',
		minWidth: '15ch'
	},
	adjustDialog1: {
		maxHeight: '100vh',
		maxWidth: '200vh',
		'& .MuiDialogContent-root': {
			padding: '12px'
		},
	},
	simpleCardGroup: {
		width: '100%',
		display: 'flex',
		height: '11rem',
		justifyContent: 'space-around',
	},
})

class ItemOnDealDetail extends Component {
	constructor(props) {
		super(props);
		this.state = {

		}
		this.getValueData = this.getValueData.bind(this);
		this.getDealCost = this.getDealCost.bind(this);
		this.getRegularCost = this.getRegularCost.bind(this);
	}
	getValueData(valueData, newValueData) {
		if (Object.keys(valueData).length && Object.keys(newValueData).length &&
			(JSON.parse(JSON.stringify(valueData)) !== JSON.parse(JSON.stringify(newValueData)))) {
			return newValueData;
		}
		return valueData;
	}
	getDealCost = ( ) => {
		const { itemListArray, rowDataAllowance } = this.props.itemOnDealListPage
		let dDealPrice = 0;
		let m_dNewCost = 0;
		if (rowDataAllowance && rowDataAllowance.length) {
			let dPurPrice = parseFloat(itemListArray["IPCHPR"]);
				dDealPrice = dPurPrice;
			let lPrDiv = parseFloat(itemListArray["IPRDIV"]);
			if (lPrDiv > 1)
				dDealPrice /= lPrDiv;
			for (let i = 0; i < rowDataAllowance.length; i++) {
				const strType = rowDataAllowance[i]["DAALOW"];
				let dPct = rowDataAllowance[i]["DAPCNT"];
				let mult = rowDataAllowance[i]["DAMULT"];
				let AlDisc = rowDataAllowance[i]["DADSCT"];
				let cost = rowDataAllowance[i]["DACOST"];
				if (strType != "I") {
					m_dNewCost = 0;
					let discount;
					if (dPct != 0) {
						discount = (dPct / 100) * dPurPrice;
						if (lPrDiv > 1)
							discount /= lPrDiv;
						dDealPrice -= discount;
					}
					if (mult != 0)
						AlDisc /= mult;
					dDealPrice -= AlDisc;

					if (cost != 0)
						dDealPrice = cost;
				}
			}

		}
		if (dDealPrice == 0)
			  m_dNewCost = 0;
			  
		return dDealPrice
	}
getRegularCost() {
	const { itemListArray } = this.props.itemOnDealListPage
	let regularCost = parseFloat(itemListArray["IPCHPR"]);
	let lPrDiv = parseFloat(itemListArray["IPRDIV"]);
	regularCost = lPrDiv != 0 ? regularCost/lPrDiv : regularCost;
	return regularCost
}
render() {
	const { classes, itemsOnDealLabelsData, currentPage, currentOwnerName, filterCriteriaDetails,
		globalDateFormat, globalFilterOptions, pageFilterOptions, canUpdateComponent, columnDefination } = this.props;

	const { tabcards } = itemsOnDealLabelsData;
	const { loading, removeRecordFlag, rowData, itemListArray, valueData, newValueData } = this.props.itemOnDealListPage;
	return (
		<div>
			{this.props.detailButton && <DialogComponent
				className={classes.adjustDialog1}
				isOpen={this.props.detailButton}
				dialogTitle={this.props.getLabelValue(LABEL_ITEM_ON_DEAL)}
				cancelText={LABEL_CLOSE}
				nextText={LABEL_PREVIOUS}
				submitText={LABEL_NEXT}
				disableSubmit={!this.props.hasNext}
				disableNext={!this.props.hasPrevious}
				handleClose={e => this.props.handleClose()}
				handleCancel={e => this.props.handleClose(true)}
				handleSubmit={() => this.props.handlePreviousNext(LABEL_NEXT)}
				handleNext={() => this.props.handlePreviousNext(LABEL_PREVIOUS)}>
				<React.Fragment>
					{valueData && Object.keys(valueData) && Object.keys(valueData).length && itemListArray && Object.keys(itemListArray) && Object.keys(itemListArray).length && <div className={classes.notesForBlock}>
						<Box className={classes.childBlock}>
							<div className={classes.fieldLabel}>{this.props.getLabelValue(ITEM)}</div>
							<div className={classes.fieldValuesParent}>
								<Typography className={classes.fieldValue + ' ' + classes.idValue}>{valueData["DSITEM"]}</Typography>
								<Typography className={classes.fieldValue + ' ' + classes.idValue}>{itemListArray["INAME"]}</Typography>
							</div>
						</Box>
						<Box className={classes.childBlock}>
							<div className={classes.fieldLabel}>{this.props.getLabelValue(WAREHOUSE)}</div>
							<div className={classes.fieldValuesParent}>
								<Typography className={classes.fieldValue + ' ' + classes.idValue}>{valueData["DSWHSE"]}</Typography>
							</div>
						</Box>
						<Box className={classes.childBlock}>
							<div className={classes.fieldLabel}>{this.props.getLabelValue(VENDOR_ID)}</div>
							<Typography className={classes.fieldValue + ' ' + classes.idValue}>{valueData["DSVNDR"]}</Typography>
							<div className={classes.fieldLabel}>{this.props.getLabelValue(REGULAR_COST)}</div>
							<Typography className={classes.fieldValue + ' ' + classes.idValue}>{this.getRegularCost(itemListArray)}</Typography>
						</Box>
						<Box className={classes.childBlock}>
							<div className={classes.fieldLabel}>{this.props.getLabelValue(LABEL_DEAL)}</div>
							<Typography className={classes.fieldValue + ' ' + classes.idValue}>{valueData["DSDEAL"]}</Typography>
							<div className={classes.fieldLabel}>{this.props.getLabelValue(DEAL_COST)}</div>
							<Typography className={classes.fieldValue + ' ' + classes.idValue}>{this.getDealCost(itemListArray)}</Typography>
						</Box>
					</div>}
					<div className={classes.PageWrapper}>
						<div className={classes.pageContainerThirty + ' ' + classes.rightMargin}>
							<div className={classes.notesForBlock}>
								<Box mb={theme.spacing(0.5)} className={classes.notesForLabel}>
									{this.props.getLabelValue(RESTRICTIONS_CARD_KEY)}
								</Box>
								<div className={classes.simpleCardGroup}>
									{!loading && currentPage && tabcards && tabcards.length && tabcards.map(formCard => {
										if (formCard.cardkey == RESTRICTIONS_CARD_KEY && valueData && newValueData) {
											return <FormFieldsGenerator
												currentOwnerName={currentOwnerName}
												labelDisplayCharacters={20}
												valueDisplayCharacters={20}
												handleSubmitDataCallBack={() => { }}
												key={formCard.cardkey}
												fieldsArray={JSON.parse(JSON.stringify(formCard.cardfields))}
												valuesArray={this.getValueData(valueData, newValueData)}
												handleChangeValue={(key, val, field) => this.props.setValueData({ key, val, field })}
												enableAddButton={() => { }}
												globalDateFormat={globalDateFormat}
												filterCriteriaDetails={filterCriteriaDetails}
												pageFilterOptions={pageFilterOptions}
												globalFilterOptions={globalFilterOptions}
												columnDefs={columnDefination}
												currentPage={ITEM_ON_DEAL}
												canUpdateComponent={canUpdateComponent}
												noMassMaintenance={true}
											/>

										}
									})}
								</div>
							</div>
						</div>
						<div className={classes.pageContainerThirty + ' ' + classes.rightMargin}>
							<div className={classes.notesForBlock}>
								<Box mb={theme.spacing(0.5)} className={classes.notesForLabel}>
									{this.props.getLabelValue(BILL_BACK_CARD_KEY)}
								</Box>
								<div className={classes.simpleCardGroup}>
									{!loading && currentPage && tabcards && tabcards.length && tabcards.map(formCard => {
										if (formCard.cardkey == BILL_BACK_CARD_KEY && valueData && newValueData) {
											return <FormFieldsGenerator
												currentOwnerName={currentOwnerName}
												labelDisplayCharacters={20}
												valueDisplayCharacters={20}
												handleSubmitDataCallBack={() => { }}
												key={formCard.cardkey}
												fieldsArray={JSON.parse(JSON.stringify(formCard.cardfields))}
												valuesArray={this.getValueData(valueData, newValueData)}
												handleChangeValue={(key, val, field) => this.props.setValueData({ key, val, field })}
												enableAddButton={() => { }}
												globalDateFormat={globalDateFormat}
												filterCriteriaDetails={filterCriteriaDetails}
												pageFilterOptions={pageFilterOptions}
												globalFilterOptions={globalFilterOptions}
												columnDefs={columnDefination}
												currentPage={ITEM_ON_DEAL}
												canUpdateComponent={canUpdateComponent}
												noMassMaintenance={true}
											/>
										}
									})}
								</div>
							</div>
						</div>
						<div className={classes.pageContainerThirty}>
							<div className={classes.notesForBlock}>
								<Box mb={theme.spacing(0.5)} className={classes.notesForLabel}>
									{this.props.getLabelValue(SPECIAL_TERMS_CARD_KEY)}
								</Box>
								<div className={classes.simpleCardGroup}>
									{!loading && currentPage && tabcards && tabcards.length && tabcards.map(formCard => {
										if (formCard.cardkey == SPECIAL_TERMS_CARD_KEY && valueData && newValueData) {
											return <FormFieldsGenerator
												currentOwnerName={currentOwnerName}
												labelDisplayCharacters={20}
												valueDisplayCharacters={20}
												handleSubmitDataCallBack={() => { }}
												key={formCard.cardkey}
												fieldsArray={JSON.parse(JSON.stringify(formCard.cardfields))}
												valuesArray={this.getValueData(valueData, newValueData)}
												handleChangeValue={(key, val, field) => this.props.setValueData({ key, val, field })}
												enableAddButton={() => { }}
												globalDateFormat={globalDateFormat}
												filterCriteriaDetails={filterCriteriaDetails}
												pageFilterOptions={pageFilterOptions}
												globalFilterOptions={globalFilterOptions}
												columnDefs={columnDefination}
												currentPage={ITEM_ON_DEAL}
												canUpdateComponent={canUpdateComponent}
												noMassMaintenance={true}
											/>
										}
									})}
								</div>

							</div>
						</div>
					</div>
					{valueData && Object.keys(valueData) && Object.keys(valueData).length && <SKUDefaultAllowanceEmbeddedList
						filterCriteriaDetails={filterCriteriaDetails}
						globalDateFormat={globalDateFormat}
						globalFilterOptions={globalFilterOptions}
						pageFilterOptions={pageFilterOptions}
						currentPage={currentPage}
						currentOwnerName={currentOwnerName}
						itemOnDealListPage={this.props.itemOnDealListPage}
						setErrorsForApiFailure={(errorMessage) => this.setErrorsForApiFailure(errorMessage)}
						deal={this.props.deal}
						onAddRec={this.props.onAddRec}
						onRemoveRec={this.props.onRemoveRec}
						onUpdateRec={this.props.onUpdateRec}
						setUpdateRecordsFlag={this.props.setUpdateRecordsFlag}
						onSetDataValueChange={this.props.onSetDataValueChange}
						errorMessageLabels={this.props.errorMessageLabels}
						valueData={this.props.valueData}
						newValueData={this.props.newValueData}
						item={this.props.item}
					/>
					}
				</React.Fragment>
			</DialogComponent>}

		</div>
	)
}
}

export default withStyles(styles)(ItemOnDealDetail);
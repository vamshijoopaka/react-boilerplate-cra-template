import React from 'react';
import PropTypes from 'prop-types';
import HightchartsReact from 'highcharts-react-official';
import Highcharts from 'highcharts/highstock';
import MoreVertIcon from '@material-ui/icons/MoreVert';
import AdjustValuesPopup from './AdjustValuesPopup';
import ContextMenu from '../../../common/ContextMenu';
import {
  ACTIONS_CONTEXT_MENU,
  SIDE_BY_SIDE_ADJUSTMENTS_GRAPH,
  YEAR_TO_YEAR_ADJUSTMENTS_GRAPH,
} from './constants';
import { withStyles } from '@material-ui/core';
import Badge from '@material-ui/core/Badge';
import { groupBy } from 'lodash';
const style = () => ({

});

function onLabelClick(context) {
  function onClick() {
    context.onColumnSelect(this, {
      point: {
        category: this.textContent,
      },
    });
  }
  return onClick;
}

class AdjustmentGraph extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      openPointValues: false,
      values: {
        year: 0,
        period: 0,
        bookings: 0,
        lost: 0,
        shipped: 0,
        adjusted: 0,
        promotional: 0,
      },
      adjustMenuItems: JSON.parse(JSON.stringify(ACTIONS_CONTEXT_MENU)),
      isAdjustMenuOpen: false,
      editable: false,
      title: props.getLabelFromId('50759') || YEAR_TO_YEAR_ADJUSTMENTS_GRAPH,
    };
    this.chartRef = React.createRef();
  }

  componentDidMount() {
    const { canUpdateComponent, adjustmentGraphType, getLabelFromId } = this.props;
    let adjustMenuItems = this.state.adjustMenuItems;
    if (canUpdateComponent && Object.keys(canUpdateComponent) && Object.keys(canUpdateComponent).length) {
        adjustMenuItems.forEach((menuItem) => {
          let isDisable = canUpdateComponent.update && menuItem.isDisable === false ? false : true; //E3C30659-apply security restrictions in addition to field check 
          if (adjustmentGraphType) {
            if (adjustmentGraphType === 'yearToYearAdjustment') {
              if (menuItem.key === 'yearToYearAdjustment')
                isDisable = true;
              if (menuItem.key === 'sideBySideAdjustment')
                isDisable = false;
            }
            if (adjustmentGraphType === 'sideBySideAdjustment') {
              if (menuItem.key === 'yearToYearAdjustment')
                isDisable = false;
              if (menuItem.key === 'sideBySideAdjustment')
                isDisable = true;
              this.setState({
                title: getLabelFromId('50760') || SIDE_BY_SIDE_ADJUSTMENTS_GRAPH,
                isSideBySide: true
              });
            }
          }
          menuItem.isDisable = isDisable;
      });
      this.setState({ adjustMenuItems });
    }
    if (
      this.chartRef.current &&
      this.chartRef.current.chart &&
      this.chartRef.current.chart.xAxis &&
      this.chartRef.current.chart.xAxis.length &&
      this.chartRef.current.chart.xAxis[0].labelGroup
    ) {
      const labels = this.chartRef.current.chart.xAxis[0].labelGroup.element.childNodes;
      // const { onColumnClick } = this;
      for (let i = 0; i < labels.length; i += 1) {
        const label = labels[i];
        label.onclick = onLabelClick(this);
      }
    }
  }

  componentDidUpdate = () => {
    if (
      this.chartRef.current &&
      this.chartRef.current.chart &&
      this.chartRef.current.chart.xAxis &&
      this.chartRef.current.chart.xAxis.length &&
      this.chartRef.current.chart.xAxis[0].labelGroup
    ) {
      const labels = this.chartRef.current.chart.xAxis[0].labelGroup.element.childNodes;
      // const { onColumnClick } = this;
      for (let i = 0; i < labels.length; i += 1) {
        const label = labels[i];
        label.onclick = onLabelClick(this);
      }
    }
  };

  onClose = () => {
    this.setState({
      openPointValues: false,
    });
  };

  onColumnSelect = (sender, event) => {
    const { categories, series, adjustmentData, isMonthly } = this.props;
    const categorySelected = event.point.category;
    let selectedIndex = -1;
    for (let i = 0; i < categories.length; i += 1) {
      if (categorySelected === categories[i]) {
        selectedIndex = i;
        break;
      }
    }
    const values = {
      year: 0,
      period: 0,
      bookings: 0,
      lost: 0,
      shipped: 0,
      adjusted: 0,
      promotional: 0,
      category: categorySelected,
    };
    const [month, day, year] = categorySelected.split('/');
    values.year = year;
    let maxIndex = 52;
    if (isMonthly) {
      maxIndex = 12;
    }
    values.period = (selectedIndex + 1) % maxIndex;
    if (values.period === 0){
      values.period = maxIndex;
    }
    if (this.state.isSideBySide) {
      values.period = Math.ceil((selectedIndex + 1)/4);
    }
    if (values.period === 1 && month == '12') {
      values.year = String(+year + 1);
    }
    values.adjusted = adjustmentData[selectedIndex];
    series.forEach(s => {
      switch (s.key) {
        case 'Lost':
          if (s.data[selectedIndex]) {
            values.lost = parseInt(s.data[selectedIndex], 10);
          } else {
            values.lost = 0;
          }
          break;
        case 'Shipped':
          if (s.data[selectedIndex]) {
            values.shipped = parseInt(s.data[selectedIndex], 10);
          } else {
            values.shipped = 0;
          }
          break;
        case 'Bookings':
          if (s.data[selectedIndex]) {
            values.bookings = parseInt(s.data[selectedIndex], 10);
          } else {
            values.bookings = 0;
          }
          break;
        case 'Promo':
          if (s.data[selectedIndex]) {
            values.promotional = parseInt(s.data[selectedIndex], 10);
          } else {
            values.promotional = 0;
          }
          break;
        default:
          break;
      }
    });
    this.setState({ openPointValues: true, values });
  };

  onChange = (name, value) => {
    const { values } = this.state;
    let newValue = parseInt(value, 10);
    if (isNaN(newValue)) {
      newValue = 0;
    }
    values[name] = newValue;
    this.setState({
      values,
    });
  };

  onSubmit = values => {
    const { category, year, period, lost, promotional, shipped, adjusted, isMonthly } = values;
    this.props.updateAdjustments({
      category,
      year,
      period,
      lost,
      promotional,
      shipped,
      adjusted,
      isMonthly,
    });
    if (this.props.onChange) {
      this.props.onChange();
    }
  };

  setIsOpenContextMenu = (evnt = false, type = '') => {
    if (!this.props.show3Dots) return;
    this.setState({
      isAdjustMenuOpen: evnt ? true : false,
      [`menuRef${type}`]: evnt.currentTarget ? evnt.currentTarget : evnt,
    });
  };

  handleItemHeaderActionItemSelection = value => {
    if (!this.props.show3Dots) return;

    const { getLabelFromId } = this.props;
    let disableOptions = this.state.adjustMenuItems.map(
      menuItem => menuItem.isDisable,
    );
    switch (value) {
      case 'adjust':
        disableOptions = this.state.adjustMenuItems.map(menuItem => {
          if (menuItem.key === 'adjust') {
            return true;
          }
          if (menuItem.key === 'applyEdits' || menuItem.key === 'cancelEdits') {
            return false;
          }
          return menuItem.isDisable;
        });
        this.setState({
          editable: true,
        });
        this.props.setStoreKeyValue('adjustmentsInProgress', true);
        break;
      case 'applyEdits':
        disableOptions = this.state.adjustMenuItems.map(menuItem => {
          if (menuItem.key === 'applyEdits' || menuItem.key === 'cancelEdits') {
            return true;
          }
          if (menuItem.key === 'adjust') {
            return false;
          }
          return menuItem.isDisable;
        });
        this.setState({
          editable: false,
        });
        this.applyAdjustments();
        break;
      case 'cancelEdits':
        disableOptions = this.state.adjustMenuItems.map(menuItem => {
          if (menuItem.key === 'applyEdits' || menuItem.key === 'cancelEdits') {
            return true;
          }
          if (menuItem.key === 'adjust') {
            return false;
          }
          return menuItem.isDisable;
        });
        this.setState({
          editable: false,
        });
        if (this.props.cancelAdjustments) {
          this.props.cancelAdjustments()
        }
        this.props.setStoreKeyValue('adjustmentsInProgress', false);
        break;
      case 'sideBySideAdjustment':
        disableOptions = this.state.adjustMenuItems.map(menuItem => {
          if (menuItem.key === 'sideBySideAdjustment') {
            return true;
          }
          if (menuItem.key === 'yearToYearAdjustment') {
            return false;
          }
          return menuItem.isDisable;
        });
        this.props.setSideBySideAdjustment();
        this.props.setStoreKeyValue('adjustmentGraphType', 'sideBySideAdjustment');
        this.setState({
          title: getLabelFromId('50760') || SIDE_BY_SIDE_ADJUSTMENTS_GRAPH,
          isSideBySide: true
        });
        break;
      case 'yearToYearAdjustment':
        disableOptions = this.state.adjustMenuItems.map(menuItem => {
          if (menuItem.key === 'sideBySideAdjustment') {
            return false;
          }
          if (menuItem.key === 'yearToYearAdjustment') {
            return true;
          }
          return menuItem.isDisable;
        });
        this.props.setYearToYearAdjustment();
        this.setState({
          title: getLabelFromId('50759') || YEAR_TO_YEAR_ADJUSTMENTS_GRAPH,
          isSideBySide: false
        });
        this.props.setStoreKeyValue('adjustmentGraphType', 'yearToYearAdjustment');
        break;
      default:
        break;
    }
    this.setState(prevState => {
      const { adjustMenuItems } = prevState;
      adjustMenuItems.forEach((menuItem, index) => {
        menuItem.isDisable = disableOptions[index];
      });
      return {
        adjustMenuItems,
        isAdjustMenuOpen: false,
      };
    });
  };
  applyAdjustments = () => {
    const { years, valueData: { ICOMP, IWHSE, IITEM } } = this.props;
    let finalObj = {
      'shipped': [],
      'promo': [],
      'lost': [],
      'bookings': [],
      'adjusted': [],
    };
    let graphType = {
      'shipped': {
        HARECD: '6315',
        HATYPE: 'G'
      },
      'promo': {
        HARECD: '6314',
        HATYPE: 'F'
      },
      'lost': {
        HARECD: '6316',
        HATYPE: 'H'
      },
      'bookings': {
        HARECD: '6311',
        HATYPE: 'B'
      },
      'adjusted': {
        HARECD: '6313',
        HATYPE: 'E'
      },
    }
    Object.keys(graphType).forEach(key => {
      for (let yIndex = 0; yIndex < years.length; yIndex++) {
        let weekObj = {
          "HARECD": graphType[key].HARECD,
          "HASTAT": "",
          "HACOMP": ICOMP,
          "HAWHSE": IWHSE,
          "HAITEM": IITEM,
          "HAYEAR": years[yIndex],
          "HATYPE": graphType[key].HATYPE,
          "HAVNDR": "",
        };
        let weeklyData = this.getUpdatedValuesForAPI(key, yIndex);
        if (weeklyData?.length) {
          const datawithHSTAT = weeklyData.map(ele => ({
            ...weekObj,
            ...ele,
            HASTAT: this.getStat(key, years[yIndex], ele.HAWEEK)
          }));
          finalObj[key] = finalObj[key].concat(datawithHSTAT);
        }
      }
    });
    this.props.applyAdjustments(finalObj);
  }
  getUpdatedValuesForAPI = (type, yIndex) => {
    const { years, adjustmentData, series, isMonthly } = this.props;
    const { isSideBySide } = this.state;
    let data = false;
    switch (type) {
      case 'shipped': {
        data = series.find(s => s.key === 'Shipped')?.data || []; break;
      }
      case 'promo': {
        data = series.find(s => s.key === 'Promo')?.data || []; break;
      }
      case 'bookings': {
        data = series.find(s => s.key === 'Bookings')?.data || []; break;
      }
      case 'lost': {
        data = series.find(s => s.key === 'Lost')?.data || []; break;
      }
      case 'adjusted': {
        data = adjustmentData || []; break;
      }
    }
    let updated = [{ 'HAWEEK': '1' }, { 'HAWEEK': '2' }, { 'HAWEEK': '3' }, { 'HAWEEK': '4' },]
    if (isMonthly) {
      updated = [{ 'HAWEEK': '0'}];
    }
    if (data) {
      if (isSideBySide) {
        // for (let i = 0, j = 0; i <= 13, j < 208; i++, j += 16) {
        //   let key = `HA7` + `${i + 1}`.padStart(2, '0');
        //   updated[0][key] = "" + (data[yIndex + (i * 4) + j] || "0");
        //   updated[1][key] = "" + (data[yIndex + (i + 1) * 4 + j] || "0");
        //   updated[2][key] = "" + (data[yIndex + (i + 2) * 4 + j] || "0");
        //   updated[3][key] = "" + (data[yIndex + (i + 3) * 4 + j] || "0");
        // }
        if (isMonthly) {
          for (let i = 1, j=0; i <=12 ; i++) {
            let key = `HA7` + `${i}`.padStart(2, '0');
            updated[0][key] = String(data[yIndex + j] || '0');
            j += 4;
          }
        }
        else
          for (let i = 1, j = 0; i <= 13; i++) {
            let key = `HA7` + `${i}`.padStart(2, '0');
            updated[0][key] = String(data[yIndex + j] || '0');
            j += 4;
            updated[1][key] = String(data[yIndex + j] || '0');
            j += 4;
            updated[2][key] = String(data[yIndex + j] || '0');
            j += 4;
            updated[3][key] = String(data[yIndex + j] || '0');
            j += 4;
          }
      }
      else {
        if (isMonthly) {
          let startIndex = yIndex * 12, endIndex = startIndex + 11;
          for (let i = startIndex, j = 1; i <= endIndex, j <= 12; i++, j++) {
            let key = `HA7` + `${j}`.padStart(2, '0');
            updated[0][key] = "" + (data[i] || "0");
          }
        }
        else {
          let startIndex = yIndex * 52, endIndex = startIndex + 51;
          for (let i = startIndex, j = 1; i <= endIndex, j <= 13; i += 4, j++) {
            let key = `HA7` + `${j}`.padStart(2, '0');
            updated[0][key] = "" + (data[i] || "0");
            updated[1][key] = "" + (data[i + 1] || "0");
            updated[2][key] = "" + (data[i + 2] || "0");
            updated[3][key] = "" + (data[i + 3] || "0");
          }
        }
      }
    }
    return this.filterUnmodified(updated, years[yIndex], type);
  }
  filterUnmodified = (updatedData, year, type) => {
    const { adjustmentGraphAPIData } = this.props;
    if (!updatedData || !year) return updatedData;
    let yearData;
    switch(type) {
      case 'shipped': {
        yearData = groupBy(adjustmentGraphAPIData.shippedData, 'HAYEAR')[year];break;
      }
      case 'promo': {
        yearData = groupBy(adjustmentGraphAPIData.promoData, 'HAYEAR')[year];break;
      }
      case 'bookings': {
        yearData = groupBy(adjustmentGraphAPIData.bookingsData, 'HAYEAR')[year];break;
      }
      case 'lost': {
        yearData = groupBy(adjustmentGraphAPIData.lostData, 'HAYEAR')[year];break;
      }
      case 'adjusted': {
        yearData = groupBy(adjustmentGraphAPIData.adjustmentValues, 'HAYEAR')[year];break;
      }
    }
    if (!yearData) return updatedData;

    const filteredData = updatedData.map(ele => {
      let weekData = yearData.find(week => week.HAWEEK === ele.HAWEEK);
      if (!weekData) return ele;
      let isNotChanged = Array(13).fill(0).every((z, i) => {
        let key = `HA7` + `${i+1}`.padStart(2, '0');
          return ele[key] == weekData[key];
      })
      if (isNotChanged) return false;
      return ele;
    }).filter(Boolean);

    return filteredData;
  }
  getStat = (type, year, week) => {
    const { adjustmentGraphAPIData } = this.props;
    let found = false;
    const compareFunc = (ele) => ele.HAWEEK === week && ele.HAYEAR === year
    switch (type) {
      case 'shipped': {
        found = adjustmentGraphAPIData.shippedData.find?.(compareFunc); break;
      }
      case 'promo': {
        found = adjustmentGraphAPIData.promoData.find?.(compareFunc); break;
      }
      case 'lost': {
        found = adjustmentGraphAPIData.lostData.find?.(compareFunc); break;
      }
      case 'bookings': {
        found = adjustmentGraphAPIData.bookingsData.find?.(compareFunc); break;
      }
      case 'lost': {
        found = adjustmentGraphAPIData.lostData.find?.(compareFunc); break;
      }
      case 'adjusted': {
        found = adjustmentGraphAPIData.adjustmentValues.find?.(compareFunc); break;
      }
    }
    return found ? 'C' : 'A';
  }
  render() {
    const {
      classes,
      series,
      categories,
      scrollable,
      years,
      hideLegends,
      show3Dots,
      adjustmentData,
      adjustmentsInProgress,
      getLabelFromId,
      isMonthly,
    } = this.props;
    const { onColumnSelect } = this;
    const legendIndex = {
      'Shipped': 1,
      'Promo': 2,
      'Lost': 3,
      'Bookings': 4,
    }

    let seriesWithoutType = series
      .filter(
        s => s.key !== 'Acceptable Sales' && s.key !== 'Demand Forecast',
      )
      .map(s => {
        const { type, ...other } = s;
        s.name = getLabelFromId(s.displayId) || s.name;
        return {
          ...other,
          legendIndex: legendIndex[s.key],
        };
      });
      seriesWithoutType = seriesWithoutType.sort((a, b) => {
        return legendIndex[b.key] - legendIndex[a.key]
      })
      const promoData = seriesWithoutType.find(s => s.key === 'Promo')?.data;
      const shippedSeries = seriesWithoutType.find(s => s.key === 'Shipped');
      if (promoData && shippedSeries?.data) {
        shippedSeries.data = shippedSeries.data.map((shipped, i) => {
          const promo = promoData[i];
          return shipped - promo > 0 ? shipped - promo : 0;
        })
      }

    const options = {
      chart: {
        type: 'column',
        scrollablePlotArea: {
          minWidth: scrollable ? isMonthly ? 6000 : 12000 : '100%',
          scrollPositionX: 1,
        },
        scrollbar: {
          enabled: scrollable,
        },
      },
      title: {
        text: this.state.title,
      },
      xAxis: {
        categories,
      },
      yAxis: {
        min: 0,
        title: {
          text: '',
        },
        stackLabels: {
          enabled: true,
          style: {
            fontWeight: 'bold',
            color:
              // theme
              (Highcharts.defaultOptions.title.style &&
                Highcharts.defaultOptions.title.style.color) ||
              'gray',
          },
        },
      },
      credits: {
        enabled: false,
      },
      legend: {
        enabled: !hideLegends,
        layout: 'vertical',
        align: 'right',
        verticalAlign: 'middle',
      },
      tooltip: {
        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
        pointFormat:
          '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
          '<td style="padding:0"><b>{point.y}</b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true,
      },
      plotOptions: {
        column: {
          stacking: 'normal',
          dataLabels: {
            enabled: false,
          },
          events: {
            click(event) {
              onColumnSelect(this, event);
            },
          },
        },
      },
      series: seriesWithoutType,
    };
    return (
      <React.Fragment>
        <div
          onMouseEnter={(event) => this.setIsOpenContextMenu(event,'3dots')}
          onMouseLeave={(event) => this.setIsOpenContextMenu(false,'3dots')}
          style={{
            width: 10,
            height: 10,
            float: 'right',
            display: show3Dots ? 'block' : 'none',
          }}
        >
          <Badge color="secondary" variant="dot" invisible={!adjustmentsInProgress}>
            <MoreVertIcon color="primary" className="cPointer"></MoreVertIcon>
          </Badge>
          <ContextMenu
            className={classes.menuButton}
            menuList={this.state.adjustMenuItems}
            isOpen={this.state.isAdjustMenuOpen}
            menuRef={this.state.menuRef3dots}
            handleItemSelection={val =>
              this.handleItemHeaderActionItemSelection(val)
            }
            handleMenuClose={val => this.setIsOpenContextMenu(val,'3dots')}
          />
        </div>
        <div style={{ marginTop: 20 }}>
          <HightchartsReact
            ref={this.chartRef}
            highcharts={Highcharts}
            options={options}
          />
        </div>
        {this.state.openPointValues ? (
          <AdjustValuesPopup
            open={this.state.openPointValues}
            values={this.state.values}
            onClose={this.onClose}
            onSubmit={this.onSubmit}
            editable={this.state.editable}
            onChange={this.onChange}
            years={years}
            categories={categories}
            series={series}
            adjustmentData={adjustmentData}
            isSideBySide={this.state.isSideBySide}
            isMonthly={this.props.isMonthly}
            errorMessageLabels={this.props.errorMessageLabels}
            getLabelFromId={getLabelFromId}
            globalNumberFormat={this.props.globalNumberFormat}
            globalNumberSeparator={this.props.globalNumberSeparator}
            globalDecimalSeparator={this.props.globalDecimalSeparator}
          />
        ) : null}
      </React.Fragment>
    );
  }
}

AdjustmentGraph.propTypes = {
  classes: PropTypes.object,
  categories: PropTypes.array,
  series: PropTypes.array,
  editable: PropTypes.bool,
  scrollable: PropTypes.bool,
  hideLegends: PropTypes.bool,
  updateAdjustments: PropTypes.func,
  onChange: PropTypes.func,
  years: PropTypes.array,
  setSideBySideAdjustment: PropTypes.func,
  setYearToYearAdjustment: PropTypes.func,
  show3Dots: PropTypes.bool,
};

export default withStyles(style)(AdjustmentGraph);

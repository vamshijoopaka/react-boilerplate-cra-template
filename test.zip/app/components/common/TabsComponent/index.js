import React from 'react';
import './styles.scss';
import {
    getPathname,
    getPropertiesPathName,
    getValuesFromLocalStorage,
    capitalizeFirstLetter,
    capitalizeAllLetters
} from '../../../utils/util';
import {
    hasLocalStorageValues
} from 'utils/filterData';
import {
    MAX_PARENT_TAB_CHARACTERS_SIZE
} from 'components/common/constants';
import ShowHidden from '../../../images/show_all.png';
import CloseAll from '../../../images/close_all_tabs.png';
import { IconButton, Box } from '@material-ui/core';
import CloseImage from '../../../images/close_icon.png';
import MoreVertIcon from '@material-ui/icons/MoreVert';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';

import { menuContext } from '../../../constants/contextMenuJson';
import ContextMenu from 'components/common/ContextMenu';

import {
    TEXT_OK, TEXT_CANCEL, CLOSE_ALL,
    DO_YOU_WANT_TO_CLOSE_ALL
} from 'components/common/constants';
import ConfirmationDialog from 'components/common/ConfirmationDialog';



import DownArrowImage from '-!react-svg-loader!../../../images/down_single_arrow.svg';
import TabClear from '-!react-svg-loader!../../../images/tab_clear.svg';
import CustomizedTooltip from '../CustomizedTooltip';
import FormattedMessageComponent from '../FormattedMessageComponent';
import { isEqual } from 'lodash';



class TabsComponent extends React.Component {
    constructor(props) {
        super(props);
        const contextMenuList = JSON.parse(JSON.stringify(menuContext));
        if (props.tabs.length === 1 && props.tabs[0].items.length === 1) {
            contextMenuList[0].isDisable = true;
        }
        this.state = {
            selectedTabIndex: 0,
            isShowMoreTabs: false,
            isOpenContextMenu: false,
            menuRef: false,
            popupComponent: false,
            contextMenuList, // JSON.parse(JSON.stringify(menuContext)),
            showCloseAllConfirmation: false,
            keyValueLength: {}
        };
        this.onTabSelect = this.onTabSelect.bind(this);
        this.getActiveBreadcrumInTab = this.getActiveBreadcrumInTab.bind(this);
        this.getLastVisibleTab = this.getLastVisibleTab.bind(this);
        this.getLastVisibleTabIndex = this.getLastVisibleTabIndex.bind(this);
        this.updateHistory = this.updateHistory.bind(this);
        this.showMoreTabs = this.showMoreTabs.bind(this);
        this.closeMoreTabs = this.closeMoreTabs.bind(this);
        this.removeCutDownParentTab = this.removeCutDownParentTab.bind(this);
        this.handleClick = this.handleClick.bind(this);
        this.getDisplayName = this.getDisplayName.bind(this);
        this.isShowTooltip = this.isShowTooltip.bind(this);
        this.setIsOpenContextMenu = this.setIsOpenContextMenu.bind(this);
        this.handleItemSelection = this.handleItemSelection.bind(this);
        this.renderSelectedMenuDialog = this.renderSelectedMenuDialog.bind(this);
        this.getLabelValue = this.getLabelValue.bind(this);
        this.findStrLen = this.findStrLen.bind(this);
    }

    componentDidUpdate = prevProps => {
        const { tabs } = this.props;
        if (tabs && !isEqual(tabs, prevProps.tabs)) {
            if (tabs.length === 1 && tabs[0].items.length === 1) {
                this.setState(prevState => {
                    const { contextMenuList } = prevState;
                    contextMenuList[0].isDisable = true;
                    return {
                        contextMenuList,
                    };
                });
            } else {
                this.setState(prevState => {
                    const { contextMenuList } = prevState;
                    contextMenuList[0].isDisable = false;
                    return {
                        contextMenuList,
                    };
                });
            }
        }
    };

    getLabelValue(key) {
        return <FormattedMessageComponent id={key} strLen={this.findStrLen}></FormattedMessageComponent>;
    }

    findStrLen(key, len, str) {
        let obj = this.state.keyValueLength;
        obj[key] = {
            length: len,
            str: str
        };
        this.setState({ keyValueLength: JSON.parse(JSON.stringify(obj)) });
    }

    removeCutDownParentTab(e, tab, index) {
        e.stopPropagation();
        e.preventDefault();
        this.props.removeParentCutdownTab(tab, index);
    }

    showMoreTabs() {
        this.setState({ isShowMoreTabs: !this.state.isShowMoreTabs })
    }

    closeMoreTabs(tab, index) {
        this.setState({ isShowMoreTabs: false });
        this.props.onClickCutDownTab(tab, index);
    }

    handleClick(e) {
        if (this.node && this.node.contains(e.target)) {
            return;
        }
        this.setState({ isShowMoreTabs: false });
    }

    componentWillMount() {
        document.addEventListener('mousedown', this.handleClick, false)
    }

    componentWillUnmount() {
        document.removeEventListener('mousedown', this.handleClick, false)
    }

    getDisplayName(displayName, id) {
        let name = '';
        if (displayName != null) {
            name = this.getLabelValue(displayName);
        }
        let keyValueName = this.state.keyValueLength[displayName];
        let maxchars = MAX_PARENT_TAB_CHARACTERS_SIZE;
        const { activeTabId } = this.props;
        if (keyValueName && keyValueName.length && keyValueName.length > maxchars && id != activeTabId) {
            return keyValueName.str
            // Show ... if exceed max length
            // let values = keyValueName.str.split('');
            // let firstStr = values.splice(0, maxchars).join('');
            // return firstStr + '...';
        }
        return name;
    }

    isShowTooltip(name) {
        let maxchars = MAX_PARENT_TAB_CHARACTERS_SIZE;
        if (name && name.length && name.length > maxchars) {
            return true;
        }
        return false;
    }

    // To select tab
    onTabSelect(tab, index, e) {
        if (!hasLocalStorageValues()) {
            this.props.setTabsData([], -1);
            return;
        }
        if (this.props.activeTabId !== tab.id)
            this.props.clearUserErrorMessage();
        this.setState({ selectedTabIndex: index });
        const activeItem = this.getActiveBreadcrumInTab(this.props.tabs, index, tab.selectedBreadcrumbId);
        let pathname = '', activeName = activeItem.name ? activeItem.name : tab.type;
        if (activeItem.childType) {
            pathname = getPropertiesPathName(activeName);
        } else {
            pathname = getPathname(activeName);
        }
        const historyObj = {
            pathname: pathname,
            search: `?tab_id=${tab.tab_id}&item_id=${tab.selectedBreadcrumbId}`
        };
        this.props.setIsShowContextMenu(false);
        this.props.history.push(historyObj);
        this.props.setSelectedTabOnNavigation(tab.tab_id, tab.selectedBreadcrumbId);
    }

    componentDidUpdate(prevProps) {
        if (prevProps.tabs.length !== this.props.tabs.length) {
            this.setState({ selectedTabIndex: this.props.tabs.length - 1 });
        }
    }
    // To close tab and update history
    closeTab = (event, tab, index) => {
        const lastVisibleIndex = this.getLastVisibleTabIndex(this.props.tabs.length - 1);
        event.stopPropagation();
        if (this.props.tabs.filter(tab => tab.show === true).length === 1) {  // tab component with one tab and closing that
            this.props.updateSelectedItem('');
            if (this.props.activeTabId === tab.tab_id) {
                this.props.history.push({ pathname: '/Dashboard' });
            }
        }
        else if (index === lastVisibleIndex) { //closing last tab
            this.updateHistory(tab, lastVisibleIndex - 1);
        } else {
            this.updateHistory(tab, lastVisibleIndex);
        }
        this.props.closeTab(tab.tab_id, index);
    }

    // get active breadcrum item from tabs
    getActiveBreadcrumInTab = (tabs, index, breadcrumbId) => {
        for (let i = 0; i < tabs[index].items.length; i++) {
            if (tabs[index].items[i].id === breadcrumbId) {
                return tabs[index].items[i];
            }
        }
        return {}
    }

    // Get last visible tab type
    getLastVisibleTab = (index) => {
        for (let i = index; this.props.tabs.length && (i > -1); i--) {
            if (this.props.tabs[i].show === true) {
                return this.props.tabs[i].type;
            }
        }
        return null;
    }

    // Get last visible tab index from index
    getLastVisibleTabIndex = (index) => {
        for (let i = index; this.props.tabs.length && (i > -1); i--) {
            if (this.props.tabs[i].show === true) {
                return i;
            }
        }
        return -1;
    }
    // To update history
    updateHistory = (tab, lastVisibleIndex) => {
        const { tabs, activeTabId, history } = this.props;
        const tabData = tabs[this.getLastVisibleTabIndex(lastVisibleIndex)];
        if (activeTabId === tab.tab_id) {
            const activeItem = this.getActiveBreadcrumInTab(tabs, lastVisibleIndex, tabData.selectedBreadcrumbId);
            let pathname = '', activeName = activeItem.name ? activeItem.name : tab.type;
            if (activeItem.childType) {
                pathname = getPropertiesPathName(activeName);
            } else {
                pathname = getPathname(activeName);
            }
            const historyObj = {
                pathname: pathname,
                search: `?tab_id=${tabData.tab_id}&item_id=${tabData.selectedBreadcrumbId}`
            };
            history.push(historyObj);
        }
        this.props.updateSelectedItem(this.getLastVisibleTab(lastVisibleIndex));
    }

    // Close or open context menu
    setIsOpenContextMenu(val) {
        this.setState({ isOpenContextMenu: Boolean(val) });
        this.setState({ menuRef: val.currentTarget ? val.currentTarget : val });
    }

    // Handle menu selection
    handleItemSelection(component) {
        this.setState({ popupComponent: component });
        this.setState({ isOpenContextMenu: false });
        this.setState({ menuRef: null });
    }

    renderSelectedMenuDialog(component) {
        const { tabs, history } = this.props;
        if (!component) {
            return;
        }
        switch (component) {
            case 'closeAllTabs':
                this.clearComponent();
                this.setState({ showCloseAllConfirmation: true });
                return null;
        }
    }

    handleClose = (flag) => {
        this.setState({ showCloseAllConfirmation: false });
        if (flag) {
            this.props.updateSelectedItem('');
            this.props.closeAllTabs();
        }
    }

    clearComponent = () => {
        this.setState({ popupComponent: null });
    }

    render() {
        const { tabs, cutDownTabs, onClickCutDownTab, closeAllTabs, errorMessages } = this.props;
        return (
            <div className='display__flex'>
                <div className='tabs' id={'tabs_wrapper'}>
                    <div className='display-flex' id={'tabs_rendered'}>
                        {
                            tabs && tabs.length && tabs.map((tab, index) => {
                                return (
                                    <CustomizedTooltip title={((tab.tab_id != this.props.activeTabId) && this.isShowTooltip(tab.type)) ? capitalizeAllLetters(tab.type) : ''}>
                                        <div
                                            key={index}
                                            onClick={(e) => this.onTabSelect(tab, index, e)}
                                            className={[
                                                tab.tab_id === this.props.activeTabId
                                                    ? 'tab__selected' : 'tab__unselected',
                                                tab.show ? '' : 'hide__tab',
                                                tab.type.toLowerCase() == 'todo' ? 'initial__tab' : ''
                                            ].join(' ')}>
                                            <div>{' '}{this.getDisplayName(tab.displayName, tab.tab_id)}</div>
                                            <TabClear className={tab.type.toLowerCase() == 'todo' ? 'tab__close__hide' : 'tab__close'} onClick={(event) => this.closeTab(event, tab, index)} />
                                            {/* <img className={tab.type.toLowerCase() == 'todo' ? 'tab__close__hide' : 'tab__close'} src={CloseImage} /> */}
                                        </div >
                                    </CustomizedTooltip>
                                );
                            })
                        }
                    </div>
                </div>
                {
                    (
                        (cutDownTabs && cutDownTabs.length) ?
                            <div className="cd__tabs" ref={node => this.node = node}>
                                <div onClick={this.showMoreTabs} className={'more_tabs'}>
                                    <div className={'tab_cutdown_length'}>+{cutDownTabs.length}</div>
                                    <div>
                                        <ExpandMoreIcon className="cd__tabs_icon" />
                                        {/* <img className={"cd__tabs_icon"} src={ShowHidden} alt="show hidden" /> */}
                                    </div>
                                </div>
                                {
                                    (this.state.isShowMoreTabs) ?
                                        <div className="cd__display__tabs">
                                            <div className={"cd__display__tabs__wrapper"}>
                                                {
                                                    (cutDownTabs.map((tab, index) => {
                                                        return (
                                                            <div className={'hidden__children'}>
                                                                <div className={'cd_display_flex'} onClick={(e) => this.closeMoreTabs(tab, index)}>
                                                                    {this.getLabelValue(tab.displayName)}
                                                                    <TabClear className="tab__close" onClick={(e) => this.removeCutDownParentTab(e, tab, index)} />
                                                                </div>
                                                            </div>
                                                        )
                                                    }))
                                                }
                                            </div>
                                        </div> : null
                                }
                            </div> : null
                    )
                }
                <div onMouseEnter={(event) => this.setIsOpenContextMenu(event)}
                    onMouseLeave={(event) => this.setIsOpenContextMenu(false)}>
                    <MoreVertIcon
                        className={'more_vertical_icon'}></MoreVertIcon>

                    <ContextMenu menuList={this.state.contextMenuList} isOpen={this.state.isOpenContextMenu}
                        handleItemSelection={(val) => this.handleItemSelection(val)}
                        handleMenuClose={(val) => this.setIsOpenContextMenu(val)} menuRef={this.state.menuRef}></ContextMenu>
                </div>

                <Box>
                    {this.state.popupComponent && this.renderSelectedMenuDialog(this.state.popupComponent)}
                </Box>
                <ConfirmationDialog
                    isOpen={this.state.showCloseAllConfirmation}
                    dialogTitle={CLOSE_ALL}
                    cancelText={TEXT_CANCEL}
                    submitText={TEXT_OK}
                    handleClose={e => this.handleClose(false)}
                    handleCancel={e => this.handleClose(false)}
                    handleSubmit={e => this.handleClose(true)}>
                    {/*E3C-31877:Ajit <div>
                        {DO_YOU_WANT_TO_CLOSE_ALL}
                    </div> */}
                    <div>
                        {errorMessages ? errorMessages['E19308']?.MTEXT.trim() : 'Confirmation'}
                    </div>
                </ConfirmationDialog>

            </div>
        )
    }
}

export default TabsComponent;
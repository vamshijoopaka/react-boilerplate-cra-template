import React, { Component } from 'react';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import { withStyles, Box } from '@material-ui/core';
import DialogComponent from 'components/common/DialogComponent';
import theme from 'jda-gcp-theme';
import FormFieldsGenerator from 'components/common/FormFieldsGenerator';
import EmbeddedList from 'containers/common/EmbeddedList';
import Spinner from 'components/Common/Spinner';
import FieldInput from 'components/common/Form/FieldInput';
import {
    TEXT_COPY,
    COPY_CONTROLS, MENU_ITEMS, FILTER_OBJ, ITEMCOPY,
    ITEM_COPY_DS
} from "./constants";
import { TEXT_CANCEL, TEXT_ALERT, TEXT_OK } from 'components/common/constants';
import { INITIAL_PAGE_PROPS } from 'components/common/constants';
import { getListPredecessor } from 'utils/util';
import reducer from './reducer';
import saga from './saga';
import ConfirmationDialog from 'components/common/ConfirmationDialog';
import {
    rowDataSelector,
    columnDefsSelector,
    loadingSelector,
    columnFlagSelector,
    pagePropsSelector,
    filterPropsSelector,
    columnInfoSelector,
    isAPIProgressSelector,
    totalCountSelector,
    moreRecordsSelector,
    apiCallCountSelector,
    updateColumnsListSelector,
    errorMessageLabels,
    makeSelectItemCopy
} from './selector';
import {
    getItemCopyList,
    setApiCallCount,
    onSetPageProps,
    getItemCopyColumnDefs,
    setFilterValues,
    setColumnDefsLoaded,
    updateShowHide,
    resetStateData,
    resetDefault,
    getItemsList,
    setLabelDataFlags
} from './action';
import { VENDORS_LIST_PAGE, ITEMS_LIST_PAGE } from '../../../common/constants';

const styles = () => ({
    adjustDialog1: {
        maxHeight: '93vh',
        '& .MuiDialogContent-root': {
            padding: '12px'
        },
    },
    notesForBlock: {
        display: 'flex',
        flexDirection: 'column',
        marginTop: '25px',
        border: '1px solid var(--divider-line)',
        padding: '10px 10px 0 10px',
        position: 'relative'
    },
    notesForLabel: {
        position: 'absolute',
        top: '-7px',
        left: '10px',
        background: 'var(--background-content)',
        padding: '0 8px',
    },
    adjustCardFieldsInline: {
        display: 'grid !important',
        width: '100%',
        gridTemplateColumns: 'auto auto auto',
    },
    fieldLabel: {
        color: 'var(--header-label-color)',
        padding: '0 0px 8px 0',
        width: '22ch',
    },
    childBlock: {
        display: 'flex',
        padding: '6px'
    },
    adjustShowDetail: {
        display: 'flex',
        bottom: '10px',
        left: '22px',
        position: 'fixed'
    },
    fieldValue: {
        color: 'var(--value)'
    },
    fieldValuesParent: {
        display: 'flex'
    },
    idValue: {
        marginRight: '20px',
        minWidth: '15ch'
    },
    showDetail: {
        paddingTop: '10px',
    },
    embeddedGrid: {
        '& > div [class*=EmbeddedList-gridSize]': {
            padding: '8px 0 0 0'
        }
    },
    marginTop: {
        marginTop: 12
    }
});

class CopyDialog extends Component {
    constructor(props) {
        super(props);
        this.state = {
            selectAllFlag: false,
            selectedCount: 0,
            selectedRecordsObject: {},
            menuItems: [...MENU_ITEMS],
            rowSelection: 'multiple',
            selectedRows: false,
            itemCopyObject: { ...ITEM_COPY_DS },
            valueDataFailureMessages: [],
            showValueConfirmationDialog: false,
        }
    }

    componentDidMount() {
        const { itemData } = this.props;
        let itemCopyObject = { ...ITEM_COPY_DS };
        itemCopyObject["showDetail"] = 0;
        itemCopyObject['ICFCMP'] = itemData.ICOMP;
        itemCopyObject['ICFWHS'] = itemData.IWHSE;
        itemCopyObject['ICFVND'] = itemData.IVNDR;
        itemCopyObject['ICFITM'] = itemData.IITEM;
        itemCopyObject['ICTCMP'] = itemData.ICOMP;
        itemCopyObject['ICTVND'] = itemData.IVNDR;
        itemCopyObject['ICTITM'] = itemData.IITEM;
        this.setState({ itemCopyObject });
        let filterProps = [{ ...FILTER_OBJ, fieldValue: itemData.ICOMP }];
        filterProps.push({ ...FILTER_OBJ, accessor: 'VNDR', fieldValue: itemData.IVNDR })
        this.props.setFilterValues(filterProps);
        this.setPageForwardDirection(true);
        this.props.getItemCopyColumnDefs({ type: ITEMCOPY });
    }

    componentDidUpdate(prevProps, prevState) {
        const { columnDefs, rowData, isColumnDefsLoaded, filterProps, pageProps, updateColumnsList } = this.props;
        const {
            isAPIforItemCopyList,
            isAPIforColumns,
            isAPIforColumnsUpdate,
            isAPIforResetColumns,
            isAPIforItemList,
        } = this.props.itemCopy

        if (this.state.valueDataFailureMessages && this.state.valueDataFailureMessages.length
            && (JSON.stringify(this.state.valueDataFailureMessages) != JSON.stringify(prevState.valueDataFailureMessages))) {
            this.handleValueDataErrorMessages(this.state.valueDataFailureMessages[0]);
        }
        if (isAPIforItemCopyList && (isAPIforItemCopyList != prevProps.itemCopy.isAPIforItemCopyList)) {
            let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
            values.push("Failed to fetch Vendor List");
            this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
            this.props.setLabelDataFlags({ key: 'isAPIforItemCopyList', value: false });
        }

        if (isAPIforColumns && (isAPIforColumns != prevProps.itemCopy.isAPIforColumns)) {
            let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
            values.push("Failed to fetch columns For Vendor Embeddedlist");
            this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
            this.props.setLabelDataFlags({ key: 'isAPIforColumns', value: false });
        }

        if (isAPIforColumnsUpdate && (isAPIforColumnsUpdate != prevProps.itemCopy.isAPIforColumnsUpdate)) {
            let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
            values.push("Failed to update columns For Vendor Embeddedlist");
            this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
            this.props.setLabelDataFlags({ key: 'isAPIforColumnsUpdate', value: false });
        }

        if (isAPIforResetColumns && (isAPIforResetColumns != prevProps.itemCopy.isAPIforResetColumns)) {
            let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
            values.push("Failed to Rest columns For Vendor Embeddedlist");
            this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
            this.props.setLabelDataFlags({ key: 'isAPIforResetColumns', value: false });
        }

        if (isAPIforItemList && (isAPIforItemList != prevProps.itemCopy.isAPIforItemList)) {
            let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
            values.push("Failed to fetch Items List");
            this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
            this.props.setLabelDataFlags({ key: 'isAPIforItemList', value: false });
        }

        if ((pageProps != prevProps.pageProps) && pageProps.isPageSizeChanged) {
            let initialPageData = {
                ...pageProps,
                actualPage: 0,
                currentPage: 0,
                totalCount: 10,
                isForwardDirection: true,
            };
            this.props.onSetPageProps({
                ...pageProps,
                isPageSizeChanged: false
            });
            this.props.setApiCallCount(0);
            this.props.getItemCopyList(this.getApiObj(filterProps, false, initialPageData, VENDORS_LIST_PAGE));
        }

        if (columnDefs != prevProps.columnDefs && isColumnDefsLoaded != prevProps.isColumnDefsLoaded) {
            if (isColumnDefsLoaded) {
                this.props.getItemCopyList(this.getApiObj(filterProps, false, pageProps, VENDORS_LIST_PAGE));
            }
        }

        if (rowData != prevProps.rowData) {
            this.setAssociativeArrayObject(rowData)
        }

        if ((updateColumnsList != prevProps.updateColumnsList) && updateColumnsList) {
            this.props.getItemCopyColumnDefs({ type: ITEMCOPY });
        }
        if ((prevState.selectAllFlag != this.state.selectAllFlag) || prevState.selectedCount != this.state.selectedCount) {
            if (this.state.selectAllFlag) {
                let deselectAllDisable = false, selectAllDisable = true;
                this.disableMenuItem(deselectAllDisable, selectAllDisable);
            }
            else if (!this.state.selectedCount) {
                let deselectAllDisable = true, selectAllDisable = false;
                this.disableMenuItem(deselectAllDisable, selectAllDisable);
            }
            else {
                this.disableMenuItem(false);

            }
        }
    }

    componentWillUnmount() {
        this.props.setColumnDefsLoaded(false);
        this.props.resetStateData(false)
    }

    setAssociativeArrayObject = (rowData) => {
        const { apiCallCount } = this.props;
        let str = apiCallCount + "buffer";
        let data = this.state.selectedRecordsObject;
        if (data && Object.keys(data) && rowData && rowData.length) {
            for (let key in data) {
                let recordData = data[key];
                if (recordData && recordData.length && (key == str)) {
                    recordData.forEach((record, index) => {
                        rowData[index]["isSelected"] = record.isSelected;
                    })
                }
            }
        }
        data[str] = rowData;
        this.setState({ selectedRecordsObject: data })
    }

    updateSelectAllFlag = (flag) => {
        const { rowData = [] } = this.props;
        this.setState({ selectAllFlag: flag, selectedCount: flag ? rowData.length : 0 });
    }
    changeValuesOnSelectDeselect = (flag) => {
        let recordObj = this.state.selectedRecordsObject;
        if (recordObj && Object.keys(recordObj)) {
            for (let key in recordObj) {
                if (recordObj[key] && recordObj[key].length) {
                    recordObj[key].forEach((record) => {
                        record.isSelected = flag;
                    })
                }
            }
        }
        this.setState({ selectedRecordsObject: recordObj })
    }

    onRowSelected = (event) => {
        if (this.grid && this.grid.api) {
            const { apiCallCount, pageProps } = this.props;
            const { actualPageSize, actualPage } = pageProps;
            let data = this.state.selectedRecordsObject;
            if (data && Object.keys(data) && Object.keys(data).length) {
                let key = apiCallCount + "buffer";
                let rowIndex = (event.rowIndex + (actualPageSize * actualPage)) % 100;
                const { selected } = event.node;
                data[key][rowIndex]['isSelected'] = selected;
                this.setState({ selectedRecordsObject: data });
                this.setState(() => ({ selectedCount: this.grid.api.getSelectedRows().length || 0 }))
            }
        }
    }
    getApiObj = (filterProps, record, pageProps, currentPage) => {
        let apiObj = {
            filterProps, filterProps,
            pageProps: pageProps,
            direction: pageProps.isForwardDirection,
            record: record,
            currentPage: currentPage
        };
        return apiObj;
    }

    setPageForwardDirection = (flag) => {
        let initialPageData = {
            ...INITIAL_PAGE_PROPS,
            actualPage: 0,
            currentPage: 0,
            totalCount: 10,
            isForwardDirection: flag
        };
        this.setState({ initialPageData: initialPageData });
        this.props.onSetPageProps(initialPageData);
    }

    disableMenuItem = (deselectAllDisable, selectAllDisable) => {
        this.setState({
            menuItems: MENU_ITEMS.map(row => {
                let item = { ...row };
                if (item.key == 'deselectAll')
                    item.isDisable = deselectAllDisable;
                else if (item.key == 'selectAll' && selectAllDisable != undefined)
                    item.isDisable = selectAllDisable;
                return item;
            })
        })
    }

    getSelectedRowsForAPI = () => {
        let selectedRows = [];
        let recordObj = this.state.selectedRecordsObject;
        if (recordObj && Object.keys(recordObj)) {
            for (let key in recordObj) {
                let dataRecord = recordObj[key];
                if (dataRecord && dataRecord.length) {
                    dataRecord.forEach((record) => {
                        if (record.isSelected) {
                            selectedRows.push(record);
                        }
                    })
                }
            }
        }
        return selectedRows;
    }

    handleSubmit = () => {
        let selectedRows = this.getSelectedRowsForAPI();
        const { itemCopyObject, selectAllFlag } = this.state
        const showDetailCheck = !!+itemCopyObject["showDetail"]
        let finalArray = [];
        let listParams = {};
        if (selectAllFlag) {
            finalArray = this.prepareData([selectedRows[0]])
            listParams = this.prepareListParamsCopyAll(selectedRows, itemCopyObject);
            this.props.copyItems({ ...finalArray[0] }, showDetailCheck, listParams)
        } else {
            finalArray = this.prepareData(selectedRows)
            listParams = showDetailCheck ? this.prepareListParams(selectedRows, itemCopyObject) : {}
            this.props.copyItems(finalArray, showDetailCheck, listParams);
        }
        this.handleClose();
    }
    prepareData = data => {
        let dataArray = []
        const { itemCopyObject } = this.state
        data.forEach((vendor) => {
            let obj = { ...itemCopyObject };
            delete obj.showDetail;
            obj['ICTWHS'] = vendor.VWHSE;
            dataArray.push(obj);
        });
        return dataArray;
    }
    prepareListParams = (rowData) => {
        let firstRow = rowData[0];
        const { itemData } = this.props;
        const { itemCopyObject: { ICTITM } } = this.state;
        let filterProps = [{ ...FILTER_OBJ }];
        filterProps.push({ ...FILTER_OBJ, accessor: 'VNDR', fieldValue: itemData.IVNDR })
        filterProps.push({ ...FILTER_OBJ, accessor: 'ITEM', fieldValue: ICTITM })
        filterProps.push({ ...FILTER_OBJ, accessor: 'WHSE', fieldValue: firstRow.VWHSE })

        let pageProps = { pageSize: 3 }
        return {
            filterProps, pageProps, direction: true, currentPage: ITEMS_LIST_PAGE
        }
    }
    prepareListParamsCopyAll = (rowData) => {
        let firstRow = rowData[0];
        const { itemData } = this.props;
        const { itemCopyObject: { ICTITM } } = this.state;
        let filterProps = [{ ...FILTER_OBJ }];
        filterProps.push({ ...FILTER_OBJ, accessor: 'VNDR', fieldValue: itemData.IVNDR })
        filterProps.push({ ...FILTER_OBJ, accessor: 'ITEM', fieldValue: ICTITM })
        filterProps.push({ ...FILTER_OBJ, accessor: 'WHSE', fieldValue: firstRow.VWHSE })

        let copyAllFilter = [{ ...FILTER_OBJ }];
        copyAllFilter.push({ ...FILTER_OBJ, accessor: 'VNDR', fieldValue: itemData.IVNDR });
        let pageProps = { pageSize: 3 }
        return {
            filterProps, pageProps, direction: true, currentPage: ITEMS_LIST_PAGE, selectAllFilterProps: copyAllFilter, selectAllFlag: true
        }
    }
    handleClose = () => {
        this.props.closeDialog();
    }

    onGridReady = (params) => {
        this.grid = params;
    }
    handleChangeValue = (key, val) => {
        this.setState(prevState => ({ itemCopyObject: { ...prevState.itemCopyObject, [key]: val } }));
    }

    closeValueDialog = () => {
        this.setState({ showValueConfirmationDialog: false });
        if (this.state.valueDataFailureMessages && this.state.valueDataFailureMessages.length) {
            let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
            values.shift();
            this.setState({ valueDataFailureMessages: values });
            if (values && values.length == 0) {
                this.handleClose();
            }
        }
    }
    handleValueDataErrorMessages = (content) => {
        this.setState({ showValueConfirmationDialog: true, dialogContent: content });
    }

    render() {
        const { classes, globalDateFormat, filterCriteriaDetails,
            pageFilterOptions, globalFilterOptions, columnDefs, currentOwnerName,
            canUpdateComponent, loading, copyLabels, rowData, totalCount, isOpen } = this.props;
        const { tabcards, tabtitle } = copyLabels;
        const { itemCopyObject } = this.state;
        return (
            <DialogComponent
                className={classes.adjustDialog1}
                isOpen={isOpen}
                dialogTitle={tabtitle}
                cancelText={TEXT_CANCEL}
                submitText={TEXT_COPY}
                handleClose={() => this.handleClose()}
                handleCancel={() => this.handleClose()}
                handleSubmit={() => this.handleSubmit()}
                disableSubmit={(this.getSelectedRowsForAPI() && this.getSelectedRowsForAPI().length) ? false : true}>
                <React.Fragment>
                    {!loading && tabcards && tabcards.map(formCard => {
                        if (formCard.cardkey == COPY_CONTROLS) {
                            return <Box className={`${classes.notesForBlock} ${classes.marginTop}`}>
                                <FormFieldsGenerator
                                    valueDisplayCharacters={22}
                                    className={classes.adjustCardFieldsInline}
                                    currentOwnerName={currentOwnerName}
                                    key={formCard.cardkey}
                                    fieldsArray={formCard.cardfields.slice(0, 1)}
                                    valuesArray={itemCopyObject}
                                    handleChangeValue={this.handleChangeValue}
                                    enableAddButton={() => { }}
                                    globalDateFormat={globalDateFormat}
                                    filterCriteriaDetails={filterCriteriaDetails}
                                    pageFilterOptions={pageFilterOptions}
                                    globalFilterOptions={globalFilterOptions}
                                    columnDefs={columnDefs}
                                    currentPage={ITEMS_LIST_PAGE}
                                    canUpdateComponent={canUpdateComponent}
                                    noMassMaintenance={true}
                                />
                            </Box>
                        }
                    })}
                    {!loading && tabcards && tabcards.map(formCard => {
                        if (formCard.cardkey == COPY_CONTROLS) {
                            return <div className={classes.notesForBlock}>
                                <Box mb={theme.spacing(0.5)} className={classes.notesForLabel}>
                                    {tabcards && tabcards[0].cardtitle}
                                </Box>
                                <FormFieldsGenerator
                                    labelDisplayCharacters={20}
                                    valueDisplayCharacters={5}
                                    className={classes.adjustCardFieldsInline}
                                    currentOwnerName={currentOwnerName}
                                    key={formCard.cardkey}
                                    fieldsArray={formCard.cardfields.slice(1, 4)}
                                    valuesArray={itemCopyObject}
                                    handleChangeValue={this.handleChangeValue}
                                    enableAddButton={() => { }}
                                    globalDateFormat={globalDateFormat}
                                    filterCriteriaDetails={filterCriteriaDetails}
                                    pageFilterOptions={pageFilterOptions}
                                    globalFilterOptions={globalFilterOptions}
                                    columnDefs={columnDefs}
                                    currentPage={ITEMS_LIST_PAGE}
                                    canUpdateComponent={canUpdateComponent}
                                    noMassMaintenance={true}
                                />
                            </div>
                        }
                    })}

                    {!loading && columnDefs && columnDefs.length && rowData && rowData.length ?
                        <Box className={classes.embeddedGrid}>
                            <EmbeddedList
                                pageProps={this.props.pageProps}
                                selectAllFlag={this.state.selectAllFlag}
                                updateSelectAllFlag={this.updateSelectAllFlag}
                                selectedRecordsObject={this.state.selectedRecordsObject}
                                hasSelectDeselectAll={true}
                                changeValuesOnSelectDeselect={this.changeValuesOnSelectDeselect}
                                updateMenuItems={() => { }}
                                suppressRowClickSelection={false}
                                onRowSelected={this.onRowSelected}
                                currentPage={"vendors"}
                                listPredecessor={getListPredecessor("vendors")}
                                rowSelection={this.state.rowSelection}
                                suppressSizeToFit={true}
                                onGridReady={this.onGridReady}
                                rowData={rowData}
                                updateShowHide={(data) => this.props.updateShowHide(data)}
                                menuItems={this.state.menuItems}
                                onSelectAll={(data) => this.onSelectAll(data)}
                                columnDefs={columnDefs}
                                gridHeight={'250px'}
                                totalCount={totalCount}
                                hasGridActions={true}
                                rowMultiSelectWithClick={true}
                            >
                            </EmbeddedList>
                        </Box>
                        : <Spinner loading type="ItemCopy" />}
                    <Box className={classes.adjustShowDetail}>
                        <FieldInput field={{ type: 'checkbox', key: 'showDetail' }} value={Number(itemCopyObject["showDetail"])}
                            onChange={(key, val) => this.handleChangeValue(key, val)} />
                        <div className={classes.showDetail}>{this.props.getLabelValue("25566")}</div>
                    </Box>
                    {
                        this.state.showValueConfirmationDialog && <ConfirmationDialog
                            hasError={true}
                            isOpen={this.state.showValueConfirmationDialog}
                            dialogTitle={TEXT_ALERT}
                            submitText={TEXT_OK}
                            handleClose={() => this.closeValueDialog()}
                            handleCancel={() => this.closeValueDialog()}
                            handleSubmit={() => this.closeValueDialog()}
                        >
                            <div>
                                {this.state.dialogContent}
                            </div>
                        </ConfirmationDialog>
                    }
                </React.Fragment>
            </DialogComponent >
        );
    }
}
const mapStateToProps = createStructuredSelector({
    itemCopy: makeSelectItemCopy(),
    rowData: rowDataSelector(),
    columnDefs: columnDefsSelector(),
    loading: loadingSelector(),
    pageProps: pagePropsSelector(),
    isColumnDefsLoaded: columnFlagSelector(),
    filterProps: filterPropsSelector(),
    columnInfo: columnInfoSelector(),
    isAPIProgress: isAPIProgressSelector(),
    totalCount: totalCountSelector(),
    moreRecordsAvailable: moreRecordsSelector(),
    apiCallCount: apiCallCountSelector(),
    updateColumnsList: updateColumnsListSelector(),
    errorMessages: errorMessageLabels(),
})

function mapDispatchToProps(dispatch) {
    return {
        dispatch,
        getItemCopyList: (data) => dispatch(getItemCopyList(data)),
        setApiCallCount: (data) => dispatch(setApiCallCount(data)),
        onSetPageProps: (data) => dispatch(onSetPageProps(data)),
        getItemCopyColumnDefs: (data) => dispatch(getItemCopyColumnDefs(data)),
        setFilterValues: (data) => dispatch(setFilterValues(data)),
        setColumnDefsLoaded: (data) => dispatch(setColumnDefsLoaded(data)),
        updateShowHide: (data) => dispatch(updateShowHide(data)),
        resetStateData: (data) => dispatch(resetStateData(data)),
        resetDefault: (data) => dispatch(resetDefault(data)),
        getItemsList: (data) => dispatch(getItemsList(data)),
        setLabelDataFlags: (data) => dispatch(setLabelDataFlags(data)),
    }
}

const withConnect = connect(
    mapStateToProps,
    mapDispatchToProps,
);
const withReducer = injectReducer({ key: 'itemCopyReducer', reducer });
const withSaga = injectSaga({ key: 'itemCopySaga', saga });
export default compose(
    withReducer,
    withSaga,
    withConnect,
    withStyles(styles),
)(CopyDialog);
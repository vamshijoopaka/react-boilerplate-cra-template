

/*
* * //==========================================================================
*
* * // Copyright 2021-2021, Blue Yonder Group, Inc.
*
* * // All Rights Reserved
*
* * //
*
* * // THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF
*
* * // BLUE YONDER GROUP, INC.
*
* * //
*
* * //
*
* * // The copyright notice above does not evidence any actual
*
* * // or intended publication of such source code.
*
* * //
*
* * // ===========================================================================
*/
import {
  REMOVE_CUTDOWN_CHILD_TAB,
  ADD_ITEM,
  SET_IS_SHOW_CONTEXT_MENU,
  SET_SELECTED_VALUE_FOR_TABS,
  CLOSE_GLOBAL_FILTER_COMPONENT,
  REMOVE_CURRENT_RECORD_OBJ,
  SET_LOGIN_STATE,  //Ajit login
  SET_CURRENT_USERNAME,
  CLEAR_LOGIN_STATE, LIST_DATA,
  GET_PREFERENCES_AFTER_LOGIN, // E3C-30525-Ajit
  GET_PREFERENCES_AFTER_LOGIN_SUCCESS,
  GET_PREFERENCES_AFTER_LOGIN_FAILURE,
  GET_SESSION_ALIVEINFO,//E3C-31117:Ajit Fixing errors during session expiry
  GET_SESSION_ALIVEINFO_SUCCESS,
  GET_SESSION_ALIVEINFO_FAILURE,
  RESET_SESSION_ALIVEINFO,
  GET_NIGHTJOB_STATUS,
  GET_NIGHTJOB_STATUS_SUCCESS,
  GET_NIGHTJOB_STATUS_FAILURE,
  RESET_NIGHT_JOBSTATUS,
  HANDLE_LOGOUT,
  SET_MESSAGE_HEADERS_FROM_SERVER //E3C-31478:Ajit Added constant for setting headers
} from 'components/common/constants';
import { SET_MANDATORY_FILTER_OPTIONS } from './components/common/constants';

export function removeChildCutdownTab(tab, index) {
  return {
    type: REMOVE_CUTDOWN_CHILD_TAB,
    tab,
    index
  }
}

export function addItem(data, breadcrumbId) {
  return {
    type: ADD_ITEM,
    payload: {
      data,
      breadcrumbId
    }
  }
}

export function addItemProperties(data, breadcrumbId, selectedValue) {
  return {
    type: LIST_DATA,
    payload: {
      data,
      breadcrumbId,
      selectedValue
    }
  }
}

export function setIsShowContextMenu(payload) {
  return {
    type: SET_IS_SHOW_CONTEXT_MENU,
    payload
  }
}

export function setSelectedValueForTabs(data) {
  return {
    type: SET_SELECTED_VALUE_FOR_TABS,
    data
  }
}

export function setMandatoryFilterOptions(data) {
  return {
    type: SET_MANDATORY_FILTER_OPTIONS,
    data
  }
}

export function closeFilterComponent(data) {
  return {
    type: CLOSE_GLOBAL_FILTER_COMPONENT,
    data
  }
}

export function removeCurrentRecordObj(tabId, breadCrumbId) {
  return {
    type: REMOVE_CURRENT_RECORD_OBJ,
    tabId,
    breadCrumbId
  }
}

//Ajit login
export function setLoginState(payload) {
  return {
    type: SET_LOGIN_STATE,
    payload
  }

}

export function setCurrentUserName(payload) {
  return {
    type: SET_CURRENT_USERNAME,
    payload
  }

}

export function clearLoginState(payload) {
  return {
    type: CLEAR_LOGIN_STATE,
    payload
  }
}
//Ajit login

// E3C-30525-Ajit-Begin
export function getPreferencesAftrLogin(data) {
  return {
    type: GET_PREFERENCES_AFTER_LOGIN,
    data,
  };
}

export function getPreferencesAftrLoginSuccess(data) {
  return {
    type: GET_PREFERENCES_AFTER_LOGIN_SUCCESS,
    data,
  };
}

export function getPreferencesAftrLoginFailure(data) {
  return {
    type: GET_PREFERENCES_AFTER_LOGIN_FAILURE,
    data,
  };
}

// E3C-30525-Ajit-End
//E3C-31117:Begin:Ajit Fixing errors during session expiry
export function getSessionAliveInfo() {
  return {
    type: GET_SESSION_ALIVEINFO,

  };
}

export function getSessionAliveInfoSuccess(data) {
  return {
    type: GET_SESSION_ALIVEINFO_SUCCESS,
    data,
  };
}

export function getSessionAliveInfoFailure(data) {
  return {
    type: GET_SESSION_ALIVEINFO_FAILURE,
    data,
  };
}
export function resetSessionAliveStatus(data) {
  return {
    type: RESET_SESSION_ALIVEINFO,
    data,
  };
}

export function getNightJobStatus(data) {
  return {
    type: GET_NIGHTJOB_STATUS,
    data

  };
}

export function getNightJobStatusSuccess(data) {
  return {
    type: GET_NIGHTJOB_STATUS_SUCCESS,
    data,
  };
}

export function getNightJobStatusFailure(data) {
  return {
    type: GET_NIGHTJOB_STATUS_FAILURE,
    data,
  };
}
export function resetNightJobStatus(data) {
  return {
    type: RESET_NIGHT_JOBSTATUS,
    data,
  };
}

export function handleLogout() {
  return {
    type: HANDLE_LOGOUT,

  };
}

//E3C-31117:Ajit Fixing errors during session expiry
//E3C-31478:Begin-Ajit Added action for setting headers
export function setMessageLabelsFromServer(data) {
  return {
    type: SET_MESSAGE_HEADERS_FROM_SERVER,
    data

  };
}
//E3C-31478:End-Ajit
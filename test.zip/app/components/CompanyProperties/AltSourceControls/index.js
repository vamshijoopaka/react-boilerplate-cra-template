/** Change Log
 * LogStart --  E3C-33195 - Kumar A- 16 September,2021 - 2022.1.0.0 Unified Product
 *              Story: E3C-33195 --Code Cleanup
*/
import React from 'react';
import { connect } from 'react-redux';
import { compose } from 'redux';
import { withStyles } from '@material-ui/core/styles';
import PropTypes from 'prop-types';

import FormFieldsGenerator from '../../common/FormFieldsGenerator';
import Spinner from '../../common/Spinner';
import { selectData } from './selector';
import {
    COMPANY_REPORTS_TO_PRINT,
    COMPANY_ALTERNATE_SOURCE,
} from './constants';
import './style.scss';
import { COMPANYS_LIST_PAGE } from 'components/common/constants';
import CardComponent from '../../common/CardComponent';

const propTypes = {
    setSaveData: PropTypes.func,
};

const style = theme => ({
    pageContainer: {
        display: 'flex',
        backgroundColor: 'var(--background-app)',
        borderTop: 'none',
        padding: '10px 20px',
    },
    pageContainerSeventy: {
        width: '70%',
    },
    pageContainerThirty: {
        width: '30%',
        marginLeft: '20px',
    },
    cardWithborder: {
        border: '1px solid var(--secondary-s3)',
        borderRadius: '4px',
        padding: '10px',
        margin: '10px',
        width: '100%',
        backgroundColor: 'var(--secondary-s5)',
    },
    card: {
        padding: '0px',
        backgroundColor: 'var(--background-content)',
        borderRadius: '4px',
        width: '100%',
        margin: '8px',
        '& .MuiCardHeader-root': {
            padding: '22px 10px 0 20px'
        },
        '& .MuiCardContent-root': {
            padding: '16px 15px 10px 15px'
        }
    },
    card1: {
        padding: '0px',
        backgroundColor: 'var(--background-content)',
        borderRadius: '4px',
        width: '90%',
        margin: '10px',
        marginLeft: '0px',
        '& .MuiCardHeader-root': {
            padding: '16px 32px'
        },
        '& .MuiCardContent-root': {
            padding: '16px 32px'
        }
    },
    card2: {
        padding: '0px',
        backgroundColor: 'var(--background-content)',
        borderRadius: '4px',
        width: '100%',
        margin: '10px',
        marginLeft: '0px',
        '& .MuiCardHeader-root': {
            padding: '16px 32px'
        },
        '& .MuiCardContent-root': {
            padding: '16px 32px'
        }
    },
    cardName: {
        fontWeight: '500',
        margin: '10px 0 20px 5px',
    },
    simpleCardGroup: {
        width: '100%',
        display: 'flex',
        justifyContent: 'space-around',
    },
    dashedBottomBorder: {
        borderBottom: '1px dashed var(--secondary-s21)',
        marginBottom: '20px',
    },
    marginLeftZero: {
        marginLeft: '0',
    },
    marginRightZero: {
        marginRight: '0',
    }
});

class CompanyControlFactors extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            fields: false,
            values: false,
            hasError: false,
            errorId: false,
        };
        this.handleChangeValue = this.handleChangeValue.bind(this);
    }

    handleChangeValue(key, val, field) {
        if (val != null) {
            this.props.setValueData({ key, val });
        }
    }

    getValueData(valueData, newValueData) {
        if (Object.keys(valueData).length && Object.keys(newValueData).length &&
            (JSON.parse(JSON.stringify(valueData)) !== JSON.parse(JSON.stringify(newValueData)))) {
            return newValueData;
        }
        return valueData;
    }

    setValueDataOnFocutOut = (key, value, field) => {
    }

    render() {
        const { classes, setSaveData, globalDateFormat, filterCriteriaDetails, pageFilterOptions,
            globalFilterOptions, columnDefs, currentPage } = this.props;
        const { loading, valueData, newValueData, alternateSourceLabelsData } = this.props.CompanyPropertiesData;
        const { tabcards } = alternateSourceLabelsData;
        return (
            <div>
                {(!loading && tabcards && tabcards.length) ? (
                    <div className={classes.pageContainer}>
                        {!loading && tabcards.map(formCard => {
                            if (formCard.cardkey == COMPANY_REPORTS_TO_PRINT) {
                                return <CardComponent title={formCard.cardtitle} className={classes.card}>
                                    <FormFieldsGenerator
                                        cardHasDotsBtn={false}
                                        cardHasCheckBox={false}
                                        noMassMaintenance
                                        labelDisplayCharacters={28}
                                        valueDisplayCharacters={5}
                                        handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                                        key={formCard.cardkey}
                                        parentPage={COMPANYS_LIST_PAGE}
                                        className="COMPANY_REPORTS_TO_PRINT"
                                        fieldsArray={formCard.cardfields}
                                        valuesArray={this.getValueData(valueData, newValueData)}
                                        handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                        enableAddButton={(e) => { setSaveData(e) }}
                                        handleFocusOut={(key, val, field) => this.setValueDataOnFocutOut(key, val, field)}
                                        globalDateFormat={globalDateFormat}
                                        filterCriteriaDetails={filterCriteriaDetails}
                                        pageFilterOptions={pageFilterOptions}
                                        globalFilterOptions={globalFilterOptions}
                                        columnDefs={columnDefs}
                                        currentPage={currentPage}
                                        parentData={this.props.companyData}
                                        canUpdateComponent={this.props.canUpdateComponent}
                                    />
                                </CardComponent>
                            }
                        })}
                        {!loading && tabcards.map(formCard => {
                            if (formCard.cardkey == COMPANY_ALTERNATE_SOURCE) {
                                return <CardComponent title={formCard.cardtitle} className={classes.card}>
                                    <FormFieldsGenerator
                                        handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                                        key={formCard.cardkey}
                                        parentPage={COMPANYS_LIST_PAGE}
                                        className="COMPANY_ALTERNATE_SOURCE"
                                        labelDisplayCharacters={9}
                                        valueDisplayCharacters={23}
                                        noMassMaintenance
                                        fieldsArray={formCard.cardfields}
                                        valuesArray={this.getValueData(valueData, newValueData)}
                                        handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                        enableAddButton={(e) => { setSaveData(e) }}
                                        handleFocusOut={(key, val, field) => this.setValueDataOnFocutOut(key, val, field)}
                                        globalDateFormat={globalDateFormat}
                                        filterCriteriaDetails={filterCriteriaDetails}
                                        pageFilterOptions={pageFilterOptions}
                                        globalFilterOptions={globalFilterOptions}
                                        columnDefs={columnDefs}
                                        currentPage={currentPage}
                                        parentData={this.props.companyData}
                                        canUpdateComponent={this.props.canUpdateComponent}
                                    />
                                </CardComponent>
                            }
                        })}
                    </div>
                ) : (<Spinner loading type="list" />)
                }
            </div>
        );
    }
}

function mapDispatchToProps(dispatch) {
    return {
        dispatch,
        getFieldList: (data) => {
            dispatch(getFieldList(data));
        },
        setGlobalCurrentPage: (pageName) => {
            dispatch(setGlobalCurrentPage(pageName));
        }
    }
}

const mapStateToProps = function (state) {
    return {
        CompanyControlFactorsData: selectData(state)
    }
};

const withConnect = connect(
    mapStateToProps,
    mapDispatchToProps,
);

CompanyControlFactors.propTypes = propTypes;

export default compose(
    withConnect,
    withStyles(style)
)(CompanyControlFactors);

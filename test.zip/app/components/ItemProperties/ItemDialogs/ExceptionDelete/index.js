/*
*LogStart - 2021.1.0.2 AWR
    E3C-33251 - J Vamshi 19-Oct-2021 : After Deleting an Exception, re-pointing the itemproperties to next exception from the list.
*/
import React from 'react'
import { connect } from 'react-redux';
import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import reducer from './reducer';
import saga from './saga';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import { Box, withStyles } from '@material-ui/core';
import CardComponent from 'components/common/CardComponent';
import FormFieldsGenerator from 'components/common/FormFieldsGenerator';
import Spinner from 'components/common/Spinner';
import {
    getCardsData, getCancelData, getPoLineData, makeSelectAuthorizedComponentsList, getLoading, makeSelectCurrentPage, makePOLineActionsPropertiesData, selectGlobalNumberSeparator, selectGlobalNumberFormat, selectGlobalDecimalSeparator,
    makePageFilterOptions, makeFilterOptions, makeSelectGlobalSelectFilterList, errorMessageLabels, getRadioData, getFilterGridData
} from './selector';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormControl from '@material-ui/core/FormControl';
import {
    getFilterData, getKeyChangeData, getFilterCriteriaData, getColumnDefs, updateState, getPOLinesList,
    updateShowHide, onSetPageProps, applyCancelLines
} from './actions'
import { getListPredecessor, prepareRowDtaFromFilterProps } from 'utils/util';
import {
    COLUMN_VALUE_ACCESSOR, OPENPOLINES_LIST_PAGE, OPENPOLINES_PROPERTIES_PAGE, TEXT_CANCEL, TEXT_APPLY, MENU_ITEMS
} from 'containers/common/constants';
import DialogComponent from 'components/common/DialogComponent'
import FilterGrid from 'containers/common/FilterGrid';
import { POLINE_CARDKEY, CANCEL_POLINE_CARDKEY, } from './constants'
import {
    makeSelectShowContextMenu,
    getFromSidePanel,
    getActiveTabData,
    makeSelectNoDataExists,
    makeSelectNoDataCallBack,
    makeSelectCutDownTabs,
    getMaxTabExceeds,
    getMaxChildTabExceeds,
    getActiveBreadcrumbId,
    getActiveTabId,
    makeSelectSelectedRecordObj,
    makeSelectFromPage,
    makeColumnDefinitions,
    makeCurrentDbSelectorProps,
    tabsSelector,
    getItems,
    makeSelectSelectedValue,
    makeSelectCurrentOwnerName
} from 'selector';
import { isEqual } from 'lodash'
import EmbeddedList from 'containers/common/EmbeddedList';
import { PAGE_SIZES } from 'containers/common/FilterCriteria/constants';
import { GLOBAL_FILTER_OPTIONS, INITIAL_PAGE_PROPS } from 'components/common/constants';
import theme from 'jda-gcp-theme';

const styles = theme => ({
    simpleCardGroup: {
        width: '100%',
        display: 'flex',
        justifyContent: 'space-around',
        paddingLeft:'16px',
        paddingRight:'16px',
        paddingTop:'10px'
    },
    card: {
        padding: '0px',
        backgroundColor: 'var(--background-content)',
        borderRadius: '4px',
        marginLeft:'15px',
        marginRight:'5px',
        // width: '100%',
        margin: '10px 0px 10px 0',
        '& .MuiCardHeader-root': {
            padding: '22px 10px 0 20px'
        },
        '& .MuiCardContent-root': {
            padding: '16px 15px 10px 15px'
        }
    },
    polineForBlock: {
        display: 'flex',
        flexDirection: 'column',
        flexWrap: 'wrap',
        border: '1px solid var(--divider-line)',
        padding: '10px 10px 0 10px',
        position: 'relative',
        width: '100%'
    },
    polineForLabel: {
        position: 'absolute',
        top: '-7px',
        left: '10px',
        background: 'var(--background-content)',
        padding: '0 8px',
    },
    data: {
        display: 'grid',
        gridTemplateColumns:'auto auto',
        columnGap: '30px',
        //padding: '16px 15px 10px 15px'
        //flexWrap: 'wrap',
        //flexDirection: 'row',
    },
    radiofield: {
       paddingLeft:'6px',
       display:'grid',
       gridTemplateColumns:'33% 33% 33%',
    },
    
    embedded_list: {
        paddingBottom: '20px'
    }
})

class ExceptionDelete extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            isSaveEnabled: false,
            cardsArray: {},
            value: "ThisPO",
            filterRowData: [],
            defaultFilters: [],
            selectAllFlag: false,
            selectedRecordsObject: {},
            recordsSelected: [],
            menuItems: MENU_ITEMS,
            appliedFilter: []
        }
    }

    prepareDefaultCriteriaFilters = () => {
        // const { filtergridCols, itemDataRecord } = this.props
        const { filtergridCols, currentRecordData } = this.props

        let filters = ['BUYR', 'COMP', 'ITEM', 'VNDR', 'WHSE', 'SUBV','EXTYP'].map((field) => { 
            return {
                accessor: field,
                fieldValue: field !== "EXTYP" ? currentRecordData[`I${field}`] : currentRecordData["EXTYPE"]
            }
        }).filter((field) => field.fieldValue !== undefined && field.fieldValue !== null)
        filters = filters.map(ele => {
            if (ele.accessor === "EXTYP") {
                ele.accessor = "EXTYPE";
            }
            return ele;
        });
        filters = prepareRowDtaFromFilterProps(filters, filtergridCols)
        this.setState({ filterRowData: filters, defaultFilters: filters, appliedFilter: filters })
        this.getPOLinesList(filters, false)
    }

    getRecordDataOnDirection(direction) {
        const { polinesRowData, apiCount } = this.props.poLinePropertiesActionData;
        if (!polinesRowData || !polinesRowData.length) {
            return {}
        }
        let count = apiCount;
        if (!direction) {
            this.props.updateState({ key: 'apiCount', value: count - 1 });
            return polinesRowData[0];
        } else {
            this.props.updateState({ key: 'apiCount', value: count + 1 });
            return polinesRowData[polinesRowData.length - 1];
        }
    }

    getPOLinesList = (filters, isNext) => {
        // const { pageProps } = this.props.poLinePropertiesActionData
        const pageProps = INITIAL_PAGE_PROPS;
        this.props.getPOLinesList({
            record: isNext ? this.getRecordDataOnDirection(pageProps.isForwardDirection) : {},
            filterProps: filters,
            currentPage: 'items',
            pageProps,
            direction: pageProps.isForwardDirection
        })
        this.setState({ appliedFilter: filters })
    }

    componentDidMount() {
        this.props.getFilterData({ data: this.props.propertiesData, value: this.state.value });
        this.props.getKeyChangeData({ data: this.props.propertiesData, value: this.state.value });
        this.state.cardsArray = JSON.parse(JSON.stringify(this.props.itemDataRecord));
        this.props.getColumnDefs({ from: 'exceptionitemdelete' })
        if (this.props.filtergridCols?.length) {
            this.prepareDefaultCriteriaFilters()
        } else {
            this.props.getFilterCriteriaData({ from: 'exceptionitemfiltercolumns' });
        }

    }
    componentDidUpdate(prevProps, prevState) {
        const { filtergridCols } = this.props
        const { updateColumnDefs, applySuccess, polinesRowData } = this.props.poLinePropertiesActionData
        if (prevState.value != this.state.value) {
            this.props.getKeyChangeData({ data: this.props.propertiesData, value: this.state.value });
        }
        if (filtergridCols && !isEqual(filtergridCols, prevProps.filtergridCols)) {
            this.prepareDefaultCriteriaFilters()
        }
        if (updateColumnDefs && prevProps.openOPPropetiesData?.updateColumnDefs !== updateColumnDefs) {
            this.props.getColumnDefs({ from: 'exceptionitemdelete' })
        }
        if (applySuccess && (applySuccess !== prevProps.poLinePropertiesActionData.applySuccess)) {
            this.handleClose(this.state.includesCurrentItem); //E3C-33251, 19-Oct-2021, J Vamshi
        }

        if (!isEqual(polinesRowData, prevProps.poLinePropertiesActionData.polinesRowData)) {
            this.setAssociativeArrayObject(polinesRowData)
        }
    }


    handleChangeValue(key, value, field) {
        this.setState({ cardsArray: { ...this.state.cardsArray, [!field.prefixFlag ? getListPredecessor(this.props.currentPage) + key : key]: value } })
    }


    handleClose(deletedFlag = false) {
        this.props.closeDeleteException(deletedFlag); //E3C-33251, 19-Oct-2021, J Vamshi
    }
    handleChange = (event) => {
        this.setState({ value: event.target.value });
    };
    setSaveData(val) {
        this.setState({ isSaveEnabled: val })
    }

    resetDefault = () => {
        if (this.props.poLinePropertiesActionData?.columnInfo?.USERID?.trim() !== 'SYSTEM') {
            this.props.getColumnDefs({ from: 'exceptionitemdelete', isResetDefault: true })
        }
    }

    onRowSelected = (event) => {
        let arr = this.getSelectedRowsForAPI();
        if (this.grid && this.grid.api) {
            const { apiCount, pageProps } = this.props.poLinePropertiesActionData;
            const { actualPageSize, actualPage } = pageProps;
            let data = this.state.selectedRecordsObject;
            if (data && Object.keys(data) && Object.keys(data).length) {
                let key = apiCount + "buffer";
                let rowIndex = (event.rowIndex + (actualPageSize * actualPage)) % 100;
                data[key][rowIndex]['isSelected'] = event.node.selected;
                this.setSelectedRecords(data);
            }
        }
    }

    getSelectedRowsForAPI = () => {
        let selectedRows = [];
        let recordObj = this.state.selectedRecordsObject;
        if (recordObj && Object.keys(recordObj)) {
            for (let key in recordObj) {
                let dataRecord = recordObj[key];
                if (dataRecord && dataRecord.length) {
                    dataRecord.forEach((record) => {
                        if (record.isSelected) {
                            selectedRows.push(record);
                        }
                    })
                }
            }
        }
        return selectedRows;
    }

    setAssociativeArrayObject = (rowData) => {
        const { apiCount, pageProps } = this.props.poLinePropertiesActionData;
        let str = apiCount + "buffer";
        let data = this.state.selectedRecordsObject;
        if (data && Object.keys(data) && rowData && rowData.length) {
            for (let key in data) {
                let recordData = data[key];
                if (recordData && recordData.length && (key == str)) {
                    recordData.forEach((record, index) => {
                        rowData[index]["isSelected"] = record.isSelected;
                    })
                }
            }
        }
        data[str] = rowData;
        this.setSelectedRecords(data);
    }


    changeValuesOnSelectDeselect = (flag) => {
        let recordObj = this.state.selectedRecordsObject;
        if (recordObj && Object.keys(recordObj)) {
            for (let key in recordObj) {
                if (recordObj[key] && recordObj[key].length) {
                    recordObj[key].forEach((record, index) => {
                        record.isSelected = flag;
                    })
                }
            }
        }
        this.setSelectedRecords(recordObj);
    }

    setSelectedRecords = (records) => {
        this.setState({ selectedRecordsObject: records }, () => {
            this.setState({ recordsSelected: this.getSelectedRowsForAPI() })
        })
    }

    onGridReady(params) {
        this.grid = params;
    }

    updateMenuItems = items => {
        this.setState({ menuItems: items })
    }
    getOkBody = () => {

        const {currentRecordData} =  this.props;
        let includesCurrentItem = false; //E3C-33251, 19-Oct-2021, J Vamshi
        
        let EXGRP = " ";
        if (currentRecordData.EXTYPE >= 0 && currentRecordData.EXTYPE <= 90) {
            EXGRP = "H"
        }
        else if (currentRecordData.EXTYPE >= 100 && currentRecordData.EXTYPE <= 250) {
            EXGRP = "M"
        } 

        const postData = {
            IACOMP: currentRecordData.ICOMP,
            IAWHSE: currentRecordData.IWHSE,
            IAVNDR: currentRecordData.IVNDR,
            IAITEM: currentRecordData.IITEM,
            // IAETYP: currentRecordData.EXTYPE,
            IEXGRP: EXGRP,
            IAAWHS: '0',
          };

          if (this.state.value === 'ThisPO') {

          }

          if (this.state.value === 'AllPO') {
            postData.IAWHSE =  '   ';
            postData.IAAWHS =  '1';
            includesCurrentItem = true; //E3C-33251, 19-Oct-2021, J Vamshi
          }

          if (this.state.value === 'Filter' && this.state.selectAllFlag) {
            postData.IAITEM =  '   ';
          }

        let body = {}
        if (this.state.value !== 'Filter') {
            body['body'] = postData;
            body['key'] = 'nonFilter'
            body['filterProps'] = GLOBAL_FILTER_OPTIONS
            body['pageProps'] = INITIAL_PAGE_PROPS
            body['currentPage'] = 'items' // Revisit exceptionitems or items
            body['direction'] = true
            includesCurrentItem = true; //E3C-33251, 19-Oct-2021, J Vamshi
        } else if (this.state.selectAllFlag) {
            body['body'] = postData;
            body['key'] = 'selectAll'
            body['filterProps'] = this.state.appliedFilter
            body['pageProps'] = INITIAL_PAGE_PROPS
            body['currentPage'] = 'items'
            body['direction'] = true
            includesCurrentItem = true; //E3C-33251, 19-Oct-2021, J Vamshi
        } else {
            body['body'] =  
                this.state.recordsSelected.map((ele) => {
                    
                    let SELEXGRP = " ";
                    if (ele.EXTYPE >= 0 && ele.EXTYPE <= 90) {
                        SELEXGRP = "H"
                    }
                    else if (ele.EXTYPE >= 100 && ele.EXTYPE <= 250) {
                        SELEXGRP = "M"
                    } 

                    return ({
                        "IACOMP": ele.ICOMP,
                        "IAWHSE": ele.IWHSE,
                        "IAVNDR": ele.IVNDR,
                        "IAITEM": ele.IITEM,
                        "IAETYP": ele.EXTYPE,
                        "IEXGRP": SELEXGRP,
                        "IAAWHS": '0',
                    })
                })
            body['key'] = 'fewRecords'
            includesCurrentItem = !!this.state.recordsSelected?.some?.(ele => isEqual(ele, this.props.currentRecordData)); //E3C-33251, 19-Oct-2021, J Vamshi
        }
        this.setState({ includesCurrentItem }); //E3C-33251, 19-Oct-2021, J Vamshi
        return body
    }
    handleApply = () => {
        const body = this.getOkBody()
        this.props.applyCancelLines(body)
    }

    getDisableValue = () => {
        const isNotFilter = this.state.value !== 'Filter'
        if (isNotFilter) {
            return Boolean(!this.state.cardsArray.IITEM)
        } else {
            return Boolean(!this.state.recordsSelected.length)
        }
    }

    render() {
        const { classes, ...otherThanClass } = this.props
        const { propertiesData, filtergridCols, cancelCardsData, polineCardsData, loading, itemDataRecord,
            currentOwnerName, currentPage, pageFilterOptions, globalFilterOptions, filterCriteriaDetails,
            canUpdateComponent, poLinePropertiesActionData } = this.props
        const { columnInfo, columnDefs, pageProps, polinesRowData, moreRecordsAvailable,
            totalCount } = poLinePropertiesActionData
        const isNotFilter = this.state.value !== 'Filter'
        
        return (
            <>

                <DialogComponent
                    isOpen={true}
                    dialogTitle={'25077'}
                    handleClose={() => this.handleClose()}
                    handleCancel={() => this.handleClose()}
                    handleSubmit={() => this.handleApply()}
                    disableSubmit={this.getDisableValue()}
                    cancelText={TEXT_CANCEL}
                    submitText={TEXT_APPLY}>
                    {loading ? <Spinner loading type="list" /> : <>
                        <Box>
                            <Box className={classes.simpleCardGroup}>
                                {!loading && propertiesData[0]?.tabcards?.map(formCard => {
                                    if (formCard.cardkey == POLINE_CARDKEY) {
                                        if (this.props.polineCardsData.length) {
                                            return <div className={classes.polineForBlock}>
                                            <Box mb={theme.spacing(0.5)} className={classes.polineForLabel}>{formCard.cardtitle}</Box>
                                                <FormFieldsGenerator
                                                    currentOwnerName={currentOwnerName}
                                                    cardHasDotsBtn={false}
                                                    cardHasCheckBox={false}
                                                    noMassMaintenance={true}
                                                    labelDisplayCharacters={20}
                                                    valueDisplayCharacters={20}
                                                    key={formCard.cardkey}
                                                    parentPPage={OPENPOLINES_LIST_PAGE}
                                                    className={classes.data}
                                                    fieldsArray={polineCardsData}
                                                    valuesArray={this.state.cardsArray}
                                                    disabled={Boolean(polineCardsData)}
                                                    handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                                    enableAddButton={(e) => { this.setSaveData(e) }}
                                                    pageFilterOptions={pageFilterOptions}
                                                    globalFilterOptions={globalFilterOptions}
                                                    currentPage={currentPage}
                                                    //parentData={polineDataRecord}
                                                canUpdateComponent={true}
                                                />
                                            </div>
                                        }
                                    }
                                })}
                                </Box>
                                <br/>
                                <Box className={classes.simpleCardGroup}>
                                {!loading && propertiesData[0]?.tabcards?.map(formCard => {
                                    if (formCard.cardkey == CANCEL_POLINE_CARDKEY) {
                                        if (this.props.cancelCardsData.length && this.state.value.length) {
                                            return <div className={classes.polineForBlock}>
                                            <Box mb={theme.spacing(0.5)} className={classes.polineForLabel}>{formCard.cardtitle}</Box>
                                            
                                                <FormControl component="fieldset">
                                                    
                                                    <RadioGroup  className={classes.radiofield} aria-label="gender" name="gender1" value={this.state.value} onChange={this.handleChange}>
                                                        <FormControlLabel value='ThisPO' control={<Radio color='primary' />} label={this.props.cancelCardsData[0].TLLAB} />
                                                        <FormControlLabel value='Filter' control={<Radio color='primary' />} label={this.props.cancelCardsData[1].TLLAB} />
                                                        <FormControlLabel value='AllPO' control={<Radio color='primary' />} label={this.props.cancelCardsData[2].TLLAB} />
                                                    </RadioGroup>
                                                </FormControl>
                                            </div>
                                        }
                                    }
                                })}
                            </Box>
                            <br/>
                          
                            <FilterGrid
                                currentPage={currentPage}
                                addFieldTitle={'Filter the Criteria List'}
                                namespace={'polinesCancelFilterGrid'}
                                gridHeight={'400px'}
                                columnDefs={filtergridCols}
                                listTitle={'ADDED FILTERS'}
                                rowData={JSON.parse(JSON.stringify(this.state.filterRowData))}
                                // gridColumnDefs={this.props.filterCriteria.columnDefs}
                                filterGridAction={(val) => { this.setState({ filterRowData: val }) }}
                                disableRows={isNotFilter ? this.state.filterRowData.map((ele) => ele.accessor) : ['COMP']} // Revisit Exception Group + 
                                isAccordion={true}
                                //listTitle={this.props.listTitle}
                                fieldClassName={'tertiary_field'}
                                fieldWrapperHeight={'430px'}
                                applyFilterCriteria={() => this.getPOLinesList(this.state.filterRowData, false)}
                                resetFilterCriteria={() => {
                                    this.setState({ filterRowData: this.state.defaultFilters })
                                    this.getPOLinesList(this.state.defaultFilters, false)
                                }}
                                //securityEnabledOnFields={this.props.securityEnabledOnFields}
                                disableFilter={isNotFilter}
                                disableReset={isNotFilter}
                                disableInputFields={isNotFilter}
                            ></FilterGrid>
                            {columnDefs.length ? <EmbeddedList
                                columnInfo={columnInfo}
                                columnDefs={columnDefs}
                                pageSizes={PAGE_SIZES}
                                pageProps={pageProps}
                                isColumnResize={true}
                                rowData={polinesRowData}
                                onGridReady={params => this.onGridReady(params)}
                                updateShowHide={(data, currentPage) => this.props.updateShowHide({ ...data, from: 'exceptionitemdelete' })}
                                listProps={this.props}
                                menuItems={this.state.menuItems}
                                updateMenuItems={items => this.updateMenuItems(items)}
                                suppressSizeToFit={true}
                                listPredecessor={getListPredecessor('items')}
                                currentPage={'items'}
                                headerHeight={38}
                                rowHeight={26}
                                noPagination={false}
                                width={'725px'}
                                nameSpace={'poLinePropertiesActionData'}
                                gridHeight={'300px'}
                                hasGridActions={isNotFilter ? false : true}
                                resetDefault={this.resetDefault}
                                moreRecordsAvailable={moreRecordsAvailable}
                                sendApi={() => this.getVendorItemList()}
                                totalCount={totalCount}
                                sendApi={() => this.getPOLinesList(this.state.filterRowData, true)}
                                selectAllFlag={this.state.selectAllFlag}
                                updateSelectAllFlag={(val) => this.setState({ selectAllFlag: val })}
                                selectedRecordsObject={this.state.selectedRecordsObject}
                                hasSelectDeselectAll={true}
                                changeValuesOnSelectDeselect={this.changeValuesOnSelectDeselect}
                                onRowSelected={this.onRowSelected}
                                rowSelection={'multiple'}
                                hasSort={false} />
                                : ''}
                        </Box>
                    </>
                    }
                </DialogComponent>

            </>
        )
    }
}

const mapStateToProps = createStructuredSelector({
    propertiesCardsData: getCardsData(),
    cancelCardsData: getCancelData(),
    polineCardsData: getPoLineData(),
    radioData: getRadioData(),
    filtergridCols: getFilterGridData(),
    currentPage: makeSelectCurrentPage(),
    loading: getLoading(),
    authorizedComponentsList: makeSelectAuthorizedComponentsList(),
    poLinePropertiesActionData: makePOLineActionsPropertiesData(),

    isShowContextMenu: makeSelectShowContextMenu(),
    getFromSidePanel: getFromSidePanel(),
    activeTabData: getActiveTabData(),
    noDataExists: makeSelectNoDataExists(),
    noDataCallBack: makeSelectNoDataCallBack(),
    cutDownTabs: makeSelectCutDownTabs(),
    isMaxTabSizeExceeds: getMaxTabExceeds(),
    isMaxChildTabSizeExceeds: getMaxChildTabExceeds(),
    activeBreadcrumbId: getActiveBreadcrumbId(),
    activeTabId: getActiveTabId(),
    selectedRecordObj: makeSelectSelectedRecordObj(),
    fromPage: makeSelectFromPage(),
    columnDefs: makeColumnDefinitions(),
    currentDbSelectorProps: makeCurrentDbSelectorProps(),
    tabs: tabsSelector(),
    breadCrumbList: getItems(),
    selectedValue: makeSelectSelectedValue(),
    currentOwnerName: makeSelectCurrentOwnerName(),
    globalDecimalSeparator: selectGlobalDecimalSeparator(),
    globalNumberFormat: selectGlobalNumberFormat(),
    globalNumberSeparator: selectGlobalNumberSeparator(),
    globalFilterOptions: makeFilterOptions(),
    pageFilterOptions: makePageFilterOptions(),
    globalSecurityFilterList: makeSelectGlobalSelectFilterList(),
    errorMessageLabels: errorMessageLabels(),
})

function mapDispatchToProps(dispatch) {
    return {
        dispatch,
        setCurrentPage: (data) => dispatch(setCurrentPage(data)),
        getFilterData: (data) => dispatch(getFilterData(data)),
        getKeyChangeData: (data) => dispatch(getKeyChangeData(data)),
        getFilterCriteriaData: (data) => dispatch(getFilterCriteriaData(data)),
        getColumnDefs: (data) => dispatch(getColumnDefs(data)),
        updateState: (data) => dispatch(updateState(data)),
        getPOLinesList: (data) => dispatch(getPOLinesList(data)),
        updateShowHide: (data) => dispatch(updateShowHide(data)),
        onSetPageProps: (data) => dispatch(onSetPageProps(data)),
        applyCancelLines: (data) => dispatch(applyCancelLines(data))
    }
}

const withReducer = injectReducer({ key: 'poLinePropertiesCancel', reducer });
const withSaga = injectSaga({ key: 'poLinePropertiesCancel', saga });

const withConnect = connect(
    mapStateToProps,
    mapDispatchToProps,
);

export default compose(
    withConnect,
    withReducer,
    withSaga,
)(withStyles(styles)(ExceptionDelete));
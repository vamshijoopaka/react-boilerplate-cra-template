import React, { Component } from 'react';
import MultiSourceVendorAssign from 'containers/ItemEmbeddedListContainers/MultiSourceVendorAssign';
class MultiSourceVendorAssignDialog extends Component {
  render() {
    return (
      <>
        {this.props.isOpen && (
          <MultiSourceVendorAssign
            errorMessageLabels={this.props.errorMessageLabels}
            getLabelValue={this.props.getLabelValue}
            multiSourceLabelsData={this.props.multiSourceLabelsData}
            isOpen={this.props.isOpen}
            closeDialog={this.props.closeDialog}
            closeDialog={this.props.closeDialog}
            item={this.props.itemData}
          />
        )}
      </>
    );
  }
}
export default MultiSourceVendorAssignDialog;

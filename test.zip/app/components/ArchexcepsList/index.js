/**
 *
 * ArchexcepsList
 *
 */

import React, { useState, useEffect } from 'react';
// import PropTypes from 'prop-types';
// import styled from 'styled-components';

import { FormattedMessage } from 'react-intl';
import { AgGridReact } from 'ag-grid-react';
import messages from './messages';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';
import { get } from 'https';
import Pagination from '../Pagination';
import PaginationGrid from '../PaginationGrid';



import {
  getListPredecessor,
  getFilterDataFromLocalStorage,
  getSaveTypeFromCurrentPage,
  getTitleObj,
  getDefaultField,
  getDefaultSortPropsDetails,
  getDefaultSortFilterProps,
  setSortDataFromSortCriteria,
  getDefaultSortInfo,
  isEqualSortArrays,
  isColumnSortable,
  getSortedArray,
  getFilterDataFromCriteriaDetails
} from '../../utils/util';

import { directive } from '@babel/types';

import Spinner from 'components/Common/Spinner';
import ErrorDetail from 'components/Common/ErrorDetail';

import {
  ARCHEXCEP_LIST_PAGE,
  ARCHEXCEP_PROPERTIES,
  PAGE_SIZES,
  INITIAL_PAGE_PROPS,
} from './constants';

import {

  ARCHEXCEPS_LIST_PAGE,
  GLOBAL_FILTER_OPTIONS,
  COLUMN_HEADER_ACCESSOR,
  COLUMN_VALUE_ACCESSOR,
  COLUMN_POSITION,
  COLUMN_SHOW_HIDE_FLAG,
  COLUMN_HEADER_PREFIX_FLAG,
  COLUMN_FIELD_LEN,
  COLUMN_FIELD_NUM,
  COLUMN_FIELD_TYPE,
  DROPDOWN_FIELD,
  VALIDATION_FIELD,
  SHOW_HIDE_FIELD,
  archexcepDefaultSort,
  SAVED_BREADCRUMB_DATA_KEY,
  FILTER_CRITERIA_API_LIST_CONSTANTS,
  TEXT_ALERT,
  TEXT_OK,
  DATA_ACCESS_KEY
} from '../../components/common/constants';
import { isEqual } from 'lodash';



import {
  getDBSelectorFilterValues,
  prepareTooltipValues
} from 'utils/filterData';
// import {
//   SAVED_BREADCRUMB_DATA_KEY,
//   FILTER_CRITERIA_API_LIST_CONSTANTS,
//   TEXT_ALERT,
//   TEXT_OK,
//   COLUMN_FIELD_NUM
// } from '../../components/common/constants';
import LinkRenderer from '../CustomGrid/LinkRenderer';
import DateRenderer from '../CustomGrid/DateRenderer';
import ConfirmationDialog from 'components/common/ConfirmationDialog';
import FormattedMessageComponent from '../common/FormattedMessageComponent';

import NumberRenderer from 'components/CustomGrid/NumberRenderer';
import TextRenderer from 'components/CustomGrid/TextRenderer';
import DropdownRenderer from 'components/CustomGrid/DropdownRenderer';

const frameworkComponent = {
  'numberRenderer': NumberRenderer,
  'textRenderer': TextRenderer,
  'dropdownRenderer': DropdownRenderer,
  'dateRenderer': DateRenderer,
  'linkRenderer': LinkRenderer
};


class ArchexcepsList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isOpenEmbeddedList: false,
      selectedRecord: false,
      currentFilterProps: false,
      currentDbSelectorProps: false,
      isDataLoaded: false,
      isFromTabs: false,
      defaultSortProps: [],
      previousFilterValues: false,
      isFiltersChanged: false,
      showConfirmationDialog: false,
      dialogTitle: '',
      hasWarning: false,
      dialogInfo: '',
      isInitialAPICall: true,
      previousSortValues: false,
      paginationRecord: false,
      listSelectedRow: false,
    }
    this.onGridReady = this.onGridReady.bind(this);
    this.getRecordDataOnDirection = this.getRecordDataOnDirection.bind(this);
    this.setPageForwardDirection = this.setPageForwardDirection.bind(this);
    this.resetPagePropsAndSendApiCall = this.resetPagePropsAndSendApiCall.bind(this);
    // this.getDefaultSortPropsDetails = this.getDefaultSortPropsDetails.bind(this);
    this.onValueChanged = this.onValueChanged.bind(this);
    this.onRowSelected = this.onRowSelected.bind(this);
    this.forceUpdateHandler = this.forceUpdateHandler.bind(this);
    this.setFilterValues = this.setFilterValues.bind(this);
    this.setFilterValuesFromState = this.setFilterValuesFromState.bind(this);
    this.handleNoDataSets = this.handleNoDataSets.bind(this);
    // this.postSort = this.postSort.bind(this);
    this.sendInitialAPIForList = this.sendInitialAPIForList.bind(this);
  }

  onRowSelected(e) {
    let currentRecordData=JSON.parse(JSON.stringify(this.grid.api.getSelectedRows()[0]))
    this.props.setSelectedRecord(JSON.parse(JSON.stringify(this.grid.api.getSelectedRows()[0])), 'archexceps');
    this.props.setIsShowContextMenu(true);
    this.props.setDataInTabs('listSelectedRecord', JSON.parse(JSON.stringify(this.grid.api.getSelectedRows()[0]))); 
  }

  onValueChanged(data, rowIndex, colId) {
  }

  sendInitialAPIForList(filterProps, sortProps, pageProps) {
    this.resetPagePropsAndSendApiCall(filterProps, sortProps, pageProps, true, false);
  }

  resetValues = () => {
    this.setState({ isInitialAPICall: true });
    this.setState({ isDataLoaded: false });
    this.props.setInitialState();
    this.props.getArchexcepColumnDefs({ type: ARCHEXCEPS_LIST_PAGE });
  }

  componentDidMount() {
    this.resetValues();
    let isFilterValuesExists = this.setFilterValues();
    let properties = ARCHEXCEP_PROPERTIES;
    let filterOptions = GLOBAL_FILTER_OPTIONS;
    this.props.setGlobalGridConfigOptions(properties);
    let currentPage = ARCHEXCEPS_LIST_PAGE;
    this.props.onLoadCurrentPage(currentPage);
    if (!isFilterValuesExists) {
      this.props.onSetFilterProps(filterOptions);
    }
  }

  modValues = (values) => {
    let modValues = [];
    values.forEach(entry => {
      if (entry.accessor !== "BTOTL") {
        if (entry.accessor.substr(1, 3) == "GRP") {
          entry.prefixFlag = true;
        }
        modValues.push(entry);
      }
    }
    );
    return modValues;
  }

  setFilterValuesFromState(values, isAPICall) {
    let filterValues = [];
    const { columnDefs } = this.props.archexcepsListPage;
    if (columnDefs && columnDefs.length) {
      values.forEach((value) => {
        let isExists = columnDefs.find((column) => column[COLUMN_VALUE_ACCESSOR].trim() == value.accessor);
        if (isExists) {
          filterValues.push(value)
        }
      });
      if (filterValues && filterValues.length) {
        if (isAPICall) {
          this.resetPagePropsAndSendApiCall(filterValues, this.previousSortValues, INITIAL_PAGE_PROPS, true, false);
        }
        this.props.onSetFilterProps(filterValues);
        this.props.setGlobalFilterProps(filterValues);
        return filterValues;
      }
    } else {
      if (isAPICall) {
        this.resetPagePropsAndSendApiCall(values, this.previousSortValues, INITIAL_PAGE_PROPS, true, false);
      }
      this.props.onSetFilterProps(values);
      this.props.setGlobalFilterProps(values);
      return values;
    }
  }

  modValues = (values) => {
    let modValues = [];
    values.forEach(entry => {
      if (entry.accessor !== "BTOTL") {
        if (entry.accessor.substr(1, 3) == "GRP") {
          entry.prefixFlag = true;
        }
        modValues.push(entry);
      }
    }
    );
    return modValues;
  }

  setFilterValues() {
    const { history } = this.props;
    let isFilterValuesExists = false, isLocalStorageValuesExists = false;
    var paramsString = window.location.search;
    if (paramsString && paramsString.length) {
      let paramsArray = paramsString.split("?");
      if (paramsArray && paramsArray.length && paramsArray.length > 1) {
        let params = paramsArray[1].split("&");
        let tabId = params[0].split("=")[1];
        let breadCrumbId = params[1].split("=")[1];
        if (tabId && breadCrumbId) {
          this.setState({ isFromTabs: true });
        }
        let localStorageValues = getFilterDataFromLocalStorage(tabId, breadCrumbId);
        if (localStorageValues && Object.keys(localStorageValues) && Object.keys(localStorageValues).length) {
          isLocalStorageValuesExists = true;
          let archexcepData = localStorageValues[DATA_ACCESS_KEY], dbSelectorValues = [];
          if (archexcepData?.listSelectedRecord && Object.keys(archexcepData?.listSelectedRecord).length) {
            this.setState({listSelectedRow: archexcepData?.listSelectedRecord})
          }
          this.props.setSelectedRecord(false, false);
          if (archexcepData) {
            if (archexcepData.dbSelector && archexcepData.dbSelector.length) {
              dbSelectorValues = JSON.parse(JSON.stringify(archexcepData.dbSelector));
            }
            if (archexcepData.filterProps && archexcepData.filterProps.length) {
              isFilterValuesExists = true;
              let values = getDBSelectorFilterValues(dbSelectorValues, archexcepData.filterProps);
              values = this.modValues(values);
              this.setState({ currentFilterProps: JSON.parse(JSON.stringify(values)) });
              this.setFilterValuesFromState(values);
            } else if (dbSelectorValues && dbSelectorValues.length) {
              isFilterValuesExists = true;
              let dbValues = getDBSelectorFilterValues(dbSelectorValues, []);
              dbValues = this.modValues(dbValues);
              this.setFilterValuesFromState(dbValues);
            }
            if (archexcepData.pageProps && Object.keys(archexcepData.pageProps) && Object.keys(archexcepData.pageProps).length) {
              this.props.onSetPageProps(archexcepData.pageProps);
            }
            if (archexcepData.paginationRecord && Object.keys(archexcepData.paginationRecord) && Object.keys(archexcepData.paginationRecord).length) {
              this.setState({ paginationRecord: archexcepData.paginationRecord });
            }
            if (archexcepData.defaultFilterInfo && Object.keys(archexcepData.defaultFilterInfo) && Object.keys(archexcepData.defaultFilterInfo).length) {
              this.props.setDefaultFilterpropsForTabs(archexcepData.defaultFilterInfo);
            }
            //E3C-32463 5 jul sravanthi begin
            if (archexcepData.apiCallCount != undefined && parseInt(archexcepData.apiCallCount) >= 0) {
              this.props.setApiCallCount(archexcepData.apiCallCount);
            }
            //E3C-32463 5 jul sravanthi end
          }
          if (!isLocalStorageValuesExists && tabId && breadCrumbId) {
            history.push({ pathname: '/Dashboard' });
          }
        }
      }
    } else {
      history.push({ pathname: '/Dashboard' });
    }
    let filterOptions = GLOBAL_FILTER_OPTIONS;
    const { dbSelector } = this.props;
    if (!isFilterValuesExists) {
      let gbValues = getDBSelectorFilterValues(dbSelector, filterOptions);
      gbValues = this.modValues(gbValues);
      this.setState({ currentFilterProps: JSON.parse(JSON.stringify(gbValues)) });
      this.setFilterValuesFromState(gbValues);
    }
    return isFilterValuesExists;
  }


  onGridReady(params) {
    this.grid = params;
    if (this.state.listSelectedRow) {
      this.grid.api.forEachNode((node, index) => {
        let nodeData = node.data
        if (isEqual(nodeData, this.state.listSelectedRow)) {
          this.grid.api.getRowNode(index).selectThisNode(true)
        }
      });
    }
  }

  componentWillUnmount() {
    this.setState({ isDataLoaded: false });
    this.props.setInitialState();
  }

  onClickLink = (data, rowIndex) => {

    const { columnDefs, pageProps, filterProps, sortProps, defaultSortProps, filterCriteriaDetails } = this.props.archexcepsListPage;
    const { actualPageSize, actualPage } = pageProps;
    if (this.state.isFromTabs) {
      let pathname = 'ArchexcepsProperties',
        filterData = (filterProps && filterProps.length) ? filterProps : [],
        sortData = (sortProps && sortProps.length) ? sortProps : [],
        defaultFilterInfo = (filterCriteriaDetails && Object.keys(filterCriteriaDetails) && Object.keys(filterCriteriaDetails).length) ? filterCriteriaDetails : {},
        defaultSortInfo = (defaultSortProps && Object.keys(defaultSortProps) && Object.keys(defaultSortProps).length) ? defaultSortProps : {},
        tooltipData = prepareTooltipValues('archexceps', data, columnDefs, 'archexcepsproperties'),

        stateData = {
          data: JSON.parse(JSON.stringify(data)),
          fromPage: 'archexceps',
          rowIndex: (actualPageSize * actualPage) + rowIndex,
          totalCount: this.props.archexcepsListPage.totalCount,
          fromParent: true,
          columnDefs: columnDefs
        }
      this.props.setIsShowContextMenu(true);

      this.props.addChildTab(pathname, stateData, tooltipData, filterData,
        sortData, defaultSortInfo, defaultFilterInfo);

    } else {
      this.props.push({
        pathname: '/ArchexcepsProperties',
        state: {
          data: data,
          fromPage: 'archexceps',
          rowIndex: (actualPageSize * actualPage) + rowIndex,
          totalCount: this.props.archexcepsListPage.totalCount,
          fromParent: true,
          columnDefs: columnDefs
        }
      })
    }
  }

  handleNoDataSets(isColumns) {
    const { history } = this.props;
    const { archexceps, columnDefs } = this.props.archexcepsListPage;
    if (this.state.isDataLoaded) {
      if (isColumns && columnDefs && columnDefs.length) {
        //do nothing here
      } else if (archexceps && archexceps.length && columnDefs && columnDefs.length) {
        //do nothing here
      } else {
        this.props.setNoDataCallBackValue(true);
        this.showConfirmationDialog = true;
        this.noDatasets = true;
      }
    }
  }

  handleCloseChildTab = () => {
    var paramsString = window.location.search;
    if (paramsString && paramsString.length) {
      let paramsArray = paramsString.split("?");
      if (paramsArray && paramsArray.length && paramsArray.length > 1) {
        let params = paramsArray[1].split("&");
        let tabId = params[0].split("=")[1];
        let breadCrumbId = params[1].split("=")[1];
        this.props.removeCurrentRecordObj(tabId, breadCrumbId);
      }
    }
  }


  onRowDoubleClicked = (event) => {
    this.setState({ selectedRecord: event.data });
    this.setState({ isOpenEmbeddedList: true });
  };

  initialLoad(props, flag) {
    const { filterProps, sortProps, pageProps } = props.archexcepsListPage;
    let record;
    if (flag) {
      record = {}
    } else {
      record = this.getRecordDataOnDirection(pageProps.isForwardDirection);
    }
    if (pageProps) {
      if (pageProps.currentPage != 0) {
        this.props.setDataInTabs("paginationRecord", record);
      } else {
        this.props.setDataInTabs("paginationRecord", {});
      }
      this.props.onloadArchexceps(filterProps, sortProps, pageProps, pageProps.isForwardDirection, record);
    }
  }

  getRecordDataOnDirection(direction) {
    const { archexceps } = this.props.archexcepsListPage;
    if (!archexceps) {
      return;
    }
    if (!direction) {
      let count = this.props.apiCallCount;
      this.props.setApiCallCount(count - 1);
      return archexceps[0];
    } else {
      let count = this.props.apiCallCount;
      this.props.setApiCallCount(count + 1);
      return archexceps[archexceps.length - 1];
    }
  }


  loadArchexceps = () => {
    if (!this.props.archexcepsListPage.isAPIProgress) {
      this.initialLoad(this.props, false);
    }
  }

  setPageForwardDirection(flag) {
    const { pageProps } = this.props.archexcepsListPage;
    this.props.onSetPageProps({
      ...pageProps,
      actualPage: 0,
      currentPage: 0,
      totalCount: 10,
      isForwardDirection: flag
    });
  }

  resetPagePropsAndSendApiCall(filterProps, sortProps, pageProps, direction, record, exportFilterProps, exportFields, showHideColumns, searchReplaceValues) {
    this.setPageForwardDirection(true);
    this.props.onloadArchexceps(filterProps, sortProps, pageProps, direction, record, exportFilterProps, exportFields, showHideColumns, searchReplaceValues);
  }

  sendAPIWithExistingPageprops = (filterProps, sortProps, pageData, direction, record, exportFilterProps, exportFields, showHideColumns, searchReplaceValues) => {
    let recordData = JSON.parse(JSON.stringify(record));
    const { pageProps } = this.props.archexcepsListPage;
    let existingPageProps = {
      ...pageProps,
      isForwardDirection: true
    }
    this.props.onSetPageProps({
      ...pageProps,
      isForwardDirection: true
    });
    if (this.state.paginationRecord && Object.keys(this.state.paginationRecord) && Object.keys(this.state.paginationRecord).length) {
      recordData = JSON.parse(JSON.stringify(this.state.paginationRecord));
    }
    this.props.onloadArchexceps(filterProps, sortProps, existingPageProps, direction, recordData, exportFilterProps, exportFields, showHideColumns, searchReplaceValues, this.state.currentPage);
  }


  forceUpdateHandler() {
    this.forceUpdate();
  };

  handleClose = (flag) => {
    if (this.noDatasets) {
      this.noDatasets = false;
      this.handleCloseChildTab();
    }
    this.setState({ showConfirmationDialog: false });
  }

  handleFilterClose = () => {
    if (this.state.isFiltersChanged) {
      this.props.onSetFilterProps(this.state.previousFilterValues);
      this.props.setGlobalFilterProps(this.state.previousFilterValues);
      this.props.setChildTabFilterProps(this.state.previousFilterValues);
      this.setState({ isFiltersChanged: false });
    }
    this.props.setValueDataAPIFailureFlag(false);
    this.props.setValueDataFlag(false);
    this.props.handleCloseArchexcepsFilter();
    this.props.closeFilterComponent(true);
  }

  componentDidUpdate(prevProps, prevState) {
    const { sortProps, filterProps, pageProps, exportFilterProps, exportFields,
      showHideColumns, searchReplaceValues, columnDefs, updateColumnsList, archexceps,
      isColumnDefsLoaded, currentLoadedProps, defaultSortProps, isSortPropsChanged, columnInfo,
      sortCriteriaDetails, closeFiltersPopup, isValueDataAPICall, isValueDataAPIFailure, hasToResetDefaults, filterCriteriaDetails ,apiCallCount} = this.props.archexcepsListPage;//E3C-32463 5 jul sravanthi

    const { dbSelector, pageFilters } = this.props;

    if (closeFiltersPopup != prevProps.archexcepsListPage.closeFiltersPopup && closeFiltersPopup) {
      this.handleFilterClose();
    }
    if (pageProps && !isEqual(pageProps, prevProps.archexcepsListPage.pageProps)) {
      this.props.setDataInTabs("pageProps", JSON.parse(JSON.stringify(pageProps)));
    }
    //E3C-32463 5 jul sravanthi begin
    if (!isEqual(apiCallCount, prevProps.archexcepsListPage.apiCallCount)) {
      this.props.setDataInTabs("apiCallCount", apiCallCount);
    }
    //E3C-32463 5 jul sravanthi end
    if ((isValueDataAPICall != prevProps.archexcepsListPage.isValueDataAPICall) && isValueDataAPICall) {
      this.setState({ isInitialAPICall: false });
      this.setState({ previousFilterValues: filterProps })
      this.props.setValueDataFlag(false);
      this.props.setValueDataAPIFailureFlag(false);
      if (this.state.isFiltersChanged) {
        this.setState({ isFiltersChanged: false });
        this.props.handleCloseArchexcepsFilter();
        this.props.closeFilterComponent(true);
      }
    }

    if ((isValueDataAPIFailure != prevProps.archexcepsListPage.isValueDataAPIFailure) && isValueDataAPIFailure) {
      this.setState({ isInitialAPICall: false });
      if (!this.state.isDataLoaded && columnDefs && columnDefs.length) {
        this.setState({ isDataLoaded: true }, () => {
          this.handleNoDataSets();
        });
      }
      if (this.state.isFiltersChanged) {
        this.props.setValueDataAPIFailureFlag(false);
        this.setState({ showConfirmationDialog: true });
        this.setState({ hasWarning: true });
        this.setState({ dialogTitle: TEXT_ALERT });
        this.setState({ dialogInfoId: '28648' });
      }
    }

    if (JSON.stringify(archexceps) != JSON.stringify(prevProps.archexcepsListPage.archexceps) && !this.state.isDataLoaded && archexceps && columnDefs && columnDefs.length) {
      this.setState({ isDataLoaded: true }, () => {
        this.handleNoDataSets();
      });
    }

    if (this.props.location.search != prevProps.location.search) {
      this.resetValues();
      this.forceUpdateHandler();
      this.setFilterValues();
      this.setState({ state: this.state });
    }

    if ((pageProps != prevProps.archexcepsListPage.pageProps) && pageProps.isPageSizeChanged) {
      this.props.setApiCallCount(0);
      this.initialLoad(this.props, true);
      this.props.onSetPageProps({
        ...pageProps,
        isPageSizeChanged: false
      });
    }

    if ((JSON.stringify(columnDefs) != JSON.stringify(prevProps.archexcepsListPage.columnDefs)) && !prevProps.archexcepsListPage.columnDefs) {
      if (columnDefs && columnDefs.length) {
        if (!isColumnDefsLoaded) {
          this.props.setFlagColumnDefsLoaded(true);
        }
      } else if (!this.state.isDataLoaded) {
        this.setState({ isDataLoaded: true }, () => {
          this.handleNoDataSets(true);
        });
      }
    }

    if ((JSON.stringify(columnDefs) != JSON.stringify(prevProps.archexcepsListPage.columnDefs))) {
      if (columnDefs && columnDefs.length) {
        this.props.setGlobalColDefs(columnDefs);
        if (columnInfo) {
          this.props.setGlobalColumnInfo(columnInfo);
        }
      }
    }

    if (currentLoadedProps != prevProps.archexcepsListPage.currentLoadedProps && currentLoadedProps == 'sort' && sortProps && filterProps && pageProps) {
      this.props.setGlobalFilterProps(filterProps);
    }

    if (isColumnDefsLoaded != prevProps.archexcepsListPage.isColumnDefsLoaded && isColumnDefsLoaded && filterProps && filterProps.length && this.state.isInitialAPICall) {
      //this.resetPagePropsAndSendApiCall(filterProps, sortProps, pageProps, true, false);
      this.sendAPIWithExistingPageprops(filterProps, sortProps, pageProps, true, false);
    }

    if ((filterCriteriaDetails != prevProps.archexcepsListPage.filterCriteriaDetails)) {
      this.props.setDataInTabs("defaultFilterInfo", JSON.parse(JSON.stringify(filterCriteriaDetails)));
      if (filterCriteriaDetails && Object.keys(filterCriteriaDetails) && Object.keys(filterCriteriaDetails).length && columnDefs && columnDefs.length) {
        let list = getFilterDataFromCriteriaDetails(filterCriteriaDetails, columnDefs, ARCHEXCEPS_LIST_PAGE);
        if (list && list.length) {
          this.props.setGlobalFilterProps(list);
          this.props.onSetFilterProps(list);
        }
      }
    }

    if ((JSON.stringify(filterProps) != JSON.stringify(prevProps.archexcepsListPage.filterProps)) && pageProps && !pageFilters && filterProps) {
      this.props.setGlobalFilterProps(filterProps);
    }

    if (!isEqual(filterProps, prevProps.archexcepsListPage.filterProps) && filterProps && filterProps.length && pageProps && !this.state.isInitialAPICall) {
      this.props.setApiCallCount(0);
      this.resetPagePropsAndSendApiCall(filterProps, sortProps, pageProps, true, false);
    }

    if ((JSON.stringify(filterProps) != JSON.stringify(prevProps.archexcepsListPage.filterProps)) && filterProps && filterProps.length) {
      this.props.setChildTabFilterProps(filterProps);
      this.setState({ isFiltersChanged: true });
    }

    if (showHideColumns != prevProps.archexcepsListPage.showHideColumns) {
      this.props.getUpdatedColumnDefs({ type: ARCHEXCEPS_LIST_PAGE, userId: this.props.columnInfo['USERID'].trim(), 'record': showHideColumns });
    }

    if ((updateColumnsList != prevProps.archexcepsListPage.updateColumnsList) && updateColumnsList) {
      this.props.getArchexcepColumnDefs({ type: ARCHEXCEPS_LIST_PAGE });
      this.props.setUpdateColumnsList(true);
    }

    if (hasToResetDefaults && (prevProps.archexcepsListPage.hasToResetDefaults !== hasToResetDefaults)) {
      this.props.colResetDefault({ type: ARCHEXCEPS_LIST_PAGE, userId: this.props.columnInfo['USERID'].trim() });
    }

    if ((exportFilterProps != prevProps.archexcepsListPage.exportFilterProps) || (exportFields != prevProps.archexcepsListPage.exportFields)) {
      this.resetPagePropsAndSendApiCall(filterProps, sortProps, pageProps, true, false, exportFilterProps, exportFields);
    }

    if (searchReplaceValues != prevProps.archexcepsListPage.searchReplaceValues) {
      this.resetPagePropsAndSendApiCall(filterProps, sortProps, pageProps, true, false, false, false, false, searchReplaceValues);
    }
  }

  closeManageIems = (flag) => {
    this.setState({ isOpenEmbeddedList: false });
  }
  render() {
    const { filterProps, pageProps, totalCount, archexceps, isAPIProgress, columnDefs, loading, moreRecordsAvailable, updateColumnsList } = this.props.archexcepsListPage;

    return (
      <div>
        {loading && <Spinner loading type="list" />}

        {!this.props.error && archexceps && !archexceps[0] ?
          <ErrorDetail type="no_data" />
          : null}

        {(archexceps && archexceps.length && columnDefs.length && !updateColumnsList) ?
          (<div>
            <PaginationGrid
              rowSelection={'single'}
              onRowSelected={(e) => this.onRowSelected(e)}
              onValueChanged={this.onValueChanged}
              frameworkComponent={frameworkComponent}
              onClickLink={this.onClickLink}
              headerHeight={45}
              props={this.props}
              listPredecessor={getListPredecessor(ARCHEXCEPS_LIST_PAGE)}
              dataKey={ARCHEXCEP_LIST_PAGE}
              moreRecordsAvailable={moreRecordsAvailable}
              columnKey={COLUMN_VALUE_ACCESSOR}
              titleKey={COLUMN_HEADER_ACCESSOR}
              columnShowFlag={COLUMN_SHOW_HIDE_FLAG}
              prefixFlag={COLUMN_HEADER_PREFIX_FLAG}
              sendApi={this.loadArchexceps}
              columnData={columnDefs}
              isAPIProgress={isAPIProgress}
              rowData={archexceps}
              totalCount={totalCount}
              onRowDoubleClicked={this.onRowDoubleClicked}
              pageSizes={PAGE_SIZES}
              pageProps={pageProps}
              onGridReady={this.onGridReady}
              isColumnResize={true} />
          </div>) : null}

        <ConfirmationDialog
          hasError={this.state.hasWarning}
          isOpen={this.state.showConfirmationDialog}
          dialogTitle={this.state.dialogTitle}
          submitText={TEXT_OK}
          handleClose={e => this.handleClose(false)}
          handleCancel={e => this.handleClose(false)}
          handleSubmit={e => this.handleClose(true)}>
          <div>
            <FormattedMessageComponent id={this.state.dialogInfoId} />
          </div>
        </ConfirmationDialog>

      </div>
    );
  }
}


ArchexcepsList.propTypes = {

};

export default ArchexcepsList;
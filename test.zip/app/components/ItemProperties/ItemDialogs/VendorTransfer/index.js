import React, { Component } from 'react';
import VendorTransferContainer from 'containers/ItemEmbeddedListContainers/VendorTransferContainer/VendorTransfer';
import PropTypes from 'prop-types';
const propTypes = {
    globalSecurityFilterList: PropTypes.object,
    handleDialogClose: PropTypes.func.isRequired,
    isOpen: PropTypes.bool.isRequired,
    systemDate: PropTypes.string.isRequired,
    vendorTransferLabels: PropTypes.object.isRequired,
    getErrorMessage: PropTypes.func.isRequired,
}
class VendorTransferDialog extends Component {
    render() {
        return (
            <>
                {
                    this.props.isOpen &&
                    <VendorTransferContainer
                        {...this.props}
                    />
                }
            </>);
    }
}
VendorTransferDialog.propTypes = propTypes;
export default VendorTransferDialog;
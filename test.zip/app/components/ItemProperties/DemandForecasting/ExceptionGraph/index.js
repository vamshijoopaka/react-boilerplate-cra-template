import React from 'react';
import PropTypes from 'prop-types';
import HightchartsReact from 'highcharts-react-official';
// import Highcharts from 'highcharts/highstock';

import * as Highcharts from 'highcharts';
import more from 'highcharts/highcharts-more';
more(Highcharts);
class ExceptionGraph extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    const { series, categories, getLabelFromId, isMonthly } = this.props;
    const legendIndex = {
      'Acceptable Sales': 1,
      'Demand Forecast': 2,
      'Shipped': 3,
      'Promo': 4,
      'Lost': 5,
      'Bookings': 6,
    }
    let seriesModified = series.map(s => {
      s.name = getLabelFromId(s.displayId) || s.name;
      if (!['Demand Forecast', 'Acceptable Sales'].includes(s.key)) {
        return { 
          ...s, 
          stack: 'exception',
        }
      }
      return s;
    })
    seriesModified = seriesModified.sort((a, b) => {
      return legendIndex[b.key] - legendIndex[a.key]
    })
    const promoData = seriesModified.find(s => s.key === 'Promo')?.data;
    const shippedSeries = seriesModified.find(s => s.key === 'Shipped');
    if (promoData && shippedSeries?.data) {
      shippedSeries.data = shippedSeries.data.map((shipped, i) => {
        const promo = promoData[i];
        return shipped - promo > 0 ? shipped - promo : 0;
      })
    }
    const options = {
      chart: {
        type: 'column',
        scrollablePlotArea: {
          minWidth: isMonthly ? 6000 : 12000,
          scrollPositionX: 1,
        },
        scrollbar: {
          enabled: true,
        },
      },
      title: {
        text: getLabelFromId('50751') || 'Exception Graph',
      },
      xAxis: {
        categories,
      },
      yAxis: {
        title: {
          text: '',
        },
        stackLabels: {
          enabled: true,
          style: {
            fontWeight: 'bold',
            color:
              // theme
              (Highcharts.defaultOptions.title.style &&
                Highcharts.defaultOptions.title.style.color) ||
              'gray',
          },
        },
      },
      legend: {
        layout: 'vertical',
        align: 'right',
        verticalAlign: 'middle',
      },
      plotOptions: {
        series: {
          label: {
            connectorAllowed: false,
          },
          marker: {
            radius: 2,
          }
        },
        column: {
          stacking: 'normal',
          dataLabels: {
            enabled: false,
          },
        }
      },
      credits: {
        enabled: false,
      },
      series: seriesModified,
      responsive: {
        rules: [
          {
            condition: {
              maxWidth: 500,
            },
            chartOptions: {
              legend: {
                layout: 'horizontal',
                align: 'center',
                verticalAlign: 'bottom',
              },
            },
          },
        ],
      },
    };
    return <HightchartsReact highcharts={Highcharts} options={options} />;
  }
}

ExceptionGraph.propTypes = {
  series: PropTypes.array,
  categories: PropTypes.array,
};

export default ExceptionGraph;

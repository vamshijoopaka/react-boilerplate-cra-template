import { createSelector } from 'reselect';

const selectData = (state) => state.get('itemCopyReducer');
const errorMessageDomain = (state) => state.get('root').get('errorMessageLabels')

const makeSelectItemCopy = () =>
	createSelector(
		selectData,
		substate => substate.toJS(),
	);

const errorMessageLabels = (state, namespace) =>
	createSelector(
		errorMessageDomain,
		data => data
	)
const rowDataSelector = (state, namespace) =>
	createSelector(
		selectData,
		data => data.get('rowData')
	)

const columnDefsSelector = (state, namespace) =>
	createSelector(
		selectData,
		data => data.get('columnDefs')
	)

const columnInfoSelector = (state, namespace) =>
	createSelector(
		selectData,
		data => data.get('columnInfo')
	)

const loadingSelector = (state, namespace) =>
	createSelector(
		selectData,
		data => data.get('loading')
	)

const pagePropsSelector = (state, namespace) =>
	createSelector(
		selectData,
		data => data.get('pageProps')
	)

const columnFlagSelector = (state, namespace) =>
	createSelector(
		selectData,
		data => data.get('isColumnDefsLoaded')
	)

const filterPropsSelector = (state, namespace) =>
	createSelector(
		selectData,
		data => data.get('filterProps')
	)

const isAPIProgressSelector = (state, namespace) =>
	createSelector(
		selectData,
		data => data.get('isAPIProgress')
	)

const totalCountSelector = (state, namespace) =>
	createSelector(
		selectData,
		data => data.get('totalCount')
	)

const moreRecordsSelector = (state, namespace) =>
	createSelector(
		selectData,
		data => data.get('moreRecordsAvailable')
	)

const apiCallCountSelector = (state, namespace) =>
	createSelector(
		selectData,
		data => data.get('apiCallCount')
	)

const updateColumnsListSelector = (state, namespace) =>
	createSelector(
		selectData,
		data => data.get('updateColumnsList')
	)

export {
	selectData,
	rowDataSelector,
	columnDefsSelector,
	loadingSelector,
	pagePropsSelector,
	columnFlagSelector,
	filterPropsSelector,
	columnInfoSelector,
	isAPIProgressSelector,
	totalCountSelector,
	moreRecordsSelector,
	apiCallCountSelector,
	updateColumnsListSelector,
	errorMessageLabels,
	makeSelectItemCopy
}
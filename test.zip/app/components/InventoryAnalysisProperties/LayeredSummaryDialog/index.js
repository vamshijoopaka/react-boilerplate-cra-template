import React from 'react';
import PropTypes from 'prop-types';
import MuiDialog from '@material-ui/core/Dialog';
import MuiDialogTitle from '@material-ui/core/DialogTitle';
import MuiDialogContent from '@material-ui/core/DialogContent';
import { Button, DialogActions, withStyles } from '@material-ui/core';
import FormattedMessageComponent from 'components/common/FormattedMessageComponent';
import FormFieldsGenerator from 'components/common/FormFieldsGenerator';
import { LAYERED_SUMMARY_FORM_FIELDS } from './constants';
import { INVENTORY_ANALYSIS_PROPERTIES } from '../constants';

const styles = () => ({
  form: {
    border: 'solid 1px #AFAFAF',
    borderRadius: 4,
    margin: '10px 20px',
    boxSizing: 'border-box',
    width: 'calc(100% - 40px)',
    padding: 10,
  },
  formControl: {
    boxSizing: 'border-box',
    '& input': {
      border: 'none',
      borderBottom: 'solid 1px #000000',
    },
  },
  btn: {
    padding: 3,
  },
});

const Dialog = withStyles(() => ({
  root: {
    '& > div': {
      '& > div': {
        width: 400,
        minWidth: '0px !important',
        maxWidth: 'auto',
        minHeight: '0px !important',
        height: 'auto',
      },
    },
  },
}))(props => {
  const { classes, children, ...other } = props;
  return (
    <MuiDialog className={classes.root} {...other}>
      {children}
    </MuiDialog>
  );
});

const DialogTitle = withStyles(() => ({}))(props => {
  const { children, ...other } = props;
  return <MuiDialogTitle {...other}>{children}</MuiDialogTitle>;
});

const DialogContent = withStyles(() => ({}))(props => {
  const { children, ...other } = props;
  return <MuiDialogContent {...other}>{children}</MuiDialogContent>;
});

class LayeredSummaryDialog extends React.PureComponent {
  constructor(props) {
    super(props);
    const initialData = {};
    LAYERED_SUMMARY_FORM_FIELDS.forEach(field => {
      if (field.dataType === 'select') {
        initialData[field.FDFNAM] = field.valueSuggestionList[0].value;
      } else {
        initialData[field.FDFNAM] = '';
      }
    });
    this.state = {
      data: initialData,
    };
  }

  handleChangeValue = (key, value) => {
    this.setState(prevState => {
      const { data } = prevState;
      data[key] = value;
      return {
        data,
      };
    });
  };

  handleSubmit = () => {
    const { layeredSummary, onClose } = this.props;
    const { data } = this.state;
    onClose();
    layeredSummary(data);
  };

  render() {
    const { classes } = this.props;
    return (
      <Dialog open onClose={this.props.onClose}>
        <DialogTitle>
          <FormattedMessageComponent id="25269" />
        </DialogTitle>
        <DialogContent>
          <div className={classes.form}>
            <FormFieldsGenerator
              fieldsArray={LAYERED_SUMMARY_FORM_FIELDS}
              valuesArray={this.state.data}
              handleChangeValue={this.handleChangeValue}
              currentPage={INVENTORY_ANALYSIS_PROPERTIES}
              enableAddButton={() => {}}
              noMassMaintenance={true}
            />
          </div>
        </DialogContent>
        <DialogActions>
          <Button
            color="default"
            variant="outlined"
            size="medium"
            onClick={this.props.onClose}
          >
            <FormattedMessageComponent id="50771" />
          </Button>
          <Button
            color="primary"
            variant="contained"
            size="medium"
            onClick={this.handleSubmit}
          >
            <FormattedMessageComponent id="52758" />
          </Button>
        </DialogActions>
      </Dialog>
    );
  }
}

LayeredSummaryDialog.propTypes = {
  classes: PropTypes.object,
  onClose: PropTypes.func,
  layeredSummary: PropTypes.func,
};

export default withStyles(styles)(LayeredSummaryDialog);

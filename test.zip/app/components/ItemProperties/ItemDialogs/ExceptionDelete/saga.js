
import { call, put, takeLatest } from "redux-saga/effects";
import { API_URI } from "utils/url";
import { APPLY_CANCEL_LINES, GET_COLUMN_DEFS, GET_FILTERCRITERIA_DATA, GET_POLINES_LIST, UPDATE_SHOW_HIDE_COLUMNS } from "./constants";
import UrlFormatUtils from 'utils/sagaUrlFormatter';
import request from 'utils/request';
import {
  getFilterCriteriaDataSuccess, getFilterCriteriaDataFailure, getColumnDefsSuccess, getColumnDefsFailure,
  getPOLinesListSuccess, getPOLinesListFailure, updateShowHideSuccess, updateShowHideFailure, updateShowHide, applyCancelLinesSuccess, applyCancelLinesFailure
} from './actions';
import { urlEndPoints } from 'utils/urlJson';
import { OPTIONS } from "components/common/constants";
import { setShowHideColumns } from "utils/util";

export function* getFilterCriteriaData(action) {
  let filterColumnDefs;
  let url = `${API_URI}/${urlEndPoints['filterColumnDefs']}`;
  url = UrlFormatUtils.formalHeaderUrl(url, action.data.from);
  try {
    filterColumnDefs = yield call(request, url);
    yield put(getFilterCriteriaDataSuccess(filterColumnDefs));
  } catch (err) {
    yield put(getFilterCriteriaDataFailure(err));
  }
}

export function* getColumnDefs(action) {
  let filterColumnDefs;
  let subUrl = action.data.isResetDefault ? urlEndPoints['listColDefault'] : urlEndPoints['listHeader']
  let url = `${API_URI}/${subUrl}`;
  url = UrlFormatUtils.formalHeaderUrl(url, action.data.from);
  try {
    filterColumnDefs = yield call(request, url);
    yield put(getColumnDefsSuccess(filterColumnDefs, action.data.isItems));
    if (action.data.isResetDefault) {
      yield put(updateShowHide({ actionCode: 'D', record: setShowHideColumns(filterColumnDefs.fields), from: action.data.from }))
    }
  } catch (err) {
    yield put(getColumnDefsFailure(err, action.namespace));
  }
}

export function* updateColDefs(action) {
  let url = `${API_URI}/${urlEndPoints['updateListHeader']}`;
  let headerUrl = UrlFormatUtils.formalHeaderUrl(url, action.data.from, action.data.userId, action.data.actionCode);
  let postOptions = OPTIONS, headerCols, postData = {};
  if (action.data && action.data.record) {
    postData = action.data.record;
  }
  try {
    postOptions.body = JSON.stringify(postData);
    headerCols = yield call(request, headerUrl, postOptions);
    if (headerCols.ok) {
      const jsonResponse = yield headerCols.text();
      yield put(updateShowHideSuccess(JSON.parse(jsonResponse), action.data.actionCode))
    }
  } catch (err) {
    yield put(updateShowHideFailure(err))
  }
}

export function* getListData(action) {
  let itemJson;
  let post = JSON.parse(JSON.stringify(OPTIONS));
  post.body = JSON.stringify(action.data.record)
  let url = `${API_URI}/${urlEndPoints.ExceptionItemsList}`;
  url = UrlFormatUtils.formatUrlWithFilterAndSortOptions(url, action.data);
  try {
    itemJson = yield call(request, url, post);
    if (itemJson.ok) {
      const resp = yield itemJson.text();
      yield put(getPOLinesListSuccess(JSON.parse(JSON.stringify(resp))));
    } else {
      yield put(getPOLinesListFailure(''));
    }
  } catch (err) {
    yield put(getPOLinesListFailure(err));
  }
}

export function* applyCancelLines(action) {
  let itemJson;
  let post = JSON.parse(JSON.stringify(OPTIONS));
  post.body = JSON.stringify(action.data.body)
  let url = `${API_URI}/`;
  if (action.data.key === 'selectAll') {
    url = `${url}${urlEndPoints.itemsExceptionDeleteAll}` //openlinesCancelAll
    url = UrlFormatUtils.formatUrlWithFilterAndSortOptions(url, action.data);
  } else if (action.data.key === 'fewRecords') {
    url = `${url}${urlEndPoints.itemsExceptionDeleteMultiple}` //polinesCancelMultiple
  } else if (action.data.key === 'nonFilter') {
    url = `${url}${urlEndPoints.itemsExceptionDelete}` //openpolinesUpdate
    url = UrlFormatUtils.formatUrlWithFilterAndSortOptions(url, action.data);
  }
  try {
    itemJson = yield call(request, url, post);
    if (itemJson.ok) {
      const resp = yield itemJson.text();
      yield put(applyCancelLinesSuccess(JSON.parse(JSON.stringify(resp))));
    } else {
      yield put(applyCancelLinesFailure(''));
    }
  } catch (err) {
    yield put(applyCancelLinesFailure(err));
  }
}

export default function* poLinePropertiesPageCancelSaga() {
  yield takeLatest(GET_FILTERCRITERIA_DATA, getFilterCriteriaData);
  yield takeLatest(GET_COLUMN_DEFS, getColumnDefs)
  yield takeLatest(GET_POLINES_LIST, getListData)
  yield takeLatest(UPDATE_SHOW_HIDE_COLUMNS, updateColDefs)
  yield takeLatest(APPLY_CANCEL_LINES, applyCancelLines)
}
/**
 * Copyright © 2018, JDA Software Group, Inc. ALL RIGHTS RESERVED.
 * <p>
 * This software is the confidential information of JDA Software, Inc., and is licensed
 * as restricted rights software. The use,reproduction, or disclosure of this software
 * is subject to restrictions set forth in your license agreement with JDA.
 */
import React from 'react';
import { shallow } from 'enzyme';
import toJson from 'enzyme-to-json';

import Spinner from '../index';

describe('<Spinner />', () => {
  it('should match snaptshot', () => {
    const props = {
      loading: true,
      type: 'list',
    };
    const wrapper = shallow(<Spinner {...props} />);
    expect(toJson(wrapper)).toMatchSnapshot();
  });
  it('should match snaptshot', () => {
    const props = {
      loading: false,
      type: 'detail',
    };
    const wrapper = shallow(<Spinner {...props} />);
    expect(toJson(wrapper)).toMatchSnapshot();
  });
  it('should match snaptshot', () => {
    const props = {
      loading: true,
      type: 'detail',
    };
    const wrapper = shallow(<Spinner {...props} />);
    expect(toJson(wrapper)).toMatchSnapshot();
  });
  it('should match snaptshot', () => {
    const props = {
      loading: true,
      type: 'panelDetail',
    };
    const wrapper = shallow(<Spinner {...props} />);
    expect(toJson(wrapper)).toMatchSnapshot();
  });
});

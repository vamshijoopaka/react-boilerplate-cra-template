import { call, put, takeLatest } from 'redux-saga/effects';
import request from 'utils/request';
import UrlFormatUtils from 'utils/sagaUrlFormatter';
import { API_URI } from 'utils/url';
import { urlEndPoints } from 'utils/urlJson';
import {
	GET_ITEM_ON_DEAL_LIST,
	GET_ITEM_ON_DEAL_COLUMN_DEFINITION,
	GET_ITEM_ON_DEAL_UPDATE_COLUMN_DEFINITION,
	RESET_DEFAULTS,
	GET_ITEMS_LIST,
	GET_DEAL_COLUMN_DEFS,
	GET_DEAL_ALLOWANCE_DETAIL,
	ITEM_ON_DEAL_DETAIL,
	ADD_RECORD,
	REMOVE_RECORD,
	UPDATE_RECORD,
	ITEM_ON_DEAL_UPDATE,
} from './constants';
import {
	setItemOnDealListSuccess,
	setItemOnDealListFailure,

	setItemOnDealListColumnDefs,
	setItemOnDealListColumnDefsFailure,
	updateColumnDefsSuccess,
	updateColumnDefsFailure,
	setItemsListSuccess,
	setItemsListFailure,

	getLabelListSucess,
	getLabelListFailure,
	getValueListSucess,
	getValueListFailure,
	getDealAllowanceValueListSucess,
	getDealAllowanceValueListFailure,
	onAddRecSuccess,
	onAddRecFailure,
	onRemoveRecSuccess,
	onRemoveRecFailure,
	onUpdateRecSuccess,
	onUpdateRecFailure,
	itemOnDealUpdateSuccess,
	itemOnDealUpdateFailure,
	resetDefaultSuccess,
	resetDefaultFailure
} from './action';

import { OPTIONS } from 'components/common/constants';

export function* getItemOnDealList(action) {
	let url = `${API_URI}/${urlEndPoints['warehousesList']}`;
	url = UrlFormatUtils.formatUrlWithFilterAndSortOptions(url, action.data);
	try {
		let items;
		let postOptions = JSON.parse(JSON.stringify(OPTIONS));
		let postData = {};
		postOptions.body = JSON.stringify(postData);
		items = yield call(request, url, postOptions);
		if (items.ok) {
			const jsonResponse = yield items.text()
			yield put(setItemOnDealListSuccess(JSON.parse(jsonResponse)))
		}

	} catch (err) {
		yield put(setItemOnDealListFailure(err));
	}
}

export function* getColumnDefs(action) {
	let url = `${API_URI}/${urlEndPoints['listHeader']}`;
	let headerUrl = UrlFormatUtils.formalHeaderUrl(url, action.data.type);
	try {
		const headerCols = yield call(request, headerUrl);
		yield put(setItemOnDealListColumnDefs(headerCols));
	} catch (err) {
		yield put(setItemOnDealListColumnDefsFailure(err));
	}
}

export function* updateColumnDefs(action) {
	let url = `${API_URI}/${urlEndPoints['updateListHeader']}`;
	let headerUrl = UrlFormatUtils.formalHeaderUrl(url, action.data.type, action.data.userId,action.data.actionCode);
	let postOptions = JSON.parse(JSON.stringify(OPTIONS)), headerCols, postData = {};
	if (action.data && action.data.record) {
		postData = action.data.record;
	}
	try {
		postOptions.body = JSON.stringify(postData);
		headerCols = yield call(request, headerUrl, postOptions);
		if (headerCols.ok) {
			const jsonResponse = yield headerCols.text()
			yield put(updateColumnDefsSuccess(JSON.parse(jsonResponse)))
		}
	} catch (err) {
		yield put(updateColumnDefsFailure(err))
	}
}

export function* resetDefaults(action) {
	let url = `${API_URI}/${urlEndPoints['listColDefault']}`;
	let headerUrl = UrlFormatUtils.formalHeaderUrl(url, action.data.type, action.data.userId);
	let headerCols;
	try {
		headerCols = yield call(request, headerUrl);
		yield put(setItemOnDealListColumnDefs(headerCols))
		yield put(resetDefaultSuccess(headerCols))
	} catch (err) {
		yield put(resetDefaultFailure(err))
	}
}

export function* getItemsList(action) {

	let url = `${API_URI}/${urlEndPoints.itemsdetail}`;
	url = UrlFormatUtils.formatVendorPropertiesUrl(url, action.data);
	try {
		let items;
		items = yield call(request, url);
		yield put(setItemsListSuccess(items));
	} catch (err) {
		yield put(setItemsListFailure(err));
	}
}
export function* getLabelsData(action) {
	let url = `${API_URI}/${urlEndPoints["vendorPropertiesLabels"]}`;
	url = UrlFormatUtils.formatVendorPropertiesUrl(url, action.data);
	try {
		const labelData = yield call(request, url);
		yield put(getLabelListSucess(labelData));
	} catch (err) {
		yield put(getLabelListFailure(err));
	}
}

export function* getDealDetailData(action) {
	var url = `${API_URI}/deals/itemDealHeader`;
	url = UrlFormatUtils.formatDealPropertiesUrl(url, action.data);
	try {
		let details;
		details = yield call(request, url);
		yield put(getValueListSucess(details));
	} catch (err) {
		yield put(getValueListFailure(err));
	}
}
export function* getDealAllownaceDetailData(action) {
	let url = `${API_URI}/deals/itemDealAllowance`;
	url = UrlFormatUtils.formatDealPropertiesUrl(url, action.data);
	try {
		let details;
		details = yield call(request, url);
		yield put(getDealAllowanceValueListSucess(details));
	} catch (err) {
		yield put(getDealAllowanceValueListFailure(err));
	}
}
export function* addRecord(action) {
	let url = `${API_URI}/${urlEndPoints['addDealAllowance']}`;
	let items;
	let postOptions = JSON.parse(JSON.stringify(OPTIONS)), postData;
	try {
		if (action.data) {
			postData = action.data;
			postOptions.body = JSON.stringify(postData);
			items = yield call(request, url, postOptions);
			if (items.ok) {
				yield put(onAddRecSuccess({ data: {...action.data}}))
			}
		}
	} catch (err) {
		yield put(onAddRecFailure(JSON.parse(err)))
	}
}
export function* removeRecord(action) {
	let url = `${API_URI}/${urlEndPoints['deleteDealAllowance']}`;
	let items;
	let postOptions = JSON.parse(JSON.stringify(OPTIONS)),postData;
	try {
		if (action.data) {
			postData = action.data;
			postOptions.body = JSON.stringify(postData);
			items = yield call(request, url, postOptions);
			if (items.ok) {
				yield put(onRemoveRecSuccess({ data: {...action.data}}))
			}
		}
	} catch (err) {
		yield put(onRemoveRecFailure(JSON.parse(err)))
	}
}
export function* updateRecord(action) {
	let url = `${API_URI}/${urlEndPoints['modifyDealAllowance']}`;
	let items;
	let postOptions = JSON.parse(JSON.stringify(OPTIONS));
	try {
		if (action.data) {
			postOptions.body = JSON.stringify(action.data);
			items = yield call(request, url, postOptions);
			if (items.ok) {
				let payloadArray = Array.isArray(action.data) ? action.data : [];
                if (!Array.isArray(action.data) && typeof action.data === 'object')
					payloadArray.push(action.data);
					
				yield put(onUpdateRecSuccess({ data: [...payloadArray]}))
			}
		}
	} catch (err) {
		yield put(onUpdateRecFailure(JSON.parse(err)))
	}
}
export function* itemOnDealDataUpdate(action) {
	let url = `${API_URI}/deals/applyChangesToItemHeader`;
	try {
		let data;
		let postOptions = JSON.parse(JSON.stringify(OPTIONS));
		if (action.data) {
			postOptions.body = JSON.stringify(action.data);
			data = yield call(request, url, postOptions);
		}
		if (data.ok) {
			const jsonResponse = yield data.text();
			yield put(itemOnDealUpdateSuccess(jsonResponse));
		}
	} catch (err) {
		yield put(itemOnDealUpdateFailure(err));
	}
}


export default function* itemOnDealSaga() {
	yield takeLatest(GET_ITEM_ON_DEAL_LIST, getItemOnDealList);
	yield takeLatest(GET_ITEM_ON_DEAL_COLUMN_DEFINITION, getColumnDefs),
	yield takeLatest(GET_ITEM_ON_DEAL_UPDATE_COLUMN_DEFINITION, updateColumnDefs);
	yield takeLatest(RESET_DEFAULTS, resetDefaults);
	yield takeLatest(GET_ITEMS_LIST, getItemsList);
	yield takeLatest(GET_DEAL_COLUMN_DEFS, getLabelsData);
	yield takeLatest(ITEM_ON_DEAL_DETAIL, getDealDetailData);
	yield takeLatest(GET_DEAL_ALLOWANCE_DETAIL, getDealAllownaceDetailData);
	yield takeLatest(ADD_RECORD, addRecord);
	yield takeLatest(REMOVE_RECORD, removeRecord);
	yield takeLatest(UPDATE_RECORD, updateRecord);
	yield takeLatest(ITEM_ON_DEAL_UPDATE, itemOnDealDataUpdate);
}
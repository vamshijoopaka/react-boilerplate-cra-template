/** Change Log
 * LogStart --  E3C-33195 - Kumar A- 16 September,2021 - 2022.1.0.0 Unified Product
 *              Story: E3C-33195 --Code Cleanup
*/
import {
    DASHBOARD_CONTROL_GET_FIELD_LIST,
    DASHBOARD_CONTROL_GET_FIELD_LIST_SUCCESS,
    DASHBOARD_CONTROL_GET_FIELD_LIST_FAILURE,
} from './constants';

import {
    SET_CURRENT_PAGE_NAME
} from '../../common/constants';

export function getFieldList(data) {
    return {
        type: DASHBOARD_CONTROL_GET_FIELD_LIST,
        data
    }
}
export function getFieldListSuccess(data) {
    return {
        type: DASHBOARD_CONTROL_GET_FIELD_LIST_SUCCESS,
        data
    }
}
export function getFieldListFailure(data) {
    return {
        type: DASHBOARD_CONTROL_GET_FIELD_LIST_FAILURE,
        data
    }
}
export function setGlobalCurrentPage(pageName){
    return {
        type: SET_CURRENT_PAGE_NAME,
        pageName
    }
}
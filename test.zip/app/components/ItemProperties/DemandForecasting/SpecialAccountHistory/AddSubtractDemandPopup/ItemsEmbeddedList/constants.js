export const MENU_ITEMS = [
  {
    label: '52735',
    key: 'itemsFilter',
    hasSubMenu: false,
    isDisable: false,
  },
];

export const LABEL_COMPANY_CI = "35136";

export const CONTEXT_MENU_EXCEPTION = [
    {
        label: '37244',
        key: "expDetail",
        hasSubMenu: false,
        isDisable: true
    },
    {
        label: '52808',
        key: "expAdd",
        hasSubMenu: false,
        isDisable: true
    },
    {
        label: '50129',
        key: "expRemove",
        hasSubMenu: false,
        isDisable: true
    }
];

export const ADD_EXCEPTION = {
    "ECATG": "",
    "ECCOMP": "E3T",
    "ECLANG": "",
    "ECLST1": "",
    "ECLST2": "",
    "ECLST3": "",
    "ECLST4": "",
    "ECRECD": "",
    "ECSTAT": "",
    "ECSTS": "1",
    "EXTYPE": "", //ECTYPE
    "ECVAL1": "",
    "ECVAL2": "",
    "ECVAL3": "",
    "ECVAL4": "",
    "ECWHSE": "",
    "EDESC": ""
}
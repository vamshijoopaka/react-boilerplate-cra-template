import React, { PureComponent } from 'react';
import HighchartsReact from 'highcharts-react-official';
import PropTypes from 'prop-types';
const propTypes = {
    data: PropTypes.shape({
        ONHND: PropTypes.object,
        SSTCK: PropTypes.object,
        PURPR: PropTypes.object,
        PUR01: PropTypes.object,
        PURCH: PropTypes.object,
    }).isRequired,
    getMessageText: PropTypes.func.isRequired,
}
class DepletionGraph extends PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            options: {
                chart: {
                    type: 'column',
                    scrollablePlotArea: {
                        minWidth: 8000,
                        scrollPositionX: 0
                    },
                    scrollbar: {
                        enabled: true
                    },
                    height: props.height || null,

                },
                accessibility: {
                    description: 'Depletion Graph'
                },
                title: {
                    text: props.getMessageText('50924') || 'Depletion Graph'
                },
                credits: {
                    enabled: false
                },
                xAxis: {
                    allowDecimals: true,
                    // tickInterval: 24 * 3600 * 1000,
                    labels: {
                        overflow: 'justify',
                        step: 1,
                        rotation: -90
                    },
                    // type: 'datetime',
                    // lineWidth: 2,
                    // dateTimeLabelFormats: {
                    //     day: '%e/%m/%Y'
                    // },
                    startOnTick: true,
                    // left: 8,
                    // min: (props.startDate && props.startDate.setDate(props.startDate.getDate() + 3)) || Date.UTC(2020),
                    categories: props.data.categories,
                },
                tooltip: {
                    // xDateFormat: '%e/%m/%Y',
                    shared: true
                },
                plotOptions: {
                    series: {
                        // lineWidth: 2,
                        // pointWidth: 15,
                        // pointInterval: 24 * 3600 * 1000,
                        // pointStart: (props.startDate && Date.parse(props.startDate)) || Date.UTC(2020),
                        scrollbar: {
                            enabled: true
                        },
                        stacking: 'normal',
                        marker: {
                            enabledThreshold: 1,
                            radius: 1
                        },
                        // pointPlacement: 'on',
                        // tickmarkPlacement: 'on',
                        // scrollPositionX: 3
                    }
                },
                series: [{
                    name: props.getMessageText('50434') || 'On Hand',
                    trackByArea: true,
                    point: {
                    },
                    data: props.data.ONHND.graphData?.slice(0, 365),
                    stack: 'sales',
                    legendIndex: 0,
                    color: '#048BD0',
                },
                {
                    name: props.getMessageText('51071') || "Open PO",
                    data: props.data.PURPR && props.data.PURPR.highestValueIndividual ? props.data.PURPR.graphData?.slice(0, 365) : false,
                    stack: 'sales',
                    legendIndex: 1,
                    color: '#FBC02D',
                },
                {
                    name: props.getMessageText('51072') || "Today's SOQ",
                    data: props.data.PUR01 && props.data.PUR01.highestValueIndividual ? props.data.PUR01.graphData?.slice(0, 365) : false,
                    stack: 'sales',
                    legendIndex: 2,
                    color: '#FBC02D',
                },
                {
                    name: props.getMessageText('51073') || 'Future SOQ',
                    data: props.data.PURCH && props.data.PURCH.highestValueIndividual ? props.data.PURCH.graphData?.slice(0, 365) : false,
                    stack: 'sales',
                    legendIndex: 3,

                    color: '#27AE60',
                },
                {
                    name: props.getMessageText('50430') || 'SStock',
                    data: props.data.SSTCK.graphData?.slice(0, 365),
                    legendIndex: 4,
                    color: '#e91e63',
                    type: 'spline',
                    zIndex: 10
                },
                ].reverse().filter(series => series.data)
            }
        }
        this.chart = React.createRef();
    }

    componentDidUpdate(prevProps) {
        const { height } = this.props;
        if (height && height != prevProps.height && this.chart && this.chart.current && this.chart.current.chart) {
            this.chart.current.chart.setSize(undefined, height)
        }
    }
    render() {
        return (
            <div style={{ maxWidth: '100%', width: '100%' }}>
                <HighchartsReact options={this.state.options} ref={this.chart} />
            </div>
        );
    }
}
DepletionGraph.propTypes = propTypes;
export default DepletionGraph;
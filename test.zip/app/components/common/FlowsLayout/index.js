import React from 'react';
import { Route } from 'react-router-dom';
import theme from 'jda-gcp-theme';
import { Box, IconButton } from '@material-ui/core';

import TabsComponent from '../TabsComponent';
import Breadcrumb from '../Breadcrumb';
import '../TabsComponent/styles.scss';
import { withStyles } from '@material-ui/core/styles';
import { compose } from 'redux';
import { connect } from 'react-redux';
// import { VendorsListPage } from '../../../containers/VendorsListPage';
// import { BuyersListPage } from '../../../containers/BuyersListPage';
import {
    getSideBarList,
    getRandomString,
    getTabData,
    getPageContextElems,
    getPathname,
    capitalizeFirstLetter
} from 'utils/util';

import {
    getFilterDataValues,
    getTabsSize,
    getTabItemsSize,
    getListNameFromPage,
    getPropertiesListFromPage,
    getPropertiesPageFromList,
    getDisplayNameFromPathNameForProperties
} from 'utils/filterData';

import {
    SAVED_BREADCRUMB_DATA_KEY,
    TABS_SIZE,
    BREADCRUMB_SIZE
} from 'components/common/constants';

const styles = theme => ({
    showContextMenu: {
        display: 'block',
        visibility: 'visible'
    },
    hideContextMenu: {
        display: 'none',
        visibility: 'hidden'
    },
    flowsLayout: {
        '@media (max-width: 1200px)': {
            display: 'inline-block',
        }
    },
    flowsLayoutOverflow: {
        'overflow-x': 'auto'
    },
    flowsLayoutPostion: {
        position: 'relative'
    }
});

class FlowsLayout extends React.Component {
    constructor(props) {
        super(props);
        this.state = { tabs: [], selectedValue: '' };
        this.updateTabAndHistory = this.updateTabAndHistory.bind(this);
    }

    componentDidMount() {
        const { addTab, history, getFromSidePanel, currentDbSelectorProps } = this.props;
        let tabPayload = getTabData(this.props.selectedItem.toLowerCase());
        const randomString = getRandomString(5);
        tabPayload.displayName = tabPayload.displayName;
        tabPayload.tab_id = randomString;
        tabPayload.cutdownItems = [];
        tabPayload.items = [{
            displayName: getListNameFromPage(tabPayload.type),
            name: tabPayload.type,
            id: randomString,
            show: true,
            path: tabPayload.path,
            item_data: {
                filterProps: [],
                sortProps: [],
                showHideProps: [],
                dbSelector: currentDbSelectorProps,
                toolTipData: []
            }
        }];
        tabPayload.selectedBreadcrumbId = randomString;
        tabPayload.menuItems = getPageContextElems(tabPayload.type);
        if (!localStorage.getItem(SAVED_BREADCRUMB_DATA_KEY)) {
            this.updateTabAndHistory(addTab, tabPayload, false, randomString, history);
        } else {
            let jsonData = JSON.parse(localStorage.getItem(SAVED_BREADCRUMB_DATA_KEY));
            if (jsonData.tabs && jsonData.tabs.length && jsonData.selectedTabIndex != -1 && getFromSidePanel != true) {
                //todo
            } else {
                this.updateTabAndHistory(addTab, tabPayload, false, randomString, history);
            }
        }
    }

    /**
     * Update tab and history on add tab
     */
    updateTabAndHistory(addTab, tabPayload, isFromLeftPanel, randomString, history) {
        const { tabs, cutDownTabs } = this.props;
        let tabsSizes = TABS_SIZE,
            currentTabSizes = getTabsSize(this.props.tabs),
            cutDownTabSizes = getTabsSize(cutDownTabs);
        if ((currentTabSizes + cutDownTabSizes) == tabsSizes) {
            return;
        }
        if ((currentTabSizes + cutDownTabSizes) <= tabsSizes) {
            addTab(tabPayload);
            this.props.setSidePanelData(isFromLeftPanel);
            history.push({ pathname: tabPayload.path, search: `?tab_id=${randomString}&item_id=${randomString}` });
        }
    }

    componentDidUpdate(prevProps) {
        // const contextMenu = this.updateBreadCrumbContextMenu();
        const { addTab, history, getFromSidePanel, randomTabId, tabs, currentDbSelectorProps } = this.props;
        let lastVisibleTab;
        if (tabs && tabs.length) {
            lastVisibleTab = tabs.map((tab) => tab.show).lastIndexOf(true);
            if ((lastVisibleTab > -1) && getFromSidePanel) {
                let tabPayload = getTabData(this.props.selectedItem.toLowerCase());
                tabPayload.tab_id = randomTabId;
                tabPayload.displayName = tabPayload.displayName;
                tabPayload.cutdownItems = [];
                tabPayload.items = [{
                    displayName: getListNameFromPage(tabPayload.type),
                    name: tabPayload.type,
                    id: randomTabId,
                    show: true,
                    path: tabPayload.path,
                    item_data: {
                        filterProps: [],
                        sortProps: [],
                        showHideProps: [],
                        dbSelector: currentDbSelectorProps,
                        toolTipData: []
                    }
                }];
                tabPayload.selectedBreadcrumbId = randomTabId;
                tabPayload.menuItems = getPageContextElems(tabPayload.type);
                this.updateTabAndHistory(addTab, tabPayload, false, randomTabId, history);
            }
        }
    }

    render() {
        const { classes } = this.props;
        const { addItem, tabs, setSelectedTab, history, setSelectedTabOnNavigation, menuItems, setIsShowContextMenu,
            isShowContextMenu, closeTab, activeBreadcrumbId, closeBreadcrumb, cutDownTabs, onClickCutDownTab, closeAllTabs } = this.props;
        return (
            <div className={classes.flowsLayoutPostion}>
                <div className={classes.flowsLayoutOverflow}>
                    <div className={classes.flowsLayout}>
                        <div className={'tabs'}>
                            <TabsComponent updateSelectedItem={this.props.updateSelectedItem}
                                removeParentCutdownTab={this.props.removeParentCutdownTab}
                                setTabsData={this.props.setTabsData}
                                closeAllTabs={closeAllTabs}
                                onClickCutDownTab={onClickCutDownTab}
                                cutDownTabs={cutDownTabs}
                                closeTab={closeTab}
                                setIsShowContextMenu={setIsShowContextMenu}
                                setSelectedTabOnNavigation={setSelectedTabOnNavigation}
                                activeTabId={this.props.activeTabId}
                                tabs={tabs}
                                setSelectedTab={setSelectedTab}
                                activeBreadcrumbId={activeBreadcrumbId}
                                clearUserErrorMessage={this.props.clearUserErrorMessage}
                                history={history}
                                errorMessages={this.props.errorMessages} />
                        </div>
                        <Breadcrumb {...this.props} />
                    </div>
                </div>
            </div>
        );
    }
}

// export default FlowsLayout;

export default compose(
    withStyles(styles),
)(FlowsLayout);
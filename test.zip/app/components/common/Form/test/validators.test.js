import * as errors from '../errors';
import * as validators from '../validators';

describe('validators.email', () => {
  it('should return null if the email address is valid', () => {
    expect(validators.email('dog@pets.com')).toEqual(null);
  });

  it('should return an error string if the email address is missing an ampersand', () => {
    expect(validators.email('dogpets.com')).toEqual(errors.EMAIL);
  });

  it('should return an error string if the email address is missing a domain', () => {
    expect(validators.email('dog@')).toEqual(errors.EMAIL);
  });

  it('should return an error string if the email address is missing a top-level domain', () => {
    expect(validators.email('dog@pets')).toEqual(errors.EMAIL);
  });
});

describe('validators.nonEmpty', () => {
  it('should return null if the input is non-empty string', () => {
    expect(validators.nonEmpty('foo')).toEqual(null);
  });

  it('should return an error string if the input is undefined', () => {
    expect(validators.nonEmpty(undefined)).toEqual(errors.NON_EMPTY);
  });

  it('should return an error string if the input is null', () => {
    expect(validators.nonEmpty(null)).toEqual(errors.NON_EMPTY);
  });

  it('should return an error string if the input is an empty string', () => {
    expect(validators.nonEmpty('')).toEqual(errors.NON_EMPTY);
  });

  it('should return an error string if the input contains only whitespace', () => {
    expect(validators.nonEmpty('  \t\n')).toEqual(errors.NON_EMPTY);
  });
});

describe('validators.passwordConfirm', () => {
  it('should return null if passwords match', () => {
    const values = { newPassword: 'foo', passwordConfirm: 'foo' };
    expect(validators.passwordConfirm(values.passwordConfirm, values)).toEqual(
      null,
    );
  });

  it("should return an error if passwords don't match", () => {
    const values = { newPassword: 'foo', passwordConfirm: 'foobar' };
    expect(validators.passwordConfirm(values.passwordConfirm, values)).toEqual(
      errors.PASSWORD_CONFIRM,
    );
  });

  it("doesn't check for valid passwords, it only checks if they match", () => {
    const emptyValues = { newPassword: '', passwordConfirm: '' };
    expect(
      validators.passwordConfirm(emptyValues.passwordConfirm, emptyValues),
    ).toEqual(null);

    const nullValues = { newPassword: null, passwordConfirm: null };
    expect(
      validators.passwordConfirm(nullValues.passwordConfirm, nullValues),
    ).toEqual(null);

    const undefinedValues = {};
    expect(
      validators.passwordConfirm(
        undefinedValues.passwordConfirm,
        undefinedValues,
      ),
    ).toEqual(null);
  });
});

describe('validators.passwordChange', () => {
  it('should return null if newPasswords different than currentPassword', () => {
    const values = { newPassword: 'foo', currentPassword: 'foobar' };
    expect(validators.passwordChange(values.newPassword, values)).toEqual(null);
  });

  it('should return an error if passwords match', () => {
    const values = { newPassword: 'foo', currentPassword: 'foo' };
    expect(validators.passwordChange(values.newPassword, values)).toEqual(
      errors.PASSWORD_SAME_AS_CURRENT,
    );
  });

  it("doesn't check for valid passwords, it only checks if they are not match", () => {
    const emptyValues = { newPassword: '', currentPassword: 'foo' };
    expect(
      validators.passwordChange(emptyValues.newPassword, emptyValues),
    ).toEqual(null);

    const nullValues = { newPassword: 'foo', currentPassword: '' };
    expect(
      validators.passwordChange(nullValues.newPassword, nullValues),
    ).toEqual(null);

    const undefinedValues = {};
    expect(
      validators.passwordChange(undefinedValues.newPassword, undefinedValues),
    ).toEqual(errors.PASSWORD_SAME_AS_CURRENT);
  });
});

describe('validators.password', () => {
  it('should return null if the password is valid', () => {
    expect(validators.password('Test123#@!')).toEqual(null);
  });

  it('should return an error string if the password is not valid', () => {
    expect(validators.password('invalid')).toEqual(errors.PASSWORD);
  });
});

describe('validators.phone', () => {
  it('should return null if the phone number is valid', () => {
    expect(validators.phone(14155555555)).toEqual(null);
  });

  it('should return an error string if the phone number is not valid', () => {
    expect(validators.phone(555)).toEqual(errors.PHONE);
  });
});

describe('validators.phoneOrEmail', () => {
  it("should return null if it's a valid email address", () => {
    expect(validators.phoneOrEmail('dog@pets.com')).toEqual(null);
  });

  it("should return null if it's a valid phone number", () => {
    expect(validators.phoneOrEmail(14155555555)).toEqual(null);
  });

  it("should return an error string if it's neither a valid phone or email address", () => {
    expect(validators.phoneOrEmail(555)).toEqual(errors.PHONE_OR_EMAIL);
    expect(validators.phoneOrEmail('dog')).toEqual(errors.PHONE_OR_EMAIL);
  });
});

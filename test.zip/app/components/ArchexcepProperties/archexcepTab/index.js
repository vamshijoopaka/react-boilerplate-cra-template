import React from 'react';
import { connect } from 'react-redux';
import { compose } from 'redux';
import { withStyles } from '@material-ui/core/styles';
import injectReducer from 'utils/injectReducer';
import injectSaga from 'utils/injectSaga';
import PropTypes from 'prop-types';
import FormFieldsGenerator from '../../common/FormFieldsGenerator';
import FormFieldComponent from '../../common/FormFieldsGenerator/formField';
import Spinner from '../../common/Spinner';
import { selectData } from './selector';
import {
    DEFAULT_URL_DATA,
    ARCHEXCEP_TAB_EXCEPTION_DETAILS,
    ARCHEXCEP_TAB_CONTROL_FACTORS,
    ARCHEXCEP_TAB_FORECAST_DETAILS,
    ARCHEXCEP_TAB_PREVIOUS_VALUES,
    ARCHEXCEP_TAB_PERIODROLL_VALUES,
    ARCHEXCEP_TAB_CHANGED_VALUES,
} from './constants';
import './style.scss';
import {
    getJulianValue, getListPredecessor,
    getSortableColumns, setNumberFields,
    getDateFormatValue
} from '../../../utils/util';
import { getDateFormatted, isValidDate } from '../../common/Form/dateTimeUtils';
import { ARCHEXCEPS_LIST_PAGE } from 'components/common/constants';
import CardComponent from '../../common/CardComponent';
import {
    COLUMN_POSITION, COLUMN_VALUE_ACCESSOR,
    COLUMN_FIELD_TYPE, DROPDOWN_FIELD, INITIAL_PAGE_PROPS
} from "components/common/constants";
import { isEqual } from 'lodash';

const propTypes = {
    setSaveData: PropTypes.func,
}

const style = theme => ({
    pageContainer: {
        display: 'flex',
        backgroundColor: 'var(--background-app)',
        borderTop: 'none',
        padding: '10px 20px',
    },
    pageContainerSeventy: {
        width: '70%',
        flexFlow: 'wrap',
        display: 'flex',
    },
    pageContainerHundred: {
        width: '100%',
        flexFlow: 'wrap',
        display: 'flex',
    },
    pageContainerThirty: {
        width: '30%',
        display: 'flex',
        flexFlow: 'wrap',
        // flexDirection: 'column',
        // borderLeft: '1.5px solid var(--divider-line)',
        // paddingLeft: '20px',
        marginLeft: '10px',
    },
    cardWithborder: {
        // border: '1px solid var(--secondary-s3)',
        borderRadius: '4px',
        // padding: '10px',
        // margin: '10px',
        width: '100%',
        backgroundColor: 'var(--secondary-s5)',
    },
    card: {
        padding: '0px',
        backgroundColor: 'var(--background-content)',
        borderRadius: '4px',
        width: '100%',
        margin: '10px',
        '& .MuiCardHeader-root': {
            padding: '22px 10px 0 20px'
        },
        '& .MuiCardContent-root': {
            padding: '16px 15px 10px 15px'
        }
        // '& .MuiCardHeader-root': {
        //     padding: '5px'
        // },
        // '& .MuiCardContent-root': {
        //     padding: '5px'
        // }
    },
    cardName: {
        fontWeight: '500',
        margin: '10px 0 20px 5px',
    },
    simpleCardGroup: {
        width: '100%',
        display: 'flex',
        justifyContent: 'space-around',
    },
    dashedBottomBorder: {
        borderBottom: '1px dashed var(--secondary-s21)',
        marginBottom: '20px',
    },
    marginLeftZero: {
        marginLeft: '0',
    },
    marginRightZero: {
        marginRight: '0',
    },
    marginLeftTen: {
        marginLeft: '10',
    },
    marginRightTen: {
        marginRight: '10',
    },
    customCardWrapper: {
        display: 'grid',
        gridTemplateColumns: '50% 50%'
    },
    marketReplenish: {
        '& .MuiCardContent-root': {
            paddingBottom: '40px'
        }
    },
    widht100: {
        width: '100%'
    },
    formContainer: {
        // display: 'grid',
        gridTemplateColumns: '100%',
        marginLeft: '1rem'
    },
})

class ArchexcepTab extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            fields: false,
            values: false,
            hasError: false,
            errorId: false,
            customCards: false,
            tabcards: false
        };
        this.handleChangeValue = this.handleChangeValue.bind(this);
        this.setGlobalProps = this.setGlobalProps.bind(this);
        // this.setCustomCards = this.setCustomCards.bind(this);
    }

    setGlobalProps() {
        //Function to set global props for massMaintenance
        // this.props.setGlobalCurrentPage(ARCHEXCEP_TAB)
    }

    handleChangeValue(key, val, field, setEnableDisable = true) {
    }

    setValueDataOnFocutOut = (key, value, field) => {
        let tabsData = this.setFieldEnableDisable(key, value, field, this.state.tabcards);
        this.setState({ tabcards: tabsData });
    }

    setFieldEnableDisable = (key, value, field, tabsData, isInitialLoad = false) => {
        const { valueData } = this.props.ArchexcepPropertiesData;
        let valueDataUpdated = JSON.parse(JSON.stringify(valueData));
        valueDataUpdated = Object.assign({}, valueDataUpdated, { [key]: value });
        // fieldKey --- field changed
        // cardFieldKey --- field to be disabled
        let cardFieldKey, fieldKey = field[COLUMN_VALUE_ACCESSOR].trim();
        let tabcards = JSON.parse(JSON.stringify(tabsData));
        tabcards = tabcards.map(card => {
            card.cardfields = card.cardfields.map(cardField => {
                cardFieldKey = cardField[COLUMN_VALUE_ACCESSOR] ? cardField[COLUMN_VALUE_ACCESSOR].trim() : "";
                    cardField['disabled'] = true;
                return cardField;
            })
            return card;
        })
        return tabcards;
    }

    getValueData(valueData, newValueData) {
        // if (Object.keys(valueData).length && Object.keys(newValueData).length &&
        //     (JSON.parse(JSON.stringify(valueData)) !== JSON.parse(JSON.stringify(newValueData)))) {
        //     return newValueData;
        // }
        let data = {...valueData};

        if (data.EXDATE > 0) {
            // data.EXDATE = getDateFormatValue(data.EXDATE); // The format YYYY-MM-DD is causing issues with date conversion in Form field generator
        }
        else{
            data.EXDATE = "";
        }

        if (data.EMFDAT > 0) {
            // data.EMFDAT = getDateFormatValue(data.EMFDAT);
        }
        else{
            data.EMFDAT = "";
        }

        if (data.ECDATE > 0) {
            // data.ECDATE = getDateFormatValue(data.ECDATE);
        }
        else{
            data.ECDATE = "";
        }

        if (data.EDDATE > 0) {
            // data.EDDATE = getDateFormatValue(data.EDDATE);
        }
        else{
            data.EDDATE = "";
        }

        data.EXTYPE = Number(data.EXTYPE).toString();
        data.EPERYR = Number(data.EPERYR).toString();
        data.ELPSAL = Number(data.ELPSAL).toFixed(2);
        data.EPLPDM = Number(data.EPLPDM).toFixed(2);
        return data;
    }

    componentDidMount() {
        let tabsData = this.props.ArchexcepPropertiesData.archexcepLabelsData.tabcards;
        let valueForm =  this.props.ArchexcepPropertiesData.currentRecordData;
        if (this.props.ArchexcepPropertiesData.valueData) {
            valueForm = this.props.ArchexcepPropertiesData.valueData;
        }

        let prefix = getListPredecessor(this.props.currentPage);
        tabsData.forEach(card => {
            card.cardfields.forEach(field => {
                if (field.key) {
                    tabsData = this.setFieldEnableDisable(field.key, valueForm[field.key], field, tabsData, true);
                    if (field.hasCheckbox) {
                        tabsData = this.setFieldEnableDisable(field.checkfieldJson.key, valueForm[field.checkfieldJson.key], field.checkfieldJson, tabsData, true);
                    }
                }
            })
        })
        this.setState({ tabcards: tabsData });

        let tempcards = this.props.ArchexcepPropertiesData.archexcepLabelsData.tabcards;
        if (valueForm.EPPERD == 13) { 
            tempcards[4].cardfields = tempcards[4].cardfields.filter(obj => (obj.FLDID != 11343 && obj.FLDID != 11322));
            tempcards[5].cardfields = tempcards[5].cardfields.filter(obj => (obj.FLDID != 11342 && obj.FLDID != 11321));
            tempcards[6].cardfields = tempcards[6].cardfields.filter(obj => (obj.FLDID != 11341 && obj.FLDID != 11320));
            this.setState({ tabcards: tempcards });
        }
        if (valueForm.EPPERD == 52) { 
            tempcards[4].cardfields = tempcards[4].cardfields.filter(obj => (obj.FLDID != 11340 && obj.FLDID != 11319));
            tempcards[5].cardfields = tempcards[5].cardfields.filter(obj => (obj.FLDID != 11339 && obj.FLDID != 11318));
            tempcards[6].cardfields = tempcards[6].cardfields.filter(obj => (obj.FLDID != 11338 && obj.FLDID != 11317));
            this.setState({ tabcards: tempcards });
        }
    }

    componentDidUpdate(prevProps) {
        const { tabcards } = this.props.ArchexcepPropertiesData.archexcepLabelsData;
        const { newValueData } = this.props.ArchexcepPropertiesData;
    }


    render() {

        const { classes, setSaveData, globalDateFormat, filterCriteriaDetails, pageFilterOptions,
            globalFilterOptions, columnDefs, currentPage, canUpdateComponent, currentOwnerName } = this.props;
        const { loading, valueData, newValueData, archexcepLabelsData } = this.props.ArchexcepPropertiesData;

        const { tabcards } = this.state;
        const { customCards } = this.state;

        return (
            <div>
                {!loading && tabcards && tabcards.length && currentPage && (
                    <div className={classes.pageContainer}>

                        <div className={classes.simpleCardGroup}>

                            <div className={classes.pageContainerHundred}>
                                
                                <div className={classes.simpleCardGroup}>

                                    {!loading && tabcards.map(formCard => {
                                        if (formCard.cardkey == ARCHEXCEP_TAB_EXCEPTION_DETAILS) {
                                            return <CardComponent title={formCard.cardtitle} className={classes.card + ' ' + classes.marginLeftZero + ' ' + classes.marginRightZero}>
                                                <FormFieldsGenerator
                                                    currentOwnerName={currentOwnerName}
                                                    cardHasDotsBtn={true}
                                                    cardHasCheckBox={false}
                                                    noMassMaintenance={true}
                                                    labelDisplayCharacters={30}
                                                    valueDisplayCharacters={30}
                                                    handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                                                    key={formCard.cardkey}
                                                    parentPage={ARCHEXCEPS_LIST_PAGE}
                                                    className={'ARCHEXCEP_TAB_EXCEPTION_DETAILS'}
                                                    fieldsArray={formCard.cardfields}
                                                    valuesArray={this.getValueData(valueData, newValueData)}
                                                    handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                                    enableAddButton={(e) => { setSaveData(e) }}
                                                    //handleFocusOut={(key, val, field) => this.props.setValueDataOnFocutOut({ key, val, field })}
                                                    handleFocusOut={(key, val, field) => this.setValueDataOnFocutOut(key, val, field)}
                                                    globalDateFormat={globalDateFormat}
                                                    // globalNumberSeparator = {numberSeparator}
                                                    filterCriteriaDetails={filterCriteriaDetails}
                                                    pageFilterOptions={pageFilterOptions}
                                                    globalFilterOptions={globalFilterOptions}
                                                    columnDefs={columnDefs}
                                                    currentPage={currentPage}
                                                    parentData={this.props.archexcepData}
                                                    canUpdateComponent={canUpdateComponent}
                                                />
                                            </CardComponent>
                                        }
                                    })}

                                    {!loading && tabcards.map(formCard => {
                                        if (formCard.cardkey == ARCHEXCEP_TAB_CONTROL_FACTORS) {
                                            return <CardComponent title={formCard.cardtitle} className={classes.card + ' ' + classes.marginLeftTen + ' ' + classes.marginRightTen}>
                                                <FormFieldsGenerator
                                                    currentOwnerName={currentOwnerName}
                                                    cardHasDotsBtn={true}
                                                    cardHasCheckBox={false}
                                                    noMassMaintenance={true}
                                                    labelDisplayCharacters={30}
                                                    valueDisplayCharacters={30}
                                                    handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                                                    key={formCard.cardkey}
                                                    parentPage={ARCHEXCEPS_LIST_PAGE}
                                                    className={'ARCHEXCEP_TAB_CONTROL_FACTORS'}
                                                    fieldsArray={formCard.cardfields}
                                                    valuesArray={this.getValueData(valueData, newValueData)}     
                                                    handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                                    enableAddButton={(e) => { setSaveData(e) }}
                                                    //handleFocusOut={(key, val, field) => this.props.setValueDataOnFocutOut({ key, val, field })}
                                                    handleFocusOut={(key, val, field) => this.setValueDataOnFocutOut(key, val, field)}
                                                    globalDateFormat={globalDateFormat}
                                                    filterCriteriaDetails={filterCriteriaDetails}
                                                    pageFilterOptions={pageFilterOptions}
                                                    globalFilterOptions={globalFilterOptions}
                                                    columnDefs={columnDefs}
                                                    currentPage={currentPage}
                                                    parentData={this.props.archexcepData}
                                                    canUpdateComponent={canUpdateComponent}
                                                />
                                            </CardComponent>
                                        }
                                    })}

                                    {!loading && tabcards.map(formCard => {
                                        if (formCard.cardkey == ARCHEXCEP_TAB_FORECAST_DETAILS) {
                                            return <CardComponent title={formCard.cardtitle} className={classes.card + ' ' + classes.marginLeftZero + ' ' + classes.marginRightZero}>
                                                <FormFieldsGenerator
                                                    currentOwnerName={currentOwnerName}
                                                    cardHasDotsBtn={false}
                                                    cardHasCheckBox={true}
                                                    noMassMaintenance={true}
                                                    labelDisplayCharacters={30}
                                                    valueDisplayCharacters={30}
                                                    handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                                                    key={formCard.cardkey}
                                                    parentPage={ARCHEXCEPS_LIST_PAGE}
                                                    className={'ARCHEXCEP_TAB_FORECAST_DETAILS'}
                                                    fieldsArray={formCard.cardfields}
                                                    valuesArray={this.getValueData(valueData, newValueData)}
                                                    handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                                    enableAddButton={(e) => { setSaveData(e) }}
                                                    //handleFocusOut={(key, val, field) => this.props.setValueDataOnFocutOut({ key, val, field })}
                                                    handleFocusOut={(key, val, field) => this.setValueDataOnFocutOut(key, val, field)}
                                                    globalDateFormat={globalDateFormat}
                                                    filterCriteriaDetails={filterCriteriaDetails}
                                                    pageFilterOptions={pageFilterOptions}
                                                    globalFilterOptions={globalFilterOptions}
                                                    columnDefs={columnDefs}
                                                    currentPage={currentPage}
                                                    parentData={this.props.archexcepData}
                                                    canUpdateComponent={canUpdateComponent}
                                                />
                                            </CardComponent>
                                        }
                                    })}

                                </div>

                                <div className={classes.simpleCardGroup}>

                                    {!loading && tabcards.map(formCard => {
                                        if (formCard.cardkey == ARCHEXCEP_TAB_PREVIOUS_VALUES) {
                                            return <CardComponent title={formCard.cardtitle} className={classes.card + ' ' + classes.marginLeftZero + ' ' + classes.marginRightZero}>
                                                <FormFieldsGenerator
                                                    currentOwnerName={currentOwnerName}
                                                    cardHasDotsBtn={false}
                                                    cardHasCheckBox={true}
                                                    noMassMaintenance={true}
                                                    labelDisplayCharacters={30}
                                                    valueDisplayCharacters={30}
                                                    handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                                                    key={formCard.cardkey}
                                                    parentPage={ARCHEXCEPS_LIST_PAGE}
                                                    className={'ARCHEXCEP_TAB_PREVIOUS_VALUES'}
                                                    fieldsArray={formCard.cardfields}
                                                    valuesArray={this.getValueData(valueData, newValueData)}
                                                    handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                                    enableAddButton={(e) => { setSaveData(e) }}
                                                    //handleFocusOut={(key, val, field) => this.props.setValueDataOnFocutOut({ key, val, field })}
                                                    handleFocusOut={(key, val, field) => this.setValueDataOnFocutOut(key, val, field)}
                                                    globalDateFormat={globalDateFormat}
                                                    filterCriteriaDetails={filterCriteriaDetails}
                                                    pageFilterOptions={pageFilterOptions}
                                                    globalFilterOptions={globalFilterOptions}
                                                    columnDefs={columnDefs}
                                                    currentPage={currentPage}
                                                    parentData={this.props.archexcepData}
                                                    canUpdateComponent={canUpdateComponent}
                                                />
                                            </CardComponent>
                                        }
                                    })}

                                    {!loading && tabcards.map(formCard => {
                                        if (formCard.cardkey == ARCHEXCEP_TAB_PERIODROLL_VALUES) {
                                            return <CardComponent title={formCard.cardtitle} className={classes.card + ' ' + classes.marginLeftTen + ' ' + classes.marginRightTen}>
                                                <FormFieldsGenerator
                                                    currentOwnerName={currentOwnerName}
                                                    cardHasDotsBtn={false}
                                                    cardHasCheckBox={true}
                                                    noMassMaintenance={true}
                                                    labelDisplayCharacters={30}
                                                    valueDisplayCharacters={30}
                                                    handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                                                    key={formCard.cardkey}
                                                    parentPage={ARCHEXCEPS_LIST_PAGE}
                                                    className={'ARCHEXCEP_TAB_PERIODROLL_VALUES'}
                                                    fieldsArray={formCard.cardfields}
                                                    valuesArray={this.getValueData(valueData, newValueData)}
                                                    handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                                    enableAddButton={(e) => { setSaveData(e) }}
                                                    //handleFocusOut={(key, val, field) => this.props.setValueDataOnFocutOut({ key, val, field })}
                                                    handleFocusOut={(key, val, field) => this.setValueDataOnFocutOut(key, val, field)}
                                                    globalDateFormat={globalDateFormat}
                                                    filterCriteriaDetails={filterCriteriaDetails}
                                                    pageFilterOptions={pageFilterOptions}
                                                    globalFilterOptions={globalFilterOptions}
                                                    columnDefs={columnDefs}
                                                    currentPage={currentPage}
                                                    parentData={this.props.archexcepData}
                                                    canUpdateComponent={canUpdateComponent}
                                                />
                                            </CardComponent>
                                        }
                                    })}

                                    {!loading && tabcards.map(formCard => {
                                        if (formCard.cardkey == ARCHEXCEP_TAB_CHANGED_VALUES) {
                                            return <CardComponent title={formCard.cardtitle} className={classes.card + ' ' + classes.marginLeftZero + ' ' + classes.marginRightZero}>
                                                <FormFieldsGenerator
                                                    currentOwnerName={currentOwnerName}
                                                    cardHasDotsBtn={false}
                                                    cardHasCheckBox={true}
                                                    noMassMaintenance={true}
                                                    labelDisplayCharacters={30}
                                                    valueDisplayCharacters={30}
                                                    handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                                                    key={formCard.cardkey}
                                                    parentPage={ARCHEXCEPS_LIST_PAGE}
                                                    className={'ARCHEXCEP_TAB_CHANGED_VALUES'}
                                                    fieldsArray={formCard.cardfields}
                                                    valuesArray={this.getValueData(valueData, newValueData)}
                                                    handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                                    enableAddButton={(e) => { setSaveData(e) }}
                                                    //handleFocusOut={(key, val, field) => this.props.setValueDataOnFocutOut({ key, val, field })}
                                                    handleFocusOut={(key, val, field) => this.setValueDataOnFocutOut(key, val, field)}
                                                    globalDateFormat={globalDateFormat}
                                                    filterCriteriaDetails={filterCriteriaDetails}
                                                    pageFilterOptions={pageFilterOptions}
                                                    globalFilterOptions={globalFilterOptions}
                                                    columnDefs={columnDefs}
                                                    currentPage={currentPage}
                                                    parentData={this.props.archexcepData}
                                                    canUpdateComponent={canUpdateComponent}
                                                />
                                            </CardComponent>
                                        }
                                    })}
                                </div>

                            </div>

                        </div>

                    </div>

                )}
            </div>

        );
    }
}


function mapDispatchToProps(dispatch) {
    return {
        dispatch
    }
}

const mapStateToProps = function (state) {
    return {
        ArchexcepTabData: selectData(state)
    }
}


const withConnect = connect(
    mapStateToProps,
    mapDispatchToProps,
);

ArchexcepTab.propTypes = propTypes;

export default compose(
    withConnect,
    withStyles(style)
)(ArchexcepTab);
//---------------------------------------------------------------------------------------------------------
/*** ChangeLog
E3C-32838 ; 2022.1.0.0 Unified Product 
    E3C-32900 -Rakesh, July 15, 2021 : Hide Min Pres stock days(25257) in Item Detail card
***/

export const setFieldNameAndPrefix = (field, FDFNAM, prefixFlag = true, FDPRFX = "1") => {
    field.FDFNAM = FDFNAM;
    field.prefixFlag = prefixFlag;
    field.FDPRFX = FDPRFX;
    return field;
};
export const manipulateFieldMetaData = (field, cardfields, cardkey) => {
    if ('TLLAB' in field) {
        field.TLLAB = field.TLLAB.replace(/(.)?(in )?Units$/, '');
        //Remove Short Label display for demo
        // field.TSLAB = '';
    }

    if (field.FLDID == "51055") {
        if(cardkey =="50542") {
            field = setFieldNameAndPrefix(field, 'IOCDYS'); //item cycle (work days)
        }
        else {
        field = setFieldNameAndPrefix(field, 'CIOCDY');
        }
    }
    if (field.FLDID == "4242") {
        field.FDFNAM = 'MVOCU';
    }
    if (field.FLDID == "51056") {
        if(cardkey =="50542") {
            field = setFieldNameAndPrefix(field, 'VORCYC'); //VENDOR CYCLE
            field.key = 'VORCYC';
        }
        else {
        field = setFieldNameAndPrefix(field, 'CVORCY');
        field.key = 'CVORCY'
        }

    }
    if (field.FLDID == "51054") {
        field.FDFNAM = 'PCHPR';
        field.FDPRFX = '0';
        field.prefixFlag = false;
    }
    if (field.FLDID == "3911" && cardkey == "50542") {
        field.dataType = 'labels'; //Display Forward buy as labels in work days in Item Details
    }
    if (field.FLDID == "9820") {
        if(cardkey =="50542")
            field.dataType = 'labels';
        field = setFieldNameAndPrefix(field, field.FDFNAM);
        field.key = "CSHLF";     
    }
    if (field.FDFILD == '4240') {
        let shelfLifeObj = cardfields.find(field => field.FLDID == '51058');
        shelfLifeObj = {... shelfLifeObj} //Deep copyShelf life object
        if (shelfLifeObj) {
            delete shelfLifeObj.FLDID;
            field = { ...field, ...shelfLifeObj, hideLabel: false };
        }
    }
    if (field.FDFILD == '10158') {
        field.FDFNAM = 'SSDYS';
    }
    if (field.FDFILD == '10157') {
        field.FDFNAM = 'CMNUT';
    }
    if (field.FDFILD == '3332') {
        field.FDFNAM = 'EVENT';
    }
    if (field.FDFILD == '3553') {
        if (cardkey != "50543") // 50543- Item Detail Order component card
            field.FDFNAM = 'PCHPE';
    }
    //Forecast History cards
    if (field.FLDID == "6956") {
        field = setFieldNameAndPrefix(field, 'CMINIX ');
    }
    if (field.FLDID == "11550") {
        field = setFieldNameAndPrefix(field, 'CFAXPD ');
    }
    if (field.FLDID == "11551") {
        field.disabled=true;
        field = setFieldNameAndPrefix(field, 'CBPZOH ');
    }
    if (field.FLDID == "11552") {
        field.disabled = true;
        field = setFieldNameAndPrefix(field, 'CBPOPR ');
        }
    if (field.FLDID == "11553") {
        field = setFieldNameAndPrefix(field, 'CBPWBP ');
    }
    if (field.FLDID == "11554") {
        field = setFieldNameAndPrefix(field, 'CBPWAP ');
    }
    if (field.FLDID == "3325") {
        field = setFieldNameAndPrefix(field, 'CDEMHI ');
    }
    if (field.FLDID == "11555") {
        field = setFieldNameAndPrefix(field, 'CNDFLH ');
    }
    if (field.FLDID == "11556") {
        field = setFieldNameAndPrefix(field, 'CUHDPF ');
        field.disabled = true;
    }
    if (field.FLDID == "3326") {
        field = setFieldNameAndPrefix(field, 'CDEMLO ');
    }
    if (field.FLDID == "11557") {
        field = setFieldNameAndPrefix(field, 'CNDFLL ');
        }
    if (field.FLDID == "11558") {
        field = setFieldNameAndPrefix(field, 'CULDPF ');
        field.disabled = true;
      }
    if (field.FLDID == "11561") {
        field = setFieldNameAndPrefix(field, 'CFIPCT ');
       }
    if (field.FLDID == "11562") {
        field = setFieldNameAndPrefix(field, 'CFDPCT ');
  }
    //Reforecast N period dialog field
    if (field.FLDID == "6669") {
        field = setFieldNameAndPrefix(field, 'IANPER ');
        }
    //Reforecast Multiple dialog fields
    if (field.FLDID == "2069") {
        field.toUppercase=false;
        field = setFieldNameAndPrefix(field, 'IAJDES ');
    }
    if (field.FLDID == "2822") {
        field.disabled = true;
        field = setFieldNameAndPrefix(field, 'IARCAL ');
    }
    if (field.FLDID == "11087") {
        field.disabled = true;
        field = setFieldNameAndPrefix(field, 'IAAPBT ');
    }
    
    //Hide Labels
    // E3C-32838, July 15,2021. Begin
    if (['3802', '4234', '3800', '4238', '4236', '4238', '51055', '51056', '3838', '4237', '4235', '51058', '9820', '3956', '10158', '4466', "3911", "25257"].includes(field.FLDID) && ['50542', '50543'].includes(cardkey)) {
    // E3C-32838-End   
        if (field.FDFILD == '4238')
            field.FDFNAM = 'CNVBP';
        field.hideLabel = true;
    }

    //No massmaintenance
    if (['4501', '3891', '4234', '3852'].includes(field.FLDID)) {
        field.showMassMaintenance = false;
        field.noMassMaintenance = true;
    }
    //Calandar Switch Disable for update
    if (['4501'].includes(field.FLDID)) {
        field.FDFNAM = "WCALSW" 
        field.key = "WCALSW"  //Define new field to enable/disable calendar swt based on item/whs/vndr calendars
        field.prefixFlag = 1;
        field.FDPRFX = "1"
        field.disabled = true;
    }

    //Item Detail TAB, Demand/Order component, display daily and event profile id
    if(['50543'].includes(cardkey) && ['3756', '3332'].includes(field.FLDID)){
        field.prefixFlag = 1;
        field.FDPRFX = "1";
        field.FDFNAM = field.FLDID == "3332" ? 'IDMPRF' : field.FDFNAM; //change EVENT to IDMPRF
    }
    if (field.FLDID == "4466") {
        if(cardkey == "50542"){ 
            field = setFieldNameAndPrefix(field, 'CLTWDY') //Lead Time workdays
            field.key = 'CLTWDY'; 
        }
    }
    if (cardkey === '51') {
        const keyMap = {
            '9734': 'HMULT',
            '9735': 'HDIVD',
            '3670': 'HITEM',
            '3161': 'HWHSE',
            '3650': 'HIGRP1',
            '3651': 'HIGRP2',
            '3652': 'HIGRP3',
            '3653': 'HIGRP4',
            '3654': 'HIGRP5',
            '3655': 'HIGRP6',
            '3657': 'HREGN',
            '3174': 'HBUYR',
            '4433': 'HVNDR',
            '5261': 'HYEAR',
            '9736': 'HINSPC',
            '9737': 'HFSCT',
            '9738': 'HACCT',
        }
        if (keyMap[field.FLDID]) {
            field = setFieldNameAndPrefix(field, keyMap[field.FLDID]);
            field.key = keyMap[field.FLDID];
            if (field.FLDID === '3657') {
                field.dataType = 'text';
            }
        }
    }
    if (field.FDFILD === '3990') {
        field.hideLabel = true;
    }
    if (field.FDFILD === '7238') {
        field.hideLabel = true;
        field.noMassMaintenance = true;
    }
 
    return field;
}

export const setUserDefinedFields = (metaArray, userLabels) => {
    if (!(metaArray && metaArray.length) || !userLabels) return metaArray;
    return metaArray.map(field => {
        field.TLLAB = userLabels['U' + field.FDFNAM.trim()];
        if (field.FDFNAM)
            field.FDFNAM = 'CFFD' + field.FDFNAM.trim().slice(-2);
        field.prefixFlag = true;
        return field;
    });
}

//We need Actual Days Labels similar to Work Days
export const buildActualDaysLabels = (field) =>{

    if (field.FDFNAM) {
        if (["MSOQD", "MAXDF", "MBALD", "MINDF", "CNVBP", "MMULD", "MMIND"].includes(field.FDFNAM.trim())) {

          field.key = 'C' + field.key.substring(1);
          field.dataType = "labels";
          field.FDFNAM = 'C' + field.FDFNAM.trim();
          field.prefixFlag = 1;
        }
      }

      if (["IOPIDY"].includes(field.key)) {
        field.key = "CIOPDY";
        field.dataType = "labels";
        field.FDFNAM = "CIOPDY";
        field.prefixFlag = 1;
      }
      if (["ILTFOR"].includes(field.key)) {
        field.key = "CLTCDY";
        field.dataType = "labels";
        field.FDFNAM = "CLTCDY";
        field.prefixFlag = 1;
      }
      if (field.FDFILD == '9820') {
      field.FDFNAM = 'SHELF';
      field.key = 'ISHELF';
      field.FDPRFX = '0';
      field.prefixFlag = 0;
      field.dataType = 'number';
      }
    if (field.FLDID == "51055") {
        field = setFieldNameAndPrefix(field, 'CIOCDY');// Item Order Cycle
        field.key = 'CIOCDY';
    }
    if (field.FLDID == "51056") {
        field = setFieldNameAndPrefix(field, 'CVORCY');// Vendor Order Cycle
        field.key = 'CVORCY';
    }
    if (field.FLDID == "4466") {
        field = setFieldNameAndPrefix(field, 'CLTCDY');// Lead Time Forecast Actual Days
        field.key = 'CLTCDY';
    }
    if (field.FLDID == "3911") {
        field.dataType = "number" //Display Forward buy as labels in actual days
    }
      return field;
}

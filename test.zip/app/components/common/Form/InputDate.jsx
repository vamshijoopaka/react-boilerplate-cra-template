
/*
* * //==========================================================================
*
* * // Copyright 2021-2021, Blue Yonder Group, Inc.
*
* * // All Rights Reserved
*
* * //
*
* * // THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF
*
* * // BLUE YONDER GROUP, INC.
*
* * //
*
* * //
*
* * // The copyright notice above does not evidence any actual
*
* * // or intended publication of such source code.
*
* * //
*
* * // ===========================================================================
*/
import React, { Component } from 'react';
import 'date-fns';
import { KeyboardDatePicker, MuiPickersUtilsProvider, DatePicker } from '@material-ui/pickers';
import DateFnsUtils from '@date-io/date-fns';
import PropTypes from 'prop-types';
import { createMuiTheme, MuiThemeProvider } from '@material-ui/core/styles';
import theme from './../../../jda-gcp-theme';
import CalendarIcon from './../../../images/calendaricon2x.png';
import { withStyles } from '@material-ui/styles';
import { TYPE_DATE } from '../../../containers/common/constants';
import ErrorMessageComponent from '../ErrorMessageComponent';
import { POPUP_TIMEOUT } from 'utils/constants';
import { getDateFormatted } from './dateTimeUtils';
import {
  getDateFormat,
  getDateFromJulian,
  getJulianValue,
  getDateFormatValue,
  getCurrentDateJulian
} from '../../../utils/util';
import { isValidDate } from 'components/common/Form/dateTimeUtils';
import TextField from '@material-ui/core/TextField';
import DateTimePicker from './datePicker'

const themes = createMuiTheme(theme);

themes.overrides = {
  MuiDialog: {
    paperWidthSm: {
      // maxWidth: 310,
      // maxHeight: 460
      height: 'auto !important',
      maxHeight: 'calc(100vh - 64px) !important',
      maxWidth: 'calc(100vw - 64px) !important',
      minHeight: '450px !important'
    },
  },
  MuiDialogContent: {
    root: {
      backgroundColor: theme.palette.common.white,
      padding: '8px 0'
    }
  },
  MuiDialogActions: {
    root: {
      padding: '8px 16px',
      backgroundColor: theme.palette.common.white
    }
  },
  MuiDialogTitle: {
    root: {
      backgroundColor: '#ffffff',
      borderBottom: '1px solid #d8d8d8',
      padding: '9px 16px'
    }
  },
  MuiSvgIcon: {
    root: {
      fontSize: '1.1rem !important',
    }
  },
  MuiPickersToolbar: {
    toolbar: {
      backgroundColor: theme.palette.common.darkOliveGreen
    }
  },
  MuiPaper: {
    root: {
      backgroundColor: '#ffffff'
    }
  },
  MuiPickersCalendarHeader: {
    iconButton: {
      backgroundColor: 'transparent'
    }
  },
  MuiButton: {
    textPrimary: {
      color: '#ffffff',
      fontSize: 12,
      backgroundColor: 'var(--primary-default)',
      '&:hover': {
        opacity: 0.9,
        backgroundColor: 'var(--primary-hover)',
      },
      '&:first-child': {
        backgroundColor: 'var(--disabled)',
        '&:hover': {
          opacity: 0.9
        },
      }
    },
    sizeLarge: {
      padding: '7px 16px'
    },
    contained: {
      boxShadow: theme.shadows[5],
      color: '#ffffff',
    },
    containedPrimary: {
      backgroundColor: '#0066D0'
    },
    containedSecondary: {
      backgroundColor: '#9A9A9A',
      '&:hover': {
        backgroundColor: '#9A9A9A',
        opacity: 0.9
      }
    },
    outlinedPrimary: {
      color: '#0066D0',
      border: '1px solid #0066D0'
    },
    outlinedSecondary: {
      color: '#9A9A9A',
      border: '1px solid #9A9A9A'
    },
  },

  MuiIconButton: {
    root: {
      color: 'var(--text)',
      '&.Mui-disabled': {
        color: 'var(--disabled)'
      },
      '&:hover': {
        backgroundColor: 'none',
      }
    }
  },
  MuiFormControl: {
    root: {
      width: '100%'
    }
  },
  MuiInputBase: {
    root: {
      fontSize: 14,
      height: 25,
      maxWidth: '13rem'
    },
    input: {
      color: theme.palette.common.inputTextValue
    }
  }
}

const styles = theme => ({
  dateFieldBox: {
    position: 'relative'
  },
  calendarIcon: {
    position: 'absolute',
    right: '7px',
    top: '2px',
    width: '14px',
    height: '18px',
    pointerEvents: 'none',
    backgroundColor: '#f1f1f1'
  },
  inputDateWrapper: {
    position: 'relative',
    display: 'flex',
    width: '100%',
    '& .error-icon-pure-css': {
      right: '34px !important',
      top: '2px !important'
    },
    '& .error-tooltip span': {
      top: '-105%',
      left: '-220px',
    }
  },
  errorMessageWrapper: {
    position: 'relative',
    display: 'inline-flex'
  }
})

const defaultProps = {
  className: '',
  isDatePicker: false
};

const propTypes = {
  className: PropTypes.string,
  field: PropTypes.shape({}).isRequired,
  onChange: PropTypes.func.isRequired,
  value: PropTypes.any,
  onFocus: PropTypes.func,
  disabled: PropTypes.any,
  isDatePicker: PropTypes.bool,
  views: PropTypes.array,
  minDate: PropTypes.any,
  maxDate: PropTypes.any,
};

class InputDate extends Component {
  constructor() {
    super();
    this.state = {
      errorId: '',
      isError: false,
      dateFormat: getDateFormat(),
    }
    this.onChange = this.onChange.bind(this);
    this.getFieldValue = this.getFieldValue.bind(this);
  }
  onChange(event, val) {
    if (!event) {
      return;
    }
    const { field, onChange, enableAddButton, gridCallBack, errorMessageLabel, isDatePicker } = this.props;
    const { key } = field;
    if (val && !this.getDate(val) && val.indexOf('_') == -1) {
      this.setError();
      if (gridCallBack) {
        gridCallBack("date",
          10727,
          errorMessageLabel);
      }
    }
    if (isDatePicker) {
      if (isValidDate(event))
        event = getJulianValue(event);
      else
        event = '';
    } else {
      if (isValidDate(this.getSelectedDate(event.currentTarget.value)))
        event = getJulianValue(this.getSelectedDate(event.currentTarget.value));
      else
        event = '';
    }
    onChange(key, event);
    if (enableAddButton) {
      enableAddButton(true);
    }
    document.dispatchEvent(
      new window.KeyboardEvent('keypress',
        {
          key: 'escape'
        })
    );
  }
  onChange_DatePicker(val, event) {
    if (!event) {
      return;
    }
    val = getDateFormatted(val);
    if (val == "Invalid date") {
      val = '';
    }
    const { field, onChange, enableAddButton, gridCallBack, errorMessageLabel, isDatePicker } = this.props;
    const { key } = field;
    if (val && !this.getDate(val) && val.indexOf('_') == -1) {
      this.setError();
      if (gridCallBack) {
        gridCallBack("date",
          10727,
          errorMessageLabel);
      }
    }
    if (isDatePicker) {
      if (isValidDate(event))
        event = getJulianValue(event);
      else
        event = '';
    } else {
      if (isValidDate(this.getSelectedDate(val)))
        event = getJulianValue(this.getSelectedDate(val));
      else
        event = '';
    }
    onChange(key, event);
    if (enableAddButton) {
      enableAddButton(true);
    }
    document.dispatchEvent(
      new window.KeyboardEvent('keypress',
        {
          key: 'escape'
        })
    );
  }
  setError = () => {
    this.setState({ isError: true });
    this.setState({ errorId: 10727 });
    setTimeout(
      () => {
        this.setState({ isError: false })
      }, POPUP_TIMEOUT);
  }

  onBlur = (e) => {
    const { gridCallBack, errorMessageLabel } = this.props;
    let val = e.target.value;
    if (val && !this.getDate(val)) {
      this.setError();
      if (gridCallBack) {
        gridCallBack("date",
          10727,
          errorMessageLabel);
      }
    }
  }

  getSelectedDate = (val) => {
    if (val) {
      let dateValues = val.split("-");
      let splitValue = val.split("-");
      dateValues = dateValues[1] + '/' + dateValues[2] + '/' + dateValues[0];
      if (Number(splitValue[0]).toString().length >= 4) {
        return (new Date(dateValues));
      }
    }
  }

  getDate = (val) => {
    if (val) {
      return (this.getSelectedDate(val)).getDate();
    }
  }

  getFieldValue(value) {
    const { isDatePicker } = this.props;
    if (isDatePicker) {
      let val = getDateFromJulian(value);
      return val;
    }
    return getDateFormatValue(value);
  }
  onClick = (event) => {
    console.log(event);
  }
  render() {
    const { className, field, value, classes, onFocus, disabled, minDate, maxDate, views, isDatePicker, isFromGrid, parentErrorClass, globalDateFormat } = this.props;
    const { placeholder, key } = field;
    return (
      <div className={classes.inputDateWrapper}>
        <div className={classes.dateFieldBox + ' ' + className}>
          <MuiThemeProvider theme={themes}>
            <MuiPickersUtilsProvider utils={DateFnsUtils}>
              <div onClick={onFocus}>
                {!isDatePicker &&
                  <DateTimePicker
                    id={key}
                    // globalDateFormat={"yy/dd/MM"}
                    globalDateFormat={globalDateFormat}
                    value={value ? this.getFieldValue(value) : null}
                    onInputClick={(event) => onClick(event)}
                    // onChange={(event) => this.onChange(event, event.currentTarget.value)}
                    onChange={(val, event) => this.onChange_DatePicker(val, event)}
                    disabled={disabled}
                    onFocus={onFocus}
                    onBlur={(e) => this.onBlur(e)}
                  />
                  // E3C-30525-Ajit-Begin Old commneted
                  // <TextField
                  //   className={className + ' ' + (this.state.isError ? ' error-input' : '')}
                  //   placeholder={this.state.dateFormat}
                  //   id={key}
                  //   format={this.state.dateFormat}
                  //   error={false}
                  //   type="date"
                  //   disabled={disabled}
                  //   value={value ? this.getFieldValue(value) : ""}
                  //   onBlur={(e) => this.onBlur(e)}
                  //   onChange={(event) => this.onChange(event, event.currentTarget.value)}
                  //   autoComplete="off"
                  //   InputLabelProps={{
                  //     shrink: true,
                  //   }}
                  //   InputProps={{ inputProps: { min: minDate, max: maxDate } }}
                  // />
                  // E3C-30525-Ajit-Begin Old commneted
                }

                {isDatePicker &&
                  <DatePicker
                    disableToolbar
                    hintText={this.state.dateFormat}
                    placeholder={this.state.dateFormat}
                    variant="inline"
                    autoOk={true}
                    views={views}
                    id={key}
                    label={placeholder}
                    className={className + ' ' + (this.state.isError ? ' error-input' : '')}
                    maxDate={maxDate}
                    minDate={minDate}
                    helperText={null}
                    error={false}
                    value={value || null}
                    onChange={(event, date) => this.onChange(event, date)}
                    disabled={disabled}
                  />
                }
              </div>
            </MuiPickersUtilsProvider>
          </MuiThemeProvider>
          {/* <div className={classes.calendarIcon}>
            <img style={{ width: 14 }} src={CalendarIcon} />
          </div> */}
        </div>
        {this.state.isError && !isFromGrid &&
          <div className={classes.errorMessageWrapper} >
            <div className={"error-icon-pure-css " + parentErrorClass}></div>
            <ErrorMessageComponent
              id={this.state.errorId}
            >
            </ErrorMessageComponent>
          </div>
        }
      </div>
    );
  }
}

InputDate.defaultProps = defaultProps;

InputDate.propTypes = propTypes;

export default withStyles(styles)(InputDate);

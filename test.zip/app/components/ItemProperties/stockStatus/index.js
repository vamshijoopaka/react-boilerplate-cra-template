import { withStyles } from '@material-ui/core/styles';
import { COLUMN_FIELD_TYPE, COLUMN_VALUE_ACCESSOR, DROPDOWN_FIELD, ITEMS_LIST_PAGE } from 'components/common/constants';
import PropTypes from 'prop-types';
import React from 'react';
import { getListPredecessor, getSortableColumns, setNumberFields, getFormattedNumber } from '../../../utils/util';
import CardComponent from '../../common/CardComponent';
import FormFieldsGenerator from '../../common/FormFieldsGenerator';
import Spinner from '../../common/Spinner';
import './style.scss';
import 'style.scss';
import { Box, Grid, Card } from '@material-ui/core';
import { isEqual, isFinite } from 'lodash';

import {STOCK_STATUS_CARD_KEY, ADJ_TO_STOCK_STS_CARD_KEY, INFORMATION_ONLY_CARD_KEY, PERIOD_TO_DATE_CARD_KEY ,UNIT_DISTRIBUTION_CARD_KEY, ITEM_STOCK_CLASSIFICATION,
    ITEM_STOCK_STATUS_DEMAND_TO_DATE} 
    from'./constants.js';

const propTypes = {
  setSaveData: PropTypes.func,
  ItemPropertiesData: PropTypes.object.isRequired,
};

import StockClass from './stockClass';
import { reducer } from 'containers/common/FilterCriteria/reducer';

const style = (theme) => ({

    pageContainer: {
    display: 'flex',
    backgroundColor: 'var(--background-app)',
    borderTop: 'none',
    padding: '14px 14px 24px 24px',
  },
  pageContainerFifty: {
    width: '50%',
  },
  pageContainerSeventy: {
    width: '70%',
  },

  card: {
    padding: '0px',
    backgroundColor: 'var(--background-content)',
    borderRadius: '4px',
    width: '100%',
    marginTop: '10px',
    marginRight: '10px',
    '& .MuiCardHeader-root': {
      padding: '16px 32px'
    },
    '& .MuiCardContent-root': {
      padding: '16px 32px'
    }
  },

  simpleCardGroup: {
    width: '100%',
    display: 'flex',
    justifyContent: 'space-around',
  },

  marginLeftZero: {
    marginLeft: '0',
  },
  marginRightZero: {
    marginRight: '0',
  },
  infoCardStyle:{
    minHeight : '202px',
  },
  periodToDateCardStyle:{
    minHeight : '512px',
  },
  unitDistCardStyles: {
    minHeight : '477px',
  },
  adjStockCardStyle: {
    minHeight : '512px',
  },

stockStatusCardWidth: {
  minHeight: 300,
},

wrapContent: {
    display: 'flex',
    justifyContent: 'space-around',
    flexWrap: 'wrap'
},

});

class StockStatus extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      fields: false,
      values: false,
      hasError: false,
      errorId: false,
      hasHardError: false,
      periodToDateCardFields: false,
      adjToStockStatusLabels: false,
      qtyHeldStatusDisabled: true,
      tabcards: false,

    };
  }
  componentDidMount() {

    const { stockClassLabelsData } = this.props.ItemPropertiesData;

    if (stockClassLabelsData) {
      this.setCardFields();
      let tabsData = this.props.ItemPropertiesData.stockStatusLabelsData.tabcards;
        let valueForm = this.props.ItemPropertiesData.valueData;
        tabsData.forEach(card => {
            card.cardfields.forEach(field => {
                if (field.key) {
                    tabsData = this.setFieldEnableDisable(field.key, valueForm[field.key], field, tabsData, true);
                    if (field.hasCheckbox) {
                        tabsData = this.setFieldEnableDisable(field.checkfieldJson.key, valueForm[field.checkfieldJson.key], field.checkfieldJson, tabsData, true);
                    }
                }
            })
        })
        this.setState({ tabcards: tabsData });
    }
  }

  componentDidUpdate(prevProps, prevState) {
    const { stockStatusLabelsData , stockClassLabelsData ,valueData, newValueData } = this.props.ItemPropertiesData;

    if((!isEqual(valueData, prevProps.ItemPropertiesData.valueData) && valueData)  ||
      (!isEqual(newValueData, prevProps.ItemPropertiesData.newValueData) && newValueData )) {
      this.setCardFields();
    }
    
    if (!this.state.periodToDateCardFields && valueData && stockStatusLabelsData && stockStatusLabelsData.tabcards ){
      this.setCardFields();
    }
    if (newValueData){
      if ((!(parseInt(newValueData.IOHHDT) > 0) && !this.state.qtyHeldStatusDisabled) ||
          ((parseInt(newValueData.IOHHDT) > 0) && this.state.qtyHeldStatusDisabled)) {
          this.adjToStockStatusCard('IOHHDT', newValueData.IOHHDT )
      }
    }
 
  }

  componentDidCatch() {
    this.setState({ hasHardError: true })
  }
  handleChangeValue = (key, val, field, setEnableDisable = true) => {
    this.props.setValueData({ key, val });
    if (field.dataType == "checkbox" || field.dataType == 'select' || field.dataType == 'date') {
      if (setEnableDisable) {
          let tabsData = this.setFieldEnableDisable(key, val, field, this.state.tabcards);
          this.setState({ tabcards: tabsData });
      }
    }
  }

  setFieldEnableDisable = (key, value, field, tabsData, isInitialLoad = false) => {
    const { valueData } = this.props.ItemPropertiesData;
    if (!valueData || !Object.keys(valueData).length) return tabsData;
    let valueDataUpdated = JSON.parse(JSON.stringify(valueData));
    valueDataUpdated = Object.assign({}, valueDataUpdated, { [key]: value });
    // fieldKey --- field changed
    // cardFieldKey --- field to be disabled
    let cardFieldKey, fieldKey = field[COLUMN_VALUE_ACCESSOR].trim();
    let tabcards = JSON.parse(JSON.stringify(tabsData));
    tabcards = tabcards.map(card => {
        card.cardfields = card.cardfields.map(cardField => {
            cardFieldKey = cardField[COLUMN_VALUE_ACCESSOR] ? cardField[COLUMN_VALUE_ACCESSOR].trim() : "";
            //  disabling enabling field for particular value
            if ((fieldKey === 'OHHDT') && (cardFieldKey === 'QHELD') && value && parseInt(value) > 0) {
                cardField['disabled'] = false;
            } else if ((fieldKey === 'OHHDT') && (cardFieldKey === 'QHELD') && value && (value == '' ||  parseInt(value) == 0) ) {
                cardField['disabled'] = true;
            }
            return cardField;
        })
        return card;
    })
    return tabcards;
  }

  getValueData = (valueData, newValueData) => {

    if(valueData && newValueData && Object.keys(valueData).length && Object.keys(newValueData).length &&
      (JSON.parse(JSON.stringify(valueData)) !== JSON.parse(JSON.stringify(newValueData)))) {
      
        if(! newValueData.DEMPD)
          newValueData['IDEMPD'] = this.getDemandToDate(newValueData); //assign Demand to Date field 

        return newValueData;
    }
    
    if(! valueData.DEMPD)
    valueData['IDEMPD'] = this.getDemandToDate(valueData); //assign Demand to Date field 

    return valueData;
  }

  //Update demand to date value based on forecast periodicity
  getDemandToDate(itemDetailObj){
    let demandToDate = 0;
    if(parseInt(itemDetailObj.IPERDF) == 12){
      demandToDate = parseInt(itemDetailObj.ISHP12) + parseInt(itemDetailObj.ILST12) - parseInt(itemDetailObj.IPRM12)
    }
    else if(parseInt(itemDetailObj.IPERDF) == 13) {
      demandToDate = parseInt(itemDetailObj.ISHP13) + parseInt(itemDetailObj.ILST13) - parseInt(itemDetailObj.IPRM13)
    }
    else if(parseInt(itemDetailObj.IPERDF) == 52) {
      demandToDate = parseInt(itemDetailObj.ISHP52) + parseInt(itemDetailObj.ILST52) - parseInt(itemDetailObj.IPRM52)
    }
    return demandToDate.toString(); 
  }


  //Calculate Stock Class % for Graph 
  stockClassPercent = (valueData) => {
    let stockClassObj = { ...ITEM_STOCK_CLASSIFICATION };
    if (valueData) {
      const { IOVUNT, IPOUNT, IPRUNT, IFBUNT, IDLUNT, IRPUNT, ISSUNT } = valueData;

      let totalStock = parseInt(IOVUNT) + parseInt(IPOUNT) + parseInt(IPRUNT) + parseInt(IFBUNT) + parseInt(IDLUNT) + parseInt(IRPUNT) + parseInt(ISSUNT);
      if (totalStock > 0) {
        stockClassObj['IOVUNT_PCT'] = parseInt(IOVUNT) ? Math.round( (parseInt(IOVUNT) / totalStock) *1000)/10 : 0;
        stockClassObj['IPOUNT_PCT'] = parseInt(IPOUNT) ? Math.round( (parseInt(IPOUNT) / totalStock) *1000 )/10 : 0;
        stockClassObj['IPRUNT_PCT'] = parseInt(IPRUNT) ? Math.round( (parseInt(IPRUNT) / totalStock) *1000 )/10 : 0;
        stockClassObj['IFBUNT_PCT'] = parseInt(IFBUNT) ? Math.round( (parseInt(IFBUNT) / totalStock) *1000 )/10 : 0;
        stockClassObj['IDLUNT_PCT'] = parseInt(IDLUNT) ? Math.round( (parseInt(IDLUNT) / totalStock) *1000 )/10 : 0;
        stockClassObj['IRPUNT_PCT'] = parseInt(IRPUNT) ? Math.round( (parseInt(IRPUNT) / totalStock) *1000 )/10 : 0;
        stockClassObj['ISSUNT_PCT'] = parseInt(ISSUNT) ? Math.round( (parseInt(ISSUNT) / totalStock) *1000 )/10 : 0; 

      }
    } 
    return stockClassObj;

  } 

  //Set card fields as API response is incorrect & has too many fields. Pick relevant 
  setCardFields = () => {
    const { stockStatusLabelsData, valueData, newValueData } = this.props.ItemPropertiesData;
    const { companyDetails } = this.props;
    let demandToDate = { ...ITEM_STOCK_STATUS_DEMAND_TO_DATE }
    let cardfields = [];
    let adjCardFields = [];
    let itemDetailObj = this.getValueData(valueData, newValueData);

    if (itemDetailObj && stockStatusLabelsData && stockStatusLabelsData.tabcards) {
      stockStatusLabelsData.tabcards.map(formCard => {
        if (formCard.cardkey == PERIOD_TO_DATE_CARD_KEY) {

          cardfields = formCard.cardfields.map(field => {

            if (field.FDFNAM) {
              
              if (["PERDH", "PERNO", "PERDF"].includes(field.FDFNAM.trim())) {
                return field;
              }

              if (parseInt(itemDetailObj.IPERDF) == 12 && ["SHP12", "LST12", "PRM12", "PER12"].includes(field.FDFNAM.trim())) {

                if (field.FDFNAM.trim() == "PER12")
                field.TLLAB = this.getMessageText('52661'); //Current Forecast Period   

                return field;
              }
              else if (parseInt(itemDetailObj.IPERDF) == 13 && ["SHP13", "LST13", "PRM13", "PER13"].includes(field.FDFNAM.trim())) {

                if (field.FDFNAM.trim() == "PER13")
                field.TLLAB = this.getMessageText('52661'); //Current Forecast Period  

                return field;
              }
              else if (parseInt(itemDetailObj.IPERDF) == 52 && ["SHP52", "LST52", "PRM52", "PER52"].includes(field.FDFNAM.trim())) {

                if (field.FDFNAM.trim() == "PER52")
                  field.TLLAB = this.getMessageText('52661'); //Current Forecast Period  

                return field;
              }

            }

            return false;
          }).filter(field => field)

          if (cardfields.length > 0) {

            demandToDate.TLLAB = this.getMessageText('51017');  //Demand to Date
            cardfields.push(demandToDate);
          }

        }
        if (formCard.cardkey == ADJ_TO_STOCK_STS_CARD_KEY) {
          let changeStoreOverUnderLabel = (this.getItemFieldData('GetOverstockOvrr') || this.getItemFieldData('GetNumberDependentWhses'));

          if (changeStoreOverUnderLabel == true) {
            formCard.cardfields.map(field => {
              if (field.FDFNAM.trim() == "PIUNT") {
                field.TLLAB = this.getMessageText('40156');  //Store Over/Understock*
              }
              if (field.FDFNAM.trim() == "QHELD") {
                if (parseInt(itemDetailObj.IOHHDT) < parseInt(companyDetails.CJDATE)) {
                  field.disabled = true;
                  this.setState({qtyHeldStatusDisabled : true})
                }
              }
            })
          }
          adjCardFields = [... formCard.cardfields]; 
        }

      })

    }
    if (cardfields.length > 0)
      this.setState({periodToDateCardFields: cardfields})
    if (adjCardFields.length > 0)
      this.setState({adjToStockStatusLabels: adjCardFields})
  }


  //Conditional Stock Status Card update
  adjToStockStatusCard = (key, val) => {
    const adjToStockStatusLabels = this.state.adjToStockStatusLabels;
    // const { companyDetails } = this.props;
    let updateLabels = false;
    let qtyHeldStatusDisabled = this.state.qtyHeldStatusDisabled; 


    if (key == 'IOHHDT') { //Qty Held Date 
      if (parseInt(val) > 0 && this.state.qtyHeldStatusDisabled) {
        this.setState({ qtyHeldStatusDisabled: !qtyHeldStatusDisabled })
        updateLabels = "QHELD";
      } else if (!(parseInt(val) > 0) && !this.state.qtyHeldStatusDisabled) {
        this.setState({ qtyHeldStatusDisabled: !qtyHeldStatusDisabled})
        updateLabels = "QHELD";
      }
    }

    if (updateLabels) {
      adjToStockStatusLabels.forEach(field => {
        if (field.FDFNAM.trim() == "QHELD" && updateLabels == "QHELD") {
            field.disabled = !qtyHeldStatusDisabled;
            //AssignmentReturnedSharp;
        }
      })
    }

  }

  getMessageText = id => {
    const { messages } = this.props;
    if (messages && messages['H' + id]) {
      return messages['H' + id].TLLAB;
    }
    else return '';
  }

  getItemFieldData = (fieldDescription) => {
    const { valueData } = this.props.ItemPropertiesData;
    if (fieldDescription) {
      switch (fieldDescription.toLowerCase()) {
        case 'GetOverstockOvrr'.toLowerCase():
          return (valueData.IORBYC == "1" ? true : false)
        case 'GetNumberDependentWhses'.toLowerCase():
          return (parseInt(valueData.IXNUM) == 0 ? false : true)
        case 'qtyHeldDate': 
          return (newValueData)
      }
    }
  }

    render() {

        const { classes, setSaveData, globalDateFormat, filterCriteriaDetails, pageFilterOptions,
          globalFilterOptions, columnDefs, currentPage, itemData, canUpdateComponent } = this.props;
        const { loading, valueData, newValueData, stockStatusLabelsData, itemMiscData, ignoreCheckboxesArray = false, buyerMinMaxFieldsArray = false, stockClassLabelsData } = this.props.ItemPropertiesData;
        const { tabcards } = this.state;
        if (this.state.hasHardError) {
        return <h2> Oops Something Went Wrong </h2>
        }
        return (
        <div>
            {(!loading && tabcards && tabcards.length) ? (
            <>
                <Grid container className={classes.pageContainer}>
                    <Grid item xs={4} className={classes.pageContainerSeventy}>       
                       {/* <div> */}
                       <div className={classes.simpleCardGroup}>
                                {!loading &&
                                tabcards.map(formCard => {
                                    if (formCard.cardkey == STOCK_STATUS_CARD_KEY) {
                                        return <CardComponent title= {formCard.cardtitle} className={`${classes.card} ${classes.marginLeftZero} ${classes.stockStatusCardWidth}`}>
                                            <FormFieldsGenerator
                                            handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                                            key={formCard.cardkey}
                                            parentPage={ITEMS_LIST_PAGE}
                                            className=".STOCK_STATUS_COMPONENTS"
                                            fieldsArray={formCard.cardfields}
                                            valuesArray={this.getValueData(valueData, newValueData)}
                                            handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                            enableAddButton={(e) => { setSaveData(e) }}
                                            globalDateFormat={globalDateFormat}
                                            filterCriteriaDetails={filterCriteriaDetails}
                                            pageFilterOptions={pageFilterOptions}
                                            globalFilterOptions={globalFilterOptions}
                                            columnDefs={columnDefs}
                                            currentPage={currentPage}
                                            parentData={valueData}
                                            cardHasCheckBox={true}
                                            labelDisplayCharacters={20}
                                            valueDisplayCharacters={15}
                                            canUpdateComponent={canUpdateComponent}
                                            />
                                        </CardComponent>
                                   }
                                   
                               })}
                            </div>
                            <div className={classes.simpleCardGroup}>
                                {!loading &&
                                tabcards.map(formCard => { 
                                    if (formCard.cardkey == INFORMATION_ONLY_CARD_KEY) { 
                                        return <CardComponent title= {formCard.cardtitle} className={`${classes.card} ${classes.marginLeftZero} ${classes.infoCardStyle}`}>
                                            <FormFieldsGenerator
                                            handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                                            key={formCard.cardkey}
                                            parentPage={ITEMS_LIST_PAGE}
                                            className="STOCK_STATUS_COMPONENTS"
                                            fieldsArray={formCard.cardfields}
                                            valuesArray={this.getValueData(valueData, newValueData)}
                                            handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                            enableAddButton={(e) => { setSaveData(e) }}
                                            globalDateFormat={globalDateFormat}
                                            filterCriteriaDetails={filterCriteriaDetails}
                                            pageFilterOptions={pageFilterOptions}
                                            globalFilterOptions={globalFilterOptions}
                                            columnDefs={columnDefs}
                                            currentPage={currentPage}
                                            parentData={valueData}
                                            labelDisplayCharacters={20}
                                            valueDisplayCharacters={15}
                                            canUpdateComponent={canUpdateComponent}
                                            />
                                        </CardComponent>
                                    }     
                                })}
                            </div> 
                         
                        </Grid>
                        <Grid item xs={4} className={classes.pageContainerSeventy}>   
                        <div className={classes.simpleCardGroup}>
                                {!loading && Object.keys(this.state.adjToStockStatusLabels).length && 
                                tabcards.map(formCard => {   
                                    if (formCard.cardkey == ADJ_TO_STOCK_STS_CARD_KEY) { 
                                        return <CardComponent title= {formCard.cardtitle} className={`${classes.card} ${classes.marginLeftZero}  ${classes.adjStockCardStyle}`}>
                                            <FormFieldsGenerator
                                            handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                                            key={this.state.adjToStockStatusLabels}
                                            parentPage={ITEMS_LIST_PAGE}
                                            className="STOCK_STATUS_COMPONENTS"
                                            fieldsArray={formCard.cardfields}
                                            valuesArray={this.getValueData(valueData, newValueData)}
                                            handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                            enableAddButton={(e) => { setSaveData(e) }}
                                            globalDateFormat={globalDateFormat}
                                            filterCriteriaDetails={filterCriteriaDetails}
                                            pageFilterOptions={pageFilterOptions}
                                            globalFilterOptions={globalFilterOptions}
                                            columnDefs={columnDefs}
                                            currentPage={currentPage}
                                            parentData={valueData}
                                            labelDisplayCharacters={20}
                                            valueDisplayCharacters={16}
                                            canUpdateComponent={canUpdateComponent}
                                            />
                                        </CardComponent>
                                    }
                                     
                                })}
                            </div> 
                    </Grid>
                    <Grid item xs={4}  className={classes.pageContainerFifty}>       
                        <div>
                            <div className={classes.simpleCardGroup}>
                                {!loading && this.state.periodToDateCardFields &&
                                tabcards.map(formCard => { 
                                    if (formCard.cardkey == PERIOD_TO_DATE_CARD_KEY && this.state.periodToDateCardFields && this.state.periodToDateCardFields.length > 0) { 
                                        return <CardComponent title= {formCard.cardtitle} className={`${classes.card} ${classes.marginLeftZero} ${classes.periodToDateCardStyle}`}>
                                            <FormFieldsGenerator
                                            handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                                            key={formCard.cardkey}
                                            parentPage={ITEMS_LIST_PAGE}
                                            className="STOCK_STATUS_COMPONENTS"
                                            fieldsArray={this.state.periodToDateCardFields}
                                            valuesArray={this.getValueData(valueData, newValueData)}
                                            handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                            enableAddButton={(e) => { setSaveData(e) }}
                                            globalDateFormat={globalDateFormat}
                                            filterCriteriaDetails={filterCriteriaDetails}
                                            pageFilterOptions={pageFilterOptions}
                                            globalFilterOptions={globalFilterOptions}
                                            columnDefs={columnDefs}
                                            currentPage={currentPage}
                                            parentData={valueData}
                                            labelDisplayCharacters={23}
                                            valueDisplayCharacters={15}
                                            canUpdateComponent={canUpdateComponent}
                                            />
                                        </CardComponent>
                                    }
                                   
                            })}
                            </div>                   
                        </div>     
                         
                    </Grid>
              
                    <Grid item xs={4} className={classes.pageContainerFifty}>       
                      {/*  <div> */}
               
                            <div className={classes.simpleCardGroup}>
                                {!loading &&
                                stockClassLabelsData.tabcards.map(formCard => {  
                                    if (formCard.cardkey == UNIT_DISTRIBUTION_CARD_KEY) { 
                                        return <CardComponent title= {formCard.cardtitle} className={`${classes.card} ${classes.marginLeftZero} ${classes.unitDistCardStyles}`}>
                                            <FormFieldsGenerator
                                            handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                                            key={formCard.cardkey}
                                            parentPage={ITEMS_LIST_PAGE}
                                            className="STOCK_STATUS_COMPONENTS"
                                            fieldsArray={formCard.cardfields}
                                            valuesArray={this.getValueData(valueData, newValueData)}
                                            handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                            enableAddButton={(e) => { setSaveData(e) }}
                                            globalDateFormat={globalDateFormat}
                                            filterCriteriaDetails={filterCriteriaDetails}
                                            pageFilterOptions={pageFilterOptions}
                                            globalFilterOptions={globalFilterOptions}
                                            columnDefs={columnDefs}
                                            currentPage={currentPage}
                                            parentData={valueData}
                                            labelDisplayCharacters={25}
                                            valueDisplayCharacters={15}
                                            canUpdateComponent={canUpdateComponent}
                                            />
                                        </CardComponent>
                                    } 
                                })}
                            </div>  
                    </Grid>
                    <Grid item xs={8} className={classes.pageContainerFifty}>  
                      <div className={classes.simpleCardGroup}>
                        {!loading && valueData ? 
                          <CardComponent title= {this.getMessageText('56118')} className={`${classes.card} ${classes.marginLeftZero}`}>
                                  <Box width='60%' align = "center">
                                      <StockClass
                                      graphData={this.stockClassPercent(valueData)} 
                                      getMessageText = {this.getMessageText}
                                      />
                                    </Box>
                          </CardComponent>: ""
                        }
                      </div>
                      
                    </Grid>              
                </Grid>
            </>
            ) : (<Spinner loading type="StockStatusTab" />) 
            }
        </div>
        );
    }
}

StockStatus.propTypes = propTypes;

export default withStyles(style)(StockStatus);

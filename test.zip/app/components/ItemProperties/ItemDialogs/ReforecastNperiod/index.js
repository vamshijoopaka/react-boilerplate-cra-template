import Box from '@material-ui/core/Box';
import { withStyles } from '@material-ui/core/styles';
import DialogComponent from 'components/common/DialogComponent';
import FormFieldsGenerator from 'components/common/FormFieldsGenerator';
import GridErrorMessages from 'components/common/GridErrorMessages';
import theme from 'jda-gcp-theme';
import React from 'react';
import { compose } from 'redux';
import { TEXT_OK,TEXT_CANCEL } from 'components/common/constants';

const style = theme => ({
    pageContainer: {
        display: 'flex',
        borderTop: 'none',
        padding: '10px 20px',
    },
    notesForBlock: {
        display: 'flex',
        flexDirection: 'column',
        border: '1px solid var(--divider-line)',
        padding: '10px 10px 0 10px',
        position: 'relative',
        width: '100%'
    },
    notesForLabel: {
        position: 'absolute',
        top: '-7px',
        left: '10px',
        background: 'var(--background-content)',
        padding: '0 8px',
    },
    dialogClass: {
        minWidth: '31%',
        maxWidth: '31%',
        height: '35%'
    }
})

class ReforecastNperiod extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            INIT_ARRAY: [{"IANPER":""}],
            body:{
                "IACOMP": "",
                "IAWHSE": "",
                "IAVNDR":"",
                "IANPER": "",
                "IAAPBT": "0"
            }
        }
        }

    handleClose = () => {
        this.props.closeDialog('reforecastNPeriod');
    };
    handleChangeValue(key, val, field) {
        this.setState({ [key]: val  })
    }
    handleSubmit = ()=>{
        let valueData =this.props.data;
        let obj={};
        obj={
            "IACOMP": valueData.ICOMP,
            "IAWHSE": valueData.IWHSE,
            "IAVNDR": valueData.IVNDR,
            "IAITEM": valueData.IITEM,
            "IANPER": this.state.IANPER,
            "IAAPBT": "0"
        }
        this.props.reforecast(obj);
        this.props.closeDialog();
    }
    render(){
        const  {tabcards}=this.props.labelData;
        const { classes, currentPage, getLabelValue, globalDateFormat } = this.props;

        return(
            <DialogComponent
                isOpen={this.props.isOpen}
                dialogTitle={this.props.title}
                cancelText={TEXT_CANCEL}
                submitText={TEXT_OK}
                handleClose={this.props.closeDialog}
                handleCancel={this.props.closeDialog}
                className={classes.dialogClass}
                handleSubmit= { e => this.handleSubmit(true) }
                disableSubmit={!(this.state.IANPER)}
                >
                <div>
                    {tabcards && tabcards.length && currentPage && (
                        <div className={classes.pageContainer}>
                            {tabcards.map(formCard => {
                                if (formCard.cardkey == '88888') {
                                    return <div className={classes.notesForBlock}>
                                        <Box mb={theme.spacing(0.5)} className={classes.notesForLabel}>{formCard.cardtitle}</Box>
                                        <FormFieldsGenerator
                                            cardHasCheckBox={true}
                                            noMassMaintenance={true}
                                            handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                                            key={formCard.cardkey}
                                            parentPage={'items'}
                                            fieldsArray={formCard.cardfields}
                                            valuesArray={this.state.INIT_ARRAY}
                                            handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                            enableAddButton={(e) => false}
                                            globalDateFormat={globalDateFormat}
                                            currentPage={currentPage}
                                            parentData={this.props.data}
                                            valueDisplayCharacters={15}
                                        />
                                    </div>
                                }
                            })}
                        </div>
                    )}
                </div>
            </DialogComponent>
        );
    }
}
export default compose(
    withStyles(style)
)(ReforecastNperiod);
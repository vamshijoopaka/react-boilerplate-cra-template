export const itemClassificationSubmitKeyDS =
[
    {
        "COLUMN_NAME": "INCOMP",
        "TABLE_NAME": "DSCITMCL",
        "ORDINAL_POSITION": "1",
        "DATA_TYPE": "CHAR    ",
        "LENGTH": "3",
        "NUMERIC_SCALE": null,
        "COLUMN_HEADING": "Company ID",
        "TABLE_SCHEMA": "E3T19100",
        "DDS_TYPE": "A"
    },
    {
        "COLUMN_NAME": "INWHSE",
        "TABLE_NAME": "DSCITMCL",
        "ORDINAL_POSITION": "2",
        "DATA_TYPE": "CHAR    ",
        "LENGTH": "3",
        "NUMERIC_SCALE": null,
        "COLUMN_HEADING": "Warehouse ID",
        "TABLE_SCHEMA": "E3T19100",
        "DDS_TYPE": "A"
    },
    {
        "COLUMN_NAME": "INREGO",
        "TABLE_NAME": "DSCITMCL",
        "ORDINAL_POSITION": "3",
        "DATA_TYPE": "CHAR    ",
        "LENGTH": "3",
        "NUMERIC_SCALE": null,
        "COLUMN_HEADING": "WREGON",
        "TABLE_SCHEMA": "E3T19100",
        "DDS_TYPE": "A"
    },
    {
        "COLUMN_NAME": "INGRP1",
        "TABLE_NAME": "DSCITMCL",
        "ORDINAL_POSITION": "4",
        "DATA_TYPE": "CHAR    ",
        "LENGTH": "5",
        "NUMERIC_SCALE": null,
        "COLUMN_HEADING": "Item Group 1",
        "TABLE_SCHEMA": "E3T19100",
        "DDS_TYPE": "A"
    },
    {
        "COLUMN_NAME": "INGRP2",
        "TABLE_NAME": "DSCITMCL",
        "ORDINAL_POSITION": "5",
        "DATA_TYPE": "CHAR    ",
        "LENGTH": "5",
        "NUMERIC_SCALE": null,
        "COLUMN_HEADING": "Item Group 2",
        "TABLE_SCHEMA": "E3T19100",
        "DDS_TYPE": "A"
    },
    {
        "COLUMN_NAME": "INGRP3",
        "TABLE_NAME": "DSCITMCL",
        "ORDINAL_POSITION": "6",
        "DATA_TYPE": "CHAR    ",
        "LENGTH": "5",
        "NUMERIC_SCALE": null,
        "COLUMN_HEADING": "Item Group 3",
        "TABLE_SCHEMA": "E3T19100",
        "DDS_TYPE": "A"
    },
    {
        "COLUMN_NAME": "INGRP4",
        "TABLE_NAME": "DSCITMCL",
        "ORDINAL_POSITION": "7",
        "DATA_TYPE": "CHAR    ",
        "LENGTH": "5",
        "NUMERIC_SCALE": null,
        "COLUMN_HEADING": "Item Group 4",
        "TABLE_SCHEMA": "E3T19100",
        "DDS_TYPE": "A"
    },
    {
        "COLUMN_NAME": "INGRP5",
        "TABLE_NAME": "DSCITMCL",
        "ORDINAL_POSITION": "8",
        "DATA_TYPE": "CHAR    ",
        "LENGTH": "5",
        "NUMERIC_SCALE": null,
        "COLUMN_HEADING": "Item Group 5",
        "TABLE_SCHEMA": "E3T19100",
        "DDS_TYPE": "A"
    },
    {
        "COLUMN_NAME": "INGRP6",
        "TABLE_NAME": "DSCITMCL",
        "ORDINAL_POSITION": "9",
        "DATA_TYPE": "CHAR    ",
        "LENGTH": "5",
        "NUMERIC_SCALE": null,
        "COLUMN_HEADING": "Item Group 6",
        "TABLE_SCHEMA": "E3T19100",
        "DDS_TYPE": "A"
    },
    {
        "COLUMN_NAME": "INTYPE",
        "TABLE_NAME": "DSCITMCL",
        "ORDINAL_POSITION": "10",
        "DATA_TYPE": "CHAR    ",
        "LENGTH": "1",
        "NUMERIC_SCALE": null,
        "COLUMN_HEADING": "TYPE",
        "TABLE_SCHEMA": "E3T19100",
        "DDS_TYPE": "A"
    },
    {
        "COLUMN_NAME": "INTIME",
        "TABLE_NAME": "DSCITMCL",
        "ORDINAL_POSITION": "11",
        "DATA_TYPE": "NUMERIC ",
        "LENGTH": "2",
        "NUMERIC_SCALE": "0",
        "COLUMN_HEADING": "TIME                FRAME",
        "TABLE_SCHEMA": "E3T19100",
        "DDS_TYPE": "S"
    },
    {
        "COLUMN_NAME": "INALLC",
        "TABLE_NAME": "DSCITMCL",
        "ORDINAL_POSITION": "12",
        "DATA_TYPE": "CHAR    ",
        "LENGTH": "1",
        "NUMERIC_SCALE": null,
        "COLUMN_HEADING": "ALL                 CLASS",
        "TABLE_SCHEMA": "E3T19100",
        "DDS_TYPE": "A"
    },
    {
        "COLUMN_NAME": "INALLS",
        "TABLE_NAME": "DSCITMCL",
        "ORDINAL_POSITION": "13",
        "DATA_TYPE": "CHAR    ",
        "LENGTH": "1",
        "NUMERIC_SCALE": null,
        "COLUMN_HEADING": "ALL SERV LEVEL GOAL",
        "TABLE_SCHEMA": "E3T19100",
        "DDS_TYPE": "A"
    }
]
export const ITEM_DETAIL_UNITS_WORKDAYS = '28354';
export const ITEM_DETAIL_DEMAND_ORDER_COMPONENTS = '28363';
export const ITEM_DETAIL_USER_DEFINED_FIELDS = '28356';

export const DEFAULT_VALUE_URL_DATA = [
  { accessor: 'COMP', operator: '=', fieldValue: '', prefixFlag: 0 },
  { accessor: 'WHSE', operator: '=', fieldValue: '', prefixFlag: 0 },
  { accessor: 'VNDR', operator: '=', fieldValue: '', prefixFlag: 0 },
  { accessor: 'SUBV', operator: '=', fieldValue: '', prefixFlag: 0 },
  { accessor: 'SUPV', operator: '=', fieldValue: '', prefixFlag: 0 },
  { accessor: 'ITEM', operator: '=', fieldValue: '', prefixFlag: 0 },
  { accessor: 'PERDF', operator: '=', fieldValue: '', prefixFlag: 0 }//E3C-31389, 11thJun2021, Thanuja
];

export const CUSTOM_CARD_ONE = '4434';
export const CUSTOM_CARD_TWO = '4501';
export const CUSTOM_CARD_THREE = '3331';
export const CUSTOM_CARD_FOUR = '4452';

export const CUSTOM_CARD_KEY = '50916';



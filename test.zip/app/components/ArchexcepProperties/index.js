/**
 *
 * ArchexcepProperties
 *
 */

import React, { memo } from 'react';
import { compose } from 'redux';
import { connect } from 'react-redux';
import injectReducer from 'utils/injectReducer';
import injectSaga from 'utils/injectSaga';
import { injectIntl, intlShape, FormattedMessage } from 'react-intl';
import { withRouter } from 'react-router-dom';
import AppBar from '@material-ui/core/AppBar';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import Typography from '@material-ui/core/Typography';
import { Formik } from 'formik';
import Button from '@material-ui/core/Button';

import {
  getListPredecessor,
  prepareValueDataForArchexceps,
  getUpdateRestrictionOnComponent,
  getParentListPredecessor,
  capitalizeFirstLetter,
  setSortDataFromSortCriteria,
  getDefaultSortInfo,
  setNumberFields,
  getFilterDataFromLocalStorage,
  getDateFromJulian,
  getFilterDataFromCriteriaDetails,
  handleFieldValuesByLength,
  prepareValueWithSpaces,
} from 'utils/util';

import { withStyles } from '@material-ui/core';
import Filter from 'containers/common/Filter';
import SortByComponent from 'containers/common/SortByComponent';
import FormattedMessageComponent from 'components/common/FormattedMessageComponent';

import {
  getDBSelectorFilterValues,
  prepareTooltipValues
} from 'utils/filterData';

import {
  errorMessageLabelsFormat
} from './selector';

import {
  HeaderAPIValuesJSON,
  ARCHEXCEP_PROPERTIES,
  DEFAULT_VALUE_URL_DATA,
  LABEL_LIST_URL_DATA,
  FILTER_DATA,
} from './constants';

import {
  ARCHEXCEPS_LIST_PAGE,
  ARCHEXCEP_PROPERTIES_PAGE,
  INITIAL_PAGE_PROPS,
  COLUMN_VALUE_ACCESSOR,
  GLOBAL_FILTER_OPTIONS,
  TEXT_ALERT,
  TEXT_OK,
  COLUMN_HEADER_ACCESSOR,
  COLUMN_FIELD_LEN,
} from '../common/constants';

import { isEqual } from 'lodash';
import { createStructuredSelector } from 'reselect';
import Spinner from '../common/Spinner';
import GridErrorMessages from 'components/common/GridErrorMessages';

import './styles.scss';

import {
  updateBreadCrumbContextMenu,
  getBreadcrumbUniqueRandomString,
  onChangeContextMenu,
} from 'utils/contextMenu';

import ConfirmationDialog from 'components/common/ConfirmationDialog';
import Header from './Header';
import moment from 'moment';
import { prepareFilterForArchexcepMembers } from './archexcep-util';
import ArchexcepTab from './ArchexcepTab';


function TabContainer(props) {
  return (
    <Typography className="minWidth1100" component="div">
      {props.children}
    </Typography>
  );
}

const style = theme => ({
  propertiesContentWrapper: {
    margin: '10px auto',
    fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
    borderRadius: '4px',
    overflow: 'hidden',
    boxShadow: '0 2px 4px var(--secondary-s10)',
    overflowX: 'auto',
  },
  hideContent: {
    display: 'none',
  },
  showContent: {
    display: 'block',
  },
});

class ArchexcepProperties extends React.Component {
  constructor() {
    super();
    this.state = {
      tab: 0,
      isSaveDataDisabled: true,
      headerData: false,
      isDataUpdated: false,
      archexcepName: '',
      columnDefs: [],
      archexcepDataJSON: [],
      stateData: false,
      updatedBrackets: false,
      updatedNotes: false,
      totalCount: 0,
      fromPage: false,
      hasError: false,
      ServerError: false,

      updatedFieldValues: {},
      selectedRow: null,
      canUpdateComponent: false,
      changeDataAPI: false,
      openFilterPopup: false,
      bracketsNotesFilterObj: {},
      radioButtonValue: 'cg',
      isFiltersChanged: false,
      previousFilterValues: false,
      showConfirmationDialog: false,
      dialogTitle: '',

      hasWarning: false,
      fromListPage: null,
      prevStateFilterProps: [],
      prevStateSortProps: [],
      hasFiltersChanged: false,
      hasSortChanged: false,
      openSortPopup: false,
      isDataLoaded: false,
      isInitialAPICall: true,
      valueDataFailureMessages: [],
      headerValues:HeaderAPIValuesJSON[0],
      noRecordForFilter: false
    };

    this.prepareHeaderDataJSON = this.prepareHeaderDataJSON.bind(this);
    this.handleArchexcepHeaderLeftArrowClick = this.handleArchexcepHeaderLeftArrowClick.bind(this);
    this.handleArchexcepHeaderRightArrowClick = this.handleArchexcepHeaderRightArrowClick.bind(this);
    this.getApiObj = this.getApiObj.bind(this);
    this.makeAPICallForPageUpDown = this.makeAPICallForPageUpDown.bind(this);
    this.getApiObjForPageUpDown = this.getApiObjForPageUpDown.bind(this);
    // this.handleSubmitDataCallBack = this.handleSubmitDataCallBack.bind(this);
    this.setHeaderAndSendAPI = this.setHeaderAndSendAPI.bind(this);
    this.setArchexcepColumnDefs = this.setArchexcepColumnDefs.bind(this);
    this.getLabelValue = this.getLabelValue.bind(this);
    this.setRecordDataValues = this.setRecordDataValues.bind(this);
    this.forceUpdateHandler = this.forceUpdateHandler.bind(this);
    // this.saveDataOnFocusOut = this.saveDataOnFocusOut.bind(this);
    // this.sendAPICallOnChange = this.sendAPICallOnChange.bind(this);
    this.setFilterValuesFromState = this.setFilterValuesFromState.bind(this);
    // this.onFieldValueChange = this.onFieldValueChange.bind(this);
    // this.onRowSelectedChange = this.onRowSelectedChange.bind(this);
    this.handleArchexcepHeaderFilterClick = this.handleArchexcepHeaderFilterClick.bind(this);
    // this.handleArchexcepHeaderSortClick = this.handleArchexcepHeaderSortClick.bind(this);
    this.onContextMenuChange = this.onContextMenuChange.bind(this);
    this.sendAPICallForValues = this.sendAPICallForValues.bind(this);
    // this.setStateWSVIds = this.setStateWSVIds.bind(this);
    this.handleNoDataSets = this.handleNoDataSets.bind(this);
    // this.setAddressValueDataOnFocutOut = this.setAddressValueDataOnFocutOut.bind(this);
    // this.sendAPICallOnChangeAddress = this.sendAPICallOnChangeAddress.bind(this);
    // this.handleSubmitAddressDataCallBack = this.handleSubmitAddressDataCallBack.bind(this);
    this.handleValueDataErrorMessages = this.handleValueDataErrorMessages.bind(this);
  }

  handleNoDataSets() {
    const { history } = this.props;
    // const { archexcepLabelsData, bracketLabelJson } = this.props.ArchexcepPropertiesData;
    const { archexcepLabelsData, bracketLabelJson } = this.props.ArchexcepPropertiesData;
    if (!this.state.isDataLoaded) {
      this.props.setNoDataCallBackValue(true);
      const paramsString = window.location.search;
      if (paramsString && paramsString.length) {
        const paramsArray = paramsString.split('?');
        if (paramsArray && paramsArray.length && paramsArray.length > 1) {
          const params = paramsArray[1].split('&');
          const tabId = params[0].split('=')[1];
          const breadCrumbId = params[1].split('=')[1];
          this.props.removeCurrentRecordObj(tabId, breadCrumbId);
        }
      }
      }
  }

  handleArchexcepHeaderFilterClick() {
    if (this.state.isFiltersChanged && this.props.ArchexcepPropertiesData.isValueDataAPIFailure) {
      this.props.onSetFilterProps(this.state.previousFilterValues);
      this.props.setGlobalFilterProps(this.state.previousFilterValues);
      this.props.setChildTabFilterProps(this.state.previousFilterValues);
      this.setState({ isFiltersChanged: false });
      this.props.setValueDataAPIFailureFlag(false);
    }
    this.setState({ openFilterPopup: !this.state.openFilterPopup, noRecordForFilter: false });
  }

  openNoDataPopUp = (val) => {
    this.setState({ showConfirmationDialog: val });
    this.setState({ hasWarning: val });
    this.setState({ dialogTitle: val ? TEXT_ALERT : '' });
    this.setState({ fromHeaderENG: val });
    this.setState({ dialogBody: val ? 'E28648' : '' });
    this.setState({ noRecordForFilter: true })
  }

  
  getLabelValue(id) {
    return <FormattedMessageComponent id={id} />;
  }

  handleChangeTab = (event, value) => {
    this.setState({ tab: value });
  };

  setFilterValuesFromState(values) {
    const filterValues = [];
    const { columnDefs } = this.state;
    if (
      (columnDefs && columnDefs.length) ||
      (this.columnDefData && this.columnDefData.length)
    ) {
      const colData = columnDefs && columnDefs.length ? columnDefs : this.columnDefData;
      values.forEach(value => {
        const isExists = colData.find(
          column => column[COLUMN_VALUE_ACCESSOR].trim() == value.accessor,
        );
        if (isExists) {
          filterValues.push(value);
        }
      });
      if (filterValues && filterValues.length) {
        this.props.onSetFilterProps(filterValues);
        this.props.setGlobalFilterProps(filterValues);
        return filterValues;
      }
    } else {
      this.props.onSetFilterProps(values);
      this.props.setGlobalFilterProps(values);
      return values;
    }
  }

  getApiObj(recordData, record, currentPage, pageProps) {
    let recordObj = false;
    if (record) {
      recordObj = record;
    }
    const apiObj = {
      recordData,
      pageProps,
      direction: pageProps.isForwardDirection,
      record: recordObj,
      currentPage,
      parentPage: ARCHEXCEPS_LIST_PAGE,
    };
    return apiObj;
  }

  getApiFilterObj(filterProps, currentPage, pageProps) {

    let apiObj = {
      filterProps,
      pageProps: pageProps,
      direction: pageProps.isForwardDirection,
      currentPage: currentPage,
      parentPage: ARCHEXCEP_LIST // ORDER_LIST
    };
    return apiObj;
  }

  prepareHeaderDataJSON(obj, fromPage) {
    const data = {};
    const headerValues = this.state.headerValues;
    const prefix = getListPredecessor(ARCHEXCEPS_LIST_PAGE);

    const keyComp = `${prefix}COMP`;
    const archexcepComp = obj[keyComp];
    headerValues.ECOMP = archexcepComp ? archexcepComp.trim() : archexcepComp;
    
    const keyVendorId = `${prefix}VNDR`;
    const vendorId = obj[keyVendorId];
    headerValues.EVNDR = vendorId ? vendorId.trim() : vendorId;

    const keySubVendorId = `${prefix}SUBV`;
    const subVendorId = obj[keySubVendorId];
    headerValues.ESUBV = subVendorId ? subVendorId.trim() : subVendorId;

    const keyVendorName = 'VNAME';
    const vendorName = obj[keyVendorName];
    headerValues.VNAME = vendorName ? vendorName.trim() : vendorName;

    const keyWarehouseId = `${prefix}WHSE`;
    const warehouseId = obj[keyWarehouseId];
    headerValues.EWHSE = warehouseId ? warehouseId.trim() : warehouseId;

    const keyWarehouseName = `${prefix}WNAME`;
    const warehouseName = obj[keyWarehouseName]; //changed to KeyWarehouseName when getting Warehouse Data
    headerValues.EWNAME = warehouseName ? warehouseName.trim() : warehouseName;

    const keyItemId = `${prefix}ITEM`;
    const itemId = obj[keyItemId];
    headerValues.EITEM = itemId ? itemId.trim() : itemId;

    const keyItemName = 'INAME';
    const itemName = obj[keyItemName];
    headerValues.INAME = itemName ? itemName.trim() : itemName;

    const keyBuyer = `${prefix}BUYR`;
    const buyerId = obj[keyBuyer];
    headerValues.EBUYR = buyerId ? buyerId.trim() : buyerId;

    const keyItemGrp1 = 'IGRP1';
    const itemGrp1 = obj[keyItemGrp1];
    headerValues.IGRP1 = itemGrp1 ? itemGrp1.trim() : itemGrp1;

    const keyItemGrp2 = 'IGRP2';
    const itemGrp2 = obj[keyItemGrp2];
    headerValues.IGRP2 = itemGrp2 ? itemGrp2.trim() : itemGrp2;

    const keyItemGrp3 = 'IGRP3';
    const itemGrp3 = obj[keyItemGrp3];
    headerValues.IGRP3 = itemGrp3 ? itemGrp3.trim() : itemGrp3;

    const keyItemGrp4 = 'IGRP4';
    const itemGrp4 = obj[keyItemGrp4];
    headerValues.IGRP4 = itemGrp4 ? itemGrp4.trim() : itemGrp4;
    
    const keySuper = `${prefix}SUPER`;
    const superId = obj[keySuper];
    headerValues.ESUPER = superId ? superId.trim() : superId;
    
    const keyUpc = `${prefix}UPC#`;
    const upcId = obj[keyUpc];
    headerValues['EUPC#'] = upcId ? upcId.trim() : upcId;
    
    const keyMfgId = `${prefix}MFGID`;
    const mfgId = obj[keyMfgId];
    headerValues.EMFGID = mfgId ? mfgId.trim() : mfgId;
    
    const keyRegion = `${prefix}REGON`;
    const regionId = obj[keyRegion];
    headerValues.EREGON = regionId ? regionId.trim() : regionId;
    
    const keyTiehi = `${prefix}TIEHI`;
    const tiehi = obj[keyTiehi];
    headerValues.ETIEHI = tiehi ? tiehi.trim() : tiehi;

    this.setState({headerValues:headerValues})
    
    return [headerValues];
  }

  forceUpdateHandler() {
    this.forceUpdate();
  }

  // setStateWSVIds(filterProps) {
  //   const obj = JSON.parse(JSON.stringify(this.state.bracketsNotesFilterObj));
  //   for (let i = 0; i < filterProps.length; i++) {
  //     if (filterProps[i].accessor == 'WHSE') {
  //       obj.warehouseId = filterProps[i].fieldValue;
  //     } else if (filterProps[i].accessor == 'VNDR') {
  //       obj.archexcepId = filterProps[i].fieldValue;
  //     } else if (filterProps[i].accessor == 'SUBV') {
  //       obj.subarchexcepId = filterProps[i].fieldValue;
  //     }
  //   }
  //   this.setState({ bracketsNotesFilterObj: JSON.parse(JSON.stringify(obj)) });
  // }

  componentDidUpdate(prevProps, prevState) {
    const { valueData, pageUpDownData, filterProps,
      currentRecordData,
      isSaveSuccess,
      isValueDataAPICall,
      isValueDataAPIFailure,
      prevNextAPICallCount,
      archexcepColumnDefs,
      sortProps,
      defaultSortProps,
      sortCriteriaDetails,
      archexcepControlFactorsLabelsData,
      updatedflag,
      headerRefreshAfterSuccess,
      newValueData,
      filterCriteriaDetails,
      newDetailCallData,
      detailCallData,
      labelsDataFailure,
      commonLabelsDataFailure,
      isAddressDataAPIFailure,
      isProfitGraphAPIFailure,
      isVendorResultAPIFailure,
      previousNextFlagAPIFailure,
      calculateOPAAPIFailure,
      isOPAResultAPIFailure,
      isCostGraphAPIFailure,
      isCalculateOPAAPIFailure,
      isAcceptOPAAPIFailure } = this.props.ArchexcepPropertiesData;

   // ********************
    // if (pageUpDownData && !isEqual(pageUpDownData, prevProps.ArchexcepPropertiesData.pageUpDownData)) {
    //   this.setState({ openFilterPopup: false });
    //   this.setHeaderAndSendAPI(pageUpDownData, ARCHEXCEPS_LIST_PAGE)
    // }
    // if ((JSON.stringify(filterProps) != JSON.stringify(prevProps.ArchexcepPropertiesData.filterProps)) && filterProps && filterProps.length) {
    //   this.setState({ isFiltersChanged: true });
    //   this.props.setChildTabFilterProps(filterProps);
    //   if (!this.state.isInitialAPICall) {
    //   if (this.state.fromPage != ARCHEXCEPS_LIST_PAGE && !this.state.hasFiltersChanged) {
    //     this.setHeaderAndSendAPI(this.state.stateData, this.state.fromPage)
    //   } else {
    //     this.makeAPICallForPageUpDown('down', {});
    //   }
    //   }
    // }

   // ********************

  //  if (valueData && !isEqual(valueData, prevProps.ArchexcepPropertiesData.valueData)) {
  //   this.setState({ isInitialAPICall: false })
  //   this.makePrevNextAPICall(true);
  //   if (this.state.isFiltersChanged) {
  //     this.setState({ openFilterPopup: false });
  //     // this.setStateWSVIds(filterProps);
  //     this.setState({ isFiltersChanged: false });
  //   }
  // }

   if (this.state.valueDataFailureMessages && this.state.valueDataFailureMessages.length
    && (JSON.stringify(this.state.valueDataFailureMessages) != JSON.stringify(prevState.valueDataFailureMessages))) {
    this.handleValueDataErrorMessages(this.state.valueDataFailureMessages[0]);
  }

  if (labelsDataFailure && (labelsDataFailure != prevProps.ArchexcepPropertiesData.labelsDataFailure)) {
    this.setState({ isDataLoaded: true })
    this.handleNoDataSets();
    this.props.setLabelDataFlags({ key: 'labelsDataFailure', value: false });
  }

  if ((commonLabelsDataFailure && (commonLabelsDataFailure != prevProps.ArchexcepPropertiesData.commonLabelsDataFailure))) {
    this.setState({ isDataLoaded: true })
    this.handleNoDataSets();
    this.props.setLabelDataFlags({ key: 'commonLabelsDataFailure', value: false });
  }

  if (previousNextFlagAPIFailure && (previousNextFlagAPIFailure != prevProps.ArchexcepPropertiesData.previousNextFlagAPIFailure)) {
    let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
    values.push("Failed to update the previous & next flags data from the server");
    this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
    this.props.setLabelDataFlags({ key: 'previousNextFlagAPIFailure', value: false });
  }

  // if (sortProps && sortProps.length && !isEqual(sortProps, prevProps.ArchexcepPropertiesData.sortProps)) {
  //   this.props.setDataInTabs("sortProps", JSON.parse(JSON.stringify(sortProps)));
  //   // this.setState({ prevStateSortProps: prevProps.ArchexcepPropertiesData.sortProps });
  //   if (!this.state.isInitialAPICall) {
  //     if (this.state.fromPage != ARCHEXCEPS_LIST_PAGE) {
  //       this.setHeaderAndSendAPI(this.state.stateData, this.state.fromPage)
  //     } else {
  //       this.makeAPICallForPageUpDown('down', {});
  //     }
  //   }
  // }

  if ((JSON.stringify(filterProps) != JSON.stringify(prevProps.ArchexcepPropertiesData.filterProps)) && filterProps && filterProps.length) {
    this.setState({ isFiltersChanged: true });
    this.props.setChildTabFilterProps(filterProps);
    if (!this.state.isInitialAPICall) {
      if (this.state.fromPage != ARCHEXCEPS_LIST_PAGE && !this.state.hasFiltersChanged) {
        this.setHeaderAndSendAPI(this.state.stateData, this.state.fromPage)
      } else {
        this.makeAPICallForPageUpDown('down', {});
      }
    }
  }

  // if ((defaultSortProps != prevProps.ArchexcepPropertiesData.defaultSortProps) && (prevProps.ArchexcepPropertiesData.defaultSortProps === null) && (sortProps == null || !sortProps || !(sortProps && sortProps.length))) {
  //   let list = setSortDataFromSortCriteria(defaultSortProps, archexcepColumnDefs, ARCHEXCEPS_LIST_PAGE);
  //   let defaultSortInfo = getDefaultSortInfo(defaultSortProps);
  //   this.props.setDataInTabs("defaultSortInfo", JSON.parse(JSON.stringify(defaultSortProps)));
  //   if (list && list.length) {
  //     this.props.sendPageSortProps(list);
  //     this.props.onSetSortProps(list);
  //   } else {
  //     this.props.sendPageSortProps([]);
  //     this.props.onSetSortProps([]);
  //   }
  // }

  // if (JSON.stringify(sortCriteriaDetails) != JSON.stringify(prevProps.ArchexcepPropertiesData.sortCriteriaDetails)) {
  //   this.props.setDataInTabs("defaultSortInfo", JSON.parse(JSON.stringify(sortCriteriaDetails)));
  //   let list = setSortDataFromSortCriteria(sortCriteriaDetails, archexcepColumnDefs, ARCHEXCEPS_LIST_PAGE);
  //   if (list && list.length) {
  //     this.props.sendPageSortProps(list);
  //     this.props.onSetSortProps(list);
  //   }
  // }

  // if ((filterCriteriaDetails != prevProps.ArchexcepPropertiesData.filterCriteriaDetails)) {
  //   this.props.setDataInTabs("defaultFilterInfo", JSON.parse(JSON.stringify(filterCriteriaDetails)));
  //   if (filterCriteriaDetails && Object.keys(filterCriteriaDetails) && Object.keys(filterCriteriaDetails).length && archexcepColumnDefs && archexcepColumnDefs.length) {
  //     let list = getFilterDataFromCriteriaDetails(filterCriteriaDetails, archexcepColumnDefs, ARCHEXCEPS_LIST_PAGE);
  //     if (list && list.length) {
  //       this.props.setGlobalFilterProps(list);
  //       this.props.onSetFilterProps(list);
  //     }
  //   }
  // }

  if (detailCallData && !isEqual(detailCallData, prevProps.ArchexcepPropertiesData.detailCallData)) {
    if (Object.keys(detailCallData) && Object.keys(detailCallData).length) {
      if (archexcepColumnDefs && archexcepColumnDefs.length) {
        this.prepareTooltipData();
      }
      this.props.setSelectedRecord(detailCallData, ARCHEXCEPS_LIST_PAGE);
      this.setState({ headerData: this.prepareHeaderDataJSON(detailCallData, ARCHEXCEPS_LIST_PAGE) });
    }
  }

  if (archexcepColumnDefs && archexcepColumnDefs.length && !isEqual(archexcepColumnDefs, prevProps.ArchexcepPropertiesData.archexcepColumnDefs) &&
    (detailCallData && Object.keys(detailCallData) && Object.keys(detailCallData).length)) {
    if (!this.state.changeDataAPI) {
      this.prepareTooltipData();
    }
  }

  // if (archexcepColumnDefs && !isEqual(archexcepColumnDefs, prevProps.ArchexcepPropertiesData.archexcepColumnDefs)) {
  //   if (archexcepColumnDefs && archexcepColumnDefs.length) {

  //   } else {
  //     // handle no data sets
  //   }
  // }

  if (archexcepColumnDefs && archexcepColumnDefs.length && !isEqual(archexcepColumnDefs, prevProps.ArchexcepPropertiesData.archexcepColumnDefs)) {
    let data = this.setArchexcepColumnDefs(archexcepColumnDefs);
    if (data) {
      this.setState({ archexcepDataJSON: data });
    }
  }

  if (isValueDataAPICall != prevProps.ArchexcepPropertiesData.isValueDataAPICall && isValueDataAPICall) {
    this.setState({ previousFilterValues: prevProps.ArchexcepPropertiesData.filterProps })
    this.setState({ isInitialAPICall: false });
    this.makePrevNextAPICall(true);
    // this.setState({ bracketsNotesFilterObj: {} });
    this.props.setValueDataFlag(false);
    if (this.state.isFiltersChanged) {
      this.setState({ openFilterPopup: false });
      // this.setStateWSVIds(filterProps);
      this.setState({ isFiltersChanged: false });
    }
  }

  if (isValueDataAPIFailure != prevProps.ArchexcepPropertiesData.isValueDataAPIFailure && isValueDataAPIFailure) {
    this.setState({ isInitialAPICall: false });
    if (this.state.isFiltersChanged) {
        // this.setState({ showConfirmationDialog: true });
        // this.setState({ hasWarning: true });
        // this.setState({ dialogTitle: TEXT_ALERT });
        // this.setState({ fromHeaderENG: true });
        // this.setState({ dialogBody: 'E28648' });
        this.openNoDataPopUp(true)
    } else {
        this.setState({ showConfirmationDialog: true });
        this.setState({ hasWarning: true });
        this.setState({ dialogTitle: TEXT_ALERT });
        this.setState({ fromHeaderENG: true });
        this.setState({ dialogBody: 'E14029' });
    }
}

  // if (isValueDataAPIFailure != prevProps.ArchexcepPropertiesData.isValueDataAPIFailure && isValueDataAPIFailure) {
  //   // this.updatedBracketListData();
  //   this.setState({ isInitialAPICall: false });
  //   let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
  //   values.push("Failed to get the detail data");
  //   this.setState({ valueDataFailureMessages: values });
  //   // if (!this.state.isDataLoaded) {
  //   //   this.setState({ isDataLoaded: true }, () => {
  //   //     this.handleNoDataSets();
  //   //   });
  //   // }
  //   if (this.state.isFiltersChanged) {
  //     this.setState({ showConfirmationDialog: true });
  //     this.setState({ hasWarning: true });
  //     this.setState({ dialogTitle: TEXT_ALERT });
  //     this.setState({ fromHeaderENG: true });
  //   }
  // }

  if (this.props.location.search != prevProps.location.search) {
    this.resetValues();
    this.forceUpdateHandler();
    this.setRecordDataValues();
    this.setState({ state: this.state });
  }

  if (pageUpDownData && JSON.stringify(pageUpDownData) != JSON.stringify(prevProps.ArchexcepPropertiesData.pageUpDownData)) {
    this.props.setSelectedRecord(pageUpDownData, ARCHEXCEPS_LIST_PAGE);
    this.setState({ fromPage: ARCHEXCEPS_LIST_PAGE });
    this.setHeaderAndSendAPI(pageUpDownData, ARCHEXCEPS_LIST_PAGE);
    let modifiedData = {
      data: JSON.parse(JSON.stringify(pageUpDownData)),
      fromPage: ARCHEXCEPS_LIST_PAGE,
      rowIndex: this.props.ArchexcepPropertiesData.rowIndex,
      totalCount: this.state.totalCount,
      fromParent: false,
      columnDefs: this.state.columnDefs,
    };
    this.props.setDataInTabs('recordData', modifiedData);
  }

  // if (isSaveSuccess && isSaveSuccess !== prevProps.ArchexcepPropertiesData.isSaveSuccess) {
  //   this.setState({ isSaveDataDisabled: true });
  //   this.setHeaderAndSendAPI(this.state.stateData, this.state.fromPage);
  // }

  if (prevProps.authorizedComponentsList !== this.props.authorizedComponentsList) {
    const canUpdateComponent = getUpdateRestrictionOnComponent(
      capitalizeFirstLetter(ARCHEXCEPS_LIST_PAGE),
      this.props.authorizedComponentsList,
    );
    this.setState({ canUpdateComponent });
  }

  // if (
  //   this.props.ArchexcepPropertiesData.formattedValues &&
  //   prevProps.ArchexcepPropertiesData.archexcepControlFactorsLabelsData &&
  //   this.props.ArchexcepPropertiesData.archexcepControlFactorsLabelsData
  // ) {
  //   if (
  //     prevProps.ArchexcepPropertiesData.archexcepControlFactorsLabelsData
  //       .tabcards !=
  //     this.props.ArchexcepPropertiesData.archexcepControlFactorsLabelsData.tabcards
  //   ) {
  //     this.props.formatVendorPropertiesValues(
  //       this.props.globalNumberFormat,
  //       this.props.globalNumberSeparator,
  //       this.props.globalDecimalSeparator,
  //     );
  //   }
  // }

  // if (
  //   !this.props.ArchexcepPropertiesData.formattedValues &&
  //   this.props.ArchexcepPropertiesData.formattedValues !=
  //   prevProps.ArchexcepPropertiesData.formattedValues
  // ) {
  //   this.props.changeFormattedValuesFlag();
  // }
  // ************
  }
  makePrevNextAPICall = flag => {
    const { filterProps, valueData, sortProps } = this.props.ArchexcepPropertiesData;
    const data = JSON.parse(JSON.stringify(INITIAL_PAGE_PROPS));
    data.isForwardDirection = flag;
    data.pageSize = 3;
    this.props.getPageUpDownFlagAPI(
      this.getApiObjForPageUpDownFlags(filterProps, valueData, ARCHEXCEPS_LIST_PAGE, data, sortProps, flag)
    );
  };

  prepareTooltipData = () => {
    const { detailCallData, archexcepColumnDefs } = this.props.ArchexcepPropertiesData;
    let tooltipData = prepareTooltipValues(ARCHEXCEPS_LIST_PAGE, detailCallData, archexcepColumnDefs, 'archexcepsproperties');
    this.props.setDataInTabs("toolTipData", JSON.parse(JSON.stringify(tooltipData)));
  }

  setHeaderAndSendAPI(jsonData, from) {
    const { pageProps, filterProps, currentRecordData } = this.props.ArchexcepPropertiesData;
    let data = this.prepareHeaderDataJSON(jsonData, from);
    this.setState({ headerData: data });
    this.setState({ stateData: jsonData });
    let valueData = prepareValueDataForArchexceps(DEFAULT_VALUE_URL_DATA, jsonData, from);
    this.sendAPICallForValues(valueData, jsonData);
  }

  prepareKeyValue(jsonData, filterName) {
    const currentPage = ARCHEXCEPS_LIST_PAGE;
    const columnDefs = this.columnDefData;
    let headerKey = COLUMN_VALUE_ACCESSOR;
    let fieldLenKey = COLUMN_FIELD_LEN;
    let filterValues = FILTER_DATA;
    if (columnDefs && columnDefs.length) {
      let filterData = '';
      filterValues.forEach((filter) => {
        let columnData = columnDefs.find((column) => {
          let columnKey = column[headerKey].trim();
          return columnKey == filter;
        });
        if (columnData && Object.keys(columnData) && Object.keys(columnData).length) {
          let fieldLen = Number(columnData[fieldLenKey].trim());
          let columnKey = columnData.prefixFlag ? (columnData[headerKey].trim()) : (getListPredecessor(currentPage) + columnData[headerKey].trim());
          let dataValue = jsonData[columnKey] ? jsonData[columnKey].trim() : jsonData[columnKey];
          let str = handleFieldValuesByLength(dataValue, fieldLen);
          if (filterName == filter) {
            filterData = str;
          }
        }
      })
      return filterData;
    }
    return '';
  }

  prepareFilterProps(data, valueData) {
    let jsonObj = JSON.parse(JSON.stringify(valueData));
    let filterData = JSON.parse(JSON.stringify(data));
    filterData[0]["fieldValue"] = this.prepareKeyValue(jsonObj, 'COMP');
    // filterData[1]["fieldValue"] = this.prepareKeyValue(jsonObj, 'VNDR');
    // filterData[2]["fieldValue"] = this.prepareKeyValue(jsonObj, 'SUBV');
    // filterData[3]["fieldValue"] = this.prepareKeyValue(jsonObj, 'WHSE');
    return filterData;
  }

  sendAPICallForValues(valueData, jsonData) {
    const { pageProps } = this.props.ArchexcepPropertiesData;

    this.props.onLoadCompanyData(
      this.getApiObj(valueData, null, ARCHEXCEP_PROPERTIES, pageProps),
    );

    this.props.getValueList(
      this.getApiObj(valueData, null, ARCHEXCEP_PROPERTIES, pageProps),
        this.props.globalNumberFormat, this.props.globalNumberSeparator, this.props.globalDecimalSeparator);
  }

  setArchexcepColumnDefs(data) {
    let ardata = data;
    // if (data && data.length) {
    //   let vData = data.find(
    //     column => column[COLUMN_VALUE_ACCESSOR].trim() == 'EVNAME',
    //   );
      // vData = setNumberFields([vData]);
      // const prefix = getListPredecessor(ARCHEXCEPS_LIST_PAGE);
      // vData[0].key = !vData[0].prefixFlag
      //   ? prefix + vData[0][COLUMN_VALUE_ACCESSOR].trim()
      //   : vData[0][COLUMN_VALUE_ACCESSOR].trim();
      return ardata;
    // }
  }

  handleValueDataErrorMessages(content) {
    this.setState({ showValueConfirmationDialog: true });
    this.setState({ dialogTitle: TEXT_ALERT });
    this.setState({ dialogContent: content });
  }

  closeValueDialog = () => {
    this.setState({ showValueConfirmationDialog: false });
    if (this.state.valueDataFailureMessages && this.state.valueDataFailureMessages.length) {
      let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
      values.shift();
      this.setState({ valueDataFailureMessages: values });
    }
  }

  setRecordDataValues() {
    let isRecordValuesExists = false, isLocalStorageValuesExists = false, isFilterValuesExists = false;
    const { history } = this.props;
    var paramsString = window.location.search;
    if (paramsString && paramsString.length) {
      let paramsArray = paramsString.split("?");
      if (paramsArray && paramsArray.length && paramsArray.length > 1) {
        let params = paramsArray[1].split("&");
        let tabId = params[0].split("=")[1];
        let breadCrumbId = params[1].split("=")[1];
        let localStorageValues = getFilterDataFromLocalStorage(tabId, breadCrumbId);
        if (localStorageValues && Object.keys(localStorageValues) && Object.keys(localStorageValues).length) {
          isLocalStorageValuesExists = true;
          let itemData = localStorageValues.item_data, dbSelectorValues = [];
          if (itemData && itemData.recordData && localStorageValues.childType) {
            this.columnDefData = JSON.parse(JSON.stringify(itemData.recordData.columnDefs))
            this.setState({ columnDefs: itemData.recordData.columnDefs });
            this.props.setCurrentRecord(itemData.recordData.data);
            this.setState({ totalCount: itemData.recordData.totalCount });
            this.setState({ fromPage: itemData.recordData.fromPage });
            this.setState({ fromListPage: itemData.recordData.fromPage });
            this.props.setRowIndex(itemData.recordData.rowIndex);
            this.setHeaderAndSendAPI(itemData.recordData.data, itemData.recordData.fromPage);
            isRecordValuesExists = true;
            this.props.setSelectedRecord(false, false);
            if (itemData) {
              if (itemData.dbSelector && itemData.dbSelector.length) {
                dbSelectorValues = JSON.parse(JSON.stringify(itemData.dbSelector));
              }
              if (itemData.filterProps && itemData.filterProps.length) {
                // this.setState({ prevStateFilterProps: JSON.parse(JSON.stringify(itemData.filterProps)) });
                this.setState({ hasFiltersChanged: false });
                isFilterValuesExists = true;
                let values = getDBSelectorFilterValues(dbSelectorValues, itemData.filterProps);
                this.setFilterValuesFromState(values);
              } else if (dbSelectorValues && dbSelectorValues.length) {
                // this.setState({ prevStateFilterProps: JSON.parse(JSON.stringify(itemData.filterProps)) });
                this.setState({ hasFiltersChanged: false });
                isFilterValuesExists = true;
                let dbValues = getDBSelectorFilterValues(dbSelectorValues, []);
                this.setFilterValuesFromState(dbValues);
              }
              // if (itemData.sortProps && itemData.sortProps.length) {
              //   // this.setState({ prevStateSortProps: JSON.parse(JSON.stringify(itemData.sortProps)) })
              //   this.setState({ hasSortChanged: false });
              //   this.props.sendPageSortProps(itemData.sortProps);
              //   this.props.onSetSortProps(itemData.sortProps);
              // } else {
              //   // this.setState({ hasSortChanged: true });
              // }
              if (itemData.defaultFilterInfo && Object.keys(itemData.defaultFilterInfo) && Object.keys(itemData.defaultFilterInfo).length) {
                this.props.setDefaultFilterpropsForTabs(itemData.defaultFilterInfo);
              }
              // if (itemData.defaultSortInfo && Object.keys(itemData.defaultSortInfo) && Object.keys(itemData.defaultSortInfo).length) {
              //   this.props.setDefaultSortpropsForTabs(itemData.defaultSortInfo);
              // }
            }
          }

        }
        if (!isLocalStorageValuesExists && tabId && breadCrumbId) {
          history.push({ pathname: '/Dashboard' });
        }
      }
    }

    let filterOptions = GLOBAL_FILTER_OPTIONS;
    const { dbSelector } = this.props;
    if (!isFilterValuesExists) {
      let gbValues = getDBSelectorFilterValues(dbSelector, filterOptions);
      this.setFilterValuesFromState(gbValues);
    }
    return isRecordValuesExists;
  }

  resetValues = () => {
    this.props.setInitialState();
    this.props.setValueDataFlag(false);
    this.props.setCurrentRecord(null);
    this.setState({ isDataLoaded: false });
    this.setState({ updatedBrackets: false });
    this.setState({ updatedNotes: false });
    this.props.getArchexcepsColumnDefs({ type: ARCHEXCEPS_LIST_PAGE });
  };

  componentDidMount() {
    this.resetValues();
    let currentPage = ARCHEXCEP_PROPERTIES_PAGE;
    this.props.onLoadCurrentPage(currentPage);
    const { valueData, detailCallData } = this.props.ArchexcepPropertiesData;
    this.props.setIsShowContextMenu(true);
    let isFound = this.setRecordDataValues();
    if (!isFound) {
      if (this.props.location && this.props.location.state) {
        this.props.setCurrentRecord(this.props.location.state.data);
        this.setState({ columnDefs: this.props.location.state.columnDefs });
        this.setState({ fromPage: this.props.location.state.fromPage });
        let data = this.setArchexcepColumnDefs(this.props.location.state.columnDefs);
        if (data) {
          this.setState({ archexcepDataJSON: data });
        }
        this.props.setRowIndex(this.props.location.state.rowIndex);
        this.setHeaderAndSendAPI(this.props.location.state.data, ARCHEXCEPS_LIST_PAGE);
      }
    }

    if (detailCallData && Object.keys(detailCallData) && Object.keys(detailCallData).length) {
      // this.setState({ headerData: this.prepareHeaderDataJSON(detailCallData, ARCHEXCEPS_LIST_PAGE) });
      this.props.setSelectedRecord(detailCallData, ARCHEXCEPS_LIST_PAGE);
    }

    const { pageProps } = this.props.ArchexcepPropertiesData;
    let labelFilters = LABEL_LIST_URL_DATA;
    this.props.getLabelsList({ recordData: labelFilters, currentPage: 'archexcepproperties' });
    this.setState({ isSaveDataDisabled: true });
    // this.props.getBracketJson({ recordData: BRACKET_LABEL_URL_DATA, currentPage: 'archexcepproperties' });
    let canUpdateComponent = getUpdateRestrictionOnComponent(capitalizeFirstLetter(ARCHEXCEPS_LIST_PAGE), this.props.authorizedComponentsList);
    this.setState({ canUpdateComponent });
  }


  getApiObjForPageUpDown(filterData, record, currentPage, pageProps, sortData, pageType) {
    let recordObj = false
    if (record) {
      recordObj = record;
    }
    let apiObj = {
      sortProps: sortData,
      filterProps: filterData,
      pageProps: pageProps,
      direction: pageProps.isForwardDirection,
      record: recordObj,
      currentPage: currentPage,
      parentPage: ARCHEXCEPS_LIST_PAGE,
      pageType: pageType
    };
    return apiObj;
  }

  getApiObjForPageUpDownFlags = (filterData, record, currentPage, pageProps, sortData, pageType) => {
    let recordObj = false
    if (record) {
      recordObj = {
        "record": record,
        "flagsOnly": true
      };
    }
    let apiObj = {
      sortProps: sortData,
      filterProps: filterData,
      pageProps: pageProps,
      direction: pageProps.isForwardDirection,
      record: recordObj,
      currentPage: currentPage,
      parentPage: ARCHEXCEPS_LIST_PAGE,
      pageType: pageType
    };
    return apiObj;
  }

  makeAPICallForPageUpDown(type, currentRecordData) {
    const { headerFieldJson, rowIndex, filterProps, sortProps } = this.props.ArchexcepPropertiesData;
    let data = JSON.parse(JSON.stringify(INITIAL_PAGE_PROPS));
    if (type == 'up') {
      data.isForwardDirection = false;
    } else {
      data.isForwardDirection = true;
    }
    let filterData = JSON.parse(JSON.stringify(filterProps));
    this.props.pageUpDownAPI(this.getApiObjForPageUpDown(filterData, currentRecordData, ARCHEXCEPS_LIST_PAGE, data, sortProps))
  }

  handleArchexcepHeaderLeftArrowClick(rowIndex, total) {
    const { currentRecordData } = this.props.ArchexcepPropertiesData;
    this.props.setCurrentType('down');
    this.makeAPICallForPageUpDown('down', currentRecordData);
    this.setState({ isSaveDataDisabled: true });
  }

  handleArchexcepHeaderRightArrowClick(rowIndex, total) {
    const { currentRecordData } = this.props.ArchexcepPropertiesData;
    this.props.setCurrentType('up');
    this.makeAPICallForPageUpDown('up', currentRecordData);
    this.setState({ isSaveDataDisabled: true });
  }


  sethaserror = val => {
    this.setState({ hasError: val });
  };

  onContextMenuChange = (e, value, check = false, filters = false, title = false) => {
    let defaultFilters = filters;
    let toPage = value;
    let displayName = title;

    const { currentRecordData } = this.props.ArchexcepPropertiesData;
    onChangeContextMenu(this.props, e, toPage, defaultFilters, displayName);
    this.props.setSelectedValueForTabs('Show Me');
  }


  setValueData(data, flag) {
    this.props.setValueData(
      data,
      this.props.globalNumberFormat,
      this.props.globalNumberSeparator,
      this.props.globalDecimalSeparator,
    );
    if (!flag) {
      this.setState({ changeDataAPI: false });
    } else {
      this.setState({ changeDataAPI: true });
    }
  }


  handleClose = bodyId => {
    this.setState({ showConfirmationDialog: false });
    switch (bodyId) {
      case 'E14029':
        //need to close the current Tab
        this.closeCurrentTab();
        break;
    }
  }

  closeCurrentTab = () => {
    this.props.setNoDataCallBackValue(true);
    var paramsString = window.location.search;
    if (paramsString && paramsString.length) {
      let paramsArray = paramsString.split("?");
      if (paramsArray && paramsArray.length && paramsArray.length > 1) {
        let params = paramsArray[1].split("&");
        let tabId = params[0].split("=")[1];
        let breadCrumbId = params[1].split("=")[1];
        this.props.removeCurrentRecordObj(tabId, breadCrumbId);
      }
    }
  }
  render() {
    const cp = ARCHEXCEP_PROPERTIES_PAGE;
    const {
      archexcepData,
      classes,
      globalDateFormat,
      filterCriteriaDetails,
      pageFilterOptions,
      globalFilterOptions,
      columnDefs,
      currentPage,
      currentOwnerName
    } = this.props;

    const {
      rowIndex,
      currentRecordData,
      bracketLabelJson,
      loading,
      valueData,
      hasNext,
      hasPrevious,
      archexcepColumnDefs,
      result,
      detailCallData,
      archexcepLabelsData
    } = this.props.ArchexcepPropertiesData;

    const { tab, showConfirmationDialog } = this.state;
    const { tabcards } = archexcepLabelsData;

    // JVK
    const { filterProps } = this.props.ArchexcepPropertiesData;
    const hideLoader =
      !loading &&
      tabcards &&
      tabcards.length;

      let contextMenu = updateBreadCrumbContextMenu(this.props) || [];
      contextMenu = contextMenu.filter(arr => arr.id != 'archexceps');
  
    return (
      <div>
        {this.state.hasError ? (
          <div>
            <GridErrorMessages
              errorMessageLabels={this.props.errorMessageLabels}
              popUp
              sethaserror={this.sethaserror}
              id={
                this.state.errorId ? this.state.errorId : this.props.ServerError
              }
            />
          </div>
        ) : (
            ''
          )}
        {!loading && tabcards && tabcards.length && this.state.fromPage ? (
          <div
            className={hideLoader ? classes.showContent : classes.hideContent}
          >
            <Formik
              initialValues={this.props.archexcepData}
              render={({
                values,
                handleSubmit,
                isSubmitting,
                handleChange,
              }) => (
                  <form>
                    <Header
                      {...this.props}
                      // archexcepData={currentRecordData}
                      filters={this.props.filters}
                      parentSubPage={ARCHEXCEP_PROPERTIES}
                      // handleSubmitDataCallBack={this.handleSubmitDataCallBack}
                      contextMenu={contextMenu}
                      fromListPage={this.state.fromListPage}
                      onContextMenuChange={this.onContextMenuChange}
                      rowIndex={rowIndex}
                      ArchexcepPropertiesData={this.props.ArchexcepPropertiesData}
                      // handleArchexcepHeaderSortClick={
                      //   this.handleArchexcepHeaderSortClick
                      // }
                      handleArchexcepHeaderFilterClick={
                        this.handleArchexcepHeaderFilterClick
                      }
                      hasNext={hasNext}
                      hasPrevious={hasPrevious}
                      archexcepData={this.state.headerData}
                      currentRecordData={currentRecordData}
                      headerFieldJson={this.state.archexcepDataJSON}
                      // handleArchexcepHeaderSaveClick={() => this.onSaveData(values)}
                      handleArchexcepHeaderLeftArrowClick={
                        this.handleArchexcepHeaderLeftArrowClick
                      }
                      handleArchexcepHeaderRightArrowClick={
                        this.handleArchexcepHeaderRightArrowClick
                      }
                      saveDisabled={this.state.isSaveDataDisabled}
                      // updateArchexcepName={this.updateArchexcepName}
                      // setSaveData={val => {
                      //   this.setState({ isSaveDataDisabled: !val });
                      // }}
                      globalDateFormat={globalDateFormat}
                      // filterCriteriaDetails={filterCriteriaDetails}
                      pageFilterOptions={pageFilterOptions}
                      globalFilterOptions={globalFilterOptions}
                      columnDefs={this.state.columnDefs}
                      currentPage={ARCHEXCEPS_LIST_PAGE}
                      valuesArray={{ EVNAME: this.state.archexcepName }}
                      parentPage={ARCHEXCEPS_LIST_PAGE}
                      // JVK
                      // handleArchexcepHeaderActionItemSelection={
                      //   this.handleItemSelection
                      // }
                      // canUpdateComponent={this.state.canUpdateComponent}
                    >
                      {' '}
                    </Header>
                    {/* {deleteDialog && (
                      <DeleteDialog
                        closeDialog={this.closeDialog}
                        // rowColumnID={this.props.rowColumnID}
                        namespace="archexcepsDelete"
                        title="Archexcep Delete"
                        // checkBoxValues={MODEL_ALL_CHECKBOX_CONSTANTS}
                        // propertyValues={}
                        currentRecord={currentRecordData}
                        filterProps={filterProps}
                        headerJson={this.state.headerData}
                        clearPopupComponent={this.closePopup}
                        onArchexcepDelete={this.props.onArchexcepDelete}
                        currentPage="archexceps"
                        getLabelValue={this.getLabelValue}
                      />
                    )} */}
                    {/* {copyDialog && (
                      <CopyDialog
                        closeDialog={() => this.closeDialog('copyDialog')}
                        namespace="archexcepsCopy"
                        title={this.getLabelValue(LABEL_COPY_ARCHEXCEP)}
                        headerJson={this.state.headerData}
                        onArchexcepCopy={this.props.onArchexcepCopy}
                        currentPage="archexceps"
                        isOpen={copyDialog}
                        getLabelValue={this.getLabelValue}
                        ArchexcepPropertiesData={this.props.ArchexcepPropertiesData}
                        onArchexcepCopy={this.props.onArchexcepCopy}
                      />
                    )} */}

                    <div className={classes.propertiesContentWrapper}>
                      {/* <AppBar
                        position="static"
                        color="default"
                        className="minWidth1100"
                      >
                        <Tabs
                          value={this.state.tab}
                          onChange={(evt, val) => {
                            this.handleChangeTab(evt, val);
                          }}
                          indicatorColor="primary"
                          textColor="primary"
                        >
                        </Tabs>
                      </AppBar> */}
                      {tab == 0 && (
                        <TabContainer>
                          <ArchexcepTab
                            color="primary"
                            parentSubPage={ARCHEXCEP_PROPERTIES}
                            currentOwnerName={currentOwnerName}
                            ArchexcepPropertiesData={this.props.ArchexcepPropertiesData}
                            rowIndex={rowIndex}
                            archexcepData={currentRecordData}
                            // handleChange={handleChange}
                            // values={values}
                            // updatedFieldValues={this.state.updatedFieldValues}
                            setValueData={this.props.setValueData}
                            sendAPICallOnChange={this.sendAPICallOnChange}
                            // setValueDataOnFocusOut={this.saveDataOnFocusOut}
                            // setSaveData={val => {
                            //   this.setState({ isSaveDataDisabled: !val });
                            // }}
                            globalDateFormat={globalDateFormat}
                            filterCriteriaDetails={filterCriteriaDetails}
                            pageFilterOptions={pageFilterOptions}
                            globalFilterOptions={globalFilterOptions}
                            columnDefs={this.state.columnDefs}
                            currentPage="archexceps"
                            // onFieldValueChange={this.onFieldValueChange}
                            // selectedRow={this.state.selectedRow}
                            // canUpdateComponent={this.state.canUpdateComponent}
                            // handleSubmitDataCallBack={
                            //   this.handleSubmitDataCallBack
                            // }
                          // authorizedComponentsList={this.props.authorizedComponentsList}
                          />
                        </TabContainer>
                      )}
                    </div>
                  </form>
                )}
            />
          </div>
        ) : null}
        {!hideLoader ? <Spinner loading type="list" /> : null}

        {this.state.openFilterPopup && (
          <Filter
            filterCriteriaDetails={this.props.filterCriteriaDetails}
            pageFilterOptions={this.props.pageFilterOptions}
            globalFilterOptions={this.props.globalFilterOptions}
            globalSecurityFilterList={this.props.globalSecurityFilterList}
            currentPage={cp}
            isOpen={Boolean(this.state.openFilterPopup)}
            ownerName={this.props.currentOwnerName}
            columnDefs={archexcepColumnDefs}
            clearPopupComponent={this.handleArchexcepHeaderFilterClick}
            hasRecordsForFilter={!this.state.noRecordForFilter}
            showNoDataPopUp={(val) => this.openNoDataPopUp(val)}
          />
        )}

        {this.state.showConfirmationDialog && <ConfirmationDialog
          hasError={this.state.hasWarning}
          isOpen={this.state.showConfirmationDialog}
          dialogTitle={this.state.dialogTitle}
          submitText={TEXT_OK}
          handleClose={e => this.handleClose(false)}
          handleCancel={e => this.handleClose(false)}
          handleSubmit={e => this.handleClose(this.state.dialogBody)}
        >
          <div>
            {this.state.fromHeaderENG && <FormattedMessageComponent id="28648" />}
            {/* {this.props.errorMessageLabels && this.props.errorMessageLabels[this.state.dialogBody] &&
              this.props.errorMessageLabels[this.state.dialogBody].MTEXT || 'Warning'} */}
          </div>
        </ConfirmationDialog>
        }
        {this.state.showValueConfirmationDialog && <ConfirmationDialog
          hasError={this.state.hasWarning}
          isOpen={this.state.showValueConfirmationDialog}
          dialogTitle={this.state.dialogTitle}
          submitText={TEXT_OK}
          handleClose={e => this.closeValueDialog(false)}
          handleCancel={e => this.closeValueDialog(false)}
          handleSubmit={e => this.closeValueDialog(this.state.dialogBody)}
        >
          <div>
            {this.state.dialogContent}
          </div>
        </ConfirmationDialog>
        }

      </div>
    );
  }
}

ArchexcepProperties.propTypes = {};

function mapDispatchToProps(dispatch) {
  return {};
}

const mapStateToProps = createStructuredSelector({
  // errorMessageLabels: errorMessageLabelsFormat()
  // ArchexcepPropertiesData: selectArchexcepData(),
  // globalDateFormat: selectGlobalDateFormat(),
  // filterCriteriaDetails: makeFilterCriteriaDetails(),
  // pageFilterOptions: makePageFilterOptions(),
  // globalFilterOptions: makeFilterOptions(),
  // // columnDefs: makeColumnDefinitions(),
  // currentPage: makeSelectCurrentPage()
});
const withConnect = connect(mapStateToProps);
// const withReducer = injectReducer({ key: 'ArchexcepProperties', reducer });
// const withSaga = injectSaga({ key: 'ArchexcepPropertiesSaga', saga });

export default compose(
  withRouter,
  // withReducer,
  // withSaga,
  withConnect,
  withStyles(style),
)(ArchexcepProperties);

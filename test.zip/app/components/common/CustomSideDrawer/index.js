import React from 'react';
import { withStyles } from '@material-ui/core/styles';
import { PropTypes } from 'prop-types';
import CloseIcon from '@material-ui/icons/Close';
import FormattedMessageComponent from '../FormattedMessageComponent';
import { IconButton, Button } from '@material-ui/core';

const propTypes = {
    dialogtitle : PropTypes.string,
    cancelText : PropTypes.string,
    submitText : PropTypes.string,
    handleAddSideDrawerClose : PropTypes.func,
    handleAddSideDrawerSubmit : PropTypes.func,
    isOpen: PropTypes.bool,
}

const style = theme => ({
    rightDrawerBackdrop:{
        position: 'fixed',
        top: 0,
        right: 0,
        width: '100%',
        height: '100%',
        backgroundColor: 'rgba(0,0,0,0.5)',
        zIndex: '3',
        display: 'flex',
        justifyContent: 'flex-end',
    },
    rightDrawer:{
        width: '300px',
        backgroundColor: 'var(--background-content)',
        paddingRight: '22px'

    },
    rightDrawerHeader:{
        margin: 0,
        padding: '9px 16px',
        borderBottom: '1px solid var(--divider-line)',
        backgroundColor: 'var(--background-content)',
        color: 'var(--text)',
        fontSize: '18px',
        fontFamily:"'Roboto', 'Helvetica', 'Arial', sans-serif",
        fontWeight: '600',
        lineHeight: '1.6rem',
    },
    rightDrawerHeaderCloseIcon:{
            top: '0px',
            right: '0px',
            position: 'absolute',
    },
    addButton:{
        position: 'absolute',
        right: '20px',
        bottom: '10px',
        padding: '8px 0px',
        '& button':{
            marginLeft: '10px'
        }
    }
})

class CustomSideDrawer extends React.Component {

    constructor(props) {
        super(props);
        this.state = {

        };
    }

    getIntlLabel = (id) => {
        return <FormattedMessageComponent id={id}></FormattedMessageComponent>
    }

    render() {

        const {classes, dialogtitle, cancelText, submitText, handleAddSideDrawerClose, handleAddSideDrawerSubmit, isOpen } = this.props;

        return (
            <div>
            { isOpen && <div className={classes.rightDrawerBackdrop}>
                <div className={classes.rightDrawer + ' ' + 'slideLeft'}>

                    <div className={classes.rightDrawerHeader}>
                        {/*Add Vendors..*/}
                        {dialogtitle && <FormattedMessageComponent id={dialogtitle} />}
                        <IconButton className={classes.rightDrawerHeaderCloseIcon} onClick={handleAddSideDrawerClose}>
                            <CloseIcon />
                        </IconButton >
                    </div>

                    {this.props.children}

                    <div className={classes.addButton}>
                        {cancelText && <Button size="large" color="primary" variant="outlined" onClick={handleAddSideDrawerClose}>{this.getIntlLabel(cancelText)}</Button>}
                        {submitText && <Button size="large" color="primary" variant="contained" disabled={this.props.disableSubmit} onClick={handleAddSideDrawerSubmit}>{this.getIntlLabel(submitText)}</Button>}
                    </div>
                </div>
            </div>}
            </div>);
    }

}

CustomSideDrawer.propTypes = propTypes;

export default withStyles(style)(CustomSideDrawer);
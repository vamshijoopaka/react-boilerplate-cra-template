
/*
* * //==========================================================================
*
* * // Copyright 2021-2021, Blue Yonder Group, Inc.
*
* * // All Rights Reserved
*
* * //
*
* * // THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF
*
* * // BLUE YONDER GROUP, INC.
*
* * //
*
* * //
*
* * // The copyright notice above does not evidence any actual
*
* * // or intended publication of such source code.
*
* * //
*
* * // ===========================================================================
*/
import { createSelector } from 'reselect';

const selectGlobal = state => state.get('app');

const selectCurrentPage = state => state.get('root');

const selectRouter = state => state.router;

const selectItemPage = state => state.get('itemListReducer');

const selectVendorPage = (state) => state.get('vendorListReducer');

const selectHoldoutPage = (state) => state.get('holdoutsListReducer');
// NIL - Events List
const selectEventPage = (state) => state.get('eventListReducer');

const selectOrdanPage = (state) => state.get('ordanListReducer');

// PRK
const selectOrderPage = (state) => state.get('orderListReducer');

const selectBuyerPage = (state) => state.get('buyersListReducer');
const selectDealPage = (state) => state.get('dealListReducer');
const selectMassmaintenancejobPage = (state) => state.get('massmaintenancejobListReducer');

const selectArchexcepPage = (state) => state.get('archexcepListReducer');

const selectOpenpoPage = (state) => state.get('openpoListReducer');

// const columnDefs = (state) => state.get('searchReplaceSelectFilterCriteria').get('columnDefs')

const selectProfilePage = (state) => state.get('profileListReducer');

const makeSelectCurrentUser = () =>
  createSelector(
    selectGlobal,
    globalState => globalState.currentUser,
  );

const makeSelectLoading = () =>
  createSelector(
    selectGlobal,
    globalState => globalState.loading,
  );

const makeSelectError = () =>
  createSelector(
    selectGlobal,
    globalState => globalState.error,
  );

const makeSelectRepos = () =>
  createSelector(
    selectGlobal,
    globalState => globalState.userData.repositories,
  );

const makeSelectLocation = () =>
  createSelector(
    selectRouter,
    routerState => routerState.location,
  );

const makeSelectCurrentPage = () =>
  createSelector(
    selectCurrentPage,
    selectCurrentPage => selectCurrentPage.get('currentPage'),
  );

const makeColumnDefinitions = () =>
  createSelector(
    selectCurrentPage,
    selectCurrentPage => selectCurrentPage.get('globalColDefs'),
  );

const makeFilterOptions = () =>
  createSelector(
    selectCurrentPage,
    selectCurrentPage => selectCurrentPage.get('globalFilterOptions'),
  );

const makePageFilterOptions = () =>
  createSelector(
    selectCurrentPage,
    selectCurrentPage => selectCurrentPage.get('pageFilterOptions'),
  );

const makeGridOptions = () =>
  createSelector(
    selectCurrentPage,
    selectCurrentPage => selectCurrentPage.get("gridLevelOptions"),
  )

const selectFilterCriteria = (state) => {
  let currentPage = selectCurrentPage(state).get('currentPage') || '';
  switch (currentPage.toLowerCase()) {
    case 'items': return selectItemPage(state).get('filterCriteriaDetails');
    case 'vendors': return selectVendorPage(state).get('filterCriteriaDetails');
    case 'ordans': return selectOrdanPage(state).get('filterCriteriaDetails');
    case 'archexceps': return selectArchexcepPage(state).get('filterCriteriaDetails');
    // case 'openpos': return selectOpenpoPage(state).get('filterCriteriaDetails');
    case 'vendorcontrolfactors': return selectVendorPage(state).get('filterCriteriaDetails');
    case 'profiles': return selectProfilePage(state).get('filterCriteriaDetails');
    case 'massmaintenancejobs': return selectMassmaintenancejobPage(state).get('filterCriteriaDetails');
    case 'orders': return selectOrderPage(state).get('filterCriteriaDetails');
    // case 'holdouts': return selectHoldoutPage(state).get('filterCriteriaDetails');//E3C-31922:Ajit
    case 'buyers': return selectBuyerPage(state).get('filterCriteriaDetails');
    case 'deals': return selectDealPage(state).get('filterCriteriaDetails');
    default: return false;
  }
}

const makeFilterCriteriaDetails = () =>
  createSelector(
    selectFilterCriteria,
    selectFilterCriteria => selectFilterCriteria,
  );

const selectGlobalNumberSeparator = () =>
  createSelector(
    selectCurrentPage,
    selectCurrentPage => selectCurrentPage.get('numberSeparator'),
  );

const selectGlobalNumberFormat = () =>
  createSelector(
    selectCurrentPage,
    selectCurrentPage => selectCurrentPage.get('numberFormatter'),
  );

const selectGlobalDecimalSeparator = () =>
  createSelector(
    selectCurrentPage,
    selectCurrentPage => selectCurrentPage.get('decimalSeparator'),
  );
// E3C-30525-Begin-Ajit
const selectGlobalDateFormat = () =>
  createSelector(
    selectCurrentPage,
    selectCurrentPage => selectCurrentPage.get('dateFormat'),
  );
// E3C-30525-End-Ajit

export {
  selectGlobal,
  makeFilterCriteriaDetails,
  makeSelectCurrentUser,
  makeSelectCurrentPage,
  makeColumnDefinitions,
  makeFilterOptions,
  makeGridOptions,
  makePageFilterOptions,
  selectGlobalNumberFormat,
  selectGlobalNumberSeparator,
  selectGlobalDecimalSeparator,
  selectGlobalDateFormat // E3C-30525 :Ajit
};
import {
  COLUMN_HEADER_ACCESSOR,
  COLUMN_VALUE_ACCESSOR,
  COLUMN_SHOW_HIDE_FLAG,
  COLUMN_POSITION,
  COLUMN_HEADER_PREFIX_FLAG,
} from '../common/constants';

export const DEFAULT_ACTION = 'app/BuyersListPage/DEFAULT_ACTION';
export const LOAD_BUYERS = 'app/BuyersListPage/LOAD_BUYERS';
export const LOAD_BUYERS_ERROR = 'app/BuyersListPage/LOAD_BUYERS_ERROR';
export const LOAD_BUYERS_SUCCESS = 'app/BuyersListPage/LOAD_BUYERS_SUCCESS';
export const LOAD_BUYERS_COUNT = 'app/BuyersListPage/LOAD_BUYERS_COUNT';
export const LOAD_BUYERS_COUNT_ERROR =
  'app/BuyersListPage/LOAD_BUYERS_COUNT_ERROR';
export const LOAD_BUYERS_COUNT_SUCCESS =
  'app/BuyersListPage/LOAD_BUYERS_COUNT_SUCCESS';
export const SET_SEARCHPROPS = 'app/BuyersListPage/SET_SEARCHPROPS';
export const SET_SORTPROPS = 'app/BuyersListPage/SET_SORTPROPS';
export const SET_FILTERID = 'app/BuyersListPage/SET_FILTERID';
export const SET_ADVANCED_FILTERS = 'app/BuyersListPage/SET_ADVANCED_FILTERS';
export const SET_FILTERPROPS = 'app/BuyersListPage/SET_FILTERPROPS';
export const SET_PAGEPROPS = 'app/BuyersListPage/SET_PAGEPROPS';
export const SET_PROPERTIESPROPS = 'app/BuyersListPage/SET_PROPERTIESPROPS';
export const SET_BUYER_COLUMN_DEF = 'app/BuyersListPage/SET_BUYER_COLUMN_DEF';
export const LOAD_HEADER = 'app/LOAD_HEADER';
export const GET_BUYER_COLUMN_DEF = 'app/BuyersListPage/GET_BUYER_COLUMN_DEF';

export const BUYER_COLUMN_HEADER_ACCESSOR = 'TLLAB';
export const BUYER_COLUMN_VALUE_ACCESSOR = 'FDFNAM';
export const BUYER_COLUMN_POSITION = 'FLDPOS';
export const BUYER_COLUMN_SHOW_HIDE_FLAG = 'FLDSHW';
export const BUYER_COLUMN_HEADER_PREFIX_FLAG = 'FDPRFX';

export const BUYER_PROPERTIES = {
  headerName: COLUMN_HEADER_ACCESSOR,
  field: COLUMN_VALUE_ACCESSOR,
  showHideFlag: COLUMN_SHOW_HIDE_FLAG,
  columnPosition: COLUMN_POSITION,
  prefixFlag: COLUMN_HEADER_PREFIX_FLAG,
};

export const PAGE_SIZES = [10, 20, 30];

export const BUYER_LIST_PAGE = 'buyersListPage';

export const SET_BUYER_GLOBAL_FILTER_PROPS = 'SET_BUYER_GLOBAL_FILTER_PROPS';

export const INITIAL_PAGE_PROPS = {
  actualPage: 0,
  currentPage: 0,
  totalCount: 10,
  actualPageSize: 10,
  pageSize: 100,
  isPageSizeChanged: false,
  isForwardDirection: true,
};

export const HAS_PAGINATION = true;

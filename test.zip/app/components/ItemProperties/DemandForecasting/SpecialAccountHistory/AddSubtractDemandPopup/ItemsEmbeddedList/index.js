import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import EmbeddedList from '../../../../../../containers/common/EmbeddedList';
import { MENU_ITEMS } from './constants';

const styles = () => ({
  itemsEmbeddedList: {
    '& > div': {
      height: '80%',
      '& > div': {
        '& > div': {
          '&:last-child': {
            '& > div': {
              '&:first-child': {
                '& > div': {
                  '&:first-child': {
                    height: 'calc(100vh - 450px) !important',
                  },
                },
              },
            },
          },
        },
      },
    },
  },
});

class ItemsEmbeddedList extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      selectedRows: [],
      selectedRowId: null,
    };
  }
  onGridReady = grid => {
    this.grid = grid;
  };

  onRowSelected = () => {};

  handleItemSelection = value => {
    const { classes, itemsEmbeddedList } = this.props;
    const { columnDefs, columnInfo, rowData, pageProps } = itemsEmbeddedList;
    switch (value) {
      case 'itemsFilter':
        this.props.handleItemSelection(value,rowData);
        break;
      default:
        break;
    }
  };

  render() {
    const { classes, itemsEmbeddedList } = this.props;
    const { columnDefs, columnInfo, rowData, pageProps } = itemsEmbeddedList;
    return (
      <div className={classes.itemsEmbeddedList}>
        {columnDefs && columnInfo ? (
          <EmbeddedList
            columnDefs={columnDefs}
            rowColumnID="WACCT"
            rowData={rowData}
            columnInfo={columnInfo}
            columnKey="WACCT"
            listPredecessor=""
            gridAPI={this.grid}
            frameworkComponents={{}}
            menuItems={MENU_ITEMS}
            pageProps={pageProps}
            selectedRows={this.state.selectedRows}
            selectedRowId={this.state.selectedRowId}
            onGridReady={this.onGridReady}
            hasPagination={false}
            hasDeleteRowAction={false}
            rowSelection="single"
            onRowSelected={this.onRowSelected}
            hasGridActions
            menuItemsHandled={['itemsFilter']}
            handleItemSelection={this.handleItemSelection}
          />
        ) : null}
      </div>
    );
  }
}

ItemsEmbeddedList.propTypes = {
  classes: PropTypes.object,
  itemsEmbeddedList: PropTypes.object,
  handleItemSelection: PropTypes.func,
};

export default withStyles(styles)(ItemsEmbeddedList);

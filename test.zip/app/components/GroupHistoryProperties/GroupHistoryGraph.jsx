import React from 'react';
import PropTypes from 'prop-types';
import HightchartsReact from 'highcharts-react-official';
import Highcharts from "highcharts";
import more from "highcharts/highcharts-more";
import draggable from "highcharts/modules/draggable-points";

if (typeof Highcharts === "object") {
  more(Highcharts);
  draggable(Highcharts);
}

class GroupHistoryGraph extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {};
  }
  componentDidUpdate(prevProps, prevState) {
    const { radioSelected } = this.props;
    if (radioSelected && radioSelected !== prevProps.radioSelected) {
      this.setState({ refreshGraph: true }, () => this.setState({ refreshGraph: false }));
    }
  }
  handleChange = (e) => {
    const { radioSelected } = this.props;
    let key = e.target?.index;
    let value = e.newPoint?.y || 0;
    let prefix = "H521";
    if (radioSelected.includes("52")) {
      key = prefix + `${key + 1}`.padStart(2, "0");
    }
    if (radioSelected.includes("13")) {
      const extractNumber = str => +str.match(/(\d+)/)[0];
      const { userOptions: { name } = {} } = e.target.series;
      let weekKey = extractNumber(name);
      key = prefix + `${weekKey + (4 * e.target.index)}`.padStart(2, "0");
    }
    this.props.handleInputChange({ key, value });
  }
  render() {
    const { radioSelected, simInProgress } = this.props;
    const { handleChange } = this;
    //catergories are either PD1-PD13 or 1-52
    let categories = radioSelected === 'show13' ?
      [...Array(13)].map((_, i) => `Pd${i + 1}`)
      : [...Array(52)].map((_, i) => `${i + 1}`);
    let series = this.props.graphData || [];
    const options = {
      chart: {
        type: 'column',
        scrollablePlotArea: {
          //   minWidth: 6000,
          scrollPositionX: 1,
        },
        scrollbar: {
          enabled: true,
        },
      },
      title: {
        text: 'Group History Graph',
      },
      xAxis: {
        categories,
      },
      yAxis: {
        title: {
          text: '',
        },
        stackLabels: {
          enabled: true,
          style: {
            fontWeight: 'bold',
            color:
              // theme
              (Highcharts.defaultOptions.title.style &&
                Highcharts.defaultOptions.title.style.color) ||
              'gray',
          },
        },
      },
      plotOptions: {
        series: {
          label: {
            connectorAllowed: false,
          },
          marker: {
            radius: 2,
          },
          dragDrop: simInProgress ? ({
            dragMinY: 0,
            draggableY: true,
            dragPrecisionY: 2,
            minPointLength: 5,
          }) : false,
          point: {
            events: {
              drop: handleChange
            }
          }
        },
        column: {
          stacking: 'normal',
          dataLabels: {
            enabled: false,
          },
        }
      },
      credits: {
        enabled: false,
      },
      series,
      responsive: {
        rules: [
          {
            condition: {
              maxWidth: 500,
            },
            chartOptions: {
              legend: {
                layout: 'horizontal',
                align: 'center',
                verticalAlign: 'bottom',
              },
            },
          },
        ],
      },
    };
    return !this.state.refreshGraph ? <HightchartsReact highcharts={Highcharts} options={options} /> : null;
  }
}

GroupHistoryGraph.propTypes = {
  series: PropTypes.array,
  categories: PropTypes.array,
};

export default GroupHistoryGraph;

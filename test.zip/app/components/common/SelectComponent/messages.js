/*
 * TypeDropdown Messages
 *
 * This contains all the text for the TypeDropdown component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages({
  default: {
    id: 'app.components.SelectComponent.default.label',
    defaultMessage: 'Filter Type',
  },
});

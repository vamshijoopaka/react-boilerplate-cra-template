import React from 'react';
import { withStyles, Typography, Box } from '@material-ui/core';
import FormattedMessageComponent from '../FormattedMessageComponent';
import PropTypes from 'prop-types';

const propTypes = {
    headerJson: PropTypes.array.isRequired,
    propertyValues: PropTypes.object.isRequired,
    isColumnDisplay: PropTypes.bool,
    labelDisplayCharacters: PropTypes.number
};

const defaultProps = {
    labelDisplayCharacters: 20
}

const styles = theme => ({
    flexWrapper: {
        display: 'flex',
        flexWrap: 'wrap',
        // margin: '1rem 0',
        padding: '8px 24px',
        // boxShadow: '0 2px 4px var(--secondary-s10)',
        // borderRadius: '4px',
        // marginBottom: '1.5rem',
        // backgroundColor: 'var(--background-content)',
        // flexDirection: 'column'
    },
    textWrapper: {
    },
    fieldLabel: {
        color: 'var(--header-label-color)',
        padding: props => props.isColumnDisplay ? '0 30px 0px 0' : '0 30px 8px 0',
        width: props => (props.labelDisplayCharacters + 3) + 'ch',
    },
    childBlock: {
        display: 'flex',
        flexDirection: 'column'
        // width: '45%'
    },
    fieldWrapper: {
        padding: props => props.isColumnDisplay ? '8px 60px 8px 0' : '16px 60px 16px 0',
        display: props => props.isColumnDisplay ? 'flex' : 'block',
    },
    fieldValue: {
        color: 'var(--value)'
    }
})

class HeaderComponent extends React.Component {
    constructor(props) {
        super(props)
    }
    render() {
        const { classes, headerJson, propertyValues, isColumnDisplay } = this.props;
        return (
            <Box className={classes.flexWrapper} style={{flexDirection: isColumnDisplay ? 'column' : 'row' }}>
                {headerJson && headerJson.map(value => {
                    return <Box className={classes.childBlock} key={value.idAccessor}>
                        {value.idLabel && <div className={classes.fieldWrapper}>
                            <div className={classes.textWrapper + ' ' + classes.fieldLabel}><FormattedMessageComponent id={value.idLabel}></FormattedMessageComponent></div>
                            <Typography className={classes.textWrapper + ' ' + classes.fieldValue}>{propertyValues[value.idAccessor]}</Typography>
                        </div>}
                        {value.nameLabel &&<div className={classes.fieldWrapper}>
                            <div className={classes.textWrapper + ' ' + classes.fieldLabel}><FormattedMessageComponent id={value.nameLabel}></FormattedMessageComponent></div>
                            <Typography className={classes.textWrapper + ' ' + classes.fieldValue}>{propertyValues[value.nameAccessor]}</Typography>
                        </div>}
                    </Box>
                })}
            </Box>
        )
    }
}

HeaderComponent.propTypes = propTypes;
HeaderComponent.defaultProps = defaultProps;
export default withStyles(styles)(HeaderComponent);
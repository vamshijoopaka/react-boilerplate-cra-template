import produce from 'immer';
import { UPDATE_COLUMN_DEFS } from './constants';

// The initial state of the filter
export const initialState = {
    columnDefs: {
    },
}
const customGridReducer = (state = initialState, action) => {
    // produce(state, draft => {
    switch (action.type) {
        case UPDATE_COLUMN_DEFS:
            return Object.assign({}, state, { columnDefs: action.payload });
        default: return { ...state };
    }
    // })
}
export default customGridReducer;
/**
 * Copyright © 2018, JDA Software Group, Inc. ALL RIGHTS RESERVED.
 * <p>
 * This software is the confidential information of JDA Software, Inc., and is licensed
 * as restricted rights software. The use,reproduction, or disclosure of this software
 * is subject to restrictions set forth in your license agreement with JDA.
 */
/*
 * AlertsPanel Messages
 *
 * This contains all the text for the AlertsPanel component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages({
  noData: {
    id: 'app.components.common.ErrorDetail.noData',
    defaultMessage: 'No data to be displayed',
  },
  noAlerts: {
    id: 'app.components.common.ErrorDetail.noAlerts',
    defaultMessage: 'No alerts to be displayed',
  },
});

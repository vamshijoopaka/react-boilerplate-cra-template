/** Change Log
 * LogStart --  E3C-33195 - Kumar A- 16 September,2021 - 2022.1.0.0 Unified Product
 *              Story: E3C-33195 --Code Cleanup
*/
export const COMPANY_RECORDS = '29003';
export const COMPANY_CLEANUP_CONTROLFACTORS = '53228';

export const RECORD_RETENTION_GET_FIELD_LIST = 'RECORD_RETENTION_GET_FIELD_LIST';
export const RECORD_RETENTION_GET_FIELD_LIST_SUCCESS = 'RECORD_RETENTION_GET_FIELD_LIST_SUCCESS';
export const RECORD_RETENTION_GET_FIELD_LIST_FAILURE = 'RECORD_RETENTION_GET_FIELD_LIST_FAILURE';

export const RECORD_RETENTION = 'recordRetentionFactors';
export const COMPANY_DATA_RESERVED = "VRSRVD";

export const CUSTOM_CARD_ONE = "4434";
export const CUSTOM_CARD_TWO = "4501";
export const CUSTOM_CARD_THREE = "3331";
export const CUSTOM_CARD_FOUR = "4452";


export const CUSTOM_CARD_KEY = "50916";
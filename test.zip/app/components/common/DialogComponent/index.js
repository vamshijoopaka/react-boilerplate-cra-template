import React, { memo } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import { DialogTitle, IconButton } from '@material-ui/core';
import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import CloseIcon from '@material-ui/icons/Close';
import PaperComponent from 'components/common/PaperComponent';
import { Box } from '@material-ui/core';
import Button from '@material-ui/core/Button';
import { withStyles } from '@material-ui/core/styles';
import CloseImage from '../../../images/close.png';
import FormattedMessageComponent from '../FormattedMessageComponent';
//JVK
import clsx from 'clsx';

const styles = theme => ({
    closeIcon: {
        position: 'absolute',
        top: '10px',
        right: '20px'
    },
    dialogWidthHeight: {
        position: 'relative',
    },
    spaceBetween: {
        display: 'flex',
        justifyContent: 'space-between'
    },
    positionLeft: {
        position: 'absolute',
        left: '16px',
        bottom: '8px',
        display: 'flex'
    },
    dialogHeader: {
        cursor: 'move',
        display: 'flex',
        justifyContent: 'space-between',
        width: '100%',
    },
    titleText: {
        display: 'inline-block'
    },
    closeIcon: {
        cursor: 'pointer'
    },
    DialogButton: {
        marginLeft: '10px'
    },
    backNextText: {
        marginLeft: '10px',
        marginRight: '10px',
    },
    secondSave: {
        marginLeft: '20px'
    }
})
class DialogComponent extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            defaultOptions: {
                disableEscapeKeyDown: true,
                dialogTitle: false
            }
        }
        this.getFormattedMessage = this.getFormattedMessage.bind(this);
        this.getHeaderTitle = this.getHeaderTitle.bind(this);
    }

    getFormattedMessage(id) {
        return <FormattedMessageComponent id={id}></FormattedMessageComponent>;
    }

    getHeaderTitle() {
        if (this.props.extraTitle) {
            return <div className={'display-flex'}>
                <FormattedMessageComponent id={this.props.dialogTitle}></FormattedMessageComponent>
                <div>-</div>
                <div>{this.props.extraTitle}</div>
            </div>;

        } else {
            return this.getFormattedMessage(this.props.dialogTitle);
        }
    }

    render() {
        const { classes, isBackArrow } = this.props;
        return (
            <div>
                <Dialog className={clsx(classes.dialogWidthHeight)}
                    classes={{ paper: this.props.className, paperWidthSm: this.props.classNamePaperWidthSm }}
                    ref="dialogRef"
                    fullScreen={this.props.fullScreen}
                    open={this.props.isOpen}
                    PaperComponent={PaperComponent}
                    aria-labelledby="draggable-dialog-title">
                    <DialogTitle id="draggable-dialog-title">
                        <div className={classes.dialogHeader}>
                            <div>
                                {isBackArrow &&
                                    <IconButton onClick={this.props.handleClose}>
                                        <ArrowBackIcon></ArrowBackIcon>
                                    </IconButton>
                                }
                                <span className={classes.titleText}>
                                    {Boolean(Number(this.props.dialogTitle)) && this.getHeaderTitle()
                                    }
                                    {!Boolean(Number(this.props.dialogTitle)) && this.props.dialogTitle}
                                </span>
                            </div>
                            <div className={classes.closeIcon}>
                                <img onClick={this.props.handleClose} className={classes.closeIcon} src={CloseImage} alt={'close_icon'} />
                            </div>
                        </div>
                    </DialogTitle>
                    <DialogContent>
                        {this.props.children}
                    </DialogContent>
                    <DialogActions>
                        <Box className={classes.positionLeft}>
                            {this.props.saveText && <Box>
                                <Button size="large" color="primary" variant="outlined" onClick={this.props.handleSave} disabled={this.props.disableSave || false}>
                                    {this.getFormattedMessage(this.props.saveText)}
                                </Button>
                            </Box>}
                            {this.props.saveText2 && <Box>
                                <Button className={classes.secondSave} size="large" color="primary" variant="outlined" onClick={this.props.handleSave2} disabled={this.props.disableSave2 || false}>
                                    {this.getFormattedMessage(this.props.saveText2)}
                                </Button>
                            </Box>}
                        </Box>
                        <Box>
                            {this.props.backText && <Button size="large" color="primary" variant="outlined" onClick={this.props.handleBack} disabled={Boolean(this.props.disableBack) || false} >
                                {Boolean(Number(this.props.backText)) && this.getFormattedMessage(this.props.backText)
                                }
                                {!Boolean(Number(this.props.backText)) && this.props.backText}
                            </Button>}
                            {this.props.backNextText && <Button className={classes.backNextText} size="large" variant="contained" color="primary" onClick={this.props.handleBackNextText} disabled={Boolean(this.props.disableBackNext) || false}>
                                {Boolean(Number(this.props.backNextText)) && this.getFormattedMessage(this.props.backNextText)
                                }
                                {!Boolean(Number(this.props.backNextText)) && this.props.backNextText}
                            </Button>}
                            {/*E3C-31765,E3C-31766:Begin: Adding cancel button to filter and sort dialogs*/}
                            {this.props.clearText && <Button size="large" color="primary" className={classes.backNextText} variant="outlined" onClick={() => this.props.handleCancel(this.props.clearText)}>
                                {Boolean(Number(this.props.clearText)) && this.getFormattedMessage(this.props.clearText)
                                }
                                {!Boolean(Number(this.props.clearText)) && this.props.clearText}
                            </Button>}
                            {this.props.resetText && <Button size="large" color="primary" className={classes.backNextText} variant="outlined" onClick={() => this.props.handleCancel(this.props.resetText)}>
                                {Boolean(Number(this.props.resetText)) && this.getFormattedMessage(this.props.resetText)
                                }
                                {!Boolean(Number(this.props.resetText)) && this.props.resetText}
                            </Button>}
                            {/*E3C-31765,E3C-31766:End */}
                            {this.props.cancelText && <Button size="large" color="primary" variant="outlined" onClick={() => this.props.handleCancel(this.props.cancelText)}> {/*E3C-31765,E3C-31766:Added code to pass id Since clear acts as cancel in filter criteria*/}
                                {Boolean(Number(this.props.cancelText)) && this.getFormattedMessage(this.props.cancelText)
                                }
                                {!Boolean(Number(this.props.cancelText)) && this.props.cancelText}
                            </Button>}

                            {this.props.submitText && <Button className={classes.DialogButton} size="large" variant="contained" color="primary" onClick={this.props.handleSubmit} disabled={Boolean(this.props.disableSubmit) || false}>
                                {Boolean(Number(this.props.submitText)) && this.getFormattedMessage(this.props.submitText)
                                }
                                {!Boolean(Number(this.props.submitText)) && this.props.submitText}
                            </Button>}
                            {this.props.nextText && <Button className={classes.DialogButton} size="large" variant="contained" color="primary" onClick={this.props.handleNext} disabled={Boolean(this.props.disableNext) || false}>
                                {Boolean(Number(this.props.nextText)) && this.getFormattedMessage(this.props.nextText)
                                }
                                {!Boolean(Number(this.props.nextText)) && this.props.nextText}
                            </Button>}
                            {this.props.applyText && <Button className={classes.DialogButton} size="large" variant="contained" color="primary" onClick={this.props.handleApply} disabled={Boolean(this.props.disableSubmit) || false}>
                                {Boolean(Number(this.props.applyText)) && this.getFormattedMessage(this.props.applyText)
                                }
                                {!Boolean(Number(this.props.applyText)) && this.props.applyText}
                            </Button>}
                        </Box>
                    </DialogActions>
                </Dialog>
            </div >
        );
    }
}

export default withStyles(styles)(DialogComponent);
import { createSelector } from 'reselect';

const errorMessageDomain = (state) => state.get('root').get('errorMessageLabels')

const errorMessageLabels = (state, namespace) =>
	createSelector(
		errorMessageDomain,
		data => data
    )

    export {
        errorMessageLabels, 
    }

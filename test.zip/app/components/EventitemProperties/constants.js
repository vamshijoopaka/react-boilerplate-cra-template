export const HeaderAPIValuesJSON = [
	{
		"EICOMP": "", //COMPANY
		"EIEVNT": "", //EVENTITEM ID
		"EIRDES": "", //EVENTITEM NAME
		"EIBGDT": "", //BEGIN DATE
		"EIENDT": "", //END DATE
		"EIBGPD": "", //BEGIN WEEK
		"EIENPD": "", //END WEEK
	}
];

export const LABEL_LIST_URL_DATA = [
	{ "accessor": "KTRIMBO", "operator": "=", "fieldValue": "TrimEventitemUI", "prefixFlag": 1 },
	{ "accessor": "KLANGID", "operator": "=", "fieldValue": "ENG", "prefixFlag": 1 }
]
export const DEFAULT_VALUE_URL_DATA = [
	{ "accessor": "COMP", "operator": "=", "fieldValue": "", "prefixFlag": 0 },
	{ "accessor": "EVNT", "operator": "=", "fieldValue": "", "prefixFlag": 0 },
	{ "accessor": "TYPE", "operator": "=", "fieldValue": "", "prefixFlag": 0 },
	{ "accessor": "WHSE", "operator": "=", "fieldValue": "", "prefixFlag": 0 },
	{ "accessor": "VNDR", "operator": "=", "fieldValue": "", "prefixFlag": 0 },
]

export const FILTER_DATA = ["COMP", "EVNT", "TYPE", "WHSE", "VNDR"]; //, "SUBV"];//, "ITEM"]; //, "RWHS", "RVND", "RSUB", "RITM"];


// KCOMP: "E3T"
// KEVNT: "487"
// KTYPE: "P"
// KINAM: "A1S9"
// KITEM: "A1S9"
// KSUBV: "SV2"
// KVNDR: "A5V5"
// KWHSE: "091"
// KMPRF: ""
// KRITM: ""
// KRSUB: ""
// KRVND: ""
// KRWHS: ""

export const LABEL_EVENTITEM_DETAIL = "28012";
export const LABEL_EVENTITEM_EFFECTS = "28013";
export const LABEL_COMPANY_ID = "33303";
export const LABEL_EVENTITEM_ID = "33785";
export const LABEL_EVENTITEM_DESC = "39606";
export const LABEL_BEGIN_DATE = "33083";
export const LABEL_END_DATE = "33082";
export const LABEL_BEGIN_WEEK = "39831";
export const LABEL_END_WEEK = "39833";
export const LABEL_COPY = "25212";
export const LABEL_DELETE = "25211";

export const LABEL_ACTIONS = '28310';


export const LABEL_VENDOR_ID = "34433";
export const LABEL_SUB_VENDOR_ID = "34435";
export const LABEL_VENDOR_NAME = "33989";
export const LABEL_WAREHOUSE_NAME = "36479";
export const LABEL_WAREHOUSE_ID = "33161";
export const LABEL_ITEM_ID = "33670";
export const LABEL_ITEM_NAME = "33990";
export const LABEL_EVENT_ID = "33078";
export const LABEL_EVENT_NAME = "39987";
export const LABEL_DATES = "52777";
export const LABEL_WEEKS = "52778";


export const CURRENT_PAGE = 'EventItemDetailsEffects';
export const radioOptions = [{ key: '52759', fieldValue: 'eventEffects' }, { key: '52760', fieldValue: 'overlappedEffects' }];


export const EVENT_ITEM_LIST_FILTERS = [{ "accessor": "COMP", 'prefixFlag': 0, "key": "COMP", "value": "E3T", "operator": "=", "fieldValue": "E3T", "jOpr": 'and' },
{ "accessor": "ITEM", 'prefixFlag': 0, "key": "ITEM", "value": "", "operator": "=", "fieldValue": "", "jOpr": 'and' },
{ "accessor": "WHSE", 'prefixFlag': 0, "key": "WHSE", "value": "", "operator": "=", "fieldValue": "", "jOpr": 'and' },
];


export const CONTEXT_MENU_EVENTITEM_ACTIONS = [
	{
		label: LABEL_DELETE,
		key: LABEL_DELETE,
		hasSubMenu: false,
		isDisable: false
	},

];
export const LABEL_ADD_PLAN = "52707";

export const CONTEXT_MENU_ACTIONS =[
	{
		label: LABEL_ADD_PLAN,
		key: LABEL_ADD_PLAN,
		hasSubMenu: false,
		isDisable: false
	},
]

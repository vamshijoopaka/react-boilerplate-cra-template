/**
 *
 * DealsList
 *
 */

import React from 'react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';
import PaginationGrid from '../PaginationGrid';



import {
  getListPredecessor,
  getFilterDataFromLocalStorage,
  getSaveTypeFromCurrentPage,
  getTitleObj,
  getDefaultField,
  setSortDataFromSortCriteria,
  getDefaultSortInfo,
  isEqualSortArrays,
  isColumnSortable,
  getFilterDataFromCriteriaDetails
} from '../../utils/util';


import Spinner from 'components/Common/Spinner';
import ErrorDetail from 'components/Common/ErrorDetail';

import {
  DEAL_LIST_PAGE,
  DEAL_PROPERTIES,
  PAGE_SIZES,
  INITIAL_PAGE_PROPS,
} from './constants';

import {

  DEALS_LIST_PAGE,
  GLOBAL_FILTER_OPTIONS,
  COLUMN_HEADER_ACCESSOR,
  COLUMN_VALUE_ACCESSOR,
  COLUMN_SHOW_HIDE_FLAG,
  COLUMN_HEADER_PREFIX_FLAG,
  COLUMN_FIELD_NUM,
  FILTER_CRITERIA_API_LIST_CONSTANTS,
  TEXT_ALERT,
  TEXT_OK,
  DATA_ACCESS_KEY
} from '../common/constants';
import { isEqual } from 'lodash';



import {
  getDBSelectorFilterValues,
  prepareTooltipValues
} from 'utils/filterData';
import LinkRenderer from '../CustomGrid/LinkRenderer';
import DateRenderer from '../CustomGrid/DateRenderer';
import ConfirmationDialog from 'components/common/ConfirmationDialog';
import FormattedMessageComponent from '../common/FormattedMessageComponent';

import NumberRenderer from 'components/CustomGrid/NumberRenderer';
import TextRenderer from 'components/CustomGrid/TextRenderer';
import DropdownRenderer from 'components/CustomGrid/DropdownRenderer';

const frameworkComponent = {
  'numberRenderer': NumberRenderer,
  'textRenderer': TextRenderer,
  'dropdownRenderer': DropdownRenderer,
  'dateRenderer': DateRenderer,
  'linkRenderer': LinkRenderer
};


class DealsList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isOpenEmbeddedList: false,
      selectedRecord: false,
      currentFilterProps: false,
      currentDbSelectorProps: false,
      isDataLoaded: false,
      isFromTabs: false,
      defaultSortProps: [],
      previousFilterValues: false,
      isFiltersChanged: false,
      showConfirmationDialog: false,
      dialogTitle: '',
      hasWarning: false,
      dialogInfo: '',
      isInitialAPICall: true,
      previousSortValues: false,
      paginationRecord: false
    }
    this.onGridReady = this.onGridReady.bind(this);
    this.getRecordDataOnDirection = this.getRecordDataOnDirection.bind(this);
    this.setPageForwardDirection = this.setPageForwardDirection.bind(this);
    this.resetPagePropsAndSendApiCall = this.resetPagePropsAndSendApiCall.bind(this);
    this.sendAPIWithExistingPageprops = this.sendAPIWithExistingPageprops.bind(this);
    this.onValueChanged = this.onValueChanged.bind(this);
    this.onRowSelected = this.onRowSelected.bind(this);
    this.forceUpdateHandler = this.forceUpdateHandler.bind(this);
    this.setFilterValues = this.setFilterValues.bind(this);
    this.setFilterValuesFromState = this.setFilterValuesFromState.bind(this);
    this.handleNoDataSets = this.handleNoDataSets.bind(this);
    this.sendInitialAPIForList = this.sendInitialAPIForList.bind(this);
  }

  onRowSelected() {
    this.props.setSelectedRecord(JSON.parse(JSON.stringify(this.grid.api.getSelectedRows()[0])), 'deals');
    this.props.setIsShowContextMenu(true);
  }

  onValueChanged() {
  }

  sendInitialAPIForList(filterProps, sortProps, pageProps) {
    this.resetPagePropsAndSendApiCall(filterProps, sortProps, pageProps, true, false);
  }

  resetValues = () => {
	this.setState({ isInitialAPICall: true });
    this.setState({ isDataLoaded: false });
    this.props.setInitialState();
    this.props.getDealColumnDefs({ type: DEALS_LIST_PAGE });
  }

  componentDidMount() {
    this.resetValues();
    let isFilterValuesExists = this.setFilterValues();
    let properties = DEAL_PROPERTIES;
    let filterOptions = GLOBAL_FILTER_OPTIONS;
    this.props.setGlobalGridConfigOptions(properties);
    let currentPage = DEALS_LIST_PAGE;
    this.props.onLoadCurrentPage(currentPage);
    if (!isFilterValuesExists) {
      this.props.onSetFilterProps(filterOptions);
    }
  }
  setFilterValuesFromState(values, isAPICall) {
    let filterValues = [];
    const { columnDefs } = this.props.dealsListPage;
    if (columnDefs && columnDefs.length) {
      values.forEach((value) => {
        let isExists = columnDefs.find((column) => column[COLUMN_VALUE_ACCESSOR].trim() == value.accessor);
        if (isExists) {
          filterValues.push(value)
        }
      });
      if (filterValues && filterValues.length) {
        if (isAPICall) {
          this.resetPagePropsAndSendApiCall(filterValues, this.previousSortValues, INITIAL_PAGE_PROPS, true, false);
        }
        this.props.onSetFilterProps(filterValues);
        this.props.setGlobalFilterProps(filterValues);
        return filterValues;
      }
    } else {
      if (isAPICall) {
        this.resetPagePropsAndSendApiCall(values, this.previousSortValues, INITIAL_PAGE_PROPS, true, false);
      }
      this.props.onSetFilterProps(values);
      this.props.setGlobalFilterProps(values);
      return values;
    }
  }

  modValues = (values) => {
    let modValues = [];
    values.forEach(entry => {
      if (entry.accessor !== "BTOTL" && entry.accessor.substr(0, 4) !== "IGRP" && entry.accessor.substr(0, 4) !== "VGRP") {
        if (entry.accessor.substr(1, 3) == "GRP") {
          entry.prefixFlag = true;
        }
        modValues.push(entry);
      }
    }
    );
    return modValues;
  }

  setFilterValues() {
    const { history } = this.props;
    let isFilterValuesExists = false, isLocalStorageValuesExists = false;
    var paramsString = window.location.search;
    if (paramsString && paramsString.length) {
      let paramsArray = paramsString.split("?");
      if (paramsArray && paramsArray.length && paramsArray.length > 1) {
        let params = paramsArray[1].split("&");
        let tabId = params[0].split("=")[1];
        let breadCrumbId = params[1].split("=")[1];
        if (tabId && breadCrumbId) {
          this.setState({ isFromTabs: true });
        }
        let localStorageValues = getFilterDataFromLocalStorage(tabId, breadCrumbId);
        if (localStorageValues && Object.keys(localStorageValues) && Object.keys(localStorageValues).length) {
          isLocalStorageValuesExists = true;
          let dealData = localStorageValues[DATA_ACCESS_KEY], dbSelectorValues = [];
          this.props.setSelectedRecord(false, false);
          if (dealData) {
            if (dealData.dbSelector && dealData.dbSelector.length) {
              dbSelectorValues = JSON.parse(JSON.stringify(dealData.dbSelector));
            }
            if (dealData.sortProps && dealData.sortProps.length) {
              this.previousSortValues = dealData.sortProps;
              this.props.sendPageSortProps(dealData.sortProps);
              this.props.onSetSortProps(dealData.sortProps);
              this.props.setSortPropsChangeFlag(false);
              this.setState({ defaultSortProps: JSON.parse(JSON.stringify(dealData.sortProps)) });
            }
            if (dealData.filterProps && dealData.filterProps.length) {
              isFilterValuesExists = true;
			  let values = getDBSelectorFilterValues(dbSelectorValues, dealData.filterProps);
			  values = this.modValues(values);
              this.setState({ currentFilterProps: JSON.parse(JSON.stringify(values)) });
              this.setFilterValuesFromState(values);
            } else if (dbSelectorValues && dbSelectorValues.length) {
              isFilterValuesExists = true;
			  let dbValues = getDBSelectorFilterValues(dbSelectorValues, []);
			  dbValues = this.modValues(dbValues);
              this.setFilterValuesFromState(dbValues);
            }
            if (dealData.defaultFilterInfo && Object.keys(dealData.defaultFilterInfo) && Object.keys(dealData.defaultFilterInfo).length) {
              this.props.setDefaultFilterpropsForTabs(dealData.defaultFilterInfo);
            }
            if (dealData.defaultSortInfo && Object.keys(dealData.defaultSortInfo) && Object.keys(dealData.defaultSortInfo).length) {
              this.props.setDefaultSortpropsForTabs(dealData.defaultSortInfo);
            }
            if (dealData.pageProps && Object.keys(dealData.pageProps) && Object.keys(dealData.pageProps).length) {
              this.props.onSetPageProps(dealData.pageProps);
            }
            if (dealData.paginationRecord && Object.keys(dealData.paginationRecord) && Object.keys(dealData.paginationRecord).length) {
              this.setState({ paginationRecord: dealData.paginationRecord });
            }
            if (dealData.apiCallCount != undefined && parseInt(dealData.apiCallCount) >= 0) {
              this.props.setApiCallCount(dealData.apiCallCount);
            }
          }
          if (!isLocalStorageValuesExists && tabId && breadCrumbId) {
            history.push({ pathname: '/Dashboard' });
          }
        }
      }
    } else {
      history.push({ pathname: '/Dashboard' });
    }
    let filterOptions = GLOBAL_FILTER_OPTIONS;
    const { dbSelector } = this.props;
    if (!isFilterValuesExists) {
	  let gbValues = getDBSelectorFilterValues(dbSelector, filterOptions);
	  gbValues = this.modValues(gbValues);
      this.setState({ currentFilterProps: JSON.parse(JSON.stringify(gbValues)) });
      this.setFilterValuesFromState(gbValues);
    }
    return isFilterValuesExists;
  }


  onGridReady(params) {
    this.grid = params;
  }

  componentWillUnmount() {
    this.setState({ isDataLoaded: false });
    this.props.setInitialState();
  }

  onClickLink = (data, rowIndex) => {

    const { columnDefs, pageProps, filterProps, sortProps, defaultSortProps, filterCriteriaDetails } = this.props.dealsListPage;
    const { actualPageSize, actualPage } = pageProps;
    if (this.state.isFromTabs) {
      let pathname = 'DealsProperties',
        filterData = (filterProps && filterProps.length) ? filterProps : [],
        sortData = (sortProps && sortProps.length) ? sortProps : [],
        defaultFilterInfo = (filterCriteriaDetails && Object.keys(filterCriteriaDetails) && Object.keys(filterCriteriaDetails).length) ? filterCriteriaDetails : {},
        defaultSortInfo = (defaultSortProps && Object.keys(defaultSortProps) && Object.keys(defaultSortProps).length) ? defaultSortProps : {},
        tooltipData = prepareTooltipValues('deals', data, columnDefs, 'dealsproperties'),

        stateData = {
          data: JSON.parse(JSON.stringify(data)),
          fromPage: 'deals',
          rowIndex: (actualPageSize * actualPage) + rowIndex,
          totalCount: this.props.dealsListPage.totalCount,
          fromParent: true,
          columnDefs: columnDefs
        }
      this.props.setIsShowContextMenu(true);

      this.props.addChildTab(pathname, stateData, tooltipData, filterData,
        sortData, defaultSortInfo, defaultFilterInfo);

    } else {
      this.props.push({
        pathname: '/DealsProperties',
        state: {
          data: data,
          fromPage: 'deals',
          rowIndex: (actualPageSize * actualPage) + rowIndex,
          totalCount: this.props.dealsListPage.totalCount,
          fromParent: true,
          columnDefs: columnDefs
        }
      })
    }
  }

  handleNoDataSets(isColumns) {
    const { deals, columnDefs } = this.props.dealsListPage;
    if (this.state.isDataLoaded) {
      if (isColumns && columnDefs && columnDefs.length) {
        //do nothing here
      } else if (deals && deals.length && columnDefs && columnDefs.length) {
        //do nothing here
      } else {
        this.props.setNoDataCallBackValue(true);
        this.showConfirmationDialog = true;
        this.noDatasets = true;
      }
    }
  }

  handleCloseChildTab = () => {
    var paramsString = window.location.search;
    if (paramsString && paramsString.length) {
      let paramsArray = paramsString.split("?");
      if (paramsArray && paramsArray.length && paramsArray.length > 1) {
        let params = paramsArray[1].split("&");
        let tabId = params[0].split("=")[1];
        let breadCrumbId = params[1].split("=")[1];
        this.props.removeCurrentRecordObj(tabId, breadCrumbId);
      }
    }
  }


  onRowDoubleClicked = (event) => {
    this.setState({ selectedRecord: event.data });
    this.setState({ isOpenEmbeddedList: true });
  };

  initialLoad(props, flag) {
    const { filterProps, sortProps, pageProps } = props.dealsListPage;
    let record;
    if (flag) {
      record = {}
    } else {
      record = this.getRecordDataOnDirection(pageProps.isForwardDirection);
    }
    if (pageProps) {
      if (pageProps.currentPage != 0) {
        this.props.setDataInTabs("paginationRecord", record);
      } else {
        this.props.setDataInTabs("paginationRecord", {});
      }
      this.props.onloadDeals(filterProps, sortProps, pageProps, pageProps.isForwardDirection, record);
    }
  }

  getRecordDataOnDirection(direction) {
    const { deals } = this.props.dealsListPage;
    if (!deals) {
      return;
    }
    if (!direction) {
      let count = this.props.apiCallCount;
      this.props.setApiCallCount(count - 1);
      return deals[0];
    } else {
      let count = this.props.apiCallCount;
      this.props.setApiCallCount(count + 1);
      return deals[deals.length - 1];
    }
  }


  loadDeals = () => {
    if (!this.props.dealsListPage.isAPIProgress) {
      this.initialLoad(this.props, false);
    }
  }

  setPageForwardDirection(flag) {
    const { pageProps } = this.props.dealsListPage;
    this.props.onSetPageProps({
      ...pageProps,
      actualPage: 0,
      currentPage: 0,
      totalCount: 10,
      isForwardDirection: flag
    });
  }

  setSortHeader = (sortProps) => {
    let sort = [];
    if (sortProps && sortProps.length) {
      sortProps.forEach(ele => {
        let obj = {};
        obj['colId'] = ele.accessor;
        obj['sort'] = ele.sort ? ele.sort : (ele.sortOrder === 'Ascending' ? 'asc' : 'desc');
        sort.push(obj);
      })
      if (this.grid) {
      }
    }
  }

  resetPagePropsAndSendApiCall(filterProps, sortProps, pageProps, direction, record, exportFilterProps, exportFields, showHideColumns, searchReplaceValues) {
    this.setPageForwardDirection(true);
    this.props.onloadDeals(filterProps, sortProps, pageProps, direction, record, exportFilterProps, exportFields, showHideColumns, searchReplaceValues);
  }

  sendAPIWithExistingPageprops(filterProps, sortProps, direction, record, exportFilterProps, exportFields, showHideColumns, searchReplaceValues) {
    let recordData = JSON.parse(JSON.stringify(record));
    const { pageProps } = this.props.dealsListPage;
    let existingPageProps = {
      ...pageProps,
      isForwardDirection: true
    }
    this.props.onSetPageProps({
      ...pageProps,
      isForwardDirection: true
    });
    if (this.state.paginationRecord && Object.keys(this.state.paginationRecord) && Object.keys(this.state.paginationRecord).length) {
      recordData = JSON.parse(JSON.stringify(this.state.paginationRecord));
    }
    this.props.onloadDeals(filterProps, sortProps, existingPageProps, direction, recordData, exportFilterProps, exportFields, showHideColumns, searchReplaceValues);
  }

  forceUpdateHandler() {
    this.forceUpdate();
  };

  handleClose = () => {
    if (this.noDatasets) {
      this.noDatasets = false;
      this.handleCloseChildTab();
    }
    this.setState({ showConfirmationDialog: false });
  }

  handleFilterClose = () => {
    if (this.state.isFiltersChanged) {
      this.props.onSetFilterProps(this.state.previousFilterValues);
      this.props.setGlobalFilterProps(this.state.previousFilterValues);
      this.props.setChildTabFilterProps(this.state.previousFilterValues);
      this.setState({ isFiltersChanged: false });
    }
    this.props.setValueDataAPIFailureFlag(false);
    this.props.setValueDataFlag(false);
    this.props.handleCloseDealsFilter();
    this.props.closeFilterComponent(true);
  }

  componentDidUpdate(prevProps, prevState) {
    const { sortProps, filterProps, pageProps, exportFilterProps, exportFields,
      showHideColumns, searchReplaceValues, columnDefs, updateColumnsList, deals,
      isColumnDefsLoaded, currentLoadedProps, defaultSortProps, isSortPropsChanged, columnInfo,
      sortCriteriaDetails, closeFiltersPopup, isValueDataAPICall, isValueDataAPIFailure, hasToResetDefaults, filterCriteriaDetails,
      apiCallCount } = this.props.dealsListPage;

    const { pageFilters } = this.props;

    if (closeFiltersPopup != prevProps.dealsListPage.closeFiltersPopup && closeFiltersPopup) {
      this.handleFilterClose();
    }

    if (!isEqual(apiCallCount, prevProps.dealsListPage.apiCallCount)) {
      this.props.setDataInTabs("apiCallCount", apiCallCount);
    }

    if (pageProps && !isEqual(pageProps, prevProps.dealsListPage.pageProps)) {
      this.props.setDataInTabs("pageProps", JSON.parse(JSON.stringify(pageProps)));
    }

    if (sortProps && sortProps.length && !isEqual(sortProps, prevProps.dealsListPage.sortProps)) {
      this.props.setDataInTabs("sortProps", JSON.parse(JSON.stringify(sortProps)));
      this.props.setSortPropsChangeFlag(false);
    }

    if ((isValueDataAPICall != prevProps.dealsListPage.isValueDataAPICall) && isValueDataAPICall) {
      this.setState({ isInitialAPICall: false });
      this.setState({ previousFilterValues: filterProps })
      this.props.setValueDataFlag(false);
      this.props.setValueDataAPIFailureFlag(false);
      if (this.state.isFiltersChanged) {
        this.setState({ isFiltersChanged: false });
        this.props.handleCloseDealsFilter();
        this.props.closeFilterComponent(true);
      }
    }

    if ((isValueDataAPIFailure != prevProps.dealsListPage.isValueDataAPIFailure) && isValueDataAPIFailure) {
      this.setState({ isInitialAPICall: false });
      if (!this.state.isDataLoaded && columnDefs && columnDefs.length) {
        this.setState({ isDataLoaded: true }, () => {
          this.handleNoDataSets();
        });
      }
      if (this.state.isFiltersChanged) {
        this.props.setValueDataAPIFailureFlag(false);
        this.setState({ showConfirmationDialog: true });
        this.setState({ hasWarning: true });
        this.setState({ dialogTitle: TEXT_ALERT });
        this.setState({ dialogInfoId: '28648' });
      }
    }

    if (JSON.stringify(deals) != JSON.stringify(prevProps.dealsListPage.deals) && !this.state.isDataLoaded && deals && columnDefs && columnDefs.length) {
      this.setState({ isDataLoaded: true }, () => {
        this.handleNoDataSets();
      });
    }

    if ((!isEqual(sortProps, prevProps.dealsListPage.sortProps) || isSortPropsChanged && currentLoadedProps == 'sort') && !this.state.isInitialAPICall) {
      this.props.setSortPropsChangeFlag(false);
      if (sortProps && sortProps.length) {
        this.resetPagePropsAndSendApiCall(filterProps, sortProps, pageProps, true, false);
      }
    }

    if (this.props.location.search != prevProps.location.search) {
      this.resetValues();
      this.forceUpdateHandler();
      this.setFilterValues();
      this.setState({ state: this.state });
    }

    if ((pageProps != prevProps.dealsListPage.pageProps) && pageProps.isPageSizeChanged) {
      this.props.setApiCallCount(0);
      let initialPageData = {
        ...pageProps,
        actualPage: 0,
        currentPage: 0,
        totalCount: 10,
        isForwardDirection: true,
      };
      this.resetPagePropsAndSendApiCall(filterProps, sortProps, initialPageData, true, false);
      this.props.onSetPageProps({
        ...initialPageData,
        isPageSizeChanged: false
      });
    }

    if ((JSON.stringify(columnDefs) != JSON.stringify(prevProps.dealsListPage.columnDefs)) && !prevProps.dealsListPage.columnDefs) {
      if (columnDefs && columnDefs.length) {
        if (!isColumnDefsLoaded) {
          this.props.setFlagColumnDefsLoaded(true);
        }
      } else if (!this.state.isDataLoaded) {
        this.setState({ isDataLoaded: true }, () => {
          this.handleNoDataSets(true);
        });
      }
    }

    if ((JSON.stringify(columnDefs) != JSON.stringify(prevProps.dealsListPage.columnDefs))) {
      if (columnDefs && columnDefs.length) {
        this.props.setGlobalColDefs(columnDefs);
        if (columnInfo) {
          this.props.setGlobalColumnInfo(columnInfo);
        }
      }
    }

    if ((defaultSortProps != prevProps.dealsListPage.defaultSortProps) && (prevProps.dealsListPage.defaultSortProps === null) && (sortProps == null || !sortProps || !(sortProps && sortProps.length))) {
      this.props.setLoadingFlag(true);
      let list = setSortDataFromSortCriteria(defaultSortProps, columnDefs, DEALS_LIST_PAGE);
      this.props.setDataInTabs("defaultSortInfo", JSON.parse(JSON.stringify(defaultSortProps)));
      if (list && list.length) {
        this.props.sendPageSortProps(list);
        this.props.onSetSortProps(list);
        this.sendAPIWithExistingPageprops(filterProps, list, true, false);
      } else {
        this.props.sendPageSortProps([]);
        this.props.onSetSortProps([]);
        this.sendAPIWithExistingPageprops(filterProps, [], true, false);
      }
    }

    if (JSON.stringify(sortCriteriaDetails) != JSON.stringify(prevProps.dealsListPage.sortCriteriaDetails)) {
      this.props.setDataInTabs("defaultSortInfo", JSON.parse(JSON.stringify(sortCriteriaDetails)));
      let list = setSortDataFromSortCriteria(sortCriteriaDetails, columnDefs, DEALS_LIST_PAGE);
      if (list && list.length) {
        this.props.sendPageSortProps(list);
        this.props.onSetSortProps(list);
      }
    }

    if (currentLoadedProps != prevProps.dealsListPage.currentLoadedProps && currentLoadedProps == 'sort' && sortProps && filterProps && pageProps) {
      this.props.setSortPropsChangeFlag(false);
      this.props.setGlobalFilterProps(filterProps);
    }

    if (sortProps != prevProps.dealsListPage.sortProps && sortProps && sortProps.length && !this.state.isInitialAPICall) {
      this.props.setApiCallCount(0);
      this.resetPagePropsAndSendApiCall(filterProps, sortProps, pageProps, true, false);
    }

    if (isColumnDefsLoaded != prevProps.dealsListPage.isColumnDefsLoaded && isColumnDefsLoaded && filterProps && filterProps.length && (sortProps == null || !sortProps || !(sortProps && sortProps.length))) {
	  this.props.setEmptyDefaultSort();
    }

    if (isColumnDefsLoaded != prevProps.dealsListPage.isColumnDefsLoaded && isColumnDefsLoaded && filterProps && filterProps.length && this.state.isInitialAPICall) {
      if (sortProps && sortProps.length) {
        this.sendAPIWithExistingPageprops(filterProps, sortProps, true, false);
      }
    }

    if ((filterCriteriaDetails != prevProps.dealsListPage.filterCriteriaDetails)) {
      this.props.setDataInTabs("defaultFilterInfo", JSON.parse(JSON.stringify(filterCriteriaDetails)));
      if (filterCriteriaDetails && Object.keys(filterCriteriaDetails) && Object.keys(filterCriteriaDetails).length && columnDefs && columnDefs.length) {
        let list = getFilterDataFromCriteriaDetails(filterCriteriaDetails, columnDefs, DEALS_LIST_PAGE);
        if (list && list.length) {
          this.props.setGlobalFilterProps(list);
          this.props.onSetFilterProps(list);
        }
      }
    }

    if ((JSON.stringify(filterProps) != JSON.stringify(prevProps.dealsListPage.filterProps)) && pageProps && !pageFilters && filterProps) {
      this.props.setGlobalFilterProps(filterProps);
    }

    if (!isEqual(filterProps, prevProps.dealsListPage.filterProps) && filterProps && filterProps.length && pageProps && !this.state.isInitialAPICall) {
      this.props.setApiCallCount(0);
      this.resetPagePropsAndSendApiCall(filterProps, sortProps, pageProps, true, false);
    }

    if ((JSON.stringify(filterProps) != JSON.stringify(prevProps.dealsListPage.filterProps)) && filterProps && filterProps.length) {
      this.props.setChildTabFilterProps(filterProps);
      this.setState({ isFiltersChanged: true });
    }

    if (showHideColumns != prevProps.dealsListPage.showHideColumns) {
      this.props.getUpdatedColumnDefs({ type: DEALS_LIST_PAGE, userId: this.props.columnInfo['USERID'].trim(), 'record': showHideColumns });
    }

    if ((updateColumnsList != prevProps.dealsListPage.updateColumnsList) && updateColumnsList) {
      this.props.getDealColumnDefs({ type: DEALS_LIST_PAGE });
      this.props.setUpdateColumnsList(true);
    }

    if (hasToResetDefaults && (prevProps.dealsListPage.hasToResetDefaults !== hasToResetDefaults)) {
      this.props.colResetDefault({ type: DEALS_LIST_PAGE, userId: this.props.columnInfo['USERID'].trim() });
    }

    if ((exportFilterProps != prevProps.dealsListPage.exportFilterProps) || (exportFields != prevProps.dealsListPage.exportFields)) {
      this.resetPagePropsAndSendApiCall(filterProps, sortProps, pageProps, true, false, exportFilterProps, exportFields);
    }

    if (searchReplaceValues != prevProps.dealsListPage.searchReplaceValues) {
      this.resetPagePropsAndSendApiCall(filterProps, sortProps, pageProps, true, false, false, false, false, searchReplaceValues);
    }
  }
  closeManageIems = () => {
    this.setState({ isOpenEmbeddedList: false });
  }
  render() {
    const { pageProps, totalCount, deals, isAPIProgress, columnDefs,
      loading, moreRecordsAvailable, updateColumnsList } = this.props.dealsListPage;

    return (
      <div>
        {loading && <Spinner loading type="list" />}

        {!this.props.error && deals && !deals[0] ?
          <ErrorDetail type="no_data" />
          : null}

        {(deals && deals.length && columnDefs.length && !updateColumnsList) ?
          (<div>
            <PaginationGrid
              rowSelection={'single'}
              onRowSelected={(e) => this.onRowSelected()}
              onValueChanged={this.onValueChanged}
              frameworkComponent={frameworkComponent}
              onClickLink={this.onClickLink}
              headerHeight={45}
              props={this.props}
              listPredecessor={getListPredecessor(DEALS_LIST_PAGE)}
              dataKey={DEAL_LIST_PAGE}
              moreRecordsAvailable={moreRecordsAvailable}
              columnKey={COLUMN_VALUE_ACCESSOR}
              titleKey={COLUMN_HEADER_ACCESSOR}
              columnShowFlag={COLUMN_SHOW_HIDE_FLAG}
              prefixFlag={COLUMN_HEADER_PREFIX_FLAG}
              sendApi={this.loadDeals}
              columnData={columnDefs}
              isAPIProgress={isAPIProgress}
              rowData={deals}
              totalCount={totalCount}
              onRowDoubleClicked={this.onRowDoubleClicked}
              pageSizes={PAGE_SIZES}
              pageProps={pageProps}
              onGridReady={this.onGridReady}
			  hasPagination={true}
              isColumnResize={true} />

          </div>) : null}

        <ConfirmationDialog
          hasError={this.state.hasWarning}
          isOpen={this.state.showConfirmationDialog}
          dialogTitle={this.state.dialogTitle}
          submitText={TEXT_OK}
          handleClose={() => this.handleClose(false)}
          handleCancel={() => this.handleClose(false)}
          handleSubmit={() => this.handleClose(true)}>
          <div>
            <FormattedMessageComponent id={this.state.dialogInfoId} />
          </div>
        </ConfirmationDialog>

      </div>
    );
  }
}


DealsList.propTypes = {

};

export default DealsList;
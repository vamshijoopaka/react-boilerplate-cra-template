/**
 *
 * HoldoutProperties
 *
 */

import React from 'react';
import { compose } from 'redux';
import { withRouter } from 'react-router-dom';
import { withStyles } from '@material-ui/core';
import Filter from 'containers/common/Filter';
import FormattedMessageComponent from 'components/common/FormattedMessageComponent';
//Copy and Delete Dialogs import
import CopyDialog from './HoldoutDialogs/CopyDialog'
import DeleteDialog from './HoldoutDialogs/DeleteDialog'

//Utilities import
import {
  getListPredecessor,
  prepareValueDataForHoldouts,
  getUpdateRestrictionOnComponent,
  capitalizeFirstLetter,
  getFilterDataFromLocalStorage,
  getFilterDataFromCriteriaDetails,
} from 'utils/util';

import {
  getDBSelectorFilterValues,
  prepareTooltipValues
} from 'utils/filterData';

import {
  HeaderAPIValuesJSON,
  DEFAULT_VALUE_URL_DATA,
  LABEL_LIST_URL_DATA,
  BRACKET_LABEL_URL_DATA
} from './constants';

import {
  HOLDOUTS_LIST_PAGE,
  HOLDOUT_PROPERTIES_PAGE,
  GLOBAL_FILTER_OPTIONS,
  COLUMN_VALUE_ACCESSOR,
  INITIAL_PAGE_PROPS,
  TEXT_OK, TEXT_ALERT
} from '../common/constants';

import { isEqual } from 'lodash';
import Spinner from '../common/Spinner';
import GridErrorMessages from 'components/common/GridErrorMessages';


import {
  onChangeContextMenu, updateBreadCrumbContextMenu
} from 'utils/contextMenu';
import ConfirmationDialog from 'components/common/ConfirmationDialog';
import HoldoutControlFactors from './HoldoutControlFactors';
import Header from './Header';
import HoldoutNotes from './HoldoutNotes';
import { LABEL_NOTE } from './HoldoutNotes/constants';
import { Badge } from '@material-ui/core';

const style = () => ({
  propertiesContentWrapper: {
    margin: '10px auto',
    fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
    borderRadius: '4px',
    overflow: 'hidden',
    boxShadow: '0 2px 4px var(--secondary-s10)',
    overflowX: 'auto',
  },
  hideContent: {
    display: 'none',
  },
  showContent: {
    display: 'block',
  },
  errorGrid: {
		position: 'fixed',
		top: '3rem',
		left: '33%',
		zIndex: 1200
	},
});

class HoldoutProperties extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      tab: 0,
      isSaveDataDisabled: true,
      headerData: false,
      columnDefs: [],
      stateData: false,
      updatedNotes: false,
      totalCount: 0,
      fromPage: false,
      hasError: false,
      canUpdateComponent: false,
      changeDataAPI: false,
      openFilterPopup: false,
      isFiltersChanged: false,
      previousFilterValues: false,
      showConfirmationDialog: false,
      dialogTitle: '',

      hasWarning: false,
      fromListPage: null,
      prevStateFilterProps: [],
      hasFiltersChanged: false,
      isDataLoaded: false,
      isInitialAPICall: true,
      valueDataFailureMessages: [],
      headerValues: HeaderAPIValuesJSON[0],
      bracketsNotesFilterObj: {},
      notesCount: 0,
    };
  }

  handleNoDataSets = () => {
    const { holdoutControlFactorsLabelsData, copyHoldoutDetailsLabelsData, deleteHoldoutDetailsLabelData } = this.props.HoldoutPropertiesData;
    if (this.state.isDataLoaded) {
      if ((holdoutControlFactorsLabelsData && Object.keys(holdoutControlFactorsLabelsData) &&
        Object.keys(holdoutControlFactorsLabelsData).length) && (Object.keys(copyHoldoutDetailsLabelsData).length &&
          copyHoldoutDetailsLabelsData && copyHoldoutDetailsLabelsData.length) &&
        (Object.keys(deleteHoldoutDetailsLabelData).length &&
          deleteHoldoutDetailsLabelData && deleteHoldoutDetailsLabelData.length)) {
        // do nothing here
      } else {
        this.props.setNoDataCallBackValue(true);
        const paramsString = window.location.search;
        if (paramsString && paramsString.length) {
          const paramsArray = paramsString.split('?');
          if (paramsArray && paramsArray.length && paramsArray.length > 1) {
            const params = paramsArray[1].split('&');
            const tabId = params[0].split('=')[1];
            const breadCrumbId = params[1].split('=')[1];
            this.props.removeCurrentRecordObj(tabId, breadCrumbId);
          }
        }
      }
    }
  }

  handleHoldoutHeaderFilterClick = () => {
    if (this.state.isFiltersChanged &&
      (this.props.HoldoutPropertiesData.isValueDataAPIFailure || this.props.HoldoutPropertiesData?.hasNoPrevNext)) {
      this.props.onSetFilterProps(this.state.previousFilterValues);
      this.props.setGlobalFilterProps(this.state.previousFilterValues);
      this.props.setChildTabFilterProps(this.state.previousFilterValues);
      this.setState({ isFiltersChanged: false });
      this.props.setValueDataAPIFailureFlag(false);
    }
    this.setState({ openFilterPopup: !this.state.openFilterPopup, noRecordForFilter: false });
  }

  getLabelValue = (id) => +id ? <FormattedMessageComponent id={id} /> : id;

  setFilterValuesFromState = (values) => {
    const filterValues = [];
    const { columnDefs } = this.state;
    if (
      (columnDefs && columnDefs.length) ||
      (this.columnDefData && this.columnDefData.length)
    ) {
      const colData = columnDefs && columnDefs.length ? columnDefs : this.columnDefData;
      values.forEach(value => {
        const isExists = colData.find(
          column => column[COLUMN_VALUE_ACCESSOR].trim() == value.accessor,
        );
        if (isExists) {
          filterValues.push(value);
        }
      });
      if (filterValues && filterValues.length) {
        this.props.onSetFilterProps(filterValues);
        this.props.setGlobalFilterProps(filterValues);
        return filterValues;
      }
    } else {
      this.props.onSetFilterProps(values);
      this.props.setGlobalFilterProps(values);
      return values;
    }
  }

  getApiObj = (recordData, record, currentPage, pageProps) => {
    let recordObj = false;
    if (record) {
      recordObj = record;
    }
    const apiObj = {
      recordData,
      pageProps,
      direction: pageProps.isForwardDirection,
      record: recordObj,
      currentPage,
      parentPage: HOLDOUTS_LIST_PAGE,
    };
    return apiObj;
  }

  prepareHeaderDataJSON = (obj) => {
    const headerValues = this.state.headerValues;
    const { vendor, item, warehouse } = this.props.HoldoutPropertiesData;
    const prefixHoldout = getListPredecessor(HOLDOUTS_LIST_PAGE);

    const key = `VNAME`;
    if (vendor && Object.keys(vendor) && Object.keys(vendor).length) {
      const vendorName = vendor[key];
      headerValues.HOVNAME = vendorName ? vendorName.trim() : vendorName;

      const keyVendorSubVendor = `${prefixHoldout}SUBV`;
      const vendorSubVendor = vendorName[keyVendorSubVendor];
      headerValues.HOSUBV = vendorSubVendor ? vendorSubVendor.trim() : vendorSubVendor;
    }

    const keyVendorId = `${prefixHoldout}VNDR`;
    const vendorId = obj[keyVendorId];
    headerValues.HOVNDR = vendorId ? vendorId.trim() : vendorId;

    if (warehouse && Object.keys(warehouse) && Object.keys(warehouse).length) {
      const warehouseName = warehouse["WNAME"];
      headerValues.HOWNAME = warehouseName ? warehouseName.trim() : warehouseName;
    }

    const keyWarehouseId = `${prefixHoldout}WHSE`;
    const warehouseId = obj[keyWarehouseId];
    headerValues.HOWHSE = warehouseId ? warehouseId.trim() : warehouseId;

    if (item && Object.keys(item) && Object.keys(item).length) {
      const itemName = item["INAME"];
      headerValues.HOINAME = itemName ? itemName.trim() : itemName;

      const buyer = item["IBUYR"];
      headerValues.HOBUYR = buyer ? buyer.trim() : buyer;
    }

    const keyItemId = `${prefixHoldout}ITEM`;
    const itemId = obj[keyItemId];
    headerValues.HOITEM = itemId ? itemId.trim() : itemId;

    this.setState({ headerValues: headerValues })
    return [headerValues];
  }

  forceUpdateHandler = () => {
    this.forceUpdate();
  }

  makePrevNextAPICall = flag => {
    const { filterProps, valueData } = this.props.HoldoutPropertiesData;
    const data = JSON.parse(JSON.stringify(INITIAL_PAGE_PROPS));
    data.isForwardDirection = flag;
    data.pageSize = 3;
    this.props.getPageUpDownFlagAPI(
      this.getApiObjForPageUpDownFlags(filterProps, valueData, HOLDOUTS_LIST_PAGE, data, flag)
    );
  };

  prepareTooltipData = () => {
    const { detailCallData, holdoutColumnDefs } = this.props.HoldoutPropertiesData;
    let tooltipData = prepareTooltipValues(HOLDOUTS_LIST_PAGE, detailCallData, holdoutColumnDefs, HOLDOUT_PROPERTIES_PAGE);
    this.props.setDataInTabs("toolTipData", JSON.parse(JSON.stringify(tooltipData)));
  }

  setHeaderAndSendAPI = (jsonData, from) => {
    let data = this.prepareHeaderDataJSON(jsonData);
    this.setState({ headerData: data });
    this.setState({ stateData: jsonData });
    let valueData = prepareValueDataForHoldouts(DEFAULT_VALUE_URL_DATA, jsonData, from);
    this.sendAPICallForValues(valueData, jsonData);
  }

  sendAPICallForValues = (valueData, jsonData) => {
    const { pageProps } = this.props.HoldoutPropertiesData;
    this.props.getValueList(this.getApiObj(valueData, null, HOLDOUT_PROPERTIES_PAGE, pageProps));
    this.checkForExistenceOfVendorItemWarehouse(jsonData)
  }

  handleValueDataErrorMessages = (content) => {
    this.setState({ showValueConfirmationDialog: true });
    this.setState({ dialogTitle: TEXT_ALERT });
    this.setState({ dialogContent: content });
  }

  closeValueDialog = () => {
    this.setState({ showValueConfirmationDialog: false });
    if (this.state.valueDataFailureMessages && this.state.valueDataFailureMessages.length) {
      let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
      values.shift();
      this.setState({ valueDataFailureMessages: values });
    }
  }

  setRecordDataValues = () => {
    let isRecordValuesExists = false, isLocalStorageValuesExists = false, isFilterValuesExists = false;
    const { history } = this.props;
    var paramsString = window.location.search;
    if (paramsString && paramsString.length) {
      let paramsArray = paramsString.split("?");
      if (paramsArray && paramsArray.length && paramsArray.length > 1) {
        let params = paramsArray[1].split("&");
        let tabId = params[0].split("=")[1];
        let breadCrumbId = params[1].split("=")[1];
        let localStorageValues = getFilterDataFromLocalStorage(tabId, breadCrumbId);
        if (localStorageValues && Object.keys(localStorageValues) && Object.keys(localStorageValues).length) {
          isLocalStorageValuesExists = true;
          let itemData = localStorageValues.item_data, dbSelectorValues = [];
          if (itemData && itemData.recordData && localStorageValues.childType) {
            this.columnDefData = JSON.parse(JSON.stringify(itemData.recordData.columnDefs))
            this.setState({ columnDefs: itemData.recordData.columnDefs });
            this.props.setCurrentRecord(itemData.recordData.data);
            this.setState({ totalCount: itemData.recordData.totalCount });
            this.setState({ fromPage: itemData.recordData.fromPage });
            this.setState({ fromListPage: itemData.recordData.fromPage });
            this.setHeaderAndSendAPI(itemData.recordData.data, itemData.recordData.fromPage);
            isRecordValuesExists = true;
            this.props.setSelectedRecord(false, false);
            if (itemData) {
              if (itemData.dbSelector && itemData.dbSelector.length) {
                dbSelectorValues = JSON.parse(JSON.stringify(itemData.dbSelector));
              }
              if (itemData.filterProps && itemData.filterProps.length) {
                this.setState({ hasFiltersChanged: false });
                isFilterValuesExists = true;
                let values = getDBSelectorFilterValues(dbSelectorValues, itemData.filterProps);
                this.setFilterValuesFromState(values);
              } else if (dbSelectorValues && dbSelectorValues.length) {
                this.setState({ hasFiltersChanged: false });
                isFilterValuesExists = true;
                let dbValues = getDBSelectorFilterValues(dbSelectorValues, []);
                this.setFilterValuesFromState(dbValues);
              }
              if (itemData.defaultFilterInfo && Object.keys(itemData.defaultFilterInfo) && Object.keys(itemData.defaultFilterInfo).length) {
                this.props.setDefaultFilterpropsForTabs(itemData.defaultFilterInfo);
              }
            }
          }

        }
        if (!isLocalStorageValuesExists && tabId && breadCrumbId) {
          history.push({ pathname: '/Dashboard' });
        }
      }
    }

    let filterOptions = GLOBAL_FILTER_OPTIONS;
    const { dbSelector } = this.props;
    if (!isFilterValuesExists) {
      let gbValues = getDBSelectorFilterValues(dbSelector, filterOptions);
      this.setFilterValuesFromState(gbValues);
    }
    return isRecordValuesExists;
  }

  resetValues = () => {
    this.props.setInitialState();
    this.props.setValueDataFlag(false);
    this.props.setCurrentRecord(null);
    this.setState({ isDataLoaded: false });
    this.props.getHoldoutsColumnDefs({ type: HOLDOUTS_LIST_PAGE });
  };

  componentDidMount() {
    this.resetValues();
    let currentPage = HOLDOUT_PROPERTIES_PAGE;
    this.props.onLoadCurrentPage(currentPage);
    const { detailCallData } = this.props.HoldoutPropertiesData;
    this.props.setIsShowContextMenu(true);
    let isFound = this.setRecordDataValues();

    if (!isFound) {
      if (this.props.location && this.props.location.state) {
        this.props.setCurrentRecord(this.props.location.state.data);
        this.setState({ columnDefs: this.props.location.state.columnDefs });
        this.setState({ fromPage: this.props.location.state.fromPage });
        this.setHeaderAndSendAPI(this.props.location.state.data, HOLDOUTS_LIST_PAGE);
      }
    }

    if (detailCallData && Object.keys(detailCallData) && Object.keys(detailCallData).length) {
      this.setState({ headerData: this.prepareHeaderDataJSON(detailCallData) });
      this.props.setSelectedRecord(detailCallData, HOLDOUTS_LIST_PAGE);
    }

    let labelFilters = LABEL_LIST_URL_DATA;
    this.props.getLabelsList({ recordData: labelFilters, currentPage: HOLDOUT_PROPERTIES_PAGE });
    this.setState({ isSaveDataDisabled: true });
    let canUpdateComponent = getUpdateRestrictionOnComponent(capitalizeFirstLetter(HOLDOUTS_LIST_PAGE), this.props.authorizedComponentsList);
    this.setState({ canUpdateComponent });
    this.props.getBracketJson({ recordData: BRACKET_LABEL_URL_DATA, currentPage: HOLDOUT_PROPERTIES_PAGE });
  }

  componentDidUpdate(prevProps, prevState) {
    const {
      pageUpDownData,
      isSaveSuccess,
      filterProps,
      isValueDataAPICall,
      holdoutColumnDefs,
      filterCriteriaDetails,
      detailCallData,
      labelsDataFailure,
      commonLabelsDataFailure,
      previousNextFlagAPIFailure,
      isAPIforVendorList,
      isAPIforWarehouseList,
      isAPIforHoldoutUpdate,
      isAPIforHoldoutDelete,
      isAPIforHoldoutColums,
      isCopySuccess,
      isDeleteSuccess,
      isAPIforHoldoutDeleteAll,
      itemNotFoundFlag,
      vendorNotFoundFlag,
      warehouseNotFoundFlag,
      hasNoPrevNext,
      isValueDataAPIFailure,
    } = this.props.HoldoutPropertiesData;

    if (this.state.valueDataFailureMessages && this.state.valueDataFailureMessages.length
      && (JSON.stringify(this.state.valueDataFailureMessages) != JSON.stringify(prevState.valueDataFailureMessages))) {
      this.handleValueDataErrorMessages(this.state.valueDataFailureMessages[0]);
    }

    if (labelsDataFailure && (labelsDataFailure != prevProps.HoldoutPropertiesData.labelsDataFailure)) {
      this.setState({ isDataLoaded: true })
      this.handleNoDataSets();
      this.props.setLabelDataFlags({ key: 'labelsDataFailure', value: false });
    }

    if (isAPIforVendorList && (isAPIforVendorList != prevProps.HoldoutPropertiesData.isAPIforVendorList)) {
      let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
      values.push("Failed to fetch Vendor List");
      this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
      this.props.setLabelDataFlags({ key: 'isAPIforVendorList', value: false });
    }

    if (isAPIforWarehouseList && (isAPIforWarehouseList != prevProps.HoldoutPropertiesData.isAPIforWarehouseList)) {
      let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
      values.push("Failed to fetch Warehouse List");
      this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
      this.props.setLabelDataFlags({ key: 'isAPIforWarehouseList', value: false });
    }

    if (isAPIforHoldoutUpdate && (isAPIforHoldoutUpdate != prevProps.HoldoutPropertiesData.isAPIforHoldoutUpdate)) {
      let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
      values.push("Failed to Update Holdout");
      this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
      this.props.setLabelDataFlags({ key: 'isAPIforHoldoutUpdate', value: false });
    }

    if ((commonLabelsDataFailure && (commonLabelsDataFailure != prevProps.HoldoutPropertiesData.commonLabelsDataFailure))) {
      this.setState({ isDataLoaded: true })
      this.handleNoDataSets();
      this.props.setLabelDataFlags({ key: 'commonLabelsDataFailure', value: false });
    }

    if (previousNextFlagAPIFailure &&
      (previousNextFlagAPIFailure != prevProps.HoldoutPropertiesData.previousNextFlagAPIFailure)) {
      let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
      values.push("Failed to update the previous & next flags data from the server");
      this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
      this.props.setLabelDataFlags({ key: 'previousNextFlagAPIFailure', value: false });
    }

    if (isAPIforHoldoutDelete && (isAPIforHoldoutDelete != prevProps.HoldoutPropertiesData.isAPIforHoldoutDelete)) {
      let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
      values.push("Holdout Delete failed for warehouse.");
      this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
      this.props.setLabelDataFlags({ key: 'isAPIforHoldoutDelete', value: false });
    }

    if (isAPIforHoldoutColums && (isAPIforHoldoutColums != prevProps.HoldoutPropertiesData.isAPIforHoldoutColums)) {
      let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
      values.push("Failed to fetch Holdout Columns");
      this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
      this.props.setLabelDataFlags({ key: 'isAPIforHoldoutColums', value: false });
    }
    if (isCopySuccess && (isCopySuccess != prevProps.HoldoutPropertiesData.isCopySuccess)) {
      let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
      values.push("Holdout Copy completed.");
      this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
      this.props.setLabelDataFlags({ key: 'isCopySuccess', value: false });
    }
    if (isDeleteSuccess && (isDeleteSuccess != prevProps.HoldoutPropertiesData.isDeleteSuccess)) {
      let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
      values.push("Holdout Delete completed.");
      this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
      this.props.setLabelDataFlags({ key: 'isDeleteSuccess', value: false });
    }
    if (isAPIforHoldoutDeleteAll && (isAPIforHoldoutDeleteAll != prevProps.HoldoutPropertiesData.isAPIforHoldoutDeleteAll)) {
      let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
      values.push("Failed to Delete All Holdouts");
      this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
      this.props.setLabelDataFlags({ key: 'isAPIforHoldoutDeleteAll', value: false });
    }
    if (itemNotFoundFlag && (itemNotFoundFlag != prevProps.HoldoutPropertiesData.itemNotFoundFlag)) {
      this.setGridError('11906', [prevState.headerData["HOITEM"]])
      this.props.setLabelDataFlags({ key: 'itemNotFoundFlag', value: true });
    }
    if (vendorNotFoundFlag && (!vendorNotFoundFlag != prevProps.HoldoutPropertiesData.vendorNotFoundFlag)) {
      this.setGridError('11905', [prevState.headerData["HOVNDR"]])
      this.props.setLabelDataFlags({ key: 'vendorNotFoundFlag', value: true });
    }
    if (warehouseNotFoundFlag && (!warehouseNotFoundFlag != prevProps.HoldoutPropertiesData.warehouseNotFoundFlag)) {
      this.setGridError('11908', [prevState.headerData["HOWHSE"]])
      this.props.setLabelDataFlags({ key: 'warehouseNotFoundFlag', value: true });
    }
    if (isValueDataAPIFailure != prevProps.HoldoutPropertiesData.isValueDataAPIFailure && isValueDataAPIFailure) {
      this.setState({ isInitialAPICall: false });
      let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
      values.push("Failed to get the detail data");
      this.setState({ valueDataFailureMessages: values });
      if (this.state.isFiltersChanged) {
        this.setState({ showConfirmationDialog: true });
        this.setState({ hasWarning: true });
        this.setState({ dialogTitle: TEXT_ALERT });
        this.setState({ fromHeaderENG: true });
      }
    }
    if ((JSON.stringify(filterProps) != JSON.stringify(prevProps.HoldoutPropertiesData.filterProps)) && filterProps && filterProps.length) {
      this.setState({ isFiltersChanged: true });
      this.props.setChildTabFilterProps(filterProps);
      this.setStateWSVIds(filterProps);
      if (!this.state.isInitialAPICall) {
        if (this.state.fromPage != HOLDOUTS_LIST_PAGE && !this.state.hasFiltersChanged) {
          this.setHeaderAndSendAPI(this.state.stateData, this.state.fromPage)
        } else {
          this.makeAPICallForPageUpDown('down', {});
        }
      }
    }

    if ((filterCriteriaDetails != prevProps.HoldoutPropertiesData.filterCriteriaDetails)) {
      this.props.setDataInTabs("defaultFilterInfo", JSON.parse(JSON.stringify(filterCriteriaDetails)));
      if (filterCriteriaDetails && Object.keys(filterCriteriaDetails) && Object.keys(filterCriteriaDetails).length && holdoutColumnDefs && holdoutColumnDefs.length) {
        let list = getFilterDataFromCriteriaDetails(filterCriteriaDetails, holdoutColumnDefs, HOLDOUTS_LIST_PAGE);
        if (list && list.length) {
          this.props.setGlobalFilterProps(list);
          this.props.onSetFilterProps(list);
        }
      }
    }

    if (detailCallData && !isEqual(detailCallData, prevProps.HoldoutPropertiesData.detailCallData)) {
      if (Object.keys(detailCallData) && Object.keys(detailCallData).length) {
        if (holdoutColumnDefs && holdoutColumnDefs.length) {
          this.prepareTooltipData();
        }
        this.props.setSelectedRecord(detailCallData, HOLDOUTS_LIST_PAGE);
        this.setState({ headerData: this.prepareHeaderDataJSON(detailCallData) });
      }
    }

    if (holdoutColumnDefs && holdoutColumnDefs.length && !isEqual(holdoutColumnDefs, prevProps.HoldoutPropertiesData.holdoutColumnDefs) &&
      (detailCallData && Object.keys(detailCallData) && Object.keys(detailCallData).length)) {
      if (!this.state.changeDataAPI) {
        this.prepareTooltipData();
      }
    }

    if (isValueDataAPICall != prevProps.HoldoutPropertiesData.isValueDataAPICall && isValueDataAPICall) {
      this.setState({ previousFilterValues: prevProps.HoldoutPropertiesData.filterProps })
      this.setState({ isInitialAPICall: false });
      this.makePrevNextAPICall(true);
      this.props.setValueDataFlag(false);
      if (this.state.isFiltersChanged) {
        this.setState({ openFilterPopup: false });
        this.setStateWSVIds(filterProps);
        this.setState({ isFiltersChanged: false });
      }
    }

    if (this.props.location.search != prevProps.location.search) {
      this.resetValues();
      this.forceUpdateHandler();
      this.setRecordDataValues();
    }

    if (pageUpDownData && JSON.stringify(pageUpDownData) != JSON.stringify(prevProps.HoldoutPropertiesData.pageUpDownData)) {
      this.props.setSelectedRecord(pageUpDownData, HOLDOUTS_LIST_PAGE);
      this.setState({ fromPage: HOLDOUTS_LIST_PAGE });
      this.setHeaderAndSendAPI(pageUpDownData, HOLDOUTS_LIST_PAGE);
      let modifiedData = {
        data: JSON.parse(JSON.stringify(pageUpDownData)),
        fromPage: HOLDOUTS_LIST_PAGE,
        totalCount: this.state.totalCount,
        fromParent: false,
        columnDefs: this.state.columnDefs,
      };
      this.props.setDataInTabs('recordData', modifiedData);
    }

    if (isSaveSuccess && isSaveSuccess !== prevProps.HoldoutPropertiesData.isSaveSuccess) {
      this.setState({ isSaveDataDisabled: true });
    }

    if (prevProps.authorizedComponentsList !== this.props.authorizedComponentsList) {
      const canUpdateComponent = getUpdateRestrictionOnComponent(
        capitalizeFirstLetter(HOLDOUTS_LIST_PAGE),
        this.props.authorizedComponentsList,
      );
      this.setState({ canUpdateComponent });
    }


    if (
      this.props.HoldoutPropertiesData.formattedValues &&
      prevProps.HoldoutPropertiesData.holdoutControlFactorsLabelsData &&
      this.props.HoldoutPropertiesData.holdoutControlFactorsLabelsData
    ) {
      if (
        prevProps.HoldoutPropertiesData.holdoutDetailsLabelsData
          .tabcards !=
        this.props.HoldoutPropertiesData.holdoutDetailsLabelsData.tabcards
      ) {
        this.props.formatHoldoutPropertiesValues(
          this.props.globalNumberFormat,
          this.props.globalNumberSeparator,
          this.props.globalDecimalSeparator,
        );
      }
    }

    if (
      !this.props.HoldoutPropertiesData.formattedValues &&
      this.props.HoldoutPropertiesData.formattedValues !=
      prevProps.HoldoutPropertiesData.formattedValues
    ) {
      this.props.changeFormattedValuesFlag();
    }
    if (hasNoPrevNext && (prevProps.HoldoutPropertiesData.hasNoPrevNext !== hasNoPrevNext)) {
      if (this.state.isFiltersChanged) {
        this.openNoDataPopUp(true)
      }
    }
  }



  onSaveData = () => {
    const { newValueData, valueData, addAndDeleteFlag } = this.props.HoldoutPropertiesData;
    let HOSTAT = 'C';
    if ( ['HOSDAT', 'HOEDAT', 'HOACCT'].some(key => valueData[key] !== newValueData[key])) {
      HOSTAT = 'A';
    }
    const detailValues = {...this.props.HoldoutPropertiesData.newValueData, "HOSTAT": HOSTAT,};
    const holdout = this.props.HoldoutPropertiesData.valueData;
    let filterProps = ['WHSE', 'VNDR', 'ITEM', 'SDAT', 'EDAT', 'ACCT'].map(accessor => ({
      accessor, 'prefixFlag': 0, "operator": "=", "jOpr": "and", "fieldValue": detailValues["HO" + accessor]
    }))

    if (this.onValid(detailValues, holdout)) {
      if (JSON.stringify(newValueData) != JSON.stringify(valueData)) {
        const pageProps = { pageSize: 3 }
        this.props.holdoutDetailsUpdate({newValues: detailValues, oldValues: valueData, deleteFlag: HOSTAT === 'A'});
      }
    }
  }

  getApiObjForPageUpDown = (filterData, record, currentPage, pageProps, pageType) => {
    let recordObj = false
    if (record) {
      recordObj = record;
    }
    let apiObj = {
      filterProps: filterData,
      pageProps: pageProps,
      direction: pageProps.isForwardDirection,
      record: recordObj,
      currentPage: currentPage,
      parentPage: HOLDOUTS_LIST_PAGE,
      pageType: pageType
    };
    return apiObj;
  }

  getApiObjForPageUpDownFlags = (filterData, record, currentPage, pageProps, pageType) => {
    let recordObj = false
    if (record) {
      recordObj = {
        "record": record,
        "flagsOnly": true
      };
    }
    let apiObj = {
      filterProps: filterData,
      pageProps: pageProps,
      direction: pageProps.isForwardDirection,
      record: recordObj,
      currentPage: currentPage,
      parentPage: HOLDOUTS_LIST_PAGE,
      pageType: pageType
    };
    return apiObj;
  }

  makeAPICallForPageUpDown = (type, currentRecordData) => {
    const { filterProps } = this.props.HoldoutPropertiesData;
    let data = JSON.parse(JSON.stringify(INITIAL_PAGE_PROPS));
    if (type == 'up') {
      data.isForwardDirection = false;
    } else {
      data.isForwardDirection = true;
    }
    let filterData = JSON.parse(JSON.stringify(filterProps));
    this.props.pageUpDownAPI(this.getApiObjForPageUpDown(filterData, currentRecordData, HOLDOUTS_LIST_PAGE, data))
  }

  handleHoldoutHeaderLeftArrowClick = () => {
    const { currentRecordData } = this.props.HoldoutPropertiesData;
    this.props.setCurrentType('down');
    this.makeAPICallForPageUpDown('down', currentRecordData);
    this.setState({ isSaveDataDisabled: true });
  }

  handleHoldoutHeaderRightArrowClick = () => {
    const { currentRecordData } = this.props.HoldoutPropertiesData;
    this.props.setCurrentType('up');
    this.makeAPICallForPageUpDown('up', currentRecordData);
    this.setState({ isSaveDataDisabled: true });
  }

  onValid = (newValueData, valueData) => {
    if (newValueData["HOQNTY"] == 0) {
      this.setGridError('12045');
      return false;
    }
      if (newValueData["HOEDAT"] == '0' ||newValueData["HOEDAT"] =="" ) {
        this.setGridError('12046');
        return false;
      }
    if (newValueData["HOSDAT"] > newValueData["HOEDAT"]) {
      this.setGridError('12047');
      return false;
    }
    return true;
  };

  setGridError = (errorId, replaceValues = []) => {
    this.setState({ hasError: true, errorId, replaceValues }, () => {
      setTimeout(() => {
        this.setState({ hasError: false, errorId: false })
      }, 3e3);
    })
  }

  resetError = hasError => this.setState({ hasError, errorId: false, replaceValues: false });

  handleItemSelection = val => {
    const type = val ? val.toLowerCase() : '';
    switch (type) {
      case 'delete':
        this.setState({ deleteDialog: true });
        break;
      case 'copy':
        this.setState({ copyDialog: true });
        break;
    }
    //~~~CreateNewFramework--JVK
    if (val.startsWith('new')) {
      if (val === 'newnote') {
        this.setState({ isOpenNote: true });
        return;
      }
    }
    //~~~CreateNewFramework--JVK
  };
  isActionDisabled = (action) => {
    if (!this.state.canUpdateComponent.update)
      return true;
    else
      return false;
  }
  onContextMenuChange = (e, value, check = false, filters = false, title = false) => {
    let defaultFilters = filters;
    let toPage = value;
    let displayName = title;
    onChangeContextMenu(this.props, e, toPage, defaultFilters, displayName);
    this.props.setSelectedValueForTabs('Show Me');
  }

  handleClose = bodyId => {
    this.setState({ showConfirmationDialog: false });
    switch (bodyId) {
      case 'E14029':
        //need to close the current Tab
        this.closeCurrentTab();
        break;
    }
  }

  closeCurrentTab = () => {
    this.props.setNoDataCallBackValue(true);
    var paramsString = window.location.search;
    if (paramsString && paramsString.length) {
      let paramsArray = paramsString.split("?");
      if (paramsArray && paramsArray.length && paramsArray.length > 1) {
        let params = paramsArray[1].split("&");
        let tabId = params[0].split("=")[1];
        let breadCrumbId = params[1].split("=")[1];
        this.props.removeCurrentRecordObj(tabId, breadCrumbId);
      }
    }
  }

  getValueData = (valueData, newValueData) => {
    if (Object.keys(valueData).length && Object.keys(newValueData).length &&
      (JSON.parse(JSON.stringify(valueData)) !== JSON.parse(JSON.stringify(newValueData)))) {
      return newValueData;
    }
    return valueData;
  }

  checkForExistenceOfVendorItemWarehouse = (data) => {
    let filters = [{ "accessor": "COMP", "operator": "=", "jOpr": "and", "fieldValue": "E3T" }, { "accessor": "VNDR", "operator": "=", "jOpr": "and", "fieldValue": data["HOVNDR"] }];
    this.props.getVendorList(filters);

    filters = [{ "accessor": "COMP", "operator": "=", "jOpr": "and", "fieldValue": "E3T" }, { "accessor": "ITEM", "operator": "=", "jOpr": "and", "fieldValue": data["HOITEM"] }];
    this.props.getItemsList(filters);

    filters = [{ "accessor": "COMP", "operator": "=", "jOpr": "and", "fieldValue": "E3T" }, { "accessor": "WHSE", "operator": "=", "jOpr": "and", "fieldValue": data["HOWHSE"] }];
    this.props.getWarehouseList(filters);

  }

  handleCopyDeletePopup = (popup, val) => {
    const type = popup ? popup.toLowerCase() : '';
    switch (type) {
      case 'delete':
        this.setState({ deleteDialog: val });
        break;
      case 'copy':
        this.setState({ copyDialog: val });
        break;
    }
  }
  setStateWSVIds = (filterProps) => {
    let obj = JSON.parse(JSON.stringify(this.state.bracketsNotesFilterObj));
    for (let i = 0; i < filterProps.length; i++) {
      if (filterProps[i].accessor == 'WHSE') {
        obj["warehouseId"] = filterProps[i].fieldValue;
      } else if (filterProps[i].accessor == 'ITEM') {
        obj["itemId"] = filterProps[i].fieldValue;
      } else if (filterProps[i].accessor == 'SDAT') {
        obj["shipDt"] = filterProps[i].fieldValue;
      } else if (filterProps[i].accessor == 'CSID') {
        obj["custId"] = filterProps[i].fieldValue;
      }
    }
    this.setState({ bracketsNotesFilterObj: JSON.parse(JSON.stringify(obj)) });

  }
  updatedNotesData = () => {
    this.setState({ updatedNotes: true });
  }
  //holdout_notes get Notes count
  setNotesCount=(count) =>{
    if (this.state.notesCount != count)
      this.setState({ notesCount: count })
  }
  openNoDataPopUp = (val) => {
    this.setState({ showConfirmationDialog: val });
    this.setState({ hasWarning: val });
    this.setState({ dialogTitle: val ? TEXT_ALERT : '' });
    this.setState({ fromHeaderENG: val });
    this.setState({ dialogBody: val ? 'E28648' : '' });
    this.setState({ noRecordForFilter: true })
  }
  render() {
    const {
      classes,
      globalDateFormat,
      filterCriteriaDetails,
      pageFilterOptions,
      globalFilterOptions
    } = this.props;

    const { deleteDialog, copyDialog } = this.state;

    const {
      currentRecordData,
      loading,
      holdoutDetailsLabelsData: { tabcards = false } = {},
      hasNext,
      hasPrevious,
      holdoutColumnDefs,
      vendor, item, warehouse,
      copyHoldoutDetailsLabelsData,
      valueData,
      newValueData,
      ApiCallCount,
      bracketLabelJson
    } = this.props.HoldoutPropertiesData;

    const hideLoader = !loading && tabcards && tabcards.length && !ApiCallCount;
    const names = {
      'HOINAME': (item?.INAME || ""),
      'HOVNAME': (vendor?.VNAME || ""),
      'HOWNAME': (warehouse?.WNAME || ""),
    }
    let contextMenu=updateBreadCrumbContextMenu(this.props) || [];
    return (
      <div>
        {this.state.hasError && this.state.errorId ? (
          <div className={classes.errorGrid}>
            <GridErrorMessages
              errorMessageLabels={this.props.errorMessageLabels}
              popUp
              sethaserror={this.resetError}
              id={this.state.errorId}
              replaceValues={this.state.replaceValues || false}
            />
          </div>
        ) : null}
        {
          tabcards &&
            tabcards.length &&
            this.state.fromPage ? (
              <div >
                <Header
                  contextMenu={contextMenu}
                  fromListPage={this.state.fromListPage}
                  onContextMenuChange={this.onContextMenuChange}
                  HoldoutPropertiesData={this.props.HoldoutPropertiesData}
                  handleHoldoutHeaderFilterClick={
                    this.handleHoldoutHeaderFilterClick
                  }
                  hasNext={hasNext}
                  hasPrevious={hasPrevious}
                  holdoutData={this.state.headerData?.[0] || {}}
                  currentRecordData={currentRecordData}
                  handleHoldoutHeaderSaveClick={() => this.onSaveData()}
                  handleHoldoutHeaderLeftArrowClick={
                    this.handleHoldoutHeaderLeftArrowClick
                  }
                  handleHoldoutHeaderRightArrowClick={
                    this.handleHoldoutHeaderRightArrowClick
                  }
                  saveDisabled={this.state.isSaveDataDisabled}
                  setSaveData={val => { this.setState({ isSaveDataDisabled: !val }); }}
                  currentPage={HOLDOUTS_LIST_PAGE}
                  handleHoldoutHeaderActionItemSelection={this.handleItemSelection}
                  canUpdateComponent={this.state.canUpdateComponent}
                  names={names}
                  systemDate={this.props.companyDetails?.CJDATE || false}
                  selectedValue={this.props.selectedValue}
                  removeChildCutdownTab={this.props.removeChildCutdownTab}
                  isActionDisabled={this.isActionDisabled}
                />

                {deleteDialog && (
                  <DeleteDialog
                    openDeletePopup={deleteDialog}
                    handleCopyDeletePopup={this.handleCopyDeletePopup}
                    deleteLabels={copyHoldoutDetailsLabelsData}
                    onSubmit={this.props.holdoutDetailsDelete}
                    onDeleteAll={this.props.holdoutDetailsDeleteAll}
                    headerJson={{ ...this.state.headerValues, ...vendor, ...item, ...warehouse, ...currentRecordData }}
                    holdoutDetailData={{...valueData, ...names}}
                    currentOwnerName={this.props.currentOwnerName}
                    globalDateFormat={globalDateFormat}
                    filterCriteriaDetails={filterCriteriaDetails}
                    pageFilterOptions={pageFilterOptions}
                    globalFilterOptions={globalFilterOptions}
                    columnDefs={this.state.columnDefs}
                    currentPage={HOLDOUTS_LIST_PAGE}
                    canUpdateComponent={this.state.canUpdateComponent}
                  />
                )}
                {copyDialog && (
                  <CopyDialog
                    openCopyPopup={copyDialog}
                    handleCopyDeletePopup={this.handleCopyDeletePopup}
                    onSubmit={this.props.holdoutDetailsCopy}
                    onCopyAll={this.props.holdoutDetailsCopyAll}
                    copyLabels={copyHoldoutDetailsLabelsData}
                    headerJson={{ ...this.state.headerValues, ...vendor, ...item, ...warehouse, ...currentRecordData }}
                    holdoutDetailData={{...valueData, ...names}}
                    currentOwnerName={this.props.currentOwnerName}
                    globalDateFormat={globalDateFormat}
                    filterCriteriaDetails={filterCriteriaDetails}
                    pageFilterOptions={pageFilterOptions}
                    globalFilterOptions={globalFilterOptions}
                    columnDefs={this.state.columnDefs}
                    currentPage={HOLDOUTS_LIST_PAGE}
                    canUpdateComponent={this.state.canUpdateComponent}
                  />
                )}

                <HoldoutControlFactors
                  HoldoutPropertiesData={this.props.HoldoutPropertiesData}
                  holdData={currentRecordData}
                  setValueData={this.props.setValueData}
                  setSaveData={val => this.setState({ isSaveDataDisabled: !val })}
                  globalDateFormat={globalDateFormat}
                  pageFilterOptions={pageFilterOptions}
                  globalFilterOptions={globalFilterOptions}
                  columnDefs={this.state.columnDefs}
                  currentPage={HOLDOUTS_LIST_PAGE}
                  canUpdateComponent={this.state.canUpdateComponent}
                />
                <div id="holdoutNotes"><HoldoutNotes currentPage={HOLDOUTS_LIST_PAGE}
                  noteLabelJson={bracketLabelJson}
                  bracketsNotesFilterObj={this.state.bracketsNotesFilterObj}
                  fromPage={HOLDOUTS_LIST_PAGE}
                  currentRecordData={valueData}
                  updatedNotesData={this.updatedNotesData}
                  canUpdateComponent={this.state.canUpdateComponent}
                  columnDefs={this.state.columnDefs}
                  setNotesCount={this.setNotesCount}
                  notesCount={this.state.notesCount}
                  isOpenNote={this.state.isOpenNote}
                  closeNote={(flag) => this.setState({ isOpenNote: flag })}
                ></HoldoutNotes>
                </div>
              </div>
            ) : null}
        {!hideLoader ? <Spinner loading type="list" /> : null}

        {this.state.openFilterPopup && (
          <Filter
            filterCriteriaDetails={this.props.filterCriteriaDetails}
            pageFilterOptions={this.props.pageFilterOptions}
            globalFilterOptions={this.props.globalFilterOptions}
            globalSecurityFilterList={this.props.globalSecurityFilterList}
            currentPage={HOLDOUT_PROPERTIES_PAGE}
            isOpen={Boolean(this.state.openFilterPopup)}
            ownerName={this.props.currentOwnerName}
            columnDefs={holdoutColumnDefs}
            clearPopupComponent={this.handleHoldoutHeaderFilterClick}
            hasRecordsForFilter={!this.state.noRecordForFilter}
            showNoDataPopUp={(val) => this.openNoDataPopUp(val)}
          />
        )}
        {this.state.showConfirmationDialog && <ConfirmationDialog
          hasError={this.state.hasWarning}
          isOpen={this.state.showConfirmationDialog}
          dialogTitle={this.state.dialogTitle}
          submitText={TEXT_OK}
          handleClose={e => this.handleClose(false)}
          handleCancel={e => this.handleClose(false)}
          handleSubmit={e => this.handleClose(this.state.dialogBody)}
        >
          <div>
            {this.state.fromHeaderENG && <FormattedMessageComponent id="28648" />}
            {this.props.errorMessageLabels && this.props.errorMessageLabels[this.state.dialogBody] &&
              this.props.errorMessageLabels[this.state.dialogBody].MTEXT || ''}
          </div>
        </ConfirmationDialog>
        }
        {this.state.showValueConfirmationDialog && hideLoader && <ConfirmationDialog
          hasError={this.state.hasWarning}
          isOpen={this.state.showValueConfirmationDialog}
          dialogTitle={this.state.dialogTitle}
          submitText={TEXT_OK}
          handleClose={() => this.closeValueDialog(false)}
          handleCancel={() => this.closeValueDialog(false)}
          handleSubmit={() => this.closeValueDialog(this.state.dialogBody)}
        >
          <div>
            {this.state.dialogContent}
          </div>
        </ConfirmationDialog>
        }
      </div>
    );
  }
}

HoldoutProperties.propTypes = {};

export default compose(
  withRouter,
  withStyles(style),
)(HoldoutProperties);

import { fromJS } from 'immutable';
import {
  INITIAL_PAGE_PROPS,
  COLUMN_POSITION,
  COLUMN_FIELD_TYPE,
  DROPDOWN_FIELD,
} from 'components/common/constants';
import {
  GET_COLUMN_DEFS,
  GET_COLUMN_DEFS_SUCCESS,
  GET_COLUMN_DEFS_ERROR,
  SET_API_CALL_COUNT,
  SET_PAGEPROPS,
  GET_WAREHOUSE_LIST,
  GET_WAREHOUSE_LIST_SUCCESS,
  GET_WAREHOUSE_LIST_FAILURE,
  GET_ITEMS_LIST,
  GET_ITEMS_LIST_SUCCESS,
  GET_ITEMS_LIST_FAILURE,
  GET_VENDOR_LIST,
  GET_VENDOR_LIST_SUCCESS,
  GET_VENDOR_LIST_FAILURE,
  RESET_DEFAULTS,
  RESET_DEFAULTS_SUCCESS,
  RESET_DEFAULTS_FAILURE,
  SET_COLUMN_DEFS_LOADED,
  REMOVE_RECORD,
  UPDATE_VALUE_ON_EDIT,
  ADD_RECORD,
  UPDATE_SHOW_HIDE_COLUMNS,
  UPDATE_SHOW_HIDE_COLUMNS_SUCCESS,
  UPDATE_SHOW_HIDE_COLUMNS_FAILURE,
  LABEL_DATA_FLAGS,
  GET_HOLDOUTS_LIST,
  GET_HOLDOUTS_LIST_SUCCESS,
  GET_HOLDOUTS_LIST_FAILURE,
  RESET_DATA,
  PLANS_RECALC,
  PLANS_RECALC_ERROR,
  PLANS_RECALC_SUCCESS,
  SET_ERROR,
  PLANS_UPDATE,
PLANS_UPDATE_SUCCESS,
PLANS_UPDATE_ERROR,
} from './constants';

import {
  getSortableColumns,
} from '../../../utils/util';
import { stubFalse } from 'lodash';

const initialState = fromJS({
  columnDefs: false,
  columnInfo: false,
  isColumnDefsLoaded: false,
  rowData: [],
  loading: true,
  pageProps: INITIAL_PAGE_PROPS,
  totalCount: 0,
  apiCallCount: 0,
  updateColumnsList: false,
  removeRecordFlag: false,
  updateRecords: false,
  error: false,
  isAPIforEmbeddedListLabels: false,
  isAPIforEmbeddedListupdate: false,
  isAPIforEmbeddedListReset: false,
  isAPIforVendorList: false,
  isAPIforItemList: false,
  isAPIforWarehouseList: false,
  holdoutsRowData: [],
  isExistinHoldoutsListFlag: false,
  isAPIforHoldoutList: false,
  recalcValues: false,
  recalSuccess:false
});

function detailDialogReducer(state = initialState, action) {
  switch (action.type) {
    case RESET_DATA:
      return initialState;
    case ADD_RECORD:
      const temp = state.get('holdoutsRowData');
      let array = [];
      if (temp !== false) array = [...temp];
      if (action.detail) {
        const rI = action.rowIndex;
        array[rI] = action.data;
        return state
          .set('loading', false)
          .set('holdoutsRowData', array)
          .set('totalCount', array.length);
      }

      if (Array.isArray(action.data)) {
        array = [...array, ...action.data];
      } else array.push(action.data);
      return state
        .set('loading', false)
        .set('holdoutsRowData', array)
        .set('totalCount', array.length);

    case GET_COLUMN_DEFS:
      return state
        .set('loading', true)
        .set('isAPIforEmbeddedListLabels', false);

    case GET_COLUMN_DEFS_SUCCESS:
      if (action.data && action.data.fields && action.data.fields.length) {
        let colFields = [];
        action.data.fields.filter(column => {
          if (column.FDFILD == '3076' || column.FDFILD == '3001' || column.FDFILD == '3003') {
            colFields.push(column);
          }
        })
        const columnFields = colFields.filter(
          col => Object.keys(col).length,
        );
        const list = getSortableColumns(
          columnFields,
          COLUMN_POSITION,
          COLUMN_FIELD_TYPE,
          DROPDOWN_FIELD,
          true,
          false,
          true,
        );
        list[2].dataType = 'text';
        return state
          .set('loading', false)
          .set('isColumnDefsLoaded', true)
          .set('updateColumnsList', false)
          .set('columnInfo', action.data.info)
          .set('columnDefs', list);
      }
      return state
        .set('columnDefs', [])
        .set('loading', false)
        .set('columnInfo', false)
        .set('isColumnDefsLoaded', true);
    case GET_COLUMN_DEFS_ERROR:
      return state
        .set('loading', false)
        .set('isAPIforEmbeddedListLabels', true);

    case UPDATE_SHOW_HIDE_COLUMNS:
      return state.set('loading', true);
    case UPDATE_SHOW_HIDE_COLUMNS_SUCCESS:
      const { data } = action;
      if (
        data.message &&
        data.message.length &&
        data.message.toLowerCase() == 'success'
      ) {
        return state
          .set('updateColumnsList', true)
          .set('loading', true)
          .set('columnDefs', []);
      }
      return state;
    case UPDATE_SHOW_HIDE_COLUMNS_FAILURE:
      return state.set('loading', false).set('error', action.error);

    case RESET_DEFAULTS:
      return state.set('loading', true).set('isAPIforEmbeddedListReset', false);
    case RESET_DEFAULTS_SUCCESS:
      if (action.data && action.data.fields && action.data.fields.length) {
        const columnFields = action.data.fields.filter(
          col => Object.keys(col).length,
        );
        const list = getSortableColumns(
          columnFields,
          COLUMN_POSITION,
          COLUMN_FIELD_TYPE,
          DROPDOWN_FIELD,
          true,
          false,
          true,
        );
        return state
          .set('loading', false)
          .set('isColumnDefsLoaded', true)
          .set('updateColumnsList', false)
          .set('columnInfo', action.data.info)
          .set('columnDefs', list);
      }
    case RESET_DEFAULTS_FAILURE:
      return state
        .set('loading', false)
        .set('error', error)
        .set('isAPIforEmbeddedListReset', true);

    case SET_PAGEPROPS:
      return state.set('pageProps', action.data);
    case SET_API_CALL_COUNT: // doubt
      return state.set('apiCallCount', action.data);

    case SET_COLUMN_DEFS_LOADED:
      return state.set('isColumnDefsLoaded', action.data);

    case UPDATE_VALUE_ON_EDIT:
      const rowDataValues = state.get('rowData');
      rowDataValues[action.data.rowIndex] = action.data.data;
      return state.set('rowData', rowDataValues);

    case REMOVE_RECORD:
      const { rowIndex } = action.data;
      const rowData = state.get('holdoutsRowData');
      const rowDataAfterRemoval = rowData.filter(x => x !== rowData[rowIndex]);
      return state.set('holdoutsRowData', rowDataAfterRemoval);

    case GET_VENDOR_LIST:
      return state
        .set('loading', true)
        .set('isExistinVendorsListFlag', false)
        .set('isAPIforVendorList', false);
    case GET_VENDOR_LIST_SUCCESS:
      if (
        action &&
        action.data &&
        action.data.listArray &&
        action.data.listArray.length
      ) {
        return state
          .set('loading', false)
          .set('isExistinVendorsListFlag', true);
      }
      return state.set('loading', false);
    case GET_VENDOR_LIST_FAILURE:
      return state
        .set('loading', false)
        .set('isExistinVendorsListFlag', false)
        .set('isAPIforVendorList', true);

    case GET_ITEMS_LIST:
      return state
        .set('loading', true)
        .set('isExistinItemListFlag', false)
        .set('isAPIforItemList', false);
    case GET_ITEMS_LIST_SUCCESS:
      if (
        action &&
        action.data &&
        action.data.listArray &&
        action.data.listArray.length
      ) {
        return state.set('loading', false).set('isExistinItemListFlag', true);
      }
      return state.set('loading', false);
    case GET_ITEMS_LIST_FAILURE:
      return state
        .set('loading', false)
        .set('isExistinItemListFlag', false)
        .set('isAPIforItemList', true);

    case GET_WAREHOUSE_LIST:
      return state
        .set('loading', true)
        .set('isExistinWarehouseListFlag', false)
        .set('isAPIforWarehouseList', false);
    case GET_WAREHOUSE_LIST_SUCCESS:
      if (
        action &&
        action.data &&
        action.data.listArray &&
        action.data.listArray.length
      ) {
        return state
          .set('loading', false)
          .set('isExistinWarehouseListFlag', true)
          .set('warehouse', action.data.listArray[0].WWNAME);
      }
      return state.set('loading', false);
    case GET_WAREHOUSE_LIST_FAILURE:
      return state
        .set('loading', false)
        .set('isExistinWarehouseListFlag', false)
        .set('isAPIforWarehouseList', true);
    case GET_HOLDOUTS_LIST:
      return state
        .set('loading', true)
        .set('isExistinHoldoutsListFlag', false)
        .set('isAPIforHoldoutList', false)
        .set('holdoutsRowData', []);
    case GET_HOLDOUTS_LIST_SUCCESS:
      // let values = {}, data = action.data;
      if (
        action &&
        action.data &&
        action.data.listArray &&
        action.data.listArray.length
      ) {
        return state
          .set('loading', false)
          .set('isExistinHoldoutsListFlag', true)
          .set('holdoutsRowData', action.data.listArray);
      }
      return state.set('loading', false);
    case GET_HOLDOUTS_LIST_FAILURE:
      return state
        .set('loading', false)
        .set('isExistinHoldoutsListFlag', false)
        .set('isAPIforHoldoutList', true)
        .set('holdoutsRowData', []);

    case LABEL_DATA_FLAGS:
      return state.set(action.data.key, action.data.value);

    case PLANS_RECALC:
      return state.set('loading', true).set('isAPIforPlansRecalc', false).set('recalSuccess',false);

    case PLANS_RECALC_SUCCESS:
      if (action && action.data) {
        return state
          .set('loading', false)
          .set('isAPIforPlansRecalc', false)
          .set('recalSuccess',true)
          .set('recalcValues', action.data);
      }
      return state.set('loading', false).set('errorId', '10848');
    case PLANS_RECALC_ERROR:
      return state
        .set('updated', false)
        .set('loading', false)
        .set('isAPIforPlansRecalc', true)
        .set('recalSuccess',false)
        .set('errorId', '10849');
    case SET_ERROR:
      return state.set('errorId', action.error);

      case PLANS_UPDATE:
        return state.set('isSaveSuccess', false)
          .set('loading', true).set('isAPIforPlanUpdate', false)
  
  
      case PLANS_UPDATE_SUCCESS:
        const valueDatax = state.get('valueData')
        const newValueDatax = state.get('newValueData')
        return state.set('isSaveSuccess', action.data === 'success')
          .set('updatedflag', true)
          .set('valueData', valueDatax)
          .set('newValueData', newValueDatax)
          .set('loading', false)
          .set('isAPIforPlanUpdate', false)
      case PLANS_UPDATE_ERROR:
        return state.set('isSaveSuccess', false)
          .set('updated', false)
          .set('loading', false)
          .set('isAPIforPlanUpdate', true)
    default:
      return state;
  }
}

export default detailDialogReducer;

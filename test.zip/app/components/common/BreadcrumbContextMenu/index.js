import React from 'react';
import Form from 'components/common/Form/Form';
import FieldInput from 'components/common/Form/FieldInput';
import FormattedMessageComponent from '../FormattedMessageComponent';

const BreadcrumbContextMenu = (props) => {
  const { menuItems, onOptionChange } = props;
  return (
    <div className='show-me-context'>
      {(menuItems && menuItems.length) ?
        <Form>
          {form => (
            <FieldInput
              value={props.selectedValue || 'Show Me'}
              field={{
                placeholder:props.noPlaceHolder?'':'Show Me', // <FormattedMessageComponent id="25376"></FormattedMessageComponent>, // 'Show Me',  Fix for E3C-32877
                type: 'select',
                key: 'contextMenu',
                options: menuItems,
              }}
              onKeyDown={() => { }}
              onChange={(key, val, e) => {
                onOptionChange(e, val);
              }}
            />
          )}
        </Form>
        : null}
    </div>
    // <select value={props.selectedValue} onChange={(e) => onOptionChange(e)}>
    //   <option default>Please select option</option>
    //   {(menuItems && menuItems.length) ? menuItems.map((menuItem, index) => {
    //     return (
    //       <option
    //         key={index}
    //         value={menuItem.id}
    //         id={menuItem.id}
    //         name={menuItem.name}
    //       >
    //         {menuItem.name}
    //       </option>
    //     );
    //   }) : null}
    // </select>
  );
};

export default BreadcrumbContextMenu;

/*
* * //==========================================================================
*
* * // Copyright 2021-2021, Blue Yonder Group, Inc.
*
* * // All Rights Reserved
*
* * //
*
* * // THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF
*
* * // BLUE YONDER GROUP, INC.
*
* * //
*
* * //
*
* * // The copyright notice above does not evidence any actual
*
* * // or intended publication of such source code.
*
* * //
*
* * // ===========================================================================
*/
export const DATE = 'date';
export const FILE = 'file';
export const NUMBER = 'number';
export const LABELS = 'labels';
export const PASSWORD = 'password';
export const RADIO = 'radio';
export const SELECT = 'select';
export const TEXT = 'text';
export const CHECKBOX = 'checkbox';
export const AUTOCOMPLETE = 'autocomplete';
export const TEXTAREA = 'textarea';

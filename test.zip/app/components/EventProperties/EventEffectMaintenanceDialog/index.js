import React from 'react';
import GridErrorMessages from 'components/common/GridErrorMessages';
import FormattedMessageComponent from 'components/common/FormattedMessageComponent';
import { withStyles, Box } from '@material-ui/core';


import {
    effectMaintenanceFlexibleDS,
    effectMaintenanceBody,
    CARDKEY_EVENT_EFFECT_MAINTENANCE_HEADER,
    CARDKEY_EVENT_EFFECT_MAINTENANCE,
    CARDKEY_EVENT_SELECTION,
    CARDKEY_ITEM_SELECTION,
} from './constants';

import {
    getListPredecessor, getDateFormatValue,
} from 'utils/util';
import DateRenderer from 'components/CustomGrid/DateRenderer';
import DialogComponent from 'components/common/DialogComponent';
import FormFieldsGenerator from 'components/common/FormFieldsGenerator';
import theme from 'jda-gcp-theme';
import FieldInput from 'components/common/Form/FieldInput';
import './styles.scss';
import Header from './header';


const frameworkComponent = {
    'dateRenderer': DateRenderer
};

const style = theme => ({
    pageContainer: {
        display: 'flex',
        borderTop: 'none',
        padding: '10px 20px',
    },
    pageContainerSeventy: {
        width: '70%',
    },
    pageContainerThirty: {
        width: '30%',
        display: 'flex',
        flexDirection: 'column',
        marginLeft: '20px',
    },
    cardWithborder: {
        borderRadius: '4px',
        width: '100%',
        backgroundColor: 'var(--secondary-s5)',
    },
    card: {
        padding: '0px',
        backgroundColor: 'var(--background-content)',
        borderRadius: '4px',
        width: '100%',
        margin: '10px',
        '& .MuiCardHeader-root': {
            padding: '22px 20px 0 20px'
        },
        '& .MuiCardContent-root': {
            padding: '16px 15px 10px 15px'
        }
    },
    cardName: {
        fontWeight: '500',
        margin: '10px 0 20px 5px',
    },
    simpleCardGroup: {
        width: '100%',
        display: 'flex',
        justifyContent: 'space-around',
    },
    dashedBottomBorder: {
        borderBottom: '1px dashed var(--secondary-s21)',
        marginBottom: '20px',
    },
    marginLeftZero: {
        marginLeft: '0',
    },
    marginRightZero: {
        marginRight: '0',
    },
    customCardWrapper: {
        display: 'grid',
        gridTemplateColumns: '50% 50%'
    },
    marketReplenish: {
        '& .MuiCardContent-root': {
            paddingBottom: '40px'
        }
    },
    widht100: {
        width: '100%'
    },
    notesForBlock: {
        display: 'flex',
        flexDirection: 'column',
        border: '1px solid var(--divider-line)',
        padding: '10px 10px 0 10px',
        position: 'relative',
        width: '100%'
    },
    notesForLabel: {
        position: 'absolute',
        top: '-7px',
        left: '10px',
        background: 'var(--background-content)',
        padding: '0 8px',
    },
    padding5: {
        padding: "10px 10px 0 15px"
    },
    whseInput: {
        width: '9rem',
        '& > div': {
            marginRight: '0.75rem'
        }
    },
    whseButton: {
        position: "relative",
        top: 101,
        left: "36rem",
        zIndex: 10
    },
    whseBox: {
        justifyContent: 'space-between',
        width: '87%',
        position: 'absolute',
        padding: '20px 0px 0px 20px'
    },
    adjustCardFieldsInline: {
        display: 'grid !important',
        width: '100%',
        gridTemplateColumns: 'auto auto',
    },
    adjustShowDetail: {
        display: 'flex',
        bottom: '10px',
        left: '22px',
        position: 'fixed'
    },
    submitJob: {
        paddingTop: '10px',
    }

})

class EventEffectMaintenanceDialog extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            effectMaintenanceData: { ...effectMaintenanceFlexibleDS },
            tabcards: [...this.props.eventEffectMaintenanceLabelsData.tabcards],
            headerData: { ...this.props.headerJson },

            hasError: false,
            ServerError: false,
            showConfirmationDialog: false,
            dialogTitle: '',
            valueDataFailureMessages: [],


        };
        this.handleChangeValue = this.handleChangeValue.bind(this);
        this.enableDisableFields = this.enableDisableFields.bind(this);
        this.clearEventSelection = this.clearEventSelection.bind(this);

    }

    componentDidMount() {
        this.enableDisableFields();
    }


    componentDidUpdate = (prevProps, prevState) => {
        if (this.state.effectMaintenanceData && (JSON.stringify(this.state.effectMaintenanceData) != JSON.stringify(prevState.effectMaintenanceData))) {
            if (this.state.effectMaintenanceData.EVTSEL !== prevState.effectMaintenanceData.EVTSEL) {
                this.clearEventSelection();
                this.enableDisableFields();
            }
        }
    }


    enableDisableFields = () => {
        let { tabcards } = this.state;
        tabcards.forEach((card, cardIndex) => {
            if (card.cardkey === CARDKEY_EVENT_SELECTION) {
                card.cardfields.forEach((field, fieldIndex) => {
                    tabcards[cardIndex].cardfields[fieldIndex].disabled = this.state.effectMaintenanceData.EVTSEL === 'C' ? true : false;
                });
            }
        });
        this.setState({ tabcards });
    }

    clearEventSelection = () => {
        let { effectMaintenanceData } = this.state;
        effectMaintenanceData.EHGRP1 = "";
        effectMaintenanceData.EHGRP2 = "";
        effectMaintenanceData.EHGRP3 = "";
        effectMaintenanceData.EHGRP4 = "";
        effectMaintenanceData.EHGRP5 = "";
        effectMaintenanceData.EHGRP6 = "";
        this.setState({ effectMaintenanceData });
    }


    handleClose = () => {
        this.props.closeDialog('copyVendor');
    };


    handleChangeValue(key, val, field) {
        let prefix = getListPredecessor(this.props.currentPage);
        let keyPrefix = !field.prefixFlag ? prefix + field.FDFNAM : field.FDFNAM;
        if (field.dataType === "select" && !val && val != "0") return;
        this.setState({
            effectMaintenanceData: { ...this.state.effectMaintenanceData, [keyPrefix.trim()]: val }
        });
    }


    handleEventEffectMaintenance = () => {
        if (this.errorValidation()) {
            this.prepareEventEffectMaintenanceBody();
            this.props.eventEffectMaintenance(effectMaintenanceBody);
            this.props.closeDialog();
        }
    }


    errorValidation = () => {
        const { effectMaintenanceData } = this.state;

        if (effectMaintenanceData.EHECHG === "" || effectMaintenanceData.EHEACT === "" || effectMaintenanceData.EHPTYP === "" || effectMaintenanceData.EHECHG < 0) {
            this.setState({ hasError: true });
            this.setState({ errorId: '19706' });
            return false;
        }

        if (effectMaintenanceData.EHSDAT !== "" && effectMaintenanceData.EHSDAT < this.props.systemDate) {
            this.setState({ hasError: true });
            this.setState({ errorId: '19704' });
            return false;
        }

        if (effectMaintenanceData.EHEDAT !== "" && effectMaintenanceData.EHEDAT < this.props.systemDate) {
            this.setState({ hasError: true });
            this.setState({ errorId: '19713' });
            return false;
        }

        if (effectMaintenanceData.EHSDAT !== "" && effectMaintenanceData.EHEDAT !== "" && effectMaintenanceData.EHSDAT > effectMaintenanceData.EHEDAT) {
            this.setState({ hasError: true });
            this.setState({ errorId: '19703' });
            return false;
        }

        if ((effectMaintenanceData.EHSDAT !== "" && effectMaintenanceData.EHSDAT < this.props.headerJson.EHBGDT) ||
            (effectMaintenanceData.EHEDAT !== "" && effectMaintenanceData.EHEDAT > this.props.headerJson.EHENDT)) {
            this.setState({ hasError: true });
            this.setState({ errorId: '19712' });
            return false;
        }

        return true;
    };

    sethaserror = val => {
        this.setState({ hasError: val });
    };

    prepareEventEffectMaintenanceBody = () => {

        const { effectMaintenanceData } = this.state;
        const { headerData } = this.state;
        effectMaintenanceBody.WCOMP = headerData.EHCOMP;
        effectMaintenanceBody.WHEVNT = headerData.EHEVNT;
        effectMaintenanceBody.WEFFCT = effectMaintenanceData.EHECHG;
        effectMaintenanceBody.WIDR = effectMaintenanceData.EHEACT;
        effectMaintenanceBody.WPTYP = effectMaintenanceData.EHPTYP;
        effectMaintenanceBody.WEGRP1 = effectMaintenanceData.EHGRP1;
        effectMaintenanceBody.WEGRP2 = effectMaintenanceData.EHGRP2;
        effectMaintenanceBody.WEGRP3 = effectMaintenanceData.EHGRP3;
        effectMaintenanceBody.WEGRP4 = effectMaintenanceData.EHGRP4;
        effectMaintenanceBody.WEGRP5 = effectMaintenanceData.EHGRP5;
        effectMaintenanceBody.WEGRP6 = effectMaintenanceData.EHGRP6;
        effectMaintenanceBody.WHSID = effectMaintenanceData.EHWHSE;
        effectMaintenanceBody.RGNID = effectMaintenanceData.EHREGN;
        effectMaintenanceBody.VNDID = effectMaintenanceData.EHVNDR;
        effectMaintenanceBody.ITYPE = effectMaintenanceData.EITYPE;
        effectMaintenanceBody.IRELE = effectMaintenanceData.EHRELE;
        effectMaintenanceBody.IPRFL = effectMaintenanceData.EHMPRF;
        effectMaintenanceBody.WIGRP1 = effectMaintenanceData.EIGRP1;
        effectMaintenanceBody.WIGRP2 = effectMaintenanceData.EIGRP2;
        effectMaintenanceBody.WIGRP3 = effectMaintenanceData.EIGRP3;
        effectMaintenanceBody.WIGRP4 = effectMaintenanceData.EIGRP4;
        effectMaintenanceBody.WIGRP5 = effectMaintenanceData.EIGRP5;
        effectMaintenanceBody.WIGRP6 = effectMaintenanceData.EIGRP6;
        effectMaintenanceBody.WEMULT = effectMaintenanceData.EVTSEL === 'C' ? '0' : '1';
        effectMaintenanceBody.WESBMT = effectMaintenanceData.EHSUBBT;
        effectMaintenanceBody["#BGDT"] = effectMaintenanceData.EHSDAT;
        effectMaintenanceBody["#ENDT"] = effectMaintenanceData.EHEDAT;

    }

    getLabelValue(id) {
        return <FormattedMessageComponent id={id}></FormattedMessageComponent>;
    }



    render() {
        const { classes, eventDetailData, eventEffectMaintenanceLabelsData, currentPage, globalDateFormat } = this.props;
        const { tabcards, headerData } = this.state;
        let formValues = { ...headerData, ...this.state.effectMaintenanceData };

        return (
            <DialogComponent
                isOpen={this.props.isOpen}
                dialogTitle={this.props.title}
                cancelText={'CANCEL'}
                submitText={'OK'}
                handleClose={e => this.handleClose(false)}
                handleCancel={e => this.handleClose(false)}
                handleSubmit={e => { this.handleEventEffectMaintenance(true) }}>
                <React.Fragment>

                    {this.state.hasError ? (
                        <div>
                            <GridErrorMessages
                                errorMessageLabels={this.props.errorMessageLabels}
                                popUp={true}
                                sethaserror={this.sethaserror}
                                id={
                                    this.state.errorId ? this.state.errorId : this.props.ServerError
                                }
                            />
                        </div>
                    ) : (
                            ''
                        )}

                    <div>
                        {Object.keys(headerData).length && tabcards.length && (
                            <div className={classes.pageContainer}>
                                {tabcards.map(formCard => {
                                    if (formCard.cardkey === CARDKEY_EVENT_EFFECT_MAINTENANCE_HEADER) {
                                        return <div className={classes.notesForBlock}>
                                            <Box mb={theme.spacing(0.5)} className={classes.notesForLabel}>{formCard.cardtitle}</Box>
                                            <Header
                                                eventItemData={headerData}
                                                getLabelValue={this.getLabelValue}
                                                globalDateFormat={globalDateFormat}
                                            />
                                        </div>
                                    }
                                })}
                            </div>
                        )}
                    </div>

                    <div>
                        {Object.keys(headerData).length && tabcards.length && (
                            <div className={classes.pageContainer}>
                                {tabcards.map(formCard => {
                                    if (formCard.cardkey === CARDKEY_EVENT_EFFECT_MAINTENANCE) {
                                        return <div className={classes.notesForBlock}>
                                            <Box mb={theme.spacing(0.5)} className={classes.notesForLabel}>{formCard.cardtitle}</Box>
                                            <FormFieldsGenerator
                                                key={formCard.cardkey}
                                                fieldsArray={JSON.parse(JSON.stringify(formCard.cardfields))}
                                                valuesArray={JSON.parse(JSON.stringify(formValues))}
                                                globalDateFormat={globalDateFormat}
                                                handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                                handleSubmitDataCallBack={() => { }}
                                                cardHasCheckBox={true}
                                                noMassMaintenance={true}
                                                enableAddButton={() => { }}
                                                currentPage={currentPage}
                                                parentData={eventDetailData}
                                                parentPage={'vendors'}
                                                className={'ACCORDIAN_COMPONENT_CARDS_2_3'}
                                                labelDisplayCharacters={22}
                                                valueDisplayCharacters={17}
                                            />
                                        </div>
                                    }
                                })}
                            </div>
                        )}
                    </div>

                    <div>
                        {Object.keys(headerData).length && tabcards.length && (
                            <div className={classes.pageContainer}>
                                {tabcards.map(formCard => {
                                    if (formCard.cardkey === CARDKEY_EVENT_SELECTION) {
                                        return <div className={classes.notesForBlock}>
                                            <Box mb={theme.spacing(0.5)} className={classes.notesForLabel}>{formCard.cardtitle}</Box>
                                            <FormFieldsGenerator
                                                key={formCard.cardkey}
                                                fieldsArray={JSON.parse(JSON.stringify(formCard.cardfields))}
                                                valuesArray={JSON.parse(JSON.stringify(formValues))}
                                                globalDateFormat={globalDateFormat}
                                                handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                                handleSubmitDataCallBack={() => { }}
                                                cardHasCheckBox={true}
                                                noMassMaintenance={true}
                                                enableAddButton={() => { }}
                                                currentPage={currentPage}
                                                parentData={eventDetailData}
                                                parentPage={'vendors'}
                                                className={'ACCORDIAN_COMPONENT_CARDS_2_3'}
                                                labelDisplayCharacters={22}
                                                valueDisplayCharacters={17} />
                                        </div>
                                    }
                                })}
                            </div>
                        )}
                    </div>

                    <div>
                        {Object.keys(headerData).length && tabcards.length && (
                            <div className={classes.pageContainer}>
                                {tabcards.map(formCard => {
                                    if (formCard.cardkey === CARDKEY_ITEM_SELECTION) {
                                        return <div className={classes.notesForBlock}>
                                            <Box mb={theme.spacing(0.5)} className={classes.notesForLabel}>{formCard.cardtitle}</Box>
                                            <FormFieldsGenerator
                                                key={formCard.cardkey}
                                                fieldsArray={JSON.parse(JSON.stringify(formCard.cardfields))}
                                                valuesArray={JSON.parse(JSON.stringify(formValues))}
                                                globalDateFormat={globalDateFormat}
                                                handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                                handleSubmitDataCallBack={() => { }}
                                                cardHasCheckBox={true}
                                                noMassMaintenance={true}
                                                enableAddButton={() => { }}
                                                currentPage={currentPage}
                                                parentData={eventDetailData}
                                                parentPage={'vendors'}
                                                className={'ACCORDIAN_COMPONENT_CARDS_4'}
                                                labelDisplayCharacters={22}
                                                valueDisplayCharacters={17} />
                                        </div>
                                    }

                                })}
                            </div>
                        )}
                    </div>

                    <Box className={classes.adjustShowDetail}>
                        <FieldInput field={{ type: 'checkbox', key: 'EHSUBBT' }} value={Number(this.state.effectMaintenanceData["EHSUBBT"])}
                            onChange={(key, val) => this.handleChangeValue(key, val, { "prefixFlag": "1", "FDFNAM": key })} />
                        <div className={classes.submitJob}>{this.getLabelValue("11087")}</div>
                    </Box>

                </React.Fragment>

            </DialogComponent>
        )
    }
}


export default withStyles(style)(EventEffectMaintenanceDialog);
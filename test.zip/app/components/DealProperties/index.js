import React, { Component } from 'react';
import { compose } from 'redux';
import { withStyles } from '@material-ui/core';
import AppBar from '@material-ui/core/AppBar';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import Typography from '@material-ui/core/Typography';
import Spinner from 'components/Common/Spinner';
import FormattedMessageComponent from 'components/common/FormattedMessageComponent';
import ConfirmationDialog from 'components/common/ConfirmationDialog';
import ApplyChangestoItems from './DealDialogs/ApplyChangestoItems'
import ManageItems from './DealDialogs/ManageItemsDialog'
import ModelDeal from './DealDialogs/ModelDealDialog'
import DeleteDialog from './DealDialogs/DeleteDialog'
import Header from './header';
import DealSummary from './DealSummary';
import { isEqual } from 'lodash';
import ItemOnDeal from './ItemOnDeal';
import DealNotes from './DealNotes';
import Filter from 'containers/common/Filter';
import CopyDeal from 'containers/DealsEmbeddedListPage/CopyDeal'
import {
	DEALS_LIST_PAGE,
	GLOBAL_FILTER_OPTIONS,
	COLUMN_VALUE_ACCESSOR,
	INITIAL_PAGE_PROPS,
	DEAL_PROPERTIES_PAGE,
	COLUMN_FIELD_LEN,
	TEXT_OK, TEXT_ALERT,
	OUTOFSTOCKITEMS_LIST_PAGE
} from '../common/constants';
import {
	prepareValueDataForDeal,
	prepareValueDataForVendors,
	getListPredecessor,
	setSortDataFromSortCriteria,
	getFilterDataFromLocalStorage,
	getFilterDataFromCriteriaDetails,
	handleFieldValuesByLength,
	getUpdateRestrictionOnComponent,
	capitalizeFirstLetter,
} from 'utils/util';
import { getDBSelectorFilterValues, prepareTooltipValues } from 'utils/filterData';
import { onChangeContextMenu, updateBreadCrumbContextMenu } from 'utils/contextMenu';
import {
	ITEM_ON_DEAL_LABEL_TAB_KEY,
	DEAL_SUMMARY_LABEL_TAB_KEY,
	LABEL_LIST_URL_DATA,
	DEFAULT_VALUE_URL_DATA,
	HeaderAPIValuesJSON,
	VENDOR_PROPERTIES,
	DEFAULT_VALUE_URL_DATA_VENDOR,
	TEXT_YES, TEXT_NO, LABEL_COPY, LABEL_DELETE,
	BRACKET_LABEL_URL_DATA
} from "./constants";
import GridErrorMessages from 'components/common/GridErrorMessages';
function TabContainer(props) {
	return (
		<Typography className="minWidth1100" component="div">
			{props.children}
		</Typography>
	);
}

const style = () => ({
	propertiesContentWrapper: {
		margin: '10px auto',
		fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
		borderRadius: '4px',
		overflow: 'hidden',
		boxShadow: '0 2px 4px var(--secondary-s10)',
		overflowX: 'auto',
	},
	hideContent: {
		display: 'none',
	},
	showContent: {
		display: 'block',
	},
});
class DealProperties extends Component {
	constructor() {
		super();
		this.state = {
			tab: 0,
			isSaveDataDisabled: true,
			headerData: false,
			columnDefs: [],
			stateData: false,
			totalCount: 0,
			fromPage: false,
			hasError: false,
			errorId: false,
			changeDataAPI: false,
			openFilterPopup: false,
			previousFilterValues: false,
			showConfirmationDialog: false,
			dialogTitle: '',
			hasWarning: false,
			fromListPage: null,
			hasFiltersChanged: false,
			hasSortChanged: false,
			isDataLoaded: false,
			isInitialAPICall: true,
			valueDataFailureMessages: [],
			headerValues: HeaderAPIValuesJSON[0],
			isFiltersChanged: false,
			copyDeal: false,
			openDeletePopup: false,
			dialogBody: false,
			parameterValues: [],
			canUpdateComponent: false,
			applyChangestoItems: false,
			showSaveDialog: false,
			manageItemsButton: false,
			modelDealButton: false,
			updatedNotes: false,
			notesFilterObj: {},
			notesCount: 0,
			notesCountWidth: '22px',
		};
		this.prepareHeaderDataJSON = this.prepareHeaderDataJSON.bind(this);
		this.handleDealHeaderRightArrowClick = this.handleDealHeaderRightArrowClick.bind(this);
		this.handleDealHeaderLeftArrowClick = this.handleDealHeaderLeftArrowClick.bind(this);
		this.getApiObj = this.getApiObj.bind(this);
		this.makeAPICallForPageUpDown = this.makeAPICallForPageUpDown.bind(this);
		this.getApiObjForPageUpDown = this.getApiObjForPageUpDown.bind(this);
		this.getLabelValue = this.getLabelValue.bind(this);
		this.setRecordDataValues = this.setRecordDataValues.bind(this);
		this.forceUpdateHandler = this.forceUpdateHandler.bind(this);
		this.setFilterValuesFromState = this.setFilterValuesFromState.bind(this);
		this.handleDealHeaderFilterClick = this.handleDealHeaderFilterClick.bind(this);
		this.onSaveData = this.onSaveData.bind(this);
		this.onContextMenuChange = this.onContextMenuChange.bind(this);
		this.sendAPICallForValues = this.sendAPICallForValues.bind(this);
		this.handleNoDataSets = this.handleNoDataSets.bind(this);
		this.handleValueDataErrorMessages = this.handleValueDataErrorMessages.bind(this);
		this.handleChangeValue = this.handleChangeValue.bind(this);
		this.handleItemSelection = this.handleItemSelection.bind(this);
		this.setNotesCount = this.setNotesCount.bind(this); //deals_notes update notes count
	}
	handleNoDataSets() {
		const { dealSummaryLabelsData, itemsOnDealLabelsData } = this.props.dealPropertiesPage;
		if (this.state.isDataLoaded) {
			if ((dealSummaryLabelsData && Object.keys(dealSummaryLabelsData) && Object.keys(dealSummaryLabelsData).length) &&
				itemsOnDealLabelsData && Object.keys(itemsOnDealLabelsData) && Object.keys(itemsOnDealLabelsData).length) {
				// do nothing here
			} else {
				this.props.setNoDataCallBackValue(true);
				const paramsString = window.location.search;
				if (paramsString && paramsString.length) {
					const paramsArray = paramsString.split('?');
					if (paramsArray && paramsArray.length && paramsArray.length > 1) {
						const params = paramsArray[1].split('&');
						const tabId = params[0].split('=')[1];
						const breadCrumbId = params[1].split('=')[1];
						this.props.removeCurrentRecordObj(tabId, breadCrumbId);
					}
				}
			}
		}
	}
	handleDealHeaderFilterClick() {
		if (this.state.isFiltersChanged && this.props.dealPropertiesPage.isValueDataAPIFailure) {
			this.props.onSetFilterProps(this.state.previousFilterValues);
			this.props.setGlobalFilterProps(this.state.previousFilterValues);
			this.props.setChildTabFilterProps(this.state.previousFilterValues);
			this.setState({ isFiltersChanged: false });
			this.props.setValueDataAPIFailureFlag(false);
		}
		this.setState({ openFilterPopup: !this.state.openFilterPopup });
	}
	getLabelValue(id) {
		return <FormattedMessageComponent id={id} />;
	}

	handleChangeTab = (event, value) => {
		this.setState({ tab: value });
		this.props.setDataInTabs("selectedPropertiesTab", value);//Ajit Saving previously visitedtab
	};

	setFilterValuesFromState(values) {
		const filterValues = [];
		const { columnDefs } = this.state;
		if ((columnDefs && columnDefs.length) || (this.columnDefData && this.columnDefData.length)) {
			const colData = columnDefs && columnDefs.length ? columnDefs : this.columnDefData;
			values.forEach(value => {
				const isExists = colData.find(
					column => column[COLUMN_VALUE_ACCESSOR].trim() == value.accessor,
				);
				if (isExists) {
					filterValues.push(value);
				}
			});
			if (filterValues && filterValues.length) {
				this.props.onSetFilterProps(filterValues);
				this.props.setGlobalFilterProps(filterValues);
				return filterValues;
			}
		} else {
			this.props.onSetFilterProps(values);
			this.props.setGlobalFilterProps(values);
			return values;
		}
	}
	getApiObj(recordData, record, currentPage, pageProps) {
		let recordObj = false;
		if (record) {
			recordObj = record;
		}
		const apiObj = {
			recordData,
			pageProps,
			direction: pageProps.isForwardDirection,
			record: recordObj,
			currentPage,
			parentPage: DEALS_LIST_PAGE,
		};
		return apiObj;
	}
	getApiFilterObj(filterProps, currentPage, pageProps) {

		let apiObj = {
			filterProps,
			pageProps: pageProps,
			direction: pageProps.isForwardDirection,
			currentPage: currentPage,
			parentPage: ORDER_LIST
		};
		return apiObj;
	}
	prepareHeaderDataJSON(obj) {
		const headerValues = this.state.headerValues;
		const { vendorData } = this.props.dealPropertiesPage;
		const prefix = getListPredecessor(DEALS_LIST_PAGE);
		const keyVendor = `${prefix}VNDR`;
		headerValues.DHVNDR = obj[keyVendor];
		if (vendorData && Object.keys(vendorData) && Object.keys(vendorData).length) {
			headerValues.DHVNAME = vendorData['VNAME'];
			headerValues.DHSUBV = vendorData['VSUBV'];
		}

		const keyWarehouse = `${prefix}WHSE`;
		headerValues.DHWHSE = obj[keyWarehouse];

		headerValues.DHWNAME = obj['DHWNAME'];

		const keyDeal = `${prefix}DEAL`
		headerValues.DHDEAL = obj[keyDeal];

		const keyCreationDate = `${prefix}BRDT`;
		headerValues.DHBRDT = obj[keyCreationDate];

		this.setState({ headerValues: headerValues })
		return [headerValues];
	}

	forceUpdateHandler() {
		this.forceUpdate();
	}
	makePrevNextAPICall = flag => {
		const { filterProps, valueData, sortProps } = this.props.dealPropertiesPage;
		const data = JSON.parse(JSON.stringify(INITIAL_PAGE_PROPS));
		data.isForwardDirection = flag;
		data.pageSize = 3;
		this.props.getPageUpDownFlagAPI(
			this.getApiObjForPageUpDownFlags(filterProps, valueData, DEALS_LIST_PAGE, data, sortProps, flag)
		);
	};
	prepareTooltipData = () => {
		const { detailCallData, dealColumnDefs } = this.props.dealPropertiesPage;
		let tooltipData = prepareTooltipValues(DEALS_LIST_PAGE, detailCallData, dealColumnDefs, DEAL_PROPERTIES_PAGE);
		this.props.setDataInTabs("toolTipData", JSON.parse(JSON.stringify(tooltipData)));
	}

	setHeaderAndSendAPI(jsonData, from) {
		let data = this.prepareHeaderDataJSON(jsonData);
		this.setState({ headerData: data });
		this.setState({ stateData: jsonData });
		let valueData = prepareValueDataForDeal(DEFAULT_VALUE_URL_DATA, jsonData, from);
		let valueDataVendor = prepareValueDataForVendors(DEFAULT_VALUE_URL_DATA_VENDOR, jsonData, from);
		this.sendAPICallForValues(valueData, jsonData, valueDataVendor);
	}
	prepareKeyValue(jsonData, filterName) {
		const currentPage = DEALS_LIST_PAGE;
		const columnDefs = this.columnDefData;
		let headerKey = COLUMN_VALUE_ACCESSOR;
		let fieldLenKey = COLUMN_FIELD_LEN;
		let filterValues = FILTER_DATA;
		if (columnDefs && columnDefs.length) {
			let filterData = '';
			filterValues.forEach((filter) => {
				let columnData = columnDefs.find((column) => {
					let columnKey = column[headerKey].trim();
					return columnKey == filter;
				});
				if (columnData && Object.keys(columnData) && Object.keys(columnData).length) {
					let fieldLen = Number(columnData[fieldLenKey].trim());
					let columnKey = columnData.prefixFlag ? (columnData[headerKey].trim()) : (getListPredecessor(currentPage) + columnData[headerKey].trim());
					let dataValue = jsonData[columnKey] ? jsonData[columnKey].trim() : jsonData[columnKey];
					let str = handleFieldValuesByLength(dataValue, fieldLen);
					if (filterName == filter) {
						filterData = str;
					}
				}
			})
			return filterData;
		}
		return '';
	}
	prepareFilterProps(data, valueData) {
		let jsonObj = JSON.parse(JSON.stringify(valueData));
		let filterData = JSON.parse(JSON.stringify(data));
		filterData[0]["fieldValue"] = this.prepareKeyValue(jsonObj, 'COMP');
		filterData[1]["fieldValue"] = this.prepareKeyValue(jsonObj, 'VNDR');
		filterData[2]["fieldValue"] = this.prepareKeyValue(jsonObj, 'ITEM');
		filterData[3]["fieldValue"] = this.prepareKeyValue(jsonObj, 'WHSE');
		return filterData;
	}

	sendAPICallForValues(valueData, jsonData, valueDataVendor) {
		const { pageProps } = this.props.dealPropertiesPage;
		this.props.getValueList(this.getApiObj(valueData, null, DEAL_PROPERTIES_PAGE, pageProps));
		this.props.getDealAllowanceValueList(this.getApiObj(valueData, null, DEAL_PROPERTIES_PAGE, pageProps));
		this.props.getVendorValueList(this.getApiObj(valueDataVendor, null, VENDOR_PROPERTIES, pageProps), this.props.globalNumberFormat,
			this.props.globalNumberSeparator, this.props.globalDecimalSeparator);
		let filters = [{ "accessor": "DSCOMP", "operator": "=", "jOpr": "and", "fieldValue": "E3T", "prefixFlag": 1 },
		{ "accessor": "DSWHSE", "operator": "=", "jOpr": "and", "fieldValue": jsonData["DHWHSE"], "prefixFlag": 1 },
		{ "accessor": "DSDEAL", "operator": "=", "jOpr": "and", "fieldValue": jsonData["DHDEAL"], "prefixFlag": 1 }];
		this.props.getItemOnDealValueList(filters);
	}
	handleValueDataErrorMessages(content) {
		this.setState({ showValueConfirmationDialog: true });
		this.setState({ dialogTitle: TEXT_ALERT });
		this.setState({ dialogContent: content });
		this.setState({ hasWarning: content == 'E10184' ? true : false });
	}

	closeValueDialog = () => {
		this.setState({ showValueConfirmationDialog: false });
		if (this.state.valueDataFailureMessages && this.state.valueDataFailureMessages.length) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.shift();
			this.setState({ valueDataFailureMessages: values });
		}
	}
	setRecordDataValues() {
		let isRecordValuesExists = false, isLocalStorageValuesExists = false, isFilterValuesExists = false;
		const { history } = this.props;
		var paramsString = window.location.search;
		if (paramsString && paramsString.length) {
			let paramsArray = paramsString.split("?");
			if (paramsArray && paramsArray.length && paramsArray.length > 1) {
				let params = paramsArray[1].split("&");
				let tabId = params[0].split("=")[1];
				let breadCrumbId = params[1].split("=")[1];
				let localStorageValues = getFilterDataFromLocalStorage(tabId, breadCrumbId);
				if (localStorageValues && Object.keys(localStorageValues) && Object.keys(localStorageValues).length) {
					isLocalStorageValuesExists = true;
					let itemData = localStorageValues.item_data, dbSelectorValues = [];
					if (itemData && itemData.recordData && localStorageValues.childType) {
						this.columnDefData = JSON.parse(JSON.stringify(itemData.recordData.columnDefs))
						this.setState({ columnDefs: itemData.recordData.columnDefs });
						this.props.setCurrentRecord(itemData.recordData.data);
						this.setState({ totalCount: itemData.recordData.totalCount });
						this.setState({ fromPage: itemData.recordData.fromPage });
						this.setState({ fromListPage: itemData.recordData.fromPage });
						this.props.setRowIndex(itemData.recordData.rowIndex);
						this.setHeaderAndSendAPI(itemData.recordData.data, itemData.recordData.fromPage);
						isRecordValuesExists = true;
						this.props.setSelectedRecord(false, false);
						if (itemData) {
							if (itemData.dbSelector && itemData.dbSelector.length) {
								dbSelectorValues = JSON.parse(JSON.stringify(itemData.dbSelector));
							}
							if (itemData.filterProps && itemData.filterProps.length) {
								this.setState({ hasFiltersChanged: false });
								isFilterValuesExists = true;
								let values = getDBSelectorFilterValues(dbSelectorValues, itemData.filterProps);
								this.setFilterValuesFromState(values);
							} else if (dbSelectorValues && dbSelectorValues.length) {
								this.setState({ hasFiltersChanged: false });
								isFilterValuesExists = true;
								let dbValues = getDBSelectorFilterValues(dbSelectorValues, []);
								this.setFilterValuesFromState(dbValues);
							}
							if (itemData.sortProps && itemData.sortProps.length) {
								this.setState({ hasSortChanged: false });
								this.props.sendPageSortProps(itemData.sortProps);
								this.props.onSetSortProps(itemData.sortProps);
							} else {
								//do nothing
							}
							if (itemData.defaultFilterInfo && Object.keys(itemData.defaultFilterInfo) && Object.keys(itemData.defaultFilterInfo).length) {
								this.props.setDefaultFilterpropsForTabs(itemData.defaultFilterInfo);
							}
							if (itemData.defaultSortInfo && Object.keys(itemData.defaultSortInfo) && Object.keys(itemData.defaultSortInfo).length) {
								this.props.setDefaultSortpropsForTabs(itemData.defaultSortInfo);
							}
							if (itemData.selectedPropertiesTab) {
								this.setState({ tab: itemData.selectedPropertiesTab });//Ajit Saving previously visitedtab
							}
						}
					}

				}
				if (!isLocalStorageValuesExists && tabId && breadCrumbId) {
					history.push({ pathname: '/Dashboard' });
				}
			}
		}

		let filterOptions = GLOBAL_FILTER_OPTIONS;
		const { dbSelector } = this.props;
		if (!isFilterValuesExists) {
			let gbValues = getDBSelectorFilterValues(dbSelector, filterOptions);
			this.setFilterValuesFromState(gbValues);
		}
		return isRecordValuesExists;
	}

	resetValues = () => {
		this.props.setInitialState();
		this.props.setValueDataFlag(false);
		this.props.setCurrentRecord(null);
		this.props.getDealColumnDefs({ type: DEALS_LIST_PAGE });
	};

	componentDidMount() {
		this.resetValues();
		let currentPage = DEAL_PROPERTIES_PAGE;
		this.props.onLoadCurrentPage(currentPage);
		const { detailCallData } = this.props.dealPropertiesPage;
		this.props.setIsShowContextMenu(true);
		let isFound = this.setRecordDataValues();

		if (!isFound) {
			if (this.props.location && this.props.location.state) {
				this.props.setCurrentRecord(this.props.location.state.data);
				this.setState({ columnDefs: this.props.location.state.columnDefs });
				this.setState({ fromPage: this.props.location.state.fromPage });
				this.props.setRowIndex(this.props.location.state.rowIndex);
				this.setHeaderAndSendAPI(this.props.location.state.data, DEALS_LIST_PAGE);
			}
		}

		if (detailCallData && Object.keys(detailCallData) && Object.keys(detailCallData).length) {
			this.setState({ headerData: this.prepareHeaderDataJSON(detailCallData) });
			this.props.setSelectedRecord(detailCallData, DEALS_LIST_PAGE);
		}
		let labelFilters = LABEL_LIST_URL_DATA;
		this.props.getLabelsList({ recordData: labelFilters, currentPage: 'vendorproperties' });
		this.setState({ isSaveDataDisabled: true });


		const { pageProps } = this.props.dealPropertiesPage;
		this.props.getLabelsList({ recordData: labelFilters, currentPage: 'vendorproperties' });
		this.setState({ isSaveDataDisabled: true });
		this.props.getBracketJson({ recordData: BRACKET_LABEL_URL_DATA, currentPage: 'vendorproperties' });
		let canUpdateComponent = getUpdateRestrictionOnComponent(capitalizeFirstLetter(DEALS_LIST_PAGE), this.props.authorizedComponentsList);
		this.setState({ canUpdateComponent })

	}

	//deal_notes get Notes count
	setNotesCount(count) {
		if (this.state.notesCount != count) {
			this.setState({ notesCount: count })
			if (count == 9)
				this.setState({ notesCountWidth: '28px' })

			else if (count < 9 && this.notesCountWidth != '22px')
				this.setState({ notesCountWidth: '22px' })
		}
	}

	updatedNotesData = () => {
		this.setState({ updatedNotes: true });
	}




	componentDidUpdate(prevProps, prevState) {
		const { pageUpDownData,
			isSaveSuccess,
			filterProps,
			isValueDataAPICall,
			isValueDataAPIFailure,
			dealColumnDefs,
			sortProps,
			defaultSortProps,
			sortCriteriaDetails,
			filterCriteriaDetails,
			detailCallData,
			labelsDataFailure,
			isAPIforVendorDetail,
			isAPIforDealAllowance,
			isAPIforItemOnDealDetail,
			isAPIforDealAllowanceUpdate,
			isAPIforDealPropertiesUpdate,
			previousNextFlagAPIFailure,
			isAPIforDealDelete,
			isAPIforDealColums,
			isCopySuccess,
			isAPIforDealDeleteAll,
			isMassMaintenanceSuccess, updateList, copiedDeal,
			isAPIforDealModel,
			isAPIforDealModelAll,
			isAPIforMassMaintenance,
			isAPIforMassMaintenanceAll,
			isAPIforAddRecord,
			isAPIforRemoveRecord,
			isAPIforUpdateRecord,
			isAPIforDeleteItemOnDeal,
		} = this.props.dealPropertiesPage

		if (this.state.valueDataFailureMessages && this.state.valueDataFailureMessages.length
			&& (JSON.stringify(this.state.valueDataFailureMessages) != JSON.stringify(prevState.valueDataFailureMessages))) {
			this.handleValueDataErrorMessages(this.state.valueDataFailureMessages[0]);
		}

		if (labelsDataFailure && (labelsDataFailure != prevProps.dealPropertiesPage.labelsDataFailure)) {
			this.setState({ isDataLoaded: true })
			this.handleNoDataSets();
			this.props.setLabelDataFlags({ key: 'labelsDataFailure', value: false });
		}

		if (isAPIforVendorDetail && (isAPIforVendorDetail != prevProps.dealPropertiesPage.isAPIforVendorDetail)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to fetch Vendor Detail");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isAPIforVendorDetail', value: false });
		}

		if (isAPIforDealAllowance && (isAPIforDealAllowance != prevProps.dealPropertiesPage.isAPIforDealAllowance)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to fetch Deal Allowance");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isAPIforDealAllowance', value: false });
		}

		if (isAPIforItemOnDealDetail && (isAPIforItemOnDealDetail != prevProps.dealPropertiesPage.isAPIforItemOnDealDetail)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to fetch item on deal List");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isAPIforItemOnDealDetail', value: false });
		}

		if (isAPIforDealAllowanceUpdate && (isAPIforDealAllowanceUpdate != prevProps.dealPropertiesPage.isAPIforDealAllowanceUpdate)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to Update Deal");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isAPIforDealAllowanceUpdate', value: false });
		}
		if (isAPIforDealPropertiesUpdate && (isAPIforDealPropertiesUpdate != prevProps.dealPropertiesPage.isAPIforDealPropertiesUpdate)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to Update Deal");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isAPIforDealPropertiesUpdate', value: false });
		}

		if (previousNextFlagAPIFailure && (previousNextFlagAPIFailure != prevProps.dealPropertiesPage.previousNextFlagAPIFailure)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to fetch Previous Next Flag");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'previousNextFlagAPIFailure', value: false });
		}
		if (isAPIforDealModel && (isAPIforDealModel != prevProps.dealPropertiesPage.isAPIforDealModel)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("E10151");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isAPIforDealModel', value: false });
		}
		if (isAPIforDealModelAll && (isAPIforDealModelAll != prevProps.dealPropertiesPage.isAPIforDealModelAll)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("E10151");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isAPIforDealModelAll', value: false });
		}
		if (isAPIforDealDelete && (isAPIforDealDelete != prevProps.dealPropertiesPage.isAPIforDealDelete)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("E10106");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isAPIforDealDelete', value: false });
		}

		if (isAPIforDealColums && (isAPIforDealColums != prevProps.dealPropertiesPage.isAPIforDealColums)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to fetch Deal Columns");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isAPIforDealColums', value: false });
		}
		if (isCopySuccess && (isCopySuccess != prevProps.dealPropertiesPage.isCopySuccess)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("E11738");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isCopySuccess', value: false });
		}
		if (isAPIforDealDeleteAll && (isAPIforDealDeleteAll != prevProps.dealPropertiesPage.isAPIforDealDeleteAll)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("E10106");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isAPIforDealDeleteAll', value: false });
		}
		if (isAPIforMassMaintenance && (isAPIforMassMaintenance != prevProps.dealPropertiesPage.isAPIforMassMaintenance)) {
			values.push("Failed Mass Maintenance transaction");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isAPIforMassMaintenance', value: true });
		}
		if (isAPIforMassMaintenanceAll && (isAPIforMassMaintenanceAll != prevProps.dealPropertiesPage.isAPIforMassMaintenanceAll)) {
			values.push("Failed Mass Maintenance All transaction");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isAPIforMassMaintenanceAll', value: true });
		}
		if (isAPIforAddRecord && (isAPIforAddRecord != prevProps.dealPropertiesPage.isAPIforAddRecord)) {
			values.push("E10163");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isAPIforAddRecord', value: true });
		}
		if (isAPIforRemoveRecord && (isAPIforRemoveRecord != prevProps.dealPropertiesPage.isAPIforRemoveRecord)) {
			values.push("E10166");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isAPIforRemoveRecord', value: true });
		}
		if (isAPIforUpdateRecord && (isAPIforUpdateRecord != prevProps.dealPropertiesPage.isAPIforUpdateRecord)) {
			values.push("Unable to update the allowance");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isAPIforUpdateRecord', value: true });
		}
		if (isAPIforDeleteItemOnDeal && (isAPIforDeleteItemOnDeal != prevProps.dealPropertiesPage.isAPIforDeleteItemOnDeal)) {
			values.push("E10149");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isAPIforDeleteItemOnDeal', value: true });
		}

		if (isMassMaintenanceSuccess && (isMassMaintenanceSuccess != prevProps.dealPropertiesPage.isMassMaintenanceSuccess)) {
			const { currentRecordData } = this.props.dealPropertiesPage;
			this.setHeaderAndSendAPI(currentRecordData, DEAL_PROPERTIES_PAGE)
		}
		if (updateList && (updateList != prevProps.dealPropertiesPage.updateList)) {
			const { currentRecordData } = this.props.dealPropertiesPage;
			let filters = [{ "accessor": "DSCOMP", "operator": "=", "jOpr": "and", "fieldValue": "E3T", "prefixFlag": 1 },
			{ "accessor": "DSWHSE", "operator": "=", "jOpr": "and", "fieldValue": currentRecordData["DHWHSE"], "prefixFlag": 1 },
			{ "accessor": "DSDEAL", "operator": "=", "jOpr": "and", "fieldValue": currentRecordData["DHDEAL"], "prefixFlag": 1 }];
			this.props.getItemOnDealValueList(filters);
		}
		if (sortProps && sortProps.length && !isEqual(sortProps, prevProps.dealPropertiesPage.sortProps)) {
			this.props.setDataInTabs("sortProps", JSON.parse(JSON.stringify(sortProps)));
			if (!this.state.isInitialAPICall) {
				if (this.state.fromPage != DEALS_LIST_PAGE) {
					this.setHeaderAndSendAPI(this.state.stateData, this.state.fromPage)
				} else {
					this.makeAPICallForPageUpDown('down', {});
				}
			}
		}

		if ((JSON.stringify(filterProps) != JSON.stringify(prevProps.dealPropertiesPage.filterProps)) && filterProps && filterProps.length) {
			this.setState({ isFiltersChanged: true });
			this.props.setChildTabFilterProps(filterProps);
			if (!this.state.isInitialAPICall) {
				if (this.state.fromPage != DEALS_LIST_PAGE && !this.state.hasFiltersChanged) {
					this.setHeaderAndSendAPI(this.state.stateData, this.state.fromPage)
				} else {
					this.makeAPICallForPageUpDown('down', {});
				}
			}
		}
		if ((defaultSortProps != prevProps.dealPropertiesPage.defaultSortProps) && (prevProps.dealPropertiesPage.defaultSortProps === null) && (sortProps == null || !sortProps || !(sortProps && sortProps.length))) {
			let list = setSortDataFromSortCriteria(defaultSortProps, dealColumnDefs, DEALS_LIST_PAGE);
			this.props.setDataInTabs("defaultSortInfo", JSON.parse(JSON.stringify(defaultSortProps)));
			if (list && list.length) {
				this.props.sendPageSortProps(list);
				this.props.onSetSortProps(list);
			} else {
				this.props.sendPageSortProps([]);
				this.props.onSetSortProps([]);
			}
		}

		if (JSON.stringify(sortCriteriaDetails) != JSON.stringify(prevProps.dealPropertiesPage.sortCriteriaDetails)) {
			this.props.setDataInTabs("defaultSortInfo", JSON.parse(JSON.stringify(sortCriteriaDetails)));
			let list = setSortDataFromSortCriteria(sortCriteriaDetails, dealColumnDefs, DEALS_LIST_PAGE);
			if (list && list.length) {
				this.props.sendPageSortProps(list);
				this.props.onSetSortProps(list);
			}
		}

		if ((filterCriteriaDetails != prevProps.dealPropertiesPage.filterCriteriaDetails)) {
			this.props.setDataInTabs("defaultFilterInfo", JSON.parse(JSON.stringify(filterCriteriaDetails)));
			if (filterCriteriaDetails && Object.keys(filterCriteriaDetails) && Object.keys(filterCriteriaDetails).length && dealColumnDefs && dealColumnDefs.length) {
				let list = getFilterDataFromCriteriaDetails(filterCriteriaDetails, dealColumnDefs, DEALS_LIST_PAGE);
				if (list && list.length) {
					this.props.setGlobalFilterProps(list);
					this.props.onSetFilterProps(list);
				}
			}
		}

		if (detailCallData && !isEqual(detailCallData, prevProps.dealPropertiesPage.detailCallData)) {
			if (Object.keys(detailCallData) && Object.keys(detailCallData).length) {
				if (dealColumnDefs && dealColumnDefs.length) {
					this.prepareTooltipData();
				}
				this.props.setSelectedRecord(detailCallData, DEALS_LIST_PAGE);
				this.setState({ headerData: this.prepareHeaderDataJSON(detailCallData) });
			}
		}

		if (dealColumnDefs && dealColumnDefs.length && !isEqual(dealColumnDefs, prevProps.dealPropertiesPage.dealColumnDefs) &&
			(detailCallData && Object.keys(detailCallData) && Object.keys(detailCallData).length)) {
			if (!this.state.changeDataAPI) {
				this.prepareTooltipData();
			}
		}
		if (isValueDataAPICall != prevProps.dealPropertiesPage.isValueDataAPICall && isValueDataAPICall) {
			this.setState({ previousFilterValues: prevProps.dealPropertiesPage.filterProps })
			this.setState({ isInitialAPICall: false });
			this.makePrevNextAPICall(true);
			this.props.setValueDataFlag(false);
			if (this.state.isFiltersChanged) {
				this.setState({ openFilterPopup: false });
				this.setState({ isFiltersChanged: false });
			}
		}

		if (isValueDataAPIFailure != prevProps.dealPropertiesPage.isValueDataAPIFailure && isValueDataAPIFailure) {
			this.setState({ isInitialAPICall: false });
			if (this.state.isFiltersChanged) {
				this.setState({ showConfirmationDialog: true });
				this.setState({ hasWarning: true });
				this.setState({ dialogTitle: TEXT_ALERT });
				this.setState({ fromHeaderENG: true });
				this.setState({ dialogBody: '28648' });
			} else {
				let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
				values.push("Failed to get the detail data");
				this.setState({ valueDataFailureMessages: values });
			}
		}

		if (this.props.location.search != prevProps.location.search) {
			this.resetValues();
			this.forceUpdateHandler();
			this.setRecordDataValues();
			this.setState({ state: this.state });
		}
		if (pageUpDownData && JSON.stringify(pageUpDownData) != JSON.stringify(prevProps.dealPropertiesPage.pageUpDownData)) {
			this.props.setSelectedRecord(pageUpDownData, DEALS_LIST_PAGE);
			this.setState({ fromPage: DEALS_LIST_PAGE });
			this.setHeaderAndSendAPI(pageUpDownData, DEALS_LIST_PAGE);
			let modifiedData = {
				data: JSON.parse(JSON.stringify(pageUpDownData)),
				fromPage: DEALS_LIST_PAGE,
				rowIndex: this.props.dealPropertiesPage.rowIndex,
				totalCount: this.state.totalCount,
				fromParent: false,
				columnDefs: this.state.columnDefs,
			};
			this.props.setDataInTabs('recordData', modifiedData);
		}
		if (isSaveSuccess && isSaveSuccess !== prevProps.dealPropertiesPage.isSaveSuccess) {
			this.setState({ isSaveDataDisabled: true });
			const { currentRecordData } = this.props.dealPropertiesPage;
			let filters = [{ "accessor": "DSCOMP", "operator": "=", "jOpr": "and", "fieldValue": "E3T", "prefixFlag": 1 },
			{ "accessor": "DSWHSE", "operator": "=", "jOpr": "and", "fieldValue": currentRecordData["DHWHSE"], "prefixFlag": 1 },
			{ "accessor": "DSDEAL", "operator": "=", "jOpr": "and", "fieldValue": currentRecordData["DHDEAL"], "prefixFlag": 1 }];
			this.props.getItemOnDealValueList(filters);
		}
		if (copiedDeal && (copiedDeal != prevProps.dealPropertiesPage.copiedDeal)) {
			this.setState({ showConfirmationDialog: true, dialogTitle: '52891', dialogBody: 'E10175' });
		}

		if (prevProps.authorizedComponentsList !== this.props.authorizedComponentsList) {
			let canUpdateComponent = getUpdateRestrictionOnComponent(capitalizeFirstLetter(DEALS_LIST_PAGE), this.props.authorizedComponentsList);
			this.setState({ canUpdateComponent });
		}
	}

	onSaveData = () => {
		const { newValueData, valueData } = this.props.dealPropertiesPage;
		if (this.onValid(newValueData, valueData)) {
			if (JSON.stringify(newValueData) != JSON.stringify(valueData)) {
				if (Object.keys(valueData).length && Object.keys(newValueData).length &&
					(JSON.stringify(valueData) == JSON.stringify(newValueData))) {
					//deal allowance update
					const { rowdata, newValueData } = this.props.dealPropertiesPage
					if (rowdata && Array.isArray(rowdata) && rowdata.length) {
						this.props.dealAllowanceUpdate(rowdata)
					}
					//deal header update
					this.props.dealDetailsUpdate(newValueData)
				} else {
					this.setState({ showSaveDialog: true })
				}
			}
		}
	}
	getApiObjForPageUpDown(filterData, record, currentPage, pageProps, sortData, pageType) {
		let recordObj = false
		if (record) {
			recordObj = record;
		}
		let apiObj = {
			sortProps: sortData,
			filterProps: filterData,
			pageProps: pageProps,
			direction: pageProps.isForwardDirection,
			record: recordObj,
			currentPage: currentPage,
			parentPage: DEALS_LIST_PAGE,
			pageType: pageType
		};
		return apiObj;
	}

	getApiObjForPageUpDownFlags = (filterData, record, currentPage, pageProps, sortData, pageType) => {
		let recordObj = false
		if (record) {
			recordObj = {
				"record": record,
				"flagsOnly": true
			};
		}
		let apiObj = {
			sortProps: sortData,
			filterProps: filterData,
			pageProps: pageProps,
			direction: pageProps.isForwardDirection,
			record: recordObj,
			currentPage: currentPage,
			parentPage: DEALS_LIST_PAGE,
			pageType: pageType
		};
		return apiObj;
	}

	makeAPICallForPageUpDown(type, currentRecordData) {
		const { filterProps, sortProps } = this.props.dealPropertiesPage;
		let data = JSON.parse(JSON.stringify(INITIAL_PAGE_PROPS));
		if (type == 'up') {
			data.isForwardDirection = false;
		} else {
			data.isForwardDirection = true;
		}
		let filterData = JSON.parse(JSON.stringify(filterProps));
		this.props.pageUpDownAPI(this.getApiObjForPageUpDown(filterData, currentRecordData, DEALS_LIST_PAGE, data, sortProps))
	}
	handleDealHeaderLeftArrowClick() {
		const { currentRecordData } = this.props.dealPropertiesPage;
		this.props.setCurrentType('down');
		this.makeAPICallForPageUpDown('down', currentRecordData);
		this.setState({ isSaveDataDisabled: true });
	}

	handleDealHeaderRightArrowClick() {
		const { currentRecordData } = this.props.dealPropertiesPage;
		this.props.setCurrentType('up');
		this.makeAPICallForPageUpDown('up', currentRecordData);
		this.setState({ isSaveDataDisabled: true });
	}
	onValid = (newValueData) => {
		const { companyDetails } = this.props;
		if (newValueData.DHBLST < newValueData.DHB1ST) {
			this.setGridError('10112');
			return false;
		}
		else if (newValueData.DHBPME < newValueData.DHBPMB) {
			this.setGridError('10113');
			return false;
		}
		else if (newValueData.DHBYAL.trim() == "0" && newValueData.DHIORJ.trim() == "J") {
			this.setGridError('10111');
			return false;
		}
		else if (newValueData.DHB1ST.trim() == "" || newValueData.DHBLST.trim() == "") {
			this.setGridError('10110');
			return false;
		}
		return true;
	}
	setGridError = (errorId, parameterValues = []) => {
		this.setState({ hasError: true, errorId, parameterValues }, () => {
			setTimeout(() => {
				this.setState({ hasError: false, errorId: false })
			}, 3e3);
		})
	}
	handleItemSelection = action => {
		switch (action) {
			case LABEL_COPY:
				this.handleCopyDeletePopup('copyDeal', true)
				break;
			case LABEL_DELETE:
				this.handleCopyDeletePopup('openDeletePopup', true)
				break;
			//~~~CreateNewFramework--JVK
			case 'newnote':
				this.setState({ isOpenNote: true });
				break;
			//~~~CreateNewFramework--JVK
		}
	}
	handleCopyDeletePopup = (popup, val) => {
		if (popup == 'copyDeal') {
			this.setState({ copyDeal: val })
		} else if (popup == 'openDeletePopup') {
			this.setState({ openDeletePopup: val })
		}
	}
	handleChangeValue(key, val, field) {
		if (val || val == "") {
			this.props.setValueData({ key, val, field });
			this.setState({ isSaveDataDisabled: false })
		}
	}

	onContextMenuChange = (e, value, check = false, filters = false, title = false) => {
		let defaultFilters = filters;
		let toPage = value;
		let displayName = title;
		onChangeContextMenu(this.props, e, toPage, defaultFilters, displayName);
		this.props.setSelectedValueForTabs('Show Me');
	}

	handleClose = bodyId => {
		this.setState({ showConfirmationDialog: false });
		switch (bodyId) {
			case 'E14029':
				this.closeCurrentTab();
				//need to close the current Tab
				break;
			case 'E10175':
				this.setState({ copyDeal: false });
				break;
			case '28648':
				this.closeCurrentTab();
				//need to close the current Tab
				break;
		}

	}

	closeCurrentTab = () => {
		this.props.setNoDataCallBackValue(true);
		var paramsString = window.location.search;
		if (paramsString && paramsString.length) {
			let paramsArray = paramsString.split("?");
			if (paramsArray && paramsArray.length && paramsArray.length > 1) {
				let params = paramsArray[1].split("&");
				let tabId = params[0].split("=")[1];
				let breadCrumbId = params[1].split("=")[1];
				this.props.removeCurrentRecordObj(tabId, breadCrumbId);
			}
		}
	}
	setErrorMessageForApplyChangestoItems = errorId => {
		let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
		values.push(errorId);
		this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
	}
	handleApplyChangestoItems = (val) => {
		if (val) {
			const { valueData, newValueData } = this.props.dealPropertiesPage;
			if (Object.keys(valueData).length && Object.keys(newValueData).length &&
				(JSON.stringify(valueData) == JSON.stringify(newValueData))) {
				this.setErrorMessageForApplyChangestoItems('E10184')
				this.setState({ applyChangestoItems: false })
			}
			else {
				this.setState({ applyChangestoItems: val })
			}
		} else {
			this.props.setOldValueData()
			this.setState({ applyChangestoItems: val })
		}
	}
	closeSaveDialog = () => {
		this.setState({ showSaveDialog: false })
	}
	yesSaveDialog = () => {
		this.setState({ showSaveDialog: false, applyChangestoItems: true })

	}
	noSaveDialog = () => {
		this.setState({ showSaveDialog: false })
		this.saveData()
	}
	saveData = () => {
		//deal allowance update
		const { rowdata, newValueData } = this.props.dealPropertiesPage
		if (rowdata && Array.isArray(rowdata) && rowdata.length) {
			this.props.dealAllowanceUpdate(rowdata)
		}
		//deal header update
		this.props.dealDetailsUpdate(newValueData)
	}

	handleManageItems = (val) => {
		this.setState({ manageItemsButton: val })
	}
	handleModelDeal = (val) => {
		this.setState({ modelDealButton: val })
	}
	handleDialogClose = (dialog) => {
		this.setState({ [dialog]: false });
	}
	isActionDisabled = (action) => {
		  switch (action) {
			case '25212':
				return false || !this.state.canUpdateComponent.update;
			case '25211':
				return false || !this.state.canUpdateComponent.update;
			case 'modelDeal':
				return false || !this.state.canUpdateComponent.update;
			case 'manageItems':
				return false || !this.state.canUpdateComponent.update;
			case 'applyChangestoItems':
				if(this.state.tab=="0"){
					return false || !this.state.canUpdateComponent.update;
				}
				else if(this.state.tab=="1")
				  return true 
				else  
				return false || !this.state.canUpdateComponent.update;
		  }
	}
	render() {
		const {
			classes, globalDateFormat, filterCriteriaDetails, pageFilterOptions, globalFilterOptions,
			columnDefs, currentPage, currentOwnerName, isShowContextMenu, globalSecurityFilterList } = this.props;
		const {
			loading, dealSummaryLabelsData, valueData, newValueData, rowIndex, currentRecordData, hasNext,
			hasPrevious, vendorData, dealColumnDefs, rowdataforItemOnDeal, filterProps, isModelSuccess, itemsOnDealLabelsData, modelDealLabelsData, bracketLabelJson } = this.props.dealPropertiesPage;

		const { canUpdateComponent, isSaveDataDisabled, headerData, tab, applyChangestoItems, manageItemsButton, modelDealButton } = this.state;
		let contextMenu = updateBreadCrumbContextMenu(this.props) || [];
		return (
			<React.Fragment>
				{this.state.hasError ? (
					<div>
						<GridErrorMessages
							errorMessageLabels={this.props.errorMessageLabels}
							popUp
							sethaserror={this.sethaserror}
							id={this.state.errorId ? this.state.errorId : this.props.ServerError} />
					</div>) : ('')}
				<Header
					tab={tab}
					filters={this.props.filters}
					parentSubPage={DEAL_PROPERTIES_PAGE}
					contextMenu={contextMenu}
					fromListPage={this.state.fromListPage}
					onContextMenuChange={this.onContextMenuChange}
					rowIndex={rowIndex}
					dealPropertiesPage={this.props.dealPropertiesPage}
					handleDealHeaderFilterClick={this.handleDealHeaderFilterClick}
					hasNext={hasNext}
					hasPrevious={hasPrevious}
					dealData={headerData}
					vendorData={vendorData}
					currentRecordData={currentRecordData}
					handleDealHeaderSaveClick={() => this.onSaveData()}
					handleDealHeaderLeftArrowClick={this.handleDealHeaderLeftArrowClick}
					handleDealHeaderRightArrowClick={this.handleDealHeaderRightArrowClick}
					saveDisabled={isSaveDataDisabled}
					setSaveData={val => { this.setState({ isSaveDataDisabled: !val }); }}
					globalDateFormat={globalDateFormat}
					filterCriteriaDetails={filterCriteriaDetails}
					pageFilterOptions={pageFilterOptions}
					globalFilterOptions={globalFilterOptions}
					columnDefs={this.state.columnDefs}
					currentPage={DEALS_LIST_PAGE}
					parentPage={DEALS_LIST_PAGE}
					handleDealHeaderActionItemSelection={this.handleItemSelection}
					canUpdateComponent={this.state.canUpdateComponent}
					isShowContextMenu={isShowContextMenu}
					handleApplyChangestoItems={this.handleApplyChangestoItems}
					handleManageItems={(data) => this.handleManageItems(data)}
					handleModelDeal={(data) => this.handleModelDeal(data)}
					manageItemsButton={this.state.manageItemsButton}
					modelDealButton={this.state.modelDealButton}
					notesCount={this.state.notesCount}
					isActionDisabled={this.isActionDisabled}
					notesCountWidth={this.state.notesCountWidth} />
				<div className={classes.propertiesContentWrapper}>

					<AppBar
						position="static"
						color="default"
						className="minWidth1100"
					>
						<Tabs
							value={this.state.tab}
							onChange={(evt, val) => { this.handleChangeTab(evt, val) }}
							indicatorColor="primary"
							textColor="primary"
						>
							<Tab value={0}
								label={this.getLabelValue(DEAL_SUMMARY_LABEL_TAB_KEY)}
							/>
							<Tab value={1}
								label={this.getLabelValue(ITEM_ON_DEAL_LABEL_TAB_KEY)}
							/>
						</Tabs>
					</AppBar>

					{tab == 0 && (
						<TabContainer>
							<DealSummary
								loading={loading}
								valueData={valueData}
								newValueData={newValueData}
								currentOwnerName={currentOwnerName}
								handleChangeValue={this.handleChangeValue}
								globalDateFormat={globalDateFormat}
								filterCriteriaDetails={filterCriteriaDetails}
								pageFilterOptions={pageFilterOptions}
								globalFilterOptions={globalFilterOptions}
								columnDefs={columnDefs}
								currentPage={currentPage}
								canUpdateComponent={canUpdateComponent}
								dealSummaryLabelsData={dealSummaryLabelsData}
								dealPropertiesPage={this.props.dealPropertiesPage}
								dealAllowanceUpdate={(data) => this.props.dealAllowanceUpdate(data)}
								setErrorMessageForApplyChangestoItems={(errorId) => this.setErrorMessageForApplyChangestoItems(errorId)}
								setHeaderAndSendAPI={(jsonData, from) => this.setHeaderAndSendAPI(jsonData, from)}
								currentRecordData={currentRecordData}
								setOldValueData={() => this.props.setOldValueData()}
								onAddRec={this.props.onAddRec}
								onRemoveRec={this.props.onRemoveRec}
								onUpdateRec={this.props.onUpdateRec}
								stateData={this.state.stateData}
								onSetDataValueChange={this.props.onSetDataValueChange}
								setUpdateRecordsFlag={this.props.setUpdateRecordsFlag}
								errorMessageLabels={this.props.errorMessageLabels}

							/>
						</TabContainer>)}
					{tab == 1 && (
						<TabContainer>
							<ItemOnDeal
								rowdataforItemOnDeal={rowdataforItemOnDeal}
								currentOwnerName={currentOwnerName}
								globalDateFormat={globalDateFormat}
								filterCriteriaDetails={filterCriteriaDetails}
								pageFilterOptions={pageFilterOptions}
								globalFilterOptions={globalFilterOptions}
								columnDefination={columnDefs}
								currentPage={currentPage}
								canUpdateComponent={canUpdateComponent}
								dealPropertiesPage={this.props.dealPropertiesPage}
								stateData={this.state.stateData}
								errorMessageLabels={this.props.errorMessageLabels}
								valueData={valueData}
								newValueData={newValueData}
								getItemOnDealValueList={this.props.getItemOnDealValueList}
								handleManageItems={this.handleManageItems}
								manageItemsButton={this.state.manageItemsButton}
								itemOnDealDelete={this.props.itemOnDealDelete}
							/>
						</TabContainer>)}
					{loading && <Spinner loading type="list" />}
					{this.state.openFilterPopup && (
						<Filter
							filterCriteriaDetails={filterCriteriaDetails}
							pageFilterOptions={pageFilterOptions}
							globalFilterOptions={globalFilterOptions}
							globalSecurityFilterList={globalSecurityFilterList}
							currentPage={currentPage}
							isOpen={Boolean(this.state.openFilterPopup)}
							ownerName={currentOwnerName}
							columnDefs={dealColumnDefs}
							clearPopupComponent={this.handleDealHeaderFilterClick}
						/>
					)}
					{applyChangestoItems && <ApplyChangestoItems
						handleApplyChangestoItems={this.handleApplyChangestoItems}
						applyChangestoItems={this.state.applyChangestoItems}
						setHeaderAndSendAPI={(jsonData, from) => this.setHeaderAndSendAPI(jsonData, from)}
						currentRecordData={currentRecordData}
						getMassMaintenanceData={(data) => this.props.getMassMaintenanceData(data)}
						getMassMaintenanceAllData={(data, filters) => this.props.getMassMaintenanceAllData(data, filters)}
						valueData={valueData}
						newValueData={newValueData}
						saveData={this.saveData}
					/>}
					{manageItemsButton && <ManageItems
						handleManageItems={this.handleManageItems}
						manageItemsButton={this.state.manageItemsButton}
						getLabelValue={this.getLabelValue}
						handleClose={this.handleClose}
						errorMessageLabels={this.props.errorMessageLabels}
						setHeaderAndSendAPI={(jsonData, from) => this.setHeaderAndSendAPI(jsonData, from)}
						currentRecordData={currentRecordData}
					/>}
					{modelDealButton && <ModelDeal
						handleModelDeal={this.handleModelDeal}
						modelDealButton={this.state.modelDealButton}
						getLabelValue={this.getLabelValue}
						errorMessageLabels={this.props.errorMessageLabels}
						headerJson={{ ...currentRecordData, ...vendorData }}
						modelDealLabelsData={dealSummaryLabelsData}
						modelDealDetailData={valueData}
						currentOwnerName={currentOwnerName}
						globalDateFormat={globalDateFormat}
						filterCriteriaDetails={filterCriteriaDetails}
						pageFilterOptions={pageFilterOptions}
						globalFilterOptions={globalFilterOptions}
						columnDefs={columnDefs}
						currentPage={currentPage}
						canUpdateComponent={canUpdateComponent}
						dealDetailsModel={this.props.dealDetailsModel}
						dealDetailsModelAll={this.props.dealDetailsModelAll}
						isModelSuccess={isModelSuccess}
						setLabelDataFlags={this.props.setLabelDataFlags}
					/>}
					{this.state.copyDeal && dealSummaryLabelsData &&
						<CopyDeal
							tabcards={dealSummaryLabelsData.tabcards}
							copyDeal={this.state.copyDeal}
							valueData={valueData}
							handleDialogClose={this.handleDialogClose}
							vendorData={vendorData}
							propertiesScreen={true}
							onDealCopy={this.props.onDealCopy}
							copyallDealFromProperties={this.props.copyallDealFromProperties}
							globalDateFormat={globalDateFormat}
						></CopyDeal>}
					{this.state.openDeletePopup && (
						<DeleteDialog
							openDeletePopup={this.state.openDeletePopup}
							handleCopyDeletePopup={this.handleCopyDeletePopup}
							headerJson={{ ...currentRecordData, ...vendorData }}
							dealDetailsDelete={this.props.dealDetailsDelete}
							currentRecord={currentRecordData}
							filterPropsFromPage={filterProps}
							dealDetailsDeleteAll={this.props.dealDetailsDeleteAll}
							globalDateFormat={globalDateFormat}
						/>)}
				</div>
				{this.state.showConfirmationDialog && <ConfirmationDialog
					hasError={this.state.hasWarning}
					isOpen={this.state.showConfirmationDialog}
					dialogTitle={this.state.dialogTitle}
					submitText={TEXT_OK}
					handleClose={() => this.handleClose(this.state.dialogBody)}
					handleCancel={() => this.handleClose(this.state.dialogBody)}
					handleSubmit={() => this.handleClose(this.state.dialogBody)}>
					<div>
						{this.state.fromHeaderENG && this.state.dialogBody && this.getLabelValue(this.state.dialogBody)}
						{!this.state.fromHeaderENG && (this.props.errorMessageLabels && this.props.errorMessageLabels[this.state.dialogBody] &&
							this.props.errorMessageLabels[this.state.dialogBody].MTEXT || 'Warning')}
					</div>
				</ConfirmationDialog>
				}
				{this.state.showValueConfirmationDialog && <ConfirmationDialog
					hasError={!this.state.hasWarning}
					hasWarning={this.state.hasWarning}
					isOpen={this.state.showValueConfirmationDialog}
					dialogTitle={this.state.dialogTitle}
					submitText={TEXT_OK}
					handleClose={() => this.closeValueDialog(false)}
					handleCancel={() => this.closeValueDialog(false)}
					handleSubmit={() => this.closeValueDialog(this.state.dialogBody)}>
					<div>
						{(this.props.errorMessageLabels[this.state.dialogContent] && this.props.errorMessageLabels[this.state.dialogContent].MTEXT)
							|| this.state.dialogContent}
					</div>
				</ConfirmationDialog>
				}
				{this.state.showSaveDialog && <ConfirmationDialog
					hasWarning={true}
					isOpen={this.state.showSaveDialog}
					dialogTitle={"52891"}
					submitText={TEXT_YES}
					cancelText={TEXT_NO}
					handleClose={() => this.closeSaveDialog()}
					handleCancel={() => this.noSaveDialog()}
					handleSubmit={() => this.yesSaveDialog()}>
					<div>
						{this.props.errorMessageLabels["E10189"].MTEXT}
					</div>
				</ConfirmationDialog>
				}
				<div id="dealNotes"><DealNotes currentPage={DEALS_LIST_PAGE}

					noteLabelJson={bracketLabelJson}
					bracketsNotesFilterObj={this.state.bracketsNotesFilterObj}

					fromPage={DEALS_LIST_PAGE}
					currentRecordData={valueData}
					updatedNotesData={this.updatedNotesData}
					canUpdateComponent={this.state.canUpdateComponent}
					//Security
					/* Dispatch notes count from child to Parent to show it on header */
					setNotesCount={this.setNotesCount}
					//~~~CreateNewFramework--JVK
					isOpenNote={this.state.isOpenNote}
					closeNote={(flag) => this.setState({ isOpenNote: flag })}
					//~~~CreateNewFramework--JVK
					columnDefs={columnDefs}></DealNotes>
				</div>
			</React.Fragment>);
	}
}
export default compose(
	withStyles(style),
)(DealProperties);
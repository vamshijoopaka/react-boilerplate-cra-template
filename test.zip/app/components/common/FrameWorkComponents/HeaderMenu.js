import React from 'react';
import MenuIcon from '@material-ui/icons/Menu'
import ArrowDownwardIcon from '@material-ui/icons/ArrowDownward';
import ArrowUpwardIcon from '@material-ui/icons/ArrowUpward';
import { withStyles } from '@material-ui/core/styles';
import theme from '../../../jda-gcp-theme';
import { COLUMN_VALUE_ACCESSOR } from '../constants';

const styles = theme => ({
    sortSVG: {
        width: '12px !important'
    }
})
class HeaderMenu extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
        };
        this.mouseClick = this.mouseClick.bind(this);
        this.sendPostSort = this.sendPostSort.bind(this);
    }
    getSortOrder = (sort) => {
        if (!this.props.column.colDef.sortingOrder) return '';
        let index = this.props.column.colDef.sortingOrder.indexOf(sort) + 1;
        index = index >= this.props.column.colDef.sortingOrder.length ? 0 : index;
        return this.props.column.colDef.sortingOrder[index];
    }
    sendPostSort = (event) => {
        let sort = [
            {
                colId: this.props.column.colDef[COLUMN_VALUE_ACCESSOR].trim(),
                sort: this.getSortOrder(this.props.column.colDef.sort)
            }
        ];
        this.props.context.componentParent.props.postSort(sort);
    }

    mouseClick = (event) => {
        event.preventDefault();
        this.props.context.componentParent.openColumnMenu(event, this.props.column.colDef);
    }
    render() {
        const { classes } = this.props;
        let sort = null;
        if (this.props.column.colDef.sortable) {
            if (this.props.column.colDef.sort === 'asc') {
                sort = <ArrowUpwardIcon className={classes.sortSVG} />
            } else if (this.props.column.colDef.sort === 'desc') {
                sort =  <ArrowDownwardIcon className={classes.sortSVG} />
            }
        }
        return (
            <div style={{ display: "inline-flex", alignItems: 'center' }} onContextMenu={this.mouseClick} onClick={this.sendPostSort}>
                {this.props.displayName}
                <div>
                    {sort}
                </div>
            </div>
        )
    }
}
export default (withStyles(styles)(HeaderMenu));
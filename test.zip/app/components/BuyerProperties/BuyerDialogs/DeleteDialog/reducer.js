import produce from 'immer';
import { fromJS } from 'immutable';

import {
  COLUMN_POSITION,
  COLUMN_FIELD_TYPE,
  DROPDOWN_FIELD,
} from 'components/common/constants';

import { getSortableColumns } from 'utils/util';
import {
  GET_BUYERDELETE_LIST,
  GET_BUYERDELETE_LIST_SUCCESS,
  GET_BUYERDELETE_LIST_FAILURE,
  GET_BUYERDELETE_COLUMN_DEFINITION,
  GET_BUYERDELETE_COLUMN_DEFINITION_SUCCESS,
  GET_BUYERDELETE_COLUMN_DEFINITION_FAILURE,
  GET_BUYERDELETE_UPDATE_COLUMN_DEFINITION,
  GET_BUYERDELETE_UPDATE_COLUMN_DEFINITION_SUCCESS,
  GET_BUYERDELETE_UPDATE_COLUMN_DEFINITION_FAILURE,
  RESET_DEFAULTS,
  RESET_DEFAULTS_SUCCESS,
  RESET_DEFAULTS_FAILURE,
  SET_FILTER_VALUES,
  SET_COLUMN_DEFS_LOADED,
  SET_PAGEPROPS,
  SET_APICALL_COUNT,
  GET_BUYERS_LIST,
  GET_BUYERS_LIST_SUCCESS,
  GET_BUYERS_LIST_FAILURE,
  RESET_DATA, // needs to be handled carefully
  LABEL_DATA_FLAGS,
} from './constants';

const initialState = fromJS({
  columnDefs: false,
  columnInfo: false,
  updateColumnsList: false,
  filterProps: false,
  isColumnDefsLoaded: false,
  rowData: false,
  loading: true,
  isAPIProgress: false,
  pageProps: false,
  totalCount: 0,
  moreRecordsAvailable: false,
  apiCallCount: 0,
  buyerListArray: [],
  isAPIforBuyerCopyList: false,
  isAPIforColumns: false,
  isAPIforColumnsUpdate: false,
  isAPIforResetColumns: false,
  isAPIforBuyerList: false,
});

const buyerDeleteReducer = (state = initialState, action) => {
  switch (action.type) {
    case GET_BUYERDELETE_LIST:
      return state.set('loading', true).set('isAPIforBuyerCopyList', false);
    case GET_BUYERDELETE_LIST_SUCCESS:
      const direction = state.get('pageProps').isForwardDirection;
      let { data } = action;
      if (data && data.listArray && data.listArray.length) {
        const count = state.get('apiCallCount');
        const totalCount = 100 * count + data.listArray.length;
        const dataList = data.listArray;
        dataList.forEach(row => {
          row.isSelected = false;
        });

        if (!direction) {
          dataList.reverse();
        }
        return state
          .set('isAPIProgress', false)
          .set('rowData', dataList)
          .set('moreRecordsAvailable', data.moreRecordsAvailable)
          .set('totalCount', totalCount)
          .set('loading', false);
      }
      return state.set('rowData', action.data);
    case GET_BUYERDELETE_LIST_FAILURE:
      return state.state
        .set('loading', false)
        .set('rowData', [])
        .set('isAPIforBuyerCopyList', true);

    case GET_BUYERDELETE_COLUMN_DEFINITION:
      return state.set('loading', true).set('isAPIforColumns', false);
    case GET_BUYERDELETE_COLUMN_DEFINITION_SUCCESS:
      if (action.data && action.data.fields && action.data.fields.length) {
        action.data.fields[0].FDPRFX = "1";
        const columnFields = action.data.fields.filter(
          col => Object.keys(col).length,
        );
        const list = getSortableColumns(
          columnFields,
          COLUMN_POSITION,
          COLUMN_FIELD_TYPE,
          DROPDOWN_FIELD,
          true,
          false,
          true,
        );
        
        return state
          .set('loading', false)
          .set('isColumnDefsLoaded', true)
          .set('updateColumnsList', false)
          .set('columnInfo', action.data.info)
          .set('columnDefs', list);
      }
    case GET_BUYERDELETE_COLUMN_DEFINITION_FAILURE:
      return state
        .set('loading', false)
        .set('isAPIforColumns', true)
        .set('loading', false);

    case GET_BUYERDELETE_UPDATE_COLUMN_DEFINITION:
      return state.set('loading', true).set('isAPIforColumnsUpdate', false);
    case GET_BUYERDELETE_UPDATE_COLUMN_DEFINITION_SUCCESS:
      const updateData = action.data;
      if (
        updateData.message &&
        updateData.message.length &&
        updateData.message.toLowerCase() == 'success'
      ) {
        return state
          .set('updateColumnsList', true)
          .set('loading', true)
          .set('columnDefs', []);
      }
      return state;
    case GET_BUYERDELETE_UPDATE_COLUMN_DEFINITION_FAILURE:
      return state.set('loading', false).set('isAPIforColumnsUpdate', true);

    case RESET_DEFAULTS:
      return state.set('loading', true).set('isAPIforResetColumns', false);
    case RESET_DEFAULTS_SUCCESS:
      return state.set('loading', false);
    case RESET_DEFAULTS_FAILURE:
      return state.set('loading', false).set('isAPIforResetColumns', true);
    case RESET_DATA:
      return initialState;

    case SET_APICALL_COUNT:
      return state.set('apiCallCount', action.data);
    case SET_PAGEPROPS:
      return state.set('pageProps', JSON.parse(JSON.stringify(action.data)));
    case SET_FILTER_VALUES:
      return state.set('filterProps', JSON.parse(JSON.stringify(action.data)));
    case SET_COLUMN_DEFS_LOADED:
      return state.set('loading', true);

    case GET_BUYERS_LIST:
      return state.set('loading', true).set('isAPIforBuyerList', false);
    case GET_BUYERS_LIST_SUCCESS:
      data = action.data;
      if (data && data.listArray && data.listArray.length) {
        return state
          .set('buyerListArray', data.listArray)
          .set('loading', false);
      }
      return state.set('loading', false);
    case GET_BUYERS_LIST_FAILURE:
      return state.set('loading', false).set('isAPIforBuyerList', true);
    case LABEL_DATA_FLAGS:
      return state.set(action.data.key, action.data.value);
    default:
      return state;
  }
};

export default buyerDeleteReducer;

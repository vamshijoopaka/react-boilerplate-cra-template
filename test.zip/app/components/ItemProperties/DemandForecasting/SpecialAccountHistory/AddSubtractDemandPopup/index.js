import React from 'react';
import PropTypes from 'prop-types';
import { MENU_ITEMS } from 'components/common/constants';
import DialogComponent from '../../../../common/DialogComponent';
import FilterCriteria from '../../../../../containers/common/FilterCriteria';
import ItemsEmbeddedList from './ItemsEmbeddedList';
import FormFieldsGenerator from '../../../../common/FormFieldsGenerator';

class AddSubtractDemandPopup extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      isFilterOpen: false,
      menuItems: MENU_ITEMS,
      fieldFilters: [],
      options: {"IITEM": "1",
                "IRFRC": "1"},
      postData: {},
    };
  }

  componentDidMount = () => {
    this.props.getItemsEmbeddedListColumns();
  };

  onSelectGridReady = paramsApi => {
    this.filterCriteriaGridApi = paramsApi;
  };

  updateMenuItems = items => {
    this.setState({
      menuItems: items,
    });
  };

  setSelectSubmit = val => {};

  handleItemSelection = (value,rowData) => {

    let filterData = [];
     filterData.push({ "accessor": "COMP", "operator": "=", "jOpr": "and", "fieldValue": rowData[0]["WCOMP"], "prefixFlag": 0 });
     filterData.push({ "accessor": "WHSE", "operator": "=", "jOpr": "and", "fieldValue": rowData[0]["WWHSE"], "prefixFlag": 0 });
     filterData.push({ "accessor": "VNDR", "operator": "=", "jOpr": "and", "fieldValue": rowData[0]["WVNDR"], "prefixFlag": 0 });
     filterData.push({ "accessor": "ITEM", "operator": "=", "jOpr": "and", "fieldValue": rowData[0]["WITEM"], "prefixFlag": 0 });
     this.setState({fieldFilters : filterData})
    switch (value) {
      case 'itemsFilter':
        this.setState({
          isFilterOpen: true,
        });
        break;
      default:
        break;
    }
  };

  handleChangeValue = (key, value, field) => {
    this.setState(prevState => {
      const { options } = prevState;
      options[`I${key}`] = value;
      return {
        options,
      };
    });
  };

  onSubmit = () => {
    const { itemsEmbeddedList } = this.props;
    const { rowData } = itemsEmbeddedList;
    if (rowData && rowData.length) {
      const postData = {
        HSCOMP: rowData[0].WCOMP,
        HSWHSE: rowData[0].WHSE,
        HSITEM: rowData[0].WITEM,
        HSVNDR: rowData[0].WVNDR,
        BBUYR: '',
        HSACCT: rowData[0].WACCT,
        HSYEAR: '',
        HSFLAG: this.state.options.IITEM || '0',
        HSRFRC: this.state.options.IRFRC || '0',
        HSINCD: rowData[0].WINCD,
      };
      this.props.specialAccountHistoryAction(postData);
    }
    this.props.onClose();
  };

  render() {
    const {
      isOpen,
      cardfields,
      title,
      onClose,
      itemsEmbeddedList,
      canUpdateComponent,
    } = this.props;
    const addSubtractCardFields =
      cardfields && cardfields.length
        ? cardfields
          .filter(cardfield => cardfield.FLDTYPE === 'checkbox')
          .map(field => ({
            ...field,
            dataType: 'checkbox',
            FDFNAM: field.FDFNAM
              ? field.FDFNAM.trim()
              : field.TDEFN.split('_')[1].trim(),
            key: field.FDFNAM
              ? field.FDFNAM.trim()
              : field.TDEFN.split('_')[1].trim(),
            showMassMaintenance: false,
            noMassMaintenance: true,
          }))
        : [];
    return (
      <DialogComponent
        isOpen={isOpen}
        dialogTitle={title}
        handleSubmit={this.onSubmit}
        handleClose={onClose}
        handleCancel={onClose}
        submitText="Submit"
        cancelText="Cancel"
      >
        {this.state.isFilterOpen ? (
          <FilterCriteria
            filterCriteria={{
              open: true,
              apiFlag: 'items',
              parentFlag: 'searchReplaceSelect',
            }}
            currentPage="items"
            onFilterCriteriaReady={this.onSelectGridReady}
            menuItems={this.state.menuItems}
            updateMenuItems={items => this.updateMenuItems(items)}
            enableSubmit={() => this.setSelectSubmit(true)}
            listTitle="Items"
            gridRowSelection="multiple"
            disableRows={[]}
            parentFilterProps={this.state.fieldFilters}
            namespace="searchReplaceSelectFilterCriteria"
            disableColumns
          />
        ) : (
          <ItemsEmbeddedList
            itemsEmbeddedList={itemsEmbeddedList}
            handleItemSelection={this.handleItemSelection}
            canUpdateComponent={canUpdateComponent}
          />
        )}
        {addSubtractCardFields && addSubtractCardFields.length ? (
          <div style={{ padding: 10 }}>
            <FormFieldsGenerator
              fieldsArray={addSubtractCardFields}
              valuesArray={this.state.options}
              handleChangeValue={this.handleChangeValue}
              enableAddButton={() => {}}
              currentPage="itemProperties"
            />
          </div>
        ) : null}
      </DialogComponent>
    );
  }
}

AddSubtractDemandPopup.propTypes = {
  title: PropTypes.string,
  onSubmit: PropTypes.func,
  children: PropTypes.element,
  onClose: PropTypes.func,
  getItemsEmbeddedListColumns: PropTypes.func,
  itemsEmbeddedList: PropTypes.object,
};

export default AddSubtractDemandPopup;

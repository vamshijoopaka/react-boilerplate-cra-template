const selectData = (state) => state.get('EventEffectMaintenanceDialog');

export {selectData};
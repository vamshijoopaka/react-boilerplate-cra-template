/**
 *
 * CompanyProperties
 *
 */

/** Change Log
 * LogStart --  E3C-29099 - Kumar A- 25 August,2021 - 2022.1.0.0 Unified Product
 *              Story: E3C-30006 --Unable to save User Defined Values(PO Control) and validations on these fields are not being applied
                Fixed QA testing issues.
 * LogStart --  E3C-33195 - Kumar A- 16 September,2021 - 2022.1.0.0 Unified Product
 *              Story: E3C-33195 --Code Cleanup
*/

import React from 'react';

import { compose } from 'redux';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { withStyles } from '@material-ui/core';

import { Formik } from 'formik';
import AppBar from '@material-ui/core/AppBar';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import Typography from '@material-ui/core/Typography';
import CompanyControlFactors from './CompanyControlFactors';
import POControl from './POControl';
import DemandForecast from './DemandForecast';
import ForecastingFactorsMatrix from './ForecastingFactorsMatrix/ForecastingFactorsMatrix';
import ClassificationControl from './ClassificationControl/ClassificationControl';
import AltSourceControls from './AltSourceControls';
import NightJobControls from './NightJobControls';
import OrderControl from './OrderControl';
import PlanningControls from './PlanningControls';
import ConstrainedControls from './ConstrainedControls';
import RecordsRetention from './RecordsRetention';
import SystemSetUp from './SystemSetUp';
import ExceptionControl from './ExceptionControl/ExceptionControl';
import ExceptionsMaintenance from './ExceptionsMaintenance/ExceptionsMaintenance';
import { itemClassificationSubmitKeyDS } from './json schemas/item-classification-submit-key';
import { forecastCalculationSubmitKeyDS } from './json schemas/forecast-calculation-submit-key';
import FormattedMessageComponent from 'components/common/FormattedMessageComponent';
import GridErrorMessages from '../common/GridErrorMessages';
import Header from './Header';
import {
  LABEL_LIST_URL_DATA,
  LABEL_LIST_SIM_URL_DATA,
  LABEL_LIST_SIM_COMMON_URL_DATA,
  LABEL_COMPANY_CONTROL_FACTORS,
  LABEL_COMPANY_DEMAND_FORECAST,
  LABEL_COMPANY_FORECAST_FACTOR_MATRIX,
  LABEL_COMPANY_EXCEPTION_CONTROL,
  LABEL_COMPANY_PO_CONTROL,
  LABEL_COMPANY_AC_CONTROL,
  LABEL_COMPANY_ORDER_CONTROL,
  LABEL_COMPANY_NIGHT_JOB_CONTROL,
  LABEL_COMPANY_PLANNING_CONTROL,
  LABEL_COMPANY_CLASSIFICATION_CONTROL,
  LABEL_COMPANY_CONSTRAINED_CONTROL,
  LABEL_COMPANY_RECORD_RETENTIONS,
  LABEL_COMPANY_SYSTEM_SETUP,
  LABEL_COMPANY_EXCEPTION_MAINTENANCE,
  //company_notes begin
  TRIMCOMMON_LABEL_URL_DATA,
  COMPANY_NOTE_LABEL_JSON,
  //company_notes end
} from './constants';

import {
  updateBreadCrumbContextMenu,
  onChangeContextMenu,
} from 'utils/contextMenu';

import {
  getFilterDataFromLocalStorage,
  getUpdateRestrictionOnComponent,
  capitalizeFirstLetter,
} from 'utils/util';

//company_notes_begin
import CompanyNotes from './CompanyNotes';
import { isEqual } from 'lodash';
//company_notes_end

import Spinner from '../common/Spinner';

import { COMPANY_PROPERTIES_PAGE } from '../common/constants';

function TabContainer(props) {
  return (
    <Typography className="minWidth1100" component="div">
      {props.children}
    </Typography>
  );
}

const steps = ['step 1', 'step 2', 'step 3'];

const style = theme => ({
  propertiesContentWrapper: {
    margin: '10px auto',
    fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
    borderRadius: '4px',
    overflow: 'hidden',
    boxShadow: '0 2px 4px var(--secondary-s10)',
    overflowX: 'auto',
  },
  hideContent: {
    display: 'none'
  },
  showContent: {
    display: 'block'
  }
});

class CompanyProperties extends React.PureComponent {
  constructor() {
    super();
    (this.state = {
      tab: 0,
      open: false,
      openNewPlan: false,
      companyConstrainedControlsChangedData: {},
      companyDashboardControlChangedData: {},
      companyRecordRetentionData: {},
      companyRecordRetentionDashboardData: {},
      companyForecastFactorsMatrixChangedData: {},
      companyExceptionControlChangedData: {},
      companyPurchaseOrderControlData: {},
      companySystemSetupData: {},
      companyUdfIDSFields: {},
      companyUdfOSSFields: {},
      companyOrderControlChangedData: {},
      companyOrderControlSSChangedData: {},
      companyClassificationData: {},
      precision: '',
      numericCheckFlag: '',

      activeStep: 0,
      lastActiveStep: 0,
      completed: false,
      isOpen: true,
      disableSubmit: true,
      disableNext: true,
      columnDefs: {},
      companyDataJSON: [],
      parameterValues: [],
      pgmAppError: true,
      isSaveDataDisabled: true,
      // error messaging
      hasError: false,
      errorId: false,
      //company_notes_begin
      companyNotesFilterObj: {},
      updatedNotes: false,
      //company_notes_end
      calendarDataSaveArray: [],
      calendarData: [],
      notesCount: 0,  //E3C30273
      canUpdateComponent: false,
    }),
    this.setCompanyColumnDefs = this.setCompanyColumnDefs.bind(this);
    this.sendCalendarList = this.sendCalendarList.bind(this);
    this.onContextMenuChange = this.onContextMenuChange.bind(this);
  }

  handleChangeTab = (event, value) => {
    this.setState({ tab: value });
    this.props.setDataInTabs("selectedPropertiesTab", value);
  };

  buildSubmitItemClassificationKey = () => {
    // COMPANY values to be soft coded default values;
    const key = {};
    itemClassificationSubmitKeyDS.forEach(row => {
      key[row.COLUMN_NAME] = ""
    });
    key.INCOMP = 'E3T';
    key.INNTYPE = 'U';
    key.INNTIM = '52';
    key.INAITCL = '1';
    key.INAITSL = '1';
    key.TKMETH = 'W';
    return key;
  };

  buildSubmitForecastCalculationKey = () => {
    // COMPANY values to be soft coded default values;
    const key = {};
    forecastCalculationSubmitKeyDS.forEach(row => {
      key[row.COLUMN_NAME] = ""
    });
    key.CFCOMP = 'E3T';
    key.CFSKFR = '0';
    key.CFSKMN = '0';
    key.CFUONL = '0';
    key.CFIMAN = '0';
    key.CFIDIS = '0';
    return key;
  };

  changeConstrainedControlData = values => {
    this.setState({ companyConstrainedControlsChangedData: values });
  };

  changeDashboardControlData = values => {
    this.setState({ companyDashboardControlChangedData: values });
  };

  changeCompanyControlData = (valueCompany, values) => {
    this.setState({
      companySystemSetupData: valueCompany,
      companyOrderControlSSChangedData: values,
    });
  };

  changeForecastFactorsMatrixData = values => {
    this.setState({ companyForecastFactorsMatrixChangedData: values });
  };

  changeExceptionControlData = values => {
    this.setState({ companyExceptionControlChangedData: values });
  };

  changeRecordRetentionData = (valueCompany, valueDashboard) => {
    this.setState({ companyRecordRetentionDashboardData: valueDashboard });
    this.setState({ companyRecordRetentionData: valueCompany });
  };

  changePurchaseOrderControlsData = (
    valueCompany,
    valuesCompanyUdfIDFields,
    valueCompanyUdfOSFields,
    valuesOrderControl,
  ) => {
    this.setState({
      companyPurchaseOrderControlData: valueCompany,
      companyUdfIDSFields: valuesCompanyUdfIDFields,
      companyUdfOSSFields: valueCompanyUdfOSFields,
      companyOrderControlChangedData: valuesOrderControl,
    });
  };

  setCompanyColumnDefs(data) {
    if (data && data.length) {
      let vData = data.find(
        column => column[COLUMN_VALUE_ACCESSOR].trim() == 'VNAME',
      );
      vData = setNumberFields([vData]);
      return vData;
    }
  }

  sethaserror = val => {
    this.setState({ hasError: val });
  };

  getLabelValue(id) {
    return <FormattedMessageComponent id={id} />;
  }

  componentDidMount() {
    if (this.props.location && this.props.location.state) {
      this.props.setCurrentRecord(this.props.location.state.data);
      this.setState({ columnDefs: this.props.location.state.columnDefs });
      const data = this.setCompanyColumnDefs(
        this.props.location.state.columnDefs,
      );
      if (data) {
        this.setState({ companyDataJSON: data });
      }
      this.props.setRowIndex(this.props.location.state.rowIndex);
    }
    let currentPage = COMPANY_PROPERTIES_PAGE;
    this.props.onLoadCurrentPage(currentPage);
    this.props.setIsShowContextMenu(true);
    const labelFilters = LABEL_LIST_URL_DATA;
    this.props.getLabelsList({
      recordData: labelFilters,
      currentPage: 'companyproperties',
    });
    const labelSimFilters = LABEL_LIST_SIM_URL_DATA;
    this.props.getLabelsSimList({
      recordData: labelSimFilters,
      currentPage: 'companyproperties',
    });
    const labelSimCommonFilters = LABEL_LIST_SIM_COMMON_URL_DATA;
    this.props.getLabelsSimCommonList({
      recordData: labelSimCommonFilters,
      currentPage: 'companyproperties',
    });
    this.setState({ isSaveDataDisabled: true });
    const data = 'CCOMP=E3T';
    this.props.getValueList(data);
    if (Object.keys(this.state.companyOrderControlChangedData).length == 0) {
      this.setState({ companyOrderControlChangedData: this.props.companyOrderDetailData })
    }
    this.setState({ companyUdfOSSFields: this.props.companyUdfOSFieldsData });
    this.setState({ companyUdfIDSFields: this.props.companyUdfIDFieldsData });
    this.setState({ companyForecastFactorsMatrixChangedData: this.props.companyForecastMatrixData });
    this.setState({ companyExceptionControlChangedData: this.props.companyExceptionControlData });
    this.setState({ companyConstrainedControlsChangedData: this.props.companyConstrainedControlsData }); //E3C-32853, 6/16/21, Kumar
    this.setState({ companyClassificationData: this.props.companyData });
    //company_notes_begin
    this.setState({ updatedNotes: false });
    this.props.getTrimCommonLabelJson({ recordData: TRIMCOMMON_LABEL_URL_DATA, currentPage: COMPANY_PROPERTIES_PAGE });
    this.props.setFromPage('company');
    //company_notes_end
    //To be in same tab
    let isLocalStorageValuesExists = false;
    var paramsString = window.location.search;
    if (paramsString && paramsString.length) {
      let paramsArray = paramsString.split("?");
      if (paramsArray && paramsArray.length && paramsArray.length > 1) {
        let params = paramsArray[1].split("&");
        let tabId = params[0].split("=")[1];
        let breadCrumbId = params[1].split("=")[1];
        let localStorageValues = getFilterDataFromLocalStorage(tabId, breadCrumbId);
        if (localStorageValues && Object.keys(localStorageValues) && Object.keys(localStorageValues).length) {
          isLocalStorageValuesExists = true;
          let itemData = localStorageValues.item_data;
          if (itemData) {
            if (itemData.selectedPropertiesTab) {
              this.setState({ tab: itemData.selectedPropertiesTab });//Ajit Saving previously visitedtab
            }
          }
        }

      }
    }

    let canUpdateComponent = getUpdateRestrictionOnComponent(capitalizeFirstLetter(COMPANY_PROPERTIES_PAGE), this.props.authorizedComponentsList);
    this.setState({ canUpdateComponent });
  }


  componentDidUpdate(prevProps) {
    // company_notes_RRUDRA_begin
    if ((Object.keys(this.state.companyNotesFilterObj).length === 0 && this.props.companyData) || (this.props.companyData && !isEqual(this.props.companyData, prevProps.companyData))) {
      let obj = {};
      if (this.props.companyData['CCOMP']) {
        obj['companyId'] = this.props.companyData['CCOMP'];
        this.setState({ companyNotesFilterObj: JSON.parse(JSON.stringify(obj)) });
      }
    }
    // company_notes_RRUDRA_end
    const { saveSuccess } = this.props.CompanyPropertiesData;
    if (saveSuccess) {
      const data = 'CCOMP=E3T';
      this.props.getValueListReload(data);
      this.props.setSaveSuccessFalse(false);
      this.setState({ isSaveDataDisabled: true });
    }

    if (prevProps.authorizedComponentsList !== this.props.authorizedComponentsList) {
      let canUpdateComponent = getUpdateRestrictionOnComponent(capitalizeFirstLetter(COMPANY_PROPERTIES_PAGE), this.props.authorizedComponentsList);
      this.setState({ canUpdateComponent });
    }
  }

  // company_notes_RRUDRA_begin
  updatedNotesData = () => {
    this.setState({ updatedNotes: true });
  }
  // company_notes_RRUDRA_end

  setSaveDataValue = (value) => {
    this.setState({ isSaveDataDisabled: !value });
  }

  calendarDataChange = (data, columnName, value) => {
    let savDataFoundFlag = false;
    let item = false;
    if (this.state.calendarDataSaveArray.length != 0) {
      let calendarDataSaveArray = this.state.calendarDataSaveArray;
      for (var d in calendarDataSaveArray) {
        if (calendarDataSaveArray[d]['AYEAR'] == data['AYEAR']) {
          savDataFoundFlag = true;
          let item = { ...calendarDataSaveArray[d] };
          item['AADJMT'] = value;
          calendarDataSaveArray[d] = item;
          this.setState({ calendarDataSaveArray });
        }
      }
    }
    if (!savDataFoundFlag) {
      let dataNew = [];
      dataNew['AYEAR'] = data['AYEAR'];
      dataNew['AADJMT'] = value;
      dataNew['ACOMP'] = data['ACOMP'];
      dataNew['ACNAME'] = data['CNAME'];
      item = this.state.calendarDataSaveArray
      item.push(dataNew);
      this.setState({ calendarDataSaveArray: item })
    }
  }

  sendCalendarList = data => {
    this.setState({ calendarData: data })
  }

  //Company_notes get Notes count
  setNotesCount = (count) => {
    if (this.state.notesCount != count) {
      this.setState({ notesCount: count })
    }
  }


  onContextMenuChange = (e, value, check = false, filters = false, title = false) => {
    let defaultFilters = filters;
    let toPage = value;
    let displayName = title;

    onChangeContextMenu(this.props, e, toPage, defaultFilters, displayName);
    this.props.setSelectedValueForTabs('Show Me');
  }

  render() {
    const company = this.props.companyData;
    const companyForecastMatrix = this.props.companyForecastMatrixData;
    const companyExceptionControl = this.props.companyExceptionControlData;
    const companyConstrainedControls = this.props.companyConstrainedControlsData;
    const companyOrderDetail = this.props.companyOrderDetailData;
    const companyDashboard = this.props.companyDashboardData;
    const companyCalendarAdjustmentList = this.props
      .companyCalendarAdjustmentListData;
    const companyExceptionMaintenanceList = this.props
      .companyExceptionMaintenanceListData;
    const itemClassificationSubmit = this.buildSubmitItemClassificationKey();
    const {
      tab,
      companyUdfIDSFields,
      companyUdfOSSFields,
      companyOrderControlChangedData,
      companyClassificationData,
    } = this.state;
    const {
      classes,
      globalDateFormat,
      filterCriteriaDetails,
      pageFilterOptions,
      globalFilterOptions,
      messages,
    } = this.props;
    const { loading, companyControlFactorsLabelsData, trimCommonLabelJson, submitItemLabelsData,
      saveSuccess, pgmAppError1, pgmAppError2, newValueData, addCalendarLabelsData, forecastCalculationLabelsData,
      detailExceptionLabelsData, newExceptionLabelsData } = this.props.CompanyPropertiesData;
    const { tabcards } = companyControlFactorsLabelsData;
    const hideLoader = !loading && tabcards && tabcards.length;
    let masterLoader = loading;
    if (company && companyForecastMatrix && companyExceptionControl && companyConstrainedControls &&
      companyOrderDetail && companyDashboard && companyCalendarAdjustmentList && companyExceptionMaintenanceList &&
      newValueData) {
      let contextMenu = updateBreadCrumbContextMenu(this.props, company) || [];
      return (
        <React.Fragment>
          {masterLoader && <Spinner loading type='list' />}
          <div>
            {this.state.hasError ? (
              <div>
                <GridErrorMessages
                  errorMessageLabels={this.props.errorMessageLabels}
                  popUp
                  sethaserror={this.sethaserror}
                  replaceValues={this.state.parameterValues}
                  id={
                    this.state.errorId ? this.state.errorId : this.props.ServerError
                  }
                />
              </div>
            ) : (
              ''
            )}

            <div>
              <Formik
                initialValues={this.props.companyData}
                enableReinitialize
                render={({ values, handleChange }) => (
                  <form>
                    <Header
                      CompanyPropertiesData={this.props.CompanyPropertiesData}
                      companyRecordRetentionData={
                        this.state.companyRecordRetentionData
                      }
                      companyRecordRetentionDashboardData={
                        this.state.companyRecordRetentionDashboardData
                      }
                      companyForecastFactorsMatrixChangedData={
                        this.state.companyForecastFactorsMatrixChangedData
                      }
                      companyExceptionControlChangedData={
                        this.state.companyExceptionControlChangedData
                      }
                      companyPurchaseOrderControlData={
                        this.state.companyPurchaseOrderControlData
                      }
                      companyUdfIDSFields={this.state.companyUdfIDSFields}
                      companyUdfOSSFields={this.state.companyUdfOSSFields}
                      companyOrderControlChangedData={
                        this.state.companyOrderControlChangedData
                      }
                      companyClassificationData={this.state.companyClassificationData}
                      newOrderDetailData={this.props.CompanyPropertiesData.newOrderDetailData}
                      errorMessageLabels={this.props.errorMessageLabels}
                      ServerError={this.props.ServerError}
                      saveDisabled={this.state.isSaveDataDisabled}
                      companySystemSetupData={this.state.companySystemSetupData}
                      setSaveData={val => {
                        this.setState({ isSaveDataDisabled: !val });
                      }}
                      onSaveCompanyPurchaseOrderControlIDData={
                        this.props.onSaveCompanyPurchaseOrderControlIDData
                      }
                      onSaveCompanyPurchaseOrderControlOSData={
                        this.props.onSaveCompanyPurchaseOrderControlOSData
                      }
                      onSaveCompanyConstarinedControlData={
                        this.props.onSaveCompanyConstarinedControlData
                      }
                      onSaveCompanyData={this.props.onSaveCompanyData}
                      onSaveCompanyOrderControlData={
                        this.props.onSaveCompanyOrderControlData
                      }
                      onSaveCompanyDashboardControlData={
                        this.props.onSaveCompanyDashboardControlData
                      }
                      onSaveCompanyExceptionControlData={
                        this.props.onSaveCompanyExceptionControlData
                      }
                      onSaveCompanyForecastFactorsMatrixData={
                        this.props.onSaveCompanyForecastFactorsMatrixData
                      }
                      showConfirmationDialog={
                        this.props.showConfirmationDialog
                      }
                      warehouseDataList={this.props.warehouseDataList}
                      onForecastCalculationSubmit={
                        this.props.onForecastCalculationSubmit
                      }
                      companyData={this.props.companyData}
                      pgmAppError1={pgmAppError1}
                      pgmAppError2={pgmAppError2}
                      saveSuccess={saveSuccess}
                      calendarDataSaveArray={this.state.calendarDataSaveArray}
                      onCalendarAjsutmentModify={
                        this.props.onCalendarAjsutmentModify
                      }
                      calendarList={this.state.calendarData}
                      forecastCalculationLabelsData={forecastCalculationLabelsData}
                      currentPage="companyControlFactors"
                      onContextMenuChange={this.onContextMenuChange}
                      contextMenu={contextMenu}
                      isShowContextMenu={this.props.isShowContextMenu}
                      notesCount={this.state.notesCount}
                      canUpdateComponent={this.state.canUpdateComponent}
                      notesCountWidth={this.state.notesCount < 10 ? '12px' : '21px'}
                      onCalendarAjsutmentSubmit={this.props.onCalendarAjsutmentSubmit}
                      getValueListReload={(data) => this.props.getValueListReload(data)}
                      //~~~CreateNewFramework--JVK
                      setisOpenNote={() => this.setState({ isOpenNote: true })}
                    //~~~CreateNewFramework--JVK
                    />
                    <div>
                      <div className={classes.propertiesContentWrapper}>
                        <AppBar
                          position="static"
                          color="default"
                          className="minWidth1100"
                        >
                          <Tabs
                            value={this.state.tab}
                            onChange={(evt, val) => {
                              this.handleChangeTab(evt, val);
                            }}
                            indicatorColor="primary"
                            textColor="primary"
                            variant="scrollable"
                            scrollButtons="auto"
                          >
                            <Tab
                              label={this.getLabelValue(
                                LABEL_COMPANY_CONTROL_FACTORS,
                              )}
                            />
                            <Tab
                              label={this.getLabelValue(
                                LABEL_COMPANY_DEMAND_FORECAST,
                              )}
                            />
                            <Tab
                              label={this.getLabelValue(
                                LABEL_COMPANY_FORECAST_FACTOR_MATRIX,
                              )}
                            />
                            <Tab
                              label={this.getLabelValue(
                                LABEL_COMPANY_EXCEPTION_CONTROL,
                              )}
                            />
                            <Tab
                              label={this.getLabelValue(
                                LABEL_COMPANY_PO_CONTROL,
                              )}
                            />
                            <Tab
                              label={this.getLabelValue(
                                LABEL_COMPANY_ORDER_CONTROL,
                              )}
                            />
                            <Tab
                              label={this.getLabelValue(
                                LABEL_COMPANY_NIGHT_JOB_CONTROL,
                              )}
                            />
                            <Tab
                              label={this.getLabelValue(
                                LABEL_COMPANY_PLANNING_CONTROL,
                              )}
                            />
                            <Tab
                              label={this.getLabelValue(
                                LABEL_COMPANY_CLASSIFICATION_CONTROL,
                              )}
                            />
                            <Tab
                              label={this.getLabelValue(
                                LABEL_COMPANY_CONSTRAINED_CONTROL,
                              )}
                              disabled={company['CCONST'] > 0 ? false : true}
                            />
                            <Tab
                              label={this.getLabelValue(
                                LABEL_COMPANY_RECORD_RETENTIONS,
                              )}
                            />
                            <Tab
                              label={this.getLabelValue(
                                LABEL_COMPANY_SYSTEM_SETUP,
                              )}
                            />
                            <Tab
                              label={this.getLabelValue(
                                LABEL_COMPANY_AC_CONTROL,
                              )}
                            />
                            < Tab
                              label={
                                this.getLabelValue(
                                  LABEL_COMPANY_EXCEPTION_MAINTENANCE,
                                )
                              }
                            />
                          </Tabs>
                        </AppBar>
                        {this.props.CompanyPropertiesData.companyControlFactorsLabelsData.tabcards && tab == 0 && (
                          <TabContainer>
                            <CompanyControlFactors
                              color="primary"
                              CompanyPropertiesData={this.props.CompanyPropertiesData}
                              companyData={company}
                              handleChange={handleChange}
                              values={values}
                              setValueData={this.props.setValueData}
                              setSaveData={val => {
                                this.setState({ isSaveDataDisabled: !val });
                              }}
                              globalDateFormat={globalDateFormat}
                              filterCriteriaDetails={filterCriteriaDetails}
                              pageFilterOptions={pageFilterOptions}
                              globalFilterOptions={globalFilterOptions}
                              columnDefs={this.state.columnDefs}
                              currentPage="companyControlFactors"
                              canUpdateComponent={this.state.canUpdateComponent}
                            />
                          </TabContainer>
                        )}
                        {tab == 1 && (
                          <TabContainer>
                            <DemandForecast
                              color="primary"
                              CompanyPropertiesData={this.props.CompanyPropertiesData}
                              companyData={company}
                              handleChange={handleChange}
                              values={values}
                              setValueData={this.props.setValueData}
                              setSaveData={val => {
                                this.setState({ isSaveDataDisabled: !val });
                              }}
                              globalDateFormat={globalDateFormat}
                              filterCriteriaDetails={filterCriteriaDetails}
                              pageFilterOptions={pageFilterOptions}
                              globalFilterOptions={globalFilterOptions}
                              columnDefs={this.state.columnDefs}
                              currentPage="companyControlFactors"
                              canUpdateComponent={this.state.canUpdateComponent}
                            />
                          </TabContainer>
                        )}
                        {tab == 4 && <Formik    // E3C-30006 , 8/25/21, Kumar
                          initialValues={{
                            company,
                            companyUdfIDSFields,
                            companyUdfOSSFields,
                            companyOrderControlChangedData,
                          }}
                          enableReinitialize
                          render={({ values, handleChange }) => (
                            <form>
                              {Object.keys(values).length > 0 && (
                                <TabContainer>
                                  <POControl
                                    CompanyPropertiesData={
                                      this.props.CompanyPropertiesData
                                    }
                                    companyData={company}
                                    handleChange={handleChange}
                                    values={values}
                                    companyOrderDetailData={companyOrderDetail}
                                    setValueData={this.props.setValueData}
                                    setValueJobControlData={
                                      this.props.setValueJobControlData
                                    }
                                    setSaveData={val => {
                                      this.setState({ isSaveDataDisabled: !val });
                                    }}
                                    globalDateFormat={globalDateFormat}
                                    filterCriteriaDetails={filterCriteriaDetails}
                                    pageFilterOptions={pageFilterOptions}
                                    globalFilterOptions={globalFilterOptions}
                                    columnDefs={this.state.columnDefs}
                                    changePurchaseOrderControlsData={
                                      this.changePurchaseOrderControlsData
                                    }
                                    validProgramLibrary1={
                                      this.props.validProgramLibrary1
                                    }
                                    validProgramLibrary2={
                                      this.props.validProgramLibrary2
                                    }
                                    currentPage={'companyControlFactors'}
                                    setSaveDataValue={this.setSaveDataValue}
                                    canUpdateComponent={this.state.canUpdateComponent}
                                    messages={messages}
                                  />
                                </TabContainer>
                              )}
                            </form>
                          )}
                        />} {/* E3C-30006 , 8/25/21, Kumar */}
                        {tab == 12 && (
                          <TabContainer>
                            <AltSourceControls
                              color="primary"
                              CompanyPropertiesData={this.props.CompanyPropertiesData}
                              companyData={company}
                              handleChange={handleChange}
                              values={values}
                              setValueData={this.props.setValueData}
                              setSaveData={val => {
                                this.setState({ isSaveDataDisabled: !val });
                              }}
                              globalDateFormat={globalDateFormat}
                              filterCriteriaDetails={filterCriteriaDetails}
                              pageFilterOptions={pageFilterOptions}
                              globalFilterOptions={globalFilterOptions}
                              columnDefs={this.state.columnDefs}
                              currentPage="companyControlFactors"
                              canUpdateComponent={this.state.canUpdateComponent}
                            />
                          </TabContainer>
                        )}
                        {tab == 5 && (
                          <TabContainer>
                            <OrderControl
                              CompanyPropertiesData={this.props.CompanyPropertiesData}
                              companyData={company}
                              setValueData={this.props.setValueData}
                              handleChange={handleChange}
                              setSaveData={val => {
                                this.setState({ isSaveDataDisabled: !val });
                              }}
                              values={values}
                              currentPage={'companyControlFactors'}
                              canUpdateComponent={this.state.canUpdateComponent}
                            />
                          </TabContainer>
                        )}
                        {tab == 6 && (
                          <TabContainer>
                            <NightJobControls
                              CompanyPropertiesData={this.props.CompanyPropertiesData}
                              companyData={company}
                              setValueData={this.props.setValueData}
                              handleChange={handleChange}
                              setSaveData={val => {
                                this.setState({ isSaveDataDisabled: !val });
                              }}
                              values={values}
                              currentPage={'companyControlFactors'}
                              canUpdateComponent={this.state.canUpdateComponent}
                            />
                          </TabContainer>
                        )}
                        {tab == 7 && (
                          <TabContainer>
                            <PlanningControls
                              CompanyPropertiesData={this.props.CompanyPropertiesData}
                              companyData={company}
                              setValueData={this.props.setValueData}
                              handleChange={handleChange}
                              setSaveData={val => {
                                this.setState({ isSaveDataDisabled: !val });
                              }}
                              values={values}
                              currentPage={'companyControlFactors'}
                              canUpdateComponent={this.state.canUpdateComponent}
                            />
                          </TabContainer>
                        )}
                        {tab == 13 && (
                          <TabContainer>
                            <ExceptionsMaintenance
                              companyData={company}
                              companyForecastMatrixData={companyForecastMatrix}
                              companyExceptionMaintenanceListData={
                                companyExceptionMaintenanceList
                              }
                              handleChange={handleChange}
                              values={values}
                              setValueData={this.props.setValueData}
                              processModifyExceptionData={
                                this.props.processModifyExceptionData
                              }
                              processModifyExceptionDeleteData={
                                this.props.processModifyExceptionDeleteData
                              }
                              processAddExceptionData={
                                this.props.processAddExceptionData
                              }
                              newExceptionLabelsData={newExceptionLabelsData}
                              detailExceptionLabelsData={detailExceptionLabelsData}
                              warehouseDataList={this.props.warehouseDataList}
                              errorMessageLabels={this.props.errorMessageLabels}
                              onLoadCompanyCalendarAdjustmentList={this.props.onLoadCompanyCalendarAdjustmentList}
                              currentPage={'companyControlFactors'}
                              messages={messages}
                              canUpdateComponent={this.state.canUpdateComponent}
                            />
                          </TabContainer>
                        )}
                      </div>
                    </div>
                  </form>
                )}
              />
              <Formik
                initialValues={this.state.companyForecastFactorsMatrixChangedData}
                enableReinitialize
                render={({ values, handleChange }) => (
                  <form>
                    {Object.keys(values).length > 0 && tab == 2 && (
                      <TabContainer>
                        <ForecastingFactorsMatrix
                          companyData={company}
                          companyForecastMatrixData={companyForecastMatrix}
                          handleChange={handleChange}
                          setValueData={this.props.setValueData}
                          changeForecastFactorsMatrixData={
                            this.changeForecastFactorsMatrixData
                          }
                          setSaveData={val => {
                            this.setState({ isSaveDataDisabled: !val });
                          }}
                          setSaveDataValue={this.setSaveDataValue}
                          values={values}
                          currentPage={'companyControlFactors'}
                          canUpdateComponent={this.state.canUpdateComponent}
                          messages={messages} //E3C-30006, 6/29/21, Kumar
                        />
                      </TabContainer>
                    )}
                  </form>
                )}
              />
              <Formik
                initialValues={this.state.companyExceptionControlChangedData}
                enableReinitialize
                render={({ values, handleChange }) => (
                  <form>
                    {Object.keys(values).length > 0 && tab == 3 && (
                      <TabContainer>
                        <ExceptionControl
                          companyData={company}
                          companyExceptionControlData={companyExceptionControl}
                          handleChange={handleChange}
                          setValueData={this.props.setValueData}
                          setSaveData={val => {
                            this.setState({ isSaveDataDisabled: !val });
                          }}
                          setSaveDataValue={this.setSaveDataValue}
                          changeExceptionControlData={this.changeExceptionControlData}
                          values={values}
                          currentPage="companyControlFactors"
                          canUpdateComponent={this.state.canUpdateComponent}
                        />
                      </TabContainer>
                    )}
                  </form>
                )}
              />
              <Formik
                initialValues={{
                  companyClassificationData,
                  itemClassificationSubmit,
                }}
                enableReinitialize
                render={({ values, handleChange }) => (
                  <form>
                    {Object.keys(values).length > 0 && tab == 8 && (
                      <TabContainer>
                        <ClassificationControl
                          companyData={company}
                          handleChange={handleChange}
                          values={values}
                          setValueData={this.props.setValueData}
                          errorMessageLabels={this.props.errorMessageLabels}
                          onItemClassificationSubmit={
                            this.props.onItemClassificationSubmit
                          }
                          onSaveItemCompanyData={this.props.onSaveCompanyData}
                          setSaveDataValue={this.setSaveDataValue}
                          currentPage={'companyControlFactors'}
                          submitItemLabelsData={submitItemLabelsData}
                          canUpdateComponent={this.state.canUpdateComponent}
                        />
                      </TabContainer>
                    )}
                  </form>
                )}
              />
              <Formik
                initialValues={this.state.companyConstrainedControlsChangedData}
                enableReinitialize
                render={({ values, handleChange }) => (
                  <form>
                    {Object.keys(values).length > 0 && (tab == 9 && company['CCONST'] > 0) ? (
                      <TabContainer>
                        <ConstrainedControls
                          CompanyPropertiesData={this.props.CompanyPropertiesData}
                          changeConstrainedControlData={
                            this.changeConstrainedControlData
                          }
                          companyConstrainedControlsData={companyConstrainedControls}
                          setValueConstraintData={this.props.setValueConstraintData}
                          handleChange={handleChange}
                          setSaveData={val => {
                            this.setState({ isSaveDataDisabled: !val });
                          }}
                          values={values}
                          currentPage={'companyControlFactors'}
                          canUpdateComponent={this.state.canUpdateComponent}
                        />
                      </TabContainer>
                    ) : ""}
                  </form>
                )}
              />
              <Formik
                initialValues={{ company, companyDashboard }}
                enableReinitialize
                render={({ values, handleChange }) => (
                  <form>
                    {Object.keys(values).length > 0 && tab == 10 && (
                      <TabContainer>
                        <RecordsRetention
                          CompanyPropertiesData={this.props.CompanyPropertiesData}
                          changeRecordRetentionData={this.changeRecordRetentionData}
                          companyData={company}
                          companyDashboardData={companyDashboard}
                          handleChange={handleChange}
                          setSaveData={val => {
                            this.setState({ isSaveDataDisabled: !val });
                          }}
                          setValueData={this.props.setValueData}
                          setValueDashboardData={this.props.setValueDashboardData}
                          values={values}
                          currentPage={'companyControlFactors'}
                          canUpdateComponent={this.state.canUpdateComponent}
                        />
                      </TabContainer>
                    )}
                  </form>
                )}
              />
              <Formik
                initialValues={company, companyOrderDetail}
                enableReinitialize
                render={({ values, handleChange }) => (
                  <form>
                    {Object.keys(values).length > 0 && tab == 11 && (
                      <TabContainer>
                        <SystemSetUp
                          CompanyPropertiesData={this.props.CompanyPropertiesData}
                          companyData={company}
                          companyCalendarAdjustmentListData={
                            companyCalendarAdjustmentList
                          }
                          companyOrderDetailData={companyOrderDetail}
                          handleChange={handleChange}
                          setSaveData={val => {
                            this.setState({ isSaveDataDisabled: !val });
                          }}
                          values={values}
                          setValueData={this.props.setValueData}
                          setValueOrderDetailData={this.props.setValueOrderDetailData}
                          onCalendarAjsutmentSubmit={
                            this.props.onCalendarAjsutmentSubmit
                          }
                          onCalendarAjsutmentDelete={
                            this.props.onCalendarAjsutmentDelete
                          }
                          changeCompanyControlData={this.changeCompanyControlData}
                          sendCalendarList={this.sendCalendarList}
                          errorMessageLabels={this.props.errorMessageLabels}
                          ServerError={this.props.ServerError}
                          currentPage={'companyControlFactors'}
                          setSaveDataValue={this.setSaveDataValue}
                          calendarDataChange={this.calendarDataChange}
                          addCalendarLabelsData={addCalendarLabelsData}
                          canUpdateComponent={this.state.canUpdateComponent}
                        />
                      </TabContainer>
                    )}
                  </form>
                )}
              />
            </div>
            <div id="companyNotes"><CompanyNotes currentPage={COMPANY_PROPERTIES_PAGE}
              noteLabelJson={trimCommonLabelJson}
              bracketsNotesFilterObj={this.state.companyNotesFilterObj}
              fromPage={COMPANY_PROPERTIES_PAGE}
              currentRecordData={company}
              updatedNotesData={this.updatedNotesData}
              canUpdateComponent={this.state.canUpdateComponent}
              columnDefs={COMPANY_NOTE_LABEL_JSON}
              setNotesCount={this.setNotesCount} /* Dispatch notes count from child to Parent to show it on header */
              //~~~CreateNewFramework--JVK
              isOpenNote={this.state.isOpenNote}
              closeNote={(flag) => this.setState({ isOpenNote: flag })}
            //~~~CreateNewFramework--JVK
            >
            </CompanyNotes>
            </div>
          </div>
        </React.Fragment>
      );
    } else {
      return <Spinner loading type="list" />
    }
  }
}

CompanyProperties.propTypes = {};

function mapDispatchToProps(dispatch) {
  return {};
}

const mapStateToProps = function (state) {
  return {};
};

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withRouter,
  withConnect,
  withStyles(style),
)(CompanyProperties);

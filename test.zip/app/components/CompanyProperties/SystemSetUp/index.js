/** Change Log
 * LogStart --  E3C-33195 - Kumar A- 16 September,2021 - 2022.1.0.0 Unified Product
 *              Story: E3C-33195 --Code Cleanup
*/
import React from 'react';
import { compose } from 'redux';
import { withStyles } from '@material-ui/core/styles';
import PropTypes from 'prop-types';

import FormFieldsGenerator from '../../common/FormFieldsGenerator';
import Spinner from '../../common/Spinner';
import {
    COMPANY_TECHNICAL_FACTORS,
    COMPANY_CALENDAR_FACTORS,
    COMPANY_MULTITIER_FACTORS,
    COMPANY_FUNCTION_CONTROL_FACTORS,
    COMPANY_DELIMITTERS,
    COMPANY_UPDATE_SWITCHES,
    COMPANY_ORDER_FLAGS,
    LABEL_COMPANY_CAH,
} from './constants';
import './style.scss';
import {
    COMPANYS_LIST_PAGE,
    COLUMN_VALUE_ACCESSOR,
} from 'components/common/constants';
import CardComponent from '../../common/CardComponent';
import GridErrorMessages from '../../common/GridErrorMessages';
import FormattedMessageComponent from '../../common/FormattedMessageComponent';

import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import { Grid } from '@material-ui/core';
import CalendarAdjustmentsEmbeddedList from '../../../containers/CalendarAdjustmentsEmbeddedList';

const propTypes = {
    setSaveData: PropTypes.func,
}

const style = theme => ({
    pageContainer: {
        display: 'flex',
        backgroundColor: 'var(--background-app)',
        borderTop: 'none',
        padding: '10px 20px',
    },
    pageContainer1: {
        display: 'flex',
        backgroundColor: 'var(--background-app)',
        borderTop: 'none',
        padding: '10px 20px',
        marginTop: '-20px',
    },
    pageContainerSeventy: {
        width: '70%',
        flexFlow: 'wrap',
        display: 'flex',
    },
    pageContainerThirty: {
        width: '30%',
        flexFlow: 'wrap',
        display: 'flex',
    },
    card: {
        padding: '0px',
        backgroundColor: 'var(--background-content)',
        borderRadius: '4px',
        width: '100%',
        margin: '8px',
        '& .MuiCardHeader-root': {
            padding: '22px 10px 0 20px'
        },
        '& .MuiCardContent-root': {
            padding: '16px 15px 10px 15px'
        }
    },
    root: {
        flexGrow: 'wrap',
        width: '100%'
    },
    cardHeader1: {
        color: 'white',
        height: '34px',
        marginTop: '-10px',
        fontSize: '16px'
    },
})

class SystemSetup extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            fields: false,
            values: false,
            hasError: false,
            errorId: false,
            rows: JSON.parse(this.props.companyCalendarAdjustmentListData),
            open: false,
            selectedData: [],
            valueOrderDetailData: false,
            showConfirmationDialog: false,
            tabcards: false,
            //error messaging
            hasError: false,
            errorId: false,
            parameterValues: [],

        };
        this.handleChangeValue = this.handleChangeValue.bind(this);
        this.handleChangeOrderDetailValue = this.handleChangeOrderDetailValue.bind(this);
        this.sendSelectRow = this.sendSelectRow.bind(this);
    }

    sendSelectRow(selectedDataFrom) {
        this.setState({ selectedData: selectedDataFrom })
    }

    handleChangeValue(key, val, field, setEnableDisable = true) {
        if (field.FDPRFX == '0') {
            if (key.includes("undefined")) {
                key = key.replace("undefined", "");
            }
            key = 'C' + key;
        }
        if (val != null) {
            this.props.setValueData({ key, val });
        }
        if (field.dataType == "checkbox" || field.dataType == 'select' || field.dataType == 'date'
            || key == 'CJTNUM') {
            if (setEnableDisable) {
                let tabsData = this.setFieldEnableDisable(key, val, field, this.state.tabcards);
                this.setState({ tabcards: tabsData });
            }
        }
    }

    handleChangeOrderDetailValue(key, val, field, setEnableDisable = true) {
        if (field.FDPRFX == '0') {
            if (key.includes("undefined")) {
                key = key.replace("undefined", "");
            }
            key = 'OC' + key;
        }
        let valueNewOrderDetailDataO = this.state.valueOrderDetailData
        if (val != null) {
            this.props.setValueOrderDetailData({ key, val, valueNewOrderDetailDataO });
        }
        if (field.dataType == "checkbox" || field.dataType == 'select' || field.dataType == 'date') {
            if (setEnableDisable) {
                let tabsData = this.setFieldEnableDisable(key, val, field, this.state.tabcards);
                this.setState({ tabcards: tabsData });
            }
        }
    }

    getValueData(valueData, newValueData) {
        if (this.state.valueOrderDetailData == false) {
            this.setState({ valueOrderDetailData: valueData });
        }
        if (Object.keys(valueData).length && Object.keys(newValueData).length &&
            (JSON.parse(JSON.stringify(valueData)) !== JSON.parse(JSON.stringify(newValueData)))) {
            return newValueData;
        }
        return valueData;
    }

    setFieldEnableDisable = (key, value, field, tabsData, isInitialLoad = false) => {
        const { valueData } = this.props.CompanyPropertiesData;
        let valueDataUpdated = JSON.parse(JSON.stringify(valueData));
        valueDataUpdated = Object.assign({}, valueDataUpdated, { [key]: value });
        // fieldKey --- field changed
        // cardFieldKey --- field to be disabled
        let cardFieldKey, fieldKey = field[COLUMN_VALUE_ACCESSOR].trim();
        let tabcards = JSON.parse(JSON.stringify(tabsData));
        tabcards = tabcards.map(card => {
            card.cardfields = card.cardfields.map(cardField => {
                cardFieldKey = cardField[COLUMN_VALUE_ACCESSOR] ? cardField[COLUMN_VALUE_ACCESSOR].trim() : "";
                //  disabling enabling field for particular value
                if ((fieldKey === 'CALA0') && (cardFieldKey === 'CALA0')) {
                    cardField['disabled'] = true;
                }
                if (fieldKey === 'CJTNUM' && (cardFieldKey === 'CJTWTT' || cardFieldKey === 'CJTWTF') && value) {
                    if (parseInt(value) > 0) {
                        cardField['disabled'] = false;
                    } else {
                        cardField['disabled'] = true;
                    }
                }
                return cardField;
            })
            return card;
        })
        return tabcards;
    }

    setValueDataOnFocutOut = (key, value, field) => {
        if (value != null) {
            let tabsData = this.setFieldEnableDisable(key, value, field, this.state.tabcards);
            this.setState({ tabcards: tabsData });
        }

    }

    componentDidMount() {
        let tabsData = this.props.CompanyPropertiesData.systemSetupLabelsData.tabcards;
        let valueForm = this.props.CompanyPropertiesData.valueData;
        tabsData.forEach(card => {
            card.cardfields.forEach(field => {
                if (field.key) {
                    tabsData = this.setFieldEnableDisable(field.key, valueForm[field.key], field, tabsData, true);
                    if (field.hasCheckbox) {
                        tabsData = this.setFieldEnableDisable(field.checkfieldJson.key, valueForm[field.checkfieldJson.key], field.checkfieldJson, tabsData, true);
                    }
                }
            })
        })
        this.setState({ tabcards: tabsData });
    }

    sethaserror = (val) => {
        this.setState({ hasError: val });
    }

    getLabelValue(id) {
        return <FormattedMessageComponent id={id} />;
    }

    render() {
        const { classes, setSaveData, globalDateFormat, filterCriteriaDetails, pageFilterOptions,
            globalFilterOptions, columnDefs, currentPage, values } = this.props;
        const { loading, valueData, newValueData } = this.props.CompanyPropertiesData;
        const { tabcards } = this.state;
        const valueData1 = values;
        const newValueData1 = values;
        return (
            <div>
                {(this.state.hasError) ? <div>
                    <GridErrorMessages
                        errorMessageLabels={this.props.errorMessageLabels}
                        popUp={true}
                        sethaserror={this.sethaserror}
                        replaceValues={this.state.parameterValues}
                        id={this.state.errorId ? this.state.errorId : this.props.ServerError}
                    />
                </div> : ''}
                {(!loading && tabcards && tabcards.length) ? (
                    <div className={classes.pageContainer}>
                        <div className={classes.pageContainerSeventy}>
                            {!loading && tabcards.map(formCard => {
                                if (formCard.cardkey == COMPANY_TECHNICAL_FACTORS) {
                                    formCard.cardfields[1]['isCheckWildCard'] = false;
                                    return <CardComponent title={formCard.cardtitle} className={classes.card}>
                                        <FormFieldsGenerator
                                            cardHasDotsBtn={false}
                                            cardHasCheckBox={false}
                                            noMassMaintenance
                                            labelDisplayCharacters={28}
                                            valueDisplayCharacters={15}
                                            handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                                            key={formCard.cardkey}
                                            parentPage={COMPANYS_LIST_PAGE}
                                            className={'COMPANY_TECHNICAL_FACTORS'}
                                            fieldsArray={formCard.cardfields}
                                            valuesArray={this.getValueData(valueData, newValueData)}
                                            handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                            enableAddButton={(e) => { setSaveData(e) }}
                                            globalDateFormat={globalDateFormat}
                                            handleFocusOut={(key, val, field) => this.setValueDataOnFocutOut(key, val, field)}
                                            filterCriteriaDetails={filterCriteriaDetails}
                                            pageFilterOptions={pageFilterOptions}
                                            globalFilterOptions={globalFilterOptions}
                                            columnDefs={columnDefs}
                                            currentPage={currentPage}
                                            parentData={this.props.companyData}
                                            canUpdateComponent={this.props.canUpdateComponent}
                                        />
                                    </CardComponent>
                                }
                            })}
                        </div>
                        <div className={classes.pageContainerSeventy}>
                            {!loading && tabcards.map(formCard => {
                                if (formCard.cardkey == COMPANY_CALENDAR_FACTORS) {
                                    return <CardComponent title={formCard.cardtitle} className={classes.card}>
                                        <FormFieldsGenerator
                                            cardHasDotsBtn={false}
                                            cardHasCheckBox={false}
                                            noMassMaintenance
                                            labelDisplayCharacters={28}
                                            valueDisplayCharacters={15}
                                            handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                                            key={formCard.cardkey}
                                            parentPage={COMPANYS_LIST_PAGE}
                                            className={'COMPANY_CALENDAR_FACTORS'}
                                            fieldsArray={formCard.cardfields}
                                            valuesArray={this.getValueData(valueData, newValueData)}
                                            handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                            enableAddButton={(e) => { setSaveData(e) }}
                                            globalDateFormat={globalDateFormat}
                                            handleFocusOut={(key, val, field) => this.setValueDataOnFocutOut(key, val, field)}
                                            filterCriteriaDetails={filterCriteriaDetails}
                                            pageFilterOptions={pageFilterOptions}
                                            globalFilterOptions={globalFilterOptions}
                                            columnDefs={columnDefs}
                                            currentPage={currentPage}
                                            parentData={this.props.companyData}
                                            canUpdateComponent={this.props.canUpdateComponent}
                                        />
                                    </CardComponent>
                                }
                            })}
                        </div>
                        <div className={classes.pageContainerThirty}>
                            {!loading && tabcards.map(formCard => {
                                if (formCard.cardkey == COMPANY_MULTITIER_FACTORS) {
                                    return <CardComponent title={formCard.cardtitle} className={classes.card}>
                                        <FormFieldsGenerator
                                            cardHasDotsBtn={false}
                                            cardHasCheckBox={false}
                                            noMassMaintenance
                                            labelDisplayCharacters={30}
                                            valueDisplayCharacters={5}
                                            handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                                            key={formCard.cardkey}
                                            parentPage={COMPANYS_LIST_PAGE}
                                            className={'COMPANY_MULTITIER_FACTORS'}
                                            fieldsArray={formCard.cardfields}
                                            valuesArray={this.getValueData(valueData, newValueData)}
                                            handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                            enableAddButton={(e) => { setSaveData(e) }}
                                            globalDateFormat={globalDateFormat}
                                            handleFocusOut={(key, val, field) => this.setValueDataOnFocutOut(key, val, field)}
                                            filterCriteriaDetails={filterCriteriaDetails}
                                            pageFilterOptions={pageFilterOptions}
                                            globalFilterOptions={globalFilterOptions}
                                            columnDefs={columnDefs}
                                            currentPage={currentPage}
                                            parentData={this.props.companyData}
                                            canUpdateComponent={this.props.canUpdateComponent}
                                        />
                                    </CardComponent>
                                }
                            })}
                            {!loading && tabcards.map(formCard => {
                                if (formCard.cardkey == COMPANY_FUNCTION_CONTROL_FACTORS) {
                                    return <CardComponent title={formCard.cardtitle} className={classes.card}>
                                        <FormFieldsGenerator
                                            cardHasDotsBtn={false}
                                            cardHasCheckBox={false}
                                            noMassMaintenance
                                            labelDisplayCharacters={30}
                                            valueDisplayCharacters={5}
                                            handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                                            key={formCard.cardkey}
                                            parentPage={COMPANYS_LIST_PAGE}
                                            className={'COMPANY_FUNCTION_CONTROL_FACTORS'}
                                            fieldsArray={formCard.cardfields}
                                            valuesArray={this.getValueData(valueData, newValueData)}
                                            handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                            enableAddButton={(e) => { setSaveData(e) }}
                                            globalDateFormat={globalDateFormat}
                                            handleFocusOut={(key, val, field) => this.setValueDataOnFocutOut(key, val, field)}
                                            filterCriteriaDetails={filterCriteriaDetails}
                                            pageFilterOptions={pageFilterOptions}
                                            globalFilterOptions={globalFilterOptions}
                                            columnDefs={columnDefs}
                                            currentPage={currentPage}
                                            parentData={this.props.companyData}
                                            canUpdateComponent={this.props.canUpdateComponent}
                                        />
                                    </CardComponent>
                                }
                            })}
                        </div>
                    </div>
                ) : (<Spinner loading type="list" />)
                }
                {(!loading && tabcards && tabcards.length) ? (
                    <Grid item xs={12}>
                        <div className={classes.root} style={{ padding: 2 }}>
                            <div className={classes.pageContainer1}>
                                <Card className={classes.card}>
                                    <CardHeader className={classes.cardHeader1}
                                        title={this.getLabelValue(
                                            LABEL_COMPANY_CAH,
                                        )}
                                    />
                                    <div
                                        id="myGrid"
                                        className="ag-theme-balham">
                                        <CalendarAdjustmentsEmbeddedList
                                            sendSelectRow={this.sendSelectRow}
                                            rows={this.state.rows}
                                            errorMessageLabels={this.props.errorMessageLabels}
                                            calendarDataChange={this.props.calendarDataChange}
                                            sendCalendarList={this.props.sendCalendarList}
                                            setSaveDataValue={this.props.setSaveDataValue}
                                            newValueData={newValueData}
                                            addCalendarLabelsData={this.props.addCalendarLabelsData}
                                            canUpdateComponent={this.props.canUpdateComponent}
                                            onCalendarAjsutmentSubmit={this.props.onCalendarAjsutmentSubmit} />
                                    </div>
                                </Card>
                                <div className={classes.pageContainerThirty}>
                                    {!loading && tabcards.map(formCard => {
                                        if (formCard.cardkey == COMPANY_DELIMITTERS) {
                                            return <CardComponent title={formCard.cardtitle} className={classes.card}>
                                                <FormFieldsGenerator
                                                    cardHasDotsBtn={false}
                                                    cardHasCheckBox={false}
                                                    noMassMaintenance
                                                    labelDisplayCharacters={22}
                                                    valueDisplayCharacters={15}
                                                    handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                                                    key={formCard.cardkey}
                                                    parentPage={COMPANYS_LIST_PAGE}
                                                    className={'COMPANY_DELIMITTERS'}
                                                    fieldsArray={formCard.cardfields}
                                                    valuesArray={this.getValueData(valueData, newValueData)}
                                                    handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                                    enableAddButton={(e) => { setSaveData(e) }}
                                                    globalDateFormat={globalDateFormat}
                                                    handleFocusOut={(key, val, field) => this.setValueDataOnFocutOut(key, val, field)}
                                                    filterCriteriaDetails={filterCriteriaDetails}
                                                    pageFilterOptions={pageFilterOptions}
                                                    globalFilterOptions={globalFilterOptions}
                                                    columnDefs={columnDefs}
                                                    currentPage={currentPage}
                                                    parentData={this.props.companyData}
                                                    canUpdateComponent={this.props.canUpdateComponent}
                                                />
                                            </CardComponent>
                                        }
                                    })}
                                </div>
                            </div>
                        </div>
                    </Grid>
                ) : ''
                }
                {(!loading && tabcards && tabcards.length) ? (
                    <div className={classes.pageContainer1}>
                        <div className={classes.pageContainerSeventy}>
                            {!loading && tabcards.map(formCard => {
                                if (formCard.cardkey == COMPANY_UPDATE_SWITCHES) {
                                    return <CardComponent title={formCard.cardtitle} className={classes.card}>
                                        <FormFieldsGenerator
                                            cardHasDotsBtn={false}
                                            cardHasCheckBox={false}
                                            noMassMaintenance
                                            labelDisplayCharacters={22}
                                            valueDisplayCharacters={20}
                                            handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                                            key={formCard.cardkey}
                                            parentPage={COMPANYS_LIST_PAGE}
                                            className={'COMPANY_UPDATE_SWITCHES'}
                                            fieldsArray={formCard.cardfields}
                                            valuesArray={this.getValueData(valueData, newValueData)}
                                            handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                            enableAddButton={(e) => { setSaveData(e) }}
                                            globalDateFormat={globalDateFormat}
                                            handleFocusOut={(key, val, field) => this.setValueDataOnFocutOut(key, val, field)}
                                            filterCriteriaDetails={filterCriteriaDetails}
                                            pageFilterOptions={pageFilterOptions}
                                            globalFilterOptions={globalFilterOptions}
                                            columnDefs={columnDefs}
                                            currentPage={currentPage}
                                            parentData={this.props.companyData}
                                            canUpdateComponent={this.props.canUpdateComponent}
                                        />
                                    </CardComponent>
                                }
                            })}
                        </div>
                        <div className={classes.pageContainerThirty}>
                            {!loading && tabcards.map(formCard => {
                                if (formCard.cardkey == COMPANY_ORDER_FLAGS) {
                                    return <CardComponent title={formCard.cardtitle} className={classes.card}>
                                        <FormFieldsGenerator
                                            cardHasDotsBtn={false}
                                            cardHasCheckBox={false}
                                            noMassMaintenance
                                            labelDisplayCharacters={20}
                                            valueDisplayCharacters={15}
                                            handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                                            key={formCard.cardkey}
                                            parentPage={COMPANYS_LIST_PAGE}
                                            className={'COMPANY_ORDER_FLAGS'}
                                            fieldsArray={formCard.cardfields}
                                            valuesArray={this.getValueData(valueData1, newValueData1)}
                                            enableAddButton={(e) => { setSaveData(e) }}
                                            handleChangeValue={(key, val, field) => this.handleChangeOrderDetailValue(key, val, field)}
                                            globalDateFormat={globalDateFormat}
                                            handleFocusOut={(key, val, field) => this.setValueDataOnFocutOut(key, val, field)}
                                            filterCriteriaDetails={filterCriteriaDetails}
                                            pageFilterOptions={pageFilterOptions}
                                            globalFilterOptions={globalFilterOptions}
                                            columnDefs={columnDefs}
                                            currentPage={currentPage}
                                            parentData={this.props.companyData}
                                            canUpdateComponent={this.props.canUpdateComponent}
                                        />
                                    </CardComponent>
                                }
                            })}
                        </div>
                    </div>
                ) : ''
                }
            </div>
        );
    }
}

SystemSetup.propTypes = propTypes;

export default compose(
    withStyles(style)
)(SystemSetup);
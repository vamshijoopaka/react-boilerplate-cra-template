/**
 * Copyright © 2018, JDA Software Group, Inc. ALL RIGHTS RESERVED.
 * <p>
 * This software is the confidential information of JDA Software, Inc., and is licensed
 * as restricted rights software. The use,reproduction, or disclosure of this software
 * is subject to restrictions set forth in your license agreement with JDA.
 */
/**
*
* ErrorDetail
* The intention is to make this easily extensible, reusable and have similar error UI.
*/

import React from 'react';
import PropTypes from 'prop-types';
import styled from '@emotion/styled';
import { injectIntl, intlShape } from 'react-intl';
import messages from './messages';

const ErrorContainer = styled.div({
  color: '#fff',
  fontSize: '18px',
  padding: '12px',
});

export const ErrorDetail = ({ type, intl }) => {
  let error;
  if (type === 'no_data') {
    error = <ErrorContainer>{intl.formatMessage(messages.noData)}</ErrorContainer>;
  } else if (type === 'no_alerts') {
    error = <ErrorContainer>{intl.formatMessage(messages.noAlerts)}</ErrorContainer>;
  } else {
    error = null;
  }
  return error;
};

ErrorDetail.propTypes = {
  type: PropTypes.string,
  intl: intlShape.isRequired,
};

export default injectIntl(ErrorDetail);

import { Box } from '@material-ui/core';
import { withStyles } from '@material-ui/core/styles';
import { TEXT_CANCEL, TEXT_OK } from 'components/common/constants';
import DialogComponent from 'components/common/DialogComponent';
import FormFieldsGenerator from 'components/common/FormFieldsGenerator';
import theme from 'jda-gcp-theme';
import React from 'react';

const styles = theme => ({
    notesForBlock: {
        display: 'flex',
        flexDirection: 'column',
        border: '1px solid var(--divider-line)',
        padding: '10px 10px 0 10px',
        position: 'relative',
        width: '100%'
    },
    notesForLabel: {
        position: 'absolute',
        top: '-7px',
        left: '10px',
        background: 'var(--background-content)',
        padding: '0 8px',
    },
    pageContainer: {
        display: 'flex',
        borderTop: 'none',
        padding: '10px 20px',
    },
    card: {
        padding: '0 0px 0 0',
        backgroundColor: 'var(--background-content)',
        borderRadius: '4px',
    },
    dialogClass: {
        minWidth: '30% !important',
        maxWidth: '30% !important',
        height: '21rem'
    }
});
class AddCalendarDialog extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            disableSubmit: true,
            amountError: false,
            yearError: false,
        }
        this.handleChangeValue = this.handleChangeValue.bind(this);
    }

    handleClose = (value) => {
        this.props.handleDialogClose(value);
    }
    handleChangeValue = (key, value, field) => {
        if (value < field.minValue || value > field.maxValue) {
            if (field.FDFNAM.trim() == 'ADJT') {
                this.setState({ amountError: true })
            }
            if (field.FDFNAM.trim() == 'YEAR') {
                this.setState({ yearError: true })
            }
        } else {
            if (field.FDFNAM.trim() == 'ADJT') {
                this.setState({ amountError: false })
            }
            if (field.FDFNAM.trim() == 'YEAR') {
                this.setState({ yearError: false })
            }
        }
        if (this.state.amountError || this.state.yearError) {
            this.setState({ disableSubmit: true })
        } else {
            this.setState({ disableSubmit: false })
        }
        this.props.handleChangeValue(key, value, field);
    }
    handleAddCalendar = () => {
        const { valueForm } = this.props;
        this.props.handleAddCalendar({ ...valueForm });
        this.handleClose(true);
    }
    render() {
        const { classes, fieldData, valueForm, currentPage, columnDefs, globalDateFormat } = this.props;
        return (
            <DialogComponent dialogTitle={'27039'}
                cancelText={TEXT_CANCEL}
                submitText={TEXT_OK}
                handleCancel={(val) => { this.handleClose(true) }}
                handleSubmit={() => { this.handleAddCalendar() }}
                handleClose={(val) => { this.handleClose(true) }}
                disableSubmit={this.state.disableSubmit}
                className={classes.dialogClass}
                isOpen={true}>
                <div className={classes.pageContainer}>
                    {fieldData && fieldData.length && fieldData.map((object) => {
                        return <div className={classes.notesForBlock}>
                            <Box mb={theme.spacing(0.5)} className={classes.notesForLabel}>{" "}</Box>
                            <FormFieldsGenerator
                                labelDisplayCharacters={26}
                                valueDisplayCharacters={10}
                                noMassMaintenance={true}
                                key={object.cardkey}
                                fieldsArray={object.cardfields}
                                valuesArray={valueForm}
                                handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                enableAddButton={(e) => { }}
                                columnDefs={columnDefs}
                                currentPage={'addCalendar'}
                                canUpdateComponent={false}
                                globalDateFormat={globalDateFormat}
                            />
                        </div>
                    })}
                </div>

            </DialogComponent>
        );
    }
}
export default withStyles(styles)(AddCalendarDialog);
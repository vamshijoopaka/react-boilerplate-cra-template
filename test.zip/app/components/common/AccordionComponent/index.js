import React from 'react';
import { ExpansionPanel, ExpansionPanelSummary, ExpansionPanelDetails } from '@material-ui/core';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import { withStyles, MuiThemeProvider, createMuiTheme } from '@material-ui/core/styles';
import { PropTypes } from 'prop-types';
import theme from '../../../jda-gcp-theme';
import FormattedMessageComponent from '../FormattedMessageComponent';
import {Badge, Box} from '@material-ui/core';

const propTypes = {
    isPanelExpanded: PropTypes.bool.isRequired,
    onChange: PropTypes.func.isRequired,
    label: PropTypes.string,
    count: PropTypes.number,
}

const themes = createMuiTheme(theme);

themes.overrides = {

    MuiExpansionPanelSummary: {
        root: {
            borderRadius: '4px',
            borderBottom: '0px solid var(--divider-line)',
            padding: '0 30px',
            minHeight: '40px',
            background: 'var(--secondary-s5)',
            color: 'var(--text)',
            fontSize: '1rem',
            minHeight: '40px',
            '&.Mui-expanded': {
                minHeight: '50px',
                borderBottom: '1.5px solid var(--divider-line)',
                backgroundColor: 'var(--secondary-s5)',
                borderRadius: '4px 4px 0 0'
            }
        },
        content: {
            margin: '0 !important',
            alignItems: 'baseline',
        },
    },
    MuiExpansionPanelDetails: {
        root: {
            borderRadius: '0 0 4px 4px',
            background: 'var(--secondary-s5)',
            padding: '16px 16px 16px 16px',
            color: 'var(--text)',
        },
    },
    MuiTabs: {
        root: {
            position: 'relative',
            backgroundColor: 'var(--background-app)',
            minHeight: 35,
            borderRadius: '16px',
            width: 'fit-content',
            border: '1px solid var(--secondary-s5)',
            color: 'var(--text)',
        },
        indicator: {
            backgroundColor: 'transparent !important',
        }
    },
    MuiTabIndicator: {
        root: {
            height: '4px',
        },
    },
    MuiTab: {
        root: {
            fontSize: '12px',
            fontWeight: '500',
            [theme.breakpoints.up('md')]: {
                minWidth: 50,
                padding: '0 20px',
                margin: '0',
                fontSize: '14px',
                fontWeight: '500',
                minHeight: 32
            },
            [theme.breakpoints.up('lg')]: {
                minWidth: 75,
                margin: 0,
                padding: '0 24px',
                fontSize: '16px',
                fontWeight: '500',
                minHeight: 40
            },
        },
        textColorInherit: {
            color: '#000000',
            backgroundColor: 'var(--background-app)',
            '&.Mui-selected': {
                backgroundColor: 'var(--inputText-value)',
                color: 'var(--background-app)',
            }
        },
        textColorPrimary: {
            color: theme.palette.common.underline,
            '&.Mui-selected': {
                color: 'var(--background-content) !important',
                backgroundColor: theme.palette.primary.default,
            },
            '&.Mui-selected:hover': {
                color: 'var(--background-content) !important',
                backgroundColor: theme.palette.primary.hover,
            },
            '&:hover': {
                color: theme.palette.primary.hover,
            },
            '&:focus': {
                color: theme.palette.primary.focus,
            },
            '&:active': {
                color: theme.palette.primary.active,
            },
            '&.Mui-disabled': {
                color: theme.palette.primary.disabled,
            },
        }
    },
    MuiButton: {
        root: {
            [theme.breakpoints.up('md')]: {
                fontSize: '14px',
            },
        },
        sizeLarge: {
            padding: '7px 16px'
        },
        // For contained type buttons configuration
        contained: {
            boxShadow: theme.shadows[5],
            color: '#ffffff',
            '&.Mui-disabled': {
                backgroundColor: theme.palette.primary.disabled,
                color: '#ffffff'
            }
        },
        containedPrimary: {
            backgroundColor: theme.palette.primary.default,
            border: '1px solid rgba(0, 0, 0, 0)',
            boxShadow: 'none',
            '&:hover': {
                backgroundColor: theme.palette.primary.hover,
            },
            '&:focus': {
                backgroundColor: theme.palette.primary.focus,
            },
            '&:active': {
                backgroundColor: theme.palette.primary.active,
            }
        },
        containedSecondary: {
            backgroundColor: '#9A9A9A',
            '&:hover': {
                backgroundColor: '#9A9A9A',
                opacity: 0.9
            }
        },

        // For outlined type buttons configuration
        outlined: {
        },
        outlinedPrimary: {
            color: theme.palette.primary.default,
            border: '1px solid ' + theme.palette.primary.default,
            '&:hover': {
                color: theme.palette.primary.hover,
                border: '1px solid ' + theme.palette.primary.hover,
            },
            '&:focus': {
                color: theme.palette.primary.focus,
                border: '1px solid ' + theme.palette.primary.focus,
            },
            '&:active': {
                color: theme.palette.primary.active,
                border: '1px solid ' + theme.palette.primary.active,
            },
            '&.Mui-disabled': {
                color: theme.palette.primary.disabled,
            },
        },
        outlinedSecondary: {
            color: '#9A9A9A',
            border: '1px solid #9A9A9A'
        },

        // For text type buttons configuration
        text: {},
        textPrimary: {
            color: theme.palette.primary.default,
            '&:hover': {
                color: theme.palette.primary.hover,
                textDecoration: 'underline',
                backgroundColor: 'unset',
            },
            '&:focus': {
                color: theme.palette.primary.focus,
                textShadow: '0px 4px 4px rgba(0, 0, 0, 0.25)',
            },
            '&:active': {
                color: theme.palette.primary.active,
                textShadow: 'unset',
            },
            '&.Mui-disabled': {
                color: theme.palette.primary.disabled,
                textDecoration: 'unset',
                backgroundColor: 'unset',
                textShadow: 'unset'
            }
        },
        textSecondary: {},
    },
    MuiAutocomplete: {
        listbox: {
            backgroundColor: 'var(--background-content)'
        },
        clearIndicator: {
            '& svg': {
                fill: 'red'
            }
        },
        input: {
            color: 'var(--text)',
        },
        inputRoot: {
            paddingRight: 40,
            paddingLeft: 20,
            '& input': {
                padding: 0
            }
        },
        popupIndicator: {
            marginTop: 3,
            marginRight: '-5px'
        }
    },
    MuiInput: {
        root: {
            height: 25,
            maxWidth: '14rem'
        },
        input: {
        },
        underline: {
            '&:after': {
                borderBottom: '2px solid var(--underline) !important',
            },
            '&:before': {
                borderBottom: '1px solid var(--underline) !important',
            },
            '&:hover:after': {
                borderBottom: '2px solid ' + theme.palette.primary.default + ' !important',
            },
            '&.Mui-disabled:before': {
                borderBottom: '1px solid ' + theme.palette.primary.disabled,
                borderBottomStyle: 'solid !important',
            },
            // '&:hover:not(.Mui-disabled):before':{
            //   borderBottom: '2px solid var(--underline)'
            // }
        }
    },
    MuiList: {
        root: {
            backgroundColor: 'var(--background-content)'
        }
    },
    MuiListItem: {
        button: {
            '&:hover': {
                backgroundColor: 'var(--list-hover)',
            }
        }
    },
    MuiTable: {
        root: {
            [theme.breakpoints.up('md')]: {
                width: '698px'
            }
        }
    },
    MuiTableCell: {
        root: {
            padding: '.3rem .6rem .3rem 0',
        },
        head: {
            fontSize: '1rem',
            color: theme.palette.common.smokeWhite,
        },
        body: {
            border: 'none'
        }
    },
    MuiFormControlLabel: {
        root: {
            marginRight: 0,
        },
        labelPlacementTop: {
            alignItems: 'flex-start',
            marginLeft: 0,
        },
        label: {
            fontSize: '12px',
            color: theme.palette.common.label,
            padding: '10px 20px 10px 20px',
            width: 'inherit',
            maxWidth: '20ch',
            overflow: 'hidden',
            whiteSpace: 'nowrap',
            textOverflow: 'ellipsis',
            '&.Mui-disabled': {
                color: 'var(--disabled)'
            }
        },
        labelPlacementStart: {
            '& .MuiFormControlLabel-label': {
                padding: '10px 20px 10px 0px'
            }
        }
    },
    MuiInputBase: {
        root: {
            fontSize: '14px !important',
            fontWeight: 400
        },
        input: {
            color: theme.palette.common.inputTextValue + " !important",
            '&.Mui-disabled': {
                color: theme.palette.primary.disabled + " !important",
            },
        }
    },
    MuiTableHead: {
        root: {
            backgroundColor: theme.palette.common.starCommandBlue,
        },
    },
    MuiTabs: {
        root: {
            position: 'relative',
            backgroundColor: 'var(--background-app)',
            minHeight: 35,
            borderRadius: '16px',
            width: 'fit-content',
            border: '1px solid var(--secondary-s5)',
            color: 'var(--text)',
            marginLeft: '16px'
        },
        indicator: {
            backgroundColor: 'transparent !important',
        }
    },
    MuiTabIndicator: {
        root: {
            height: '4px',
        },
    },
    MuiTab: {
        root: {
            fontSize: '12px',
            fontWeight: '500',
            [theme.breakpoints.up('md')]: {
                minWidth: 50,
                padding: '0 20px',
                margin: '0',
                fontSize: '14px',
                fontWeight: '500',
                minHeight: 32
            },
            [theme.breakpoints.up('lg')]: {
                minWidth: 75,
                margin: 0,
                padding: '0 24px',
                fontSize: '16px',
                fontWeight: '500',
                minHeight: 40
            },
        },
        textColorInherit: {
            color: '#000000',
            backgroundColor: 'var(--background-app)',
            '&.Mui-selected': {
                backgroundColor: 'var(--inputText-value)',
                color: 'var(--background-app)',
            }
        },
        textColorPrimary: {
            color: theme.palette.common.underline,
            '&.Mui-selected': {
                color: 'var(--background-content) !important',
                backgroundColor: theme.palette.primary.default,
            },
            '&.Mui-selected:hover': {
                color: 'var(--background-content) !important',
                backgroundColor: theme.palette.primary.hover,
            },
            '&:hover': {
                color: theme.palette.primary.hover,
            },
            '&:focus': {
                color: theme.palette.primary.focus,
            },
            '&:active': {
                color: theme.palette.primary.active,
            },
            '&.Mui-disabled': {
                color: theme.palette.primary.disabled,
            },
        }
    },
    MuiIconButton: {
        // root currently only being used in the error notifications, or any MuiIconButton with no color specified.
        root: {
            color: 'var(--text)',
            '&.Mui-disabled': {
                color: 'var(--disabled)'
            }
        },
        // colorPrimary: {
        //   color: '#0e0e0e',
        // },
    },
    MuiAppBar: {
        root: {
            boxShadow: 'none',
        },
        colorPrimary: {
            backgroundColor: 'var(--logo)',
        }
    },
    MuiMenu: {
        paper: {
            borderRadius: 4,
        },
        list: {
            '& > *': {
                padding: '0.6rem'
            }
        }
    },
    MuiFormLabel: {
        root: {
            color: 'black',
        },
    },
    MuiFormHelperText: {
        root: {
            color: 'gray',
        },
    },
    MuiSelect: {
        root: {
            // color: 'black',
        },
        selectMenu: {
            height: '100%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'inherit'
        },
        icon: {
            color: 'var(--text) !important',
        }
    },
    MuiCard: {
        root: {
            color: 'var(--text)',
            padding: '1rem',
            boxShadow: '0 4px 8px rgba(0,0,0,0.10)',
            '&:hover': {
                boxShadow: '0 4px 8px rgba(0,0,0,0.25)',
            },
            '&:focus-within': {
                boxShadow: '0 4px 4px rgba(0,0,0,0.25)',
            },
        },
    },
    MuiCardHeader: {
        root: {
            padding: '22px 20px 0 20px',
        },
        title: {
            color: 'var(--text)',
            fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
            fontSize: '18px',
            fontWeight: '700',
        }
    },
    MuiOutlinedInput: {
        root: {
            padding: '.5rem',
            height: '100%',
            alignItems: 'flex-start'
        },
        input: {
            padding: '0'
        }
    },
    MuiDialogContent: {
        root: {
            backgroundColor: 'var(--background-content)',
            padding: '8px 0'
        }
    },
    MuiDialogActions: {
        root: {
            padding: '8px 16px',
            backgroundColor: 'var(--background-content)'
        }
    },
    MuiDialogTitle: {
        root: {
            backgroundColor: 'var(--background-content)',
            borderBottom: '1px solid var(--divider-line)',
            padding: '9px 16px'
        }
    },
    MuiPaper: {
        root: {
            backgroundColor: 'var(--background-content)',
            color: 'var(--text)'
        },
        elevation1: {
            boxShadow: '0 2px 4px 0 rgba(148,148,148,0.5)'
        },
        rounded: {
            borderRadius: 0
        }
    },
    MuiDialog: {
        paperWidthSm: {
            [theme.breakpoints.up('md')]: {
                height: 'calc(100% - 96px)',
                minWidth: '768px'
            },
            [theme.breakpoints.up('sm')]: {
                minWidth: '550px',
                maxWidth: '767px',
                height: 'calc(100% - 96px)',
            },
            [theme.breakpoints.up('xs')]: {
                height: 'calc(100% - 96px)',
                width: 'calc(100% - 30px)'
            },
        },
        paper: {
            margin: 0
        },
        paperFullScreen: {
            width: '93vw',
            height: '90vh',
        }
    },
    MuiTooltip: {
        tooltip: {
            lineHeight: 1.4,
            backgroundColor: '#929292',
            padding: '4px 8px 4px 8px',
            color: '#fff',// theme.palette.common.white,
            fontSize: '10px',
            borderRadius: '0',
            fontWeight: theme.typography.fontWeightLight,
        }
    },
    MuiStepper: {
        root: {
            backgroundColor: 'transparent',
        },
        horizontal: {
            alignItems: 'flex-start'
        }
    },
    MuiStepIcon: {
        root: {
            color: '#var(--disabled)',
            '&$completed': {
                color: theme.palette.primary.default,
                cursor: 'pointer'
            },
            '&$active': {
                color: theme.palette.primary.default,
                cursor: 'default !important'
            }
        },
    },
    MuiStepLabel: {
        root: {
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            flexDirection: 'column',
        },
        iconContainer: {
            paddingRight: 0,
        },
        labelContainer: {
            marginTop: '8px',
        },
        label: {
            color: 'var(--disabled)',
            fontWeight: '400',
            '&$completed': {
                color: 'var(--text)',
                cursor: 'pointer',
                fontWeight: '400',
            },
            '&$active': {
                color: 'var(--text) !important',
                fontWeight: '600 !important',
                cursor: 'default !important'
            }
        }
    },
    MuiStepButton: {
        root: {
            cursor: 'default'
        }
    },
    MuiStepConnector: {
        root: {
            marginTop: '10px'
        },
        // completed: {
        //   '& span': {
        //     borderColor: '#0066D0'
        //   }
        // },
        active: {
            '& span': {
                borderColor: theme.palette.primary.default,
            }
        }
    },
    MuiSvgIcon: {
        root: {
            fontSize: '1.1rem !important',
        },
    },
    MuiRadio: {
        colorPrimary: {
            color: 'var(--radio-focus)',
            '&:hover': {
                color: 'var(--radio-hover)',
            },
            '&:focus': {
                color: 'var(--radio-focus)',
            },
            '&:active': {
                color: 'var(--radio-active)',
            },
            '& .Mui-disabled': {
                color: 'var(--disabled)',
            },
        }
    },
    MuiTablePagination: {
        select: {
            fontSize: '14px'
        },
        root: {
            color: 'var(--text)'
        },
    },
    MuiCheckbox: {
        root: {
            color: 'var(--text)',
        },
        colorPrimary: {
            '& .Mui-checked:hover': {
                color: 'var(--radio-focus)',
            }
        }
    },
    MuiAutocomplete: {
        paper: {
            color: '#3F4756',
            backgroundColor: '#ffffff',
        },
        clearIndicator: {
            color: '#ff0000'
        },
        popupIndicator: {
            color: 'var(--text)'
        },
        input: {
            '&:first-child': {
                paddingLeft: '20px !important',
            }
        }
    },
}


const style = theme => ({    
    panelSummary: {

        '& [class*="MuiBadge-root"]': {
            marginLeft: '20px !important',
            marginBottom: '3px !important',

            '& [class*="MuiBadge-badge"]': {
                fontSize: '0.68rem',
                paddingBottom: '1px',
                height: '18px',
                minWidth: props => (props.badgeWidth || '27px'),
            }
        }

    }


})

class AccordionComponent extends React.Component {

    constructor(props) {
        super(props);
        this.state = {

        }
    }

    render() {

        const { classes, isPanelExpanded, onChange, label, count } = this.props;

        return (
            <MuiThemeProvider theme={themes}>
                <ExpansionPanel expanded={isPanelExpanded} onChange={(event, expanded) => onChange(event, expanded)}>
                    <ExpansionPanelSummary expandIcon={<ExpandMoreIcon fontSize="large" />} >
                        {Boolean(Number(label)) ? <FormattedMessageComponent id={label} /> : <span>{label}</span>}                     
                        <span className={classes.panelSummary} >
                            {Boolean(count) ? <Badge color="error" overlap="circle" anchorOrigin={{ vertical: "top", horizontal: "right" }} max={99} badgeContent={count} /> : ''}
                        </span>
                    </ExpansionPanelSummary>
                    <ExpansionPanelDetails>
                        {this.props.children}
                    </ExpansionPanelDetails>
                </ExpansionPanel>
            </MuiThemeProvider>
        );
    }

}

AccordionComponent.propTypes = propTypes;

export default withStyles(style)(AccordionComponent)
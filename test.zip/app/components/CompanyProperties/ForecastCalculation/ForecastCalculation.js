/** Change Log
 * LogStart --  E3C-33195 - Kumar A- 16 September,2021 - 2022.1.0.0 Unified Product
 *              Story: E3C-33195 --Code Cleanup
*/
import React from 'react';
import { Grid } from '@material-ui/core';
import { withStyles } from '@material-ui/core/styles';
import Input from '@material-ui/core/Input';
import Checkbox from '@material-ui/core/Checkbox';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Box from '@material-ui/core/Box';
import RadioGroup from '@material-ui/core/RadioGroup';
import Card from '@material-ui/core/Card';
import FormLabel from '@material-ui/core/FormLabel';
import CardHeader from '@material-ui/core/CardHeader';
import Button from '@material-ui/core/Button';
import RadioButton from '../../common/RadioButton';
import Modal from '@material-ui/core/Modal';
import GridErrorMessages from '../../common/GridErrorMessages';


const styles = theme => ({
    paper: {
        margin: 10,
        height: '100px'
    },
    root: {
        flexGrow: 1,
        width: '100%'
    },
    cardHeader: {
        color: 'white',
        height: '34px',
        backgroundColor: '#01A9E0',
        marginBottom: 15,
        fontSize: '16px'
    },
    cardHeader1: {
        color: 'white',
        height: '34px',
        marginBottom: 0,
        fontSize: '16px'
    },
    cardTitle: {
        fontSize: '1.2rem',
    },
    card1: {
        height: '350px',
        width: '450px',
    },
    card2: {
        height: '440px',
        marginTop: '100px',
        marginLeft: '850px',
        width: '350px',
    },
    cardHeaderContent: {
        textAlign: 'left',
        fontSize: '14px',
        paddingTop: '0px'
    },
    cardItemContent: {
        textAlign: 'center',
        fontWeight: 'bold',
        fontSize: '25px',
        paddingTop: '0px'
    },
    gridItemHeader: {
        [theme.breakpoints.down("sm")]: {
            width: '100%',
        },
        [theme.breakpoints.between("sm", "md")]: {
            width: '50%',
        },
        [theme.breakpoints.between("md", "lg")]: {
            width: '25%',
        },
    },
    gridItem: {
        [theme.breakpoints.down("sm")]: {
            width: '100%',
        },
        [theme.breakpoints.between("sm", "md")]: {
            width: '50%',
        },
        [theme.breakpoints.between("md", "lg")]: {
            width: '20%',
        },
    },
    card: {
        height: '100%'
    },
    buttonCard: {
        textAlign: 'left'
    },
    cardItem: {
        boxShadow: '-10px -10px 30px 4px rgba(0,0,0,.1), 10px 10px 30px 4px rgba(45,78,255,.2)',
        borderRadius: '8px'
    },
    table: {
        minWidth: 700,
    },
    row: {
        '&:nth-of-type(odd)': {
            backgroundColor: '#F6F9FB',
        },
    },
    chip: {
        margin: theme.spacing.unit,
    },
    button: {
        margin: theme.spacing.unit,
        backgroundColor: '#007AB4',
        fontSize: '11px',
        color: '#FAFAFA',
        fontStyle: 'medium',
        borderRadius: '4px',
        height: '24px',
        marginLeft: theme.spacing.unit * 3,
    },
    button1: {
        margin: '160px',
        height: '40px',
        width: 140,
        marginLeft: '80px',
    },
    button2: {
        width: 100,
        marginLeft: '20px',
        marginTop: '20px',
        margin: theme.spacing.unit,
        backgroundColor: '#007AB4',
        fontSize: '11px',
        color: '#FAFAFA',
        fontStyle: 'medium',
        borderRadius: '4px',
        height: '40px',
        marginLeft: theme.spacing.unit * 3,
    },
    button3: {
        width: 100,
        marginLeft: '8px',
        marginTop: '20px',
        margin: theme.spacing.unit,
        backgroundColor: '#007AB4',
        fontSize: '11px',
        color: '#FAFAFA',
        fontStyle: 'medium',
        borderRadius: '4px',
        height: '40px',
    },
    leftIcon: {
        marginRight: theme.spacing.unit,
    },
    rightIcon: {
        marginLeft: theme.spacing.unit,
    },
    close: {
        padding: theme.spacing.unit / 2,
    },
    textField: {
        width: 90,
        fontSize: '14px !important',
        marginBottom: theme.spacing.unit * 50,
        marginTop: theme.spacing.unit * 50,
        marginLeft: '117px',
    },
    textField1: {
        marginLeft: theme.spacing.unit * 0,
        width: 100,
        fontSize: '12px !important',
    },
    textField2: {
        width: 320,
        marginBottom: theme.spacing.unit * 50,
        marginTop: theme.spacing.unit * -100,
        marginLeft: '-75px',
        fontSize: '12px !important',
    },
    textField3: {
        marginLeft: '61px',
        width: 100,
        fontSize: '12px !important',
    },
    textField4: {
        marginLeft: '65px',
        width: 100,
        fontSize: '12px !important',
    },
    textField5: {
        marginLeft: '30px',
        width: 100,
        fontSize: '12px !important',
    },
    textField6: {
        marginLeft: '42px',
        width: 100,
        fontSize: '12px !important',
    },
    textField7: {
        marginLeft: '7px',
        width: 100,
        fontSize: '12px !important',
    },
    checkboxfield: {
        marginBottom: theme.spacing.unit * 50,
        marginTop: theme.spacing.unit * -49.5,
        marginLeft: '-200px',
        width: 450,
    },
    checkboxfield1: {
        marginBottom: theme.spacing.unit * 50,
        marginTop: theme.spacing.unit * -51.5,
        marginLeft: '-200px',
        width: 450,
    },
    poCard: {
        textAlign: 'left'
    },
    date: {
        marginRight: theme.spacing.unit,
    },
    formControl: {
        margin: theme.spacing.unit,
        minWidth: 120,
    },
    formLabel: {
        padding: "7px 7px 7px",
        width: '50%',
        fontSize: '14px',
        color: 'black',
        marginLeft: theme.spacing.unit * 1.5,
        marginTop: theme.spacing.unit * 1.5,
    },
    formLabel1: {
        padding: "7px 7px 7px",
        width: '50%',
        fontSize: '14px',
        color: 'black',
        marginLeft: theme.spacing.unit * 1.5,
    },
    formLabel2: {
        padding: "7px 7px 7px",
        width: '50%',
        fontSize: '14px',
        color: 'black',
        marginLeft: theme.spacing.unit * 1.5,
        marginBottom: theme.spacing.unit * 50,
        marginTop: theme.spacing.unit * -45,
    },
    formLabel3: {
        padding: "7px 7px 7px",
        width: '50%',
        fontSize: '14px',
        color: 'black',
        marginLeft: theme.spacing.unit * 1.5,
        marginBottom: theme.spacing.unit * 50,
        marginTop: theme.spacing.unit * -50,
    },
    formLabel4: {
        padding: "7px 7px 7px",
        width: '50%',
        fontSize: '14px',
        color: 'black',
        marginLeft: theme.spacing.unit * 1.5,
        marginBottom: theme.spacing.unit * 50,
        marginTop: theme.spacing.unit * -99,
    },
    input: {
        width: '25%',
        fontSize: '14px',
        marginBottom: theme.spacing.unit * 1,
        marginLeft: theme.spacing.unit * 5.5,
        marginTop: theme.spacing.unit * 1.5,
        textAlignLast: 'start'
    },
    input1: {
        width: '25%',
        fontSize: '14px',
        marginBottom: theme.spacing.unit * 1,
        marginLeft: theme.spacing.unit * 5.5,
        textAlignLast: 'start'
    },
    input2: {
        width: '25%',
        fontSize: '14px',
        marginBottom: theme.spacing.unit * 50,
        marginTop: theme.spacing.unit * -9,
        marginLeft: '160px',
        textAlignLast: 'start'
    },
    input3: {
        width: '25%',
        fontSize: '14px',
        marginBottom: theme.spacing.unit * 50,
        marginTop: theme.spacing.unit * -45,
        marginLeft: theme.spacing.unit * 5.5,
        textAlignLast: 'start'
    },
    input4: {
        width: '25%',
        fontSize: '14px',
        marginBottom: theme.spacing.unit * 50,
        marginTop: theme.spacing.unit * -51,
        marginLeft: theme.spacing.unit * 5.5,
        textAlignLast: 'start'
    },
    input5: {
        width: '25%',
        fontSize: '14px',
        marginBottom: theme.spacing.unit * 50,
        marginTop: theme.spacing.unit * -51,
        marginLeft: theme.spacing.unit * 5.5,
        textAlignLast: 'end'
    },
    radio: {
        marginRight: '145px',
    },
});

const isChecked = (values, field) => {
    if (values.hasOwnProperty(field)) {
        if (typeof values[field] == 'string') {
            return parseInt(values[field]);
        }
        if (typeof values[field] == 'boolean')
            return values[field];
    }
    else
        return false;
}

class ForecastCalculation extends React.PureComponent {
    constructor(props) {
        super(props)
        this.state = {
            data: [],
            open: true,
            errorId: false,
            hasError: false,
            parameterValues: [],
            warehouse: 'whId',
        }
        this.handleChangeValue = this.handleChangeValue.bind(this);
    }

    handleOpen = () => {
        this.setState({ open: true });
    }

    handleClose = () => {
        this.setState({ open: false });
    }

    formatObject = (object) => {
        let newObject = { ...object };
        for (let key in newObject) {
            if (typeof newObject[key] == 'boolean') {
                newObject[key] = newObject[key] ? "1" : "0";
            }
        }
        return newObject;
    }

    onForecastCalculationSubmit = (values) => {
        values = this.formatObject(values);
        const warehouseList = this.props.warehouseDataList;
        const warehouseMList = warehouseList.listArray;
        let warehouseExist = false;
        for (let key in warehouseMList) {
            if (values.CFWHSE.trim() == warehouseMList[key]['WWHSE'].trim()) {
                warehouseExist = true;
                break;
            }
        }
        if (!warehouseExist && this.state.warehouse == 'whId') {
            this.setState({ hasError: true })
            this.setState({ errorId: '5163' })
            this.setState({ parameterValues: [values.CFWHSE.trim()] })
        } else {
            this.props.onForecastCalculationSubmit({ ...values });
        }
        this.handleClose();
    }

    sethaserror = (val) => {
        this.setState({ hasError: val });
    }

    handleChangeValue(event) {
        this.setState({
            warehouse: event.target.value,
        });
    }

    render() {
        const { classes, handleChange, values } = this.props;
        const { open } = this.state;
        return (
            <div className={classes.root}>
                {(this.state.hasError) ? <div>
                    <GridErrorMessages
                        errorMessageLabels={this.props.errorMessageLabels}
                        popUp={true}
                        sethaserror={this.sethaserror}
                        replaceValues={this.state.parameterValues}
                        id={this.state.errorId ? this.state.errorId : this.props.ServerError}
                    />
                </div> : ''}
                <Grid container spacing={2} >
                    <div className={classes.root} style={{ padding: 2 }}>
                        <Grid container>
                            <Modal
                                open={open}
                                onClose={this.handleClose}
                            >
                                <Card className={classes.card2}>
                                    <CardHeader className={classes.cardHeader1}
                                        title='Forecast Calculation'
                                    />
                                    <Box display="flex">
                                        <FormLabel className={classes.formLabel}>Company ID</FormLabel>
                                        <Input disabled name='CFCOMP' onChange={handleChange} className={classes.input} value={values['CFCOMP']} />
                                    </Box>
                                    <RadioGroup className={classes.radio} defaultValue={this.state.warehouse} value={this.state.warehouse} onChange={this.handleChangeValue} aria-label="gender" name="customized-radios">
                                        <FormControlLabel labelPlacement='start' value="whId" control={<RadioButton />} label="Warehouse ID" />
                                        <FormControlLabel labelPlacement='start' value="EaWh" control={<RadioButton />} label="All Warehouses" />
                                    </RadioGroup>
                                    <Box display="flex">
                                        <Input name='CFWHSE' onChange={handleChange} disabled={this.state.warehouse == 'whId' ? false : true} className={classes.input2} value={values['CFWHSE']} />
                                    </Box>
                                    <FormControlLabel
                                        control={<Checkbox name='CFSKMN' color={"primary"} onChange={handleChange} className={classes.textField3}
                                            checked={isChecked(values, 'CFSKMN')} />}
                                        label="Skip Manual"
                                        labelPlacement='start'
                                        className={classes.checkboxfield}
                                    />
                                    <FormControlLabel
                                        control={<Checkbox name='CFSKFR' color={"primary"} onChange={handleChange} className={classes.textField4}
                                            checked={isChecked(values, 'CFSKFR')} />}
                                        label="Skip Frozen"
                                        labelPlacement='start'
                                        className={classes.checkboxfield1}
                                    />
                                    <FormControlLabel
                                        control={<Checkbox name='CFUONL' color={"primary"} onChange={handleChange} className={classes.textField5}
                                            checked={isChecked(values, 'CFUONL')} />}
                                        label="Uninitialized Only"
                                        labelPlacement='start'
                                        className={classes.checkboxfield1}
                                    />
                                    <FormControlLabel
                                        control={<Checkbox name='CFIMAN' color={"primary"} onChange={handleChange} className={classes.textField6}
                                            checked={isChecked(values, 'CFIMAN')} />}
                                        label="Include Manual"
                                        labelPlacement='start'
                                        className={classes.checkboxfield1}
                                    />
                                    <FormControlLabel
                                        control={<Checkbox name='CFIDIS' color={"primary"} onChange={handleChange} className={classes.textField7}
                                            checked={isChecked(values, 'CFIDIS')} />}
                                        label="Include Discontinued"
                                        labelPlacement='start'
                                        className={classes.checkboxfield1}
                                    />
                                    <Button onClick={() => this.onForecastCalculationSubmit(values)} disabled={values['CFWHSE'] != '' || this.state.warehouse == 'EaWh' ? false : true} variant="contained" color="primary" className={classes.button2}>Ok</Button>
                                    <Button onClick={this.handleClose} variant="contained" color="secondary" className={classes.button3}>
                                        Cancel</Button>
                                </Card>
                            </Modal>
                        </Grid>
                    </div>
                </Grid>
            </div>
        )
    }

}

export default (withStyles(styles)(ForecastCalculation));
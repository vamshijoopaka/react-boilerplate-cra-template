import React from 'react';
import PropTypes from 'prop-types';
import KeyboardArrowDownIcon from '@material-ui/icons/KeyboardArrowDown';
import KeyboardArrowUpIcon from '@material-ui/icons/KeyboardArrowUp';
import { Box, Button, Grid, withStyles } from '@material-ui/core';
import withFixedPosition from 'containers/common/withFixedPosition';
import { onChangeContextMenu, updateBreadCrumbContextMenu } from 'utils/contextMenu';
import BreadcrumbContextMenu from 'components/common/BreadcrumbContextMenu';
import FormattedMessageComponent from '../../common/FormattedMessageComponent';
import { INITIAL_PAGE_PROPS } from '../../common/constants';
import ContextMenu from '../../common/ContextMenu';
import FilterIcon from '../../../images/icon_filter.png';
import { CONTEXT_MENU_ITEM_HEADER } from '../constants';
import InvestmentAnalysisDialog from '../InvestmentAnalysisDialog';
import LayeredSummaryDialog from '../LayeredSummaryDialog';
import { isEqual } from 'lodash';
const styles = () => ({
  propertiesHeaderContainer: {
    width: '100%',
    marginBottom: '1.5rem',
    backgroundColor: 'var(--background-app)',
    borderRadius: '0px 0px 4px 4px',
    overflow: 'hidden',
  },
  itemContainer: {
    display: 'flex',
    backgroundColor: 'var(--background-content)',
    fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
    alignItems: 'center',
    padding: '0 0 0 16px',
    position: 'relative',
  },
  itemDetailsWrapper: {
    display: 'flex',
    width: '100%',
  },
  itemArrow: {
    padding: '0 !important',
    margin: '0',
    minWidth: '16px',
    background: 'none',
    height: '16px',
    width: '16px',
  },
  itemArrowWrapper: {
    display: 'flex',
    flexDirection: 'column',
    border: '1px solid var(--primary-default)',
    borderRadius: '4px',
    justifyContent: 'center',
    alignItems: 'baseline',
    height: '38px',
    padding: '2px',
  },
  left: {
    width: 'calc(100% - 40px)',
    marginLeft: 15,
  },
  label: {
    color: 'var(--header-label-color)',
    padding: '0px 5px 5px 10px',
    whiteSpace: 'nowrap',
    '& label': {
      fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
    },
  },
  data: {
    padding: '0px 5px 20px 10px',
    '& label': {
      fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
    },
  },
  right: {
    float: 'right',
    width: 280,
    position: 'absolute',
    right: 10,
    top: 0,
  },
  buttonActionsSecondChild: {
    '& span': {
      fontSize: '1.23em',
    },
  },
  vendorActionsFilter: {
    minWidth: '37px',
    border: '1px solid var(--primary-default)',
    height: '32px',
    marginLeft: '35px',
    padding: '10px',
    '& img': {
      width: '14px',
      height: '14px',
    },
    '& svg': {
      width: '18px',
      height: '18px',
    },
  },
});

class Header extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      isOpenActionsContextMenu3dots: false,
      contextMenu: updateBreadCrumbContextMenu(props),
      isInvestmentAnalysisOpen: false,
      isLayeredSummaryOpen: false,
      contextMenuList: CONTEXT_MENU_ITEM_HEADER,
    };
  }

  componentDidMount = () => {
    this.fetchPageUpDownFlags();
    if (this.props.canUpdateComponent !== false) {
      this.setState(({ contextMenuList }) => ({ contextMenuList: contextMenuList.map(ele => ({ ...ele, isDisable: !this.props.canUpdateComponent.update })) }));
    }
  };
  componentDidUpdate(prevProps, prevState) {
    const { currentRecordData } = this.props.inventoryAnalysisPropertiesPage;
    if (currentRecordData && !isEqual(currentRecordData, prevProps.inventoryAnalysisPropertiesPage.currentRecordData)) {
      this.fetchPageUpDownFlags();
    }
  }
  fetchPageUpDownFlags = () => {
    const {
      pageUpDownAPI,
      inventoryAnalysisPropertiesPage,
    } = this.props;
    const { filterProps, sortProps, currentRecordData } = inventoryAnalysisPropertiesPage;
    const data = { ...INITIAL_PAGE_PROPS };
    data.isForwardDirection = true;
    data.pageSize = 3;
    const postObject = this.props.getApiObjForPageUpDown(
      filterProps,
      currentRecordData,
      'inventoryAnalysis',
      data,
      sortProps,
      true,
      true,
    );
    pageUpDownAPI(postObject);
  }
  getFormattedMessage = id => <FormattedMessageComponent id={id} />;

  onClickUpArrow = () => {
    const {
      // currentRecordData,
      pageUpDownAPI,
      inventoryAnalysisPropertiesPage,
    } = this.props;
    const { filterProps, sortProps, currentRecordData } = inventoryAnalysisPropertiesPage;
    const data = { ...INITIAL_PAGE_PROPS };
    data.isForwardDirection = false;
    data.pageSize = 3;
    const postObject = this.props.getApiObjForPageUpDown(
      filterProps,
      currentRecordData,
      'inventoryAnalysis',
      data,
      sortProps,
      true,
    );
    pageUpDownAPI(postObject);
  };

  onClickDownArrow = () => {
    const {
      // currentRecordData,
      pageUpDownAPI,
      inventoryAnalysisPropertiesPage,
    } = this.props;
    const { filterProps, sortProps, currentRecordData } = inventoryAnalysisPropertiesPage;
    const data = { ...INITIAL_PAGE_PROPS };
    data.isForwardDirection = true;
    data.pageSize = 3;
    const postObject = this.props.getApiObjForPageUpDown(
      filterProps,
      currentRecordData,
      'inventoryAnalysis',
      data,
      sortProps,
      false,
    );
    pageUpDownAPI(postObject);
  };

  handleDisableUpArrow = () => {
    const { hasPrevious } = this.props;
    return !hasPrevious ;
  };

  handleDisableDownArrow = () => {
    const { hasNext  } = this.props;
    return !hasNext ;
  };

  getValueFromData = (data, key) => {

    if (data[key]) return data[key]; 
    else if (key.trim().substr(0,1) === 'V') {
      key = 'PS' + key.trim().substr(1);
      if (data[key]) return data[key];
      else return ' ';
    } else {
      return ' ';
    }

  }

  setIsOpenContextMenu = (event, type) => {
    this.setState({
      [`isOpenActionsContextMenu${type}`]: false,
      [`menuRef${type}`]: event.currentTarget ? event.currentTarget : event,
    });
  };

  setIsOpenActionsContextMenu = (event = false, type = '') => {
    this.setState({
      [`isOpenActionsContextMenu${type}`]: Boolean(event),
      [`menuRef${type}`]: event.currentTarget ? event.currentTarget : event,
    });
  };

  handleHeaderActionItemSelection = value => {
    switch (value) {
      case 'Investment Analysis...':
        this.setState({
          isInvestmentAnalysisOpen: true,
        });
        break;
      case 'Layered Summary...':
        this.setState({
          isLayeredSummaryOpen: true,
        });
        break;
      default:
        break;
    }
    this.setIsOpenActionsContextMenu(false, '3dots');
  };

  handleItemHeaderFilterClick = () => {
    this.props.handleItemHeaderFilterClick();
  };

  onOptionChange = (event, value, filters = false, title = false) => {
    const defaultFilters = filters;
    const toPage = value;
    const displayName = title;
    onChangeContextMenu(this.props, event, toPage, defaultFilters, displayName);
    this.props.setSelectedValueForTabs('Show Me');
  };

  render() {
    const { classes, currentRecordData, freezeComponentStyle } = this.props;
    return (
      <div
        className={classes.propertiesHeaderContainer}
        style={{ ...freezeComponentStyle }}
      >
        {currentRecordData ? (
          <div className={classes.itemContainer}>
            <Box className={classes.itemDetailsWrapper}>
              <Box className={classes.itemArrowWrapper}>
                <Button
                  color="primary"
                  onClick={() => this.onClickUpArrow()}
                  className={classes.itemArrow}
                  disabled={this.handleDisableUpArrow()}
                >
                  <KeyboardArrowUpIcon />
                </Button>
                <Button
                  color="primary"
                  onClick={() => this.onClickDownArrow()}
                  className={classes.itemArrow}
                  disabled={this.handleDisableDownArrow()}
                >
                  <KeyboardArrowDownIcon />
                </Button>
              </Box>
              <Box style={{ width: '100%' }}>
                <Box className={classes.left}>
                  <Grid container>
                    <Grid item xs={12} sm={12} md={5} lg={3} xl={2}>
                      <Grid item container>
                        <Grid item xs={12} sm={12} md={6} lg={6} xl={6}>
                          <Grid item container>
                            <Grid
                              xs={12}
                              sm={12}
                              md={12}
                              lg={12}
                              xl={12}
                              className={classes.label}
                            >
                              <label>{this.getFormattedMessage('34433')}</label>
                            </Grid>
                            <Grid
                              xs={12}
                              sm={12}
                              md={12}
                              lg={12}
                              xl={12}
                              className={classes.data}
                            >
                              <label>
                                {this.getValueFromData(
                                  currentRecordData,
                                  'VVNDR',
                                )}
                              </label>
                            </Grid>
                          </Grid>
                        </Grid>
                        <Grid item xs={12} sm={12} md={6} lg={6} xl={6}>
                          <Grid item container>
                            <Grid
                              xs={12}
                              sm={12}
                              md={12}
                              lg={12}
                              xl={12}
                              className={classes.label}
                            >
                              <label>{this.getFormattedMessage('34435')}</label>
                            </Grid>
                            <Grid
                              xs={12}
                              sm={12}
                              md={12}
                              lg={12}
                              xl={12}
                              className={classes.data}
                            >
                              <label>
                                {this.getValueFromData(
                                  currentRecordData,
                                  'VSUBV',
                                )}
                              </label>
                            </Grid>
                          </Grid>
                        </Grid>
                      </Grid>
                      <Grid item container>
                        <Grid
                          item
                          xs={12}
                          sm={12}
                          md={12}
                          lg={12}
                          xl={12}
                          className={classes.label}
                        >
                          <label>{this.getFormattedMessage('36593')}</label>
                        </Grid>
                        <Grid
                          item
                          xs={12}
                          sm={12}
                          md={12}
                          lg={12}
                          xl={12}
                          className={classes.data}
                        >
                          <label>
                            {this.getValueFromData(currentRecordData, 'VNAME')}
                          </label>
                        </Grid>
                      </Grid>
                    </Grid>
                    <Grid xs={12} sm={12} md={4} lg={2} xl={1}>
                      <Grid item container>
                        <Grid
                          xs={12}
                          sm={12}
                          md={12}
                          lg={12}
                          xl={12}
                          className={classes.label}
                        >
                          <label>{this.getFormattedMessage('34372')}</label>
                        </Grid>
                        <Grid
                          xs={12}
                          sm={12}
                          md={12}
                          lg={12}
                          xl={12}
                          className={classes.data}
                        >
                          <label>
                            {this.getValueFromData(currentRecordData, 'VWHSE')}
                          </label>
                        </Grid>
                      </Grid>
                      <Grid item container>
                        <Grid
                          xs={12}
                          sm={12}
                          md={12}
                          lg={12}
                          xl={12}
                          className={classes.label}
                        >
                          <label>{this.getFormattedMessage('50870')}</label>
                        </Grid>
                        <Grid
                          xs={12}
                          sm={12}
                          md={12}
                          lg={12}
                          xl={12}
                          className={classes.data}
                        >
                          <label>
                            {this.getValueFromData(currentRecordData, 'VBUYR')}
                          </label>
                        </Grid>
                      </Grid>
                    </Grid>
                  </Grid>
                </Box>
                <Box className={classes.right}>
                  <Grid container>
                    <Grid item xs={12} sm={12} md={12} lg={12} xl={12}>
                      <Grid item container>
                        <Grid item xs={5} sm={5} md={5} lg={5} xl={5}>
                          <div className={classes.buttonActionsSecondChild}>
                            <Button
                              color="primary"
                              size="small"
                              variant="outlined"
                              onClick={event =>
                                this.setIsOpenActionsContextMenu(event, '3dots')
                              }
                            >
                              <div>{this.getFormattedMessage('28310')}</div>
                              <KeyboardArrowDownIcon />
                            </Button>
                            <ContextMenu
                              className={classes.menuButton}
                              menuList={this.state.contextMenuList}
                              isOpen={this.state.isOpenActionsContextMenu3dots}
                              menuRef={this.state.menuRef3dots}
                              handleItemSelection={
                                this.handleHeaderActionItemSelection
                              }
                              handleMenuClose={val =>
                                this.setIsOpenContextMenu(val, '3dots')
                              }
                            />
                          </div>
                        </Grid>
                        <Grid
                          item
                          xs={3}
                          sm={3}
                          md={3}
                          lg={3}
                          xl={3}
                          style={{
                            paddingTop: 6,
                            fontSize: '1.23em',
                          }}
                        >
                          <BreadcrumbContextMenu
                            menuItems={this.state.contextMenu}
                            onOptionChange={this.onOptionChange}
                          />
                        </Grid>
                        <Grid
                          item
                          xs={2}
                          sm={2}
                          md={2}
                          lg={2}
                          xl={2}
                          style={{ marginLeft: 12 }}
                        >
                          <Button
                            component="div"
                            color="primary"
                            onClick={this.handleItemHeaderFilterClick}
                            className={classes.vendorActionsFilter}
                          >
                            <img src={FilterIcon} alt="Filter Icon" />
                          </Button>
                        </Grid>
                      </Grid>
                    </Grid>
                  </Grid>
                </Box>
              </Box>
            </Box>
          </div>
        ) : null}
        {this.state.isInvestmentAnalysisOpen ? (
          <InvestmentAnalysisDialog
            onClose={() => this.setState({ isInvestmentAnalysisOpen: false })}
            investmentAnalysis={this.props.investmentAnalysis}
            companyDetails={this.props.companyDetails}
          />
        ) : null}
        {this.state.isLayeredSummaryOpen ? (
          <LayeredSummaryDialog
            onClose={() => this.setState({ isLayeredSummaryOpen: false })}
            layeredSummary={this.props.layeredSummary}
          />
        ) : null}
      </div>
    );
  }
}

Header.propTypes = {
  classes: PropTypes.object,
  currentRecordData: PropTypes.object,
  inventoryAnalysisPropertiesPage: PropTypes.object,
  pageUpDownAPI: PropTypes.func,
  setSelectedValueForTabs: PropTypes.func,
  handleItemHeaderFilterClick: PropTypes.func,
  investmentAnalysis: PropTypes.func,
  layeredSummary: PropTypes.func,
  freezeComponentStyle: PropTypes.object,
  getApiObjForPageUpDown: PropTypes.func,
};

export default withStyles(styles)(withFixedPosition(Header));

import React, { Component } from 'react';
import ModelDeal from 'containers/DealsEmbeddedListPage/ModelDeal';

class ModelDealDialog extends Component {
	constructor(props) {
		super(props);
		this.state = {

		}
	}

	render() {
		return (
			<div>
				<ModelDeal
					{...this.props} />
			</div>)
	}
}
export default ModelDealDialog;
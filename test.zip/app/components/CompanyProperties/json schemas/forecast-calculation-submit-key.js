export const forecastCalculationSubmitKeyDS =
[
    {
        "COLUMN_NAME": "CFCOMP",
        "TABLE_NAME": "DSCFCST",
        "ORDINAL_POSITION": "1",
        "DATA_TYPE": "CHAR    ",
        "LENGTH": "3",
        "NUMERIC_SCALE": null,
        "COLUMN_HEADING": "Company ID",
        "TABLE_SCHEMA": "E3T19100",
        "DDS_TYPE": "A"
    },
    {
        "COLUMN_NAME": "CFWHSE",
        "TABLE_NAME": "DSCFCST",
        "ORDINAL_POSITION": "2",
        "DATA_TYPE": "CHAR    ",
        "LENGTH": "3",
        "NUMERIC_SCALE": null,
        "COLUMN_HEADING": "Warehouse ID",
        "TABLE_SCHEMA": "E3T19100",
        "DDS_TYPE": "A"
    },
    {
        "COLUMN_NAME": "CFSKFR",
        "TABLE_NAME": "DSCFCST",
        "ORDINAL_POSITION": "3",
        "DATA_TYPE": "CHAR    ",
        "LENGTH": "1",
        "NUMERIC_SCALE": null,
        "COLUMN_HEADING": "SKIP                FROZEN",
        "TABLE_SCHEMA": "E3T19100",
        "DDS_TYPE": "A"
    },
    {
        "COLUMN_NAME": "CFSKMN",
        "TABLE_NAME": "DSCFCST",
        "ORDINAL_POSITION": "4",
        "DATA_TYPE": "CHAR    ",
        "LENGTH": "1",
        "NUMERIC_SCALE": null,
        "COLUMN_HEADING": "SKIP                MANUAL",
        "TABLE_SCHEMA": "E3T19100",
        "DDS_TYPE": "A"
    },
    {
        "COLUMN_NAME": "CFUONL",
        "TABLE_NAME": "DSCFCST",
        "ORDINAL_POSITION": "5",
        "DATA_TYPE": "CHAR    ",
        "LENGTH": "1",
        "NUMERIC_SCALE": null,
        "COLUMN_HEADING": "U                   ONLY",
        "TABLE_SCHEMA": "E3T19100",
        "DDS_TYPE": "A"
    },
    {
        "COLUMN_NAME": "CFIMAN",
        "TABLE_NAME": "DSCFCST",
        "ORDINAL_POSITION": "6",
        "DATA_TYPE": "CHAR    ",
        "LENGTH": "1",
        "NUMERIC_SCALE": null,
        "COLUMN_HEADING": "INCLUDE             MANUAL",
        "TABLE_SCHEMA": "E3T19100",
        "DDS_TYPE": "A"
    },
    {
        "COLUMN_NAME": "CFIDIS",
        "TABLE_NAME": "DSCFCST",
        "ORDINAL_POSITION": "7",
        "DATA_TYPE": "CHAR    ",
        "LENGTH": "1",
        "NUMERIC_SCALE": null,
        "COLUMN_HEADING": "INCLUDE             DISCONTINUED",
        "TABLE_SCHEMA": "E3T19100",
        "DDS_TYPE": "A"
    }
]
import React, { Component } from 'react';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import { withStyles, Box, Typography } from '@material-ui/core';
import theme from '../../../jda-gcp-theme';
import DialogComponent from 'components/common/DialogComponent';
import FormattedMessageComponent from '../../common/FormattedMessageComponent';
import EmbeddedList from 'containers/common/EmbeddedList';
import Spinner from 'components/Common/Spinner';
import {
	DIALOG_TITLE_DELETE, TEXT_DELETE,
	FROM_WAREHOUSES, EVENT_SUMMARY, WAREHOUSE, EVENT_ID, REF_ID, EVENT_DESC, 
	BEGIN_DATE, END_DATE, ITEM, VENDOR_ID, SHIP_DATE_TO_CUSTOMER, CUSTOMER_ID,
	MENU_ITEMS, EVENTS_FILTER_VALUES, EVENTS,
	WAREHOUSE_PAGE, EVENTS_PAGE
} from "./constants";
import { TEXT_CANCEL, TEXT_ALERT, TEXT_OK } from '../../common/constants';
import { INITIAL_PAGE_PROPS } from 'components/common/constants';
import { getListPredecessor, getDateFormatValue } from 'utils/util';
import ConfirmationDialog from 'components/common/ConfirmationDialog';

const styles = theme => ({
	adjustDialog1: {
		maxHeight: '93vh',
		'& .MuiDialogContent-root': {
			padding: '12px'
		},
	},
	notesForBlock: {
		display: 'flex',
		flexDirection: 'column',
		marginTop: '25px',
		border: '1px solid var(--divider-line)',
		padding: '10px 10px 0 10px',
		position: 'relative'
	},
	notesForLabel: {
		position: 'absolute',
		top: '-7px',
		left: '10px',
		background: 'var(--background-content)',
		padding: '0 8px',
	},
	fieldLabel: {
		color: 'var(--header-label-color)',
		padding: '0 0px 8px 0',
		width: '22ch',
	},
	childBlock: {
		display: 'flex',
		padding: '6px'
	},
	fieldValue: {
		color: 'var(--value)'
	},
	fieldValuesParent: {
		display: 'flex'
	},
	idValue: {
		marginRight: '20px',
		minWidth: '15ch'
	}
});

class DeleteDialog extends Component {
	constructor(props) {
		super(props);
		this.state = {
			selectAllFlag: false,
			selectedCount: 0,
			selectedRecordsObject: {},
			menuItems: [...MENU_ITEMS],
			rowSelection: 'multiple',
			selectedRows: false,
			deleteConfirmationDialog: false,
			valueDataFailureMessages: [],
			showValueConfirmationDialog: false,
		}
		this.handleValueDataErrorMessages = this.handleValueDataErrorMessages.bind(this);
	}

	getLabelValue(id) {
		return <FormattedMessageComponent id={id}></FormattedMessageComponent>;
	}

	componentWillUnmount() {
	}

	componentDidMount() {
		const { headerJson } = this.props
	}

	componentDidUpdate(prevProps, prevState) {
		const { columnDefs, rowData, isColumnDefsLoaded, filterProps, pageProps, updateColumnsList, eventDetailData } = this.props;

		if (this.state.valueDataFailureMessages && this.state.valueDataFailureMessages.length
			&& (JSON.stringify(this.state.valueDataFailureMessages) != JSON.stringify(prevState.valueDataFailureMessages))) {
			this.handleValueDataErrorMessages(this.state.valueDataFailureMessages[0]);
		}
	}

	handleClose = () => {
		this.props.handleCopyDeletePopup('openDeletePopup', false)
	}

	onGridReady = (params) => {
		this.grid = params;
	}

	//Create an array of Objects and send to api 
	handleSubmit = () => {
		const { filterProps, eventDetailData, headerJson } = this.props;
		let currentRecord = headerJson;
		const { events } = this.props;
		let listParams = { filterProps, pageProps: { pageSize: 3 }, direction: true, currentPage: 'events' }

		this.props.eventDetailsDelete(eventDetailData,true,listParams);
		this.handleClose();
	}
	prepareData = data => {
		let dataArray = []
		const { headerJson, eventDetailData } = this.props;
		return dataArray;
	}
	handleConfirmBeforeSubmit = (flag = true) => {
		this.setState({ deleteConfirmationDialog: flag })
	}

	closeValueDialog = () => {
		this.setState({ showValueConfirmationDialog: false });
		if (this.state.valueDataFailureMessages && this.state.valueDataFailureMessages.length) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.shift();
			this.setState({ valueDataFailureMessages: values });
			if (values && values.length == 0) {
				this.handleClose();
			}
		}
	}
	handleValueDataErrorMessages(content) {
		this.setState({ showValueConfirmationDialog: true, dialogContent: content });
	}
	render() {
		const { classes, columnDefs, apiCallCount, loading, rowData, headerJson, eventDetailData, errorMessages, events } = this.props;

		return (<React.Fragment>
			<DialogComponent
				className={classes.adjustDialog1}
				isOpen={this.props.openDeletePopup}
				dialogTitle={this.getLabelValue(DIALOG_TITLE_DELETE)}
				cancelText={TEXT_CANCEL}
				submitText={TEXT_OK}
				handleClose={e => this.handleClose()}
				handleCancel={e => this.handleClose()}
				handleSubmit={() => this.handleConfirmBeforeSubmit()}
				// disableSubmit={(this.getSelectedRowsForAPI() && this.getSelectedRowsForAPI().length) ? false : true}
				>
				<React.Fragment>
					<div className={classes.notesForBlock}>
						<Box mb={theme.spacing(0.5)} className={classes.notesForLabel}>
							<FormattedMessageComponent id={this.getLabelValue(EVENT_SUMMARY)}></FormattedMessageComponent>
						</Box>
						<Box className={classes.childBlock}>
							<div className={classes.fieldLabel}>{this.getLabelValue(EVENT_ID)}</div>
							<div className={classes.fieldValuesParent}>
								<Typography className={classes.fieldValue + ' ' + classes.idValue}>{eventDetailData["EHEVNT"]}</Typography>
							</div>
						</Box>
						<Box className={classes.childBlock}>
							<div className={classes.fieldLabel}>{this.getLabelValue(REF_ID)}</div>
							<div className={classes.fieldValuesParent}>
								<Typography className={classes.fieldValue + ' ' + classes.idValue}>{eventDetailData["EHREFN"]}</Typography>
							</div>
						</Box>
						<Box className={classes.childBlock}>
							<div className={classes.fieldLabel}>{this.getLabelValue(EVENT_DESC)}</div>
							<div className={classes.fieldValuesParent}>
								<Typography className={classes.fieldValue + ' ' + classes.idValue}>{eventDetailData["EHDESC"]}</Typography>
							</div>
						</Box>
						<Box className={classes.childBlock}>
							<div className={classes.fieldLabel}>{this.getLabelValue(BEGIN_DATE)}</div>
							<Typography className={classes.fieldValue + ' ' + classes.idValue}>{(Number(eventDetailData["EHBGDT"])) && getDateFormatValue(eventDetailData["EHBGDT"])}</Typography>
						</Box>
						<Box className={classes.childBlock}>
							<div className={classes.fieldLabel}>{this.getLabelValue(END_DATE)}</div>
							<Typography className={classes.fieldValue + ' ' + classes.idValue}>{(Number(eventDetailData["EHENDT"])) && getDateFormatValue(eventDetailData["EHENDT"])}</Typography>
						</Box>
					</div>
					{this.state.deleteConfirmationDialog &&
						<ConfirmationDialog
							isOpen={this.state.deleteConfirmationDialog}
							dialogTitle={this.getLabelValue('52891')}
							cancelText={TEXT_CANCEL}
							submitText={TEXT_OK}
							handleClose={e => this.handleConfirmBeforeSubmit(false)}
							handleCancel={e => this.handleConfirmBeforeSubmit(false)}
							handleSubmit={e => this.handleSubmit()}>
							<div>
								{errorMessages ? errorMessages['E19816']['MTEXT'] : 'Confirmation'}
							</div>
						</ConfirmationDialog>
					}
					{this.state.showValueConfirmationDialog && <ConfirmationDialog
						hasError={true}
						isOpen={this.state.showValueConfirmationDialog}
						dialogTitle={TEXT_ALERT}
						submitText={TEXT_OK}
						handleClose={e => this.closeValueDialog()}
						handleCancel={e => this.closeValueDialog()}
						handleSubmit={e => this.closeValueDialog()}
					>
						<div>
							{this.state.dialogContent}
						</div>
					</ConfirmationDialog>
					}
				</React.Fragment>
			</DialogComponent>

		</React.Fragment>
		);
	}
}

export default withStyles(styles)(DeleteDialog);

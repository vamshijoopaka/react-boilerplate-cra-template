/** Change Log
 * LogStart --  E3C-33122 - Thanuja - 19 October,2021 - 2022.1.0.0 Unified Product
 *              Story: E3C-33122 --OPT Details not captured in Web
 * LogStart --  E3C-33377 - Kumar A - 16 November,2021 - 2022.1.0.0 Unified Product
 *              Story: E3C-33377 --Item balance details display - Rows are not in the same sequence as Client; Cust Back Order is repeated
*/
export const ITEM_DETAIL_UNITS_WORKDAYS = '50387';
export const ITEM_DETAIL_DEMAND_ORDER_COMPONENTS = '50543';
export const ITEM_DETAIL_USER_DEFINED_FIELDS = '50387';
export const CUSTOM_EXIT_NOT_FOUND = '6217';

export const CUSTOM_CARD_ONE = '4434';
export const CUSTOM_CARD_TWO = '4501';
export const CUSTOM_CARD_THREE = '3331';
export const CUSTOM_CARD_FOUR = '4452';

export const CUSTOM_CARD_KEY = '50916';

export const CUSTOM_CARDS = [
  {
    cardtitle: 'Custom cards',
    cardkey: '50916',
    cardfields: [
      {
        FLDID: '4434',
        FLDTYPE: 'TextBox',
        FDPROD: ' ',
        FDFILD: '4434',
        FDFNAM: 'VACTDT    ',
        FDPRFX: '1',
        FDFCLS: 'S',
        FDFTYP: 'D',
        FDMINV: '.0000',
        FDMAXV: '.0000',
        FDVLDT: 'N',
        FDZAPO: 'M',
        FDFLEN: '7',
        FDDECP: '0',
        FDDEFN: 'IDF_ACTDT                                         ',
        FDMASK: '                                                  ',
        FDLTRL: '                                                  ',
        FDDATR: '                                                  ',
        FDDPRN: '0',
        FDDDIV: '0',
        TLANG: 'ENG',
        TPROD: ' ',
        TIDNO: '34434',
        TDEFN: 'IDx_34434                                         ',
        TLLAB:
          'Deactivate Until                                                                                    ',
        TULLB:
          '                                                                                                    ',
        TSLAB: '                    ',
        TUSLB: '                    ',
        FLDVLD: '',
      },
      {
        FLDID: '4501',
        FLDTYPE: 'checkbox',
        FDPROD: ' ',
        FDFILD: '4501',
        FDFNAM: 'CALSW     ',
        FDPRFX: '0',
        FDFCLS: 'S',
        FDFTYP: 'N',
        FDMINV: '.0000',
        FDMAXV: '9.0000',
        FDVLDT: 'N',
        FDZAPO: 'N',
        FDFLEN: '1',
        FDDECP: '0',
        FDDEFN: '                                                  ',
        FDMASK: '                                                  ',
        FDLTRL: '                                                  ',
        FDDATR: '                                                  ',
        FDDPRN: '0',
        FDDDIV: '0',
        TLANG: 'ENG',
        TPROD: ' ',
        TIDNO: '34501',
        TDEFN: 'IDT_CALSW                                         ',
        TLLAB:
          'Calendar                                                                                            ',
        TULLB:
          '                                                                                                    ',
        TSLAB: '                    ',
        TUSLB: '                    ',
        FLDVLD: '',
      },
      {
        FLDID: '3331',
        FLDTYPE: 'COMBOBOX',
        FDPROD: ' ',
        FDFILD: '3331',
        FDFNAM: 'DPERD     ',
        FDPRFX: '0',
        FDFCLS: 'F',
        FDFTYP: 'N',
        FDMINV: '12.0000',
        FDMAXV: '52.0000',
        FDVLDT: 'Y',
        FDZAPO: 'N',
        FDFLEN: '2',
        FDDECP: '0',
        FDDEFN: '                                                  ',
        FDMASK: '                                                  ',
        FDLTRL: '                                                  ',
        FDDATR: '                                                  ',
        FDDPRN: '0',
        FDDDIV: '0',
        TLANG: 'ENG',
        TPROD: ' ',
        TIDNO: '33331',
        TDEFN: 'IDT_DPERD                                         ',
        TLLAB:
          'History Periodicity                                                                                 ',
        TULLB:
          '                                                                                                    ',
        TSLAB: '                    ',
        TUSLB: '                    ',
        FLDVLD: '12=Monthly|13=4-Week|52=Weekly',
      },
      {
        FLDID: '4452',
        FLDTYPE: 'TextBox',
        FDPROD: ' ',
        FDFILD: '4452',
        FDFNAM: 'ORMON     ',
        FDPRFX: '0',
        FDFCLS: 'S',
        FDFTYP: 'N',
        FDMINV: '.0000',
        FDMAXV: '31.0000',
        FDVLDT: 'N',
        FDZAPO: 'M',
        FDFLEN: '2',
        FDDECP: '0',
        FDDEFN: '                                                  ',
        FDMASK: '                                                  ',
        FDLTRL: '                                                  ',
        FDDATR: '                                                  ',
        FDDPRN: '0',
        FDDDIV: '0',
        TLANG: 'ENG',
        TPROD: ' ',
        TIDNO: '34452',
        TDEFN: 'IDT_ORMON                                         ',
        TLLAB:
          'Order Day in Month                                                                                  ',
        TULLB:
          '                                                                                                    ',
        TSLAB: '                    ',
        TUSLB: '                    ',
        FLDVLD: '',
      },
    ],
  },
];
export const COST_TABLE_KEY_LABEL = [
  {
    key:'IPCHPR',
    label:'33725'
  },
  {
    key:'IEFFPR',
    label:'33726'
  },
  {
    key:'IOVRPR',
    label:'33852'
  },
  {
    key:'IPCHPE',
    label:'33553'
  },
]

export const STOCKSTATUS_TABLE_KEY_LABEL = [
  {
    key:'IONHND',
    label:'33683'
  },
  {
    key:'IONORD',
    label:'33684'
  },
  { //E3C-33377, 11/16/21, Kumar:Start
    key: 'IPIUNT',
    label: '33698'
  },
  {
    key: 'ISOQB',
    label: '40036'
  }, //E3C-33377, 11/16/21, Kumar:End
  {
    key:'IONBAC',
    label:'34207'
  },
  {
    key:'IQRSVR',
    label:'33689'
  },
  {
    key:'IQHELD',
    label:'33690'
  },
  {
    key:'IOHHDT',
    label:'33691',
    dataType: 'date',
  },
  {
    key:'IOQHLD',//Auto Held
    label:'33826'
  },
  {
    key:'IOOPRM',
    label:'33693'
  },
  {
    key:'IOHPUB',
    label:'33697'
  },
  {
    key:'IEOQDT',
    label:'33840'
  },
  {
    key:'ISOQB',
    label:'33831'
  },
  {
    key:'IBALCE',
    label:'33687'
  }
]

export const FB_UNITS =
{
  FLDID: '',
  FLDTYPE: 'RightLabel',
  FDPROD: ' ',
  FDFILD: '',
  FDFNAM: '    ',
  FDPRFX: '1',
  FDFCLS: 'S',
  FDFTYP: 'C',
  FDMINV: '.0000',
  FDMAXV: '.0000',
  FDVLDT: 'N',
  FDFLEN: '7',
  FDDEFN: '                                         ',
  FDMASK: '                                                  ',
  FDLTRL: '                                                  ',
  FDDATR: '                                                  ',
  FDDPRN: '0',
  FDDDIV: '0',
  TLANG: 'ENG',
  TPROD: ' ',
  TIDNO: '',
  TDEFN: '                                         ',
  TLLAB: 'Forward Buy',
  TULLB:
    '                                                                                                    ',
  TSLAB: '                    ',
  TUSLB: '                    ',
  FLDVLD: '',
  dataType: "labels",
};
export const MONTHLY_LABEL_ID_START = 35173;
export const WEEKLY13_LABEL_ID_START = 35186;
export const WEEKLY52_LABEL_ID_START = 35200;


export const LT_QUOTED = 
{
  "FLDID": "4465",
  "FLDTYPE": "RightLabel",
  "FDPROD": " ",
  "FDFILD": "4465",
  "FDFNAM": "VLTQTD     ",
  "FDPRFX": "1",
  "FDFCLS": "S",
  "FDFTYP": "N",
  "FDMINV": ".0000",
  "FDMAXV": "365.0000",
  "FDVLDT": "N",
  "FDZAPO": "D",
  "FDFLEN": "3",
  "FDDECP": "0",
  "FDDEFN": "                                                  ",
  "FDMASK": "                                                  ",
  "FDLTRL": "                                                  ",
  "FDDATR": "                                                  ",
  "FDDPRN": "0",
  "FDDDIV": "0",
  "TLANG": "ENG",
  "TPROD": " ",
  "TIDNO": "34465",
  "TDEFN": "IDT_LTQTD                                         ",
  // "TLLAB": "Lead Time Quoted",
  "TLLAB": "",
  "TULLB": "",
  "TSLAB": "",
  "TUSLB": "",
  "FLDVLD": "",
  "dataType": "labels",
  // "hideLabel": "1",
  "key": "CLTQTD",
  "prefixFlag": 1,
  "maxLength": 5,
  "maxValue": 365,
  "width": 105



}
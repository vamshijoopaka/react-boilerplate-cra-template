export const COLUMN_DEFS = [{
}];

export const MENU_ITEMS = [
    {
        label: '2812',
        key: 'showHide',
        hasSubMenu: false,
        isDisable: false
    },
    {
        label: '25536',
        key: 'selectAll',
        hasSubMenu: false,
        isDisable: false
    },
    {
        label: '50278',
        key: 'deselectAll',
        hasSubMenu: false,
        isDisable: false
    },
]

export const WAREHOUSES = 'modeldeleteall';
export const WAREHOUSE_FILTER_VALUES = [{ "accessor": "COMP", "operator": "=", "jOpr": "and", "fieldValue": "E3T", "prefixFlag": 0 }]
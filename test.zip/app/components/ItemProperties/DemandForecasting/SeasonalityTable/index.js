import React from 'react';
import PropTypes from 'prop-types';
import {
  TableContainer,
  TableHead,
  Table,
  TableRow,
  TableCell,
  TableBody,
} from '@material-ui/core';
import {
  createStyles,
  withStyles,
  createMuiTheme,
} from '@material-ui/core/styles';
import theme from '../../../../jda-gcp-theme';
import { mean, round } from 'lodash';
import { FieldInput } from '../../../common/Form';
import { isEqual } from 'lodash';
import { getFormattedNumber } from '../../../../utils/util';

const themes = createMuiTheme(theme);
themes.overrides = {
  MuiCardHeader: {
    root: {
      padding: '0rem 0.5rem',
    },
  },
  MuiTableCell: {
    head: {
      color: 'black',
      paddingLeft: '12px',
      fontSize: '12px',
    },
    root: {
      padding: '5px',
    },
    body: {
      color: 'rgba(0, 0, 0, 0.87)',
      paddingLeft: '14px',
      fontSize: '12px',
      paddingRight: '14px',
      minWidth: '158px',
    },
    alignLeft: {
      borderRight: '1px solid black !important',
      borderLeft: '1px solid black !important',
      borderTop: '1px solid black !important',
      borderBottom: '1px solid black !important',
      // minWidth:'158px'
    },
  },
  MuiPaper: {
    root: {
      backgroundColor: '#ffffff',
    },
  },
  MuiInputBase: {
    input: {
      fontSize: '12px',
    },
  },
};

const style = createStyles(() => ({
  tableContainer: {
    width: '100%',
  },
  table: {
    width: '100%',
  },
  tableHead: {
    color: '#000',
  },
  tableCell1: {
    whiteSpace: 'nowrap',
    backgroundColor: '#f5f5f6',
    color: '#000000',
    border: 'solid 1px #000000',
    padding: 5,
  },
  tableCell2: {
    whiteSpace: 'nowrap',
    backgroundColor: '#FFFFFF',
    color: '#000000',
    border: 'solid 1px #000000',
    padding: 5,
  },
  tableHeaderCell: {
    textAlign: 'center',
  },
  tableCell: {
    textAlign: 'right',
  },
  cellInput: {
    '& [class*="MuiInputBase-input"]': {
      textAlign: 'right',
    }
  },
}));

class SeasonalityTable extends React.Component {

  handleChange = (key, value) => {
    this.props.handleCompositeChange(key, value);
  }
  getLatestYearValue = (data, year, index) => {
    const { columnDefs, hideValuesFromCurrentDate } = this.props;
    if (hideValuesFromCurrentDate)
      data = hideValuesFromCurrentDate({ data, year, index, columnDefs })
    if (data === '') return '';
    return data;
  }
  render() {
    const { classes, columnDefs, series, profileIndices, simInProgress, compositeSeries: compositeSeriesEdited, getLabelFromId } = this.props;
    let compositeSeries;
    const profile = { data: [], key: 'Profile', name: getLabelFromId('25237'), displayId: '25237' };
    if (series && series.length) {
      compositeSeries = series.find(s => s.key === 'Composite');
      if (simInProgress) {
        if (compositeSeries.data && compositeSeries.data.some(Boolean)) {
          const avgDemand = mean(compositeSeries.data);
          profile.data = compositeSeries.data.map(val => round(val / avgDemand, 2));
        } else {
          profile.data = Array(compositeSeries.data.length).fill(0);
        }
      }
      else if (profileIndices) {
        profile.data = profileIndices;
      }
    }
    const yearsSeries = series.filter(s => !isNaN(parseInt(s.key, 10)));
    const years = yearsSeries.map(s => parseInt(s.key, 10)).sort();
    let latestYear;
    let latestYearSeries;
    if (years && years.length) {
      latestYear = years[years.length - 1];
      latestYearSeries = yearsSeries.find(s => s.key === `${latestYear}`);
    }
    if (compositeSeries && compositeSeriesEdited)
      compositeSeries = compositeSeriesEdited;
    return (
      <TableContainer className={classes.tableContainer}>
        <Table className={classes.table}>
          <TableHead className={classes.tableHead}>
            {columnDefs && columnDefs.length ? (
              <TableRow>
                <TableCell className={classes.tableCell1} />
                {columnDefs.map(column => (
                  <TableCell
                    className={`${classes.tableCell1} ${classes.tableHeaderCell
                      }`}
                  >
                    {column}
                  </TableCell>
                ))}
              </TableRow>
            ) : null}
          </TableHead>
          <TableBody>
            {compositeSeries ? (
              <TableRow>
                <TableCell className={classes.tableCell2}>
                  {getLabelFromId(compositeSeries.displayId) || compositeSeries.name}
                </TableCell>
                {compositeSeries.data && compositeSeries.data.length
                  ? compositeSeries.data.map((data, rowIndex) => (
                    <TableCell
                      className={`${classes.tableCell2} ${classes.tableCell}`}
                    >
                      {simInProgress
                        ? <FieldInput
                          field={{
                            type: 'number', key: `${rowIndex}`, Attr: ' '
                          }}
                          maxLength={7}
                          precisionLength={2}
                          numberType={'decimal'}
                          onChange={this.handleChange}
                          value={data?.toString()}
                          enableAddButton={() => { }}
                          errorMessageLabel={getLabelFromId('50765')}
                          errorMessageLabels={this.props.errorMessageLabels}
                          globalNumberFormat={this.props.globalNumberFormat}
                          globalNumberSeparator={this.props.globalNumberSeparator}
                          className={classes.cellInput}
                        />
                        : getFormattedNumber(data, this.props.globalNumberFormat, this.props.globalNumberSeparator, 0, this.props.globalDecimalSeparator)}

                    </TableCell>
                  ))
                  : null}
              </TableRow>
            ) : null}
            {profile ? (
              <TableRow>
                <TableCell className={classes.tableCell1}>
                  {profile.name}
                </TableCell>
                {profile.data && profile.data.length
                  ? profile.data.map(data => (
                    <TableCell className={`${classes.tableCell1} ${classes.tableCell}`}>
                      {data === " " ? " " : getFormattedNumber(data, this.props.globalNumberFormat, this.props.globalNumberSeparator, 2, this.props.globalDecimalSeparator)}
                    </TableCell>
                  ))
                  : null}
              </TableRow>
            ) : null}
            {latestYearSeries ? (
              <TableRow>
                <TableCell className={classes.tableCell2}>
                  {latestYearSeries.name}
                </TableCell>
                {latestYearSeries.data && latestYearSeries.data.length
                  ? latestYearSeries.data.map((data, index) => (
                    <TableCell className={`${classes.tableCell2} ${classes.tableCell}`}>
                      {this.getLatestYearValue(data, latestYear, index)}
                    </TableCell>
                  ))
                  : null}
              </TableRow>
            ) : null}
          </TableBody>
        </Table>
      </TableContainer>
    );
  }
}

SeasonalityTable.propTypes = {
  columnDefs: PropTypes.array,
  classes: PropTypes.object,
};

export default withStyles(style)(SeasonalityTable);

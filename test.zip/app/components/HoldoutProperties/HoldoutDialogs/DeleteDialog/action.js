import {
    GET_HOLDOUTDELETE_LIST,
    GET_HOLDOUTDELETE_LIST_SUCCESS,
    GET_HOLDOUTDELETE_LIST_FAILURE,
    GET_HOLDOUTDELETE_COLUMN_DEFINITION,
    GET_HOLDOUTDELETE_COLUMN_DEFINITION_SUCCESS,
    GET_HOLDOUTDELETE_COLUMN_DEFINITION_FAILURE,
    GET_HOLDOUTDELETE_UPDATE_COLUMN_DEFINITION,
    GET_HOLDOUTDELETE_UPDATE_COLUMN_DEFINITION_SUCCESS,
    GET_HOLDOUTDELETE_UPDATE_COLUMN_DEFINITION_FAILURE,
    RESET_DEFAULTS,
    RESET_DEFAULTS_SUCCESS,
    RESET_DEFAULTS_FAILURE,
    SET_FILTER_VALUES,
    SET_COLUMN_DEFS_LOADED,
    SET_PAGEPROPS,
    SET_APICALL_COUNT,
    RESET_DATA,// needs to be handled carefully 
    GET_HOLDOUTS_LIST,
    GET_HOLDOUTS_LIST_SUCCESS,
    GET_HOLDOUTS_LIST_FAILURE,
    LABEL_DATA_FLAGS
} from './constants';

export function getHoldoutDeleteList(namespace, data) {
    return {
        type: GET_HOLDOUTDELETE_LIST,
        data
    }
}

export function setHoldoutDeleteListSuccess(data) {
    return {
        type: GET_HOLDOUTDELETE_LIST_SUCCESS,
        data
    }
}

export function setHoldoutDeleteListFailure(data) {
    return {
        type: GET_HOLDOUTDELETE_LIST_FAILURE,
        data
    }
}


export function getHoldoutDeleteColumnDefs(namespace, data) {
    return {
        type: GET_HOLDOUTDELETE_COLUMN_DEFINITION,
        data
    }
}

export function setHoldoutDeleteListColumnDefs(data) {
    return {
        type: GET_HOLDOUTDELETE_COLUMN_DEFINITION_SUCCESS,
        data
    }
}

export function setHoldoutDeleteListColumnDefsFailure(data) {
    return {
        type: GET_HOLDOUTDELETE_COLUMN_DEFINITION_FAILURE,
        data
    }
}

export function updateShowHide(namespace, data) {
    return {
        type: GET_HOLDOUTDELETE_UPDATE_COLUMN_DEFINITION,
        data
    }
}

export function updateColumnDefsSuccess(data) {
    return {
        type: GET_HOLDOUTDELETE_UPDATE_COLUMN_DEFINITION_SUCCESS,
        data
    }
}

export function updateColumnDefsFailure(data) {
    return {
        type: GET_HOLDOUTDELETE_UPDATE_COLUMN_DEFINITION_FAILURE,
        data
    }
}

export function resetDefault(data) {
    return {
        type: RESET_DEFAULTS,
        data
    }
}

export function resetDefaultSuccess(data) {
    return {
        type: RESET_DEFAULTS_SUCCESS,
        data
    }
}

export function resetDefaultFailure(data) {
    return {
        type: RESET_DEFAULTS_FAILURE,
        data
    }
}

export function setFilterValues(namespace, data) {
    return {
        type: SET_FILTER_VALUES,
        data
    }
}

export function setColumnDefsLoaded(namespace, data) {
    return {
        type: SET_COLUMN_DEFS_LOADED,
        data
    }
}

export function resetStateData(namespace, data) {
    return {
        type: RESET_DATA,
        data
    }
}


export function setApiCallCount(namespace, data) {
    return {
        type: SET_APICALL_COUNT,
        data
    }
}

export function onSetPageProps(namespace, data) {
    return {
        type: SET_PAGEPROPS,
        data
    }
}

export function getHoldoutsList(namespace, data) {
    return {
        type: GET_HOLDOUTS_LIST,
        data
    }
}

export function setHoldoutsListSuccess(data) {
    return {
        type: GET_HOLDOUTS_LIST_SUCCESS,
        data
    }
}

export function setHoldoutsListFailure(data) {
    return {
        type: GET_HOLDOUTS_LIST_FAILURE,
        data
    }
}
export function setLabelDataFlags(namespace, data) {
    return {
        type: LABEL_DATA_FLAGS,
        data
    }
}
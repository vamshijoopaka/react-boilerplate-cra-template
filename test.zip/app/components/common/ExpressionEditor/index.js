import React from 'react';
import DialogComponent from '../DialogComponent';
import { createStructuredSelector } from 'reselect';
import ExpressionComponent from '../ExpressionComponent';
import ConfirmationDialog from 'components/common/ConfirmationDialog';
import { connect } from 'react-redux';
import { compose } from 'redux';
import * as math from 'mathjs';
import FormattedMessageComponent from '../../common/FormattedMessageComponent';
import { COMMA_SEPARATED_LANGS } from '../../../components/common/constants';
import {
    COLUMN_HEADER_ACCESSOR,
    COLUMN_VALUE_ACCESSOR,
} from '../../../components/common/constants';
import { TEXT_EXPRESSION_EDITOR, TEXT_CANCEL, TEXT_OK } from '../../../containers/common/constants';
import {TEXT_ALERT} from '../../common/constants'
import { postValidateInputNumber } from '../../../utils/fieldValidations';
//import ServerErrorMessage from '../ServerErrorMessage';
import { addServerErrorMessage } from '../../../containers/common/ServerErrorMessage/actions'
import { errorMessageLabels} from './selector'
const userLang = 'English';

class ExpressionEditor extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            expressionData: this.props.expressionData,
            expressionValidity: false,
            alertConfirmationDialog: false,
        }
        this.handleCancel = this.handleCancel.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.updateExpression = this.updateExpression.bind(this);
    }

    handleCancel() {
        this.props.closeExpressionEditor(this.props.expressionData, false);
    }
    handleSubmitPopup(){
        this.setState({alertConfirmationDialog:false})
    }
    getLabelValue(id) {
		return <FormattedMessageComponent id={id}></FormattedMessageComponent>;
	}

    handleSubmit() {
        let expr = '';
        this.state.expressionData.split(/\[|\]/g).forEach(e => {
            if (e) {
                let element = this.props.columnDefs.filter(field => field && (field[COLUMN_HEADER_ACCESSOR].toLowerCase().trim() === e.toLowerCase().trim()));
                if (element && element[0] && element[0][COLUMN_VALUE_ACCESSOR]) {
                    expr = expr + '[' + element[0][COLUMN_VALUE_ACCESSOR].trim() + ']';
                } else {
                    expr = expr + e;
                }
            }
        });
        try {
            // to check for 2 consecutive '+' or '-' operators
            for (let i = 0; i < expr.length - 1; i++) {
                if (((i === 0) && ['+', '-'].includes(expr[i])) || (['+', '-'].includes(expr[i]) && ['+', '-'].includes(expr[i + 1]))) {
                    throw ('Misplaced operators')
                }
            }
            if ((COMMA_SEPARATED_LANGS.includes(userLang.toLowerCase()) && (expr.indexOf('.') > -1)) || (!COMMA_SEPARATED_LANGS.includes(userLang.toLowerCase()) && (expr.indexOf(',') > -1))) {
                throw ('Invalid')
            }
            const parse = math.parse(expr.replace(/,/g, '.').replace('#',''));
            if (parse.compile()) {
                const compile = parse.compile();
                if (this.props.selectedField && expr && /^[0-9]+([,.][0-9]+)?$/g.test(expr)) { // if expression has only numbers
                    const { maxValue, minValue, isNegative, numberType,
                      precisionLength, value, maxLength } = this.props.selectedField;
                    let validate = postValidateInputNumber(expr, maxValue, minValue, maxLength, precisionLength, numberType);
                    if(!validate)  {
                        throw('Parameter is Incorrect');
                    }
                }
                this.props.closeExpressionEditor(this.state.expressionData, true);
                this.setState({ expressionValidity: true });
                
            }
        }
        catch (error) {
            this.setState({ expressionValidity: false });
            this.setState({ alertConfirmationDialog: true });
            //typeof error === 'string' ? alert(error) : alert("Invalid expression");
             typeof(error) === 'string' ?
            this.props.addServerErrorMessage({ ERRCOD: '522', ERRMSG:this.props.errorMessages['E522'].MTEXT.trim() })
             :
             this.props.addServerErrorMessage({ ERRCOD: '522', ERRMSG:"Invalid Expression" });
             
        }
    }
    handleConfirmBeforeSubmit = (flag = true) => {
		this.setState({ alertConfirmationDialog: false })
	}
    updateExpression(val) {
        this.setState({ expressionData: val });
    }
    keyDown = (event) => {
        if (document.getElementById('expression-editor')) {
            if (((event.keyCode === 13) || (event.which === 13)) && (event.target.tabIndex === -1)) {
                event.preventDefault();
                this.handleSubmit();
            }
        }
    }
    render() {
        const{errorMessages}=this.props
        return (
            <div id="expression-editor" onKeyDown={(event) => { this.keyDown(event); }}>
                <DialogComponent isOpen={this.props.isOpen}
                    dialogTitle={TEXT_EXPRESSION_EDITOR}
                    cancelText={TEXT_CANCEL}
                    submitText={TEXT_OK}
                    handleClose={this.handleCancel}
                    handleCancel={this.handleCancel}
                    isBackArrow={true}
                    handleSubmit={this.handleSubmit}>
                    <ExpressionComponent submitExpression={() => this.handleSubmit()}
                        expressionData={this.state.expressionData}
                        updateExpression={(val) => this.updateExpression(val)}
                        columnDefs={this.props.columnDefs}
                        columnDefOptions={this.props.columnDefOptions}>
                    </ExpressionComponent>
                    {this.state.alertConfirmationDialog &&
						<ConfirmationDialog
							isOpen={this.state.alertConfirmationDialog}
							dialogTitle={TEXT_ALERT}
							//cancelText={TEXT_CANCEL}
							submitText={TEXT_OK}
							handleClose={e => this.handleConfirmBeforeSubmit(false)}
							//handleCancel={e => this.handleConfirmBeforeSubmit(false)}
							handleSubmit={e => this.handleSubmitPopup()}>
							<div>
								{errorMessages ? errorMessages['E522']['MTEXT'] : 'Confirmation'}
							</div>
						</ConfirmationDialog>
					}
                </DialogComponent>
            </div>
        );
    }
}


const mapStateToProps = createStructuredSelector({
	errorMessages: errorMessageLabels(),
})


function mapDispatchToProps(dispatch) {
    return {
        dispatch,
        addServerErrorMessage: data => {
            dispatch(addServerErrorMessage(data));
          },
    };
}

const withConnect = connect(
    mapStateToProps,
    mapDispatchToProps,
);

export default compose(
    withConnect
)(ExpressionEditor);
/**
 * ChartComponent
 */

import React from 'react';
import PropTypes from 'prop-types';
import HighchartsReact from 'highcharts-react-official';
import Highcharts from 'highcharts/highstock';

class ChartComponent extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    const { options } = this.props;
    return <HighchartsReact highcharts={Highcharts} options={options} />;
  }
}

ChartComponent.propTypes = {
  options: PropTypes.object,
};

export default ChartComponent;

import {GET_HOLDOUT_NOTES, GET_HOLDOUT_NOTES_SUCCESS, GET_HOLDOUT_NOTES_FAILURE, CLEAR_NOTES_DATA, GET_HOLDOUT_NOTE_DETAILS, GET_HOLDOUT_NOTE_DETAILS_SUCCESS,
    GET_HOLDOUT_NOTE_DETAILS_FAILURE, SET_HOLDOUT_SELECTED_NOTE_DETAILS, GET_HOLDOUT_NOTES_ALL_SUCCESS, CONTROL_HOLDOUT_NOTE_CREATION,
    CONTROL_HOLDOUT_NOTE_CREATION_SUCCESS, CONTROL_HOLDOUT_NOTE_CREATION_FAILURE, SET_HOLDOUT_NOTE_CONTROL_COUNT,
    REMOVE_HOLDOUT_NOTE_OF_KEY, CLEAR_HOLDOUT_NOTES, SET_IS_EMBEDDED_LIST, CLEAR_STATE_VALUES } from './constants';

export function getHoldoutNotes(data){
   return {
       type: GET_HOLDOUT_NOTES,
       data
   }
}
export function getHoldoutNotesSuccess(data){
   return {
       type: GET_HOLDOUT_NOTES_SUCCESS,
       data
   }
}
export function getHoldoutNotesFailure(data){
   return {
       type: GET_HOLDOUT_NOTES_FAILURE,
       data
   }    
}

export function clearNotesData() {
   return {
       type: CLEAR_NOTES_DATA
   }
}
export function getNoteDetails(data) {
   return {
       type: GET_HOLDOUT_NOTE_DETAILS,
       data
   }
}
export function getNoteDetailsSuccess(data) {
   return {
       type: GET_HOLDOUT_NOTE_DETAILS_SUCCESS,
       data
   }
}
export function getNoteDetailsFailure(data) {
   return {
       type: GET_HOLDOUT_NOTE_DETAILS_FAILURE,
       data
   }
}
export function getNoteDetailsAllSuccess(data) {
   return {
       type: GET_HOLDOUT_NOTES_ALL_SUCCESS,
       data
   }
}
export function setSelectedNoteDetails(data) {
   return {
       type: SET_HOLDOUT_SELECTED_NOTE_DETAILS,
       data
   }
}
export function controlNoteCreation(data) {
   return {
       type: CONTROL_HOLDOUT_NOTE_CREATION,
       data
   }
}
export function controlNoteCreationSuccess(data) {
   return {
       type: CONTROL_HOLDOUT_NOTE_CREATION_SUCCESS,
       data
   }
}
export function controlNoteCreationFailure(data) {
   return {
       type: CONTROL_HOLDOUT_NOTE_CREATION_FAILURE,
       data
   }
}
export function setControlNoteCount(data) {
   return {
       type: SET_HOLDOUT_NOTE_CONTROL_COUNT,
       data
   }
}
export function removeNoteByKey(data) {
   return {
       type: REMOVE_HOLDOUT_NOTE_OF_KEY,
       data
   }
}
export function clearAllHoldoutNotes() {
   return {
       type: CLEAR_HOLDOUT_NOTES
   }
}

export function setIsEmbeddedList() {
   return {
       type: SET_IS_EMBEDDED_LIST
   }
}
export function clearStateValues(){
   return{
       type: CLEAR_STATE_VALUES
   }
}
import { UPDATE_COLUMN_DEFS } from './constants';

export function updateColumnDefs(payload) {
    return {
        type: UPDATE_COLUMN_DEFS,
        payload
    }
}
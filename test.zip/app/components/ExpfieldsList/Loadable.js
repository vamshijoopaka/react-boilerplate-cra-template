/**
 *
 * Asynchronously loads the component for ExpfieldsList
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));

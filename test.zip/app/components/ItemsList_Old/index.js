/**
 *
 * ItemsList
 *
 */

import React, { useState, useEffect } from 'react';
// import PropTypes from 'prop-types';
// import styled from 'styled-components';
import { FormattedMessage } from 'react-intl';
import { AgGridReact } from 'ag-grid-react';
import messages from './messages';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';
import { get } from 'https';
import Pagination from '../Pagination';
import PaginationGrid from '../PaginationGrid';
import {
  getListPredecessor,
  getSortedArray,
  isEqualSortArrays,
  getDefaultSortInfo,
  getFilterDataFromCriteriaDetails
} from '../../utils/util';
import { directive } from '@babel/types';

import Spinner from 'components/Common/Spinner';
import ErrorDetail from 'components/Common/ErrorDetail';

import {
  ITEM_LIST_PAGE,
  ITEM_PROPERTIES,
  PAGE_SIZES,
  INITIAL_PAGE_PROPS,
  ITEMS_LIST_MANDATORY_FIELDS
} from './constants';

import {
  ITEMS_LIST_PAGE,
  GLOBAL_FILTER_OPTIONS,
  FILTER_CRITERIA_API_LIST_CONSTANTS,

  COLUMN_HEADER_ACCESSOR,
  COLUMN_VALUE_ACCESSOR,
  COLUMN_POSITION,
  COLUMN_SHOW_HIDE_FLAG,
  COLUMN_HEADER_PREFIX_FLAG,
  COLUMN_FIELD_LEN,
  COLUMN_FIELD_NUM,
  COLUMN_FIELD_TYPE,
  DROPDOWN_FIELD,
  VALIDATION_FIELD,
  SHOW_HIDE_FIELD,
  itemDefaultSort,
  TEXT_ALERT,
  TEXT_OK,
  SORT_SUPPORT_LIST,
  DATA_ACCESS_KEY,
} from '../../components/common/constants';
import { isEqual } from 'lodash';

import {
  isColumnSortable,
  getSaveTypeFromCurrentPage,
  getTitleObj,
  getDefaultField,
  setSortDataFromSortCriteria,
  getFilterDataFromLocalStorage
} from 'utils/util';

import {
  getDBSelectorFilterValues
} from 'utils/filterData';

import LinkRenderer from 'components/CustomGrid/LinkRenderer';
import ConfirmationDialog from 'components/common/ConfirmationDialog';
import FormattedMessageComponent from '../common/FormattedMessageComponent';


const frameworkComponent = {
  'linkRenderer': LinkRenderer
};


class ItemsList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isOpenEmbeddedList: false,
      selectedRecord: false,
      currentFilterProps: false,
      currentDbSelectorProps: false,
      isDataLoaded: false,
      isFiltersChanged: false,
      previousFilterValues: false,
      showConfirmationDialog: false,
      dialogTitle: '',
      hasWarning: false,
      dialogInfo: '',
      //JVK
      currentPage:'items',
      isInitialAPICall: true,
      previousSortValues: false,
      paginationRecord: false,
    }
    this.onGridReady = this.onGridReady.bind(this);
    this.getRecordDataOnDirection = this.getRecordDataOnDirection.bind(this);
    this.setPageForwardDirection = this.setPageForwardDirection.bind(this);
    this.resetPagePropsAndSendApiCall = this.resetPagePropsAndSendApiCall.bind(this);
    this.sendAPIWithExistingPageprops = this.sendAPIWithExistingPageprops.bind(this);
    this.getDefaultSortPropsDetails = this.getDefaultSortPropsDetails.bind(this);
    this.onValueChanged = this.onValueChanged.bind(this);
    this.onRowSelected = this.onRowSelected.bind(this);
    this.forceUpdateHandler = this.forceUpdateHandler.bind(this);
    this.setFilterValues = this.setFilterValues.bind(this);
    this.setFilterValuesFromState = this.setFilterValuesFromState.bind(this);
    this.handleNoDataSets = this.handleNoDataSets.bind(this);
    this.postSort = this.postSort.bind(this);
    this.sendInitialAPIForList = this.sendInitialAPIForList.bind(this);
  }

  onRowSelected(e) {
    this.props.setSelectedRecord(JSON.parse(JSON.stringify(this.grid.api.getSelectedRows()[0])), 'items');
    this.props.setIsShowContextMenu(true);
  }

  resetValues = () => {
    this.setState({ isDataLoaded: false });
    this.props.setInitialState();
    this.props.getItemColumnDefs({ type: ITEMS_LIST_PAGE });
  }

  componentDidMount() {
    const {pathname='/items'}=window.location;
    this.setState({currentPage:pathname.slice(1)});
    this.resetValues();
    let mandatoryFields = ITEMS_LIST_MANDATORY_FIELDS;
    this.props.setMandatoryFilterOptions(mandatoryFields);
    let isFilterValuesExists = this.setFilterValues();
    //JVK
    let currentPage = pathname.slice(1) || ITEMS_LIST_PAGE;
    this.props.onLoadCurrentPage(currentPage);
  }

  sendInitialAPIForList(filterProps, sortProps, pageProps) {
    this.resetPagePropsAndSendApiCall(filterProps, sortProps, pageProps, true, false);
  }

  postSort() {
    if (this.grid) {
      let sortArray = [], fieldName = COLUMN_VALUE_ACCESSOR;
      let columnDefs = this.props.itemsListPage.columnDefs;
      let sort = this.grid.api.getSortModel().length ? this.grid.api.getSortModel() : false;
      if (!sort) return;
      let isSortable = isColumnSortable(ITEMS_LIST_PAGE, sort[0].colId);
      if (!isSortable) {
        return;
      }
      columnDefs = columnDefs.map(col => {
        let filter = sort.find(sortField => ((sortField.colId === col[fieldName].trim())));
        if (filter) {
          let sortObj = JSON.parse(JSON.stringify(col));
          sortObj['accessor'] = col[fieldName].trim();
          sortObj['sortOrder'] = filter.sort === 'desc' ? 'Descending' : 'Ascending';
          sortObj['sort'] = filter.sort;
          sortArray.push(sortObj);
          col['sort'] = filter.sort;
          return col
        } else {
          delete col.sort;
          return col;
        }
      })
      let globalSortProps = this.props.itemsListPage.sortProps ? this.props.itemsListPage.sortProps : [];

      let equal = isEqualSortArrays(globalSortProps, sortArray, COLUMN_FIELD_NUM);
      if (sortArray.length && !equal && !this.props.itemsListPage.isSortPropsChanged) {
        // this.props.setSortColumnDefs(columnDefs);
        this.props.onSetSortProps(sortArray);
        this.props.setSortPropsChangeFlag(false);
        this.props.sendPageSortProps(sortArray);
        this.props.setSortCriteriaDetails(false);
      }
    }
  }

  setFilterValuesFromState(values, isAPICall) {
    let filterValues = [];
    const { columnDefs } = this.props.itemsListPage;
    if (columnDefs && columnDefs.length) {
      values.forEach((value) => {
        let isExists = columnDefs.find((column) => column[COLUMN_VALUE_ACCESSOR].trim() == value.accessor);
        // if (isExists) {
          filterValues.push(value)
        // }
      });
      if (filterValues && filterValues.length) {
        if (isAPICall) {
          this.resetPagePropsAndSendApiCall(filterValues, this.previousSortValues, INITIAL_PAGE_PROPS, true, false);
        }
        this.props.onSetFilterProps(filterValues);
        this.props.setGlobalFilterProps(filterValues);
        return filterValues;
      }
    } else {
      if (isAPICall) {
        this.resetPagePropsAndSendApiCall(values, this.previousSortValues, INITIAL_PAGE_PROPS, true, false);
      }
      this.props.onSetFilterProps(values);
      this.props.setGlobalFilterProps(values);
      return values;
    }
  }


  setFilterValues() {
    const { history } = this.props;
    let isFilterValuesExists = false, isLocalStorageValuesExists = false;
    var paramsString = window.location.search;
    if (paramsString && paramsString.length) {
      let paramsArray = paramsString.split("?");
      if (paramsArray && paramsArray.length && paramsArray.length > 1) {
        let params = paramsArray[1].split("&");
        let tabId = params[0].split("=")[1];
        let breadCrumbId = params[1].split("=")[1];
        let localStorageValues = getFilterDataFromLocalStorage(tabId, breadCrumbId);
        if (localStorageValues && Object.keys(localStorageValues) && Object.keys(localStorageValues).length) {
          isLocalStorageValuesExists = true;
          let itemData = localStorageValues[DATA_ACCESS_KEY], dbSelectorValues = [];
          this.props.setSelectedRecord(false, false);
          if (itemData) {
            if (itemData.dbSelector && itemData.dbSelector.length) {
              dbSelectorValues = JSON.parse(JSON.stringify(itemData.dbSelector));
            }
            if (itemData.sortProps && itemData.sortProps.length) {
              this.previousSortValues = itemData.sortProps;
              this.props.sendPageSortProps(itemData.sortProps);
              this.props.onSetSortProps(itemData.sortProps);
              this.props.setSortPropsChangeFlag(false);
            }
            if (itemData.filterProps && itemData.filterProps.length) {
              isFilterValuesExists = true;
              let values = getDBSelectorFilterValues(dbSelectorValues, itemData.filterProps);
              this.setState({ currentFilterProps: JSON.parse(JSON.stringify(values)) });
              this.setFilterValuesFromState(values);
            } else if (dbSelectorValues && dbSelectorValues.length) {
              isFilterValuesExists = true;
              let dbValues = getDBSelectorFilterValues(dbSelectorValues, []);
              this.setFilterValuesFromState(dbValues);
            }

            if (itemData.defaultFilterInfo && Object.keys(itemData.defaultFilterInfo) && Object.keys(itemData.defaultFilterInfo).length) {
              this.props.setDefaultFilterpropsForTabs(itemData.defaultFilterInfo);
            }

            if (itemData.defaultSortInfo && Object.keys(itemData.defaultSortInfo) && Object.keys(itemData.defaultSortInfo).length) {
              this.props.setDefaultSortpropsForTabs(itemData.defaultSortInfo);
            }
            //JVK to disable filters
            if(itemData.disableRows){
              this.props.setGlobalFilterOptions(itemData.disableRows);
            }

            if (itemData.pageProps && Object.keys(itemData.pageProps) && Object.keys(itemData.pageProps).length) {
              this.props.onSetPageProps(itemData.pageProps);
            }
            if (itemData.paginationRecord && Object.keys(itemData.paginationRecord) && Object.keys(itemData.paginationRecord).length) {
              this.setState({ paginationRecord: itemData.paginationRecord });
            }
            if (itemData.apiCallCount != undefined && parseInt(itemData.apiCallCount) >= 0) {
              this.props.setApiCallCount(itemData.apiCallCount);
            }

          }
          if (!isLocalStorageValuesExists && tabId && breadCrumbId) {
            history.push({ pathname: '/Dashboard' });
          }
        }
      }
    } else {
      history.push({ pathname: '/Dashboard' });
    }
    let filterOptions = GLOBAL_FILTER_OPTIONS;
    const { dbSelector } = this.props;
    if (!isFilterValuesExists) {
      let gbValues = getDBSelectorFilterValues(dbSelector, filterOptions);
      this.setState({ currentFilterProps: JSON.parse(JSON.stringify(gbValues)) });
      this.setFilterValuesFromState(gbValues);
    }
    return isFilterValuesExists;
  }


  onGridReady(params) {
    this.grid = params;
  }

  componentWillUnmount() {
    this.setState({ isDataLoaded: false });
    this.props.setInitialState();
    //JVK to revert the globalfilters
    this.props.setGlobalFilterOptions(GLOBAL_FILTER_OPTIONS);
  }

  handleNoDataSets(isColumns) {
    const { history } = this.props;
    const { items, columnDefs } = this.props.itemsListPage;
    if (this.state.isDataLoaded) {
      if (isColumns && columnDefs && columnDefs.length) {
        //do nothing here
      } else if (items && items.length && columnDefs && columnDefs.length) {
        //do nothing here
      } else {
        this.props.setNoDataCallBackValue(true);
        this.showConfirmationDialog = true;
        this.noDatasets = true;
        // this.handleCloseChildTab();
      }
    }
  }

  handleCloseChildTab = () => {
    var paramsString = window.location.search;
    if (paramsString && paramsString.length) {
      let paramsArray = paramsString.split("?");
      if (paramsArray && paramsArray.length && paramsArray.length > 1) {
        let params = paramsArray[1].split("&");
        let tabId = params[0].split("=")[1];
        let breadCrumbId = params[1].split("=")[1];
        this.props.removeCurrentRecordObj(tabId, breadCrumbId);
      }
    }
  }

  handleFilterClose = () => {
    if (this.state.isFiltersChanged) {
      this.props.onSetFilterProps(this.state.previousFilterValues);
      this.props.setGlobalFilterProps(this.state.previousFilterValues);
      this.props.setChildTabFilterProps(this.state.previousFilterValues);
      this.setState({ isFiltersChanged: false });
    }
    this.props.setValueDataAPIFailureFlag(false);
    this.props.setValueDataFlag(false);
    this.props.handleCloseItemsFilter();
    this.props.closeFilterComponent(true);
  }

  handleClose = (flag) => {
    if(this.noDatasets){
      this.noDatasets = false;
      this.handleCloseChildTab();
    }
    this.setState({ showConfirmationDialog: false });
  }

  onValueChanged(data, rowIndex, colId) {
    // this.props.setItemData({date: data, colId: colId, rowIndex: rowIndex});
  }

  getDefaultSortPropsDetails() {
    let pageProps = JSON.parse(JSON.stringify(INITIAL_PAGE_PROPS));
    let defaultProps = JSON.parse(JSON.stringify(FILTER_CRITERIA_API_LIST_CONSTANTS));
    defaultProps[1]['fieldValue'] = getSaveTypeFromCurrentPage(ITEMS_LIST_PAGE);
    defaultProps.push(getTitleObj(ITEMS_LIST_PAGE));
    defaultProps.push(getDefaultField());
    if(SORT_SUPPORT_LIST.includes(this.state.currentPage))
    this.props.getDefaultSortProps({ filterProps: JSON.parse(JSON.stringify(defaultProps)), pageProps: pageProps, fromPage: 'sort', currentPage: 'sort', direction: pageProps.isForwardDirection });
  }



  onRowDoubleClicked = (event) => {
    this.setState({ selectedRecord: event.data });
    this.setState({ isOpenEmbeddedList: true });
  };

  initialLoad(props, flag) {
    const { filterProps, sortProps, pageProps } = props.itemsListPage;
    let record;
    if (flag) {
      record = {}
    } else {
      record = this.getRecordDataOnDirection(pageProps.isForwardDirection);
    }
    if (pageProps) {
      if (pageProps.currentPage != 0) {
        this.props.setDataInTabs("paginationRecord", record);
      } else {
        this.props.setDataInTabs("paginationRecord", {});
      }
      //JVK
      this.props.onloadItems(filterProps, sortProps, pageProps, pageProps.isForwardDirection, record, this.state.currentPage);
    }
  }

  getRecordDataOnDirection(direction) {
    const { items } = this.props.itemsListPage;
    if (!items) {
      return;
    }
    if (!direction) {
      let count = this.props.apiCallCount;
      this.props.setApiCallCount(count - 1);
      return items[0];
    } else {
      let count = this.props.apiCallCount;
      this.props.setApiCallCount(count + 1);
      return items[items.length - 1];
    }
  }


  loadItems = () => {
    if (!this.props.itemsListPage.isAPIProgress) {
      this.initialLoad(this.props, false);
    }
  }

  setPageForwardDirection(flag) {
    const { pageProps } = this.props.itemsListPage;
    this.props.onSetPageProps({
      ...pageProps,
      actualPage: 0,
      currentPage: 0,
      totalCount: 10,
      isForwardDirection: flag
    });
  }

  setSortHeader = (sortProps) => {
    let sort = [];
    if (sortProps && sortProps.length) {
      sortProps.forEach(ele => {
        let obj = {};
        obj['colId'] = ele.accessor;
        obj['sort'] = ele.sort ? ele.sort : (ele.sortOrder === 'Ascending' ? 'asc' : 'desc');
        sort.push(obj);
      })
      if (this.grid) {
        // this.grid.api.setSortModel(sort);
      }
    }
  }

  resetPagePropsAndSendApiCall(filterProps, sortProps, pageProps, direction, record, exportFilterProps, exportFields, showHideColumns, searchReplaceValues) {
    this.setPageForwardDirection(true);
    //JVK
    this.props.onloadItems(filterProps, sortProps, pageProps, direction, record, exportFilterProps, exportFields, showHideColumns, searchReplaceValues, this.state.currentPage);
  }

  sendAPIWithExistingPageprops(filterProps, sortProps, pageData, direction, record, exportFilterProps, exportFields, showHideColumns, searchReplaceValues) {
    let recordData = JSON.parse(JSON.stringify(record));
    const { pageProps } = this.props.itemsListPage;
    let existingPageProps = {
      ...pageProps,
      isForwardDirection: true
    }
    this.props.onSetPageProps({
      ...pageProps,
      isForwardDirection: true
    });
    if (this.state.paginationRecord && Object.keys(this.state.paginationRecord) && Object.keys(this.state.paginationRecord).length) {
      recordData = JSON.parse(JSON.stringify(this.state.paginationRecord));
    }
    this.props.onloadItems(filterProps, sortProps, existingPageProps, direction, recordData, exportFilterProps, exportFields, showHideColumns, searchReplaceValues, this.state.currentPage);
  }

  forceUpdateHandler() {
    this.forceUpdate();
  };

  componentDidUpdate(prevProps, prevState) {
    const { sortProps,
      filterProps,
      pageProps, items,
      exportFilterProps,
      exportFields,
      showHideColumns, searchReplaceValues,
      columnDefs, updateColumnsList, columnInfo, apiCallCount, 
      isSortPropsChanged, defaultSortProps, isColumnDefsLoaded, currentLoadedProps, hasToResetDefaults,
      isValueDataAPICall, isValueDataAPIFailure, closeFiltersPopup, sortCriteriaDetails, filterCriteriaDetails } = this.props.itemsListPage;

    const { dbSelector, pageFilters } = this.props;

    if (!isEqual(apiCallCount, prevProps.itemsListPage.apiCallCount)) {
      this.props.setDataInTabs("apiCallCount", apiCallCount);
    }

    if (pageProps && !isEqual(pageProps, prevProps.itemsListPage.pageProps)) {
      this.props.setDataInTabs("pageProps", JSON.parse(JSON.stringify(pageProps)));
    }

    /**
     * To close the global filter, dispatch an action 
     */
    if (closeFiltersPopup != prevProps.itemsListPage.closeFiltersPopup && closeFiltersPopup) {
      this.handleFilterClose();
    }

    /**
     * Set the sort values after changing the sort values in the popup
     */
    if (sortProps && sortProps.length && !isEqual(sortProps, prevProps.itemsListPage.sortProps)) {
      this.props.setDataInTabs("sortProps", JSON.parse(JSON.stringify(sortProps)));
      this.props.setSortPropsChangeFlag(false);
    }

    /**
     * Handle list API success call and if there is filter applied then on success of list close the filter
     */
    if ((isValueDataAPICall != prevProps.itemsListPage.isValueDataAPICall) && isValueDataAPICall) {
      this.setState({ isInitialAPICall: false });
      this.setState({ previousFilterValues: filterProps })
      this.props.setValueDataFlag(false);
      this.props.setValueDataAPIFailureFlag(false);
      if (this.state.isFiltersChanged) {
        this.setState({ isFiltersChanged: false });
        this.props.handleCloseItemsFilter();
        this.props.closeFilterComponent(true);
      }
    }

    /**
     * handle no datasets cases on list data failure / filters API failure
     */
    if ((isValueDataAPIFailure != prevProps.itemsListPage.isValueDataAPIFailure) && isValueDataAPIFailure) {
      this.setState({ isInitialAPICall: false });
      if (!this.state.isDataLoaded && columnDefs && columnDefs.length) {
        this.setState({ isDataLoaded: true }, () => {
          this.handleNoDataSets();
        });
      }
      if (this.state.isFiltersChanged) {
        this.props.setValueDataAPIFailureFlag(false);
        this.setState({ showConfirmationDialog: true });
        this.setState({ hasWarning: true });
        this.setState({ dialogTitle: TEXT_ALERT });
        this.setState({ dialogInfoId: '28648' });
      }
    }

    /**
     * No data sets handle for items
     */
    if (JSON.stringify(items) != JSON.stringify(prevProps.itemsListPage.items) && !this.state.isDataLoaded && items && columnDefs && columnDefs.length) {
      this.setState({ isDataLoaded: true }, () => {
        this.handleNoDataSets();
      });
    }

    /**
     * Send API call after default sort criteria loaded
     */
    if ((!isEqual(sortProps, prevProps.itemsListPage.sortProps) || isSortPropsChanged && currentLoadedProps == 'sort') && !this.state.isInitialAPICall) {
      this.props.setSortPropsChangeFlag(false);
      if (sortProps && sortProps.length) {
        this.resetPagePropsAndSendApiCall(filterProps, sortProps, pageProps, true, false);
      }
      // this.setSortHeader(sortProps);
    }

    /**
     * Handle multiple tabs if we open same list data
     */
    if (this.props.location.search != prevProps.location.search) {
      this.resetValues();
      this.forceUpdateHandler();
      this.setFilterValues();
      this.setState({ state: this.state });
      this.setState({currentPage:window.location.pathname.slice(1)},()=>{
        this.props.onLoadCurrentPage(this.state.currentPage);
      });
    }

    /**
     * On page size change send an API call to backend & when click on first page
     */
    if ((pageProps != prevProps.itemsListPage.pageProps) && pageProps.isPageSizeChanged) {
      this.props.setApiCallCount(0);
      let initialPageData = {
        ...pageProps,
        actualPage: 0,
        currentPage: 0,
        totalCount: 10,
        isForwardDirection: true,
      };
      this.resetPagePropsAndSendApiCall(filterProps, sortProps, initialPageData, true, false);
      this.props.onSetPageProps({
        ...initialPageData,
        isPageSizeChanged: false
      });
    }


    /**
     * Handle no data sets if the column defintion API failure
     */
    if (!isEqual(columnDefs, prevProps.itemsListPage.columnDefs) && !(prevProps.itemsListPage.columnDefs)) {
      if (columnDefs && columnDefs.length) {
        if (!isColumnDefsLoaded) {
          this.props.setFlagColumnDefsLoaded(true);
        }
      } else {
        this.setState({ isDataLoaded: true }, () => {
          this.handleNoDataSets(true);
        });
      }
    }

    /**
     * Update column defs on global on change column data for ex: show hide
     */
    if (!isEqual(columnDefs, prevProps.itemsListPage.columnDefs)) {
      if (columnDefs && columnDefs.length) {
        this.props.setGlobalColDefs(columnDefs);
        if (columnInfo) {
          this.props.setGlobalColumnInfo(columnInfo);
        }
      }
    }

    /**
     * Handle default sort data if there is no sort applied previously on records
     */
    if ((defaultSortProps != prevProps.itemsListPage.defaultSortProps) && (prevProps.itemsListPage.defaultSortProps === null) && (sortProps == null || !sortProps || !(sortProps && sortProps.length))) {
      this.props.setLoadingFlag(true);
      let list = setSortDataFromSortCriteria(defaultSortProps, columnDefs, ITEMS_LIST_PAGE);
      let defaultSortInfo = getDefaultSortInfo(defaultSortProps);
      this.props.setDataInTabs("defaultSortInfo", JSON.parse(JSON.stringify(defaultSortInfo)));
      if (list && list.length) {
        this.previousSortValues = list;
        this.props.sendPageSortProps(list);
        this.props.onSetSortProps(list);
        // this.resetPagePropsAndSendApiCall(filterProps, list, pageProps, true, false);
        this.sendAPIWithExistingPageprops(filterProps, list, pageProps, true, false);
      } else {
        this.props.sendPageSortProps([]);
        this.props.onSetSortProps([]);
        this.sendAPIWithExistingPageprops(filterProps, [], pageProps, true, false);
        // this.resetPagePropsAndSendApiCall(filterProps, [], pageProps, true, false);
      }
    }


    /**
     * If any sort criteria selected in sort dialog update the values in the list data
     */
    if (JSON.stringify(sortCriteriaDetails) != JSON.stringify(prevProps.itemsListPage.sortCriteriaDetails)) {
      this.props.setDataInTabs("defaultSortInfo", JSON.parse(JSON.stringify(sortCriteriaDetails)));
      let list = setSortDataFromSortCriteria(sortCriteriaDetails, columnDefs, ITEMS_LIST_PAGE);
      if (list && list.length) {
        this.props.sendPageSortProps(list);
        this.props.onSetSortProps(list);
      }
    }


    if (currentLoadedProps != prevProps.itemsListPage.currentLoadedProps && currentLoadedProps == 'sort' && sortProps && filterProps && pageProps) {
      this.props.setSortPropsChangeFlag(false);
      // this.setSortHeader(sortProps);
      this.props.setGlobalFilterProps(filterProps);
    }

    /**
     * send list API call on change sort data and it should not be a first call
     */
    if (sortProps != prevProps.itemsListPage.sortProps && sortProps && sortProps.length && !this.state.isInitialAPICall) {
      this.props.setApiCallCount(0);
      this.resetPagePropsAndSendApiCall(filterProps, sortProps, pageProps, true, false);
    }

    /**
     * Making the API call for default sort data list after columndefs loaded
     */
    if (isColumnDefsLoaded != prevProps.itemsListPage.isColumnDefsLoaded && isColumnDefsLoaded && filterProps && filterProps.length && (sortProps == null || !sortProps || !(sortProps && sortProps.length))) {
      this.getDefaultSortPropsDetails();
    }

    /**
     * Making the initial list API call if the sort exists
     */
    if (isColumnDefsLoaded != prevProps.itemsListPage.isColumnDefsLoaded && isColumnDefsLoaded && filterProps && filterProps.length && this.state.isInitialAPICall) {
      if (sortProps && sortProps.length) {
        this.sendAPIWithExistingPageprops(filterProps, sortProps, pageProps, true, false);
        // this.resetPagePropsAndSendApiCall(filterProps, sortProps, pageProps, true, false);
      }
    }

    /**
     * On change filter criteria details in the current list
     */
    if (filterCriteriaDetails != prevProps.itemsListPage.filterCriteriaDetails) {
      this.props.setDataInTabs("defaultFilterInfo", JSON.parse(JSON.stringify(filterCriteriaDetails)));
      if (filterCriteriaDetails && Object.keys(filterCriteriaDetails) && Object.keys(filterCriteriaDetails).length && columnDefs && columnDefs.length) {
        let list = getFilterDataFromCriteriaDetails(filterCriteriaDetails, columnDefs, ITEMS_LIST_PAGE);
        if (list && list.length) {
          this.props.setGlobalFilterProps(list);
          this.props.onSetFilterProps(list);
        }
      }
    }

    /**
     * Update the sort values in the current tab on change filters
     */
    if (!isEqual(filterProps, prevProps.itemsListPage.filterProps) && filterProps && filterProps.length) {
      this.setState({ isFiltersChanged: true });
      this.props.setChildTabFilterProps(filterProps);
    }

    /**
     * send list API call on change filter data and it should not be a first call
     */
    if (!isEqual(filterProps, prevProps.itemsListPage.filterProps) && filterProps && filterProps.length && pageProps && !this.state.isInitialAPICall) {
      this.props.setApiCallCount(0);
      this.resetPagePropsAndSendApiCall(filterProps, sortProps, pageProps, true, false);
    }

    /**
     * set gobal filters to set the applied filters in filter dialog
     */
    if (!isEqual(filterProps, prevProps.itemsListPage.filterProps) && pageProps && !pageFilters) {
      this.props.setGlobalFilterProps(filterProps);
    }

    if (showHideColumns != prevProps.itemsListPage.showHideColumns) {
      this.props.getUpdatedColumnDefs({ type: ITEMS_LIST_PAGE, userId: this.props.columnInfo['USERID'].trim(), 'record': showHideColumns });
    }

    if ((updateColumnsList != prevProps.itemsListPage.updateColumnsList) && updateColumnsList) {
      this.props.getItemColumnDefs({ type: ITEMS_LIST_PAGE });
      this.props.setUpdateColumnsList(false);
    }

    if (hasToResetDefaults && (prevProps.itemsListPage.hasToResetDefaults !== hasToResetDefaults)) {
      this.props.colResetDefault({ type: ITEMS_LIST_PAGE, userId: this.props.columnInfo['USERID'].trim() });
    }

    if ((exportFilterProps != prevProps.itemsListPage.exportFilterProps) || (exportFields != prevProps.itemsListPage.exportFields)) {
      this.resetPagePropsAndSendApiCall(filterProps, sortProps, pageProps, true, false, exportFilterProps, exportFields);
    }

    if (searchReplaceValues && !isEqual(searchReplaceValues, prevProps.itemsListPage.searchReplaceValues)) {
      this.resetPagePropsAndSendApiCall(filterProps, sortProps, pageProps, true, false, false, false, false, searchReplaceValues);
    }
  }


  closeManageIems = (flag) => {
    this.setState({ isOpenEmbeddedList: false });
  }

  render() {
    const { filterProps, pageProps, totalCount, items, isAPIProgress, columnDefs, loading, moreRecordsAvailable, updateColumnsList } = this.props.itemsListPage;

    return (
      <div>
        {loading && <Spinner loading type="list" />}

        {!this.props.error && items && !items[0] ?
          <ErrorDetail type="no_data" />
          : null}

        {(items && items.length && columnDefs.length && !updateColumnsList) ?
          (<div>
            <PaginationGrid
              rowSelection={'single'}
              frameworkComponent={frameworkComponent}
              onClickLink={this.onClickLink}
              headerHeight={45}
              props={this.props}
              listPredecessor={getListPredecessor(ITEMS_LIST_PAGE)}
              dataKey={"itemsListPage"}
              columnKey={COLUMN_VALUE_ACCESSOR}
              titleKey={COLUMN_HEADER_ACCESSOR}
              columnShowFlag={COLUMN_SHOW_HIDE_FLAG}
              prefixFlag={COLUMN_HEADER_PREFIX_FLAG}
              sendApi={this.loadItems}
              columnData={columnDefs}
              isAPIProgress={isAPIProgress}
              rowData={items}
              totalCount={totalCount}
              onRowSelected={(e) => this.onRowSelected(e)}
              onRowDoubleClicked={this.onRowDoubleClicked}
              pageSizes={PAGE_SIZES}
              pageProps={pageProps}
              onGridReady={this.onGridReady}
              moreRecordsAvailable={moreRecordsAvailable}
              // menuItemSelect={this.menuItemSelect}
              isColumnResize={true}
              postSort={this.postSort}
            />
            {/* {this.state.isOpenEmbeddedList && this.state.selectedRecord && 
                <ManageItemsPopup
                isOpen={this.state.isOpenEmbeddedList}
                closeDialog={this.closeManageIems}
                columnDefs={columnDefs}
                currentPage={ITEMS_LIST_PAGE}
                selectedRecord={this.state.selectedRecord}
                rowData={items}
                >
                </ManageItemsPopup>} */}
          </div>) : null}
        <ConfirmationDialog
          hasError={this.state.hasWarning}
          isOpen={this.state.showConfirmationDialog}
          dialogTitle={this.state.dialogTitle}
          submitText={TEXT_OK}
          handleClose={e => this.handleClose(false)}
          handleCancel={e => this.handleClose(false)}
          handleSubmit={e => this.handleClose(true)}>
          <div>
            <FormattedMessageComponent id={this.state.dialogInfoId} />
          </div>
        </ConfirmationDialog>
      </div>
    );
  }
}

ItemsList.propTypes = {

};

export default ItemsList;

/*
* * //==========================================================================
*
* * // Copyright 2021-2021, Blue Yonder Group, Inc.
*
* * // All Rights Reserved
*
* * //
*
* * // THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF
*
* * // BLUE YONDER GROUP, INC.
*
* * //
*
* * //
*
* * // The copyright notice above does not evidence any actual
*
* * // or intended publication of such source code.
*
* * //
*
* * // ===========================================================================
*/
import PropTypes from 'prop-types';
import React, { Component } from 'react';
import MenuItem from '@material-ui/core/MenuItem';
import Select from '@material-ui/core/Select';
import CustomizedTooltip from '../CustomizedTooltip';
import FormattedMessageComponent from '../FormattedMessageComponent';//E3C-31878:Ajit

const defaultProps = {
    className: '',
    value: '',
};

const propTypes = {
    className: PropTypes.string,
    field: PropTypes.shape({}).isRequired,
    onChange: PropTypes.func.isRequired,
    value: PropTypes.any,
    onFocus: PropTypes.func,
    enableAddButton: PropTypes.func,
    onFocusOut: PropTypes.func
};

class InputSelect extends Component {
    constructor() {
        super();
        this.onChange = this.onChange.bind(this);
    }

    onChange(e) {
        const { field, onChange, enableAddButton, onFocusOut } = this.props;
        const { key } = field;
        onChange(key, e.target.value, e);
        if (enableAddButton) {
            enableAddButton(true);
        }
        if (onFocusOut) onFocusOut();
    }
    getFormattedMessage = id => <FormattedMessageComponent id={id} />;//E3C-31878:Ajit
    render() {
        const { className, tabindex, field, value, disabled, onFocus, showTooltip } = this.props;
        const { options, placeholder, defaultValue } = field;
        //E3C-31878: Ajit added code to display as formatmessage
        //let selectOptions = options.map(val1 => <MenuItem disabled={val1.isDisable} key={val1.label} value={val1.value}>{val1.label}</MenuItem>);
        let selectOptions = options.map(val1 => <MenuItem disabled={val1.isDisable} key={val1.label} value={val1.value}>{val1.displayName ? this.getFormattedMessage(val1.displayName) : val1.label}</MenuItem>);
        if (placeholder) {
            if (placeholder == 'Show Me')
                selectOptions.unshift(<MenuItem value={placeholder} key={placeholder} disabled>{this.getFormattedMessage('25376')}</MenuItem>)
            else
                selectOptions.unshift(<MenuItem value={placeholder} key={placeholder} disabled>{placeholder}</MenuItem>)
        }
        //E3C-31878:Ajit
        return (
            <CustomizedTooltip title={showTooltip && value ? value : ''}>
                <Select
                    placeholder={placeholder}
                    className={className}
                    value={value || defaultValue || ''}
                    onChange={this.onChange}
                    disabled={disabled}
                    onFocus={onFocus}
                    id={field.key}
                    displayEmpty
                >
                    {selectOptions}
                </Select>
            </CustomizedTooltip>
        );
    }
}

InputSelect.defaultProps = defaultProps;
InputSelect.propTypes = propTypes;

export default InputSelect;

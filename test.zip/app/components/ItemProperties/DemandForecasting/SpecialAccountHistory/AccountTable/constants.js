export const MENU_ITEMS = [
  {
    label: '6010',
    key: 'addToTotalDemand',
    hasSubMenu: false,
    isDisable: true,
  },
  {
    label: '6011',
    key: 'subtractFromTotalDemand',
    hasSubMenu: false,
    isDisable: true,
  },
];

export const MENU_ITEMS_HANDLED = [
  'addToTotalDemand',
  'subtractFromTotalDemand',
];

import { createSelector } from 'reselect';

const selectData = (state) => state.get('itemOnDealReducer');
const errorMessageDomain = (state) => state.get('root').get('errorMessageLabels')

const makeSelectItemOnDealList = () =>
	createSelector(
		selectData,
		substate => substate.toJS(),
	);

const errorMessageLabels = (state, namespace) =>
	createSelector(
		errorMessageDomain,
		data => data
	)


export {
	errorMessageLabels,
	makeSelectItemOnDealList
}
import { createSelector } from 'reselect';

const selectDetailData = state => state.get('detailDialogReducer').toJSON();
export { selectDetailData };

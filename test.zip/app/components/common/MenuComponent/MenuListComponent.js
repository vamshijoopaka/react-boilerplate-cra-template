import React from 'react';
import Popper from "@material-ui/core/Popper";
import ClickAwayListener from "@material-ui/core/ClickAwayListener";
import Grow from "@material-ui/core/Grow";
import Paper from "@material-ui/core/Paper";
import MenuItem from '@material-ui/core/MenuItem';
import SubMenuItem from './subMenuItem';
import MenuList from '@material-ui/core/MenuList';

class MenuListComponent extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
        }
        this.handleClose = this.handleClose.bind(this);
        this.renderMenuItems = this.renderMenuItems.bind(this);
    }
    handleClose() {
        this.props.onClose(true);
    }
    renderMenuItems = () => {
        const { menuitems } = this.props;
        if (menuitems) {
          return menuitems.map(menuItem => {
            if (menuItem.hasSubMenu) {
              return (
                <SubMenuItem
                  key={menuItem.menuTitle}
                  title={menuItem.menuTitle}
                  menuitems={menuItem.subMenu}
                  itemselect={(val) => { this.props.itemselect(val)}}
                />
              );
            }
      
            return (
              <MenuItem key={menuItem.menuTitle} onClick={(event) => {event.stopPropagation(); this.props.itemselect(menuItem.menuTitle) }}>
                {menuItem.menuTitle}
              </MenuItem>
            );
          });
        }
      };
    render() {
        return(
            <Popper anchorEl={this.props.menuRef} style={{zIndex:'10000'}}
                placement={"right-start"}
                // disablePortal={true}
                modifiers={{
                flip: {
                    enabled: false,
                },
                preventOverflow: {
                    enabled: true,
                    boundariesElement: 'scrollParent',
                }
                }}
            open={Boolean(this.props.menuRef)}>
              {/* {({ TransitionProps, placement }) => ( 
               <Grow 
                {...TransitionProps}
                style={{ transformOrigin: placement === 'bottom' ? 'center top' : 'center bottom' }}
               > */}
                  <Paper id="menu-list-grow">
                    <ClickAwayListener onClickAway={() => this.handleClose()}>
                        <MenuList
                            onClose={() => this.props.onClose()}
                            >
                                {this.renderMenuItems()}
                            </MenuList>
                    </ClickAwayListener>
                  </Paper>
                {/* </Grow>
            )} */}
            </Popper>
        )
    }
}
export default MenuListComponent;
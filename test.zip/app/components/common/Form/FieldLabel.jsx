
/*
* * //==========================================================================
*
* * // Copyright 2021-2021, Blue Yonder Group, Inc.
*
* * // All Rights Reserved
*
* * //
*
* * // THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF
*
* * // BLUE YONDER GROUP, INC.
*
* * //
*
* * //
*
* * // The copyright notice above does not evidence any actual
*
* * // or intended publication of such source code.
*
* * //
*
* * // ===========================================================================
*/
import React, { Component } from 'react';
import classNames from 'classnames';
import PropTypes from 'prop-types';
import { getPrecisionLength, getUnformattedValue, getFormattedNumber, changeDecimalSeparator } from '../../../utils/util';

const defaultProps = {
  className: '',
};

const propTypes = {
  className: PropTypes.string,
  field: PropTypes.shape({}).isRequired,
};

// const FieldLabel = ({ className, field }) => {
//   const { label, key } = field;
//   return (
//     <label
//       className={classNames({
//         'filed-label': true,
//         [`filed-label--${key}`]: key,
//         [className]: className,
//       })}
//       htmlFor={key}
//     >
//       {label ? <div className="label"> {label}</div> : null}
//     </label>
//   );
// };

class FieldLabel extends Component {
  constructor(props) {
    super(props);

    this.getDisplayLabel = this.getDisplayLabel.bind(this);
  }

  getDisplayLabel = (value) => {
    const { globalNumberFormat, globalNumberSeparator, globalDecimalSeparator, field: { options = false }, fieldType } = this.props;
    if (value) {
      if (options && options.length) {
        let labelObj = options.find(ele => ele.value == value);
        return labelObj ? labelObj.label : value;
      }
      if ((Number(value) || Number(value) == 0) && !['C', 'D'].includes(fieldType)) { //display formatted number only if tyhe field is not of charactor type 

        if (getPrecisionLength(value)) {
          if(!(value<0 && value>-1))      //Fix for E3C-33112
          {
            let splittedValue = (value + '').split('.');
            value = Number(Math.round(splittedValue[0])) + '.' + splittedValue[1];
          }
          return getFormattedNumber(value, globalNumberFormat, globalNumberSeparator, null, globalDecimalSeparator);
        } else {
          return getFormattedNumber(Math.round(value), globalNumberFormat, globalNumberSeparator, 0, globalDecimalSeparator);
        }
      }
      return value;
    }
    return '';
  }

  render() {
    const { className, field, value, autoComplete, autoFocus, onKeyDown, onFocus, onClick, isFromGrid,
      disabled, maxLength, errorMessageLabel, enableAddButton,
      showTooltip } = this.props;
    const { key, placeholder, type } = field;
    let val = value;

    if (field.key != 'EPERYR') {
      val = this.getDisplayLabel(value)
    }

    return (
      <label
        key={field.key}
        id={field.key}
      >
        {val}
      </label>
    )
  }
}

FieldLabel.defaultProps = defaultProps;
FieldLabel.propTypes = propTypes;

export default FieldLabel;

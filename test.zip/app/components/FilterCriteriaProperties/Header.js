import React from 'react'
import { withStyles, Button, Box } from '@material-ui/core';
import KeyboardArrowUpIcon from '@material-ui/icons/KeyboardArrowUp';
import KeyboardArrowDownIcon from '@material-ui/icons/KeyboardArrowDown';
import MoreVertIcon from '@material-ui/icons/MoreVert';
import SaveIcon from '@material-ui/icons/Save';
import FilterIcon from '../../images/icon_filter.png';
import ContextMenu from '../common/ContextMenu';
import BreadcrumbContextMenu from 'components/common/BreadcrumbContextMenu';
import FormattedMessageComponent from '../common/FormattedMessageComponent';
import {
    KEY_OWNER_ID, KEY_FILTERCRITERIA_ID, LABEL_ACTIONS,
    LABEL_BUYER_ID, LABEL_FILTERCRITERIA_ID, LABEL_TYPE,
    LABEL_OWNER, CONTEXT_MENU_HEADER, LABEL_DESCRIPTION,
    LockField, EVIField, DescriptionField, KEY_TYPE,
    LABEL_FILTERCRITERIA_LOCK, LABEL_FILTERCRITERIA_EVI
} from './constants';
import { FILTERCRITERIA_LIST_PAGE } from '../common/constants';
import { isEqual } from 'lodash';
import FormFieldsGenerator from '../common/FormFieldsGenerator';
import { getListPredecessor } from '../../utils/util';
import { compose } from 'redux';
import { connect } from 'react-redux';
import { makeVendorItemData } from './selector';
import { createStructuredSelector } from 'reselect';
import ContextMenuCreateNew from '../common/ContextMenuCreateNew';

const style = theme => ({
    propertiesHeaderContainer: {
        width: '100%',
        marginBottom: '1.5rem',
        backgroundColor: 'var(--background-app)',
        borderRadius: '4px',
        borderTopLeftRadius: '0px',
        borderTopRightRadius: '0px',
        overflow: 'hidden',
        boxShadow: '0 4px 4px var(--secondary-s10)',
        overflowX: 'auto',
    },
    filtercriteriaContainer: {
        display: 'flex',
        width: '100%',
        backgroundColor: 'var(--background-content)',
        fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
        alignItems: 'center',
        padding: '0 0 0 24px',
        position: 'relative',
        minWidth: '630px',
    },
    headerDetailsWrapper: {
        width: '100%',
        display: 'flex',
    },
    arrowWrapper: {
        display: 'flex',
        flexDirection: 'column',
        border: '1px solid var(--primary-default)',
        borderRadius: '4px',
        justifyContent: 'center',
        alignItems: 'baseline',
        height: '38px',
        marginTop: '24px',
        padding: '2px',
    },
    arrow: {
        padding: '0 !important',
        margin: '0',
        minWidth: '16px',
        background: 'none',
        height: '16px',
        width: '16px',
    },
    headerDetailRow: {
        width: '100%',
        display: 'flex',
        flexWrap: 'wrap',
        padding: '0px 0 24px 0',
        paddingLeft: '24px',
        paddingTop: '24px',
    },
    headerLabel: {
        color: 'var(--header-label-color)',
        paddingBottom: '6px'
    },
    headerLabel1: {
        color: 'var(--header-label-color)',
        paddingBottom: '6px',
        paddingTop: '6px'
    },
    headerFieldValue: {
        color: 'var(--value)',
        display: 'flex',
        flexWrap: 'wrap',
        paddingBottom: '12px'
    },
    detailBlockField: {
        padding: '0 0px 0 0px',
        lineHeight: '1.1',
    },
    padding20: {
        paddingBottom: '20px'
    },
    filtercriteriadetailBlock: {
        width: '18ch'
    },
    displayFieldWrapper: {
        display: 'flex'
    },
    typeBlockField: {
        width: '20ch'
    },
    buttonActions: {
        display: 'flex',
        alignItems: 'center',
        '@media (max-width: 1220px)': {
            marginBottom: '20px',
        },
        '& .MuiButton-root': {
            borderRadius: '4px',
            fontSize: '14px',
            width: '120px',
            lineHeight: '14px',
        },
        '& .MuiButton-sizeLarge': {
            fontSize: '18px',
        },
        '& .MuiButton-sizeSmall': {
            fontSize: '12px',
            padding: '8px 16px',
        },
        '& .MuiButton-containedPrimary': {
            backgroundColor: theme.palette.primary.default,
            border: '1px solid rgba(0, 0, 0, 0)',
            boxShadow: 'none',
            color: 'var(--background-content)',
            '&:hover': {
                backgroundColor: theme.palette.primary.hover,
                color: 'var(--background-content)',
                border: '1px solid rgba(0, 0, 0, 0)',
            },
            '&:focus': {
                backgroundColor: theme.palette.primary.focus,
                color: 'var(--background-content)',
                border: '1px solid rgba(0, 0, 0, 0)',
            },
            '&:active': {
                backgroundColor: theme.palette.primary.active,
                color: 'var(--background-content)',
                border: '1px solid rgba(0, 0, 0, 0)',
            },
        },
        '& .MuiButton-containedSecondary': {
            backgroundColor: 'var(--background-content)',
            border: '1px solid var(--button-tertiary-color)',
            color: 'var(--button-tertiary-color)',
            boxShadow: '0px 4px 14px rgba(0, 0, 0, 0.05)',
            '&:hover': {
                backgroundColor: 'var(--background-content)',
                color: 'var(--button-tertiary-hover-color)',
                border: '1px solid var(--button-tertiary-hover-color)',
            },
            '&:focus': {
                backgroundColor: 'var(--background-content)',
                color: 'var(--button-tertiary-focused)',
                border: '1px solid var(--button-tertiary-focused)',
            },
            '&:active': {
                backgroundColor: 'var(--background-content)',
                color: 'var(--button-tertiary-hover-color)',
                border: '1px solid var(--button-tertiary-hover-color)',
            },
            '&.Mui-disabled': {
                color: theme.palette.primary.disabled,
                textDecoration: 'unset',
                backgroundColor: 'unset',
                textShadow: 'unset',
            },
        },
        '& .MuiButton-outlinedPrimary': {
            border: `${'1px solid '}${theme.palette.primary.default}`,
            boxShadow: '0px 4px 14px rgba(0, 0, 0, 0.05)',
            backgroundColor: 'var(--background-content)',
            color: theme.palette.primary.default,
            '&:hover': {
                backgroundColor: 'var(--background-content)',
                border: '1px solid var(--button-secondary-hover-border)',
                color: 'var(--button-secondary-hover-border)',
            },
            '&:focus': {
                backgroundColor: 'var(--background-content)',
                border: `${'1px solid '}${theme.palette.primary.default}`,
                color: theme.palette.primary.default,
            },
            '&:active': {
                backgroundColor: 'var(--background-content)',
                border: '1px solid var(--primary-button-pressed)',
                color: 'var(--primary-button-pressed)',
            },
            '&.Mui-disabled': {
                color: theme.palette.primary.disabled,
                textDecoration: 'unset',
                backgroundColor: 'unset',
                textShadow: 'unset',
            },
        },
        '& .MuiButton-outlinedSecondary': {
            backgroundColor: 'var(--background-content)',
            border: '1px solid var(--button-tertiary-color)',
            color: 'var(--button-tertiary-color)',
            boxShadow: '0px 4px 14px rgba(0, 0, 0, 0.05)',
            '&:hover': {
                backgroundColor: 'var(--background-content)',
                color: 'var(--button-tertiary-hover-color)',
                border: '1px solid var(--button-tertiary-hover-color)',
            },
            '&:focus': {
                backgroundColor: 'var(--background-content)',
                color: 'var(--button-tertiary-focused)',
                border: '1px solid var(--button-tertiary-focused)',
            },
            '&:active': {
                backgroundColor: 'var(--background-content)',
                color: 'var(--button-tertiary-hover-color)',
                border: '1px solid var(--button-tertiary-hover-color)',
            },
            '&.Mui-disabled': {
                color: theme.palette.primary.disabled,
                textDecoration: 'unset',
                backgroundColor: 'unset',
                textShadow: 'unset',
            },
        },
    },
    buttonActionsSecondChild: {
        marginRight: '15px',
        '& .MuiButton-outlinedPrimary': {
            width: '100px',
            height: '28px',
        },
    },
    actionsFilter: {
        minWidth: '37px',
        border: '1px solid var(--primary-default)',
        height: '32px',
        marginLeft: '15px',
        '@media (max-width: 1220px)': {
            marginLeft: '0px',
        },
        '& img': {
            width: '14px',
            height: '14px',
        },
        '& svg': {
            width: '18px',
            height: '18px',
        },
    },
    menuButton: {
        minWidth: '37px',
        border: '1px solid var(--primary-default)',
        height: '32px',
        marginLeft: '15px',
        borderRadius: '4px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        '@media (max-width: 1220px)': {
            marginLeft: '0px',
        },
    },
    openPoActions: {
        top: '24px',
        padding: '0px 0px 20px 20px',
        right: '16px',
        display: 'flex',
        position: 'absolute',
        alignItems: 'center',
        justifyContent: 'space-between',
        '@media (max-width: 1220px)': {
            flexWrap: 'wrap',
            width: '250px',
        },
    },
    actions: {
        padding: '0 !important',
        margin: '0',
        minWidth: '16px',
        background: 'none',
        height: '16px',
        width: '16px',
    },
    fieldLabel: {
        paddingLeft: '6px'
    },
    descField: {
        width: '36ch',
        '& .MuiInput-root': {
            maxWidth: '36ch'
        }
    },
    commentField: {
        width: '50ch',
        paddingRight: '20px',
        backgroundColor: 'white',
        '& .MuiInput-root': {
            maxWidth: '50ch',
            paddingRight: '20px',
            backgroundColor: 'white',
        }
    },
    formField: {
        width: 'inherit'
    }
})

class Header extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            type: '',
            contextMenuList: CONTEXT_MENU_HEADER,
            isOpenActionsContextMenu: false,
            menuRef: null,
            actionList: CONTEXT_MENU_HEADER,
            isOpenActions: false,
            actionMenuRef: null,
            headerData: {
                FVDESC: '',
                FVLOCK: ''
            }

        }
        this.setIsOpenActionsButtonContextMenu = this.setIsOpenActionsButtonContextMenu.bind(this);
    }

    updateMenu = (disableApprove) => {
        this.setState({
            actionList: this.state.actionList.map((ele) => ({
                ...ele, isDisable: ele.key == 'approve' ? disableApprove : ele.isDisable
            }))
        })
    }

    componentDidMount() {
        if (this.props?.headerDetails?.data) {
            this.setState({ headerData: this.props?.headerDetails?.data })
        }
    }

    componentDidUpdate(prevProps) {
        const { data } = this.props.headerDetails
        const { selectVendorItemData, filterCriteriaDetails } = this.props
        if (data && !isEqual(data, prevProps.headerDetails.data)) {
            this.setState({ headerData: data })
        }
        if (selectVendorItemData && !isEqual(selectVendorItemData.rowData, prevProps.selectVendorItemData?.rowData)) {
            this.updateMenu(selectVendorItemData.rowData && selectVendorItemData.rowData.length ? false : true)
        }

        if (filterCriteriaDetails && !isEqual(filterCriteriaDetails, prevProps.filterCriteriaDetails)) {
            this.setState({
                headerData: {
                    ...this.state.headerData,
                    FVDEFN: filterCriteriaDetails['FVDEFN']
                }
            })
        }

    }


    getLabelValue = (id) => {
        return <FormattedMessageComponent id={id} />;
    }

    setIsOpenActionsButtonContextMenu = event => {
        this.setState({ isOpenActions: Boolean(event) });
        this.setState({ actionMenuRef: event.currentTarget ? event.currentTarget : event });
    }
    setIsActionClose = () => {
        this.setState({ isOpenActions: false });
    }

    onClickDownArrow() {
        this.props.handleHeaderDownArrowClick();
    }

    onClickUpArrow() {
        this.props.handleHeaderUpArrowClick();
    }

    onChange = (key, value, field) => {
        this.setState({ headerData: { ...this.state.headerData, [`${!field.prefixFlag ? getListPredecessor(FILTERCRITERIA_LIST_PAGE) : ''}${key}`]: value } })
    }

    setIsOpenActionsContextMenu = event => {
        this.setState({ isOpenActionsContextMenu: Boolean(event) });
        this.setState({ menuRef: event.currentTarget ? event.currentTarget : event, });
    };
    render() {
        const { classes, headerDetails, isShowContextMenu, removeChildCutdownTab, contextMenu, selectedValue, handleHeaderActionItemSelection, onContextMenuChange, currentOwnerName, selectedRecordObj } = this.props
        
        LockField[0].disabled = false;
        DescriptionField[0].disabled = false;
        if (currentOwnerName != false && this.props?.headerDetails?.data && headerDetails.data.FVOWNR != currentOwnerName) {
            LockField[0].disabled = true;
            if (headerDetails.data.FVLOCK == '1') {
				DescriptionField[0].disabled = true;
			}  
		}
         
        return (
            <div className={classes.propertiesHeaderContainer}>
                <div className={classes.filtercriteriaContainer}>
                    <Box className={classes.headerDetailsWrapper}>
                        <Box className={classes.arrowWrapper}>
                            <Button
                                color="primary"
                                onClick={() => this.onClickUpArrow()}
                                className={classes.arrow}
                                disabled={!this.props.hasPrevious}
                            >
                                <KeyboardArrowUpIcon />
                            </Button>
                            <Button
                                color="primary"
                                onClick={() => this.onClickDownArrow()}
                                className={classes.arrow}
                                disabled={!this.props.hasNext}
                            >
                                <KeyboardArrowDownIcon />
                            </Button>
                        </Box>
                        <Box className={classes.headerDetailRow}>
                            <div className={`${classes.displayFieldWrapper}`}>
                                <div className={`${classes.detailBlockField} ${classes.filtercriteriadetailBlock}`}>
                                    <div className={classes.headerLabel}>
                                        {this.getLabelValue(LABEL_FILTERCRITERIA_ID)}
                                    </div>
                                    <div className={classes.headerFieldValue}>
                                        {headerDetails?.data?.[KEY_FILTERCRITERIA_ID]}
                                    </div>
                                    <div className={classes.headerLabel1}>
                                        {this.getLabelValue(LABEL_FILTERCRITERIA_LOCK)}
                                    </div>
                                    <div className={classes.headerFieldValue}>
                                        <FormFieldsGenerator
                                            valueDisplayCharacters={20}
                                            key={'lock'}
                                            fieldsArray={LockField}
                                            valuesArray={this.state.headerData}
                                            handleChangeValue={this.onChange}
                                            enableAddButton={(e) => { this.props.enableAddButton(e) }}
                                            handleFocusOut={() => { }}
                                            currentPage={FILTERCRITERIA_LIST_PAGE}
                                            noMassMaintenance={true}
                                            hideLabels={true}
                                            parentFieldWrapper={classes.formField}
                                        />
                                    </div>
                                </div>
                                <div className={`${classes.detailBlockField} ${classes.typeBlockField}`}>
                                    <div className={classes.headerLabel}>
                                        {this.getLabelValue(LABEL_TYPE)}
                                    </div>
                                    <div className={classes.headerFieldValue}>
                                        {headerDetails?.data?.[KEY_TYPE]}
                                    </div>
                                    <div className={classes.headerLabel1}>
                                        {this.getLabelValue(LABEL_FILTERCRITERIA_EVI)}
                                    </div>
                                    <div className={classes.headerFieldValue}>
                                        <FormFieldsGenerator
                                            valueDisplayCharacters={20}
                                            key={'evi'}
                                            fieldsArray={EVIField}
                                            valuesArray={this.state.headerData}
                                            handleChangeValue={this.onChange}
                                            enableAddButton={(e) => { this.props.enableAddButton(e) }}
                                            handleFocusOut={() => { }}
                                            currentPage={FILTERCRITERIA_LIST_PAGE}
                                            noMassMaintenance={true}
                                            hideLabels={true}
                                            parentFieldWrapper={classes.formField}
                                        />
                                    </div>
                                </div>
                                <div className={`${classes.detailBlockField} ${classes.typeBlockField}`}>
                                    <div className={classes.headerLabel}>
                                        {this.getLabelValue(LABEL_OWNER)}
                                    </div>
                                    <div className={classes.headerFieldValue}>
                                        {headerDetails?.data?.[KEY_OWNER_ID]}
                                    </div>
                                </div>

                                <div className={`${classes.detailBlockField}`}>
                                    <div className={`${classes.headerLabel} ${classes.fieldLabel}`}>
                                        {this.getLabelValue(LABEL_DESCRIPTION)}
                                    </div>
                                    <div className={classes.descField}>
                                        <FormFieldsGenerator
                                            valueDisplayCharacters={20}
                                            key={'desc'}
                                            fieldsArray={DescriptionField}
                                            valuesArray={this.state.headerData}
                                            handleChangeValue={this.onChange}
                                            enableAddButton={(e) => { this.props.enableAddButton(e) }}
                                            handleFocusOut={() => { }}
                                            currentPage={FILTERCRITERIA_LIST_PAGE}
                                            noMassMaintenance={true}
                                            hideLabels={true}
                                            parentFieldWrapper={classes.formField}
                                        />
                                    </div>
                                </div>

                            </div>
                        </Box>
                        <Box className={classes.openPoActions}>
                            <div className={classes.buttonActions}>
                                <div className={isShowContextMenu ? 'showContextMenu' : 'hideContextMenu'}>
                                    <BreadcrumbContextMenu
                                        onOptionChange={(e, val) => onContextMenuChange(e, val)} menuItems={contextMenu}
                                        removeChildCutdownTab={removeChildCutdownTab}
                                        selectedValue={selectedValue} />
                                </div>
                            </div>
                            <Button
                                component="div"
                                color="primary"
                                onClick={this.props.handleHeaderFilterClick}
                                className={classes.actionsFilter}
                            >
                                <img src={FilterIcon} alt="Filter Icon" />
                            </Button>
                            <Button
                                component="div"
                                color="primary"
                                onClick={() => this.props.handleHeaderSaveClick({ ...this.state.headerData, FVSTAT: 'C' })}
                                disabled={!this.props.isSaveEnabled}
                                className={classes.actionsFilter}
                            >
                                <SaveIcon fontSize="large" />
                            </Button>
                            <Box className={classes.menuButton}>
                                <div
                                    onMouseEnter={event => this.setIsOpenActionsContextMenu(event)}
                                    onMouseLeave={() => this.setIsOpenActionsContextMenu(false)}
                                >
                                    <MoreVertIcon color="primary" className="cPointer" />
                                    <ContextMenuCreateNew
                                        className={classes.ActionsContextMenu}
                                        menuList={this.state.contextMenuList}
                                        isOpen={this.state.isOpenActionsContextMenu}
                                        menuRef={this.state.menuRef}
                                        handleItemSelection={(val) => handleHeaderActionItemSelection(val)}
                                        handleMenuClose={val => this.setIsOpenActionsContextMenu(val)}
                                    />
                                </div>
                            </Box>
                        </Box>
                    </Box>
                </div>
            </div>
        )
    }
}

const mapStateToProps = createStructuredSelector({
    selectVendorItemData: makeVendorItemData(),
})

const withConnect = connect(
    mapStateToProps,
    undefined,
);

export default compose(withConnect, withStyles(style))(Header);
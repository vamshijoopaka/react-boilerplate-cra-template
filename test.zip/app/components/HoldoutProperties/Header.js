import React from 'react';
import { withStyles, Button, Box } from '@material-ui/core';
import { injectIntl } from 'react-intl';
import KeyboardArrowUpIcon from '@material-ui/icons/KeyboardArrowUp';
import KeyboardArrowDownIcon from '@material-ui/icons/KeyboardArrowDown';
import MoreVertIcon from '@material-ui/icons/MoreVert';
import SaveIcon from '@material-ui/icons/Save';
import PropTypes from 'prop-types';
import {
    KEY_VENDOR_NAME, KEY_VENDOR_ID, KEY_WAREHOUSE_ID,
    KEY_WAREHOUSE_NAME, KEY_ITEM_ID, KEY_ITEM_NAME, LABEL_VENDOR_ID,
    LABEL_WAREHOUSE_NAME, LABEL_WAREHOUSE_ID, LABEL_ITEM_ID, LABEL_ITEM_NAME,
    CONTEXT_MENU_HOLDOUT_HEADER,
    LABEL_BUYR_ID, KEY_BUYR_ID, LABEL_VENDOR_NAME, KEY_SUB_VENDOR_ID, LABEL_SUB_VENDOR_ID
} from './constants';
import { HOLDOUTS_LIST_PAGE, BADGE_MAX_COUNT } from '../common/constants';

import FormattedMessageComponent from '../common/FormattedMessageComponent';
import FilterIcon from "../../images/icon_filter.png";
import ContextMenu from '../common/ContextMenu';
import ContextMenuCreateNew from '../common/ContextMenuCreateNew';
import { LABEL_NOTE } from './HoldoutNotes/constants';
import { Badge } from '@material-ui/core';
import BreadcrumbContextMenu from 'components/common/BreadcrumbContextMenu';

const defaultProps = {
    holdoutData: {},
    saveDisabled: true,
};

const propTypes = {
    holdoutData: PropTypes.array.isRequired,
    saveDisabled: PropTypes.bool.isRequired,
    handleHoldoutHeaderFilterClick: PropTypes.func,
    handleHoldoutHeaderSaveClick: PropTypes.func,
    handleHoldoutHeaderLeftArrowClick: PropTypes.func,
    handleHoldoutHeaderRightArrowClick: PropTypes.func,
    handleHoldoutHeaderActionItemSelection: PropTypes.func
};

const style = () => ({
    propertiesHeaderContainer: {
        width: '100%',
        marginBottom: '1.5rem',
        backgroundColor: 'var(--background-app)',
        borderRadius: '4px',
        borderTopLeftRadius: '0px',
        borderTopRightRadius: '0px',
        overflow: 'hidden',
        boxShadow: '0 4px 4px var(--secondary-s10)',
        overflowX: 'auto'
    },
    holdoutContainer: {
        display: 'flex',
        width: '100%',
        backgroundColor: 'var(--background-content)',
        fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
        alignItems: 'center',
        padding: '0 0 0 24px',
        position: 'relative',
        minWidth: '630px'
    },
    holdoutDetailsWrapper: {
        width: '100%',
        display: 'flex',
    },
    holdoutDetailRow: {
        width: '100%',
        display: 'flex',
        flexWrap: 'wrap',
        padding: '0px 0 24px 0',
        paddingLeft: '15px'
    },
    holdoutDetail: {
        padding: '0px 0px 0px 0px',
        lineHeight: '1.1',
    },
    holdoutLabel: {
        color: 'var(--header-label-color)',
        paddingBottom: '6px',
        width: '20ch',
    },
    holdoutItemLabel: {
        color: 'var(--header-label-color)',
        paddingBottom: '6px',
        width: '48ch',
        height: '42px',
    },
    holdoutItemValue: {
        color: 'var(--value)',
        width: '25ch',
        height: '42px',
    },
    holdoutValue: {
        color: 'var(--value)',
    },
    holdoutActions: {
        top: '24px',
        padding: '0px 20px 20px 20px',
        right: '16px',
        display: 'flex',
        position: 'absolute',
        alignItems: 'center',
        justifyContent: 'space-between',
        '@media (max-width: 1220px)': {
            flexWrap: 'wrap',
            width: '250px'
        }
    },
    holdoutActionsFilter: {
        minWidth: '37px',
        border: '1px solid var(--primary-default)',
        height: '32px',
        marginLeft: '15px',
        '@media (max-width: 1220px)': {
            marginLeft: '0px'
        },
        '& img': {
            width: '14px',
            height: '14px'
        },
        '& svg': {
            width: '18px',
            height: '18px'
        }
    },
    holdoutArrow: {
        padding: '0 !important',
        margin: '0',
        minWidth: '16px',
        background: 'none',
        height: '16px',
        width: '16px',
    },
    holdoutArrowWrapper: {
        display: 'flex',
        flexDirection: 'column',
        border: '1px solid var(--primary-default)',
        borderRadius: '4px',
        justifyContent: 'center',
        alignItems: 'baseline',
        height: '38px',
        marginTop: '24px',
        padding: '2px',
    },
    holdoutIDBlock: {
        display: 'flex',
    },
    holdoutSubHoldoutDetails: {
        display: 'flex',
        flexDirection: 'column',
        width: '16ch',
        padding: '0 30px 0 0px',
        lineHeight: '1.1'
    },
    holdoutIdDetails: {
        width: '16ch',
        padding: '0 30px 0 0px',
        lineHeight: '1.1'
    },
    holdoutIDSubID: {
        paddingTop: '24px'
    },
    menuButton: {
        minWidth: '37px',
        border: '1px solid var(--primary-default)',
        height: '32px',
        marginLeft: '15px',
        borderRadius: '4px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        '@media (max-width: 1220px)': {
            marginLeft: '0px'
        },
    },
    label: {
        color: 'var(--header-label-color)',
        paddingBottom: '6px',
        width: '20ch',
    },
    value: {
        color: 'var(--value)',
        height: '1rem'
    },
    references: {
        position: 'absolute',
        right: '3rem',
        bottom: '0px',

        '&& .MuiBadge-root': {              //E3C30273_Styling for Badge
            '& .MuiBadge-badge': {
                fontSize: '0.6 rem',
                padding: '2px 5px',
                height: '13.5px',
                minWidth: props => (props.notesCountWidth || '21px'),
            }
        }
    },
});

class Header extends React.Component {
    state = {
        contextMenuList: CONTEXT_MENU_HOLDOUT_HEADER,
        isOpenActionsContextMenu: false,
        menuRef: null,
        actionMenuRef: null,
    }

    getLabelValue = (id) => +id ? <FormattedMessageComponent id={id} /> : id;

    handleDisableUpArrow = () => {
        const { hasPrevious, fromListPage } = this.props;
        return !hasPrevious || fromListPage != HOLDOUTS_LIST_PAGE;
    };

    handleDisableDownArrow = () => {
        const { hasNext, fromListPage } = this.props;
        return !hasNext || fromListPage != HOLDOUTS_LIST_PAGE;
    };

    setIsOpenActionsContextMenu = event => {
        this.setState({ isOpenActionsContextMenu: Boolean(event) });
        this.setState({ menuRef: event.currentTarget ? event.currentTarget : event });
        if (event) {
            let contextMenuList = CONTEXT_MENU_HOLDOUT_HEADER.map(action => {
                return { ...action, isDisable: this.props.isActionDisabled(action.key) }
            })
            this.setState({ contextMenuList })
        }
    }

    onClickDownArrow = () => {
        this.props.handleHoldoutHeaderLeftArrowClick();
    }

    onClickUpArrow = () => {
        this.props.handleHoldoutHeaderRightArrowClick();
    }

    render() {
        const { classes, holdoutData, handleHoldoutHeaderFilterClick, handleHoldoutHeaderSaveClick,
            saveDisabled, handleHoldoutHeaderActionItemSelection, currentPage, names, onContextMenuChange, removeChildCutdownTab, selectedValue, isShowContextMenu, contextMenu } = this.props;
        return (

            <div className={classes.propertiesHeaderContainer}>
                {holdoutData && currentPage &&
                    <div className={classes.holdoutContainer}>
                        <Box className={classes.holdoutDetailsWrapper}>
                            <Box className={classes.holdoutArrowWrapper}>
                                <Button color="primary" onClick={() => this.onClickUpArrow()} className={classes.holdoutArrow} disabled={this.handleDisableUpArrow()}>
                                    <KeyboardArrowUpIcon />
                                </Button>
                                <Button color="primary" onClick={() => this.onClickDownArrow()} className={classes.holdoutArrow} disabled={this.handleDisableDownArrow()}>
                                    <KeyboardArrowDownIcon />
                                </Button>
                            </Box>
                            <Box className={classes.holdoutDetailRow}>
                                <div className={classes.holdoutIDSubID}>
                                    <div className={classes.holdoutDetailRow}>
                                        <div className={`${classes.holdoutIDBlock} ${classes.holdoutItemLabel}`}>
                                            <div className={`${classes.holdoutDetail} ${classes.holdoutIdDetails}`}>
                                                <div className={classes.holdoutLabel}>
                                                    {this.getLabelValue(LABEL_VENDOR_ID)}
                                                </div>
                                                <div className={classes.holdoutValue}>{holdoutData[KEY_VENDOR_ID]}</div>
                                            </div>
                                            <div className={`${classes.holdoutIDBlock} ${classes.holdoutItemLabel}`}>
                                                <div className={`${classes.holdoutDetail} ${classes.holdoutSubHoldoutDetails}`}>
                                                    <div className={classes.holdoutItemLabel}>
                                                        {this.getLabelValue(LABEL_VENDOR_NAME)}
                                                    </div>
                                                    <div className={classes.holdoutItemValue}>{names[KEY_VENDOR_NAME]}</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className={`${classes.holdoutDetail} ${classes.holdoutSubHoldoutDetails}`}>
                                            <div className={classes.holdoutLabel}>
                                                {this.getLabelValue(LABEL_SUB_VENDOR_ID)}
                                            </div>
                                            <div className={classes.holdoutValue}>{holdoutData[KEY_SUB_VENDOR_ID]}</div>
                                        </div>

                                        <div className={classes.holdoutIDBlock}>
                                            <div className={`${classes.holdoutDetail} ${classes.holdoutIdDetails}`}>
                                                <div className={classes.holdoutLabel}>
                                                    {this.getLabelValue(LABEL_WAREHOUSE_ID)}
                                                </div>
                                                <div className={classes.holdoutValue}>{holdoutData[KEY_WAREHOUSE_ID]} </div>
                                            </div>
                                        </div>
                                        <div className={`${classes.holdoutIDBlock} ${classes.holdoutItemLabel}`}>
                                            <div className={`${classes.holdoutDetail} ${classes.holdoutSubHoldoutDetails}`}>
                                                <div className={classes.holdoutItemLabel}>
                                                    {this.getLabelValue(LABEL_WAREHOUSE_NAME)}
                                                </div>
                                                <div className={classes.holdoutItemValue}>{names[KEY_WAREHOUSE_NAME]}</div>
                                            </div>
                                        </div>
                                    </div>

                                    <div className={classes.holdoutDetailRow}>
                                        <div className={`${classes.holdoutIDBlock} ${classes.holdoutItemLabel}`}>
                                            <div className={`${classes.holdoutDetail} ${classes.holdoutIdDetails}`}>
                                                <div className={classes.holdoutLabel}>
                                                    {this.getLabelValue(LABEL_ITEM_ID)}
                                                </div>
                                                <div className={classes.holdoutValue}>{holdoutData[KEY_ITEM_ID]}</div>
                                            </div>
                                            <div className={`${classes.holdoutDetail} ${classes.holdoutSubHoldoutDetails}`}>
                                                <div className={classes.holdoutItemLabel}>
                                                    {this.getLabelValue(LABEL_ITEM_NAME)}
                                                </div>
                                                <div className={classes.holdoutItemValue}> {names[KEY_ITEM_NAME]}</div>
                                            </div>
                                        </div>

                                        <div className={classes.holdoutIDBlock}>
                                            <div className={`${classes.holdoutDetail} ${classes.holdoutIdDetails}`}>
                                                <div className={classes.holdoutLabel}>
                                                    {this.getLabelValue(LABEL_BUYR_ID)}
                                                </div>
                                                <div className={classes.holdoutValue}>{holdoutData[KEY_BUYR_ID]} </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </Box>
                        </Box>
                        <Box className={classes.holdoutActions}>
                            <div>
                                <BreadcrumbContextMenu
                                    onOptionChange={(e, val) => onContextMenuChange(e, val)} menuItems={contextMenu}
                                    removeChildCutdownTab={removeChildCutdownTab}
                                    selectedValue={selectedValue} 
                                />
          					</div>
                            <Button component="div" color="primary" onClick={handleHoldoutHeaderFilterClick} className={classes.holdoutActionsFilter}>
                                <img src={FilterIcon} alt="Filter Icon" />
                            </Button>
                            <Button component="div" color="primary" onClick={handleHoldoutHeaderSaveClick} disabled={saveDisabled} className={classes.holdoutActionsFilter}>
                                <SaveIcon fontSize="large" />
                            </Button>
                            <Box className={classes.menuButton}>
                                <div
                                    onMouseEnter={(event) => this.setIsOpenActionsContextMenu(event)}
                                    onMouseLeave={() => this.setIsOpenActionsContextMenu(false)}>
                                    <MoreVertIcon color="primary" className="cPointer"></MoreVertIcon>
                                    <ContextMenuCreateNew
                                        className={classes.ActionsContextMenu}
                                        menuList={this.state.contextMenuList}
                                        isOpen={this.state.isOpenActionsContextMenu}
                                        menuRef={this.state.menuRef}
                                        handleItemSelection={(val) => handleHoldoutHeaderActionItemSelection(val)}
                                        handleMenuClose={(val) => this.setIsOpenActionsContextMenu(val)}
                                        currentPage={this.props.currentPage}
                                        currentRecord={holdoutData}
                                    />
                                </div>
                            </Box>
                        </Box>
                    <Box className={classes.references}>
                        <Button component="div" color="primary" size="small" onClick={e => { document.getElementById("holdoutNotes").scrollIntoView(); }}>
                            {this.getLabelValue(LABEL_NOTE)}
                        </Button>
                        <Badge color="error" overlap="circle" anchorOrigin={{ vertical: "top", horizontal: "right" }} max={BADGE_MAX_COUNT} badgeContent={this.props.notesCount}>
                        </Badge>
                    </Box>
                    </div>
                }
            </div>
        );
    }
}

Header.defaultProps = defaultProps;
Header.propTypes = propTypes;

export default injectIntl(withStyles(style)(Header));

import {
    COLUMN_HEADER_ACCESSOR, 
    COLUMN_VALUE_ACCESSOR,
    COLUMN_SHOW_HIDE_FLAG,
    COLUMN_POSITION,
    COLUMN_HEADER_PREFIX_FLAG
} from '../../components/common/constants';

export const DEFAULT_ACTION = 'app/ItemsListPage/DEFAULT_ACTION';
export const LOAD_ITEMS = 'app/ItemsListPage/LOAD_ITEMS';
export const LOAD_ITEMS_ERROR = 'app/ItemsListPage/LOAD_ITEMS_ERROR';
export const LOAD_ITEMS_SUCCESS = 'app/ItemsListPage/LOAD_ITEMS_SUCCESS';
export const LOAD_ITEMS_COUNT = 'app/ItemsListPage/LOAD_ITEMS_COUNT';
export const LOAD_ITEMS_COUNT_ERROR = 'app/ItemsListPage/LOAD_ITEMS_COUNT_ERROR';
export const LOAD_ITEMS_COUNT_SUCCESS = 'app/ItemsListPage/LOAD_ITEMS_COUNT_SUCCESS';
export const SET_SEARCHPROPS = 'app/ItemsListPage/SET_SEARCHPROPS';
export const SET_SORTPROPS = 'app/ItemsListPage/SET_SORTPROPS';
export const SET_FILTERID = 'app/ItemsListPage/SET_FILTERID';
export const SET_ADVANCED_FILTERS = 'app/ItemsListPage/SET_ADVANCED_FILTERS';
export const SET_FILTERPROPS = 'app/ItemsListPage/SET_FILTERPROPS';
export const SET_PAGEPROPS = 'app/ItemsListPage/SET_PAGEPROPS';
export const SET_PROPERTIESPROPS = 'app/ItemsListPage/SET_PROPERTIESPROPS';
export const SET_ITEM_COLUMN_DEF = 'app/ItemsListPage/SET_ITEM_COLUMN_DEF';
export const LOAD_HEADER = 'app/LOAD_HEADER';
export const GET_ITEM_COLUMN_DEF = 'app/ItemsListPage/GET_ITEM_COLUMN_DEF';

export const ITEMS_LIST_MANDATORY_FIELDS = ['COMP', 'WHSE']

export const ITEM_PROPERTIES = {
    "headerName": COLUMN_HEADER_ACCESSOR,
    "field": COLUMN_VALUE_ACCESSOR,
    "showHideFlag": COLUMN_SHOW_HIDE_FLAG,
    "columnPosition": COLUMN_POSITION,
    "prefixFlag": COLUMN_HEADER_PREFIX_FLAG
}

export const PAGE_SIZES = [10, 20, 30];

export const ITEM_LIST_PAGE = "itemsListPage";

export const SET_ITEM_GLOBAL_FILTER_PROPS = "SET_ITEM_GLOBAL_FILTER_PROPS";

export const INITIAL_PAGE_PROPS = {
    actualPage: 0,
    currentPage: 0,
    totalCount: 10,
    actualPageSize: 10,
    pageSize: 100,
    isPageSizeChanged: false,
    isForwardDirection: true
}

export const HAS_PAGINATION = true;
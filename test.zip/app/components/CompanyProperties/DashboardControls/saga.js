/** Change Log
 * LogStart --  E3C-33195 - Kumar A- 16 September,2021 - 2022.1.0.0 Unified Product
 *              Story: E3C-33195 --Code Cleanup
*/
import { call, put, takeLatest } from 'redux-saga/effects';

import request from 'utils/request';
import UrlFormatUtils from 'utils/sagaUrlFormatter';
import { API_URI } from 'utils/url';
import { DASHBOARD_CONTROL_GET_FIELD_LIST } from './constants';
import { getFieldListSuccess, getFieldListFailure } from './actions';
import { urlEndPoints } from 'utils/urlJson';

export function* getFieldListDefs(action){
    let url, response;
    url = `${API_URI}/${urlEndPoints["companyproperties"]}`;
    url = UrlFormatUtils.formatCompanyPropertiesUrl(url, action.data);
    try{
        response = yield call(request, url);
        yield put(getFieldListSuccess(response));
    } catch(err){
        yield put(getFieldListFailure(err));
    }
}

export default function* CompanyControlFactorsSaga() {
    yield takeLatest(DASHBOARD_CONTROL_GET_FIELD_LIST, getFieldListDefs);
}
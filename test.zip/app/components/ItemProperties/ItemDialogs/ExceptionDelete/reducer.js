import { fromJS } from 'immutable';
import { cloneDeep } from 'lodash';
import { COLUMN_FIELD_TYPE, COLUMN_HEADER_ACCESSOR, COLUMN_POSITION, COLUMN_VALUE_ACCESSOR, COLUMN_DECIMAL_FIELD, DROPDOWN_FIELD, INITIAL_PAGE_PROPS } from 'components/common/constants';
import { getSortableColumns, setNumberFields } from 'utils/util';
import {
  Poline, Cancelline, GET_FILTER_DATA, GET_KEY_CHANGE_DATA, GET_FILTERCRITERIA_DATA, GET_FILTERCRITERIA_DATA_SUCCESS,
  GET_FILTERCRITERIA_DATA_FAIL, GET_COLUMN_DEFS, GET_COLUMN_DEFS_SUCCESS, GET_COLUMN_DEFS_FAILURE, UPDATE_STATE, GET_POLINES_LIST,
  GET_POLINES_LIST_SUCCESS, GET_POLINES_LIST_FAILURE, UPDATE_SHOW_HIDE_COLUMNS, UPDATE_SHOW_HIDE_COLUMNS_SUCCESS,
  UPDATE_SHOW_HIDE_COLUMNS_FAILURE, SET_PAGE_PROPS, APPLY_CANCEL_LINES, APPLY_CANCEL_LINES_SUCCESS, APPLY_CANCEL_LINES_FAILURE
} from './constants';

export const initialState = fromJS({
  cardsData: [],
  cardsDataFailure: false,
  loading: false,
  cancelPoData: [],
  poLineData: [],
  radioVal: "",
  filterCols: [],
  columnDefs: false,
  columnInfo: false,
  updateColumnDefs: false,
  pageProps: INITIAL_PAGE_PROPS,
  polinesRowData: [],
  apiCount: 0,
  moreRecordsAvailable: false,
  totalCount: 0
})

function PoLinePropertiesActionsContainerReducer(state = initialState, action) {
  switch (action.type) {
    case GET_FILTER_DATA:
      let tabs = action.data.data && Array.isArray(action.data.data) ? JSON.parse(JSON.stringify(action.data.data)) : [];
      let currentVal = action.data.value

      let dataArray = tabs.find(obj => obj.tabkey == '25077')

      let line = dataArray.tabcards.find(obj => obj.cardkey == '25258')
      let linedata = line.cardfields
      let polinedata = linedata.filter(id => Poline.includes(id.FLDID));

      line = dataArray.tabcards.find(obj => obj.cardkey == '51095')
      linedata = line.cardfields
      let canceldata = linedata.filter(id => Cancelline.includes(id.FLDID));
     

      if (tabs && tabs.length) {
        tabs = tabs.map(tab => {
          tab.tabcards = tab.tabcards.map(tabCard => {
            tabCard.cardfields = getSortableColumns(tabCard.cardfields, false, COLUMN_FIELD_TYPE, DROPDOWN_FIELD);
            tabCard.cardfields = setNumberFields(tabCard.cardfields);
            tabCard.cardfields = tabCard.cardfields.map(card => {
              return Object.assign({}, card, {
                key: card[COLUMN_VALUE_ACCESSOR] ? card[COLUMN_VALUE_ACCESSOR].trim() : (card[COLUMN_HEADER_ACCESSOR] ? card[COLUMN_HEADER_ACCESSOR].trim() : (card["TLLAB"] ? card["TLLAB"].trim() : "")),
              });
            })
            return tabCard;
          })
          return tab;
        })

      }
      return state.set('cardsData', tabs).set('cancelPoData', canceldata).set('poLineData', polinedata)
        .set('loading', false).set('cardsDataFailure', true).set('radioVal', currentVal)

    case GET_KEY_CHANGE_DATA:
      let currentValue = action.data.value
      if (currentValue == "ThisPO") {
        let updatedpoLine = state.get("poLineData")
        updatedpoLine[0]["disabled"] = true;
        updatedpoLine[1]["disabled"] = false;
        updatedpoLine[2]["disabled"] = false;
        return state.set('poLineData', updatedpoLine).set('radioVal', currentValue)

      }
      if (currentValue == "AllPO" ) {
        let updatedpoLine1 = state.get("poLineData")
        updatedpoLine1[0]["disabled"] = true;
        updatedpoLine1[1]["disabled"] = true;
        updatedpoLine1[2]["disabled"] = false;
        return state.set('poLineData', updatedpoLine1).set('radioVal', currentValue)

      }
      if (currentValue == "Filter" ) {
        let updatedpoLine2 = state.get("poLineData")
        updatedpoLine2[0]["disabled"] = true;
        updatedpoLine2[1]["disabled"] = true;
        updatedpoLine2[2]["disabled"] = true;
        return state.set('poLineData', updatedpoLine2).set('radioVal', currentValue)

      }
      else {
        return state.set('loading', false)
          .set('cardsDataFailure', true)
      }
    case GET_FILTERCRITERIA_DATA: return state
    case GET_FILTERCRITERIA_DATA_SUCCESS:
      let list = Array.isArray(action.data) ? action.data : (action.data.fields && Array.isArray(action.data.fields) ? action.data.fields : []);
      list = getSortableColumns(list, COLUMN_POSITION, COLUMN_FIELD_TYPE, DROPDOWN_FIELD)
      return state.set('filterCols', list)
    case GET_FILTERCRITERIA_DATA_FAIL:
      return state.set('filterCols', [])

    case GET_COLUMN_DEFS: return state.set('loading', true).set('columnDefs', false)
    case GET_COLUMN_DEFS_SUCCESS:
      if (action.data && action.data.fields && action.data.fields.length) {
        let columnFields = action.data.fields;
        let position = COLUMN_POSITION,
          fieldType = COLUMN_FIELD_TYPE,
          dropdownField = DROPDOWN_FIELD;
        let list = getSortableColumns(columnFields, position, fieldType, dropdownField, true);
        list = list.map(item => Object.assign({}, item, { sortable: false }));
        return state.set('columnDefs', list).set('columnInfo', action.data?.info).set('updateColumnDefs', false).set('loading', false)
      }
      return state.set('columnDefs', []).set('columnInfo', action.data?.info).set('updateColumnDefs', false).set('loading', false)
    case GET_COLUMN_DEFS_FAILURE: return state.set('loading', false).set('columnDefs', []).set('columnInfo', {})
    case UPDATE_STATE: return state.set(action.data.key, action.data.value)
    case GET_POLINES_LIST: return state.set('loading', true).set('polinesRowData', []).set('moreRecordsAvailable', false).set('totalCount', 0)
    case GET_POLINES_LIST_SUCCESS:
      const itemList = action?.data && JSON.parse(action?.data)?.listArray?.length ? JSON.parse(action?.data)?.listArray : []
      const itemMore = action?.data ? JSON.parse(action?.data)?.moreRecordsAvailable : false
      let count = state.get('apiCount');
      count = 100 * count + itemList.length;
      return state.set('loading', false).set('polinesRowData', itemList).set('moreRecordsAvailable', itemMore)
        .set('totalCount', count)
    case GET_POLINES_LIST_FAILURE: return state.set('loading', false)
    case UPDATE_SHOW_HIDE_COLUMNS: return state.set('loading', true)
    case UPDATE_SHOW_HIDE_COLUMNS_SUCCESS:
      let updateData = action.data;
      if (updateData.message && updateData.message.length && updateData.message.toLowerCase() == 'success' && (action.code != 'D')) {
        return state.set('updateColumnDefs', true)
      } else if (updateData.message && updateData.message.length && updateData.message.toLowerCase() == 'success' && (action.code == 'D')) {
        return state.set('loading', false)
      }
      return state
    case UPDATE_SHOW_HIDE_COLUMNS_FAILURE:
      return state.set('loading', false)
    case SET_PAGE_PROPS: return state.set('pageProps', action.data)
    case APPLY_CANCEL_LINES: return state.set('loading', true).set('applySuccess', false)
    case APPLY_CANCEL_LINES_SUCCESS: return state.set('loading', false).set('applySuccess', true)
    case APPLY_CANCEL_LINES_FAILURE: return state.set('loading', false)
    default:
      return state;

  }
}
export default PoLinePropertiesActionsContainerReducer;










import { createSelector } from 'reselect';
import { initialState } from './reducer';


const selectCurrentPage = state => state.get('root');
const selectPoLineProperties = state => state.get('poLinePropertiesCancel') ? state.get('poLinePropertiesCancel') : initialState
const selectApp = (state) => state.get('app');

const makeSelectCurrentPage = () =>
  createSelector(
    selectCurrentPage,
    selectCurrentPage => selectCurrentPage.get('currentPage'),
  );
const getCardsData = () =>
  createSelector(
    selectPoLineProperties,
    propertiesData => propertiesData?.get('cardsData')
  )
const getCancelData = () =>
  createSelector(
    selectPoLineProperties,
    propertiesData => propertiesData?.get('cancelPoData')
  )
const getPoLineData = () =>
  createSelector(
    selectPoLineProperties,
    propertiesData => propertiesData?.get('poLineData')
  )
  const getFilterGridData = () =>
  createSelector(
    selectPoLineProperties,
    propertiesData => propertiesData?.get('filterCols')
  )

const getRadioData = () =>
  createSelector(
    selectPoLineProperties,
    propertiesData => propertiesData?.get('radioVal')
  )

const makePOLineActionsPropertiesData = () =>
  createSelector(
    selectPoLineProperties,
    selectPoLineProperties => selectPoLineProperties?.toJS()
  );

const getLoading = () =>
  createSelector(
    selectPoLineProperties,
    propertiesData => propertiesData?.get('loading')
  )

const makeSelectAuthorizedComponentsList = () => createSelector(
  selectApp, (selectApp) => selectApp.get('authorizedComponentsList')
)
const selectGlobalDecimalSeparator = () =>
  createSelector(
    selectCurrentPage,
    selectCurrentPage => selectCurrentPage.get("decimalSeparator"),
  );

const selectGlobalNumberSeparator = () =>
  createSelector(
    selectCurrentPage,
    selectCurrentPage => selectCurrentPage.get('numberSeparator')
  );

const selectGlobalNumberFormat = () =>
  createSelector(
    selectCurrentPage,
    selectCurrentPage => selectCurrentPage.get('numberFormatter')
  );
const makePageFilterOptions = () =>
  createSelector(
    selectCurrentPage,
    selectCurrentPage => selectCurrentPage.get("pageFilterOptions"),
  );

const makeFilterOptions = () =>
  createSelector(
    selectCurrentPage,
    selectCurrentPage => selectCurrentPage.get("globalFilterOptions"),
  );

const makeSelectGlobalSelectFilterList = () =>
  createSelector(
    selectApp,
    substate => substate.get("globalSecurityFilters"),
  );
const errorMessageLabels = () => createSelector(
  selectCurrentPage,
  substate => substate.get('errorMessageLabels') || false
)

export {
  makeSelectCurrentPage,
  getCardsData,
  makeSelectAuthorizedComponentsList,
  getLoading,
  makePOLineActionsPropertiesData,
  selectGlobalDecimalSeparator,
  selectGlobalNumberFormat,
  selectGlobalNumberSeparator,
  makeFilterOptions,
  makePageFilterOptions,
  makeSelectGlobalSelectFilterList,
  errorMessageLabels,
  getCancelData,
  getPoLineData,
  getRadioData,
  getFilterGridData

}
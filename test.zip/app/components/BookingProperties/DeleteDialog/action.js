import {
	GET_BOOKINGDELETE_LIST,
	GET_BOOKINGDELETE_LIST_SUCCESS,
	GET_BOOKINGDELETE_LIST_FAILURE,
	GET_BOOKINGDELETE_COLUMN_DEFINITION,
	GET_BOOKINGDELETE_COLUMN_DEFINITION_SUCCESS,
	GET_BOOKINGDELETE_COLUMN_DEFINITION_FAILURE,
	GET_BOOKINGDELETE_UPDATE_COLUMN_DEFINITION,
	GET_BOOKINGDELETE_UPDATE_COLUMN_DEFINITION_SUCCESS,
	GET_BOOKINGDELETE_UPDATE_COLUMN_DEFINITION_FAILURE,
	RESET_DEFAULTS,
	RESET_DEFAULTS_SUCCESS,
	RESET_DEFAULTS_FAILURE,
	SET_FILTER_VALUES,
	SET_COLUMN_DEFS_LOADED,
	SET_PAGEPROPS,
	SET_APICALL_COUNT,
	RESET_DATA,// needs to be handled carefully 
	GET_BOOKINGS_LIST,
	GET_BOOKINGS_LIST_SUCCESS,
	GET_BOOKINGS_LIST_FAILURE,
	LABEL_DATA_FLAGS
} from './constants';

export function getBookingDeleteList(namespace, data) {
	return {
		type: GET_BOOKINGDELETE_LIST,
		data
	}
}

export function setBookingDeleteListSuccess(data) {
	return {
		type: GET_BOOKINGDELETE_LIST_SUCCESS,
		data
	}
}

export function setBookingDeleteListFailure(data) {
	return {
		type: GET_BOOKINGDELETE_LIST_FAILURE,
		data
	}
}


export function getBookingDeleteColumnDefs(namespace, data) {
	return {
		type: GET_BOOKINGDELETE_COLUMN_DEFINITION,
		data
	}
}

export function setBookingDeleteListColumnDefs(data) {
	return {
		type: GET_BOOKINGDELETE_COLUMN_DEFINITION_SUCCESS,
		data
	}
}

export function setBookingDeleteListColumnDefsFailure(data) {
	return {
		type: GET_BOOKINGDELETE_COLUMN_DEFINITION_FAILURE,
		data
	}
}

export function updateShowHide(namespace, data) {
	return {
		type: GET_BOOKINGDELETE_UPDATE_COLUMN_DEFINITION,
		data
	}
}

export function updateColumnDefsSuccess(data) {
	return {
		type: GET_BOOKINGDELETE_UPDATE_COLUMN_DEFINITION_SUCCESS,
		data
	}
}

export function updateColumnDefsFailure(data) {
	return {
		type: GET_BOOKINGDELETE_UPDATE_COLUMN_DEFINITION_FAILURE,
		data
	}
}

export function resetDefault(data) {
	return {
		type: RESET_DEFAULTS,
		data
	}
}

export function resetDefaultSuccess(data) {
	return {
		type: RESET_DEFAULTS_SUCCESS,
		data
	}
}

export function resetDefaultFailure(data) {
	return {
		type: RESET_DEFAULTS_FAILURE,
		data
	}
}

export function setFilterValues(namespace, data) {
	return {
		type: SET_FILTER_VALUES,
		data
	}
}

export function setColumnDefsLoaded(namespace, data) {
	return {
		type: SET_COLUMN_DEFS_LOADED,
		data
	}
}

export function resetStateData(namespace, data) {
	return {
		type: RESET_DATA,
		data
	}
}


export function setApiCallCount(namespace, data) {
	return {
		type: SET_APICALL_COUNT,
		data
	}
}

export function onSetPageProps(namespace, data) {
	return {
		type: SET_PAGEPROPS,
		data
	}
}

export function getBookingsList(namespace, data) {
	return {
		type: GET_BOOKINGS_LIST,
		data
	}
}

export function setBookingsListSuccess(data) {
	return {
		type: GET_BOOKINGS_LIST_SUCCESS,
		data
	}
}

export function setBookingsListFailure(data) {
	return {
		type: GET_BOOKINGS_LIST_FAILURE,
		data
	}
}
export function setLabelDataFlags(namespace, data) {
	return {
		type: LABEL_DATA_FLAGS,
		data
	}
}
/** Change Log
 * LogStart --  E3C-29099 - Kumar A- 25 August,2021 - 2022.1.0.0 Unified Product
 *              Story: E3C-30006 --Unable to save User Defined Values(PO Control) and validations on these fields are not being applied
                Fixed QA testing issues.
                Code review comment incorporated.
 * LogStart --  E3C-33195 - Kumar A- 16 September,2021 - 2022.1.0.0 Unified Product
 *              Story: E3C-33195 --Code Cleanup
*/
import React from 'react';
import { compose } from 'redux';
import { withStyles } from '@material-ui/core/styles';
import PropTypes from 'prop-types';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import { Grid } from '@material-ui/core';
import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import Box from '@material-ui/core/Box';
import FormLabel from '@material-ui/core/FormLabel';
import Input from '@material-ui/core/Input';
import Checkbox from '@material-ui/core/Checkbox';
import FormControlLabel from '@material-ui/core/FormControlLabel';


import FormFieldsGenerator from '../../common/FormFieldsGenerator';
import FormattedMessageComponent from 'components/common/FormattedMessageComponent';
import Spinner from '../../common/Spinner';
import {
    PURCHASE_ORDER_FACTORS,
    COMPANY_RECEIVING_FACTORS,
    JOB_CONTROL_FACTORS,
    LABEL_COMPANY_UDF,
    LABEL_COMPANY_OAF,
    LABEL_COMPANY_DESCRIPTION,
    LABEL_COMPANY_NCF,
    LABEL_COMPANY_LENGTH,
    LABEL_COMPANY_PRECISION,
    LABEL_COMPANY_DV,
    LABEL_COMPANY_UOSF,
    LABEL_COMPANY_UIDF,
} from './constants';
import './style.scss';
import { COMPANYS_LIST_PAGE, COLUMN_VALUE_ACCESSOR } from 'components/common/constants';
import CardComponent from '../../common/CardComponent';
import FieldInput from 'components/common/Form/FieldInput';

const propTypes = {
    setSaveData: PropTypes.func,
};

const style = theme => ({
    pageContainer: {
        display: 'flex',
        backgroundColor: 'var(--background-app)',
        borderTop: 'none',
        padding: '10px 20px',
    },
    pageContainerSeventy: {
        width: '100%',
        flexFlow: 'wrap',
        display: 'flex',
    },
    pageContainerSeventy1: {
        width: '85%',
        flexFlow: 'wrap',
        display: 'flex',
        marginTop: '0px',
    },
    card: {
        padding: '0px',
        backgroundColor: 'var(--background-content)',
        borderRadius: '4px',
        width: '100%',
        margin: '8px',
        '& .MuiCardHeader-root': {
            padding: '22px 10px 0 20px'
        },
        '& .MuiCardContent-root': {
            padding: '16px 15px 10px 15px'
        }
    },
    simpleCardGroup: {
        width: '100%',
        display: 'flex',
        justifyContent: 'space-around',
    },
    card3: {
        height: '600px',
        padding: '0px',
        backgroundColor: 'var(--background-content)',
        borderRadius: '4px',
        width: '100%',
        margin: '8px',
        '& .MuiCardHeader-root': {
            padding: '22px 10px 0 20px'
        },
        '& .MuiCardContent-root': {
            padding: '16px 15px 10px 15px'
        }
    },
    table1: {
        marginLeft: '10px',
        width: '100%',
    },
    table2: {
        marginLeft: '-150px',
        marginTop: '70px',
        width: '100%',
    },
    table3: {
        marginLeft: '20px',
        marginTop: '-75px',
        width: '80%',
    },
    checkboxfield2: {
        height: 10,
        marginLeft: '60px',
        marginBottom: theme.spacing(0),
        marginTop: '40px',
    },
    checkboxfield3: {
        height: 10,
        marginLeft: '20px',
        marginBottom: '45px',
        marginTop: '40px',
        width: '100%',
    },
    input4: {
        width: '72%',
        fontSize: '14px',
        marginBottom: theme.spacing(1),
        marginLeft: theme.spacing(-15),
        textAlignLast: 'start'
    },
    formLabel2: {
        padding: "7px 7px 7px",
        width: '70%',
        fontSize: '14px',
        color: 'black',
        marginLeft: theme.spacing(1),
        marginBottom: theme.spacing(1),
    },
    border: {
        borderLeft: '1px solid black',
        borderRight: '1px solid black',
        borderBottom: '1px solid black',
        borderTop: '1px solid black',
        textAlign: 'center',
        backgroundColor: 'white',
        color: '#3F4756',
    },
    cardHeader: {
        marginTop: '-10px',
    },
    simpleCardGroup2: {
        display: 'flex',
        width: '50%',
        justifyContent: 'space-around',
    },
    simpleCardGroup3: {
        display: 'flex',
        width: '50%',
        justifyContent: 'space-around',
    },
    simpleCardGroup4: {
        width: '60%',
        display: 'flex',
        justifyContent: 'space-around',
    },
    simpleCardGroup5: {
        width: '40%',
        display: 'flex',
        justifyContent: 'space-around',
    },
});

const toInputUppercase = e => {
    e.target.value = ("" + e.target.value).toUpperCase();
};

const isChecked = (values, field) => {
    if (values.hasOwnProperty(field)) {
        if (typeof values[field] === 'string') {
            if (values[field] === 'Y' || values[field] === 'N') {
                return (values[field] === 'Y' ? 1 : 0)
            }
            return parseInt(values[field]);
        }
        if (typeof values[field] === 'boolean')
            return values[field];
    }
    else
        return false;
};

class CompanyControlFactors extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            fields: false,
            values: false,
            hasError: false,
            errorId: false,
            valueJobControlData: false,
            tabcards: false,
            valueCompanyOrderDetailData: this.props.companyOrderDetailData,
            precisionValue1: this.props.companyOrderDetailData.OCDECP.substring(0, 1),
            precisionValue2: this.props.companyOrderDetailData.OCDECP.substring(1, 2),
            precisionValue3: this.props.companyOrderDetailData.OCDECP.substring(2, 3),
            precisionValue4: this.props.companyOrderDetailData.OCDECP.substring(3, 4),
            precisionValue5: this.props.companyOrderDetailData.OCDECP.substring(4, 5),
            precisionValue6: this.props.companyOrderDetailData.OCDECP.substring(5, 6),
            precisionValue7: this.props.companyOrderDetailData.OCDECP.substring(6, 7),
            precisionValue8: this.props.companyOrderDetailData.OCDECP.substring(7),
            numericCheck1: this.props.companyOrderDetailData.OCNMRC.substring(0, 1),
            numericCheck2: this.props.companyOrderDetailData.OCNMRC.substring(1, 2),
            numericCheck3: this.props.companyOrderDetailData.OCNMRC.substring(2, 3),
            numericCheck4: this.props.companyOrderDetailData.OCNMRC.substring(3, 4),
            numericCheck5: this.props.companyOrderDetailData.OCNMRC.substring(4, 5),
            numericCheck6: this.props.companyOrderDetailData.OCNMRC.substring(5, 6),
            numericCheck7: this.props.companyOrderDetailData.OCNMRC.substring(6, 7),
            numericCheck8: this.props.companyOrderDetailData.OCNMRC.substring(7),
        };
        this.handleChangeValue = this.handleChangeValue.bind(this);
        this.handleChangeForm1 = this.handleChangeForm1.bind(this);
        this.handleChangeForm2 = this.handleChangeForm2.bind(this);
        this.handleChangeForm3 = this.handleChangeForm3.bind(this);
        this.handleChangeForm4 = this.handleChangeForm4.bind(this);
        this.handleChangeForm5 = this.handleChangeForm5.bind(this);
        this.handleChangeForm6 = this.handleChangeForm6.bind(this);
        this.handleChangeForm7 = this.handleChangeForm7.bind(this);
        this.handleChangeForm8 = this.handleChangeForm8.bind(this);
        this.handleChangeNC1 = this.handleChangeNC1.bind(this);
        this.handleChangeNC2 = this.handleChangeNC2.bind(this);
        this.handleChangeNC3 = this.handleChangeNC3.bind(this);
        this.handleChangeNC4 = this.handleChangeNC4.bind(this);
        this.handleChangeNC5 = this.handleChangeNC5.bind(this);
        this.handleChangeNC6 = this.handleChangeNC6.bind(this);
        this.handleChangeNC7 = this.handleChangeNC7.bind(this);
        this.handleChangeNC8 = this.handleChangeNC8.bind(this);
        this.handleChangeJobControlValue = this.handleChangeJobControlValue.bind(this);
    }

    handleChangeValue(key, val, field, setEnableDisable = true) {
        this.props.setSaveDataValue(true);
        if (val != null) {
            val = val.toUpperCase();
            this.props.setValueData({ key, val });
            if (field != undefined && (field.dataType == "checkbox" || field.dataType == 'select' || field.dataType == 'date')) {
                if (setEnableDisable) {
                    let tabsData = this.setFieldEnableDisable(key, val, field, this.state.tabcards);
                    this.setState({ tabcards: tabsData });
                }
            }
        }
    }

    handleChangeValueTable(key, val) {
        const { valueCompanyOrderDetailData } = this.state;
        if (val != undefined) {
            let temp = { ...valueCompanyOrderDetailData, [key]: val }
            this.setState({ valueCompanyOrderDetailData: temp });
        }
    }

    setFieldEnableDisable = (key, value, field, tabsData, isInitialLoad = false) => {
        const valueData = this.props.values.companyOrderControlChangedData;
        let valueDataUpdated = JSON.parse(JSON.stringify(valueData));
        valueDataUpdated = Object.assign({}, valueDataUpdated, { [key]: value });
        // fieldKey --- field changed
        // cardFieldKey --- field to be disabled
        let cardFieldKey, fieldKey = field[COLUMN_VALUE_ACCESSOR].trim();
        let tabcards = JSON.parse(JSON.stringify(tabsData));
        tabcards = tabcards.map(card => {
            card.cardfields = card.cardfields.map(cardField => {
                cardFieldKey = cardField[COLUMN_VALUE_ACCESSOR] ? cardField[COLUMN_VALUE_ACCESSOR].trim() : "";
                //  disabling enabling field for particular value
                if (fieldKey === 'VORCV' && cardFieldKey === 'VORCV') {
                    if (this.props.values.company['CPOSYS'] > 0) {
                        cardField['disabled'] = false;
                    } else {
                        cardField['disabled'] = true;
                    }
                }
                if (fieldKey === 'POACT' && cardFieldKey === 'POACT') {
                    if (this.props.values.company['CPOSYS'] > 0) {
                        cardField['disabled'] = false;
                    } else {
                        cardField['disabled'] = true;
                    }
                }
                return cardField;
            })
            return card;
        })
        return tabcards;
    }

    setValueDataOnFocutOut = (key, value, field) => {
        if (value != null) {
            let tabsData = this.setFieldEnableDisable(key, value, field, this.state.tabcards);
            this.setState({ tabcards: tabsData });
        }
    }

    setValueDataOnFocutOutJCF = (key, value, field) => {
        if (key == 'OCUPGL') {
            this.props.validProgramLibrary1({ "UCOMP": "E3T", "ULIB": value, "UPGM": "" });
        }
        if (key == 'OCUPGM') {
            this.props.validProgramLibrary2({ "UCOMP": "E3T", "ULIB": "", "UPGM": value });
        }
    }

    getValueData(valueData, newValueData) {
        if (Object.keys(valueData).length && Object.keys(newValueData).length &&
            (JSON.parse(JSON.stringify(valueData)) !== JSON.parse(JSON.stringify(newValueData)))) {
            return newValueData;
        }
        return valueData;
    }

    getJobControlValueData(valueData, newValueData) {
        if (this.state.valueJobControlData == false) {
            this.setState({ valueJobControlData: valueData });
        }
        if (Object.keys(valueData).length && Object.keys(newValueData).length &&
            (JSON.parse(JSON.stringify(valueData)) !== JSON.parse(JSON.stringify(newValueData)))) {
            return newValueData;
        }
        return valueData;
    }

    handleChangeJobControlValue(key, val, field) {
        this.props.setSaveDataValue(true);
        if (field.FDPRFX == '0') {
            if (key.includes("undefined")) {
                key = key.replace("undefined", "");
            }
            key = 'OC' + key;
        }
        let valueJobControlDataC = this.state.valueJobControlData
        this.props.setValueJobControlData({ key, val, valueJobControlDataC });
    }

    componentDidMount() {
        let tabsData = this.props.CompanyPropertiesData.poControlLabelsData.tabcards;
        let valueForm = this.props.values.companyOrderControlChangedData;
        tabsData.forEach(card => {
            card.cardfields.forEach(field => {
                if (field.key) {
                    tabsData = this.setFieldEnableDisable(field.key, valueForm[field.key], field, tabsData, true);
                    if (field.hasCheckbox) {
                        tabsData = this.setFieldEnableDisable(field.checkfieldJson.key, valueForm[field.checkfieldJson.key], field.checkfieldJson, tabsData, true);
                    }
                }
            })
        })
        this.setState({ tabcards: tabsData });
    }

    //E3C-30006, 6/29/21, Kumar:Start Modified part of function

    handleChangeForm1(field, value) {
        this.setState({
            precisionValue1: value,
        });
        const { valueCompanyOrderDetailData } = this.state;
        let changedValue1 = valueCompanyOrderDetailData.OCDECP;
        changedValue1 = this.setCharAt(changedValue1, 0, value);
        let temp = { ...valueCompanyOrderDetailData, ['OCDECP']: changedValue1 }
        this.setState({ valueCompanyOrderDetailData: temp });
    }

    handleChangeForm2(field, value) {
        this.setState({
            precisionValue2: value,
        });
        const { valueCompanyOrderDetailData } = this.state;
        let changedValue1 = valueCompanyOrderDetailData.OCDECP;
        changedValue1 = this.setCharAt(changedValue1, 1, value);
        let temp = { ...valueCompanyOrderDetailData, ['OCDECP']: changedValue1 }
        this.setState({ valueCompanyOrderDetailData: temp });
    }

    handleChangeForm3(field, value) {
        this.setState({
            precisionValue3: value,
        });
        const { valueCompanyOrderDetailData } = this.state;
        let changedValue1 = valueCompanyOrderDetailData.OCDECP;
        changedValue1 = this.setCharAt(changedValue1, 2, value);
        let temp = { ...valueCompanyOrderDetailData, ['OCDECP']: changedValue1 }
        this.setState({ valueCompanyOrderDetailData: temp });
    }

    handleChangeForm4(field, value) {
        this.setState({
            precisionValue4: value,
        });
        const { valueCompanyOrderDetailData } = this.state;
        let changedValue1 = valueCompanyOrderDetailData.OCDECP;
        changedValue1 = this.setCharAt(changedValue1, 3, value);
        let temp = { ...valueCompanyOrderDetailData, ['OCDECP']: changedValue1 }
        this.setState({ valueCompanyOrderDetailData: temp });
    }

    handleChangeForm5(field, value) {
        this.setState({
            precisionValue5: value,
        });
        const { valueCompanyOrderDetailData } = this.state;
        let changedValue1 = valueCompanyOrderDetailData.OCDECP;
        changedValue1 = this.setCharAt(changedValue1, 4, value);
        let temp = { ...valueCompanyOrderDetailData, ['OCDECP']: changedValue1 }
        this.setState({ valueCompanyOrderDetailData: temp });
    }

    handleChangeForm6(field, value) {
        this.setState({
            precisionValue6: value,
        });
        const { valueCompanyOrderDetailData } = this.state;
        let changedValue1 = valueCompanyOrderDetailData.OCDECP;
        changedValue1 = this.setCharAt(changedValue1, 5, value);
        let temp = { ...valueCompanyOrderDetailData, ['OCDECP']: changedValue1 }
        this.setState({ valueCompanyOrderDetailData: temp });
    }

    handleChangeForm7(field, value) {
        this.setState({
            precisionValue7: value,
        });
        const { valueCompanyOrderDetailData } = this.state;
        let changedValue1 = valueCompanyOrderDetailData.OCDECP;
        changedValue1 = this.setCharAt(changedValue1, 6, value);
        let temp = { ...valueCompanyOrderDetailData, ['OCDECP']: changedValue1 }
        this.setState({ valueCompanyOrderDetailData: temp });
    }

    handleChangeForm8(field, value) {
        this.setState({
            precisionValue8: value,
        });
        const { valueCompanyOrderDetailData } = this.state;
        let changedValue1 = valueCompanyOrderDetailData.OCDECP;
        changedValue1 = this.setCharAt(changedValue1, 7, value);
        let temp = { ...valueCompanyOrderDetailData, ['OCDECP']: changedValue1 }
        this.setState({ valueCompanyOrderDetailData: temp });
    }

    //E3C-30006, 6/29/21, Kumar:End Modified part of function

    setCharAt(str, index, chr) {
        str = str + ' '.repeat(8 - str.length);
        if (index > str.length - 1) return str;
        return str.substring(0, index) + chr + str.substring(index + 1);
    }

    handleChangeNC1(event) {
        const { valueCompanyOrderDetailData } = this.state;
        let changedValue1 = valueCompanyOrderDetailData.OCNMRC;
        changedValue1 = this.setCharAt(changedValue1, 0, event.target.checked == true ? 'Y' : 'N');
        this.setState({
            numericCheck1: event.target.checked == true ? 'Y' : 'N'
        });
        let changedValue2 = valueCompanyOrderDetailData.OCDECP;
        changedValue2 = this.setCharAt(changedValue2, 0, '0');
        let temp = { ...valueCompanyOrderDetailData, ['OCNMRC']: changedValue1, ['OCLEN1']: '0', ['OCDUS1']: '', ['OCDECP']: changedValue2 }
        this.setState({ valueCompanyOrderDetailData: temp });
        this.setState({ precisionValue1: 0 })
        this.props.setSaveDataValue(true);
    }

    handleChangeNC2(event) {
        const { valueCompanyOrderDetailData } = this.state;
        let changedValue1 = valueCompanyOrderDetailData.OCNMRC;
        changedValue1 = this.setCharAt(changedValue1, 1, event.target.checked == true ? 'Y' : 'N');
        this.setState({
            numericCheck2: event.target.checked == true ? 'Y' : 'N'
        });
        let changedValue2 = valueCompanyOrderDetailData.OCDECP;
        changedValue2 = this.setCharAt(changedValue2, 1, '0');
        let temp = { ...valueCompanyOrderDetailData, ['OCNMRC']: changedValue1, ['OCLEN2']: '0', ['OCDUS2']: '', ['OCDECP']: changedValue2 }
        this.setState({ valueCompanyOrderDetailData: temp });
        this.setState({ precisionValue2: 0 })
        this.props.setSaveDataValue(true);
    }

    handleChangeNC3(event) {
        const { valueCompanyOrderDetailData } = this.state;
        let changedValue1 = valueCompanyOrderDetailData.OCNMRC;
        changedValue1 = this.setCharAt(changedValue1, 2, event.target.checked == true ? 'Y' : 'N');
        this.setState({
            numericCheck3: event.target.checked == true ? 'Y' : 'N'
        });
        let changedValue2 = valueCompanyOrderDetailData.OCDECP;
        changedValue2 = this.setCharAt(changedValue2, 2, '0');
        let temp = { ...valueCompanyOrderDetailData, ['OCNMRC']: changedValue1, ['OCLEN3']: '0', ['OCDUS3']: '', ['OCDECP']: changedValue2 }
        this.setState({ valueCompanyOrderDetailData: temp });
        this.setState({ precisionValue3: 0 })
        this.props.setSaveDataValue(true);
    }

    handleChangeNC4(event) {
        const { valueCompanyOrderDetailData } = this.state;
        let changedValue1 = valueCompanyOrderDetailData.OCNMRC;
        changedValue1 = this.setCharAt(changedValue1, 3, event.target.checked == true ? 'Y' : 'N');
        this.setState({
            numericCheck4: event.target.checked == true ? 'Y' : 'N'
        });
        let changedValue2 = valueCompanyOrderDetailData.OCDECP;
        changedValue2 = this.setCharAt(changedValue2, 3, '0');
        let temp = { ...valueCompanyOrderDetailData, ['OCNMRC']: changedValue1, ['OCLEN4']: '0', ['OCDUS4']: '', ['OCDECP']: changedValue2 }
        this.setState({ valueCompanyOrderDetailData: temp });
        this.setState({ precisionValue4: 0 })
        this.props.setSaveDataValue(true);
    }

    handleChangeNC5(event) {
        const { valueCompanyOrderDetailData } = this.state;
        let changedValue1 = valueCompanyOrderDetailData.OCNMRC;
        changedValue1 = this.setCharAt(changedValue1, 4, event.target.checked == true ? 'Y' : 'N');
        this.setState({
            numericCheck5: event.target.checked == true ? 'Y' : 'N'
        });
        let changedValue2 = valueCompanyOrderDetailData.OCDECP;
        changedValue2 = this.setCharAt(changedValue2, 4, '0');
        let temp = { ...valueCompanyOrderDetailData, ['OCNMRC']: changedValue1, ['OCLEN5']: '0', ['OCDUS5']: '', ['OCDECP']: changedValue2 }
        this.setState({ valueCompanyOrderDetailData: temp });
        this.setState({ precisionValue5: 0 })
        this.props.setSaveDataValue(true);
    }

    handleChangeNC6(event) {
        const { valueCompanyOrderDetailData } = this.state;
        let changedValue1 = valueCompanyOrderDetailData.OCNMRC;
        changedValue1 = this.setCharAt(changedValue1, 5, event.target.checked == true ? 'Y' : 'N');
        this.setState({
            numericCheck6: event.target.checked == true ? 'Y' : 'N'
        });
        let changedValue2 = valueCompanyOrderDetailData.OCDECP;
        changedValue2 = this.setCharAt(changedValue2, 5, '0');
        let temp = { ...valueCompanyOrderDetailData, ['OCNMRC']: changedValue1, ['OCLEN6']: '0', ['OCDUS6']: '', ['OCDECP']: changedValue2 }
        this.setState({ valueCompanyOrderDetailData: temp });
        this.setState({ precisionValue6: 0 })
        this.props.setSaveDataValue(true);
    }

    handleChangeNC7(event) {
        const { valueCompanyOrderDetailData } = this.state;
        let changedValue1 = valueCompanyOrderDetailData.OCNMRC;
        changedValue1 = this.setCharAt(changedValue1, 6, event.target.checked == true ? 'Y' : 'N');
        this.setState({
            numericCheck7: event.target.checked == true ? 'Y' : 'N'
        });
        let changedValue2 = valueCompanyOrderDetailData.OCDECP;
        changedValue2 = this.setCharAt(changedValue2, 6, '0');
        let temp = { ...valueCompanyOrderDetailData, ['OCNMRC']: changedValue1, ['OCLEN7']: '0', ['OCDUS7']: '', ['OCDECP']: changedValue2 }
        this.setState({ valueCompanyOrderDetailData: temp });
        this.setState({ precisionValue7: 0 })
        this.props.setSaveDataValue(true);
    }

    handleChangeNC8(event) {
        const { valueCompanyOrderDetailData } = this.state;
        let changedValue1 = valueCompanyOrderDetailData.OCNMRC;
        changedValue1 = this.setCharAt(changedValue1, 7, event.target.checked == true ? 'Y' : 'N');
        this.setState({
            numericCheck8: event.target.checked == true ? 'Y' : 'N'
        });
        let changedValue2 = valueCompanyOrderDetailData.OCDECP;
        changedValue2 = this.setCharAt(changedValue2, 7, '0');
        let temp = { ...valueCompanyOrderDetailData, ['OCNMRC']: changedValue1, ['OCLEN8']: '0', ['OCDUS8']: '', ['OCDECP']: changedValue2 }
        this.setState({ valueCompanyOrderDetailData: temp });
        this.setState({ precisionValue8: 0 })
        this.props.setSaveDataValue(true);
    }

    getLabelValue(id) {
        return <FormattedMessageComponent id={id} />;
    }

    getMessageText = id => {
        const { messages } = this.props;
        if (messages && messages['H' + id]) {
            return messages['H' + id].TLLAB;
        }
        else return '';
    }

    render() {
        const { classes, handleChange, globalDateFormat, filterCriteriaDetails, pageFilterOptions,
            globalFilterOptions, columnDefs, currentPage, values, setSaveData } = this.props;
        const { loading, valueData, newValueData } = this.props.CompanyPropertiesData;
        const { tabcards, valueCompanyOrderDetailData } = this.state;
        const valueDataJobControl = values.companyOrderControlChangedData;
        const newValueDataJobControl = values.companyOrderControlChangedData;
        this.props.changePurchaseOrderControlsData(newValueData, values.companyUdfIDSFields, values.companyUdfOSSFields, valueCompanyOrderDetailData);
        // E3C-30006 , 8/25/21, Kumar:Start
        const descLabel = this.getMessageText('50805');
        const lengthLabel = this.getMessageText('33564');
        const precisionLabel = this.getMessageText('33588');
        const defaultLabel = this.getMessageText('50801');
        // E3C-30006 , 8/25/21, Kumar:End
        return (
            <div>
                {(!loading && tabcards && tabcards.length) ? (
                    <div className={classes.pageContainer}>
                        <Grid container item xs={12} >
                            <div className={classes.pageContainerSeventy}>
                                <div className={classes.simpleCardGroup}>
                                    {!loading && tabcards.map(formCard => {
                                        if (formCard.cardkey == JOB_CONTROL_FACTORS) {
                                            formCard.cardfields[4]['isCheckWildCard'] = false;
                                            formCard.cardfields[5]['isCheckWildCard'] = false;
                                            return <CardComponent title={formCard.cardtitle} className={classes.card}>
                                                <FormFieldsGenerator
                                                    cardHasDotsBtn={false}
                                                    cardHasCheckBox={false}
                                                    noMassMaintenance
                                                    labelDisplayCharacters={22}
                                                    valueDisplayCharacters={15}
                                                    handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                                                    key={formCard.cardkey}
                                                    parentPage={COMPANYS_LIST_PAGE}
                                                    className="JOB_CONTROL_FACTORS"
                                                    fieldsArray={formCard.cardfields}
                                                    valuesArray={this.getJobControlValueData(valueDataJobControl, newValueDataJobControl)}
                                                    handleChangeValue={(key, val, field) => this.handleChangeJobControlValue(key, val, field)}
                                                    enableAddButton={(e) => { setSaveData(e) }}
                                                    handleFocusOut={(key, val) => this.setValueDataOnFocutOutJCF(key, val)}
                                                    globalDateFormat={globalDateFormat}
                                                    filterCriteriaDetails={filterCriteriaDetails}
                                                    pageFilterOptions={pageFilterOptions}
                                                    globalFilterOptions={globalFilterOptions}
                                                    columnDefs={columnDefs}
                                                    currentPage={currentPage}
                                                    parentData={this.props.companyData}
                                                    canUpdateComponent={this.props.canUpdateComponent}
                                                />
                                            </CardComponent>
                                        }
                                    })}
                                    {!loading && tabcards.map(formCard => {
                                        if (formCard.cardkey == COMPANY_RECEIVING_FACTORS) {
                                            return <CardComponent title={formCard.cardtitle} className={classes.card}>
                                                <FormFieldsGenerator
                                                    cardHasDotsBtn={false}
                                                    cardHasCheckBox={false}
                                                    noMassMaintenance
                                                    labelDisplayCharacters={22}
                                                    valueDisplayCharacters={18}
                                                    handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                                                    key={formCard.cardkey}
                                                    parentPage={COMPANYS_LIST_PAGE}
                                                    className="COMPANY_RECEIVING_FACTORS"
                                                    fieldsArray={formCard.cardfields}
                                                    valuesArray={this.getValueData(valueData, newValueData)}
                                                    handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                                    enableAddButton={(e) => { setSaveData(e) }}
                                                    handleFocusOut={(key, val, field) => this.setValueDataOnFocutOut(key, val, field)}
                                                    globalDateFormat={globalDateFormat}
                                                    filterCriteriaDetails={filterCriteriaDetails}
                                                    pageFilterOptions={pageFilterOptions}
                                                    globalFilterOptions={globalFilterOptions}
                                                    columnDefs={columnDefs}
                                                    currentPage={currentPage}
                                                    parentData={this.props.companyData}
                                                    canUpdateComponent={this.props.canUpdateComponent}
                                                />
                                            </CardComponent>
                                        }
                                    })}
                                    {!loading && tabcards.map(formCard => {
                                        if (formCard.cardkey == PURCHASE_ORDER_FACTORS) {
                                            return <CardComponent title={formCard.cardtitle} className={classes.card}>
                                                <FormFieldsGenerator
                                                    cardHasDotsBtn={false}
                                                    cardHasCheckBox={false}
                                                    noMassMaintenance
                                                    labelDisplayCharacters={22}
                                                    valueDisplayCharacters={15}
                                                    handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                                                    key={formCard.cardkey}
                                                    parentPage={COMPANYS_LIST_PAGE}
                                                    className="PURCHASE_ORDER_FACTORS"
                                                    fieldsArray={formCard.cardfields}
                                                    valuesArray={this.getValueData(valueData, newValueData)}
                                                    handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                                    enableAddButton={(e) => { setSaveData(e) }}
                                                    handleFocusOut={(key, val, field) => this.setValueDataOnFocutOut(key, val, field)}
                                                    globalDateFormat={globalDateFormat}
                                                    filterCriteriaDetails={filterCriteriaDetails}
                                                    pageFilterOptions={pageFilterOptions}
                                                    globalFilterOptions={globalFilterOptions}
                                                    columnDefs={columnDefs}
                                                    currentPage={currentPage}
                                                    parentData={this.props.companyData}
                                                    canUpdateComponent={this.props.canUpdateComponent}
                                                />
                                            </CardComponent>
                                        }
                                    })}
                                </div>
                            </div>
                            <div className={classes.pageContainerSeventy}>
                                <Card className={classes.card3}>
                                    <CardHeader
                                        className={classes.cardHeader}
                                        title={this.getLabelValue(
                                            LABEL_COMPANY_UDF,
                                        )}
                                    />
                                    <Box display="flex">
                                        <FormLabel className={classes.formLabel2}>{this.getLabelValue(
                                            LABEL_COMPANY_OAF,
                                        )}</FormLabel>
                                    </Box>
                                    <div className={classes.pageContainerSeventy}>
                                        <div className={classes.simpleCardGroup4}>
                                            <Table className={classes.table1} aria-label="simple table">
                                                <TableHead>
                                                    <TableRow>
                                                        <TableCell className={classes.border} align="centre" width="25%">{this.getLabelValue(
                                                            LABEL_COMPANY_DESCRIPTION,
                                                        )}</TableCell>
                                                        <TableCell className={classes.border} align="centre" width="12%">{this.getLabelValue(
                                                            LABEL_COMPANY_NCF,
                                                        )}</TableCell>
                                                        <TableCell className={classes.border} align="centre" width="10%">{this.getLabelValue(
                                                            LABEL_COMPANY_LENGTH,
                                                        )}</TableCell>
                                                        <TableCell className={classes.border} align="centre" width="12%">{this.getLabelValue(
                                                            LABEL_COMPANY_PRECISION,
                                                        )}</TableCell>
                                                        <TableCell className={classes.border} align="centre" width="25%">{this.getLabelValue(
                                                            LABEL_COMPANY_DV,
                                                        )}</TableCell>
                                                    </TableRow>
                                                </TableHead>
                                                <TableBody>
                                                    <TableRow >
                                                        <TableCell className={classes.border} align="centre">
                                                            <FieldInput
                                                                className={classes.input4}
                                                                value={valueCompanyOrderDetailData.OCUSR1}
                                                                field={{ key: "OCUSR1" }}
                                                                isCheckWildCard={true}
                                                                toUppercase={true}
                                                                maxLength={30}
                                                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                                                                defaultValue={""}
                                                                onChange={(key, val) => this.handleChangeValueTable(key, val)}
                                                                enableAddButton={e => setSaveData(e)}
                                                                isColumnEditable={true}
                                                                globalDecimalSeparator={"."}
                                                                errorMessageLabel={descLabel} // E3C-30006 , 8/25/21, Kumar
                                                            />
                                                        </TableCell>
                                                        <TableCell className={classes.border} align="centre"><Checkbox disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                                                            onChange={this.handleChangeNC1} color={"primary"}
                                                            checked={this.state.numericCheck1 == 'Y'} />
                                                        </TableCell>
                                                        <TableCell className={classes.border} align="centre">
                                                            <FieldInput
                                                                className={classes.input4}
                                                                value={valueCompanyOrderDetailData.OCLEN1}
                                                                field={{ type: "number", key: "OCLEN1", Attr: ' ' }}
                                                                numberType={"integer"}
                                                                isCheckWildCard={true}
                                                                toUppercase={false}
                                                                maxLength={this.state.numericCheck1 == 'Y' ? 1 : 2}
                                                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                                                                minValue={this.state.numericCheck1 == 'Y' ? "0" : "00"}
                                                                maxValue={this.state.numericCheck1 == 'Y' ? 9 : 99}
                                                                isNegative={false}
                                                                precisionLength={0}
                                                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                                                enableAddButton={e => setSaveData(e)}
                                                                prefixFlag={1}
                                                                defaultValue={"0"}
                                                                onChange={(key, val) => this.handleChangeValueTable(key, val)}
                                                                isColumnEditable={true}
                                                                globalDecimalSeparator={"."}
                                                                errorMessageLabel={lengthLabel} // E3C-30006 , 8/25/21, Kumar
                                                            />
                                                        </TableCell>
                                                        {/*E3C-30006, 6/29/21, Kumar:Start */}
                                                        <TableCell className={classes.border} align="centre">
                                                            <FieldInput
                                                                className={classes.input4}
                                                                value={this.state.precisionValue1}
                                                                field={{ type: "number", Attr: ' ' }}
                                                                numberType={"integer"}
                                                                globalDecimalSeparator={"."}
                                                                isCheckWildCard={true}
                                                                toUppercase={false}
                                                                maxLength={1}
                                                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.numericCheck1 != 'Y' ? true : false}
                                                                minValue={"0"}
                                                                maxValue={valueCompanyOrderDetailData.OCLEN1}
                                                                isNegative={false}
                                                                precisionLength={0}
                                                                prefixFlag={1}
                                                                defaultValue={"0"}
                                                                onChange={(key, val) => this.handleChangeForm1(key, val)}
                                                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                                                enableAddButton={e => setSaveData(e)}
                                                                isColumnEditable={true}
                                                                errorMessageLabel={precisionLabel} // E3C-30006 , 8/25/21, Kumar
                                                            />
                                                        </TableCell>
                                                        {/*E3C-30006, 6/29/21, Kumar:End */}
                                                        <TableCell className={classes.border} align="centre">
                                                            <FieldInput
                                                                className={classes.input4}
                                                                value={valueCompanyOrderDetailData.OCDUS1}
                                                                field={{ type: this.state.numericCheck1 == 'Y' ? "number" : "text", key: "OCDUS1", Attr: ' ' }}
                                                                numberType={this.state.numericCheck1 == 'Y' && (this.state.precisionValue1 == 0 || this.state.precisionValue1 == ' ') ? "integer" : this.state.numericCheck1 == 'Y' && this.state.precisionValue1 > 0 ? "decimal" : "text"}
                                                                isCheckWildCard={true}
                                                                toUppercase={true}
                                                                maxLength={valueCompanyOrderDetailData.OCLEN1}
                                                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                                                                isNegative={false}
                                                                precisionLength={this.state.precisionValue1}
                                                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                                                enableAddButton={e => setSaveData(e)}
                                                                prefixFlag={1}
                                                                defaultValue={""}
                                                                onChange={(key, val) => this.handleChangeValueTable(key, val)}
                                                                isColumnEditable={true}
                                                                globalDecimalSeparator={"."}
                                                                errorMessageLabel={defaultLabel} // E3C-30006 , 8/25/21, Kumar
                                                            />
                                                        </TableCell>
                                                    </TableRow>
                                                    <TableRow >
                                                        <TableCell className={classes.border} align="centre">
                                                            <FieldInput
                                                                className={classes.input4}
                                                                value={valueCompanyOrderDetailData.OCUSR2}
                                                                field={{ key: "OCUSR2" }}
                                                                isCheckWildCard={true}
                                                                toUppercase={true}
                                                                maxLength={30}
                                                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                                                                defaultValue={""}
                                                                onChange={(key, val) => this.handleChangeValueTable(key, val)}
                                                                enableAddButton={e => setSaveData(e)}
                                                                isColumnEditable={true}
                                                                globalDecimalSeparator={"."}
                                                                errorMessageLabel={descLabel} // E3C-30006 , 8/25/21, Kumar
                                                            />
                                                        </TableCell>
                                                        <TableCell className={classes.border} align="centre"><Checkbox disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                                                            onChange={this.handleChangeNC2} color={"primary"}
                                                            checked={this.state.numericCheck2 == 'Y'} />
                                                        </TableCell>
                                                        <TableCell className={classes.border} align="centre">
                                                            <FieldInput
                                                                className={classes.input4}
                                                                value={valueCompanyOrderDetailData.OCLEN2}
                                                                field={{ type: "number", key: "OCLEN2", Attr: ' ' }}
                                                                numberType={"integer"}
                                                                isCheckWildCard={true}
                                                                toUppercase={false}
                                                                maxLength={this.state.numericCheck2 == 'Y' ? 1 : 2}
                                                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                                                                minValue={this.state.numericCheck2 == 'Y' ? "0" : "00"}
                                                                maxValue={this.state.numericCheck2 == 'Y' ? 9 : 99}
                                                                isNegative={false}
                                                                precisionLength={0}
                                                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                                                enableAddButton={e => setSaveData(e)}
                                                                prefixFlag={1}
                                                                defaultValue={"0"}
                                                                onChange={(key, val) => this.handleChangeValueTable(key, val)}
                                                                isColumnEditable={true}
                                                                globalDecimalSeparator={"."}
                                                                errorMessageLabel={lengthLabel}  // E3C-30006 , 8/25/21, Kumar
                                                            />
                                                        </TableCell>
                                                        {/*E3C-30006, 6/29/21, Kumar:Start */}
                                                        <TableCell className={classes.border} align="centre">
                                                            <FieldInput
                                                                className={classes.input4}
                                                                value={this.state.precisionValue2}
                                                                field={{ type: "number", Attr: ' ' }}
                                                                numberType={"integer"}
                                                                globalDecimalSeparator={"."}
                                                                isCheckWildCard={true}
                                                                toUppercase={false}
                                                                maxLength={1}
                                                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.numericCheck2 != 'Y' ? true : false}
                                                                minValue={"0"}
                                                                maxValue={valueCompanyOrderDetailData.OCLEN2}
                                                                isNegative={false}
                                                                precisionLength={0}
                                                                prefixFlag={1}
                                                                defaultValue={"0"}
                                                                onChange={(key, val) => this.handleChangeForm2(key, val)}
                                                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                                                enableAddButton={e => setSaveData(e)}
                                                                isColumnEditable={true}
                                                                errorMessageLabel={precisionLabel} // E3C-30006 , 8/25/21, Kumar
                                                            />
                                                        </TableCell>
                                                        {/*E3C-30006, 6/29/21, Kumar:End */}
                                                        <TableCell className={classes.border} align="centre">
                                                            <FieldInput
                                                                className={classes.input4}
                                                                value={valueCompanyOrderDetailData.OCDUS2}
                                                                field={{ type: this.state.numericCheck2 == 'Y' ? "number" : "text", key: "OCDUS2", Attr: ' ' }}
                                                                numberType={this.state.numericCheck2 == 'Y' && (this.state.precisionValue2 == 0 || this.state.precisionValue2 == ' ') ? "integer" : this.state.numericCheck2 == 'Y' && this.state.precisionValue2 > 0 ? "decimal" : "text"}
                                                                isCheckWildCard={true}
                                                                toUppercase={true}
                                                                maxLength={valueCompanyOrderDetailData.OCLEN2}
                                                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                                                                isNegative={false}
                                                                precisionLength={this.state.precisionValue2}
                                                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                                                enableAddButton={e => setSaveData(e)}
                                                                prefixFlag={1}
                                                                defaultValue={""}
                                                                onChange={(key, val) => this.handleChangeValueTable(key, val)}
                                                                isColumnEditable={true}
                                                                globalDecimalSeparator={"."}
                                                                errorMessageLabel={defaultLabel} // E3C-30006 , 8/25/21, Kumar
                                                            />
                                                        </TableCell>
                                                    </TableRow>
                                                    <TableRow >
                                                        <TableCell className={classes.border} align="centre">
                                                            <FieldInput
                                                                className={classes.input4}
                                                                value={valueCompanyOrderDetailData.OCUSR3}
                                                                field={{ key: "OCUSR3" }}
                                                                isCheckWildCard={true}
                                                                toUppercase={true}
                                                                maxLength={30}
                                                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                                                                defaultValue={""}
                                                                onChange={(key, val) => this.handleChangeValueTable(key, val)}
                                                                enableAddButton={e => setSaveData(e)}
                                                                isColumnEditable={true}
                                                                globalDecimalSeparator={"."}
                                                                errorMessageLabel={descLabel} // E3C-30006 , 8/25/21, Kumar
                                                            />
                                                        </TableCell>
                                                        <TableCell className={classes.border} align="centre"><Checkbox disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                                                            onChange={this.handleChangeNC3} color={"primary"}
                                                            checked={this.state.numericCheck3 == 'Y'} />
                                                        </TableCell>
                                                        <TableCell className={classes.border} align="centre">
                                                            <FieldInput
                                                                className={classes.input4}
                                                                value={valueCompanyOrderDetailData.OCLEN3}
                                                                field={{ type: "number", key: "OCLEN3", Attr: ' ' }}
                                                                numberType={"integer"}
                                                                isCheckWildCard={true}
                                                                toUppercase={false}
                                                                maxLength={this.state.numericCheck3 == 'Y' ? 1 : 2}
                                                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                                                                minValue={this.state.numericCheck3 == 'Y' ? "0" : "00"}
                                                                maxValue={this.state.numericCheck3 == 'Y' ? 9 : 99}
                                                                isNegative={false}
                                                                precisionLength={0}
                                                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                                                enableAddButton={e => setSaveData(e)}
                                                                prefixFlag={1}
                                                                defaultValue={"0"}
                                                                onChange={(key, val) => this.handleChangeValueTable(key, val)}
                                                                isColumnEditable={true}
                                                                globalDecimalSeparator={"."}
                                                                errorMessageLabel={lengthLabel} // E3C-30006 , 8/25/21, Kumar
                                                            />
                                                        </TableCell>
                                                        {/*E3C-30006, 6/29/21, Kumar:Start */}
                                                        <TableCell className={classes.border} align="centre">
                                                            <FieldInput
                                                                className={classes.input4}
                                                                value={this.state.precisionValue3}
                                                                field={{ type: "number", Attr: ' ' }}
                                                                numberType={"integer"}
                                                                globalDecimalSeparator={"."}
                                                                isCheckWildCard={true}
                                                                toUppercase={false}
                                                                maxLength={1}
                                                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.numericCheck3 != 'Y' ? true : false}
                                                                minValue={"0"}
                                                                maxValue={valueCompanyOrderDetailData.OCLEN3}
                                                                isNegative={false}
                                                                precisionLength={0}
                                                                prefixFlag={1}
                                                                defaultValue={"0"}
                                                                onChange={(key, val) => this.handleChangeForm3(key, val)}
                                                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                                                enableAddButton={e => setSaveData(e)}
                                                                isColumnEditable={true}
                                                                errorMessageLabel={precisionLabel} // E3C-30006 , 8/25/21, Kumar
                                                            />
                                                        </TableCell>
                                                        {/*E3C-30006, 6/29/21, Kumar:End */}
                                                        <TableCell className={classes.border} align="centre">
                                                            <FieldInput
                                                                className={classes.input4}
                                                                value={valueCompanyOrderDetailData.OCDUS3}
                                                                field={{ type: this.state.numericCheck3 == 'Y' ? "number" : "text", key: "OCDUS3", Attr: ' ' }}
                                                                numberType={this.state.numericCheck3 == 'Y' && (this.state.precisionValue3 == 0 || this.state.precisionValue3 == ' ') ? "integer" : this.state.numericCheck3 == 'Y' && this.state.precisionValue3 > 0 ? "decimal" : "text"}
                                                                isCheckWildCard={true}
                                                                toUppercase={true}
                                                                maxLength={valueCompanyOrderDetailData.OCLEN3}
                                                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                                                                isNegative={false}
                                                                precisionLength={this.state.precisionValue3}
                                                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                                                enableAddButton={e => setSaveData(e)}
                                                                prefixFlag={1}
                                                                defaultValue={""}
                                                                onChange={(key, val) => this.handleChangeValueTable(key, val)}
                                                                isColumnEditable={true}
                                                                globalDecimalSeparator={"."}
                                                                errorMessageLabel={defaultLabel} // E3C-30006 , 8/25/21, Kumar
                                                            />
                                                        </TableCell>
                                                    </TableRow>
                                                    <TableRow >
                                                        <TableCell className={classes.border} align="centre">
                                                            <FieldInput
                                                                className={classes.input4}
                                                                value={valueCompanyOrderDetailData.OCUSR4}
                                                                field={{ key: "OCUSR4" }}
                                                                isCheckWildCard={true}
                                                                toUppercase={true}
                                                                maxLength={30}
                                                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                                                                defaultValue={""}
                                                                onChange={(key, val) => this.handleChangeValueTable(key, val)}
                                                                enableAddButton={e => setSaveData(e)}
                                                                isColumnEditable={true}
                                                                globalDecimalSeparator={"."}
                                                                errorMessageLabel={descLabel} // E3C-30006 , 8/25/21, Kumar
                                                            />
                                                        </TableCell>
                                                        <TableCell className={classes.border} align="centre"><Checkbox disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                                                            onChange={this.handleChangeNC4} color={"primary"}
                                                            checked={this.state.numericCheck4 == 'Y'} />
                                                        </TableCell>
                                                        <TableCell className={classes.border} align="centre">
                                                            <FieldInput
                                                                className={classes.input4}
                                                                value={valueCompanyOrderDetailData.OCLEN4}
                                                                field={{ type: "number", key: "OCLEN4", Attr: ' ' }}
                                                                numberType={"integer"}
                                                                isCheckWildCard={true}
                                                                toUppercase={false}
                                                                maxLength={this.state.numericCheck4 == 'Y' ? 1 : 2}
                                                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                                                                minValue={this.state.numericCheck4 == 'Y' ? "0" : "00"}
                                                                maxValue={this.state.numericCheck4 == 'Y' ? 9 : 99}
                                                                isNegative={false}
                                                                precisionLength={0}
                                                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                                                enableAddButton={e => setSaveData(e)}
                                                                prefixFlag={1}
                                                                defaultValue={"0"}
                                                                onChange={(key, val) => this.handleChangeValueTable(key, val)}
                                                                isColumnEditable={true}
                                                                globalDecimalSeparator={"."}
                                                                errorMessageLabel={lengthLabel} // E3C-30006 , 8/25/21, Kumar
                                                            />
                                                        </TableCell>
                                                        {/*E3C-30006, 6/29/21, Kumar:Start */}
                                                        <TableCell className={classes.border} align="centre">
                                                            <FieldInput
                                                                className={classes.input4}
                                                                value={this.state.precisionValue4}
                                                                field={{ type: "number", Attr: ' ' }}
                                                                numberType={"integer"}
                                                                globalDecimalSeparator={"."}
                                                                isCheckWildCard={true}
                                                                toUppercase={false}
                                                                maxLength={1}
                                                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.numericCheck4 != 'Y' ? true : false}
                                                                minValue={"0"}
                                                                maxValue={valueCompanyOrderDetailData.OCLEN4}
                                                                isNegative={false}
                                                                precisionLength={0}
                                                                prefixFlag={1}
                                                                defaultValue={"0"}
                                                                onChange={(key, val) => this.handleChangeForm4(key, val)}
                                                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                                                enableAddButton={e => setSaveData(e)}
                                                                isColumnEditable={true}
                                                                errorMessageLabel={precisionLabel}
                                                            />
                                                        </TableCell>
                                                        {/*E3C-30006, 6/29/21, Kumar:End */}
                                                        <TableCell className={classes.border} align="centre">
                                                            <FieldInput
                                                                className={classes.input4}
                                                                value={valueCompanyOrderDetailData.OCDUS4}
                                                                field={{ type: this.state.numericCheck4 == 'Y' ? "number" : "text", key: "OCDUS4", Attr: ' ' }}
                                                                numberType={this.state.numericCheck4 == 'Y' && (this.state.precisionValue4 == 0 || this.state.precisionValue4 == ' ') ? "integer" : this.state.numericCheck4 == 'Y' && this.state.precisionValue4 > 0 ? "decimal" : "text"}
                                                                isCheckWildCard={true}
                                                                toUppercase={true}
                                                                maxLength={valueCompanyOrderDetailData.OCLEN4}
                                                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                                                                isNegative={false}
                                                                precisionLength={this.state.precisionValue4}
                                                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                                                enableAddButton={e => setSaveData(e)}
                                                                prefixFlag={1}
                                                                defaultValue={""}
                                                                onChange={(key, val) => this.handleChangeValueTable(key, val)}
                                                                isColumnEditable={true}
                                                                globalDecimalSeparator={"."}
                                                                errorMessageLabel={defaultLabel}
                                                            />
                                                        </TableCell>
                                                    </TableRow>
                                                    <TableRow >
                                                        <TableCell className={classes.border} align="centre">
                                                            <FieldInput
                                                                className={classes.input4}
                                                                value={valueCompanyOrderDetailData.OCUSR5}
                                                                field={{ key: "OCUSR5" }}
                                                                isCheckWildCard={true}
                                                                toUppercase={true}
                                                                maxLength={30}
                                                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                                                                defaultValue={""}
                                                                onChange={(key, val) => this.handleChangeValueTable(key, val)}
                                                                enableAddButton={e => setSaveData(e)}
                                                                isColumnEditable={true}
                                                                globalDecimalSeparator={"."}
                                                                errorMessageLabel={descLabel} // E3C-30006 , 8/25/21, Kumar
                                                            />
                                                        </TableCell>
                                                        <TableCell className={classes.border} align="centre"><Checkbox disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                                                            onChange={this.handleChangeNC5} color={"primary"}
                                                            checked={this.state.numericCheck5 == 'Y'} />
                                                        </TableCell>
                                                        <TableCell className={classes.border} align="centre">
                                                            <FieldInput
                                                                className={classes.input4}
                                                                value={valueCompanyOrderDetailData.OCLEN5}
                                                                field={{ type: "number", key: "OCLEN5", Attr: ' ' }}
                                                                numberType={"integer"}
                                                                isCheckWildCard={true}
                                                                toUppercase={false}
                                                                maxLength={this.state.numericCheck5 == 'Y' ? 1 : 2}
                                                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                                                                minValue={this.state.numericCheck5 == 'Y' ? "0" : "00"}
                                                                maxValue={this.state.numericCheck5 == 'Y' ? 9 : 99}
                                                                isNegative={false}
                                                                precisionLength={0}
                                                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                                                enableAddButton={e => setSaveData(e)}
                                                                prefixFlag={1}
                                                                defaultValue={"0"}
                                                                onChange={(key, val) => this.handleChangeValueTable(key, val)}
                                                                isColumnEditable={true}
                                                                globalDecimalSeparator={"."}
                                                                errorMessageLabel={lengthLabel} // E3C-30006 , 8/25/21, Kumar
                                                            />
                                                        </TableCell>
                                                        {/*E3C-30006, 6/29/21, Kumar:Start */}
                                                        <TableCell className={classes.border} align="centre">
                                                            <FieldInput
                                                                className={classes.input4}
                                                                value={this.state.precisionValue5}
                                                                field={{ type: "number", Attr: ' ' }}
                                                                numberType={"integer"}
                                                                globalDecimalSeparator={"."}
                                                                isCheckWildCard={true}
                                                                toUppercase={false}
                                                                maxLength={1}
                                                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.numericCheck5 != 'Y' ? true : false}
                                                                minValue={"0"}
                                                                maxValue={valueCompanyOrderDetailData.OCLEN5}
                                                                isNegative={false}
                                                                precisionLength={0}
                                                                prefixFlag={1}
                                                                defaultValue={"0"}
                                                                onChange={(key, val) => this.handleChangeForm5(key, val)}
                                                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                                                enableAddButton={e => setSaveData(e)}
                                                                isColumnEditable={true}
                                                                errorMessageLabel={precisionLabel} // E3C-30006 , 8/25/21, Kumar
                                                            />
                                                        </TableCell>
                                                        {/*E3C-30006, 6/29/21, Kumar:End */}
                                                        <TableCell className={classes.border} align="centre">
                                                            <FieldInput
                                                                className={classes.input4}
                                                                value={valueCompanyOrderDetailData.OCDUS5}
                                                                field={{ type: this.state.numericCheck5 == 'Y' ? "number" : "text", key: "OCDUS5", Attr: ' ' }}
                                                                numberType={this.state.numericCheck5 == 'Y' && (this.state.precisionValue5 == 0 || this.state.precisionValue5 == ' ') ? "integer" : this.state.numericCheck5 == 'Y' && this.state.precisionValue5 > 0 ? "decimal" : "text"}
                                                                isCheckWildCard={true}
                                                                toUppercase={true}
                                                                maxLength={valueCompanyOrderDetailData.OCLEN5}
                                                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                                                                isNegative={false}
                                                                precisionLength={this.state.precisionValue5}
                                                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                                                enableAddButton={e => setSaveData(e)}
                                                                prefixFlag={1}
                                                                defaultValue={""}
                                                                onChange={(key, val) => this.handleChangeValueTable(key, val)}
                                                                isColumnEditable={true}
                                                                globalDecimalSeparator={"."}
                                                                errorMessageLabel={defaultLabel} // E3C-30006 , 8/25/21, Kumar
                                                            />
                                                        </TableCell>
                                                    </TableRow>
                                                    <TableRow >
                                                        <TableCell className={classes.border} align="centre">
                                                            <FieldInput
                                                                className={classes.input4}
                                                                value={valueCompanyOrderDetailData.OCUSR6}
                                                                field={{ key: "OCUSR6" }}
                                                                isCheckWildCard={true}
                                                                toUppercase={true}
                                                                maxLength={30}
                                                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                                                                defaultValue={""}
                                                                onChange={(key, val) => this.handleChangeValueTable(key, val)}
                                                                enableAddButton={e => setSaveData(e)}
                                                                isColumnEditable={true}
                                                                globalDecimalSeparator={"."}
                                                                errorMessageLabel={descLabel} // E3C-30006 , 8/25/21, Kumar
                                                            />
                                                        </TableCell>
                                                        <TableCell className={classes.border} align="centre"><Checkbox disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                                                            onChange={this.handleChangeNC6} color={"primary"}
                                                            checked={this.state.numericCheck6 == 'Y'} />
                                                        </TableCell>
                                                        <TableCell className={classes.border} align="centre">
                                                            <FieldInput
                                                                className={classes.input4}
                                                                value={valueCompanyOrderDetailData.OCLEN6}
                                                                field={{ type: "number", key: "OCLEN6", Attr: ' ' }}
                                                                numberType={"integer"}
                                                                isCheckWildCard={true}
                                                                toUppercase={false}
                                                                maxLength={this.state.numericCheck6 == 'Y' ? 1 : 2}
                                                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                                                                minValue={this.state.numericCheck6 == 'Y' ? "0" : "00"}
                                                                maxValue={this.state.numericCheck6 == 'Y' ? 9 : 99}
                                                                isNegative={false}
                                                                precisionLength={0}
                                                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                                                enableAddButton={e => setSaveData(e)}
                                                                prefixFlag={1}
                                                                defaultValue={"0"}
                                                                onChange={(key, val) => this.handleChangeValueTable(key, val)}
                                                                isColumnEditable={true}
                                                                globalDecimalSeparator={"."}
                                                                errorMessageLabel={lengthLabel} // E3C-30006 , 8/25/21, Kumar
                                                            />
                                                        </TableCell>
                                                        {/*E3C-30006, 6/29/21, Kumar:Start */}
                                                        <TableCell className={classes.border} align="centre">
                                                            <FieldInput
                                                                className={classes.input4}
                                                                value={this.state.precisionValue6}
                                                                field={{ type: "number", Attr: ' ' }}
                                                                numberType={"integer"}
                                                                globalDecimalSeparator={"."}
                                                                isCheckWildCard={true}
                                                                toUppercase={false}
                                                                maxLength={1}
                                                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.numericCheck6 != 'Y' ? true : false}
                                                                minValue={"0"}
                                                                maxValue={valueCompanyOrderDetailData.OCLEN6}
                                                                isNegative={false}
                                                                precisionLength={0}
                                                                prefixFlag={1}
                                                                defaultValue={"0"}
                                                                onChange={(key, val) => this.handleChangeForm6(key, val)}
                                                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                                                enableAddButton={e => setSaveData(e)}
                                                                isColumnEditable={true}
                                                                errorMessageLabel={precisionLabel} // E3C-30006 , 8/25/21, Kumar
                                                            />
                                                        </TableCell>
                                                        {/*E3C-30006, 6/29/21, Kumar:End */}
                                                        <TableCell className={classes.border} align="centre">
                                                            <FieldInput
                                                                className={classes.input4}
                                                                value={valueCompanyOrderDetailData.OCDUS6}
                                                                field={{ type: this.state.numericCheck6 == 'Y' ? "number" : "text", key: "OCDUS6", Attr: ' ' }}
                                                                numberType={this.state.numericCheck6 == 'Y' && (this.state.precisionValue6 == 0 || this.state.precisionValue6 == ' ') ? "integer" : this.state.numericCheck6 == 'Y' && this.state.precisionValue6 > 0 ? "decimal" : "text"}
                                                                isCheckWildCard={true}
                                                                toUppercase={true}
                                                                maxLength={valueCompanyOrderDetailData.OCLEN6}
                                                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                                                                isNegative={false}
                                                                precisionLength={this.state.precisionValue6}
                                                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                                                enableAddButton={e => setSaveData(e)}
                                                                prefixFlag={1}
                                                                defaultValue={""}
                                                                onChange={(key, val) => this.handleChangeValueTable(key, val)}
                                                                isColumnEditable={true}
                                                                globalDecimalSeparator={"."}
                                                                errorMessageLabel={defaultLabel}
                                                            />
                                                        </TableCell>
                                                    </TableRow>
                                                    <TableRow >
                                                        <TableCell className={classes.border} align="centre">
                                                            <FieldInput
                                                                className={classes.input4}
                                                                value={valueCompanyOrderDetailData.OCUSR7}
                                                                field={{ key: "OCUSR7" }}
                                                                isCheckWildCard={true}
                                                                toUppercase={true}
                                                                maxLength={30}
                                                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                                                                defaultValue={""}
                                                                onChange={(key, val) => this.handleChangeValueTable(key, val)}
                                                                enableAddButton={e => setSaveData(e)}
                                                                isColumnEditable={true}
                                                                globalDecimalSeparator={"."}
                                                                errorMessageLabel={descLabel} // E3C-30006 , 8/25/21, Kumar
                                                            />
                                                        </TableCell>
                                                        <TableCell className={classes.border} align="centre"><Checkbox disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                                                            onChange={this.handleChangeNC7} color={"primary"}
                                                            checked={this.state.numericCheck7 == 'Y'} />
                                                        </TableCell>
                                                        <TableCell className={classes.border} align="centre">
                                                            <FieldInput
                                                                className={classes.input4}
                                                                value={valueCompanyOrderDetailData.OCLEN7}
                                                                field={{ type: "number", key: "OCLEN7", Attr: ' ' }}
                                                                numberType={"integer"}
                                                                isCheckWildCard={true}
                                                                toUppercase={false}
                                                                maxLength={this.state.numericCheck7 == 'Y' ? 1 : 2}
                                                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                                                                minValue={this.state.numericCheck7 == 'Y' ? "0" : "00"}
                                                                maxValue={this.state.numericCheck7 == 'Y' ? 9 : 99}
                                                                isNegative={false}
                                                                precisionLength={0}
                                                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                                                enableAddButton={e => setSaveData(e)}
                                                                prefixFlag={1}
                                                                defaultValue={"0"}
                                                                onChange={(key, val) => this.handleChangeValueTable(key, val)}
                                                                isColumnEditable={true}
                                                                globalDecimalSeparator={"."}
                                                                errorMessageLabel={lengthLabel} // E3C-30006 , 8/25/21, Kumar
                                                            />
                                                        </TableCell>
                                                        {/*E3C-30006, 6/29/21, Kumar:Start */}
                                                        <TableCell className={classes.border} align="centre">
                                                            <FieldInput
                                                                className={classes.input4}
                                                                value={this.state.precisionValue7}
                                                                field={{ type: "number", Attr: ' ' }}
                                                                numberType={"integer"}
                                                                globalDecimalSeparator={"."}
                                                                isCheckWildCard={true}
                                                                toUppercase={false}
                                                                maxLength={1}
                                                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.numericCheck7 != 'Y' ? true : false}
                                                                minValue={"0"}
                                                                maxValue={valueCompanyOrderDetailData.OCLEN7}
                                                                isNegative={false}
                                                                precisionLength={0}
                                                                prefixFlag={1}
                                                                defaultValue={"0"}
                                                                onChange={(key, val) => this.handleChangeForm7(key, val)}
                                                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                                                enableAddButton={e => setSaveData(e)}
                                                                isColumnEditable={true}
                                                                errorMessageLabel={precisionLabel}
                                                            />
                                                        </TableCell>
                                                        {/*E3C-30006, 6/29/21, Kumar:End */}
                                                        <TableCell className={classes.border} align="centre">
                                                            <FieldInput
                                                                className={classes.input4}
                                                                value={valueCompanyOrderDetailData.OCDUS7}
                                                                field={{ type: this.state.numericCheck7 == 'Y' ? "number" : "text", key: "OCDUS7", Attr: ' ' }}
                                                                numberType={this.state.numericCheck7 == 'Y' && (this.state.precisionValue7 == 0 || this.state.precisionValue7 == ' ') ? "integer" : this.state.numericCheck7 == 'Y' && this.state.precisionValue7 > 0 ? "decimal" : "text"}
                                                                isCheckWildCard={true}
                                                                toUppercase={true}
                                                                maxLength={valueCompanyOrderDetailData.OCLEN7}
                                                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                                                                isNegative={false}
                                                                precisionLength={this.state.precisionValue7}
                                                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                                                enableAddButton={e => setSaveData(e)}
                                                                prefixFlag={1}
                                                                defaultValue={""}
                                                                onChange={(key, val) => this.handleChangeValueTable(key, val)}
                                                                isColumnEditable={true}
                                                                globalDecimalSeparator={"."}
                                                                errorMessageLabel={defaultLabel}
                                                            />
                                                        </TableCell>
                                                    </TableRow>
                                                    <TableRow >
                                                        <TableCell className={classes.border} align="centre">
                                                            <FieldInput
                                                                className={classes.input4}
                                                                value={valueCompanyOrderDetailData.OCUSR8}
                                                                field={{ key: "OCUSR8" }}
                                                                isCheckWildCard={true}
                                                                toUppercase={true}
                                                                maxLength={30}
                                                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                                                                defaultValue={""}
                                                                onChange={(key, val) => this.handleChangeValueTable(key, val)}
                                                                enableAddButton={e => setSaveData(e)}
                                                                isColumnEditable={true}
                                                                globalDecimalSeparator={"."}
                                                                errorMessageLabel={descLabel} // E3C-30006 , 8/25/21, Kumar
                                                            />
                                                        </TableCell>
                                                        <TableCell className={classes.border} align="centre"><Checkbox disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                                                            onChange={this.handleChangeNC8} color={"primary"}
                                                            checked={this.state.numericCheck8 == 'Y'} />
                                                        </TableCell>
                                                        <TableCell className={classes.border} align="centre">
                                                            <FieldInput
                                                                className={classes.input4}
                                                                value={valueCompanyOrderDetailData.OCLEN8}
                                                                field={{ type: "number", key: "OCLEN8", Attr: ' ' }}
                                                                numberType={"integer"}
                                                                isCheckWildCard={true}
                                                                toUppercase={false}
                                                                maxLength={this.state.numericCheck8 == 'Y' ? 1 : 2}
                                                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                                                                minValue={this.state.numericCheck8 == 'Y' ? "0" : "00"}
                                                                maxValue={this.state.numericCheck8 == 'Y' ? 9 : 99}
                                                                isNegative={false}
                                                                precisionLength={0}
                                                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                                                enableAddButton={e => setSaveData(e)}
                                                                prefixFlag={1}
                                                                defaultValue={"0"}
                                                                onChange={(key, val) => this.handleChangeValueTable(key, val)}
                                                                isColumnEditable={true}
                                                                globalDecimalSeparator={"."}
                                                                errorMessageLabel={lengthLabel} // E3C-30006 , 8/25/21, Kumar
                                                            />
                                                        </TableCell>
                                                        {/*E3C-30006, 6/29/21, Kumar:Start */}
                                                        <TableCell className={classes.border} align="centre">
                                                            <FieldInput
                                                                className={classes.input4}
                                                                value={this.state.precisionValue8}
                                                                field={{ type: "number", Attr: ' ' }}
                                                                numberType={"integer"}
                                                                globalDecimalSeparator={"."}
                                                                isCheckWildCard={true}
                                                                toUppercase={false}
                                                                maxLength={1}
                                                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : this.state.numericCheck8 != 'Y' ? true : false}
                                                                minValue={"0"}
                                                                maxValue={valueCompanyOrderDetailData.OCLEN8}
                                                                isNegative={false}
                                                                precisionLength={0}
                                                                prefixFlag={1}
                                                                defaultValue={"0"}
                                                                onChange={(key, val) => this.handleChangeForm8(key, val)}
                                                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                                                enableAddButton={e => setSaveData(e)}
                                                                isColumnEditable={true}
                                                                errorMessageLabel={precisionLabel} // E3C-30006 , 8/25/21, Kumar
                                                            />
                                                        </TableCell>
                                                        {/*E3C-30006, 6/29/21, Kumar:End */}
                                                        <TableCell className={classes.border} align="centre">
                                                            <FieldInput
                                                                className={classes.input4}
                                                                value={valueCompanyOrderDetailData.OCDUS8}
                                                                field={{ type: this.state.numericCheck8 == 'Y' ? "number" : "text", key: "OCDUS8", Attr: ' ' }}
                                                                numberType={this.state.numericCheck8 == 'Y' && (this.state.precisionValue8 == 0 || this.state.precisionValue8 == ' ') ? "integer" : this.state.numericCheck8 == 'Y' && this.state.precisionValue8 > 0 ? "decimal" : "text"}
                                                                isCheckWildCard={true}
                                                                toUppercase={true}
                                                                maxLength={valueCompanyOrderDetailData.OCLEN8}
                                                                disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                                                                isNegative={false}
                                                                precisionLength={this.state.precisionValue8}
                                                                onBlurMinValidate={(obj) => setSaveData(obj.isMinMaxConditionValid)}
                                                                enableAddButton={e => setSaveData(e)}
                                                                prefixFlag={1}
                                                                defaultValue={""}
                                                                onChange={(key, val) => this.handleChangeValueTable(key, val)}
                                                                isColumnEditable={true}
                                                                globalDecimalSeparator={"."}
                                                                errorMessageLabel={defaultLabel} // E3C-30006 , 8/25/21, Kumar
                                                            />
                                                        </TableCell>
                                                    </TableRow>
                                                </TableBody>
                                            </Table>
                                        </div>
                                        <div className={classes.simpleCardGroup5}>
                                            <div className={classes.pageContainerSeventy}>
                                                <div className={classes.simpleCardGroup2}>
                                                    <FormControlLabel
                                                        control={<Checkbox disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                                                            name='company.CCSOSW' onChange={handleChange} onBlur={this.handleChangeValue} color={"primary"}
                                                            checked={isChecked(values.company, 'CCSOSW')} />}
                                                        label={this.getLabelValue(
                                                            LABEL_COMPANY_UOSF,
                                                        )}
                                                        labelPlacement='start'
                                                        className={classes.checkboxfield2}
                                                    />
                                                    <Table className={classes.table2} aria-label="simple table">
                                                        <TableHead>
                                                            <TableRow>
                                                                <TableCell className={classes.border} align="centre" width="10%">{this.getLabelValue(
                                                                    LABEL_COMPANY_DESCRIPTION,
                                                                )}</TableCell>
                                                            </TableRow>
                                                        </TableHead>
                                                        <TableBody>
                                                            <TableRow >
                                                                <TableCell className={classes.border} align="centre"><Input disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false} name='companyUdfOSSFields.ORTXT1' onChange={handleChange} onInput={toInputUppercase} onBlur={this.handleChangeValue} className={classes.input4} value={values.companyUdfOSSFields.ORTXT1} /></TableCell>
                                                            </TableRow>
                                                            <TableRow>
                                                                <TableCell className={classes.border} align="centre"><Input disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false} name='companyUdfOSSFields.ORTXT2' onChange={handleChange} onInput={toInputUppercase} onBlur={this.handleChangeValue} className={classes.input4} value={values.companyUdfOSSFields.ORTXT2} /></TableCell>
                                                            </TableRow>
                                                            <TableRow>
                                                                <TableCell className={classes.border} align="centre"><Input disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false} name='companyUdfOSSFields.ORTXT3' onChange={handleChange} onInput={toInputUppercase} onBlur={this.handleChangeValue} className={classes.input4} value={values.companyUdfOSSFields.ORTXT3} /></TableCell>
                                                            </TableRow>
                                                            <TableRow>
                                                                <TableCell className={classes.border} align="centre"><Input disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false} name='companyUdfOSSFields.ORTXT4' onChange={handleChange} onInput={toInputUppercase} onBlur={this.handleChangeValue} className={classes.input4} value={values.companyUdfOSSFields.ORTXT4} /></TableCell>
                                                            </TableRow>
                                                            <TableRow>
                                                                <TableCell className={classes.border} align="centre"><Input disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false} name='companyUdfOSSFields.ORTXT5' onChange={handleChange} onInput={toInputUppercase} onBlur={this.handleChangeValue} className={classes.input4} value={values.companyUdfOSSFields.ORTXT5} /></TableCell>
                                                            </TableRow>
                                                            <TableRow>
                                                                <TableCell className={classes.border} align="centre"><Input disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false} name='companyUdfOSSFields.ORTXT6' onChange={handleChange} onInput={toInputUppercase} onBlur={this.handleChangeValue} className={classes.input4} value={values.companyUdfOSSFields.ORTXT6} /></TableCell>
                                                            </TableRow>
                                                        </TableBody>
                                                    </Table>

                                                </div>
                                                <div className={classes.simpleCardGroup3}>
                                                    <div className={classes.pageContainerSeventy1}>
                                                        <FormControlLabel
                                                            control={<Checkbox disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false}
                                                                name='company.CCSTSW' onChange={handleChange} onBlur={this.handleChangeValue} color={"primary"}
                                                                checked={isChecked(values.company, 'CCSTSW')} />}
                                                            label={this.getLabelValue(
                                                                LABEL_COMPANY_UIDF,
                                                            )}
                                                            labelPlacement='start'
                                                            className={classes.checkboxfield3}
                                                        />
                                                        <Table className={classes.table3} aria-label="simple table">
                                                            <TableHead>
                                                                <TableRow>
                                                                    <TableCell className={classes.border} align="centre" width="10%">{this.getLabelValue(
                                                                        LABEL_COMPANY_DESCRIPTION,
                                                                    )}</TableCell>
                                                                </TableRow>
                                                            </TableHead>
                                                            <TableBody>
                                                                <TableRow >
                                                                    <TableCell className={classes.border} align="centre"><Input disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false} name='companyUdfIDSFields.UTXT01' onChange={handleChange} onInput={toInputUppercase} onBlur={this.handleChangeValue} className={classes.input4} value={values.companyUdfIDSFields.UTXT01} /></TableCell>
                                                                </TableRow>
                                                                <TableRow>
                                                                    <TableCell className={classes.border} align="centre"><Input disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false} name='companyUdfIDSFields.UTXT02' onChange={handleChange} onInput={toInputUppercase} onBlur={this.handleChangeValue} className={classes.input4} value={values.companyUdfIDSFields.UTXT02} /></TableCell>
                                                                </TableRow>
                                                                <TableRow>
                                                                    <TableCell className={classes.border} align="centre"><Input disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false} name='companyUdfIDSFields.UTXT03' onChange={handleChange} onInput={toInputUppercase} onBlur={this.handleChangeValue} className={classes.input4} value={values.companyUdfIDSFields.UTXT03} /></TableCell>
                                                                </TableRow>
                                                                <TableRow>
                                                                    <TableCell className={classes.border} align="centre"><Input disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false} name='companyUdfIDSFields.UTXT04' onChange={handleChange} onInput={toInputUppercase} onBlur={this.handleChangeValue} className={classes.input4} value={values.companyUdfIDSFields.UTXT04} /></TableCell>
                                                                </TableRow>
                                                                <TableRow>
                                                                    <TableCell className={classes.border} align="centre"><Input disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false} name='companyUdfIDSFields.UTXT05' onChange={handleChange} onInput={toInputUppercase} onBlur={this.handleChangeValue} className={classes.input4} value={values.companyUdfIDSFields.UTXT05} /></TableCell>
                                                                </TableRow>
                                                                <TableRow>
                                                                    <TableCell className={classes.border} align="centre"><Input disabled={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? true : false} name='companyUdfIDSFields.UTXT06' onChange={handleChange} onInput={toInputUppercase} onBlur={this.handleChangeValue} className={classes.input4} value={values.companyUdfIDSFields.UTXT06} /></TableCell>
                                                                </TableRow>
                                                            </TableBody>
                                                        </Table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </Card>
                            </div>
                        </Grid>
                    </div>
                ) : (<Spinner loading type="list" />)
                }
            </div>
        );
    }
}

CompanyControlFactors.propTypes = propTypes;

export default compose(
    withStyles(style)
)(CompanyControlFactors);

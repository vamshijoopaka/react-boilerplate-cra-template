/**
 *
 * ItemsList
 *
 */

import React, { useState, useEffect } from 'react';
// import PropTypes from 'prop-types';
// import styled from 'styled-components';
import { compose } from 'redux';
import { FormattedMessage } from 'react-intl';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';
import GridErrorMessages from '../common/GridErrorMessages';
import FormattedMessageComponent from '../common/FormattedMessageComponent';
import { isEqual } from 'lodash';
import Spinner from 'components/Common/Spinner';
import CardComponent from '../common/CardComponent';
import TextField from '@material-ui/core/TextField';
import { withStyles, Card, CardHeader, CardContent, Paper, Button, Link } from '@material-ui/core';
import { Route, Redirect } from 'react-router-dom';


import Grid from '@material-ui/core/Grid';
import { fontSize } from '@material-ui/system';
import BlueYonderIcon from '../../images/logo-blueyonder-M.png';
import { clearServerError } from "../../containers/LoginPage/actions";
let loginBackgroundImageUrl = require('../../images/LoginBackground_image.png');
const width = 320;

const style = theme => ({
    MuiInput: {
        root: {
            maxWidth: '280px',
            minWidth: '280px'
        }
    },
    loginContainer: {
        display: 'flex',
        flexDirection: 'column',
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
    },
    loginCard: {
        width: '328px',
        height: '192px',
        backgroundColor: '#F0F2FA',
        borderRadius: '4px'
    },
    textField: {
        width: '280px',
        marginLeft: '24px',
        marginRight: '24px',
        height: '48px',
        minWidth: '280px',
        maxWidth: '280px'
    },
    serverTextField: {
        marginTop: '24px',
        marginLeft: '24px',
        marginRight: '24px',
        width: '280px',
        maxWidth: '280px'
    },
    userTextField: {
        marginTop: '4px',
        marginLeft: '24px',
        marginRight: '24px'
    },
    passwordTextField: {
        marginTop: '4px',
        marginLeft: '24px',
        marginRight: '24px'
    },
    loginButton: {
        width: '280px',
        height: '32px',
        padding: '8px 16px',
        backgroundColor: '#047ABC',
        marginTop: '16px',
        marginBottom: '24px',
        marginLeft: '24px',
        marginRight: '24px'


    },
    paper: {
        display: 'flex',
        flexDirection: 'column',
        marginTop: '40px',

        width: '328px',
        height: '260px',
        backgroundColor: '#F0F2FA',
        borderRadius: '4px',

    },
    changePassword: {
        marginTop: '8px'
    },
    okButton: {
        width: '140px',
        marginLeft: '8px',
        padding: '8px 16px',
        backgroundColor: '#047ABC',
        marginTop: '16px',
        marginBottom: '24px',
    },
    cancelButton: {
        width: '140px',
        marginLeft: '24px',
        padding: '8px 16px',
        backgroundColor: '#047ABC',
        marginTop: '16px',
        marginBottom: '24px',
    },
    errorText: {
        fontSize: '14px',
        color: '#EA1515',
        marginLeft: '24px',
        marginBottom: '16px'
    }
});

class changePasswordForm extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            userName: '',
            passWord: '',
            serverName: '',
            newPassword: '',
            openChangePassword: false,
            hasLocalError: true,
            localErrorMessageID: 227,
            enableChangePasswordOk: true

        };

    }

    componentDidMount() {
        console.log(this.props.history);
        let loginUser = JSON.parse(this.props.history.location.state);
        this.setState({ userName: loginUser.userName });
        this.setState({ serverName: loginUser.serverName });
        document.querySelector('#app').style.backgroundImage = `url(${loginBackgroundImageUrl})`;
    }
    componentDidUpdate(prevProps, prevState) {
        if (this.props.changePasswordPage.isPasswordChanged
            && this.props.changePasswordPage.changePasswordInfo
            && this.props.changePasswordPage.isPasswordChanged != prevProps.changePasswordPage.isPasswordChanged) {
            this.props.setLoginState({ loginSuccess: true, user: this.props.changePasswordPage.changePasswordInfo.userId });
        }


    }

    handleCancel = () => {
        this.props.restChangePasswordState();
        this.props.history.push({
            pathname: '/login',
            state: JSON.stringify({ userName: this.state.userName, serverName: this.state.serverName })
        })


    };
    handleSubmit = () => {

        let user = {
            "userName": this.state.userName,
            "oldPassword": this.state.oldPassword,
            "serverName": this.state.serverName,
            "newPassword": this.state.newPassword,
            "confirmPassword": this.state.confirmPassword
        }
        this.props.clearLoginState(true);
        this.props.changePassword(user);
    };


    handleChange = e => {
        this.setState({
            hasLocalError: false,
            localErrorMessageID: ''
        })
        this.props.clearServerError();
        if (e.target.name == "oldPassword") {
            this.setState({ oldPassword: e.target.value }, () => this.updateErrors())
        } else if (e.target.name == "newPassword") {
            this.setState({ newPassword: e.target.value }, () => this.updateErrors())
        }
        else {
            this.setState({ confirmPassword: e.target.value }, () => this.updateErrors())
        }



    }


    updateErrors() {
        if ((this.state.oldPassword && this.state.newPassword && this.state.confirmPassword) && this.state.oldPassword != '' && this.state.newPassword != '' && this.state.confirmPassword != '') {
            this.setState({
                hasLocalError: false,
            });
            if (this.state.newPassword == this.state.confirmPassword) {
                if (this.state.newPassword == this.state.oldPassword) {
                    this.setState({
                        hasLocalError: true,
                        localErrorMessageID: 226
                    })
                } else {
                    this.setState({
                        hasLocalError: false,
                        localErrorMessageID: ''
                    })
                    this.setState({ enableChangePasswordOk: false })
                }
            } else {
                this.setState({
                    hasLocalError: true,
                    localErrorMessageID: 225// old and new password mis match
                })
            }
        } else {
            this.setState({
                hasLocalError: true,
                localErrorMessageID: 227// Please fill all the fields
            })
        }
    }


    render() {
        const { classes, errorMessageLabels } = this.props;
        const { loading } = this.props.changePasswordPage;
        // if (errorMessageLabels) {
        return (
            <React.Fragment>
                {loading && <Spinner loading type='loading Login' />}
                <div>

                    {(this.props.changePasswordPage.hasError) ? <div>
                        <GridErrorMessages
                            errorMessageLabels={this.props.errorMessageLabels}
                            // id={this.state.errorId ? this.state.errorId : this.props.ServerError}
                            id={this.props.changePasswordPage.ErrorID}
                        />

                    </div> : ''}
                    <div className={classes.loginContainer}>
                        <img
                            src={BlueYonderIcon}
                            width="253px"
                            height="30px"
                            style={{ marginLeft: '24px', marginRight: '24px' }}
                            alt="jdaicon"
                        />
                        <Paper title="Login" className={classes.paper} >


                            <TextField
                                className={`${classes.textField} ${classes.serverTextField}`}
                                id="standard-basic" label={<FormattedMessageComponent id={53324}></FormattedMessageComponent>} name="oldPassword"
                                style={{ width }}
                                type="password"
                                onChange={e => this.handleChange(e)}
                                value={this.state.oldPassword}
                                InputProps={{
                                    style: {
                                        minWidth: '280px',
                                        maxWidth: '280px',
                                        width: '280px'
                                    },
                                }} />
                            <TextField
                                onChange={e => this.handleChange(e)}
                                value={this.state.newPassword}
                                type="password"
                                className={`${classes.textField} ${classes.userTextField}`}
                                InputProps={{
                                    style: {
                                        minWidth: '280px',
                                        maxWidth: '280px',
                                        width: '280px'
                                    },
                                }} id="standard-basic" label={<FormattedMessageComponent id={53325}></FormattedMessageComponent>} name="newPassword" />
                            <TextField
                                onChange={e => this.handleChange(e)}
                                value={this.state.confirmPassword}
                                type="password"
                                className={`${classes.textField} ${classes.passwordTextField}`} InputProps={{
                                    style: {
                                        minWidth: '280px',
                                        maxWidth: '280px',
                                        width: '280px'
                                    },
                                }} id="standard-basic" label={<FormattedMessageComponent id={53326}></FormattedMessageComponent>} name="confirm" />
                            <div style={{ display: 'flex' }}>
                                <Button onClick={this.handleCancel} className={classes.cancelButton} variant="contained" color="primary" >{<FormattedMessageComponent id={50771}></FormattedMessageComponent>}</Button>
                                <Button onClick={this.handleSubmit} className={classes.okButton} variant="contained" color="primary" disabled={this.state.enableChangePasswordOk} >{<FormattedMessageComponent id={52758}></FormattedMessageComponent>}</Button>
                            </div>
                            {(this.state.hasLocalError && errorMessageLabels) ? <div className={classes.errorText}>{this.props.errorMessageLabels[`E${this.state.localErrorMessageID}`].MTEXT.trim()}</div> : ''}
                            {this.props.changePasswordPage.serverError ? <div className={classes.errorText}>
                                {this.props.changePasswordPage.serverErrorId.ERRMSG1}
                            </div>
                                : ''}

                        </Paper>
                    </div>
                </div>
            </React.Fragment>
        );
        // }



    }
}

changePasswordForm.propTypes = {};

export default withStyles(style)(changePasswordForm);

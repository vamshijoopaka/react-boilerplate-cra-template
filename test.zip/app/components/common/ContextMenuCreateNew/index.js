import React, { Component } from 'react';
import ContextMenu from '../ContextMenu'
import { createStructuredSelector } from 'reselect';
import { connect } from 'react-redux';
import { compose } from 'redux';
import { makeSelectAuthorizedComponentsList } from 'containers/App/selectors.js';
import { createNewModuleItem } from '../../../utils/contextMenu';
import { secureNewSubMenuList, getSideBarList } from '../../../utils/util';
import { NEW_MENU_ITEMS } from '../constants';
import { tabsSelector, makeSelectCompanyDetails, getActiveTabData } from '../../../containers/App/selectors';
import { withRouter } from 'react-router-dom';
import PropTypes from 'prop-types';
import { setSelectedTabOnNavigation, setIsShowContextMenu } from '../../../containers/App/actions';
const propTypes = {
    currentPage: PropTypes.string.isRequired,
    currentRecord: PropTypes.object.isRequired,
    authorizedComponentsList: PropTypes.object.isRequired,
    tabs: PropTypes.array.isRequired,
    dispatch: PropTypes.func.isRequired,
}
class ContextMenuCreateNew extends Component {
    constructor(props) {
        super(props);
        this.state = {
            menuList: props.menuList,
        }
    }
    static propTypes = propTypes;
    static defaultProps = {
        currentPage: '',
        currentRecord: {},
    }
    componentDidMount() {
        this.setState({ menuList: this.insertNewMenuItem() }, () => {
            secureNewSubMenuList(this.props.authorizedComponentsList, this.state.menuList, this.props.currentPage, this.props.companyDetails)
        });
    }
    componentDidUpdate(prevProps, prevState) {
        const { authorizedComponentsList, menuList, companyDetails } = this.props;
        if (authorizedComponentsList && JSON.stringify(authorizedComponentsList) !== JSON.stringify(prevProps.authorizedComponentsList)) {
            secureNewSubMenuList(authorizedComponentsList, this.state.menuList, this.props.currentPage, companyDetails);
        }
        if (menuList && JSON.stringify(menuList) !== JSON.stringify(prevProps.menuList)) {
            this.setState({ menuList }, () => {
                secureNewSubMenuList(authorizedComponentsList, this.state.menuList, this.props.currentPage, companyDetails);
                this.setState({ menuList: this.insertNewMenuItem() });
            });
        }
    }
    insertNewMenuItem = () => {
        const newObj = {
            label: '25250',
            key: 'new',
            hasSubMenu: true,
            isDisable: false,
            subMenuList: [...NEW_MENU_ITEMS]
        }
        Object.defineProperty(newObj, 'isDisable', { writable: false }); //New button should never be disabled
        if (!this.state.menuList?.length) {
            return [newObj];
        }
        let menuList = [...this.state.menuList];
        if (menuList?.length) {
            let newIndex = menuList.findIndex(ele => ele?.key?.toLowerCase() === 'new');
            if (newIndex !== -1) {
                menuList[newIndex] = newObj;
            }
            else {
                menuList?.unshift(newObj);
            }
        }
        return menuList;
    }
    handleItemSelection = key => {
        if (key.startsWith('new') && key !== 'newnote') {
            if (this.checkAddNewTabs(key))
                return;
            const argumentObj = {
                fromPage: this.props.currentPage,
                currentRecord: this.props.currentRecord,
                newItemType: key,
                props: { ...this.props },
            }
            createNewModuleItem(argumentObj);
            return;
        }
        this.props.handleItemSelection(key);
    }
    checkAddNewTabs = (selectedKey) => {
        const menuItemObj = NEW_MENU_ITEMS?.find(item => item.key === selectedKey) || {};
        let sideNavbarLabel = menuItemObj.sideNavbarLabel || selectedKey;
        const path = getSideBarList()?.find(ele => ele.type?.toLowerCase() === sideNavbarLabel?.toLowerCase())?.path || "";
        if (!path) return false;
        const redirectPreference = ['parent', 'child'].reverse();//Search -> First Parent then child;
        const redirectPreferenceMap = {
            //Find in Parent Tabs.
            'parent': () => this.props.tabs.find((ele) => ele.path === path),
            //Find in Child Tabs.
            'child': () => {
                let existingTab = this.props.activeTabData?.items?.find((ele) => ele.path === path);
                if (existingTab) {
                    existingTab.selectedBreadcrumbId = existingTab.id;
                    existingTab.tab_id = this.props.activeTabId;
                }
                return existingTab;
            }
        }
        const existingTab = redirectPreference.reduce((acc, type) => redirectPreferenceMap[type]?.() || acc, false);
        if (existingTab) {
            this.props.setIsShowContextMenu(false);
            this.props.history.push({ pathname: existingTab.path, search: `?tab_id=${existingTab.tab_id}&item_id=${existingTab.selectedBreadcrumbId}` });
            this.props.setSelectedTabOnNavigation(existingTab.tab_id, existingTab.selectedBreadcrumbId);
            return true
        }
        return false
    }
    render() {
        return (
            <ContextMenu
                {...this.props}
                handleItemSelection={this.handleItemSelection}
                menuList={this.state.menuList}
            />
        );
    }
}
const getActiveTabId = () => Object.fromEntries(new URLSearchParams(window.location.search)).tab_id;

const mapDispatchToProps = dispatch => ({
    dispatch,
    activeTabId: getActiveTabId(),
    setSelectedTabOnNavigation: (tabId, breadcrumbId) => {
        dispatch(setSelectedTabOnNavigation(tabId, breadcrumbId));
    },
    setIsShowContextMenu: data => {
        dispatch(setIsShowContextMenu(data));
    },
})
const mapStateToProps = createStructuredSelector({
    authorizedComponentsList: makeSelectAuthorizedComponentsList(),
    tabs: tabsSelector(),
    companyDetails: makeSelectCompanyDetails(),
    activeTabData: getActiveTabData(),
});
const withConnect = connect(
    mapStateToProps,
    mapDispatchToProps,
);
export default compose(withConnect, withRouter)(ContextMenuCreateNew)

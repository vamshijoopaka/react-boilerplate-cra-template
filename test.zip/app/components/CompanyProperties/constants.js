export const HeaderAPIValuesJSON = [
  {
    VNAME: '', // COMPANY NAME
    VVNDR: '', // COMPANY ID
    WNAME: '', // WAREHOUSE NAME
    VWHSE: '', // WAREHOUSE ID
    VASLSU: '', // LAST ACCEPTED OPA
    VBIRDT: '', // lAST CALCULATED OPA
    VORCYC: '',
  },
];
// PLEASE NOTE THAT THE KEYS USED FOR HEADER VALUES MAY NOT BE SAME FOR FUTURE WORK.
// PLEASE CHANGE THE KEY VALUES TO REQUIRED KEYS AS NECCESSARY.
export const KEY_COMPANY_NAME = 'VNAME';
export const KEY_COMPANY_ID = 'VVNDR';
export const KEY_WAREHOUSE_NAME = 'VWHSE';
export const KEY_WAREHOUSE_ID = 'WNAME';
export const KEY_LAST_ACCEPTED_OPA = 'VASLSU';
export const KEY_LAST_CALCULATED_OPA = 'VBIRDT';
export const KEY_CURRENT_ORDER_CYCLE = 'VORCYC';
export const KEY_SUB_COMPANY_ID = 'VSUBV';

export const LABEL_COMPANY_LIST = '25190'; // ! needs to be included in Header_ENG.json
export const LABEL_COMPANY_ID = '33303'; // ! needs to be included in Header_ENG.json
export const LABEL_WAREHOUSE_NAME = '36479'; // ! needs to be included in Header_ENG.json
export const LABEL_WAREHOUSE_ID = '33161'; // ! needs to be included in Header_ENG.json
export const LABEL_LAST_ACCEPTED_OPA = '34431'; // ! needs to be included in Header_ENG.json
export const LABEL_LAST_CALCULATED_OPA = '34432'; // ! needs to be included in Header_ENG.json
export const LABEL_CURRENT_ORDER_CYCLE = '40170'; // ! needs to be included in Header_ENG.json

export const LABEL_COMPANY_CONTROL_FACTORS = '25136';
export const LABEL_COMPANY_DEMAND_FORECAST = '25137';
export const LABEL_COMPANY_FORECAST_FACTOR_MATRIX = '28350';
export const LABEL_COMPANY_EXCEPTION_CONTROL = '27022';
export const LABEL_COMPANY_PO_CONTROL = '25128';
export const LABEL_COMPANY_AC_CONTROL = '25133';
export const LABEL_COMPANY_ORDER_CONTROL = '25132';
export const LABEL_COMPANY_NIGHT_JOB_CONTROL = '25135';
export const LABEL_COMPANY_PLANNING_CONTROL = '25131';
export const LABEL_COMPANY_CLASSIFICATION_CONTROL = '27027';
export const LABEL_COMPANY_CONSTRAINED_CONTROL = '28087';
export const LABEL_COMPANY_DASHBOARD_CONTROL = 'Dashboard Controls';
export const LABEL_COMPANY_RECORD_RETENTIONS = "65608";//'Record Retentions';
export const LABEL_COMPANY_SYSTEM_SETUP = "65609";//'System Set Up';
export const LABEL_COMPANY_EXCEPTION_MAINTENANCE = '52805';

export const LABEL_ORDER_CONTROL_FACTORS = '25181';
export const LABEL_OPA_SETUP = '25183';
export const LABEL_OPA_RESULTS = '25507';
export const LABEL_OPA_GRAPH = '25057';
export const LABEL_COMPANY_ADDRESS = '25102';

export const LABEL_ACTIONS = '28310';
export const LABEL_SAVE = '28650';

export const KEY_NEW = 'New';
export const KEY_COPY = 'Copy';
export const KEY_POSITION_TO = 'PositionTo';
export const KEY_DELETE = 'Delete';

export const JOB_SUBMITTED_WARNING = 'A job was submitted to apply Forecasting Demand Limit changes to the Vendors and Items.  Please review Items and reforecast, if needed.';

export const KEY_FORECAST_CALCULATION = "ForecastCalculation";
export const KEY_NEW_PLAN = "NewPlan";

export const CONTEXT_MENU_COMPANY_HEADER = [
  {
      label: '27043',
      key: KEY_FORECAST_CALCULATION,
      hasSubMenu: false
  }
];

export const DEFAULT_FIELD_URL_DATA = [
  { accessor: 'DSNAME', operator: '=', fieldValue: 'DSVNDR', prefixFlag: 1 },
  {
    accessor: 'BONAME',
    operator: '=',
    fieldValue: 'TrimCompanyBusObj',
    prefixFlag: 1,
  },
];
export const DEFAULT_VALUE_URL_DATA = [
  { accessor: 'COMP', operator: '=', fieldValue: '', prefixFlag: 0 },
  { accessor: 'WHSE', operator: '=', fieldValue: '', prefixFlag: 0 },
  { accessor: 'VNDR', operator: '=', fieldValue: '', prefixFlag: 0 },
  { accessor: 'SUBV', operator: '=', fieldValue: '', prefixFlag: 0 },
];

export const DEFAULT_VALUE_URL_DATA_WITH_OUT_SUB_COMPANY = [
  { accessor: 'COMP', operator: '=', fieldValue: '', prefixFlag: 0 },
  { accessor: 'WHSE', operator: '=', fieldValue: '', prefixFlag: 0 },
  { accessor: 'VNDR', operator: '=', fieldValue: '', prefixFlag: 0 },
];

export const LABEL_LIST_URL_DATA = [
  {
    accessor: 'TRIMBO',
    operator: '=',
    fieldValue: 'TrimCompanyUI&KLANGID=ENG',
    prefixFlag: 0,
  },
];

export const LABEL_LIST_SIM_URL_DATA = [
  {
    accessor: 'TRIMBO',
    operator: '=',
    fieldValue: 'SIMCompanyUI&KLANGID=ENG',
    prefixFlag: 0,
  },
];

export const LABEL_LIST_SIM_COMMON_URL_DATA = [
  {
    accessor: 'TRIMBO',
    operator: '=',
    fieldValue: 'SIMCommon&KLANGID=ENG',
    prefixFlag: 0,
  },
];

export const COMPANY_PROPERTIES_GET_VALUE_LIST =
  'COMPANY_PROPERTIES_GET_VALUE_LIST';
export const COMPANY_PROPERTIES_GET_VALUE_LIST_SUCCESS =
  'COMPANY_PROPERTIES_GET_VALUE_LIST_SUCCESS';
export const COMPANY_PROPERTIES_GET_VALUE_LIST_FAILURE =
  'COMPANY_PROPERTIES_GET_VALUE_LIST_FAILURE';
export const COMPANY_PROPERTIES_LOAD_PREV_NEXT_DATA =
  'COMPANY_PROPERTIES_LOAD_PREV_NEXT_DATA';
export const COMPANY_PROPERTIES_LOAD_PREV_NEXT_DATA_SUCCESS =
  'COMPANY_PROPERTIES_LOAD_PREV_NEXT_DATA_SUCCESS';
export const COMPANY_PROPERTIES_LOAD_PREV_NEXT_DATA_FAILURE =
  'COMPANY_PROPERTIES_LOAD_PREV_NEXT_DATA_FAILURE';
export const COMPANY_PROPERTIES_SET_VALUE = 'COMPANY_PROPERTIES_SET_VALUE';
export const COMPANY_PROPERTIES_CONSTRAINED_SET_VALUE =
  'COMPANY_PROPERTIES_CONSTRAINED_SET_VALUE';
export const COMPANY_PROPERTIES_JOB_CONTROL_SET_VALUE =
  'COMPANY_PROPERTIES_JOB_CONTROL_SET_VALUE';
export const COMPANY_PROPERTIES_DASHBOARD_SET_VALUE =
  'COMPANY_PROPERTIES_DASHBOARD_SET_VALUE';
export const COMPANY_PROPERTIES_ORDER_DETAIL_SET_VALUE =
  'COMPANY_PROPERTIES_ORDER_DETAIL_SET_VALUE';
export const COMPANY_PROPERTIES_SEND_DATA_TO_SERVER =
  'COMPANY_PROPERTIES_SEND_DATA_TO_SERVER';
export const COMPANY_PROPERTIES_SEND_DATA_TO_SERVER_FAILURE =
  'COMPANY_PROPERTIES_SEND_DATA_TO_SERVER_FAILURE';
export const COMPANY_PROPERTIES_SEND_DATA_TO_SERVER_SUCCESS =
  'COMPANY_PROPERTIES_SEND_DATA_TO_SERVER_SUCCESS';
export const UPDATE_VALUE_DATA = 'COMPANY_PROPERTIES_UPDATE_VALUE_DATA';
export const COMPANY_PROPERTIES_SET_CURRENT_TYPE =
  'COMPANY_PROPERTIES_SET_CURRENT_TYPE';
export const COMPANY_PROPERTIES_SET_ROW_INDEX =
  'COMPANY_PROPERTIES_SET_ROW_INDEX';
export const COMPANY_PROPERTIES_CURRENT_RECORD_DATA =
  'COMPANY_PROPERTIES_CURRENT_RECORD_DATA';
export const COMPANY_PROPERTIES_LABELS = 'COMPANY_PROPERTIES_LABELS';
export const COMPANY_PROPERTIES_LABELS_SUCCESS =
  'COMPANY_PROPERTIES_LABELS_SUCCESS';
export const COMPANY_PROPERTIES_LABELS_FAILURE =
  'COMPANY_PROPERTIES_LABELS_FAILURE';
export const COMPANY_PROPERTIES_SIM_LABELS = 'COMPANY_PROPERTIES_SIM_LABELS';
export const COMPANY_PROPERTIES_SIM_LABELS_SUCCESS =
  'COMPANY_PROPERTIES_SIM_LABELS_SUCCESS';
export const COMPANY_PROPERTIES_SIM_LABELS_FAILURE =
  'COMPANY_PROPERTIES_SIM_LABELS_FAILURE';

export const COMPANY_PROPERTIES = 'companyProperties';

export const companyPropertiesCompanyNameJSON = [
  {
    key: 'VNAME',
    labelPlacement: 'start',
    disabled: 0,
    dataType: 'text',
    valueSuggestionList: '',
    isCheckWildCard: false,
    toUppercase: false,
    maxLength: '30',
    TLLAB: 'Company Name',
    hasMassMaintenance: true,
    showMassMaintenance: false,
  },
];

//company_notes_begin
export const TRIMCOMMON_LABEL_URL_DATA = [
  { "accessor": "TRIMBO", "operator": "=", "fieldValue": "TrimCommon", "prefixFlag": 0 },
  { "accessor": "LANGID", "operator": "=", "fieldValue": "ENG", "prefixFlag": 0 }
]

export const COMPANY_NOTE_LABEL_JSON = [{"FLDID":"3303","FLDTYPE":"Label","FDPROD":" ","FDFILD":"3303","FDFNAM":"COMP      ","FDPRFX":"0","FDFCLS":"F","FDFTYP":"C","FDMINV":".0000","FDMAXV":".0000","FDVLDT":"N","FDZAPO":"N","FDFLEN":"3","FDDECP":"0","FDDEFN":"IDF_COMP                                          ","FDMASK":"                                                  ","FDLTRL":"                                                  ","FDDATR":"                                                  ","FDDPRN":"0","FDDDIV":"0","TLANG":"ENG","TPROD":" ","TIDNO":"33303","TDEFN":"IDX_33303                                         ","TLLAB":"Company ID","TULLB":"","TSLAB":"Cmp","TUSLB":"","FLDVLD":""}]
//company_notes_end

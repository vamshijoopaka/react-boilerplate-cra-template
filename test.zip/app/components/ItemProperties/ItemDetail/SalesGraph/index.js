import React, { PureComponent } from 'react';
import HighchartsReact from 'highcharts-react-official';
import PropTypes from 'prop-types';
const propTypes = {
    data: PropTypes.shape({
        DEMND: PropTypes.object,
        PROMO: PropTypes.object,
        ONBAC: PropTypes.object,
        BOOKN: PropTypes.object,
    }).isRequired,
    getMessageText: PropTypes.func.isRequired,
}
class SalesGraph extends PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            options: {
                chart: {
                    type: 'column',
                    scrollablePlotArea: {
                        minWidth: 8000,
                        scrollPositionX: 0
                    },
                    scrollbar: {
                        enabled: true
                    },
                    height: props.height || null,
                },
                accessibility: {
                    description: 'Sales Graph'
                },
                title: {
                    text: props.getMessageText('50789') || 'Sales Graph'
                },
                credits: {
                    enabled: false
                },
                xAxis: {
                    allowDecimals: true,
                    // tickInterval: 24 * 3600 * 1000,
                    labels: {
                        overflow: 'justify',
                        step: 1,
                        rotation: -90
                    },
                    scrollbar: {
                        enabled: true
                    },
                    // type: 'datetime',
                    lineWidth: 2,
                    // dateTimeLabelFormats: {
                    //     day: '%e/%m/%Y'
                    // },
                    startOnTick: true,
                    // tickmarkPlacement: 'on',
                    // left: 8,
                    categories: props.data.categories
                },
                tooltip: {
                    // xDateFormat: '%e/%m/%Y',
                    shared: true
                },
                plotOptions: {
                    series: {
                        // lineWidth: 2,
                        // pointWidth: 15,
                        // pointInterval: 24 * 3600 * 1000,
                        // pointStart: (props.startDate && Date.parse(props.startDate)) || Date.UTC(2020),
                        scrollbar: {
                            enabled: true
                        },
                        stacking: 'normal',
                        marker: {
                            enabledThreshold: 1,
                            radius: 1
                        },
                        animation: true,
                    }
                },
                series: [{
                    name: props.getMessageText('50784') || 'Demand',
                    trackByArea: true,
                    point: {
                    },
                    data: props.data.DEMND.graphData?.slice(0, 365),
                    stack: 'sales',
                    legendIndex: 0,
                    color: '#048BD0',
                },
                {
                    name: props.getMessageText('50785') || 'Promo',
                    data: props.data.PROMO.graphData?.slice(0, 365),
                    stack: 'sales',
                    legendIndex: 1,
                    color: '#27AE60',
                },
                {
                    name: props.getMessageText('50786') || 'Back Order',
                    data: props.data.ONBAC.graphData?.slice(0, 365),
                    stack: 'sales',
                    legendIndex: 2,
                    color: '#e91e63',
                },
                {
                    name: props.getMessageText('50787') || 'Booking',
                    data: props.data.BOOKN.graphData?.slice(0, 365),
                    stack: 'sales',
                    legendIndex: 3,
                    color: '#FBC02D'
                },
                ].reverse()
            }
        }
        this.chart = React.createRef();
    }
    componentDidUpdate(prevProps) {
        const { height } = this.props;
        if (height && height != prevProps.height && this.chart && this.chart.current && this.chart.current.chart) {
            this.chart.current.chart.setSize(undefined, height);
        }
    }
    render() {
        return (
            <div style={{ maxWidth: '100%', width: '100%' }}>
                <HighchartsReact options={this.state.options} ref={this.chart}/>
            </div>
        );
    }
}
SalesGraph.propTypes = propTypes;
export default SalesGraph;
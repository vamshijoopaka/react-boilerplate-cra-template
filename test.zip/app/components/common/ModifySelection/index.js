/*// ===========================================================================
E3C-33076-Sachin,,09-11-2021-MM on OUTl field with enable edits - add is not updating correct value
* * // ===========================================================================
*/
import React from 'react';
import { connect } from 'react-redux';
import { compose } from 'redux';
import InputDialog from '../InputDialog';
import { TEXT_CANCEL, TEXT_OK } from '../../../containers/common/constants';
import FieldInput from '../Form/FieldInput';
import { Box, FormControlLabel, withStyles } from '@material-ui/core';
import FormattedMessageComponent from '../FormattedMessageComponent';
import { COLUMN_HEADER_ACCESSOR, COLUMN_VALUE_ACCESSOR } from '../constants';
import Form from '../Form/Form';
import { checkMaxCondition, checkMinCondition } from '../../../utils/fieldValidations';
import { getUnformattedValue } from '../../../utils/util';

const radioOptions = [{ key: '2988', fieldValue: 'replace' }, { key: '2994', fieldValue: 'add' }];

const style = theme => ({
    ValuesInputField: {
        margin: '20px 0px',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        fontSize: '16px',
        alignSelf: 'flex-start',
        height:'125px'                  //Fix for E3C-30685
    }
});

class ModifySelection extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            modifyInputValue: '',
            replaceEveryCell: true,
            addToEveryCell: false,
            hasError: false,
            errorCode: false,
            displayValue: false
        }
    }

    handleChangeValue = (key, val, field) => {
        let value = val;
        if (field.dataType == 'number')
            value = getUnformattedValue(val, this.props.globalNumberFormat, this.props.globalNumberSeparator, this.props.globalDecimalSeparator);
        this.setState({ modifyInputValue: value, displayValue: val });
    }

    onModifyCheckboxSelect = () => {
        this.setState({
            replaceEveryCell: !this.state.replaceEveryCell,
            addToEveryCell: !this.state.addToEveryCell
        }, () => {
            let isValid = this.checkMinMaxCondition(this.state.addToEveryCell);
        });
    }

    handleCancel = () => {
        this.props.closeModifySelection(this.state, false);
    }

    checkMinMaxCondition(isAdd) {
        const { modifyInputValue, addToEveryCell, replaceEveryCell } = this.state;
        const { field, selectedRows } = this.props;
        let maxValid, minValid, maxErrorCode, minErrorCode;
        let value = Number(modifyInputValue.trim());
        let check = selectedRows.some(ele => {
            [maxValid, maxErrorCode] = checkMaxCondition(Number(field.maxValue), isAdd ? Number(ele[field.key].trim()) + value : value, Number(field.minValue), true);
            [minValid, minErrorCode] = checkMinCondition(Number(field.minValue), isAdd ? Number(ele[field.key].trim()) + value : value, true)
            return maxValid && minValid;
        });
        if (check) {
            return true;
        } else {
            this.setState({ hasError: true, errorCode: minErrorCode || maxErrorCode });
            return false;
        }
    }

    handleSubmit = () => {
        const { modifyInputValue, addToEveryCell, replaceEveryCell } = this.state;
        const { field, selectedRows } = this.props;
        if (field.dataType !== 'number') {
            this.props.closeModifySelection(this.state, true);
        } else {
            let isValid = this.checkMinMaxCondition(addToEveryCell);
            if (isValid) {
                this.props.closeModifySelection(this.state, true);
            }
        }
    }

    onBlurMinValidation(obj) {
    }
    clearErrorCode = () => {
        this.setState({ hasError: false, errorCode: false });
    }
    render() {
        const { classes, isOpen, field, currentPage, globalNumberFormat, globalNumberSeparator, globalDecimalSeparator } = this.props;
        return (
            <div id="modify-selection">
                <InputDialog
                    isOpen={isOpen}
                    dialogTitle={'2891'}
                    cancelText={TEXT_CANCEL}
                    submitText={TEXT_OK}
                    handleClose={this.handleCancel}
                    handleCancel={this.handleCancel}
                    isBackArrow={true}
                    handleSubmit={this.handleSubmit}>
                    <Box display='flex' justifyContent='center' alignItems='center' flexDirection='column'>
                        <Box className={classes.ValuesInputField}>
                            <FormattedMessageComponent id={2838} title={'Value'} />
                            <Form>
                                {({ errors, onChange, validate, values }) => (
                                    <FormControlLabel
                                        className={classes.inputField}
                                        control={<FieldInput
                                            value={this.state.displayValue ? this.state.displayValue : this.state.modifyInputValue}
                                            field={{
                                                type: field.dataType, valueSuggestionList: field.valueSuggestionList ? field.valueSuggestionList : [], Attr: field.FDDATR ? field.FDDATR : ' ',
                                                options: field.valueSuggestionList ? field.valueSuggestionList : []
                                            }}
                                            onChange={(key, val) => { onChange(key, val), this.handleChangeValue(key, val, field) }}
                                            isCheckWildCard={field.isCheckWildCard}
                                            toUppercase={field.toUppercase}
                                            isNegative={field.isNegative}
                                            numberType={field.numberType}
                                            precisionLength={field.precisionLength}
                                            maxLength={Number(field.maxLength)}
                                            minValue={field.minValue}
                                            maxValue={field.maxValue}
                                            onBlurMinValidate={(val) => this.onBlurMinValidation(val)}
                                            errorMessageLabel={field[COLUMN_HEADER_ACCESSOR]}
                                            hasError={this.state.hasError}
                                            errorCode={this.state.errorCode}
                                            clearErrorCode={this.clearErrorCode}
                                            addValueOnPostValidation={this.state.addToEveryCell}
                                            preValue={this.state.addToEveryCell ? Number(field.key)?Number(field.key):0 : 0}            //Fix for E3C-33076,09-11-2021,sachin
                                            globalNumberFormat={globalNumberFormat}
                                            globalNumberSeparator={globalNumberSeparator}
                                            globalDecimalSeparator={globalDecimalSeparator}
                                            globalDateFormat={this.props.globalDateFormat}              //Fix for E3C-30685
                                        ></FieldInput>}
                                        label={''}
                                        labelPlacement={'start'}
                                        title={''}
                                    />
                                )}
                            </Form>
                        </Box>
                        {/* <Box display='flex' justifyContent='flex-start' alignItems='center' width='100%'>
                            <FieldInput
                                value={this.state.replaceEveryCell}
                                onChange={this.onModifyCheckboxSelect}
                                field={{ type: 'checkbox' }}
                            ></FieldInput>
                            <FormattedMessageComponent id={2988}></FormattedMessageComponent>
                        </Box>
                        <Box display='flex' justifyContent='flex-start' alignItems='center' width='100%'>
                            <FieldInput
                                value={this.state.addToEveryCell}
                                onChange={this.onModifyCheckboxSelect}
                                field={{ type: 'checkbox' }}
                            ></FieldInput>
                            <FormattedMessageComponent id={2994}></FormattedMessageComponent>
                                        </Box> */}
                        {field.dataType === 'number' && <FormControlLabel
                            control={<FieldInput
                                formatMessage={true}
                                options={radioOptions}
                                value={this.state.replaceEveryCell ? 'replace' : 'add'}
                                field={{ key: 'modify', type: 'radio', options: radioOptions }}
                                onChange={(key, val1) => { this.onModifyCheckboxSelect() }}
                            ></FieldInput>}
                            labelPlacement={'end'}
                        />}
                    </Box>
                </InputDialog>
            </div>
        );
    }

}

const mapStateToProps = function (state) {
    return {
    }

}

function mapDispatchToProps(dispatch) {
    return {
        dispatch,
    };
}

const withConnect = connect(
    mapStateToProps,
    mapDispatchToProps,
);

export default compose(
    withConnect,
    withStyles(style)
)(ModifySelection);
import React, { Component } from 'react';
import DeleteDeal from 'containers/DealsEmbeddedListPage/DeleteDeal';
class DeleteDealDialog extends Component {
	constructor(props) {
		super(props);
		this.state = {

		}
	}

	render() {
		return (
			<div>
				<DeleteDeal
					{...this.props} />
			</div>)
	}
}
export default DeleteDealDialog;
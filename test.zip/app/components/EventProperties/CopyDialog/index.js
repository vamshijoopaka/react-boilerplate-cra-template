import React, { Component } from 'react';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import { withStyles, Box, Typography } from '@material-ui/core';
import DialogComponent from 'components/common/DialogComponent';
import theme from '../../../jda-gcp-theme';
import FormattedMessageComponent from '../../common/FormattedMessageComponent';
import FormFieldsGenerator from '../../common/FormFieldsGenerator';
import EmbeddedList from 'containers/common/EmbeddedList';
import Spinner from 'components/Common/Spinner';
import FieldInput from 'components/common/Form/FieldInput';
import GridErrorMessages from 'components/common/GridErrorMessages';
import {
	DIALOG_TITLE_COPY, TEXT_COPY, FROM_EVENT,
	TO_EVENT, OPTIONS_COPY, EVENT_INFORMATION, WAREHOUSE,
	ITEM, VENDOR_ID, SHIP_DATE_TO_CUSTOMER, CUSTOMER_ID,
	MENU_ITEMS, EVENTS_FILTER_VALUES, EVENTS,
	TO_WAREHOUSES, WAREHOUSE_PAGE, ITEMS_PAGE, 
	COPY_KEY_JSON
} from "./constants";
import { TEXT_CANCEL, TEXT_ALERT, TEXT_OK } from '../../common/constants';
import { INITIAL_PAGE_PROPS } from 'components/common/constants';
import { getListPredecessor, getDateFormatValue } from 'utils/util';
import reducer from './reducer';
import saga from './saga';
import ConfirmationDialog from 'components/common/ConfirmationDialog';
import {
	rowDataSelector,
	columnDefsSelector,
	loadingSelector,
	columnFlagSelector,
	pagePropsSelector,
	filterPropsSelector,
	columnInfoSelector,
	isAPIProgressSelector,
	totalCountSelector,
	moreRecordsSelector,
	apiCallCountSelector,
	updateColumnsListSelector,
	errorMessageLabels,
	itemsListSelector,
	makeSelectEventCopy
} from './selector';
import {
	getEventCopyList,
	setApiCallCount,
	onSetPageProps,
	getEventCopyColumnDefs,
	setFilterValues,
	setColumnDefsLoaded,
	updateShowHide,
	resetStateData,
	resetDefault,
	getItemsList,
	setLabelDataFlags
} from './action';

const styles = theme => ({
	adjustDialog1: {
		maxHeight: '93vh',
		'& .MuiDialogContent-root': {
			padding: '12px'
		},
	},
	notesForBlock: {
		display: 'flex',
		flexDirection: 'column',
		marginTop: '25px',
		border: '1px solid var(--divider-line)',
		padding: '10px 10px 0 10px',
		position: 'relative'
	},
	notesForLabel: {
		position: 'absolute',
		top: '-7px',
		left: '10px',
		background: 'var(--background-content)',
		padding: '0 8px',
	},
	adjustCardFieldsInline: {
		display: 'grid !important',
		width: '100%',
		gridTemplateColumns: 'auto auto',
	},
	fieldLabel: {
		color: 'var(--header-label-color)',
		padding: '0 0px 8px 0',
		width: '22ch',
	},
	childBlock: {
		display: 'flex',
		padding: '6px'
	},
	adjustShowDetail: {
		display: 'flex',
		bottom: '10px',
		left:'22px',
		position:'fixed'
	},
	fieldValue: {
		color: 'var(--value)'
	},
	fieldValuesParent: {
		display: 'flex'
	},
	idValue: {
		marginRight: '20px',
		minWidth: '15ch'
	},
	showDetail: {
		paddingTop: '10px',
	}
});

class CopyDialog extends Component {
	constructor(props) {
		super(props);
		this.state = {
			selectAllFlag: false,
			selectedCount: 0,
			selectedRecordsObject: {},
			menuItems: [...MENU_ITEMS],
			rowSelection: 'multiple',
			selectedRows: false,
			valueArrayToEvent: {},
			valueDataFailureMessages: [],
			showValueConfirmationDialog: false,
		}
		this.handleValueDataErrorMessages = this.handleValueDataErrorMessages.bind(this);
	}

	getLabelValue(id) {
		return <FormattedMessageComponent id={id}></FormattedMessageComponent>;
	}

	setAssociativeArrayObject = (rowData) => {
		const { apiCallCount, pageProps } = this.props;
		let str = apiCallCount + "buffer";
		let data = this.state.selectedRecordsObject;
		if (data && Object.keys(data) && rowData && rowData.length) {
			for (let key in data) {
				let recordData = data[key];
				if (recordData && recordData.length && (key == str)) {
					recordData.forEach((record, index) => {
						rowData[index]["isSelected"] = record.isSelected;
					})
				}
			}
		}
		data[str] = rowData;
		this.setState({ selectedRecordsObject: data })
	}

	updateSelectAllFlag = (flag) => {
		const { rowData = [] } = this.props;
		this.setState({ selectAllFlag: flag, selectedCount: flag ? rowData.length : 0 });
	}

	changeValuesOnSelectDeselect = (flag) => {
		let recordObj = this.state.selectedRecordsObject;
		if (recordObj && Object.keys(recordObj)) {
			for (let key in recordObj) {
				if (recordObj[key] && recordObj[key].length) {
					recordObj[key].forEach((record, index) => {
						record.isSelected = flag;
					})
				}
			}
		}
		this.setState({ selectedRecordsObject: recordObj })
	}

	onRowSelected = (event) => {
		if (this.grid && this.grid.api) {
			const { apiCallCount, pageProps } = this.props;
			const { actualPageSize, actualPage } = pageProps;
			let data = this.state.selectedRecordsObject;
			if (data && Object.keys(data) && Object.keys(data).length) {
				let key = apiCallCount + "buffer";
				let rowIndex = (event.rowIndex + (actualPageSize * actualPage)) % 100;
				const { selected } = event.node;
				data[key][rowIndex]['isSelected'] = selected;
				this.setState({ selectedRecordsObject: data });
				this.setState((state) => ({ selectedCount: this.grid.api.getSelectedRows().length || 0 }))
			}
		}
	}
	getApiObj = (filterProps, record, pageProps, currentPage) => {
		let apiObj = {
			filterProps, filterProps,
			pageProps: pageProps,
			direction: pageProps.isForwardDirection,
			record: record,
			currentPage: currentPage
		};
		return apiObj;
	}

	setPageForwardDirection = (flag) => {
		let initialPageData = {
			...INITIAL_PAGE_PROPS,
			actualPage: 0,
			currentPage: 0,
			totalCount: 10,
			isForwardDirection: flag
		};
		this.setState({ initialPageData: initialPageData });
		this.props.onSetPageProps(initialPageData);
	}

	componentWillUnmount() {
		this.props.setColumnDefsLoaded(false);
		this.props.resetStateData(false)
	}

	componentDidMount() {
		const { headerJson, eventDetailData } = this.props;
		let valueArrayToEvent = { ...eventDetailData }

		valueArrayToEvent["showDetail"] = 0;
		valueArrayToEvent = {...valueArrayToEvent, ...COPY_KEY_JSON};
		valueArrayToEvent['ECCOMP'] = eventDetailData['EHCOMP'];
		valueArrayToEvent['ECREFN'] = eventDetailData['EHREFN'];
		// valueArrayToEvent['EHBGDT'] = getDateFormatValue(eventDetailData["EHBGDT"]);
		// valueArrayToEvent['EHENDT'] = getDateFormatValue(eventDetailData["EHENDT"]);
		valueArrayToEvent['EHBGDT'] = eventDetailData["EHBGDT"];
		valueArrayToEvent['EHENDT'] = eventDetailData["EHENDT"];
		this.setState({ valueArrayToEvent });

		let filterData = [...EVENTS_FILTER_VALUES];
		this.props.setFilterValues(filterData);
		this.setPageForwardDirection(true);
		this.props.getEventCopyColumnDefs({ type: EVENTS });
	}

	componentDidUpdate(prevProps, prevState) {
		const { columnDefs, rowData, isColumnDefsLoaded, filterProps, pageProps, updateColumnsList } = this.props;
		const { valueArrayToEvent } = this.state;
		const {
			isAPIforEventCopyList,
			isAPIforColumns,
			isAPIforColumnsUpdate,
			isAPIforResetColumns,
			isAPIforItemList,
		} = this.props.eventCopy

		if (this.state.valueDataFailureMessages && this.state.valueDataFailureMessages.length
			&& (JSON.stringify(this.state.valueDataFailureMessages) != JSON.stringify(prevState.valueDataFailureMessages))) {
			this.handleValueDataErrorMessages(this.state.valueDataFailureMessages[0]);
		}

		let filterData = [...EVENTS_FILTER_VALUES];
		filterData.push({ "accessor": "VNDR", "operator": "=", "jOpr": "and", "fieldValue": valueArrayToEvent["EHVNDR"], "prefixFlag": 0 });
		filterData.push({ "accessor": "ITEM", "operator": "=", "jOpr": "and", "fieldValue": valueArrayToEvent["EHITEM"], "prefixFlag": 0 });

		if ((pageProps != prevProps.pageProps) && pageProps.isPageSizeChanged) {
			let initialPageData = {
				...pageProps,
				actualPage: 0,
				currentPage: 0,
				totalCount: 10,
				isForwardDirection: true,
			};
			this.props.onSetPageProps({
				...pageProps,
				isPageSizeChanged: false
			});

		if ((updateColumnsList != prevProps.updateColumnsList) && updateColumnsList) {
			this.props.getEventCopyColumnDefs({ type: EVENTS });
		}
		}
	}
	disableMenuItem = (menuItem, disable) => {
		this.setState({
			menuItems: MENU_ITEMS.map(row => {
				let item = { ...row };
				if (item.key == menuItem)
					item.isDisable = disable;
				return item;
			})
		})
	}

	getSelectedRowsForAPI = () => {
		let selectedRows = [];
		let recordObj = this.state.selectedRecordsObject;
		if (recordObj && Object.keys(recordObj)) {
			for (let key in recordObj) {
				let dataRecord = recordObj[key];
				if (dataRecord && dataRecord.length) {
					dataRecord.forEach((record) => {
						if (record.isSelected) {
							selectedRows.push(record);
						}
					})
				}
			}
		}
		return selectedRows;
	}

	handleSubmit = () => {
		const { valueArrayToEvent } = this.state
		if (this.onValid(valueArrayToEvent)) {
			const showDetailCheck = Boolean(valueArrayToEvent["showDetail"])
				let listParams = showDetailCheck ? this.prepareListParams() : {}
				this.props.onSubmit(valueArrayToEvent, showDetailCheck, listParams);
				this.handleClose();
		}
	}

	onValid = (valueArrayToEvent) => {

		const { companyDetails } = this.props;
		
		if(valueArrayToEvent.ECREFT == ' ') {
			this.setGridError('19701');
			return false;
		}
	
		if(valueArrayToEvent.ECDESC == ' ') {
			this.setGridError('19705');
			return false;
		}

		if(valueArrayToEvent.ECBGDT == ' ' || valueArrayToEvent.ECENDT == ' ') {
			this.setGridError('19702');
			return false;
		}

		if (companyDetails && valueArrayToEvent["ECBGDT"] < companyDetails.CJDATE) {
			this.setGridError('19704');
			return false;
		}

		if (valueArrayToEvent["ECBGDT"] > valueArrayToEvent["ECENDT"]) {
			this.setGridError('19703');
			return false;
		}

		return true;
	}

	setGridError = (errorId, parameterValues = []) => {
		this.setState({ hasError: true, errorId, parameterValues }, () => {
			setTimeout(() => {
				this.setState({ hasError: false, errorId: false })
			}, 3e3);
		})
	}

	prepareData = data => {
		let dataArray = []
		const { valueArrayToEvent } = this.state
		const { headerJson } = this.props;
		data.forEach(row => {
			let obj = {};
			dataArray.push(obj);
		});
		return dataArray;
	}

	prepareListParams = () => {
		const { valueArrayToEvent } = this.state;
		let filterProps = [{ "accessor": "COMP", 'prefixFlag': 0, "operator": "=", "jOpr": "and", "fieldValue": "E3T" },
		{ "accessor": "REFN", 'prefixFlag': 0, "operator": "=", "jOpr": "and", "fieldValue": valueArrayToEvent['ECREFT'] },
		];
		let pageProps = { pageSize: 3 }
		return {
			filterProps, pageProps, direction: true, currentPage: 'events'
		}
	}

	prepareListParamsCopyAll = (rowData, keyData) => {
		let firstRow = rowData[0];
		const { headerJson } = this.props;
		let filterData = [{ "accessor": "ICOMP", 'prefixFlag': 1, "operator": "=", "jOpr": "and", "fieldValue": "E3T" }];
		filterData.push({ "accessor": "IVNDR", "operator": "=", "jOpr": "and", "fieldValue": headerJson["BKVNDR"], "prefixFlag": 1 });
		filterData.push({ "accessor": "IITEM", "operator": "=", "jOpr": "and", "fieldValue": headerJson["BKITEM"], "prefixFlag": 1 });

		let pageFilter = [...EVENTS_FILTER_VALUES];
		pageFilter.push({ "accessor": "VNDR", 'prefixFlag': 0, "operator": "=", "jOpr": "and", "fieldValue": headerJson["BKVNDR"] });
		pageFilter.push({ "accessor": "ITEM", 'prefixFlag': 0, "operator": "=", "jOpr": "and", "fieldValue": headerJson["BKITEM"] });
		pageFilter.push({ "accessor": "SDAT", 'prefixFlag': 0, "operator": "=", "jOpr": "and", "fieldValue": keyData["BKTDAT"] });
		pageFilter.push({ "accessor": "CSID", 'prefixFlag': 0, "operator": "=", "jOpr": "and", "fieldValue": keyData["BKTCSD"] });
		pageFilter.push({ "accessor": "WHSE", 'prefixFlag': 0, "operator": "=", "jOpr": "and", "fieldValue": firstRow["WWHSE"] });
		
		let pageProps = { pageSize: 3 }
		return {
			filterProps:filterData, pageProps, direction: true, currentPage: 'events',pageFilter
		}
	}

	handleClose = () => {
		this.props.handleCopyDeletePopup('openCopyPopup', false)
	}

	onGridReady = (params) => {
		this.grid = params;
	}

	handleChangeValue = (key, val) => {
		if(!val && val!="")return;
		if(['ECSLS', 'ECMSG'].includes(key) && !val) return;
		const valueArrayToEvent = { ...this.state.valueArrayToEvent };
		valueArrayToEvent[key] = val;
		this.setState({ valueArrayToEvent });
	}

	closeValueDialog = () => {
		this.setState({ showValueConfirmationDialog: false });
		if (this.state.valueDataFailureMessages && this.state.valueDataFailureMessages.length) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.shift();
			this.setState({ valueDataFailureMessages: values });
			if (values && values.length == 0) {
				this.handleClose();
			}
		}
	}

	handleValueDataErrorMessages(content) {
		this.setState({ showValueConfirmationDialog: true, dialogContent: content });
	}

	disableSubmit = () =>{
		let disable =false;
		const { valueArrayToEvent} = this.state;
		if(!valueArrayToEvent.ECREFT || !valueArrayToEvent.ECDESC || !valueArrayToEvent.ECBGDT || !valueArrayToEvent.ECENDT)
			disable = true;
		return disable;
	}

	render() {
		const { classes, globalDateFormat, filterCriteriaDetails,
			pageFilterOptions, globalFilterOptions, columnDefs, currentOwnerName,
			currentPage, canUpdateComponent, loading, copyLabels, rowData, headerJson, eventDetailData, items, apiCallCount, companyDetails } = this.props;
		const { tabcards } = copyLabels;
		const { valueArrayToEvent } = this.state;

		return (
			<DialogComponent
				className={classes.adjustDialog1}
				isOpen={this.props.openCopyPopup}
				dialogTitle={this.getLabelValue(DIALOG_TITLE_COPY)}
				cancelText={TEXT_CANCEL}
				submitText={TEXT_OK}
				handleClose={e => this.handleClose()}
				handleCancel={e => this.handleClose()}
				handleSubmit={() => this.handleSubmit()}
				disableSubmit={this.disableSubmit()}>

				<React.Fragment>
				{this.state.hasError ? (
					<div>
						<GridErrorMessages
							errorMessageLabels={this.props.errorMessages}
							popUp
							sethaserror={this.sethaserror}
							replaceValues={this.state.parameterValues}
							id={this.state.errorId ? this.state.errorId : this.props.ServerError} />
					</div>) : ('')}
					<div className={classes.notesForBlock}>
						<Box mb={theme.spacing(0.5)} className={classes.notesForLabel}>
							<FormattedMessageComponent id={FROM_EVENT}></FormattedMessageComponent>
						</Box>
						{!loading && valueArrayToEvent && tabcards && tabcards.map(formCard => {
							if (formCard.cardkey == FROM_EVENT) {
								return <FormFieldsGenerator
									labelDisplayCharacters={22}
									valueDisplayCharacters={18}
									className={classes.adjustCardFieldsInline}
									currentOwnerName={currentOwnerName}
									handleSubmitDataCallBack={() => { }}
									key={formCard.cardkey}
									fieldsArray={JSON.parse(JSON.stringify(formCard.cardfields))}
									valuesArray={JSON.parse(JSON.stringify(valueArrayToEvent))}
									handleChangeValue={(key, val) => { this.handleChangeValue(key, val) }}
									enableAddButton={() => { }}
									globalDateFormat={globalDateFormat}
									filterCriteriaDetails={filterCriteriaDetails}
									pageFilterOptions={pageFilterOptions}
									globalFilterOptions={globalFilterOptions}
									columnDefs={columnDefs}
									currentPage={currentPage}
									canUpdateComponent={canUpdateComponent}
									noMassMaintenance={true}
								/>
							}
						})}
					</div>
					<div className={classes.notesForBlock}>
						<Box mb={theme.spacing(0.5)} className={classes.notesForLabel}>
							<FormattedMessageComponent id={TO_EVENT}></FormattedMessageComponent>
						</Box>
						{!loading && valueArrayToEvent && tabcards && tabcards.map(formCard => {
							if (formCard.cardkey == TO_EVENT) {
								return <FormFieldsGenerator
									labelDisplayCharacters={22}
									valueDisplayCharacters={18}
									className={classes.adjustCardFieldsInline}
									currentOwnerName={currentOwnerName}
									handleSubmitDataCallBack={() => { }}
									key={formCard.cardkey}
									fieldsArray={JSON.parse(JSON.stringify(formCard.cardfields))}
									valuesArray={JSON.parse(JSON.stringify(valueArrayToEvent))}
									handleChangeValue={(key, val) => { this.handleChangeValue(key, val) }}
									enableAddButton={() => { }}
									globalDateFormat={globalDateFormat}
									filterCriteriaDetails={filterCriteriaDetails}
									pageFilterOptions={pageFilterOptions}
									globalFilterOptions={globalFilterOptions}
									columnDefs={columnDefs}
									// currentPage={currentPage}
									currentPage={'eventCopy'}

									canUpdateComponent={canUpdateComponent}
									noMassMaintenance={true}
								/>
							}
						})}
					</div>
					<div className={classes.notesForBlock}>
						<Box mb={theme.spacing(0.5)} className={classes.notesForLabel}>
							<FormattedMessageComponent id={OPTIONS_COPY}></FormattedMessageComponent>
						</Box>
						{!loading && valueArrayToEvent && tabcards && tabcards.map(formCard => {
							if (formCard.cardkey == OPTIONS_COPY) {
								return <FormFieldsGenerator
									labelDisplayCharacters={22}
									valueDisplayCharacters={18}
									className={classes.adjustCardFieldsInline}
									currentOwnerName={currentOwnerName}
									handleSubmitDataCallBack={() => { }}
									key={formCard.cardkey}
									fieldsArray={JSON.parse(JSON.stringify(formCard.cardfields))}
									valuesArray={JSON.parse(JSON.stringify(valueArrayToEvent))}
									handleChangeValue={(key, val) => { this.handleChangeValue(key, val) }}
									enableAddButton={() => { }}
									globalDateFormat={globalDateFormat}
									filterCriteriaDetails={filterCriteriaDetails}
									pageFilterOptions={pageFilterOptions}
									globalFilterOptions={globalFilterOptions}
									columnDefs={columnDefs}
									currentPage={'eventCopy'}
									canUpdateComponent={canUpdateComponent}
									noMassMaintenance={true}
								/>
							}
						})}{loading && <Spinner loading type="list" />}
					</div>
					<Box className={classes.adjustShowDetail}>
						<FieldInput field={{ type: 'checkbox', key: 'showDetail' }} value={Number(valueArrayToEvent["showDetail"])}
							onChange={(key, val) => this.handleChangeValue(key, val)} />
						<div className={classes.showDetail}>{this.getLabelValue("25566")}</div>
					</Box>
					{this.state.showValueConfirmationDialog && <ConfirmationDialog
						hasError={true}
						isOpen={this.state.showValueConfirmationDialog}
						dialogTitle={TEXT_ALERT}
						submitText={TEXT_OK}
						handleClose={e => this.closeValueDialog()}
						handleCancel={e => this.closeValueDialog()}
						handleSubmit={e => this.closeValueDialog()}
					>
						<div>
							{this.state.dialogContent}
						</div>
					</ConfirmationDialog>
					}
				</React.Fragment>
			</DialogComponent>
		);
	}
}
const mapStateToProps = createStructuredSelector({
	eventCopy: makeSelectEventCopy(),
	rowData: rowDataSelector(),
	columnDefs: columnDefsSelector(),
	loading: loadingSelector(),
	pageProps: pagePropsSelector(),
	isColumnDefsLoaded: columnFlagSelector(),
	filterProps: filterPropsSelector(),
	columnInfo: columnInfoSelector(),
	isAPIProgress: isAPIProgressSelector(),
	totalCount: totalCountSelector(),
	moreRecordsAvailable: moreRecordsSelector(),
	apiCallCount: apiCallCountSelector(),
	updateColumnsList: updateColumnsListSelector(),
	errorMessages: errorMessageLabels(),
	items: itemsListSelector(),
})

function mapDispatchToProps(dispatch, ownProps) {
	return {
		dispatch,
		getEventCopyList: (data) => dispatch(getEventCopyList(ownProps.nameSpace, data)),
		setApiCallCount: (data) => dispatch(setApiCallCount(ownProps.nameSpace, data)),
		onSetPageProps: (data) => dispatch(onSetPageProps(ownProps.namespace, data)),
		getEventCopyColumnDefs: (data) => dispatch(getEventCopyColumnDefs(ownProps.nameSpace, data)),
		setFilterValues: (data) => dispatch(setFilterValues(ownProps.nameSpace, data)),
		setColumnDefsLoaded: (data) => dispatch(setColumnDefsLoaded(ownProps.nameSpace, data)),
		updateShowHide: (data) => dispatch(updateShowHide(ownProps.nameSpace, data)),
		resetStateData: (data) => dispatch(resetStateData(ownProps.nameSpace, data)),
		resetDefault: (data) => dispatch(resetDefault(data)),
		getItemsList: (data) => dispatch(getItemsList(ownProps.nameSpace, data)),
		setLabelDataFlags: (data) => dispatch(setLabelDataFlags(ownProps.nameSpace, data)),
	}
}

const withConnect = connect(
	mapStateToProps,
	mapDispatchToProps,
);
const withReducer = injectReducer({ key: 'eventCopyReducer', reducer });
const withSaga = injectSaga({ key: 'eventCopySaga', saga });
export default compose(
	withReducer,
	withSaga,
	withConnect,
	withStyles(styles),
)(CopyDialog);
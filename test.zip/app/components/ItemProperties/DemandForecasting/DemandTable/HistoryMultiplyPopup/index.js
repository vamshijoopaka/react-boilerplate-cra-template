import React from 'react';
import DialogComponent from '../../../../common/DialogComponent';
import FormFieldsGenerator from '../../../../common/FormFieldsGenerator';
import { TEXT_CANCEL, TEXT_SUBMIT } from 'containers/common/constants';
import BoxBorder from '../../../../../containers/common/BoxBorder';
import { withStyles, Radio, Box } from '@material-ui/core';
const styles = () => ({
  ffgClass: {
    display: 'grid',
    gridTemplateColumns: 'auto auto',
  },
  wrapper: {
    margin: '1rem'
  },
  radioFFG: {
    '& > div': {
      padding: 0
    }
  }
})
class HistoryMultiplyPopup extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      data: {
        HMULT: "0",
        HDIVD: "0",
        HCOMP: props.valueData.ICOMP,
        HITEM: props.valueData.IITEM,
        HWHSE: props.valueData.IWHSE,
        HVNDR: props.valueData.IVNDR,
        HREGN: props.warehouseDetails?.WREGON || '',
        HFSCT: "1",
      }
    };
  }

  handleChangeValue = (key, value) => {
    if (!value && value !== "")
     return;
    this.setState(({ data }) => ({ data: { ...data, [key]: value } }));
  }
  disableSumit = () => {
    const { data, radioSelected } = this.state;
    if (radioSelected === 'multiplyRadio' && data.HMULT) {
      return !(+data.HMULT);
    }
    if (radioSelected === 'divideRadio' && data.HDIVD) {
      return !(+data.HDIVD);
    }
    return true;
  }
  handleRadio = ({ target: { value = false } = {} }) => {
    this.setState({
      radioSelected: value,
      data: { ...this.state.data, HDIVD: '0', HMULT: '0' }
    })
  }
  handleSubmit = () => {
    let payload = { ...this.state.data };
    payload.HFSCT = payload.HFSCT === "1" ? 'Y' : 'N';
    payload.HACCT = payload.HACCT === "1" ? 'Y' : 'N';
    this.props.historyMultiply(payload);
    this.props.onClose();
  }
  render() {
    const { card, isOpen, onClose, classes } = this.props;
    const { radioSelected = false } = this.state;
    let multiplyField = card.cardfields?.find(ele => ele.FLDID === '9734');
    let divideField = card.cardfields?.find(ele => ele.FLDID === '9735');
    let multipyDisable = true, divideDisable = true;
    if (radioSelected && radioSelected === 'multiplyRadio') {
      multipyDisable = false;
      divideDisable = true;
    }
    else if (radioSelected && radioSelected === 'divideRadio') {
      multipyDisable = true;
      divideDisable = false;
    }
    multiplyField = { ...multiplyField, disabled: multipyDisable };
    divideField = { ...divideField, disabled: divideDisable };
    multiplyField = [multiplyField];
    divideField = [divideField];
    return (
      <div>
        <DialogComponent
          dialogTitle={"28114"}
          submitText={TEXT_SUBMIT}
          cancelText={TEXT_CANCEL}
          isOpen={isOpen}
          handleCancel={onClose}
          handleClose={onClose}
          disableSubmit={this.disableSumit()}
          handleSubmit={this.handleSubmit}
        >
          <BoxBorder className={classes.wrapper}>
            <Box display="flex" marginBottom="1rem">
              <Box display='flex' marginRight="5rem">
                <Radio color="primary"
                  checked={radioSelected === 'multiplyRadio'}
                  onChange={this.handleRadio}
                  value="multiplyRadio"
                />
                <FormFieldsGenerator
                  className={classes.radioFFG}
                  fieldsArray={multiplyField}
                  handleChangeValue={this.handleChangeValue}
                  valuesArray={this.state.data}
                  currentPage="items"
                  enableAddButton={() => { }}
                  noMassMaintenance
                  labelDisplayCharacters={15.5}
                />
              </Box>
              <Box display="flex">
                <Radio color="primary"
                  checked={radioSelected === 'divideRadio'}
                  onChange={this.handleRadio}
                  value="divideRadio"
                />
                <FormFieldsGenerator
                  className={classes.radioFFG}
                  fieldsArray={divideField}
                  handleChangeValue={this.handleChangeValue}
                  valuesArray={this.state.data}
                  currentPage="items"
                  enableAddButton={() => { }}
                  noMassMaintenance
                  labelDisplayCharacters={16}
                />
              </Box>
            </Box>
            <FormFieldsGenerator
              // className={classes.ffgClass}
              fieldsArray={card.cardfields?.filter(ele => ele.FLDID === '3670')}
              handleChangeValue={this.handleChangeValue}
              valuesArray={this.state.data}
              currentPage="items"
              enableAddButton={() => { }}
              noMassMaintenance
              valueDisplayCharacters={54}
            />
            <FormFieldsGenerator
              className={classes.ffgClass}
              fieldsArray={card.cardfields?.filter(ele => !['9734', '9735', '3670'].includes(ele.FLDID))}
              handleChangeValue={this.handleChangeValue}
              valuesArray={this.state.data}
              currentPage="items"
              enableAddButton={() => { }}
              noMassMaintenance
            />
          </BoxBorder>
        </DialogComponent>
      </div>
    );
  }
}

export default withStyles(styles)(HistoryMultiplyPopup);

export const LABEL_NOTE = '25297';
export const BUYER_NOTES = 'buyernotes';
export const BUYER_NOTES_FILTER_PROPS = [
    {"accessor":"FLID","operator":"=","jOpr":"and","key":"FLID","fieldValue":""},
    {"accessor":"FKEY","operator":"=","jOpr":"and","key":"FKEY","fieldValue":""}
]

export const FILTER_DATA = ['COMP', 'BUYR', 'WHSE'];

export const GET_BUYER_NOTES = 'GET_BUYER_NOTES';
export const GET_BUYER_NOTES_SUCCESS = 'GET_BUYER_NOTES_SUCCESS';
export const GET_BUYER_NOTES_FAILURE = 'GET_BUYER_NOTES_FAILURE';
export const CLEAR_NOTES_DATA = 'CLEAR_NOTES_DATA';
export const GET_BUYER_NOTE_DETAILS = 'GET_BUYER_NOTE_DETAILS';
export const GET_BUYER_NOTE_DETAILS_SUCCESS = 'GET_BUYER_NOTE_DETAILS_SUCCESS';
export const GET_BUYER_NOTE_DETAILS_FAILURE = 'GET_BUYER_NOTE_DETAILS_FAILURE';
export const GET_BUYER_NOTES_ALL_SUCCESS = 'GET_BUYER_NOTES_ALL_SUCCESS';
export const SET_BUYER_SELECTED_NOTE_DETAILS = 'SET_BUYER_SELECTED_NOTE_DETAILS';
export const CONTROL_BUYER_NOTE_CREATION = 'CONTROL_BUYER_NOTE_CREATION';
export const CONTROL_BUYER_NOTE_CREATION_SUCCESS = 'CONTROL_BUYER_NOTE_CREATION_SUCCESS';
export const CONTROL_BUYER_NOTE_CREATION_FAILURE = 'CONTROL_BUYER_NOTE_CREATION_FAILURE';
export const SET_BUYER_NOTE_CONTROL_COUNT = 'SET_BUYER_NOTE_CONTROL_COUNT';
export const REMOVE_BUYER_NOTE_OF_KEY = 'REMOVE_BUYER_NOTE_OF_KEY';
export const CLEAR_BUYER_NOTES = 'CLEAR_BUYER_NOTES';
export const SET_IS_EMBEDDED_LIST = 'SET_IS_EMBEDDED_LIST';
export const CLEAR_STATE_VALUES = "CLEAR_STATE_VALUES";

export const NOTES_TEXT_ACCESSOR = 'MFTEXT';
export const NOTES_KEY_ACCESSOR = 'MFKEY';
export const NO_NOTES_TO_SHOW_TEXT = 'No Notes To Show'


export const MENU_BUYERS = [
    {
        label: '51170',
        key: 'Remove All',
        hasSubMenu: false
    },
    {
        label: '25651',
        key: 'note',
        hasSubMenu: false
    }
]


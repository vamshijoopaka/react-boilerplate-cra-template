/** Change Log
 * LogStart --  E3C-33069 - Kumar A- 4 August,2021 - 2022.1.0.0 Unified Product
 *              Story: E3C-33069 --Location Group Changes in Warehouse
                1. Added Location Group 1 to 12 for unified product
            --  E3C- 33249-Sachin-13 october,2021
                Vendor Service Level Goal - Check Box - is not Mass maintenable (Framework Issue)
*/
import React from 'react';
import { compose } from 'redux';
import { connect } from 'react-redux';
import { injectIntl } from 'react-intl';
import { withStyles } from '@material-ui/core/styles';
import Form from '../Form/Form';
import { FormControlLabel, Button, Box, FormLabel, Checkbox } from '@material-ui/core';
import FieldInput from '../Form/FieldInput';
import {
    COLUMN_HEADER_ACCESSOR, COLUMN_USER_SHORT_LABEL, COLUMN_USER_LONG_LABEL,
    COLUMN_SHORT_LABEL,
    PROPERTIES_FIELD_TYPE,
    MENU_ITEMS
} from '../constants';
import { VENDOR_DATA_RESERVED } from '../../VendorProperties/VendorControlFactors/constants';
import { getDateFromJulian, getListPredecessor, getJulianValue, getSearchReplaceSelectTitle, getReplacedKeyString, getPropertiesButtonFilterFields, getDefaultFilterForMassMaintenance } from '../../../utils/util';
import { getDateFormatted } from '../Form/dateTimeUtils';
import { createStructuredSelector } from 'reselect';
import MassMaintenance from 'containers/common/MassMaintenance';
import OpenInNewIcon from '@material-ui/icons/OpenInNew';
import { isValidDate } from 'components/common/Form/dateTimeUtils';
import './style.css';
import {
    selectGlobal,
    makeFilterCriteriaDetails,
    makeSelectCurrentUser,
    makeSelectCurrentPage,
    makeFilterOptions,
    makeGridOptions,
    makePageFilterOptions,
    selectGlobalNumberFormat,
    selectGlobalNumberSeparator,
    selectGlobalDecimalSeparator,
    selectGlobalDateFormat// E3C-30525-Ajit
} from '../Form/selectors';

import {
    GLOBAL_FILTER_OPTIONS,
    COLUMN_VALUE_ACCESSOR,
} from 'components/common/constants';
import { isEqual } from 'lodash';
import FilterCriteria from 'containers/common/FilterCriteria';
import DialogComponent from '../DialogComponent';
import { filterCriteriaMenuItems } from './constants';
import { TEXT_CANCEL, TEXT_OK, TEXT_APPLY, KEY_FILTER } from '../../../containers/common/constants';
import { getUnformattedValue, getFormattedNumber } from '../../../utils/util';
import PropTypes from 'prop-types';
import CustomizedTooltip from '../CustomizedTooltip';
import theme from '../../../jda-gcp-theme';
import { trueDependencies } from 'mathjs';
import FormattedMessageComponent from '../FormattedMessageComponent';
import ExpressionEditor from '../ExpressionEditor';
import { makeSelectCompanyDetails } from 'containers/App/selectors';

const defaultProps = {
    noMassMaintenance: false,
    cardHasCheckBox: false,
    cardHasLabel: false,
    labelDisplayCharacters: 20,
    valueDisplayCharacters: 10,
    cardHasDotsBtn: false
};

const propTypes = {
    currentPage: PropTypes.any,
    labelDisplayCharacters: PropTypes.number, // Label character length eg: 10
    cardHasCheckBox: PropTypes.bool, // true, if card has any field with extra checkbox
    valueDisplayCharacters: PropTypes.number,
    cardHasDotsBtn: PropTypes.bool,
    cardHasLabel: PropTypes.bool
};


const labels = [COLUMN_USER_SHORT_LABEL, COLUMN_USER_LONG_LABEL, COLUMN_SHORT_LABEL, COLUMN_HEADER_ACCESSOR];

const style = theme => ({


    hideField: {
        display: 'none !important'
    },

    fieldExtraActions: {
        display: 'flex',
        alignItems: 'baseline',
        alignSelf: 'flex-end',
    },
    formControl: {
        display: 'flex',
        padding: '5px',
        flexDirection: 'column',
        // justifyContent: 'center',
        alignItems: 'center'
    },
    simpleCardInput: {
        margin: '0',
        width: '100%',
        '& input': {
            overflow: 'hidden',
            whiteSpace: 'nowrap',
            textOverflow: 'ellipsis',
        },
        '&.error-input:after': {
            borderBottom: '2px solid var(--card-error-border) !important'
        },
        '&.error-input:hover::after': {
            borderBottom: '2px solid var(--card-error-border) !important'
        },
    },
    inputErrorClass: {
        '&.error-icon-pure-css': {
            border: '2px solid var(--card-error-border) !important'
        },
        '&.error-icon-pure-css:after': {
            color: 'var(--card-error-border) !important'
        }
    },
    simpleCardCheckbox: {
        padding: '0'
    },
    simpleCardFormLabel: {
        paddingLeft: '50px'
    },
    simpleCardFormCheckLabel: {
        marginLeft: '-12px'
    },
    simpleCardOFormLabel: {
        paddingLeft: '75px',
        width: '170px',
        fontWeight: 'bold',
    },
    simpleCardNotBoldFormLabel: {
        paddingLeft: '75px',
        width: '170px',
    },
    simpleCardSelect: {
        width: '100%',
        overflow: 'hidden',
        // paddingRight: '15px',
        '& [class*="MuiSelect-select"]': {
            display: 'inline-block'
        }
    },
    simpleCardField: {
        // width: '100%',
        display: 'flex',
        // justifyContent: 'flex-end',
        alignItems: 'center',
        // margin: '0 10px 0 0',
        // '@media (max-width : 1024px)': {
        //     flexDirection: 'column-reverse',
        //     alignItems: 'baseline !important',
        //     padding: ' 10px !important',
        // },
        // '& .MuiFormControlLabel-label': {
        //     overflow: 'hidden',
        //     whiteSpace: 'nowrap',
        //     textOverflow: 'ellipsis',
        //     width: '100%',
        // },
        '& label': {
            fontSize: '14px',
            fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
            color: 'var(--text)',
            marginRight: '15px'
        }
    },
    fieldRightMargin: {
        marginRight: '10px !important'
    },
    fieldInput: {
        // maxWidth: props => 'calc(100% - ' + (props.labelDisplayCharacters ? props.labelDisplayCharacters + 'ch' : '20ch') + ' - 15px' + ')',
        // minWidth: props => 'calc(100% - ' + (props.labelDisplayCharacters ? props.labelDisplayCharacters + 'ch' : '20ch') + ' - 15px' + ')',
        width: props => (props.valueDisplayCharacters + 'ch'),
        '& input': {
            color: 'var(--card-field-value) !important',
            width: '100%',
        },
        '& [class*="MuiInputBase-input"]': {
            color: 'var(--card-field-value)',
        },
        '& [class*="MuiInput-underline"]:before': {
            borderBottom: '1px solid var(--card-field-value) !important'
        },
        '& [class*="MuiInput-underline"]:hover::before': {
            borderBottom: '2px solid var(--text) !important'
        },
        '& [class*="MuiInput-underline"]:after': {
            borderBottom: '2px solid var(--inputText-value) !important'
        },
        '& [class*="MuiInput-root"]': {
            maxWidth: 'inherit'
        }
    },
    simpleCheckboxCardField: {
        // justifyContent: 'flex-end !important',
    },
    FormFieldWithMM: {
        position: 'relative',
        display: 'flex',
        alignItems: 'baseline',
        padding: '0 0px 20px 0',
        width: '100%',
    },
    // FormFieldWithoutMM: {
    //     position: 'relative',
    //     display: 'flex',
    //     alignItems: 'baseline',
    //     width: '100%',
    //     paddingBottom: '20px'
    // },
    MassMaintenance: {
        // position: 'absolute',
        cursor: 'pointer',
        height: '18px',
        width: '18px',
        alignSelf: 'flex-end',
        // right: '10px',
        // top: '7px',
    },
    filterCriteriaButton: {
        minWidth: '22px !important',
        width: '22px',
        padding: '3px',
        marginRight: '10px'
    },
    simpleCardLabel: {
        maxWidth: props => props.labelDisplayCharacters ? props.labelDisplayCharacters + 'ch' : '20ch',
        minWidth: props => props.labelDisplayCharacters ? props.labelDisplayCharacters + 'ch' : '20ch',
    },
    simpleCardLabelEmpty: {
        width: '0',
        display: 'none !important'
    },
    expr_btn: {
        marginRight: '15px'
    },
    simpleCardFieldWithCheckBox: {
        width: 'calc(100% - 18px) !important'
    },
    width80: {
        // width: 'calc(100% - 50px) !important'
    },
    fieldAdditionalCheckBox: {
        top: '4px',
        marginRight: '8px'
    },
    fieldAdditionalLabel: {
        top: '4px',
        marginRight: '8px'
    },
    fieldWrapper: {
        display: 'flex'
    },
    fieldLabel: {
        maxWidth: props => props.labelDisplayCharacters ? props.labelDisplayCharacters + 'ch' : '20ch',
        minWidth: props => props.labelDisplayCharacters ? props.labelDisplayCharacters + 'ch' : '20ch',
        overflow: 'hidden',
        whiteSpace: 'nowrap',
        textOverflow: 'ellipsis',
    },
    fieldInputWithoutLabel: {
        width: '100%',
        '& input': {
            color: 'var(--card-field-value) !important'
        },
        '& [class*="MuiInputBase-input"]': {
            color: 'var(--card-field-value)'
        },
        '& [class*="MuiInput-underline"]:before': {
            borderBottom: '1px solid var(--card-field-value) !important'
        },
        '& [class*="MuiInput-underline"]:hover::before': {
            borderBottom: '2px solid var(--text) !important'
        },
        '& [class*="MuiInput-underline"]:after': {
            borderBottom: '2px solid var(--inputText-value) !important'
        },
    },
    fieldSelect: {
        width: '0'
    },
    disabledField: {
        '& [class*="MuiInputBase-input"]': {
            color: 'var(--primary-disabled) !important',
        },
        '& [class*="MuiInput-underline"]': {
            pointerEvents: 'none !important'
        },
        // '& label': {
        //     color: 'var(--primary-disabled) !important'
        // },
        '& [class*="MuiInput-underline"]:before': {
            borderBottom: '1px solid var(--primary-disabled) !important'
        },
        '& [class*="MuiInput-underline"]:hover::before': {
            borderBottom: '1px solid var((--primary-disabled) !important'
        },
    }
});

class FormFieldsGenerator extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            showMassMaintainance: false,
            isOpenMassMaintainance: false,
            selectedField: false,
            fieldsArray: this.props.fieldsArray,
            disableFilterCriteriaSubmit: true,
            isFilterCriteriaOpen: false,
            filterCriteriaField: false,
            fieldFilters: false,
            showValueTooltip: false,
            selectDialogTitle: false,
            menuItems: filterCriteriaMenuItems,
            isOpenSelect: false,
            selectSelectedRows: false,
            displayValue: {},
            isOpenExpressionEditor: false,
            exprField: false,
        }
        this.getFieldValue = this.getFieldValue.bind(this);
        this.openMassMaintainance = this.openMassMaintainance.bind(this);
        this.clearPopupComponent = this.clearPopupComponent.bind(this);
        this.onValueFocusOut = this.onValueFocusOut.bind(this);
        this.clearMassMaintenance = this.clearMassMaintenance.bind(this);
        this.updateFieldError = this.updateFieldError.bind(this);
        this.handleOnChangeDateValues = this.handleOnChangeDateValues.bind(this);
        this.onGridReady = this.onGridReady.bind(this);
        this.handleHoverOff = this.handleHoverOff.bind(this);

    }

    updateFieldError(currentField, value) {
        // field.hasFormError = value;
        // field.showMassMaintenance = value;
        if (this.props.noMassMaintenance) {
            return;
        }
        let fields = this.state.fieldsArray;
        fields = fields.map(field => {
            if (isEqual(field, currentField)) {
                field.showMassMaintenance = value;
                field['hasFormError'] = value;
            }
            return field;
        });
        this.setState({ fieldsArray: fields });
    }
    getDateFormat(format) {
        switch (format) {
            case 'MM/dd/yyyy': return 'MM/DD/yyyy'
            case 'dd/MM/yyyy': return 'DD/MM/yyyy'
            default: return format.toUpperCase();//E3C-31926: Added code to turn to caps
        }
    }
    //E3C-31926:Ajit Removed duplicate method
    // getDateFormat(format) {
    //     switch(format) {
    //       case 'MM/dd/yyyy': return 'MM/DD/yyyy'
    //       case 'dd/MM/yyyy': return 'DD/MM/yyyy'
    //       default: return format
    //     }
    //   }
    //E3C-31926:Ajit Removed duplicate method

    getFieldValue(field, dataType) {
        const { valuesArray, globalDateFormat } = this.props;
        // let key = field.key;
        let valueAccessor = COLUMN_VALUE_ACCESSOR;
        if (field[valueAccessor] && field.fieldType != 'radio') {
            let keyValue = field[valueAccessor].trim();
            let key = field.prefixFlag ? keyValue : getListPredecessor(this.props.currentPage) + keyValue;
            // if(valuesArray[key] == '') return valuesArray[key];
            if (VENDOR_DATA_RESERVED.includes(key) && valuesArray && valuesArray["VRSRVD"]) {//THIS IS TEMPORARY, DISCUSS FOR RESERVED FIELDS
                // return field.FDFTYP=="N"?parseInt(valuesArray["VRSRVD"][key]):valuesArray["VRSRVD"][key];
                // this.props.handleChangeValue(key,valuesArray["VRSRVD"][key],'')
                if (dataType == 'select' && valuesArray["VRSRVD"][key] == "")
                    return " ";
                return valuesArray["VRSRVD"][key];

            }
            // if (key == VENDOR_DATA_RESERVED && valuesArray ) {//THIS IS TEMPORARY, DISCUSS FOR RESERVED FIELDS
            //     return Object.values(valuesArray[key])[0];
            // }

            // if (dataType == 'number') {
            //     if (this.state.displayValue[key])
            //     {
            //         if(field.precisionLength){
            //             return Number(this.state.displayValue[key]).toFixed(field.precisionLength)
            //         }
            //        return this.state.displayValue[key];
            //     }
            // }
            if (dataType == 'number') {
                //MultiCurrency -- JVK -- Start
                if (this.props.canConvertCurrency && this.props.currencySelected && this.props.currencyConversion?.MCFTOL) {
                    if (!field.isEdited && /C|F/.test(field.FDDATR) && this.props.currencySelected === 'local' && !field.doNotConvert) {
                        return getFormattedNumber(String(valuesArray[key] * this.props.currencyConversion.MCFTOL), this.props.globalNumberFormat, this.props.globalNumberSeparator, field.precisionLength, this.props.globalDecimalSeparator);
                    }
                }
                //MultiCurrency -- JVK -- End
                if (this.state.displayValue[key])
                    return this.state.displayValue[key];
                if (field['FDDATR'] && !field['FDDATR'].includes('G'))
                    return getFormattedNumber(valuesArray[key], this.props.globalNumberFormat, this.props.globalNumberSeparator, field.precisionLength, this.props.globalDecimalSeparator);

                return valuesArray[key];
            }

            if (dataType == 'select' && valuesArray[key] == "") {
                return " ";
            } else if (field.fieldType === 'date' && dataType === 'labels' && valuesArray[key]) {
                return getDateFormatted(getDateFromJulian(valuesArray[key]), this.getDateFormat(this.props.globalDateFormat))
            } else {
                return valuesArray[key];
            }
            // return field.FDFTYP=="N"? parseInt(valuesArray[key]):valuesArray[key];
        } else if (field.fieldType == 'radio' && field.valueSuggestionList && field.valueSuggestionList.length && valuesArray) {
            if (field.radioType == 'radioGroup') {
                return valuesArray && Object.keys(valuesArray) && Object.keys(valuesArray).length && valuesArray[field.key];
            } else {
                let keyValue = field[valueAccessor].trim(), keyString = [];
                field.valueSuggestionList.forEach((fieldValue) => {
                    if (fieldValue.key && valuesArray[fieldValue.key]) {
                        keyString.push(valuesArray[fieldValue.key]);
                    }
                });
                if (keyString && keyString.length) {
                    let index = keyString.findIndex((str) => str && Number(str));
                    if (index != -1) {
                        return field.valueSuggestionList[index].key;
                    }
                } else {
                    return '';
                }
            }
        }
    }

    updatecomponent() {
        this.forceUpdate();
    }

    onValueFocusOut(field, val) {
        this.clearMassMaintenance(field, true)
        let key = field.key;
        let value;
        if (val == '' || !val) {
            value = val;
            if (field.dataType == 'number') {
                if (field.minValue != undefined) {
                    value = field.minValue.toString();
                    value = getUnformattedValue(value, this.props.globalNumberFormat, this.props.globalNumberSeparator, this.props.globalDecimalSeparator);
                } else {
                    value = '0';
                }
                if (field.precisionLength) {
                    value = Number(value).toFixed(field.precisionLength);
                }
            }
            this.handleChangeValue(field.key, value, field, this.props.handleFocusOut);
            return;
        }
        if (VENDOR_DATA_RESERVED.includes(key) && val) {//THIS IS TEMPORARY, DISCUSS FOR RESERVED FIELDS
            value = Object.values(val)[0];
            this.handleChangeValue(field.key, value, field, this.props.handleFocusOut);
            return;
        }
        if (field.dataType == 'date' && val) {
            value = JSON.parse(JSON.stringify(getDateFromJulian(val)));
            if (isValidDate(val)) {
                value = getJulianValue(val);
            } else {
                return;
            }
            this.handleChangeValue(field.key, value, field, this.props.handleFocusOut);
            return;
        }
        if (field.precisionLength) {
            if (Number(val).toString() == 'NaN') {
                this.handleChangeValue(field.key, val, field, this.props.handleFocusOut);
                return;
            }
            value = field.dataType === 'number' ? Number(val).toFixed(field.precisionLength) : val;
            this.handleChangeValue(field.key, value, field, this.props.handleFocusOut);
            return;
        }
        if (field.dataType === 'checkbox') {
            value = Number(val);
            this.handleChangeValue(field.key, value.toString(), field, this.props.handleFocusOut);
            return;
        }
        if (val == undefined) {
            value = '';
            this.handleChangeValue(field.key, value, field, this.props.handleFocusOut);
            return;
        }
        if (this.props.handleFocusOut) {
            this.props.handleFocusOut(field.key, val, field);
        }
    }

    handleChangeValue = (key, value, field, method) => {
        this.props.handleChangeValue(key, value, field);
        if (method) {
            method(key, value, field)
        }

        if (field['FLDTYPE'] == 'COMBOBOX') {
            if (!field.hasFormError) {
                this.setState({ selectedField: field });
            }
        }

    }

    clearMassMaintenance(currentField, onFocusOut) {
        if (this.props.noMassMaintenance) {
            return;
        }
        const { isHeader } = this.props;
        let fields = this.state.fieldsArray;
        fields = fields.map(field => {
            if (isEqual(field, currentField) && !(field.hasFormError)) {
                field.showMassMaintenance = true;
            //Begin E3C-33249,Sachin   
                if (field.checkfieldJson)
                    field.checkfieldJson.showMassMaintenance = false; 
            } else if (field.checkfieldJson && !(field.hasFormError) && isEqual(field.checkfieldJson, currentField) ){
                field.checkfieldJson.showMassMaintenance = true;
                field.showMassMaintenance = false;
            }else {
                field.showMassMaintenance = false;
                if (field.checkfieldJson)
                field.checkfieldJson.showMassMaintenance = false;
            }
            //End E3C-33249
            return field;
        });
        this.setState({ fieldsArray: fields });
        if (isHeader && onFocusOut) {
            setTimeout(
                function () {
                    currentField.showMassMaintenance = false;
                    this.updatecomponent();
                }
                    .bind(this),
                2000
            );
        }
        this.updatecomponent();
    }

    onFocus(field) {
        this.clearMassMaintenance(field);
        if (!field.hasFormError) {
            this.setState({ selectedField: field });
        }
    }

    openMassMaintainance() {
        this.setState({ isOpenMassMaintainance: true });
    }

    clearPopupComponent() {
        this.setState({ isOpenMassMaintainance: false });
    }

    handleOnChangeDateValues(key, val, field, isCheckBoxValue) {

        let value = val, displayValue = this.state.displayValue;
        if (field.dataType == 'number') {
            if (val.trim() == '') {
                val = '';
            }
            //comma seperator code
            // displayValue[key] = val;
            // if (!val.includes(this.props.globalDecimalSeparator) && field.numberType == 'decimal')
            //     val = val.replaceAll(this.props.globalNumberSeparator, '')
            // value = getUnformattedValue(val, this.props.globalNumberFormat, this.props.globalNumberSeparator, this.props.globalDecimalSeparator,field.numberType);
            displayValue[key] = value;
            this.setState({ displayValue });
            //value = getUnformattedValue(val, this.props.globalNumberFormat, this.props.globalNumberSeparator, this.props.globalDecimalSeparator);
            //comma seperator code
        } else {
            displayValue[key] = null;
        }
        this.setState({ displayValue });

        let fieldKey = key;
        if (field.dataType === 'checkbox') {
            value = val.toString();
            this.clearMassMaintenance(field);
            this.setState({ selectedField: field });
        }
        if (isCheckBoxValue) {
            // fieldKey = fieldKey + 'CB';
        }
        if (field['FLDTYPE'] == 'COMBOBOX') {
            this.clearMassMaintenance(field);
            if (!field.hasFormError) {
                this.setState({ selectedField: field });
            }
        }
        //MultiCurrency -- JVK -- Start
        if (/C|F/.test(field.FDDATR) && this.props.canConvertCurrency && this.props.currencySelected === 'local') {
            // field.isEdited = true;
            this.setState(({ fieldsArray }) => ({
                fieldsArray: fieldsArray.map(fieldMap => {
                    if (fieldMap.FLDID === field.FLDID && !field.isEdited) {
                        let factor = 1;
                        if (this.props.currencyConversion?.MCFTOL)
                            factor = this.props.currencyConversion.MCFTOL;
                        const [maxValue, minValue] = [field.maxValue, field.minValue].map(ele => Number((ele * factor).toFixed(field.precisionLength)));
                        return { ...field, isEdited: true, maxValue, minValue };
                    }
                    return fieldMap;
                })
            }))
        }
        //MultiCurrency -- JVK -- End
        this.props.handleChangeValue(fieldKey, value.toString(), field)
    }
    setFilterCriteriaDisable = (val) => {
        this.setState({ disableFilterCriteriaSubmit: val });
    }
    onFilterCriteriaReady = (paramsApi) => {
        this.filterCriteriaGridApi = paramsApi;
        this.setFilterCriteriaDisable(true);
    }
    handleFilterCriteriaSubmit = () => {
        this.handleFilterCriteriaClose(false);
    }
    handleFilterCriteriaClose = (val, field, defaultFilters = false) => {
        const { valuesArray, parentPage, columnDefs } = this.props;
        if (val && !defaultFilters) {
            {
                field == 'Warehouses' ?
                    this.setState({ fieldFilters: [{ "accessor": "COMP", "operator": "=", "fieldValue": valuesArray.VCOMP, "prefixFlag": 0, "value": valuesArray.VCOMP }, { "accessor": "TIER", "operator": ">", "fieldValue": valuesArray.VMWTIR, "prefixFlag": 1, "value": valuesArray.VMWTIR }] })
                    : field == 'Profiles' ? this.setState({ fieldFilters: [{ "accessor": "PTYPE", "operator": "=", "fieldValue": "L", "prefixFlag": 0, "value": "L" }] })
                        : field == 'Buyers' ? this.setState({ fieldFilters: [{ "accessor": "COMP", "operator": "=", "fieldValue": valuesArray.VCOMP, "prefixFlag": 0, "value": valuesArray.VCOMP }, { "accessor": "WHSE", "operator": "=", "fieldValue": valuesArray.VWHSE, "prefixFlag": 0 }] })
                            : ""
                if (field == 'dailyprofiles') {
                    valuesArray.IPERDH == "52" ?
                        this.setState({ fieldFilters: [{ "accessor": "COMP", "operator": "=", "fieldValue": valuesArray.ICOMP, "prefixFlag": 1, "value": valuesArray.ICOMP }, { "accessor": "TTYPE", "operator": "=", "fieldValue": "WP", "prefixFlag": 1, "value": "WP" }] })
                        : valuesArray.IPERDH == "52" ? this.setState({ fieldFilters: [{ "accessor": "COMP", "operator": "=", "fieldValue": valuesArray.ICOMP, "prefixFlag": 1, "value": valuesArray.ICOMP }, { "accessor": "TTYPE", "operator": "=", "fieldValue": "MP", "prefixFlag": 1, "value": "MP" }] })
                            : this.setState({ fieldFilters: [{ "accessor": "COMP", "operator": "=", "fieldValue": valuesArray.ICOMP, "prefixFlag": 1, "value": valuesArray.ICOMP }] })
                }//E3C-33069 , 8/4/21, Kumar:Start
                if (field.includes('LocationGroup')) {
                    this.setState({ fieldFilters: [{ "accessor": "COMP", "operator": "=", "fieldValue": this.props.companyDetails.CCOMP, "prefixFlag": 0, "value": 'E3T' }, { "accessor": "MDTYPE", "operator": "=", "fieldValue": "LG", "prefixFlag": 1, "value": "LG" }] })
                }//E3C-33069 , 8/4/21, Kumar:End
            };
            this.setState({ filterCriteriaField: field });
            field != 'dailyprofiles' ? field.includes('LocationGroup') ? this.setState({ selectDialogTitle: "Location Group" }) : this.setState({ selectDialogTitle: field }) : this.setState({ selectDialogTitle: "Daily Profiles" }); //E3C-33069 , 8/4/21, Kumar:Added Location group
        }
        if (val && defaultFilters) {
            this.setState({ filterCriteriaField: field, selectDialogTitle: field });
            this.setState({ fieldFilters: [{ "accessor": "COMP", "operator": "=", "fieldValue": 'E3T', "prefixFlag": 0, "value": 'E3T' }] })
        }
        this.setState({ isOpenSelect: val })
    }


    componentDidUpdate(prevProps, prevState) {
        const { fieldsArray, valuesArray } = this.props;
        if (fieldsArray && !isEqual(fieldsArray, prevProps.fieldsArray)) {
            this.setState({ fieldsArray: fieldsArray });
        }

        if (this.props.currentPage == 'vendors') {
            if (fieldsArray && !isEqual(fieldsArray, prevState.fieldsArray)) {
                let isEqualflag = 0
                //let newfieldsArray=this.state.fieldsArray
                const fieldsArrayManipulated = fieldsArray.map((fieldval, index) => {
                    if (prevState.fieldsArray[index] && prevState.fieldsArray[index]['showMassMaintenance'])
                        if (fieldval['showMassMaintenance'] != prevState.fieldsArray[index]['showMassMaintenance']) {
                            isEqualflag = 1
                            //newfieldsArray[index]['showMassMaintenance']=false
                        }
                    if (prevState.fieldsArray[index]?.isEdited) {
                        const { maxValue, minValue } = prevState.fieldsArray[index];
                        return { ...fieldval, isEdited: true, maxValue, minValue };
                    }
                    return fieldval;
                })
                if (isEqualflag)
                    this.setState({ fieldsArray: fieldsArrayManipulated })
            }
        }
        //JVK if field.dataType=="number" getFieldValue is taking values from state.displayValue which is retaining old values even after valuesArray is changed
        if (valuesArray && !isEqual(valuesArray, prevProps.valuesArray)) {
            this.setState({ displayValue: valuesArray });
        }
        //MultiCurrency -- JVK -- Start
        if (this.props.currencySelected === 'foreign' && this.props.currencySelected !== prevProps.currencySelected && this.props.currencyConversion?.MCLTOF) {
            this.setState(({ displayValue }) => ({
                fieldsArray: fieldsArray.map(field => {
                    if (/C|F/.test(field.FDDATR) && field.isEdited) {
                        // field.isEdited = false
                        if (displayValue?.[field.key]) {
                            displayValue[field.key] = String(displayValue[field.key] * this.props.currencyConversion.MCLTOF);
                        }
                        return { ...field, isEdited: false };
                    }
                    return field;
                })
            }))
        }
        //MultiCurrency -- JVK -- End

    }
    getFieldCheckValue = (field, dataType) => {
        let prefix = getListPredecessor(this.props.currentPage);
        let key = !field.prefixFlag ? prefix + field[COLUMN_VALUE_ACCESSOR].trim() : field[COLUMN_VALUE_ACCESSOR].trim();
        // key = key + 'CB';
        return this.props.valuesArray[key] || false;
    }
    getFieldLabelValue = (field, dataType) => {
        let prefix = getListPredecessor(this.props.currentPage);
        let key = !field.prefixFlag ? prefix + field[COLUMN_VALUE_ACCESSOR].trim() : field[COLUMN_VALUE_ACCESSOR].trim();
        return this.props.valuesArray[key] || false;
    }
    isEllipsisActive = (el) => {
        if (!el) return false;
        return el.offsetWidth + 1 < el.scrollWidth //E3C-32619:Ajit
    }
    setShowValueTooltip = (val) => {
        this.setState({ showValueTooltip: val });
    }
    getValueForTooltip = (field, dataType) => {
        const { valuesArray, globalDateFormat } = this.props;
        // let key = field.key;
        let valueAccessor = COLUMN_VALUE_ACCESSOR;
        if (field[valueAccessor]) {
            let keyValue = field[valueAccessor].trim();
            let key = field.prefixFlag ? keyValue : getListPredecessor(this.props.currentPage) + keyValue;
            if (!valuesArray[key]) return "";
            if (dataType == 'date' && valuesArray) {
                let val = getDateFormatted(valuesArray[key], globalDateFormat);
                // return val;
                return ""
            } else if (dataType == 'select') {
                let option = field.valueSuggestionList.find(opt => opt.value === valuesArray[key]);
                return option?.label ? option.label : ""
            } else if (dataType == 'number') {
                //MultiCurrency -- JVK -- Start
                if (this.props.canConvertCurrency && this.props.currencySelected && this.props.currencyConversion?.MCFTOL) {
                    if (!field.isEdited && /C|F/.test(field.FDDATR) && this.props.currencySelected === 'local' && !field.doNotConvert) {
                        return getFormattedNumber(String(valuesArray[key] * this.props.currencyConversion.MCFTOL), this.props.globalNumberFormat, this.props.globalNumberSeparator, field.precisionLength, this.props.globalDecimalSeparator);
                    }
                }
                //MultiCurrency -- JVK -- End
                if (field['FDDATR'] && !field['FDDATR'].includes('G'))
                    return getFormattedNumber(valuesArray[key], this.props.globalNumberFormat, this.props.globalNumberSeparator, field.precisionLength, this.props.globalDecimalSeparator);

            }
            return valuesArray[key];
        }
    }
    getLabelToDisplay = (field, forTooltip) => {
        const { labelDisplayCharacters } = this.props;
        let displayLabel = "";
        for (const label in labels) {
            if (field[labels[label]] && (field[labels[label]].trim() !== '') && !displayLabel.length)
                displayLabel = field[labels[label]].trim();
        }
        if (forTooltip) {
            displayLabel = displayLabel.length > labelDisplayCharacters ? displayLabel : "";
        } else {
            displayLabel = displayLabel.length > labelDisplayCharacters ? displayLabel.substr(0, labelDisplayCharacters) + '...' : displayLabel;
        }
        return displayLabel;
    }
    updateMenuItems = items => {
        this.setState({ menuItems: items })
    }
    setSelectSubmit = (val) => {
        this.setState({ enableSelectSubmit: val });
    }
    sendSelectedRows = (data) => {
        this.setState({ selectSelectedRows: data });
    }
    onSelectGridReady = (paramsApi) => {
        this.filterCriteriaGridApi = paramsApi;
        this.setSelectSubmit(false);
    }
    onGridReady(params) {
        this.grid = params;
    }
    handleSelectSubmit = (data) => {
        const prefix = getListPredecessor(this.props.currentPage)
        this.state.selectSelectedRows[0].hasOwnProperty("PPRFL") && this.props.parentPage == "items" ? this.props.handleChangeValue("ILTPRF", this.state.selectSelectedRows[0].PPRFL, '') :
            this.state.selectSelectedRows[0].hasOwnProperty("DPRFL") ? this.props.handleChangeValue("DLYPR", this.state.selectSelectedRows[0].DPRFL, '') :
                this.state.selectSelectedRows[0].hasOwnProperty("WWHSE") ? this.props.handleChangeValue("VPVDID", this.state.selectSelectedRows[0].WWHSE, ' ') :
                    this.state.selectSelectedRows[0].hasOwnProperty("MDID") ? this.props.handleChangeValue("WLGP"+ this.state.filterCriteriaField.trim().match(/(\d+)/)[0], this.state.selectSelectedRows[0].MDID, ' ') :  //E3C-33069 , 8/4/21, Kumar
                        this.state.selectSelectedRows[0].hasOwnProperty("BBUYR") ? this.props.handleChangeValue(prefix + "BUYR", this.state.selectSelectedRows[0].BBUYR, '') : this.props.handleChangeValue("VLTPRF", this.state.selectSelectedRows[0].PPRFL, '')
        this.setState({ isOpenSelect: false });
        this.props.enableAddButton?.(true)
    }

    handleSelectClose = () => {
        this.setState({ isOpenSelect: false });
    }

    showHideMassMaintainence = (field, fieldsArray) => {
        const { canUpdateComponent } = this.props;
        if (fieldsArray.filter(x => x['FLDID'] == field['FLDID'])[0] && fieldsArray.filter(x => x['FLDID'] == field['FLDID'])[0]['FDZAPO'] == 'M') {
            if (canUpdateComponent && Object.keys(canUpdateComponent) && Object.keys(canUpdateComponent).length) {
                if (canUpdateComponent.update && !field.disabled && !this.isDisabledForCurrency(field))
                    return field.showMassMaintenance;
                else
                    return false;
            } else
                return field.showMassMaintenance;
        }
        //Begin E3C-33249,Sachin
        else{
            var bFound=0
            for(var i=0;i<fieldsArray.length;i++){
                if(fieldsArray[i].hasCheckbox && fieldsArray[i].checkfieldJson){
                    if(fieldsArray[i].checkfieldJson['FLDID']==field['FLDID']){
                        if(field['FDZAPO']=='M'){
                            if (canUpdateComponent && Object.keys(canUpdateComponent) && Object.keys(canUpdateComponent).length) {
                                if (canUpdateComponent.update && !field.disabled && !this.isDisabledForCurrency(field)){
                                    bFound=1
                                    break
                                }                                    
                            } 
                        }
                    }
                }
            }

            if(bFound)
                return field.showMassMaintenance
            //End E3C-33249    
            return false;
        }
    }

    isFieldDisabled = (field, canUpdateComponent) => {
        //MultiCurrency -- JVK -- Start
        if (this.props.canConvertCurrency && this.props.currencySelected) {
            if (this.isDisabledForCurrency(field))
                return true;
        }
        //MultiCurrency -- JVK -- End

        if (field && field.hasOwnProperty('disabled') && field.disabled) {
            return true;
        }
        else {
            return canUpdateComponent && Object.keys(canUpdateComponent) && Object.keys(canUpdateComponent).length ? !canUpdateComponent.update : Boolean(field.disabled);
        }
    }

    //MultiCurrency -- JVK -- Start
    isDisabledForCurrency = field => {
        if (
            field.FDDATR && field.FDDATR.includes('C') && this.props.currencySelected === 'foreign' ||
            field.FDDATR && field.FDDATR.includes('F') && this.props.currencySelected === 'local'
        ) {
            return !this.props?.canUpdateComponent?.update || true;
        }
        return field.disabled;
    }
    //MultiCurrency -- JVK -- End

    onExpressionClick = (field) => {
        this.setState({ isOpenExpressionEditor: true, exprField: field })
    }

    getExpressionToChild = () => {
        const key = !this.state.exprField?.prefixFlag ? getListPredecessor(this.props.currentPage) + this.state.exprField[COLUMN_VALUE_ACCESSOR]?.trim() : this.state.exprField[COLUMN_VALUE_ACCESSOR]?.trim()
        return this.props.valuesArray[key] ? this.props.valuesArray[key] : '';
    }

    closeExpressionEditor = (val, flag) => {
        this.setState({ isOpenExpressionEditor: false, exprField: false })
        if (!flag) return;
        this.props.handleChangeValue(this.state.exprField.key, val, this.state.exprField)
    }
    handleHoverOff() {
        //Fix for E3C-30680
        if (!this.props.noMassMaintenance) {
            let fields = this.state.fieldsArray;
            fields = fields.map(field => {

                field.showMassMaintenance = false;
                if (field.checkfieldJson)       //Fix for E3C-33249,Sachin
                    field.checkfieldJson.showMassMaintenance = false;
                return field;
            });
            this.setState({ fieldsArray: fields });
        }
        //End
    }
    disableRowsForFilterCriteria = () => {
        if (this.state.selectDialogTitle == "Buyers")
            return [];

        if (this.props.selectFilters?.length)
            return this.props.selectFilters.map(row => row.accessor);

        return this.state.fieldFilters.map?.(row => row.accessor);
    }
    render() {
        const { classes, className, handleChangeValue, enableAddButton, hideLabels, propertiesData, valuesArray, noMassMaintenance, globalNumberFormat,
            globalNumberSeparator, parentInputWrapper, parentFieldWrapper, parentFormField, canUpdateComponent, cardHasDotsBtn, cardHasCheckBox, globalDecimalSeparator,
            hasMaintainancePopup, globalDateFormat } = this.props;
        const { fieldsArray } = this.state;
        return (
            <div onMouseLeave={this.handleHoverOff}>
                <Form>
                    {({ errors, onChange, validate, values }) => (
                        <div className={classes.formControl + ' ' + className}>{
                            fieldsArray && fieldsArray.length ? fieldsArray.map(field => {
                                return <div key={field.key} className={(classes.FormFieldWithMM) + " formField " + parentFormField + " " + (field.hide ? classes.hideField : "")}>


                                    <Box className={classes.fieldWrapper + " " + classes.simpleCardField + " " + (!noMassMaintenance || cardHasDotsBtn || cardHasCheckBox ? classes.fieldRightMargin : "") + " " + (field.dataType == 'checkbox' ? classes.simpleCheckboxCardField : "") + " "
                                        + parentFieldWrapper + " " + (this.isFieldDisabled(field, canUpdateComponent) ? classes.disabledField : "") + " "
                                    }>
                                        {!hideLabels || !field.hideLabel ? <CustomizedTooltip title={this.getLabelToDisplay(field, true)}>
                                            <label className={classes.fieldLabel + " " + (hideLabels || field.hideLabel ? classes.simpleCardLabelEmpty : classes.simpleCardLabel)}>{this.getLabelToDisplay(field, false)}</label>

                                        </CustomizedTooltip> : ""}
                                        {field.hasExpressionBtn ?
                                            <div className={classes.fieldLabel + " " + classes.simpleCardLabel + " " + classes.expr_btn}>
                                                <Button variant="outlined" color="primary" disabled={this.isFieldDisabled(field, canUpdateComponent)}
                                                    onClick={() => this.onExpressionClick(field)}
                                                >{<FormattedMessageComponent id={'2902'} />}</Button>
                                            </div> : ''
                                        }
                                        <CustomizedTooltip title={this.isEllipsisActive(document.getElementById(field.key ? field.key : (field[COLUMN_VALUE_ACCESSOR] ? field[COLUMN_VALUE_ACCESSOR].trim() : false))) ? this.getValueForTooltip(field, field.dataType) : ""}>
                                            <div onMouseOver={() => this.setShowValueTooltip(true)}
                                                onMouseOut={() => this.setShowValueTooltip(false)}
                                                className={(hideLabels ? classes.fieldInputWithoutLabel : classes.fieldInput) + ' ' + (field.dataType === 'select' ? classes.fieldSelect : "") + ' ' + parentInputWrapper}
                                            >
                                                <FieldInput
                                                    parentErrorClass={classes.inputErrorClass}
                                                    updateFieldError={(fieldVal, val) => this.updateFieldError(field, val)}
                                                    className={field.dataType == 'checkbox' ? classes.simpleCardCheckbox : field.dataType == 'select' ? classes.simpleCardSelect : classes.simpleCardInput}
                                                    value={this.getFieldValue(field, field.dataType)}
                                                    field={{
                                                        type: field.dataType,
                                                        options: field.valueSuggestionList ? field.valueSuggestionList : [],
                                                        key: field.key ? field.key : (field[COLUMN_VALUE_ACCESSOR] ? field[COLUMN_VALUE_ACCESSOR].trim() : ""),
                                                        Attr: field.FDDATR ? field.FDDATR : ' '
                                                    }}
                                                    isCheckWildCard={field.isCheckWildCard}
                                                    toUppercase={field.toUppercase}
                                                    isNegative={field.isNegative}
                                                    numberType={field.numberType}
                                                    precisionLength={field.precisionLength}
                                                    maxLength={Number(field.maxLength)}
                                                    minValue={field.minValue}
                                                    maxValue={field.maxValue}
                                                    disabled={this.isFieldDisabled(field, canUpdateComponent)}
                                                    onChange={(key, val) => {
                                                        if (field.hasExpressionBtn) {
                                                            return
                                                        }
                                                        onChange(key, val),
                                                            this.handleOnChangeDateValues(key, val, field)
                                                    }}
                                                    errorMessageLabel={field.hasExpressionBtn ? '' : field[COLUMN_HEADER_ACCESSOR]}
                                                    onFocus={() => this.onFocus(field)}
                                                    onFocusOut={() => this.onValueFocusOut(field, this.getFieldValue(field, field.dataType))}
                                                    onBlurMinValidate={(obj) => { enableAddButton?.(obj.isMinMaxConditionValid) }}
                                                    enableAddButton={e => enableAddButton?.(e)}
                                                    globalNumberFormat={globalNumberFormat}
                                                    globalDecimalSeparator={globalDecimalSeparator}
                                                    globalNumberSeparator={globalNumberSeparator}
                                                    globalDateFormat={globalDateFormat}// E3C-30525
                                                    rowsMax={field.rowsMax}
                                                    rowsMin={field.rowsMin}
                                                    fieldType={field.FDFTYP}
                                                ></FieldInput>
                                            </div>
                                        </CustomizedTooltip>
                                    </Box>

                                    {this.showHideMassMaintainence(field, fieldsArray) && !field.noMassMaintenance ?
                                        (<OpenInNewIcon className={classes.MassMaintenance} onClick={this.openMassMaintainance} />)
                                        : (noMassMaintenance ? "" : <div className={classes.MassMaintenance} />)
                                    }
                                    {cardHasDotsBtn && field.hasDotBtn ?
                                        <Button variant="outlined" size="small" color="primary" className={classes.filterCriteriaButton}
                                            disabled={canUpdateComponent && Object.keys(canUpdateComponent) && Object.keys(canUpdateComponent).length ? !canUpdateComponent.update : Boolean(field.disabled)}
                                            // onClick={() => { this.handleFilterCriteriaClose(true, field["dotButtonField"].trim() === "IDA_SEL_ITEM" ? 'Buyers' : 'Warehouses') }}> {/* field[COLUMN_HEADER_ACCESSOR] instead of harded value*/}
                                            onClick={() => {
                                                this.handleFilterCriteriaClose(true, field["dotButtonField"].trim() === "IDA_SEL_ITEM" ? 'Buyers' :
                                                    field["dotButtonField"].trim() === "IDA_SELECT_PROFILE" ? 'Profiles' :
                                                        field["dotButtonField"].trim() === "IDA_SELECT_DAILY_PROFILE" ? 'dailyprofiles' :
                                                            field["dotButtonField"].trim() === "IDA_BUYERS" ? 'Buyers' :
                                                                field[COLUMN_VALUE_ACCESSOR].includes("LGP") && field["dotButtonField"].trim() === "IDA_SEL_LOCATION_GROUP" ? 'LocationGroup' + field[COLUMN_VALUE_ACCESSOR].trim().match(/(\d+)/)[0] : //E3C-33069 , 8/4/21, Kumar
                                                                    'Warehouses', field["dotButtonField"].trim() === "IDA_BUYERS")
                                            }}> {/* field[COLUMN_HEADER_ACCESSOR] instead of harded value*/}
                                            {/* onClick={() => { this.handleFilterCriteriaClose(true, 'buyer id' ) }}> field[COLUMN_HEADER_ACCESSOR] instead of harded value */}
                                            {'...'}
                                        </Button> : null}
                                    {field.hasCheckbox && this.props.cardHasCheckBox && field.checkfieldJson ? <FieldInput
                                        className={classes.simpleCardCheckbox + ' ' + classes.fieldAdditionalCheckBox}
                                        value={this.getFieldCheckValue(field.checkfieldJson, field.checkfieldJson.dataType)}
                                        field={{
                                            type: 'checkbox',
                                            key: field.checkfieldJson.key
                                        }} disabled={this.isFieldDisabled(this.props.currentPage != 'warehouseControlFactors' ? field : field.checkfieldJson, canUpdateComponent)}

                                        onChange={(key, val) => {
                                            this.handleOnChangeDateValues(key, val, field.checkfieldJson, true)
                                        }}
                                    ></FieldInput> : ""}
                                    {/*Begin E3C-33249 Sachin */}
                                     {field.hasCheckbox && field.checkfieldJson && this.showHideMassMaintainence(field.checkfieldJson, fieldsArray) && !field.noMassMaintenance ?
                                        (<OpenInNewIcon className={classes.MassMaintenance} onClick={this.openMassMaintainance} />)
                                        : (noMassMaintenance ? "" : <div className={classes.MassMaintenance} />)
                                    }
                                    {/*End E3C-33249 */}
                                    {field.hasLabel && field.hasCheckbox && this.props.cardHasLabel && this.props.cardHasCheckBox
                                        && field.labelJson && field.checkfieldJson ? <FormLabel
                                            className={classes.simpleCardFormLabel + ' ' + classes.fieldAdditionalLabel}
                                        >{field.labelJson.FLDTYPE == 'checkbox' ? <Checkbox
                                            className={classes.simpleCardFormCheckLabel}
                                            disabled={true}
                                            checked={this.getFieldLabelValue(field.labelJson, field.labelJson.dataType) == '1' ? true : false}
                                            color="primary"
                                            inputProps={{ 'aria-label': 'secondary checkbox' }}
                                        /> : this.getFieldLabelValue(field.labelJson, field.labelJson.dataType)}</FormLabel> : ""}
                                    {field.hasLabel && !field.hasCheckbox && this.props.cardHasLabel && field.labelJson ? <FormLabel
                                        className={field.FLDID == '' ? classes.simpleCardOFormLabel : classes.simpleCardNotBoldFormLabel + ' ' + classes.fieldAdditionalLabel}
                                    >{this.getFieldLabelValue(field.labelJson, field.labelJson.dataType)}</FormLabel> : ""}
                                </div>
                            }) : ''}</div>
                    )}
                </Form>
                {this.state.isOpenMassMaintainance && this.state.selectedField &&
                    <MassMaintenance
                        hasBackArrow={hasMaintainancePopup}
                        handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                        filterCriteriaDetails={this.props.filterCriteriaDetails}
                        pageFilterOptions={this.props.pageFilterOptions}
                        globalFilterOptions={this.props.globalFilterOptions}
                        columnDefs={this.props.columnDefs}
                        currentPage={this.props.currentPage}
                        parentPage={this.props.parentPage}
                        parentSubPage={this.props.parentSubPage}
                        ownerName={this.props.currentOwnerName}
                        isOpen={this.state.isOpenMassMaintainance}
                        field={this.state.selectedField}
                        parentData={this.props.parentData}
                        clearPopupComponent={(val) => this.clearPopupComponent()}
                    >
                    </MassMaintenance>
                }
                {this.state.isOpenSelect &&
                    <DialogComponent
                        dialogTitle={this.state.selectDialogTitle}
                        cancelText={TEXT_CANCEL}
                        submitText={TEXT_OK}
                        handleClose={this.handleSelectClose}
                        handleCancel={this.handleSelectClose}
                        isOpen={this.state.isOpenSelect}
                        disableSubmit={!this.state.selectSelectedRows.length}
                        isBackArrow
                        handleSubmit={this.handleSelectSubmit}>
                        <FilterCriteria
                            filterCriteria={{
                                open: true,
                                apiFlag: getReplacedKeyString(this.state.selectDialogTitle),
                                parentFlag: 'searchReplaceSelect'
                            }}
                            currentPage={getReplacedKeyString(this.state.selectDialogTitle)}
                            onFilterCriteriaReady={this.onSelectGridReady}
                            menuItems={this.state.menuItems}
                            updateMenuItems={items => this.updateMenuItems(items)}
                            enableSubmit={() => this.setSelectSubmit(true)}
                            listTitle={'ADDED FILTERS'}
                            gridRowSelection={'single'}
                            disableRows={this.disableRowsForFilterCriteria()}
                            parentFilterProps={this.props.selectFilters || this.state.fieldFilters}
                            sendSelectedRows={this.sendSelectedRows}
                            namespace={'searchReplaceSelectFilterCriteria'}
                        ></FilterCriteria>
                    </DialogComponent>
                }
                {this.state.isOpenExpressionEditor &&
                    <ExpressionEditor
                        expressionData={this.getExpressionToChild()}
                        closeExpressionEditor={(val, flag) => this.closeExpressionEditor(val, flag)}
                        columnDefs={this.props.expressionColumnData}
                        isOpen={this.state.isOpenExpressionEditor}
                        globalNumberFormat={this.props.globalNumberFormat}
                        globalNumberSeparator={this.props.globalNumberSeparator}
                        globalDecimalSeparator={this.props.globalDecimalSeparator}
                    ></ExpressionEditor>
                }
            </div>
        );
    }
}

const mapStateToProps = createStructuredSelector({
    // currentPage: makeSelectCurrentPage(),
    globalFilterOptions: makeFilterOptions(),
    pageFilterOptions: makePageFilterOptions(),
    gridOptions: makeGridOptions(),
    filterCriteriaDetails: makeFilterCriteriaDetails(),
    globalNumberFormat: selectGlobalNumberFormat(),
    globalNumberSeparator: selectGlobalNumberSeparator(),
    globalDecimalSeparator: selectGlobalDecimalSeparator(),
    globalDateFormat: selectGlobalDateFormat(),// E3C-30525-Ajit
    companyDetails: makeSelectCompanyDetails()
});

const withConnect = connect(mapStateToProps, null);

FormFieldsGenerator.defaultProps = defaultProps;
FormFieldsGenerator.propTypes = propTypes;

export default compose(withConnect, withStyles(style))(FormFieldsGenerator);
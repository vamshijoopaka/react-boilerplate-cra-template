import { withStyles } from '@material-ui/core/styles';
import {
  ITEMS_LIST_PAGE,
} from 'components/common/constants';
import PropTypes from 'prop-types';
import React from 'react';
import {
  getCompanyInfo,
} from '../../../utils/util';
import CardComponent from '../../common/CardComponent';
import FormFieldsGenerator from '../../common/FormFieldsGenerator';
import Spinner from '../../common/Spinner';
import {
  ITEM_PROJECTIONS_OPTIONS,
  ITEM_PROJECTIONS_OCF,
  CONTEXT_MENU_ITEM_OPTIONS,
  ITEM_PROJECTIONS_MTGRAPH,
  DEFAULT_FILTER_PROPS,
} from './constants';
import './style.scss';
import ItemProjectionsEmbeddedList from 'containers/ItemEmbeddedListContainers/ItemProjectionsEmbeddedList/weekly';
import { Grid, FormControlLabel } from '@material-ui/core';
import ContextMenu from '../../common/ContextMenu';
import MoreVertIcon from '@material-ui/icons/MoreVert';
import FormFieldComponent from 'components/common/FormFieldsGenerator/formField';
import MultitierGraph from 'components/ItemProperties/ItemProjection/MultitierGraph';
import FieldInput from 'components/common/Form/FieldInput';
const propTypes = {
  setSaveData: PropTypes.func,
};

const style = () => ({
  pageContainer: {
    display: 'flex',
    backgroundColor: 'var(--background-app)',
    borderTop: 'none',
    padding: '10px 20px',
    width: '100%',
  },
  pageContainerSeventy: {
    width: '100%',
  },
  card: {
    padding: '0px',
    backgroundColor: 'var(--background-content)',
    borderRadius: '4px',
    width: '100%',
    margin: '10px',
    '& .MuiCardHeader-root': {
      padding: '10px 10px',
    },
    '& .MuiCardContent-root': {
      padding: '10px 10px 10px 35px',
    },
  },
  marginLeftZero: {
    marginLeft: '0',
  },
  ActionsContextMenu: {
    display: 'flex',
    flexDirection: 'column',
    width: '100%',
  },
  table: {
    marginLeft: '-15px',
    width: '102.5%',
  },
  fromVendorBox: {
    display: 'grid !important',
    width: '100%',
    gridTemplateColumns: '20% 20% 18% 18% 20%',
    padding: '10px 0 0 0 0',
    '& label': {
      margin: 0,
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
    },
    marginLeft: '15px',
  },
  cardSummary: {
    padding: '0px',
    backgroundColor: 'white',
    boxShadow: '0 0 black',
    width: '100%',
    '& .MuiCardHeader-root': {
      padding: '16px 32px',
    },
    '& .MuiCardContent-root': {
      padding: '16px 12px 10px 15px',
    },
  },
  blockWidth: {
    width: '100%',
  },
  blockMargin: {
    marginRight: '22px',
  },
});

class ItemProjection extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      fields: false,
      values: false,
      hasError: false,
      errorId: false,
      itemOptions: 52,
      itemOptions1: { IOPTIONS: '52' },
      itemMADP: { IPLTCR: '0' },
      mtgraph: false,
      dependents: true,
      incdependent: { IINCDEP: false },
      labelsdata: false,
      contextMenuList: CONTEXT_MENU_ITEM_OPTIONS,
      isOpenActionsContextMenu: false,
    };
    this.setIsOpenActionsContextMenu = this.setIsOpenActionsContextMenu.bind(
      this,
    );
  }

  setFilterProps = data => {
    let defaultFilterProps = [];
    if (data && Object.keys(data).length) {
      defaultFilterProps = DEFAULT_FILTER_PROPS.map(row => {
        row.fieldValue = data[`I${row.accessor}`]
          ? data[`I${row.accessor}`].trim()
          : '';
        return row;
      });
    }
    return defaultFilterProps;
  };

  handleChangeValue = (key, val, field) => {
    if (key == 'IOPTIONS') {
      this.setState({ itemOptions1: { IOPTIONS: val } });
      this.setState({ itemOptions: val });
    }
    if (field.FLDID == '3817') {
      this.setState({ itemMADP: { IPLTCR: val } });
    }
    if (field.FLDID == '53220') {
      this.setState({ incdependent: { IINCDEP: val } });
    }
  };

  handleGraphValue = () => {
    this.setState({ mtgraph: !this.state.mtgraph });
    const { valueData } = this.props.ItemPropertiesData;
    const Period = valueData.IPERDF;
    const currentPage = 'ItemProjectionsWV';
    const recordData = this.setFilterProps(valueData);
    const apiObj = { recordData, currentPage, Period };
    this.props.getProjectionsGraphData(apiObj);
  };

  getValueData = (valueData, newValueData) => {
    if (
      Object.keys(valueData).length &&
      Object.keys(newValueData).length &&
      JSON.parse(JSON.stringify(valueData)) !==
        JSON.parse(JSON.stringify(newValueData))
    ) {
      return newValueData;
    }
    return valueData;
  };


  setIsOpenActionsContextMenu = event => {
    this.setState({ isOpenActionsContextMenu: Boolean(event) });
    this.setState({
      menuRef: event.currentTarget ? event.currentTarget : event,
    });
  };

  handleReproject = () => {
    const { valueData } = this.props.ItemPropertiesData;
    const payload = {
      IACOMP: valueData.ICOMP,
      IAWHSE: valueData.IWHSE,
      IAVNDR: valueData.IVNDR,
      IAITEM: valueData.IITEM,
    };
    this.props.reproject(payload);
  };

  handleActionSelection = (value, type = '') => {
    this.props.handleReprojectAction(value);
    this.setIsOpenActionsContextMenu(false);
  };

  componentDidMount() {
    const { itemProjectionLabelsData } = this.props.ItemPropertiesData;
    const { companyDetails = false } = this.props;
    const { valueData } = this.props.ItemPropertiesData;
    const { canUpdateComponent } = this.props;
    this.setState({ itemMADP: { IPLTCR: valueData.IPLTCR } });
    this.setState({ itemOptions1: { IOPTIONS: valueData.IPERDF } });
    this.setState({ itemOptions: valueData.IPERDF });
    const multiTierModuleSwitch = companyDetails
      ? getCompanyInfo(companyDetails, 'multiTierSystem')
      : false; // MultiTierSystemInstalledSwitch(CDCSYS)
    let projMADPSwitchDisabled;
    const includeDependentsDisabled = true;
    if (valueData) {
      if (multiTierModuleSwitch) {
        // Multi-tier Switch ON
        if (parseInt(valueData.IXNUM) > 0) {
          // IXNUM - No of dependentWhses
          this.setState({ dependents: !this.state.dependents }); // Multi-tier Graph switch display
          includeDependentsDisabled, (projMADPSwitchDisabled = false);
        }
        if (
          getCompanyInfo(companyDetails, 'ProjMADPWeightedAvgForceUpdateSw') ||
          parseInt(valueData.IXNUM) == 0
        ) {
          projMADPSwitchDisabled = true;
        }
      } else {
        // Multi-tier Switch OFF
        includeDependentsDisabled, (projMADPSwitchDisabled = true);
      }
    }

    if (Object.keys(itemProjectionLabelsData).length) {
      const Labelsdata = { ...itemProjectionLabelsData };
      if (Labelsdata && (Labelsdata.tabcards[0].cardtitle = 'Options')) {
        for (let i = 0; i < 5; i++) {
          if (Labelsdata.tabcards[0].cardfields[i].FLDID == '23220') {//E3C-33010 
            // ProjMADP Weighted Average
            Labelsdata.tabcards[0].cardfields[
              i
            ].disabled = projMADPSwitchDisabled;
          }
          if (Labelsdata.tabcards[0].cardfields[i].FLDID == '53220') {
            Labelsdata.tabcards[0].cardfields[
              i
            ].disabled = includeDependentsDisabled;
          }
        }
      }
      this.setState({ labelsdata: Labelsdata });
    }

    if (
      canUpdateComponent &&
      Object.keys(canUpdateComponent) &&
      Object.keys(canUpdateComponent).length
    ) {
      const { contextMenuList } = this.state;
      contextMenuList.forEach(menuItem => {
        menuItem.isDisable = !canUpdateComponent.update; // E3C30659-apply security restrictions in addition to field check
      });
      this.setState({ contextMenuList });
    }
  }
  //E3C-33010 begin
  componentDidUpdate(prevProps){
    const { companyDetails = false } = this.props;
    const multiTierModuleSwitch = companyDetails
      ? getCompanyInfo(companyDetails, 'multiTierSystem')
      : false; // MultiTierSystemInstalledSwitch(CDCSYS)
    const { itemProjectionLabelsData } = this.props.ItemPropertiesData;
    const { valueData } = this.props.ItemPropertiesData;
    if(JSON.stringify(valueData)!= JSON.stringify(prevProps.ItemPropertiesData.valueData)){
      this.setState({ itemMADP: { IPLTCR: valueData.IPLTCR } });
      this.setState({ itemOptions1: { IOPTIONS: valueData.IPERDF } });
      this.setState({ itemOptions: valueData.IPERDF });
      let projMADPSwitchDisabled;
      const includeDependentsDisabled = true;
      if (valueData) {
        this.setState({ mtgraph: false }); //33011 Rakesh P
        if (multiTierModuleSwitch) {
          // Multi-tier Switch ON
          if (parseInt(valueData.IXNUM) > 0) {
            // IXNUM - No of dependentWhses
            this.setState({ dependents: false }); // Multi-tier Graph switch display
            includeDependentsDisabled, (projMADPSwitchDisabled = false);
          }
          if (
            getCompanyInfo(companyDetails, 'ProjMADPWeightedAvgForceUpdateSw') ||
            parseInt(valueData.IXNUM) == 0
          ) {
            projMADPSwitchDisabled = true;
            this.setState({ dependents: true });
          }
        } else {
          // Multi-tier Switch OFF
          includeDependentsDisabled, (projMADPSwitchDisabled = true);
          this.setState({ dependents: true });
        }
      }
      if (Object.keys(itemProjectionLabelsData).length) {
        const Labelsdata = { ...itemProjectionLabelsData };
        if (Labelsdata && (Labelsdata.tabcards[0].cardtitle = 'Options')) {
          for (let i = 0; i < 5; i++) {
            if (Labelsdata.tabcards[0].cardfields[i].FLDID == '23220') {
              // ProjMADP Weighted Average
              Labelsdata.tabcards[0].cardfields[
                i
              ].disabled = projMADPSwitchDisabled;
            }
            if (Labelsdata.tabcards[0].cardfields[i].FLDID == '53220') {
              Labelsdata.tabcards[0].cardfields[
                i
              ].disabled = includeDependentsDisabled;
            }
          }
        }
        this.setState({ labelsdata: Labelsdata });
      }
   }
  }
  //E3C-33010 end

  render() {
    const {
      classes,
      globalDateFormat,
      filterCriteriaDetails,
      pageFilterOptions,
      globalFilterOptions,
      columnDefs,
      currentPage,
      canUpdateComponent,
    } = this.props;
    const {
      loading,
      valueData,
      ProjectionsGraphData,
    } = this.props.ItemPropertiesData;
    const { tabcards } = this.state.labelsdata;
    return (
      <div>
        {!loading && tabcards && tabcards.length ? (
          <div className={classes.pageContainer}>
            <div className={classes.pageContainerSeventy}>
              <MoreVertIcon
                color="primary"
                onClick={event => this.setIsOpenActionsContextMenu(event)}
                className="cPointer"
                style={{ marginLeft: '98.3%' }}
              />
              <ContextMenu
                className={classes.ActionsContextMenu}
                menuList={this.state.contextMenuList}
                isOpen={this.state.isOpenActionsContextMenu}
                menuRef={this.state.menuRef}
                handleItemSelection={val => this.handleActionSelection(val)}
                handleMenuClose={val => this.setIsOpenActionsContextMenu(val)}
              />
              <div
                className={`${classes.notesForBlock} ${classes.blockWidth} ${
                  classes.blockMargin
                }`}
              >
                {!loading &&
                  tabcards.map(formCard => {
                    if (formCard.cardkey == ITEM_PROJECTIONS_OPTIONS) {
                      return (
                        <CardComponent
                          title={formCard.cardtitle}
                          className={classes.cardSummary}
                        >
                          <div className={classes.fromVendorBox}>
                            {formCard.cardfields.map(field => {
                              if (field.FLDID.trim() == '9904') {
                                return (
                                  <div>
                                    <FormFieldComponent
                                      noMassMaintenance
                                      key={field.FLDID}
                                      parentPage="items"
                                      field={field}
                                      valuesArray={this.state.itemOptions1}
                                      handleChangeValue={(key, val, field) =>
                                        this.handleChangeValue(key, val, field)
                                      }
                                      currentPage="items"
                                      labelDisplayCharacters={15}
                                      valueDisplayCharacters={12}
                                      canUpdateComponent={canUpdateComponent}
                                    />
                                  </div>
                                );
                              }
                            })}

                            {formCard.cardfields.map(field => {
                              if (field.FLDID.trim() == '3817') {
                                return (
                                  <div>
                                    <FormFieldComponent
                                      noMassMaintenance
                                      key={field.FLDID}
                                      parentPage="items"
                                      field={field}
                                      valuesArray={this.state.itemMADP}
                                      handleChangeValue={(key, val, field) =>
                                        this.handleChangeValue(key, val, field)
                                      }
                                      currentPage="items"
                                      labelDisplayCharacters={25}
                                      valueDisplayCharacters={2}
                                      canUpdateComponent={canUpdateComponent}
                                    />
                                  </div>
                                );
                              }
                            })}

                            {formCard.cardfields.map(field => {
                              if (field.FLDID.trim() == '23220') {
                                return (
                                  <div>
                                    <FormFieldComponent
                                      noMassMaintenance
                                      key={field.FLDID}
                                      parentPage="items"
                                      field={field}
                                      valuesArray={this.state.incdependent}
                                      handleChangeValue={(key, val, field) =>
                                        this.handleChangeValue(key, val, field)
                                      }
                                      currentPage="items"
                                      labelDisplayCharacters={18}
                                      valueDisplayCharacters={2}
                                      canUpdateComponent={canUpdateComponent}
                                    />
                                  </div>
                                );
                              }
                            })}

                            {formCard.cardfields.map(field => {
                              if (field.FLDID.trim() == '53207') {
                                return (
                                  <div>
                                    <FormFieldComponent
                                      noMassMaintenance
                                      key={field.FLDID}
                                      parentPage="items"
                                      field={field}
                                      handleChangeValue={(key, val, field) =>
                                        this.handleChangeValue(key, val, field)
                                      }
                                      currentPage="items"
                                      labelDisplayCharacters={27}
                                      valueDisplayCharacters={0}
                                      canUpdateComponent={canUpdateComponent}
                                    />
                                  </div>
                                );
                              }
                            })}

                            {formCard.cardfields.map(field => {
                              if (field.FLDID.trim() == '53208') {
                                return (
                                  <div>
                                    <FormFieldComponent
                                      noMassMaintenance
                                      key={field.FLDID}
                                      parentPage="items"
                                      field={field}
                                      handleChangeValue={(key, val, field) =>
                                        this.handleChangeValue(key, val, field)
                                      }
                                      currentPage="items"
                                      labelDisplayCharacters={35}
                                      valueDisplayCharacters={0}
                                      canUpdateComponent={canUpdateComponent}
                                    />
                                  </div>
                                );
                              }
                            })}
                          </div>
                        </CardComponent>
                      );
                    }
                  })}
              </div>
              <Grid className={classes.table}>
                <Grid container item>
                  <ItemProjectionsEmbeddedList
                    itemData={this.props.ItemPropertiesData.currentRecordData}
                    itemOptions={this.state.itemOptions}
                    canUpdateComponent={canUpdateComponent}
                    globalDateFormat={globalDateFormat}
                  />
                </Grid>
              </Grid>
              {!loading &&
                valueData &&
                tabcards.map(formCard => {
                  if (formCard.cardkey == ITEM_PROJECTIONS_OCF) {
                    return (
                      <CardComponent
                        title={formCard.cardtitle}
                        className={`${classes.card} ${classes.marginLeftZero}`}
                      >
                        <FormFieldsGenerator
                          labelDisplayCharacters={20}
                          valueDisplayCharacters={11}
                          handleSubmitDataCallBack={
                            this.props.handleSubmitDataCallBack
                          }
                          key={formCard.cardkey}
                          parentPage={ITEMS_LIST_PAGE}
                          className="ITEM_PROJECTIONS_ORDER"
                          fieldsArray={formCard.cardfields}
                          valuesArray={valueData}
                          handleChangeValue={(key, val, field) =>
                            this.handleChangeValue(key, val, field)
                          }
                          globalDateFormat={globalDateFormat}
                          filterCriteriaDetails={filterCriteriaDetails}
                          pageFilterOptions={pageFilterOptions}
                          globalFilterOptions={globalFilterOptions}
                          columnDefs={columnDefs}
                          currentPage={currentPage}
                          parentData={this.props.vendorData}
                        />
                      </CardComponent>
                    );
                  }
                })}

              {!loading &&
                tabcards.map(formCard => {
                  if (formCard.cardkey == ITEM_PROJECTIONS_MTGRAPH) {
                    return (
                      <CardComponent
                        title={formCard.cardtitle}
                        className={`${classes.card} ${classes.marginLeftZero}`}
                      >
                        {formCard.cardfields.map(field => {
                          if (field.FLDID.trim() == '53225') {
                            return (
                              <div>
                                <FormControlLabel
                                  control={
                                    <FieldInput
                                      value={this.state.mtgraph}
                                      field={{ key: '53225', type: 'checkbox' }}
                                      onChange={() => this.handleGraphValue()}
                                      disabled={this.state.dependents}
                                    />
                                  }
                                  label={this.props.getLabelValue('53225')}
                                  labelPlacement="end"
                                />
                                {ProjectionsGraphData && this.state.mtgraph && (
                                  <MultitierGraph
                                    series={
                                      ProjectionsGraphData
                                        ? ProjectionsGraphData.series
                                        : []
                                    }
                                    categories={
                                      ProjectionsGraphData
                                        ? ProjectionsGraphData.categories
                                        : []
                                    }
                                  />
                                )}
                              </div>
                            );
                          }
                        })}
                      </CardComponent>
                    );
                  }
                })}
            </div>
          </div>
        ) : (
          <Spinner loading type="ItemProjectionTab" />
        )}
      </div>
    );
  }
}

ItemProjection.propTypes = propTypes;

export default withStyles(style)(ItemProjection);

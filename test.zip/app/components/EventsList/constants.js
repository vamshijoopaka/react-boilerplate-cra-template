import {
    COLUMN_HEADER_ACCESSOR, 
    COLUMN_VALUE_ACCESSOR,
    COLUMN_SHOW_HIDE_FLAG,
    COLUMN_POSITION,
    COLUMN_HEADER_PREFIX_FLAG
} from '../common/constants';


export const DEFAULT_ACTION = 'app/EventsListPage/DEFAULT_ACTION';
export const LOAD_EVENTS = 'app/EventsListPage/LOAD_EVENTS';
export const LOAD_EVENTS_ERROR = 'app/EventsListPage/LOAD_EVENTS_ERROR';
export const LOAD_EVENTS_SUCCESS = 'app/EventsListPage/LOAD_EVENTS_SUCCESS';
export const SET_SEARCHPROPS = 'app/EventsListPage/SET_SEARCHPROPS';
export const SET_SORTPROPS = 'app/EventsListPage/SET_SORTPROPS';
export const SET_FILTERID = 'app/EventsListPage/SET_FILTERID';
export const SET_ADVANCED_FILTERS = 'app/EventsListPage/SET_ADVANCED_FILTERS';
export const SET_FILTERPROPS = 'app/EventsListPage/SET_FILTERPROPS';
export const SET_PAGEPROPS = 'app/EventsListPage/SET_PAGEPROPS';
export const SET_PROPERTIESPROPS = 'app/EventsListPage/SET_PROPERTIESPROPS';
export const SET_EVENT_COLUMN_DEF = 'app/EventsListPage/SET_EVENT_COLUMN_DEF';
export const LOAD_HEADER = 'app/LOAD_HEADER';
export const GET_EVENT_COLUMN_DEF = 'app/EventsListPage/GET_EVENT_COLUMN_DEF';

export const EVENT_COLUMN_HEADER_ACCESSOR = "TLLAB";
export const EVENT_COLUMN_VALUE_ACCESSOR = "FDFNAM";
export const EVENT_COLUMN_POSITION = "FLDPOS";
export const EVENT_COLUMN_SHOW_HIDE_FLAG = "FLDSHW"
export const EVENT_COLUMN_HEADER_PREFIX_FLAG = "FDPRFX";

export const EVENT_PROPERTIES = {
    "headerName": COLUMN_HEADER_ACCESSOR,
    "field": COLUMN_VALUE_ACCESSOR,
    "showHideFlag": COLUMN_SHOW_HIDE_FLAG,
    "columnPosition": COLUMN_POSITION,
    "prefixFlag": COLUMN_HEADER_PREFIX_FLAG
}

export const PAGE_SIZES = [10, 20, 30];

export const EVENT_LIST_PAGE = "eventsListPage";

export const SET_EVENT_GLOBAL_FILTER_PROPS = "SET_EVENT_GLOBAL_FILTER_PROPS";

export const INITIAL_PAGE_PROPS = {
    actualPage: 0,
    currentPage: 0,
    totalCount: 10,
    actualPageSize: 10,
    pageSize: 100,
    isPageSizeChanged: false,
    isForwardDirection: true
}

export const HAS_PAGINATION = true;
import {
    GET_ITEMDELETE_LIST,
    GET_ITEMDELETE_LIST_SUCCESS,
    GET_ITEMDELETE_LIST_FAILURE,
    SET_PAGEPROPS,
    SET_APICALL_COUNT,
    GET_ITEMDELETE_COLUMN_DEFINITION,
    GET_ITEMDELETE_COLUMN_DEFINITION_SUCCESS,
    GET_ITEMDELETE_COLUMN_DEFINITION_FAILURE,
    GET_ITEMDELETE_UPDATE_COLUMN_DEFINITION,
    GET_ITEMDELETE_UPDATE_COLUMN_DEFINITION_SUCCESS,
    GET_ITEMDELETE_UPDATE_COLUMN_DEFINITION_FAILURE,
    SET_FILTER_VALUES,
    SET_COLUMN_DEFS_LOADED,
    RESET_DATA,
    RESET_DEFAULTS,
    RESET_DEFAULTS_SUCCESS,
    RESET_DEFAULTS_FAILURE,
} from './constants';

export function getItemDeleteList(data) {
    return {
        type: GET_ITEMDELETE_LIST,
        data
    }
}

export function setItemDeleteListSuccess(data) {
    return {
        type: GET_ITEMDELETE_LIST_SUCCESS,
        data
    }
}

export function setItemDeleteListFailure(data) {
    return {
        type: GET_ITEMDELETE_LIST_FAILURE,
        data
    }
}

export function setApiCallCount(data) {
    return {
        type: SET_APICALL_COUNT,
        data
    }
}

export function onSetPageProps(data) {
    return {
        type: SET_PAGEPROPS,
        data
    }
}

export function getItemDeleteColumnDefs(data) {
    return {
        type: GET_ITEMDELETE_COLUMN_DEFINITION,
        data
    }
}

export function setItemDeleteListColumnDefs(data) {
    return {
        type: GET_ITEMDELETE_COLUMN_DEFINITION_SUCCESS,
        data
    }
}

export function setItemDeleteListColumnDefsFailure(data) {
    return {
        type: GET_ITEMDELETE_COLUMN_DEFINITION_FAILURE,
        data
    }
}

export function updateShowHide(data) {
    return {
        type: GET_ITEMDELETE_UPDATE_COLUMN_DEFINITION,
        data
    }
}

export function updateColumnDefsSuccess(data) {
    return {
        type: GET_ITEMDELETE_UPDATE_COLUMN_DEFINITION_SUCCESS,
        data
    }
}

export function updateColumnDefsFailure(data) {
    return {
        type: GET_ITEMDELETE_UPDATE_COLUMN_DEFINITION_FAILURE,
        data
    }
}

export function setFilterValues(data) {
    return {
        type: SET_FILTER_VALUES,
        data
    }
}

export function setColumnDefsLoaded(data) {
    return {
        type: SET_COLUMN_DEFS_LOADED,
        data
    }
}

export function resetStateData(data) {
    return {
        type: RESET_DATA,
        data
    }
}
export function resetDefault(data) {
    return {
        type: RESET_DEFAULTS,
        data
    }
}

export function resetDefaultSuccess(data) {
    return {
        type: RESET_DEFAULTS_SUCCESS,
        data
    }
}

export function resetDefaultFailure(data) {
    return {
        type: RESET_DEFAULTS_FAILURE,
        data
    }
}


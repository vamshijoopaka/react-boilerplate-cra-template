
/*
* * //==========================================================================
*
* * // Copyright 2021-2021, Blue Yonder Group, Inc.
*
* * // All Rights Reserved
*
* * //
*
* * // THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF
*
* * // BLUE YONDER GROUP, INC.
*
* * //
*
* * //
*
* * // The copyright notice above does not evidence any actual
*
* * // or intended publication of such source code.
*
* * //
*
* * // ===========================================================================
*/
import PropTypes from 'prop-types';
import React, { Component } from 'react';
import { Radio, RadioGroup, FormControlLabel, FormControl } from '@material-ui/core';
import FormattedMessageComponent from 'components/common/FormattedMessageComponent';
import {
  COLUMN_HEADER_ACCESSOR
} from 'components/common/constants';

const defaultProps = {
  className: '',
};

const propTypes = {
  className: PropTypes.string,
  field: PropTypes.shape({}).isRequired,
  onChange: PropTypes.func.isRequired,
  options: PropTypes.array.isRequired, //{label, fieldValue, disabled, labelplacement}
  defaultValue: PropTypes.any,
  isHorizontal: PropTypes.bool
};

class InputRadio extends Component {
  constructor() {
    super();
    this.onChange = this.onChange.bind(this);
    this.getLabelValue = this.getLabelValue.bind(this);
  }

  onChange(event) {
    const { onChange, field } = this.props;
    const { key } = field;
    onChange(key, event.currentTarget.value);
  }

  getLabelValue(val) {
    const { field, options, value, defaultValue, formatMessage } = this.props;
    if (formatMessage) {
      return <FormattedMessageComponent id={val.key}></FormattedMessageComponent>;
    }
    if (val[COLUMN_HEADER_ACCESSOR] && val[COLUMN_HEADER_ACCESSOR].length) {
      return val[COLUMN_HEADER_ACCESSOR].trim();
    }
    return val.key;
  }

  render() {
    const { field, value, defaultValue, formatMessage, isHorizontal } = this.props;
    const { options } = field;

    return (
      <div>
        <FormControl component="fieldset">
          <RadioGroup value={value} onChange={(e, key) => this.onChange(e, key)} row={isHorizontal}>
            {options && options.length && options.map(val => {
              return <FormControlLabel
                key={val.key}
                value={val.fieldValue}
                disabled={val.disabled}
                control={<Radio color="primary" />}
                label={this.getLabelValue(val)}
                labelPlacement={val.labelPlacement ? val.labelPlacement : "end"}
              />
            })}
          </RadioGroup>
        </FormControl>
      </div>
    );
  }
}

InputRadio.defaultProps = defaultProps;
InputRadio.propTypes = propTypes;

export default InputRadio;

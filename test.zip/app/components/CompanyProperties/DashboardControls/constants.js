/** Change Log
 * LogStart --  E3C-33195 - Kumar A- 16 September,2021 - 2022.1.0.0 Unified Product
 *              Story: E3C-33195 --Code Cleanup
*/
export const COMPANY_GRAPH_CONTROL_FACTORS = '53227';
export const COMPANY_PROJECTION_CONTROL_FACTORS = '53382';
export const COMPANY_CLEANUP_CONTROLFACTORS = '53228';

export const DASHBOARD_CONTROL_GET_FIELD_LIST = 'DASHBOARD_CONTROL_GET_FIELD_LIST';
export const DASHBOARD_CONTROL_GET_FIELD_LIST_SUCCESS = 'DASHBOARD_CONTROL_GET_FIELD_LIST_SUCCESS';
export const DASHBOARD_CONTROL_GET_FIELD_LIST_FAILURE = 'DASHBOARD_CONTROL_GET_FIELD_LIST_FAILURE';

export const DASHBOARD_CONTROL = 'dashboardFactors';
export const COMPANY_DATA_RESERVED = "VRSRVD";

export const CUSTOM_CARD_ONE = "4434";
export const CUSTOM_CARD_TWO = "4501";
export const CUSTOM_CARD_THREE = "3331";
export const CUSTOM_CARD_FOUR = "4452";

export const CUSTOM_CARD_KEY = "50916";

export const CUSTOM_CARDS = [
    {
        "cardtitle": "Custom cards",
        "cardkey": "50916",
        "cardfields": [
            {
                "FLDID": "4434",
                "FLDTYPE": "TextBox",
                "FDPROD": " ",
                "FDFILD": "4434",
                "FDFNAM": "VACTDT    ",
                "FDPRFX": "1",
                "FDFCLS": "S",
                "FDFTYP": "D",
                "FDMINV": ".0000",
                "FDMAXV": ".0000",
                "FDVLDT": "N",
                "FDZAPO": "M",
                "FDFLEN": "7",
                "FDDECP": "0",
                "FDDEFN": "IDF_ACTDT                                         ",
                "FDMASK": "                                                  ",
                "FDLTRL": "                                                  ",
                "FDDATR": "                                                  ",
                "FDDPRN": "0",
                "FDDDIV": "0",
                "TLANG": "ENG",
                "TPROD": " ",
                "TIDNO": "34434",
                "TDEFN": "IDx_34434                                         ",
                "TLLAB": "Deactivate Until                                                                                    ",
                "TULLB": "                                                                                                    ",
                "TSLAB": "                    ",
                "TUSLB": "                    ",
                "FLDVLD": ""
            }, {
                "FLDID": "4501",
                "FLDTYPE": "checkbox",
                "FDPROD": " ",
                "FDFILD": "4501",
                "FDFNAM": "CALSW     ",
                "FDPRFX": "0",
                "FDFCLS": "S",
                "FDFTYP": "N",
                "FDMINV": ".0000",
                "FDMAXV": "9.0000",
                "FDVLDT": "N",
                "FDZAPO": "N",
                "FDFLEN": "1",
                "FDDECP": "0",
                "FDDEFN": "                                                  ",
                "FDMASK": "                                                  ",
                "FDLTRL": "                                                  ",
                "FDDATR": "                                                  ",
                "FDDPRN": "0",
                "FDDDIV": "0",
                "TLANG": "ENG",
                "TPROD": " ",
                "TIDNO": "34501",
                "TDEFN": "IDT_CALSW                                         ",
                "TLLAB": "Calendar                                                                                            ",
                "TULLB": "                                                                                                    ",
                "TSLAB": "                    ",
                "TUSLB": "                    ",
                "FLDVLD": ""
            }, {
                "FLDID": "3331",
                "FLDTYPE": "COMBOBOX",
                "FDPROD": " ",
                "FDFILD": "3331",
                "FDFNAM": "DPERD     ",
                "FDPRFX": "0",
                "FDFCLS": "F",
                "FDFTYP": "N",
                "FDMINV": "12.0000",
                "FDMAXV": "52.0000",
                "FDVLDT": "Y",
                "FDZAPO": "N",
                "FDFLEN": "2",
                "FDDECP": "0",
                "FDDEFN": "                                                  ",
                "FDMASK": "                                                  ",
                "FDLTRL": "                                                  ",
                "FDDATR": "                                                  ",
                "FDDPRN": "0",
                "FDDDIV": "0",
                "TLANG": "ENG",
                "TPROD": " ",
                "TIDNO": "33331",
                "TDEFN": "IDT_DPERD                                         ",
                "TLLAB": "History Periodicity                                                                                 ",
                "TULLB": "                                                                                                    ",
                "TSLAB": "                    ",
                "TUSLB": "                    ",
                "FLDVLD": "12=Monthly|13=4-Week|52=Weekly"
            }, {
                "FLDID": "4452",
                "FLDTYPE": "TextBox",
                "FDPROD": " ",
                "FDFILD": "4452",
                "FDFNAM": "ORMON     ",
                "FDPRFX": "0",
                "FDFCLS": "S",
                "FDFTYP": "N",
                "FDMINV": ".0000",
                "FDMAXV": "31.0000",
                "FDVLDT": "N",
                "FDZAPO": "M",
                "FDFLEN": "2",
                "FDDECP": "0",
                "FDDEFN": "                                                  ",
                "FDMASK": "                                                  ",
                "FDLTRL": "                                                  ",
                "FDDATR": "                                                  ",
                "FDDPRN": "0",
                "FDDDIV": "0",
                "TLANG": "ENG",
                "TPROD": " ",
                "TIDNO": "34452",
                "TDEFN": "IDT_ORMON                                         ",
                "TLLAB": "Order Day in Month                                                                                  ",
                "TULLB": "                                                                                                    ",
                "TSLAB": "                    ",
                "TUSLB": "                    ",
                "FLDVLD": ""
            }
        ]
    }
]
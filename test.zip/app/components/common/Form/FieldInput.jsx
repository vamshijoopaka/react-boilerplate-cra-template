
/*
* * //==========================================================================
*
* * // Copyright 2021-2021, Blue Yonder Group, Inc.
*
* * // All Rights Reserved
*
* * //
*
* * // THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF
*
* * // BLUE YONDER GROUP, INC.
*
* * //
*
* * //
*
* * // The copyright notice above does not evidence any actual
*
* * // or intended publication of such source code.
*
* * //
*
* * // ===========================================================================
*/
import PropTypes from 'prop-types';
import React from 'react';
import InputDate from './InputDate';
import InputFile from './InputFile';
import InputNumber from './InputNumber';
import InputRadio from './InputRadio';
import AutoComplete from './AutoComplete';
import InputSelect from './InputSelect';
import InputText from './InputText';
import InputPassword from './InputPassword';
import FieldInputCheckbox from './InputCheckbox';
import * as fieldTypes from './fieldTypes';
import FieldLabel from './FieldLabel';
import InputTextArea from './InputTextArea';

const defaultProps = {
  className: '',
};

const propTypes = {
  className: PropTypes.string,
  field: PropTypes.shape({}).isRequired,
  onChange: PropTypes.func.isRequired,
  value: PropTypes.any,
};

const FieldInput = props => {
  const { type } = props.field;

  switch (type) {
    case fieldTypes.DATE:
      return <InputDate {...props} />;
    case fieldTypes.FILE:
      return <InputFile {...props} />;
    case fieldTypes.NUMBER:
      return <InputNumber {...props} />;
    case fieldTypes.RADIO:
      return <InputRadio {...props} />;
    case fieldTypes.SELECT:
      return <InputSelect {...props} />;
    case fieldTypes.AUTOCOMPLETE:
      return <AutoComplete {...props} />;
    case fieldTypes.CHECKBOX:
      return <FieldInputCheckbox {...props} />;
    case fieldTypes.PASSWORD:
      return <InputPassword {...props} />;
    case fieldTypes.LABELS:
      return <FieldLabel {...props} />;
    case fieldTypes.TEXTAREA:
      return <InputTextArea {...props} />;
    default:
      return <InputText {...props} />;
  }
};

FieldInput.defaultProps = defaultProps;
FieldInput.propTypes = propTypes;

export default FieldInput;

import { withStyles, Box } from '@material-ui/core';
import DialogComponent from 'components/common/DialogComponent';
import FormFieldsGenerator from 'components/common/FormFieldsGenerator';

import theme from 'jda-gcp-theme';
import PropTypes from 'prop-types';
import React from 'react';
import { compose } from 'redux';
import {
    MENU_ITEMS_SELECT_WHSE as MENU_ITEMS,
} from './constants';

const defaultProps = {
    className: '',
};

const propTypes = {
    parentFilterProps: PropTypes.array,
    currentPage: PropTypes.string,
    handleClose: PropTypes.func,
    isOpen: PropTypes.bool
};

const styles = () => ({
    notesForBlock: {
        display: 'flex',
        flexDirection: 'column',
        marginTop: '25px',
        border: '1px solid var(--divider-line)',
        padding: '10px 10px 0 10px',
        position: 'relative'
    },
    notesForLabel: {
        position: 'absolute',
        top: '-7px',
        left: '10px',
        background: 'var(--background-content)',
        padding: '0 8px',
    },
    pageContainer: {
        width: '100%',
        display: 'flex',
        borderTop: 'none',
        padding: '0px 20px',
    },
    pageContainerFull: {
        width: '100%',
    },

    pageContainerFifty: {
        width: '42%',
        flexDirection: 'row'
    },
    pageContainerSixty: {
        width: '58%',
        flexDirection: 'row',
        paddingRight: '16px'
    },
    dialogClass: {
        minWidth: '30% !important',
        maxWidth: '70% !important',
    }
});

class DetailHoldouts extends React.PureComponent {
    calendarComponentRef = React.createRef();

    constructor(props) {
        super(props);
        this.state = {
            selectedCalendarToDelete: [],
            menuItems: MENU_ITEMS,
            detailValuesArray: [],
            detailHoldoutValues: [],
            headerValues: false
        }
    }
    componentDidMount() {
        const { valuesArray, holdoutsValuesArray, itemDetails, values } = this.props;
        let headerValues = { ...values }
        headerValues["VNAME"]=itemDetails["EIVNAM"]
    headerValues["INAME"]=itemDetails["EIINAM"]   
    headerValues["EIWNAME"]=itemDetails["EIWNAM"]   
        this.setState({ headerValues: headerValues })
        let detailValues = valuesArray.data;
        this.setState({ detailValuesArray: detailValues })
        const { detailHoldoutValues } = this.state
        this.changeHOtoPL(detailValues, detailHoldoutValues, holdoutsValuesArray)
    }
    changeHOtoPL = (
        detailValuesArray,
        detailHoldoutValues,
        holdoutsValuesArray,
    ) => {
        detailHoldoutValues.EIACCT = detailValuesArray.HOACCT
        detailHoldoutValues.EIDEAL = detailValuesArray.HODEAL
        detailHoldoutValues.EIHEND = detailValuesArray.HOEDAT
        detailHoldoutValues.EIITEM = detailValuesArray.HOITEM
        detailHoldoutValues.EIMFGI = detailValuesArray.HOMFGI
        detailHoldoutValues.EIOLTF = detailValuesArray.HOOLTF
        detailHoldoutValues.EIPLNI = detailValuesArray.HOPLNI
        detailHoldoutValues.EIQTY = detailValuesArray.HOQNTY
        detailHoldoutValues.EIRECD = detailValuesArray.HORECD
        detailHoldoutValues.EIHBEG = detailValuesArray.HOSDAT
        detailHoldoutValues.EISRC = detailValuesArray.HOSRC
        detailHoldoutValues.EISTAT = detailValuesArray.HOSTAT
        detailHoldoutValues.EISTOR = detailValuesArray.HOSTOR
        detailHoldoutValues.EITYPE = detailValuesArray.HOTYPE
        detailHoldoutValues.EIUPCI = detailValuesArray.HOUPCI
        detailHoldoutValues.EIVNDR = detailValuesArray.HOVNDR
        detailHoldoutValues.EIWHSE = detailValuesArray.HOWHSE
        detailHoldoutValues.EISEQN = detailValuesArray.HWSEQN
        detailHoldoutValues.EIWSTN = detailValuesArray.HWWSTN
        detailHoldoutValues.INAME = detailValuesArray.INAME
        detailHoldoutValues.KBRDT = detailValuesArray.KBRDT
        detailHoldoutValues.EIVNAME = holdoutsValuesArray.VNAME
        detailHoldoutValues.EIINAME = holdoutsValuesArray.INAME
        detailHoldoutValues.VNAME = holdoutsValuesArray.VNAME
        detailHoldoutValues.INAME = holdoutsValuesArray.INAME
        detailHoldoutValues.EIWNAME = holdoutsValuesArray.PDWNAME

        this.setState({ detailHoldoutValues: detailHoldoutValues });
    };
    setSelectSubmit = () => {
        let nodeData = [];
        this.deleteGridApi.forEachNode((node) => {
            if (node.selected) {
                node.data.DSTAT = 'D'; // To delte
                nodeData.push(node.data);
            }
        })
        this.setState({ selectedCalendarToDelete: nodeData })
    };

    selectedWarehouses = flag => {
        if (flag) {
            this.props.selectedWarehouses(this.state.selectedRows);
        }
    };

    deleteGridReady = params => {
        this.deleteGridApi = params;
    };

    updateMenuItems = items => {
        this.setState({ menuItems: items })
    };
    sendSelectedRows = data => {
        this.setState({
            selectedRows: data,
        });

    };
    handleChangeValue = (key, val) => {
        if (!val) return
        this.setState({
            detailHoldoutValues: { ...this.state.detailHoldoutValues, [key]: val },
        });
    };

    onAddRecord = flag => {
        const { detailHoldoutValues } = this.state;
        let obj = {};
        if (flag) {
            obj.HOACCT = detailHoldoutValues.EIACCT;
            obj.HOCOMP = detailHoldoutValues.EICOMP;
            obj.HOVNDR = detailHoldoutValues.EIVNDR;
            obj.HOWHSE = detailHoldoutValues.EIWHSE;
            obj.HOEDAT = detailHoldoutValues.EIHEND;
            obj.HOSDAT = detailHoldoutValues.EIHBEG;
            obj.HOITEM = detailHoldoutValues.EIITEM;
            obj.HODEAL = detailHoldoutValues.EIDEAL;
            obj.HOEVNT = detailHoldoutValues.EIEVNT;
            obj.HOMFGI = detailHoldoutValues.EIMFGI;
            obj.HOOLTF = detailHoldoutValues.EIOLTF;
            obj.HOPLNI = detailHoldoutValues.EIPLNI;
            obj.HOQNTY = detailHoldoutValues.EIQTY;
            obj.HORECD = detailHoldoutValues.EIRECD;;
            obj.HOSRC = detailHoldoutValues.EISRC;
            obj.HOSTAT = detailHoldoutValues.EISTAT;;
            obj.HOSTOR = detailHoldoutValues.EISTOR; // no ASR
            obj.HOTYPE = detailHoldoutValues.EITYPE;
            obj.HOUPCI = detailHoldoutValues.EIUPCI;
            obj.HWSEQN = detailHoldoutValues.EIWSEQN;
            obj.HWWSTN = detailHoldoutValues.EIWSTN;
            obj.INAME = detailHoldoutValues.INAME;
            // this.props.onAddRec(obj);
        }
        return obj;
    };

    getFieldLength = formCard => {
        let cardFields = formCard.cardfields;
        if (cardFields[1].FLDID == "3989" || cardFields[3].FLDID == "3990" || cardFields[5].FLDID == "6479") return 34
        else return 9
    };
    handleClose = () => {
        if (this.props.closeDialog) {
            this.props.closeDialog('detailHoldouts');
        }
    };
    handleSubmit = () => {
        let valid =this.props.onValid(this.state.detailHoldoutValues)
        if(valid){
        this.props.onAddRec(this.onAddRecord(true), true, this.props.valuesArray.rowIndex)
        this.props.closeDialog('detailHoldouts');
        }
    };
    render() {
        const { classes, valuesArray } = this.props;
        const { detailHoldoutValues, headerValues } = this.state;
        // detailValues.replace()
        const { loading, plansLabelsData } = this.props.newPlanData;
        const { tabcards } = plansLabelsData
        return (
            <DialogComponent
                isOpen={this.props.isOpen}
                dialogTitle={this.props.title}
                cancelText="CANCEL"
                submitText="OK"
                handleClose={() => this.handleClose()}
                handleCancel={() => this.handleClose()}
                className={classes.dialogClass}
                handleSubmit={() => this.handleSubmit()}
                isBackArrow
            // handleSubmit={() => { this.props.handleCopy(true) }}
            >
                <div>
                    <div className={classes.pageContainer}>
                        {tabcards && tabcards.length && (
                            <div className={classes.pageContainerFull} >
                                {!loading && tabcards.map(formCard => {
                                    if (formCard.cardkey == '25014') {
                                        return <div className={classes.notesForBlock}>
                                            <Box mb={theme.spacing(0.5)} className={classes.notesForLabel}>{formCard.cardtitle}</Box>
                                            <FormFieldsGenerator
                                                cardHasCheckBox
                                                noMassMaintenance
                                                key={formCard.cardkey}
                                                //parentPage="plans"
                                                className="COPY_VENDOR"
                                                currentPage="eventitems"
                                                fieldsArray={formCard.cardfields}
                                                valuesArray={headerValues}
                                                handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                                valueDisplayCharacters={(formCard) => this.getFieldLength(formCard)}
                                                labelDisplayCharacters={15}
                                            />
                                        </div>
                                    }
                                })}
                            </div>
                        )}
                    </div>

                    <div >
                        {tabcards && tabcards.length && (
                            <div className={classes.pageContainer}>
                                <div className={classes.pageContainerSixty}>
                                    {!loading && tabcards.map(formCard => {
                                        if (formCard.cardkey == '50855') {
                                            return <div className={classes.notesForBlock}>
                                                <Box mb={theme.spacing(0.5)} className={classes.notesForLabel}>{formCard.cardtitle}</Box>
                                                <FormFieldsGenerator
                                                    cardHasCheckBox
                                                    noMassMaintenance
                                                    key={formCard.cardkey}
                                                  //  parentPage="plans"
                                                    className="ADD_HOLDOUTS"
                                                    fieldsArray={formCard.cardfields}
                                                    valuesArray={detailHoldoutValues}
                                                    handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                                    currentPage="eventitems"
                                                    valueDisplayCharacters={18}
                                                    labelDisplayCharacters={25}
                                                />
                                            </div>
                                        }
                                    })}
                                </div>
                                <div className={classes.pageContainerFifty}>
                                    {!loading && tabcards.map(formCard => {
                                        if (formCard.cardkey == '50856') {
                                            return <div className={classes.notesForBlock}>
                                                <Box mb={theme.spacing(0.5)} className={classes.notesForLabel}>{formCard.cardtitle}</Box>
                                                <FormFieldsGenerator
                                                    cardHasCheckBox
                                                    noMassMaintenance
                                                    key={formCard.cardkey}
                                                    //parentPage="plans"
                                                    className="ADD_HOLDOUTS"
                                                    fieldsArray={formCard.cardfields}
                                                    valuesArray={detailHoldoutValues}
                                                    handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                                    currentPage="eventitems"
                                                    valueDisplayCharacters={15}
                                                />
                                            </div>
                                        }
                                    })}
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            </DialogComponent>
        );
    }
}


DetailHoldouts.defaultProps = defaultProps;
DetailHoldouts.propTypes = propTypes;

export default compose(
    withStyles(styles)
)(DetailHoldouts);

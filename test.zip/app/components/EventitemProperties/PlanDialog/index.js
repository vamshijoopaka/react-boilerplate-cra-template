import React from 'react';
import { connect } from 'react-redux';
import { compose } from 'redux';

import DialogComponent from 'components/common/DialogComponent';
import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import saga from './saga';
import { withStyles, Box } from '@material-ui/core';
import DateRenderer from 'components/CustomGrid/DateRenderer';
import DropdownRenderer from 'components/CustomGrid/DropdownRenderer';
import TextRenderer from 'components/CustomGrid/TextRenderer';
import NumberRenderer from 'components/CustomGrid/NumberRenderer';
import GridErrorMessages from '../../common/GridErrorMessages';

import FormFieldsGenerator from '../../common/FormFieldsGenerator';
import FormattedMessageComponent from 'components/common/FormattedMessageComponent';
import theme from 'jda-gcp-theme';
import AddHoldouts from './AddHoldouts';
import DetailHoldouts from './DetailHoldout';
import Header from './Header';

import {
    TEXT_CANCEL,
    TEXT_OK
} from 'containers/common/constants';

import EmbeddedList from 'containers/common/EmbeddedList';
import reducer from './reducer';
import { selectDetailData } from './selector';
import {
    HOLDOUT_ITEM,
    ROW_COLUMN_ID,
    PLANS_EMBEDDED_LIST,
    MENU_ITEMS,
    PURCHASE_DATE_QUANTITY,
    PURCHASE_DATE_CALCULATION_FACTORS,
    OTHER_FACTORS,
    PLAN_CONTROL_FACTORS,
    PLANNED_QTY_CALCULATION_FACTORS,
    PLAN_CONTROLS,
} from './constants';
import {
    getcolumnDefs,
    setApiCallCount,
    onSetPageProps,
    removeRecord,
    updateShowHide,
    resetDefault,
    setColumnDefsLoaded,
    onSetDataValueChange,
    addRec,
    addRecordsfromNonStockAndItems,
    getVendorList,
    getItemsList,
    getWarehouseList,
    getHoldoutsList,
    setLabelDataFlags,
    resetStateData,
    plansRecalcQty,
    setError,
    plansUpdate
} from './action';
import { getListPredecessor } from '../../../utils/util';
const style = () => ({
    pageContainer1: {
        width: '100%',
        display: 'flex',
        borderTop: 'none',
        padding: '0px 20px',
    },
    pageContainerNext: {
        display: 'flex',
        borderTop: 'none',
        padding: '2px 24px 0px 24px',
    },
    pageContainerThirtyPlus: {
        width: '36%',
        display: 'grid',
        flexDirection: 'row',
        paddingRight: '16px'
    },
    pageContainerThirtyT: {
        width: '33%',
        display: 'grid',
        flexDirection: 'row',
    },
    dialogClass: {
        minWidth: '90% !important',
        maxWidth: '100% !important',
        height: '41rem'
    },
    notesForBlock: {
        display: 'flex',
        flexDirection: 'column',
        marginTop: '25px',
        border: '1px solid var(--divider-line)',
        padding: '10px 10px 0 10px',
        position: 'relative'
    },
    notesForLabel1: {
        position: 'absolute',
        top: '-7px',
        left: '10px',
        background: 'var(--background-content)',
        padding: '0 8px',
    },
    pageContainerThirty: {
        width: '32%',
        display: 'flex',
        flexDirection: 'row',
        paddingRight: '16px'
    },
});

const frameworkComponent = {
    'numberRenderer': NumberRenderer,
    'textRenderer': TextRenderer,
    'dropdownRenderer': DropdownRenderer,
    'dateRenderer': DateRenderer
};

class DetailDialog extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            valuesArray: false,
            rowSelection: 'single',
            holdoutsSelectedRows: false,
            holdoutRows: false,
            menuItems: [...MENU_ITEMS],
            addDialog: false,
            detailHoldouts: false,
            valueArrayToPlan: {},
            headerValues: false,
            hasError: false
        }

    }

    componentDidMount() {
        const{valueData}=this.props;
        this.setState({valuesArray:valueData})
        this.props.getcolumnDefs({ type: PLANS_EMBEDDED_LIST });
    }
    componentDidUpdate(prevProps, prevState) {
        const { errorId, updateColumnsList, recalSuccess, recalcValues } = this.props.detialDialogData
        if (errorId && errorId != prevProps.detialDialogData.errorId) {
            this.setGridError(errorId);
            this.props.setError(false);
        }
        if (updateColumnsList && (updateColumnsList != prevProps.detialDialogData.updateColumnsList)) {
            this.props.getcolumnDefs({ type: PLANS_EMBEDDED_LIST });
        }
        if (recalSuccess && (recalSuccess != prevProps.detialDialogData.recalSuccess)) {
            this.handleDisplayRecalcValues(recalcValues)

        }
    }
    handleDisplayRecalcValues(recalcValues) {
        let recalctionValues = {};
        recalctionValues["EICOMP"] = recalcValues["PQCOMP"];
        recalctionValues["EIITEM"] = recalcValues["PQITEM"];
        recalctionValues["EILT"] = recalcValues["PQLT"];
        recalctionValues["EILTV"] = recalcValues["PQLTV"];
        recalctionValues["EIPACT"] = recalcValues["PQPACT"];
        recalctionValues["EIPCT"] = recalcValues["PQPCT"];
        recalctionValues["EIPCTD"] = recalcValues["PQPCTD"];
        recalctionValues["EIPCTP"] = recalcValues["PQPCTP"];
        recalctionValues["EIPDAT"] = recalcValues["PQPDAT"];
        recalctionValues["EIQTY"] = recalcValues["PQQTY"];
        recalctionValues["EIRDAT"] = recalcValues["PQRDAT"];
        recalctionValues["EIRECD"] = recalcValues["PQRECD"];
        recalctionValues["EISTAT"] = recalcValues["PQSTAT"];
        recalctionValues["EIVNDR"] = recalcValues["PQVNDR"];
        recalctionValues["EIWHSE"] = recalcValues["PQWHSE"];

        Object.keys(recalctionValues).map(key => {
            this.handleChangeValue(key, recalctionValues[key]);
        })
    }

    setGridError = errorId => {
        this.setState({ hasError: true, errorId }, () => {
            setTimeout(() => {
                this.setState({ hasError: false, errorId: false });
            }, 3e3);
        });
    };
    getLabelValue = (id) => {
        return <FormattedMessageComponent id={id}></FormattedMessageComponent>;
    }

    handleClose = () => {
        if (this.props.closeDialog) {
            this.props.closeDialog('openPlanDialog');
        }
    }

    handleSubmit = () => {
        let valid = this.props.onValid(this.state.valuesArray);
        if (valid) {
            // this.props.detialDialogData.plansUpdate({
            //     addAndDeleteFlag: addAndDeleteFlag, filterProps: filterProps, updateRecord: detailValues,
            //     currentRecord: planValues, currentPage: PLAN_PROPERTIES_PAGE, pageProps, direction: true
            //   });
            if (this.props.closeDialog) {
                this.props.closeDialog('openPlanDialog');
            } else {
                this.setGridError('10711');
                this.props.setError(false);
            }
        }
    }

    handleChangeValue = (key, val) => {
        if (!val) return
        this.setState({
            valuesArray: { ...this.state.valuesArray, [key]: val },
        });
    };

    onValueChanged = (rowIndex, colId, updatedData) => {
        const selectedRows = [...this.state.holdoutsSelectedRows];
        if (selectedRows && selectedRows.length > 0) {
            selectedRows[0] = updatedData;
            this.setState({ selectedRows })
        }
        this.props.onSetDataValueChange({ data: updatedData, rowIndex, colId })
    }

    handleItemSelection = type => {
        const { holdoutsSelectedRows } = this.state;
        if (type === 'remove') {
            this.props.removeRecord(holdoutsSelectedRows);
            this.setState({ holdoutsSelectedRows: false });
        }
        if (type === 'Add') {
            this.setState({ addDialog: true });
        }
        if (type === 'detail') {
            this.setState({ detailHoldouts: true });
        }
    };
    sendSelectedRows = event => {
        let array = [];
        array = [{ ...event.data }];
        this.setState({
            holdoutsSelectedRows: event,
            holdoutRows: array
        });
    };
    closeDialog = val => {
        this.setState({ [val]: false });
    };

    handleDetailRemove = () => {
        if (this.state.holdoutsSelectedRows.data) {
            return true
        }
        return false
    }

    onGridReady(params) {
        this.grid = params;
    }
    render() {
        const {
            columnDefs,
            pageProps,
            columnInfo,
            holdoutsRowData,
            warehouse,
        } = this.props.detialDialogData;

        const { currentPage, classes, plansLabelsData } = this.props;
        const { loading } = this.props.newPlanData
        const { addDialog, detailHoldouts, holdoutsSelectedRows,valuesArray } = this.state;
        const { tabcards } = plansLabelsData;
        return (
            <div>
                {(this.state.hasError) && this.state.errorId ? <div>
                    <GridErrorMessages
                        errorMessageLabels={this.props.errorMessageLabels}
                        popUp
                        id={this.state.errorId ? this.state.errorId : this.props.ServerError}
                    />
                </div> : ''}
                {addDialog && (
                    <AddHoldouts
                        closeDialog={this.closeDialog}
                        title={this.getLabelValue(HOLDOUT_ITEM)}
                        currentPage="eventitems"
                        isOpen={addDialog}
                        getLabelValue={this.getLabelValue}
                        newPlanData={this.props.newPlanData}
                        plansLabelsData={plansLabelsData}
                        columnDefs={columnDefs}
                        currentPage={currentPage}
                        onAddRec={this.props.onAddRec}
                        setValueData={this.props.setValueData}
                        valuesArray={this.state.valuesArray}
                        handleChangeValue={this.handleChangeValue}
                        values={this.props.headerData}
                        itemDetails={this.props.itemDetails}
                        onValid={this.props.onValid}
                        setError={this.props.setError}
                        warehouse={warehouse}

                    />
                )}
                {detailHoldouts && (
                    <DetailHoldouts
                        closeDialog={this.closeDialog}
                        title={this.getLabelValue(HOLDOUT_ITEM)}
                        currentPage="eventitems"
                        isOpen={detailHoldouts}
                        getLabelValue={this.getLabelValue}
                        newPlanData={this.props.newPlanData}
                        columnDefs={columnDefs}
                        currentPage={currentPage}
                        valuesArray={holdoutsSelectedRows}
                        onAddRec={this.props.onAddRec}
                        holdoutsValuesArray={this.state.valuesArray}
                        setValueData={this.props.setValueData}
                        values={this.props.headerData}
                        itemDetails={this.props.itemDetails}
                        warehouse={warehouse}
                        onValid={this.props.onValid}
                    />
                )}

                <DialogComponent
                    dialogTitle={this.getLabelValue('25044')}
                    isOpen={this.props.isOpen}
                    cancelText={TEXT_CANCEL}
                    submitText={TEXT_OK}
                    handleClose={() => this.handleClose()}
                    handleCancel={() => this.handleClose()}
                    handleSubmit={() => this.handleSubmit()}
                    isBackArrow
                    className={classes.dialogClass}
                >
                    <Header
                        color="primary"
                        headerData={this.props.headerData}
                        itemDetails={this.props.itemDetails}
                        commentFieldArray={this.props.commentFieldArray}
                        warehouse={warehouse}
                        valuesArray={this.state.valuesArray}
                        plansRecalcQty={this.props.plansRecalcQty}
                        setGridError={this.props.setGridError}
                        setError={this.props.setError}
                        handleChangeValue={this.handleChangeValue}
                        commentFieldArray={this.props.commentFieldArray}
                    ></Header>
                    <div className={classes.pageContainer1}>
                        <div className={classes.pageContainerThirty}>
                            {!loading &&
                                tabcards.map(formCard => {
                                    if (formCard.cardkey == PURCHASE_DATE_QUANTITY) {
                                        return (
                                            <div className={classes.notesForBlock}>
                                                <Box
                                                    mb={theme.spacing(0.5)}
                                                    className={classes.notesForLabel1}
                                                >
                                                    {formCard.cardtitle}
                                                </Box>
                                                <FormFieldsGenerator
                                                    cardHasDotsBtn
                                                    labelDisplayCharacters={20}
                                                    handleSubmitDataCallBack={
                                                        this.props.handleSubmitDataCallBack
                                                    }
                                                    key={formCard.cardkey}
                                                    fieldsArray={JSON.parse(
                                                        JSON.stringify(formCard.cardfields),
                                                    )}
                                                    valuesArray={valuesArray}
                                                    handleChangeValue={(key, val, field) =>
                                                        this.handleChangeValue(key, val, field)
                                                    }
                                                    handleFocusOut={(key, val, field) =>
                                                        this.props.setValueDataOnFocutOut({
                                                            key,
                                                            val,
                                                            field,
                                                        })
                                                    }
                                                    valueDisplayCharacters={18}
                                                    currentPage="eventitems"
                                                    noMassMaintenance
                                                />
                                            </div>
                                        );
                                    }
                                })}
                        </div>
                        <div className={classes.pageContainerThirtyPlus}>
                            {!loading &&
                                tabcards.map(formCard => {
                                    if (formCard.cardkey == PURCHASE_DATE_CALCULATION_FACTORS) {
                                        return (
                                            <div className={classes.notesForBlock}>
                                                <Box
                                                    mb={theme.spacing(0.5)}
                                                    className={classes.notesForLabel1}
                                                >
                                                    {formCard.cardtitle}
                                                </Box>
                                                <FormFieldsGenerator
                                                    cardHasDotsBtn
                                                    labelDisplayCharacters={23}
                                                    handleSubmitDataCallBack={
                                                        this.props.handleSubmitDataCallBack
                                                    }
                                                    key={formCard.cardkey}
                                                    fieldsArray={JSON.parse(
                                                        JSON.stringify(formCard.cardfields),
                                                    )}

                                                    valuesArray={valuesArray}
                                                    handleChangeValue={(key, val, field) =>
                                                        this.handleChangeValue(key, val, field)
                                                    }
                                                    handleFocusOut={(key, val, field) =>
                                                        this.props.setValueDataOnFocutOut({
                                                            key,
                                                            val,
                                                            field,
                                                        })
                                                    }
                                                    valueDisplayCharacters={18}
                                                    currentPage="eventitems"
                                                    noMassMaintenance
                                                />
                                            </div>
                                        );
                                    }
                                })}{' '}
                        </div>
                        <div className={classes.pageContainerThirtyT}>
                            {!loading &&
                                tabcards.map(formCard => {
                                    if (formCard.cardkey == OTHER_FACTORS) {
                                        return (
                                            <div className={classes.notesForBlock}>
                                                <Box
                                                    mb={theme.spacing(0.5)}
                                                    className={classes.notesForLabel1}
                                                >
                                                    {formCard.cardtitle}
                                                </Box>
                                                <FormFieldsGenerator
                                                    cardHasDotsBtn
                                                    labelDisplayCharacters={18}
                                                    handleSubmitDataCallBack={
                                                        this.props.handleSubmitDataCallBack
                                                    }
                                                    key={formCard.cardkey}
                                                    fieldsArray={JSON.parse(
                                                        JSON.stringify(formCard.cardfields),
                                                    )}
                                                    valuesArray={valuesArray}
                                                    handleChangeValue={(key, val, field) =>
                                                        this.handleChangeValue(key, val, field)
                                                    }
                                                    handleFocusOut={(key, val, field) =>
                                                        this.props.setValueDataOnFocutOut({
                                                            key,
                                                            val,
                                                            field,
                                                        })
                                                    }
                                                    currentPage="eventitems"
                                                    valueDisplayCharacters={20}
                                                    //currentPage="eventitems"
                                                    noMassMaintenance
                                                />
                                            </div>
                                        );
                                    }
                                })}{' '}
                        </div>
                    </div>
                    <div className={classes.pageContainerNext}>
                        <div className={classes.pageContainerThirty}>
                            {!loading &&
                                tabcards.map(formCard => {
                                    if (formCard.cardkey == PLAN_CONTROL_FACTORS) {
                                        return (
                                            <div className={classes.notesForBlock}>
                                                <Box
                                                    mb={theme.spacing(0.5)}
                                                    className={classes.notesForLabel1}
                                                >
                                                    {formCard.cardtitle}
                                                </Box>
                                                <FormFieldsGenerator
                                                    cardHasDotsBtn
                                                    labelDisplayCharacters={20}
                                                    handleSubmitDataCallBack={
                                                        this.props.handleSubmitDataCallBack
                                                    }
                                                    key={formCard.cardkey}
                                                    fieldsArray={JSON.parse(
                                                        JSON.stringify(formCard.cardfields),
                                                    )}
                                                    valuesArray={valuesArray}
                                                    handleChangeValue={(key, val, field) =>
                                                        this.handleChangeValue(key, val, field)
                                                    }
                                                    handleFocusOut={(key, val, field) =>
                                                        this.props.setValueDataOnFocutOut({
                                                            key,
                                                            val,
                                                            field,
                                                        })
                                                    }
                                                    valueDisplayCharacters={18}
                                                    currentPage="eventitems"
                                                    noMassMaintenance
                                                />
                                            </div>
                                        );
                                    }
                                })}
                        </div>
                        <div className={classes.pageContainerThirtyPlus}>
                            {!loading &&
                                tabcards.map(formCard => {
                                    if (formCard.cardkey == PLANNED_QTY_CALCULATION_FACTORS) {
                                        return (
                                            <div className={classes.notesForBlock}>
                                                <Box
                                                    mb={theme.spacing(0.5)}
                                                    className={classes.notesForLabel1}
                                                >
                                                    {formCard.cardtitle}
                                                </Box>
                                                <FormFieldsGenerator
                                                    cardHasDotsBtn
                                                    labelDisplayCharacters={25}
                                                    handleSubmitDataCallBack={
                                                        this.props.handleSubmitDataCallBack
                                                    }
                                                    key={formCard.cardkey}
                                                    fieldsArray={JSON.parse(
                                                        JSON.stringify(formCard.cardfields),
                                                    )}
                                                    valuesArray={valuesArray}
                                                    handleChangeValue={(key, val, field) =>
                                                        this.handleChangeValue(key, val, field)
                                                    }
                                                    handleFocusOut={(key, val, field) =>
                                                        this.props.setValueDataOnFocutOut({
                                                            key,
                                                            val,
                                                            field,
                                                        })
                                                    }
                                                    valueDisplayCharacters={12}
                                                    currentPage="eventitems"
                                                    noMassMaintenance
                                                />
                                            </div>
                                        );
                                    }
                                })}
                        </div>
                        <div className={classes.pageContainerThirtyT}>
                            {!loading &&
                                tabcards.map(formCard => {
                                    if (formCard.cardkey == PLAN_CONTROLS) {
                                        return (
                                            <div className={classes.notesForBlock}>
                                                <Box
                                                    mb={theme.spacing(0.5)}
                                                    className={classes.notesForLabel1}
                                                >
                                                    {formCard.cardtitle}
                                                </Box>
                                                <FormFieldsGenerator
                                                    cardHasDotsBtn
                                                    labelDisplayCharacters={20}
                                                    handleSubmitDataCallBack={
                                                        this.props.handleSubmitDataCallBack
                                                    }
                                                    key={formCard.cardkey}
                                                    fieldsArray={JSON.parse(
                                                        JSON.stringify(formCard.cardfields),
                                                    )}
                                                    valuesArray={valuesArray}
                                                    handleChangeValue={(key, val, field) =>
                                                        this.handleChangeValue(key, val, field)
                                                    }
                                                    handleFocusOut={(key, val, field) =>
                                                        this.props.setValueDataOnFocutOut({
                                                            key,
                                                            val,
                                                            field,
                                                        })
                                                    }
                                                    //globalDateFormat={globalDateFormat}
                                                    valueDisplayCharacters={12}
                                                    currentPage="eventitems"
                                                    noMassMaintenance
                                                />
                                            </div>
                                        );
                                    }
                                })}
                        </div>
                    </div>
                    <Box mt='1rem' >
                        {columnDefs && columnDefs.length && (
                            <EmbeddedList
                                className={classes.gridSize}
                                gridHeight="230px"
                                onValueChanged={this.onValueChanged}
                                rowColumnID={ROW_COLUMN_ID}
                                columnInfo={columnInfo}
                                singleClickEdit
                                gridAPI={this.grid}
                                columnDefs={columnDefs}
                                frameworkComponent={frameworkComponent}
                                pageProps={pageProps}
                                detailRowAction={() => this.handleDetailRemove}
                                deleteRowAction={() => this.handleDetailRemove}
                                selectedRows={this.state.holdoutRows}
                                onGridReady={this.onGridReady}
                                props={this.props}
                                listProps={this.props}
                                rowSelection={this.state.rowSelection}
                                onRowSelected={(e) => this.sendSelectedRows(e)}
                                rowData={holdoutsRowData}
                                menuItems={this.state.menuItems}
                                listPredecessor={getListPredecessor(PLANS_EMBEDDED_LIST)}
                                sendApi={() => { }}
                                dataKey="embeddedList"
                                hasPagination={false}
                                currentPage="planHoldouts"
                                namespace="planHoldouts"
                                updateShowHide={(data) => this.props.updateShowHide(data, "planholdouts")}
                                resetDefault={(data) => this.props.resetDefault(data)}
                                hasRowActions
                                isEnableSaveButton={false}
                                hasGridActions
                                handleItemSelection={this.handleItemSelection}

                                menuItemsHandled={['detail', 'Add', 'remove']}

                            >
                            </EmbeddedList>
                        )
                        }
                    </Box>
                    {/* </div> */}
                </DialogComponent>
            </div>

        );
    }
}

const mapStateToProps = function (state) {
    return {
        detialDialogData: selectDetailData(state)
    }
}

function mapDispatchToProps(dispatch) {
    return {
        dispatch,
        getcolumnDefs: (data) => dispatch(getcolumnDefs(data)),
        setApiCallCount: (data) => dispatch(setApiCallCount(data)),
        onSetPageProps: (data) => dispatch(onSetPageProps(data)),
        removeRecord: (data) => dispatch(removeRecord(data)),
        getVendorList: (data) => dispatch(getVendorList(data)),
        getItemsList: (data) => dispatch(getItemsList(data)),
        getWarehouseList: (data) => dispatch(getWarehouseList(data)),
        getHoldoutsList: (data) => dispatch(getHoldoutsList(data)),
        updateShowHide: (data, currentPage) => dispatch(updateShowHide(data, currentPage)),
        resetDefault: (data) => dispatch(resetDefault(data)),
        setColumnDefsLoaded: (data) => dispatch(setColumnDefsLoaded(data)),
        onSetDataValueChange: (data) => dispatch(onSetDataValueChange(data)),
        onAddRec: (data, detail, rowIndex) => dispatch(addRec(data, detail, rowIndex)),
        addRecordsfromNonStockAndItems: (data) => { dispatch(addRecordsfromNonStockAndItems(data)) },
        setLabelDataFlags: (data) => { dispatch(setLabelDataFlags(data)) },
        resetStateData: (data) => { dispatch(resetStateData(data)) },
        plansRecalcQty: (data) => dispatch(plansRecalcQty(data)),
        setError: (filterprops) => dispatch(setError(filterprops)),
        plansUpdate: (data) => dispatch(plansUpdate(data)),


    };
}

const withReducer = injectReducer({ key: 'detailDialogReducer', reducer });
const withSaga = injectSaga({ key: 'detailDialogSaga', saga });
const withConnect = connect(
    mapStateToProps,
    mapDispatchToProps,
);
export default compose(
    withReducer,
    withConnect,
    withSaga,
    withStyles(style)
)(DetailDialog);

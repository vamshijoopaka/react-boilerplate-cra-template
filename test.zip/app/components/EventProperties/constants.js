export const LABEL_LIST_URL_DATA = [
	{ "accessor": "KTRIMBO", "operator": "=", "fieldValue": "TrimEventUI", "prefixFlag": 1 },
	{ "accessor": "KLANGID", "operator": "=", "fieldValue": "ENG", "prefixFlag": 1 }
]
export const DEFAULT_VALUE_URL_DATA = [
	{ "accessor": "COMP", "operator": "=", "fieldValue": "", "prefixFlag": 0 },
	{ "accessor": "EVNT", "operator": "=", "fieldValue": "", "prefixFlag": 0 }
]

export const FILTER_DATA = ["COMP", "EVNT"];

export const LABEL_EVENT_DEFAULTS = "28004";
export const LABEL_ITEMS_ON_EVENT = "28005";
export const LABEL_STATISTICS = "28006";
export const LABEL_COPY = "25212";
export const LABEL_DELETE = "25211";
export const LABEL_ACTIONS = '28310';

export const CONTEXT_MENU_EVENT_ACTIONS = [
	{
		label: LABEL_COPY,
		key: LABEL_COPY,
		hasSubMenu: false,
		isDisable: false
	},
	{
		label: LABEL_DELETE,
		key: LABEL_DELETE,
		hasSubMenu: false,
		isDisable: false
	},
];


export const KEY_EVENT_EFFECT_MAINTENANCE = "Event Effect Maintenance";

export const CONTEXT_MENU_EVENT_BUTTON_ACTIONS = [
    {
        label: '52740',
        key: KEY_EVENT_EFFECT_MAINTENANCE,
        hasSubMenu: false,
        isDisable: false
    },
];

export const LABEL_EVENT_EFFECT_MAINTENANCE = "52754";




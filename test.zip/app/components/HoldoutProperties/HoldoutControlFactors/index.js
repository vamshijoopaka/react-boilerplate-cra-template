import React from 'react';
import { withStyles } from '@material-ui/core/styles';
import PropTypes from 'prop-types';
import FormFieldsGenerator from '../../common/FormFieldsGenerator';
import Spinner from '../../common/Spinner';
import {
    HOLDOUT_CONTROL_FACTORS,
    HOLDOUT_OTHER_CONTROL_FACTORS
} from './constants';
import './style.scss';
import { HOLDOUTS_LIST_PAGE } from 'components/common/constants';
import CardComponent from '../../common/CardComponent';

const propTypes = {
    setSaveData: PropTypes.func,
}

const style = () => ({
    pageContainer: {
        display: 'flex',
        backgroundColor: 'var(--background-app)',
        borderTop: 'none',
        padding: '16px',
    },
    card: {
        padding: '0px',
        backgroundColor: 'var(--background-content)',
        borderRadius: '4px',
        width: '100%',
        margin: '8px',
        '& .MuiCardHeader-root': {
            padding: '16px 32px'
        },
        '& .MuiCardContent-root': {
            padding: '16px 32px'
        }
    },
    simpleCardGroup: {
        width: '100%',
        display: 'flex',
        justifyContent: 'space-around',
    },
})

class HoldoutControlFactors extends React.Component {
    state = {
        tabcards: false
    };

    handleChangeValue = (key, val, field) => {
        if (!val && val !== '') return;
        this.props.setValueData({ key, val, field });
        this.setState({ isSaveDataDisabled: false })
    }

    getValueData = (valueData, newValueData) => {
        if (Object.keys(valueData).length && Object.keys(newValueData).length &&
            (JSON.parse(JSON.stringify(valueData)) !== JSON.parse(JSON.stringify(newValueData)))) {
            return newValueData;
        }
        return valueData;

    }

    componentDidMount() {
        let tabsData = this.props.HoldoutPropertiesData.holdoutDetailsLabelsData.tabcards;
        this.setState({ tabcards: tabsData });
    }

    render() {

        const { classes, setSaveData, globalDateFormat, pageFilterOptions,
            globalFilterOptions, columnDefs, canUpdateComponent, currentOwnerName, currentPage } = this.props;
        const { loading, valueData, newValueData } = this.props.HoldoutPropertiesData;
        const { tabcards } = this.state
        return (
            <div>
                {(tabcards && tabcards.length) ? (
                    <div className={classes.pageContainer}>
                        <div className={classes.simpleCardGroup}>
                            {/* <h1>Card 1 - HOLDOUT_CONTROL_FACTORS </h1> */}
                            { tabcards.map(formCard => {
                                if (formCard.cardkey == HOLDOUT_CONTROL_FACTORS) {
                                    return <CardComponent title={formCard.cardtitle} className={classes.card}>
                                        <FormFieldsGenerator
                                            currentOwnerName={currentOwnerName}
                                            cardHasDotsBtn={false}
                                            cardHasCheckBox={false}
                                            noMassMaintenance={true}
                                            labelDisplayCharacters={22}
                                            valueDisplayCharacters={38}
                                            handleSubmitDataCallBack={() => { }}
                                            key={formCard.cardkey}
                                            parentPage={HOLDOUTS_LIST_PAGE}
                                            className={'HOLDOUT_CONTROLS_FULL_GRID'}
                                            fieldsArray={JSON.parse(JSON.stringify(formCard.cardfields))}
                                            valuesArray={this.getValueData(valueData, newValueData)}
                                            handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                            enableAddButton={(e) => { setSaveData(e) }}
                                            globalDateFormat={globalDateFormat}
                                            pageFilterOptions={pageFilterOptions}
                                            globalFilterOptions={globalFilterOptions}
                                            columnDefs={columnDefs}
                                            currentPage={currentPage}
                                            canUpdateComponent={canUpdateComponent}
                                        />
                                    </CardComponent>
                                }
                            })}
                            {/* <h1>Card 2 - HOLDOUT_OTHER_CONTROL_FACTORS </h1> */}
                            {tabcards.map(formCard => {
                                if (formCard.cardkey == HOLDOUT_OTHER_CONTROL_FACTORS) {
                                    return <CardComponent title={formCard.cardtitle} className={classes.card}>
                                        <FormFieldsGenerator
                                            currentOwnerName={currentOwnerName}
                                            cardHasDotsBtn={false}
                                            cardHasCheckBox={false}
                                            noMassMaintenance={true}
                                            labelDisplayCharacters={22}
                                            valueDisplayCharacters={38}
                                            handleSubmitDataCallBack={() => { }}
                                            key={formCard.cardkey}
                                            parentPage={HOLDOUTS_LIST_PAGE}
                                            className={'HOLDOUT_CONTROLS_FULL_GRID'}
                                            fieldsArray={JSON.parse(JSON.stringify(formCard.cardfields))}
                                            valuesArray={this.getValueData(valueData, newValueData)}
                                            handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                            enableAddButton={(e) => { setSaveData(e) }}
                                            globalDateFormat={globalDateFormat}
                                            pageFilterOptions={pageFilterOptions}
                                            globalFilterOptions={globalFilterOptions}
                                            columnDefs={columnDefs}
                                            currentPage={currentPage}
                                            parentData={this.props.holdoutData}
                                            canUpdateComponent={canUpdateComponent}
                                        />
                                    </CardComponent>
                                }
                            })}
                        </div>
                    </div>
                ) : <Spinner loading type="list" />
                }
            </div>
        );
    }
}


HoldoutControlFactors.propTypes = propTypes;

export default withStyles(style)(HoldoutControlFactors);
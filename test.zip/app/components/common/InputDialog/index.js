import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { createMuiTheme, MuiThemeProvider } from '@material-ui/core/styles';
import theme from './../../../jda-gcp-theme';
import { withStyles } from '@material-ui/styles';
import FormattedMessageComponent from '../FormattedMessageComponent';
import PaperComponent from 'components/common/PaperComponent';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import { DialogTitle, IconButton } from '@material-ui/core';
import { Box } from '@material-ui/core';
import Button from '@material-ui/core/Button';
import CloseImage from '../../../images/close.png';
import ArrowBackIcon from '@material-ui/icons/ArrowBack';

const themes = createMuiTheme(theme);

themes.overrides = {
    MuiDialog: {
        paperWidthSm: {
            width: '310px',
        },
    },
    MuiPickersToolbar: {
        toolbar: {
            backgroundColor: theme.palette.common.darkOliveGreen
        }
    },
    MuiPaper: {
        root: {
            backgroundColor: '#ffffff'
        }
    },
    MuiPickersCalendarHeader: {
        iconButton: {
            backgroundColor: 'transparent'
        }
    },
    MuiButton: {
        textPrimary: {
            color: '#ffffff',
            fontSize: 12,
            backgroundColor: '#0066D0',
            '&:hover': {
                opacity: 0.9,
                backgroundColor: '#0066D0',
            },
            '&:first-child': {
                backgroundColor: '#9A9A9A',
                '&:hover': {
                    opacity: 0.9
                },
            }
        },
        contained: {
            boxShadow: theme.shadows[5],
            color: '#ffffff',
        },
        containedPrimary: {
            backgroundColor: '#0066D0'
        },
        containedSecondary: {
            backgroundColor: '#9A9A9A',
            '&:hover': {
                backgroundColor: '#9A9A9A',
                opacity: 0.9
            }
        },
    },
    MuiDialogContent: {
        root: {
            padding: '20px 16px'
        }
    },
    MuiFormControl: {
        root: {
            width: '100%'
        }
    },
    MuiInputBase: {
        root: {
            width: '100%'
        }
    },
    MuiAutocomplete: {
        listbox: {
            backgroundColor: '#ffffff'
        },
        clearIndicator: {
            display: 'none'
        },
        input: {
            color: '#000000',
        },
        inputRoot: {
            width: '100%',
            paddingRight: 10,
            paddingLeft: 20,
            'input': {
                padding: 0
            }
        },
        popupIndicator: {
            marginTop: 3,
            marginRight: '-5px'
        }
    },
    MuiInput: {
        root: {
            height: 25,
            maxWidth: '13rem',
            width: 'inherit'
        },
        input: {
            width: 'inherit'
        },
        underline: {
            '&:after': {
                borderBottom: '1px solid #3F4756',
            },
            '&:before': {
                borderBottom: '1px solid #3F4756',
            },
            '&:hover:after': {
                borderBottom: '2px solid ' + theme.palette.primary.default,
            },
            '&.Mui-disabled:before': {
                borderBottom: '1px solid ' + theme.palette.primary.disabled,
                borderBottomStyle: 'solid',
            }
        }
    },
    MuiList: {
        root: {
            backgroundColor: '#ffffff'
        }
    },
    MuiFormControlLabel: {
        root: {
            marginRight: 0,
        },
        labelPlacementTop: {
            alignItems: 'flex-start',
            marginLeft: 0,
        },
        label: {
            fontSize: '12px',
            color: theme.palette.common.label,
            padding: '10px 10px 10px 0',
            width: 'inherit'
        }
    },
    MuiInputBase: {
        root: {
            fontSize: 14,
            fontWeight: 400
        },
        input: {
            color: theme.palette.common.inputTextValue
        }
    },
    MuiMenu: {
        paper: {
            borderRadius: 4,
        },
        list: {
            '& > *': {
                padding: '0.6rem'
            }
        }
    },
    MuiFormLabel: {
        root: {
            color: 'black',
        },
    },
    MuiFormHelperText: {
        root: {
            color: 'gray',
        },
    },
    MuiSelect: {
        root: {
            color: 'black',
        },
        selectMenu: {
            height: '100%',
            display: 'flex',
            alignItems: 'center'
        }
    },
    MuiCard: {
      root: {
        color: 'var(--text)',
        padding: '1rem',
        boxShadow: '0 4px 8px rgba(0,0,0,0.10)',
        '&:hover': {
          boxShadow: '0 4px 8px rgba(0,0,0,0.25)',
        },
        '&:focus-within': {
          boxShadow: '0 4px 4px rgba(0,0,0,0.25)',
        },
      },
    },
    MuiCardHeader:{
      root:{
        padding: '1rem 0.5rem',
      },
      title:{
        color: 'var(--text)',
        fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
        fontSize: '18px',
        fontWeight: '700',
      }
    },
    MuiOutlinedInput: {
        root: {
            padding: '.5rem',
            height: '100%',
            alignItems: 'flex-start'
        },
        input: {
            padding: '0'
        }
    },
    MuiDialogActions: {
        root: {
            padding: '8px 16px',
            backgroundColor: theme.palette.common.white
        }
    },
    MuiDialogTitle: {
        root: {
            backgroundColor: '#ffffff',
            borderBottom: '1px solid #d8d8d8',
            padding: '9px 16px'
        }
    },
}

const styles = theme => ({
    closeIcon: {
        position: 'absolute',
        top: '10px',
        right: '20px',
        '& img': {
            cursor: 'pointer',
        }
    },
    dialogTitle: {
        cursor: 'move'
    },
    submitButton: {
        marginLeft: '10px'
    },
    titleText: {
        display: 'inline-block'
    },
    titleWrapper: {
    }
})

const defaultProps = {
    className: '',
};

const propTypes = {
    isOpen: PropTypes.any.isRequired,
    dialogTitle: PropTypes.any,
    cancelText: PropTypes.any.isRequired,
    submitText: PropTypes.any.isRequired,
    handleCancel: PropTypes.func.isRequired,
    handleSubmit: PropTypes.func.isRequired,
};

class InputDialog extends Component {
    constructor() {
        super();
    }

    render() {
        const { classes, isBackArrow} = this.props;
        return (
            <MuiThemeProvider theme={themes}>
                <Dialog
                    open={this.props.isOpen}
                    PaperComponent={PaperComponent}
                    aria-labelledby="draggable-dialog-title"
                    classes={{ paperWidthSm: this.props.classNamePaperWidthSm }}>
                    <DialogTitle className={classes.dialogTitle} id="draggable-dialog-title">
                        <div>
                            {isBackArrow &&
                                <IconButton onClick={this.props.handleClose}>
                                    <ArrowBackIcon></ArrowBackIcon>
                                </IconButton>
                            }
                            <span className={classes.titleText}>
                                {Boolean(Number(this.props.dialogTitle)) && <FormattedMessageComponent id={this.props.dialogTitle}></FormattedMessageComponent>
                                }
                                {!Boolean(Number(this.props.dialogTitle)) && this.props.dialogTitle}
                            </span>
                        </div>
                        <div className={classes.closeIcon}>
                            <img onClick={this.props.handleClose} src={CloseImage} alt={'close_icon'} />
                        </div>
                    </DialogTitle>
                    <DialogContent>
                        {this.props.children}
                    </DialogContent>
                    <DialogActions>
                        <Box>
                            {this.props.cancelText && <Button size="large" color="primary" variant="outlined" onClick={this.props.handleCancel}>
                                {Boolean(Number(this.props.cancelText)) && <FormattedMessageComponent id={this.props.cancelText}></FormattedMessageComponent>
                                }
                                {!Boolean(Number(this.props.cancelText)) && this.props.cancelText}
                            </Button>}
                            {this.props.submitText && <Button className={classes.submitButton} size="large" variant="contained" color="primary" onClick={this.props.handleSubmit} disabled={this.props.disableSubmit || false}>
                                {Boolean(Number(this.props.submitText)) && <FormattedMessageComponent id={this.props.submitText}></FormattedMessageComponent>
                                }
                                {!Boolean(Number(this.props.submitText)) && this.props.submitText}
                            </Button>}
                        </Box>
                    </DialogActions>
                </Dialog>
            </MuiThemeProvider>
        );
    }
}

InputDialog.defaultProps = defaultProps;

InputDialog.propTypes = propTypes;

export default withStyles(styles)(InputDialog);

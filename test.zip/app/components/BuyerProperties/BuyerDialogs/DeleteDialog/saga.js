import { call, put, takeLatest } from 'redux-saga/effects';
import request from 'utils/request';
import UrlFormatUtils from 'utils/sagaUrlFormatter';
import { API_URI } from 'utils/url';
import { urlEndPoints } from 'utils/urlJson';
import { OPTIONS } from 'components/common/constants';
import {
  GET_BUYERDELETE_LIST,
  GET_BUYERDELETE_COLUMN_DEFINITION,
  GET_BUYERDELETE_UPDATE_COLUMN_DEFINITION,
  RESET_DEFAULTS,
  GET_BUYERS_LIST,
} from './constants';
import {
  setBuyerDeleteListSuccess,
  setBuyerDeleteListFailure,
  setBuyerDeleteListColumnDefs,
  setBuyerDeleteListColumnDefsFailure,
  updateColumnDefsSuccess,
  updateColumnDefsFailure,
  setBuyersListSuccess,
  setBuyersListFailure,
} from './action';

export function* getBuyerDelete(action) {
  let url = `${API_URI}/${urlEndPoints.buyersList}`;
  url = UrlFormatUtils.formatUrlWithFilterAndSortOptions(url, action.data);
  try {
    let items;
    const postOptions = OPTIONS;
    const postData = {};
    postOptions.body = JSON.stringify(postData);
    items = yield call(request, url, postOptions);
    if (items.ok) {
      const jsonResponse = yield items.text();
      yield put(setBuyerDeleteListSuccess(JSON.parse(jsonResponse)));
    }
  } catch (err) {
    yield put(setBuyerDeleteListFailure(err));
  }
}

export function* getColumnDefs(action) {
  const url = `${API_URI}/${urlEndPoints.listHeader}`;
  const headerUrl = UrlFormatUtils.formalHeaderUrl(url, action.data.type);
  try {
    const headerCols = yield call(request, headerUrl);
    yield put(setBuyerDeleteListColumnDefs(headerCols));
  } catch (err) {
    yield put(setBuyerDeleteListColumnDefsFailure(err));
  }
}

export function* updateColumnDefs(action) {
  const url = `${API_URI}/${urlEndPoints.updateListHeader}`;
  const headerUrl = UrlFormatUtils.formalHeaderUrl(
    url,
    action.data.type,
    action.data.userId,
  );
  const postOptions = OPTIONS;
  let headerCols;
  let postData = {};
  if (action.data && action.data.record) {
    postData = action.data.record;
  }
  try {
    postOptions.body = JSON.stringify(postData);
    headerCols = yield call(request, headerUrl, postOptions);
    if (headerCols.ok) {
      const jsonResponse = yield headerCols.text();
      yield put(updateColumnDefsSuccess(JSON.parse(jsonResponse)));
    }
  } catch (err) {
    yield put(updateColumnDefsFailure(err));
  }
}

export function* resetDefaults(action) {
  const url = `${API_URI}/${urlEndPoints.listColDefault}`;
  const headerUrl = UrlFormatUtils.formalHeaderUrl(
    url,
    action.data.type,
    action.data.userId,
  );
  let headerCols;
  try {
    headerCols = yield call(request, headerUrl);
    yield put(setBuyerDeleteListColumnDefs(headerCols));
  } catch (err) {}
}

export function* getBuyersList(action) {
  let url = `${API_URI}/${urlEndPoints.buyersList}`;
  url = UrlFormatUtils.formatUrlWithFilterAndSortOptions(url, action.data);
  try {
    let buyers;
    const postOptions = OPTIONS;
    const postData = {};
    postOptions.body = JSON.stringify(postData);
    buyers = yield call(request, url, postOptions);

    if (buyers.ok) {
      const jsonResponse = yield buyers.text();
      const buyersJsonResponse = JSON.parse(jsonResponse);
      yield put(setBuyersListSuccess(buyersJsonResponse));
    }
  } catch (err) {
    yield put(setBuyersListFailure(err));
  }
}
export default function* buyerDeleteSaga() {
  yield takeLatest(GET_BUYERDELETE_LIST, getBuyerDelete);
  yield takeLatest(GET_BUYERDELETE_COLUMN_DEFINITION, getColumnDefs);
  yield takeLatest(GET_BUYERDELETE_UPDATE_COLUMN_DEFINITION, updateColumnDefs);
  yield takeLatest(RESET_DEFAULTS, resetDefaults);
  yield takeLatest(GET_BUYERS_LIST, getBuyersList);
}

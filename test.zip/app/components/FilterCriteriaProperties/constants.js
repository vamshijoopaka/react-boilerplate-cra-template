export const KEY_OWNER_ID = 'FVOWNR';
export const KEY_FILTERCRITERIA_ID = 'FVREFN';
export const KEY_TYPE = 'FVTYPE';

export const LABEL_ACTIONS = '28310';
export const LABEL_BUYER_ID = '33174';
export const LABEL_FILTERCRITERIA_ID = '40029';
export const LABEL_TYPE = '33018';
export const LABEL_OWNER = '39948';
export const LABEL_DESCRIPTION = '50805';
export const LABEL_COMMENT = '34345';
export const LABEL_FILTERCRITERIA_LOCK = '39950';
export const LABEL_FILTERCRITERIA_EVI = '39949';
export const KEY_DELETE ='Delete';

export const CONTEXT_MENU_HEADER = [
  {
    label: '28642',
    key: KEY_DELETE,
    hasSubMenu: false,
    isDisable: false
  },
]

export const DescriptionField = [{
  FDFNAM: 'DESC', dataType: 'text', toUppercase: true, maxLength: 15, key: 'DESC',
  prefixFlag: 0, TLLAB: 'Description', disabled: false
}]
export const LockField = [{
  FDFNAM: 'LOCK', dataType: 'checkbox', toUppercase: true, maxLength: 15, key: 'LOCK',
  prefixFlag: 0, TLLAB: 'Lock', disabled: false
}]
export const EVIField = [{
  FDFNAM: 'CEVI', dataType: 'checkbox', toUppercase: true, maxLength: 15, key: 'CEVI',
  prefixFlag: 0, TLLAB: 'EVI', disabled: true
}]

export const FILTERLIST = [{
  FDFNAM: 'KUMAR'
}]

export const FILTERLISTDATA = {
  FIELD: 'Company ID',
  OPERATOR: 'Equal to',
  VALUE: 'E3T'
}

export const COLUMNINFO = { PRODCODE: "T", KEYCODE: "51133 ", USERID: "SYSTEM " }

export const PAGEPROPS = {
  actualPage: 0,
  actualPageSize: 10,
  currentPage: 0,
  isForwardDirection: true,
  isPageSizeChanged: false,
  pageSize: 100,
  totalCount: 10
}

export const COLUMNDEFS = [
  {
    headerName: "Field", field: "FIELD", width: 280, cellStyle: { 'text-align': "left", fontFamily: 'Roboto', fontSize: '12px', color: '#3F4756' }, editable: false
  },
  {
    headerName: "Operator", field: "OPERATOR", width: 280, cellStyle: { 'text-align': "left", fontFamily: 'Roboto', fontSize: '12px', color: '#3F4756' }, editable: false
  },
  {
    headerName: "Value", field: "VALUE", editable: false, cellStyle: { 'text-align': "left", fontFamily: 'Roboto', fontSize: '12px', color: '#3F4756' }, width: 450, editable: false
  }];
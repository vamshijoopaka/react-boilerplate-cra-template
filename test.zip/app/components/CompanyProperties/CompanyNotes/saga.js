import { call, put, takeLatest, takeEvery } from 'redux-saga/effects';

import request from 'utils/request';
import { GET_COMPANY_NOTES, GET_COMPANY_NOTE_DETAILS, CONTROL_COMPANY_NOTE_CREATION,} from './constants';
import { getCompanyNotesSuccess, getCompanyNotesFailure, getNoteDetailsAllSuccess, getNoteDetailsSuccess, getNoteDetailsFailure,
    controlNoteCreationSuccess, controlNoteCreationFailure } from './action';
import { API_URI } from '../../../utils/url';
import { urlEndPoints } from 'utils/urlJson';
import UrlFormatUtils from 'utils/sagaUrlFormatter';
import { OPTIONS } from '../../common/constants';

export function* getCompanyNotesList(action){
    let url, response;
    url = `${API_URI}/${urlEndPoints["noteDisplay"]}`;
    url = UrlFormatUtils.formatUrlWithFilterAndSortOptions(url, action.data.body);
    let postOptions = JSON.parse(JSON.stringify(OPTIONS));
    //send CJDATE in body for notes list
    postOptions.body = JSON.stringify(action.data.record);
    try{
        response = yield call(request, url, postOptions);
        const jsonResponse = yield response.text()
        yield put(getCompanyNotesSuccess(jsonResponse));
    }
    catch(err){
        yield put(getCompanyNotesFailure(err));
    }
}

export function* getNoteDetails(action) {
    let url, response;
    url = `${API_URI}/${urlEndPoints["noteDisplay"]}`;
    url = UrlFormatUtils.formatUrlWithFilterAndSortOptions(url, action.data.body);
    let postOptions = JSON.parse(JSON.stringify(OPTIONS));
    //send CJDATE in body for notes list
    postOptions.body = JSON.stringify(action.data.record);
    try{
        response = yield call(request, url, postOptions);
        if (response.ok) {
            const jsonResponse = yield response.text()
            if (action.data.allFlag) {
                yield put(getNoteDetailsAllSuccess(JSON.parse(jsonResponse)))
            } else {
                yield put(getNoteDetailsSuccess(jsonResponse));
            }
        }
    }
    catch(err){
        yield put(getNoteDetailsFailure(err));
    }
}
export function* controlNoteCreation(action) {
    let controlKey;
    let url = `${API_URI}/${urlEndPoints['noteCreationControl']}`;
    let postOptions = JSON.parse(JSON.stringify(OPTIONS));
    postOptions.body = JSON.stringify(action.data.body);
    try {
        controlKey = yield call(request, url, postOptions);
        if (controlKey.ok) {
            let res = yield controlKey.text();
            yield put(controlNoteCreationSuccess(res));
        }
    } catch (err) {
        yield put(controlNoteCreationFailure(err));
    }
}

export default function* CompanyNotesSaga() {
    yield takeLatest(GET_COMPANY_NOTES, getCompanyNotesList);
    yield takeEvery(GET_COMPANY_NOTE_DETAILS, getNoteDetails);
    yield takeEvery(CONTROL_COMPANY_NOTE_CREATION, controlNoteCreation)
}



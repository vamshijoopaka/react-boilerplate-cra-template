/**
 *
 * Asynchronously loads the component for ArchexcepsList
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));


export const effectMaintenanceFlexibleDS = {

/* Effect Maintenance Card Fields */
    "EHECHG" : "",
    "EHEACT" : "",
    "EHPTYP" : "",
    "EHSDAT" : "",
    "EHEDAT" : "",
    "EVTSEL" : "C", /* Radio Button for Current Event=C and Multiple Events=M */

/* Event Selection Card Fields */
    "EHGRP1" : "",
    "EHGRP2" : "",
    "EHGRP3" : "",
    "EHGRP4" : "",
    "EHGRP5" : "",
    "EHGRP6" : "",

/* Item Selection Card Fields */
    "EHWHSE" : "",
    "EHREGN" : "",
    "EHVNDR" : "",
    "EITYPE" : "",
    "EHRELE" : "",
    "EHMPRF" : "",
    
    "EIGRP1" : "",
    "EIGRP2" : "",
    "EIGRP3" : "",
    "EIGRP4" : "",
    "EIGRP5" : "",
    "EIGRP6" : "",

/* Submit Batch Checkbox */
    "EHSUBBT" : "1",

};

export const CARDKEY_EVENT_EFFECT_MAINTENANCE_HEADER = "40";
export const CARDKEY_EVENT_EFFECT_MAINTENANCE = "52754";
export const CARDKEY_EVENT_SELECTION = "52755";
export const CARDKEY_ITEM_SELECTION = "52756";

export const effectMaintenanceBody = {

    "WCOMP" : "" , 
    "WHEVNT" : "" , 
    "WEFFCT" : "" , 
    "WIDR" : "" , 
    "WPTYP" : "" , 
    "WEGRP1" : "" , 
    "WEGRP2" : "" , 
    "WEGRP3" : "" , 
    "WEGRP4" : "" , 
    "WEGRP5" : "" , 
    "WEGRP6" : "" , 
    "WHSID" : "" , 
    "RGNID" : "" , 
    "VNDID" : "" , 
    "ITYPE" : "" , 
    "IRELE" : "" , 
    "IPRFL" : "" , 
    "WIGRP1" : "" , 
    "WIGRP2" : "" , 
    "WIGRP3" : "" , 
    "WIGRP4" : "" , 
    "WIGRP5" : "" , 
    "WIGRP6" : "" , 
    "WEMULT" : "0" , 
    "WESBMT" : "1"

};
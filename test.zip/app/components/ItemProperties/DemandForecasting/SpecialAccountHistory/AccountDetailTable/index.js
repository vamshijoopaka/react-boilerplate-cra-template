import React from 'react';
import PropTypes from 'prop-types';
import {
  Table,
  TableContainer,
  TableRow,
  TableCell,
  TableHead,
  TableBody,
  withStyles,
} from '@material-ui/core';
import FieldInput from 'components/common/Form/FieldInput';

const styles = () => ({
  tableContainer: {
    width: '100%',
  },
  table: {
    width: '100%',
  },
  tableHead: {
    color: '#000',
  },
  tableCell1: {
    whiteSpace: 'nowrap',
    backgroundColor: '#f5f5f6',
    color: '#000000',
    border: 'solid 1px #000000',
    padding: 5,
    minWidth: 100,
    '& input': {
      backgroundColor: 'transparent',
      width: '100%',
    },
  },
  tableCell2: {
    whiteSpace: 'nowrap',
    backgroundColor: '#FFFFFF',
    color: '#000000',
    border: 'solid 1px #000000',
    padding: 5,
    minWidth: 100,
    '& input': {
      backgroundColor: 'transparent',
      width: '100%',
    },
  },
  tableHeaderCell: {
    textAlign: 'center',
  },
  tableCell: {
    textAlign: 'right',
  },
  selected: {
    backgroundColor: '#d3f0fa !important',
  },
  tableRow: {
    cursor: 'pointer',
  },
});

class AccountDetailTable extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {};
  }

  onRowSelect = name => {
    this.props.onRowSelect(name);
  };

  render() {
    const {
      classes,
      columnDefs,
      rowsData,
      selectedYear,
      onChange,
      canUpdateComponent,
    } = this.props;
    const keys = Object.keys(rowsData);
    //E3C30659-Security-For View Only , disable Existing notes button 
    const disableCell = canUpdateComponent
      ? canUpdateComponent.update
        ? true
        : false
      : true;
    //E3C30659-End
    return (
      <React.Fragment>
        <TableContainer style={{ width: 100, float: 'left' }}>
          <Table className={classes.table}>
            <TableHead>
              <TableRow>
                <TableCell
                  className={classes.tableCell1}
                  style={{ height: 28, borderRight: 'none' }}
                />
              </TableRow>
            </TableHead>
            <TableBody>
              {keys && keys.length
                ? keys.map((key, index) => (
                  <TableRow
                    className={classes.tableRow}
                    onClick={() => this.onRowSelect(key)}
                  >
                    <TableCell
                      className={
                        classes[`tableCell${index % 2 === 0 ? '2' : '1'}`]
                      }
                      style={{ height: 30, borderRight: 'none' }}
                    >
                      {key}
                    </TableCell>
                  </TableRow>
                ))
                : null}
            </TableBody>
          </Table>
        </TableContainer>
        <TableContainer
          className={classes.tableContainer}
          style={{ width: 'calc(100% - 100px)', float: 'right' }}
        >
          <Table className={classes.table}>
            <TableHead>
              <TableRow>
                {columnDefs && columnDefs.length
                  ? columnDefs.map(column => (
                      <TableCell
                        className={`${classes.tableCell1} ${
                          classes.tableHeaderCell
                        }`}
                      >
                        {column}
                      </TableCell>
                    ))
                  : null}
              </TableRow>
            </TableHead>
            <TableBody>
              {keys && keys.length
                ? keys.map((key, index) => (
                    <TableRow
                      onClick={() => this.onRowSelect(key)}
                      className={classes.tableRow}
                    >
                    {rowsData[key].data && rowsData[key].data.length
                      ? rowsData[key].data.map((data, index2) => (
                        <TableCell
                          className={`${classes.tableCell} ${
                            classes[
                              `tableCell${index % 2 === 0 ? '2' : '1'}`
                            ]
                              } ${
                                selectedYear === key ? classes.selected : ''
                              }`}
                        >
                              <input
                                type="text"
                                style={{
                                  border: 'none',
                                  borderBottom: 'solid 1px #000',
                                  textAlign: 'right',
                                  cursor: 'text',
                                }}
                                value={data.toLocaleString('en')}
                                onChange={event =>
                                  onChange(
                                    columnDefs[index2],
                                    key,
                                    event.target.value.replaceAll(',', ''),
                                  )
                                }
                              />
                        </TableCell>
                      ))
                      : null}
                  </TableRow>
                ))
                : null}
            </TableBody>
          </Table>
        </TableContainer>
      </React.Fragment>
    );
  }
}

AccountDetailTable.propTypes = {
  classes: PropTypes.object,
  columnDefs: PropTypes.array,
  rowsData: PropTypes.array,
  onRowSelect: PropTypes.func,
  onChange: PropTypes.func,
  selectedYear: PropTypes.string,
  canUpdateComponent: PropTypes.object,
};

export default withStyles(styles)(AccountDetailTable);

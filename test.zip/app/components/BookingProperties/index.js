/**
 *
 * BookingProperties
 *
 */

import React, { Component } from 'react'
import { withStyles, Button, Box } from '@material-ui/core';
import KeyboardArrowDownIcon from '@material-ui/icons/KeyboardArrowDown';
import Typography from '@material-ui/core/Typography';
import KeyboardArrowUpIcon from '@material-ui/icons/KeyboardArrowUp';
import SaveIcon from '@material-ui/icons/Save';
import MoreVertIcon from '@material-ui/icons/MoreVert';
import FilterIcon from "../../images/icon_filter.png";
import { isEqual } from 'lodash';
import FormattedMessageComponent from '../common/FormattedMessageComponent';
import CardComponent from '../common/CardComponent';
import Spinner from 'components/Common/Spinner';
import FormFieldsGenerator from '../common/FormFieldsGenerator';
import ContextMenuCreateNew from '../common/ContextMenuCreateNew';
import ConfirmationDialog from 'components/common/ConfirmationDialog';
import BreadcrumbContextMenu from 'components/common/BreadcrumbContextMenu';
import Filter from 'containers/common/Filter';
import GridErrorMessages from 'components/common/GridErrorMessages';
import CopyDialog from "./CopyDialog";
import DeleteDialog from './DeleteDialog'
import {
	BOOKINGS_PROPERTIES_PAGE,
	GLOBAL_FILTER_OPTIONS,
	COLUMN_VALUE_ACCESSOR,
	INITIAL_PAGE_PROPS,
	BOOKINGS_LIST_PAGE,
	BADGE_MAX_COUNT,
	COLUMN_FIELD_LEN,
	TEXT_OK, TEXT_ALERT
} from '../common/constants';
import {
	getListPredecessor,
	prepareValueDataForBookings,
	setSortDataFromSortCriteria,
	getDefaultSortInfo,
	getFilterDataFromLocalStorage,
	getFilterDataFromCriteriaDetails,
	handleFieldValuesByLength,
	getUpdateRestrictionOnComponent,
	capitalizeFirstLetter,
} from 'utils/util';
import { getDBSelectorFilterValues, prepareTooltipValues } from 'utils/filterData';
import { onChangeContextMenu, updateBreadCrumbContextMenu } from 'utils/contextMenu';
import {
	HeaderAPIValuesJSON,
	BOOKING_CONTROL_FACTORS,
	LABEL_VENDOR_ID,
	LABEL_SUB_VENDOR_ID,
	LABEL_VENDOR_NAME,
	LABEL_WAREHOUSE_NAME,
	LABEL_WAREHOUSE_ID,
	LABEL_ITEM_ID,
	LABEL_ITEM_NAME, CONTEXT_MENU_BOOKING_ACTIONS,
	LABEL_COPY, LABEL_DELETE,
	LABEL_LIST_URL_DATA,
	DEFAULT_VALUE_URL_DATA,
	BRACKET_LABEL_URL_DATA,
} from "./constants";

import BookingNotes from './BookingNotes';
import { LABEL_NOTE } from './BookingNotes/constants';
import { Badge } from '@material-ui/core';
const style = theme => ({
	propertiesContentWrapper: {
		margin: '10px auto',
		borderRadius: '4px',
		overflow: 'hidden',
		boxShadow: '0 2px 4px var(--secondary-s10)',
		overflowX: 'auto'
	},
	propertiesHeaderContainer: {
		width: '100%',
		marginBottom: '1.5rem',
		backgroundColor: 'var(--background-app)',
		borderRadius: '4px',
		borderTopLeftRadius: '0px',
		borderTopRightRadius: '0px',
		overflow: 'hidden',
		boxShadow: '0 4px 4px var(--secondary-s10)',
		overflowX: 'auto'
	},
	boookingDetailContainer: {
		display: 'flex',
		width: '100%',
		backgroundColor: 'var(--background-content)',
		fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
		alignItems: 'center',
		padding: '0 0 0 24px',
		position: 'relative',
		minWidth: '630px'
	},
	boookingDetailDetailsWrapper: {
		width: '100%',
		display: 'flex',
	},
	pageContainer: {
		display: 'flex',
		backgroundColor: 'var(--background-app)',
		borderTop: 'none',
		padding: '10px 10px',
	},
	card: {
		padding: '0px',
		backgroundColor: 'var(--background-content)',
		borderRadius: '4px',
		width: '100%',
		margin: '10px',
		'& .MuiCardHeader-root': {
			padding: '22px 20px 0 20px'
		},
		'& .MuiCardContent-root': {
			padding: '16px 15px 10px 15px'
		}
	},
	marginLeftZero: {
		marginLeft: '0',
	},
	boookingArrow: {
		padding: '0 !important',
		margin: '0',
		minWidth: '16px',
		background: 'none',
		height: '16px',
		width: '16px',
	},
	bookingArrowWrapper: {
		display: 'flex',
		flexDirection: 'column',
		border: '1px solid var(--primary-default)',
		borderRadius: '4px',
		justifyContent: 'center',
		alignItems: 'baseline',
		height: '38px',
		padding: '2px',
	},
	vendorDetailRow: {
		width: '75%',
		display: 'flex',
		flexWrap: 'wrap',
		padding: '0px 0 24px 0',
		paddingLeft: '15px'
	},
	vendorDetail: {
		padding: '0px 0px 0 0px',
		lineHeight: '1.1',
	},
	vendorIDBlock: {
		display: 'flex',
	},
	vendorIdDetails: {
		width: '15ch',
		padding: '0 30px 0 0px',
		lineHeight: '1.1'
	},
	vendorLabel: {
		color: 'var(--header-label-color)',
		paddingBottom: '6px',
		width: '20ch',
	},
	vendorSubVendorDetails: {
		display: 'flex',
		flexDirection: 'column',
		width: '16ch',
		padding: '0 30px 0 0px',
		lineHeight: '1.1'
	},
	nameField: {
		paddingTop: '32px'
	},
	vendorValue: {
		color: 'var(--value)',
	},
	vendorIDSubID: {
		paddingRight: '24px'
	},
	IdNameBlock: {
		paddingRight: '40px',
	},
	bookingActions: {
		top: '24px',
		padding: '0px 20px 20px 20px',
		right: '16px',
		display: 'flex',
		position: 'absolute',
		alignItems: 'center',
		justifyContent: 'space-between',
		'@media (max-width: 1220px)': {
			flexWrap: 'wrap',
			width: '250px'
		}
	},
	buttonActions: {
		display: 'flex',
		alignItems: 'center',
		'@media (max-width: 1220px)': {
			marginBottom: '20px'
		},
		'& .MuiButton-root': {
			borderRadius: '4px',
			fontSize: '14px',
			width: '120px',
			lineHeight: '14px',
		},
		'& .MuiButton-sizeLarge': {
			fontSize: '18px',
		},
		'& .MuiButton-sizeSmall': {
			fontSize: '12px',
			padding: '8px 16px',
		},
		'& .MuiButton-containedPrimary': {
			backgroundColor: theme.palette.primary.default,
			border: '1px solid rgba(0, 0, 0, 0)',
			boxShadow: 'none',
			color: 'var(--background-content)',
			'&:hover': {
				backgroundColor: theme.palette.primary.hover,
				color: 'var(--background-content)',
				border: '1px solid rgba(0, 0, 0, 0)',
			},
			'&:focus': {
				backgroundColor: theme.palette.primary.focus,
				color: 'var(--background-content)',
				border: '1px solid rgba(0, 0, 0, 0)',
			},
			'&:active': {
				backgroundColor: theme.palette.primary.active,
				color: 'var(--background-content)',
				border: '1px solid rgba(0, 0, 0, 0)',
			}
		},
		'& .MuiButton-containedSecondary': {
			backgroundColor: 'var(--background-content)',
			border: '1px solid var(--button-tertiary-color)',
			color: 'var(--button-tertiary-color)',
			boxShadow: '0px 4px 14px rgba(0, 0, 0, 0.05)',
			'&:hover': {
				backgroundColor: 'var(--background-content)',
				color: 'var(--button-tertiary-hover-color)',
				border: '1px solid var(--button-tertiary-hover-color)',
			},
			'&:focus': {
				backgroundColor: 'var(--background-content)',
				color: 'var(--button-tertiary-focused)',
				border: '1px solid var(--button-tertiary-focused)',
			},
			'&:active': {
				backgroundColor: 'var(--background-content)',
				color: 'var(--button-tertiary-hover-color)',
				border: '1px solid var(--button-tertiary-hover-color)',
			},
			'&.Mui-disabled': {
				color: theme.palette.primary.disabled,
				textDecoration: 'unset',
				backgroundColor: 'unset',
				textShadow: 'unset'
			}
		},
		'& .MuiButton-outlinedPrimary': {
			border: `${'1px solid '}${theme.palette.primary.default}`,
			boxShadow: '0px 4px 14px rgba(0, 0, 0, 0.05)',
			backgroundColor: 'var(--background-content)',
			color: theme.palette.primary.default,
			'&:hover': {
				backgroundColor: 'var(--background-content)',
				border: '1px solid var(--button-secondary-hover-border)',
				color: 'var(--button-secondary-hover-border)',
			},
			'&:focus': {
				backgroundColor: 'var(--background-content)',
				border: `${'1px solid '}${theme.palette.primary.default}`,
				color: theme.palette.primary.default
			},
			'&:active': {
				backgroundColor: 'var(--background-content)',
				border: '1px solid var(--primary-button-pressed)',
				color: 'var(--primary-button-pressed)'
			},
			'&.Mui-disabled': {
				color: theme.palette.primary.disabled,
				textDecoration: 'unset',
				backgroundColor: 'unset',
				textShadow: 'unset'
			}
		},
		'& .MuiButton-outlinedSecondary': {
			backgroundColor: 'var(--background-content)',
			border: '1px solid var(--button-tertiary-color)',
			color: 'var(--button-tertiary-color)',
			boxShadow: '0px 4px 14px rgba(0, 0, 0, 0.05)',
			'&:hover': {
				backgroundColor: 'var(--background-content)',
				color: 'var(--button-tertiary-hover-color)',
				border: '1px solid var(--button-tertiary-hover-color)',
			},
			'&:focus': {
				backgroundColor: 'var(--background-content)',
				color: 'var(--button-tertiary-focused)',
				border: '1px solid var(--button-tertiary-focused)',
			},
			'&:active': {
				backgroundColor: 'var(--background-content)',
				color: 'var(--button-tertiary-hover-color)',
				border: '1px solid var(--button-tertiary-hover-color)',
			},
			'&.Mui-disabled': {
				color: theme.palette.primary.disabled,
				textDecoration: 'unset',
				backgroundColor: 'unset',
				textShadow: 'unset'
			}
		},
	},
	bookingActionsFilter: {
		minWidth: '37px',
		border: '1px solid var(--primary-default)',
		height: '32px',
		marginLeft: '15px',
		'@media (max-width: 1220px)': {
			marginLeft: '0px'
		},
		'& img': {
			width: '14px',
			height: '14px'
		},
		'& svg': {
			width: '18px',
			height: '18px'
		}
	},
	menuButton: {
		minWidth: '37px',
		border: '1px solid var(--primary-default)',
		height: '32px',
		marginLeft: '15px',
		borderRadius: '4px',
		display: 'flex',
		alignItems: 'center',
		justifyContent: 'center',
		'@media (max-width: 1220px)': {
			marginLeft: '0px'
		},
	},
	adjustCardFieldsInline: {
		display: 'grid !important',
		width: '100%',
		gridTemplateColumns: 'auto auto',
		paddingRight: '22px'
	},
    references: {
        position: 'absolute',
        right: '3rem',
        bottom: '0px',
                
        '&& .MuiBadge-root': {              //E3C30273_Styling for Badge
            '& .MuiBadge-badge': {
                    fontSize: '0.6 rem',
                    padding: '2px 5px',
                    height: '13.5px',
                    minWidth: props => (props.notesCountWidth || '21px'),                                     
            }
        }
    },
});

function TabContainer(props) {
	return (
		<Typography className={'minWidth1100'} component="div">
			{props.children}
		</Typography>
	);
}

class BookingProperties extends Component {
	constructor(props) {
		super(props);
		this.state = {
			isSaveDataDisabled: true,
			headerData: false,
			columnDefs: [],
			stateData: false,
			totalCount: 0,
			fromPage: false,
			hasError: false,
			errorId: false,
			canUpdateComponent: false,
			changeDataAPI: false,
			openFilterPopup: false,
			previousFilterValues: false,
			showConfirmationDialog: false,
			dialogTitle: '',
			hasWarning: false,
			fromListPage: null,
			hasFiltersChanged: false,
			hasSortChanged: false,
			isDataLoaded: false,
			isInitialAPICall: true,
			valueDataFailureMessages: [],
			headerValues: HeaderAPIValuesJSON[0],
			saveDisabled: false,
			isOpenActionsContextMenu: false,
			menuRef: null,
			contextMenuList: [...CONTEXT_MENU_BOOKING_ACTIONS],
			isFiltersChanged: false,
			openCopyPopup: false,
			openDeletePopup: false,
			dialogBody: false,
			parameterValues: [],
			notesCount: 0,
			notesCountWidth: '22px',
			bracketsNotesFilterObj: {},
			noRecordForFilter: false
		};
		this.prepareHeaderDataJSON = this.prepareHeaderDataJSON.bind(this);
		this.handleBookingHeaderRightArrowClick = this.handleBookingHeaderRightArrowClick.bind(this);
		this.handleBookingHeaderLeftArrowClick = this.handleBookingHeaderLeftArrowClick.bind(this);
		this.getApiObj = this.getApiObj.bind(this);
		this.makeAPICallForPageUpDown = this.makeAPICallForPageUpDown.bind(this);
		this.getApiObjForPageUpDown = this.getApiObjForPageUpDown.bind(this);
		this.getLabelValue = this.getLabelValue.bind(this);
		this.setRecordDataValues = this.setRecordDataValues.bind(this);
		this.forceUpdateHandler = this.forceUpdateHandler.bind(this);
		this.setFilterValuesFromState = this.setFilterValuesFromState.bind(this);
		this.handleBookingHeaderFilterClick = this.handleBookingHeaderFilterClick.bind(this);
		this.handleBookingHeaderSaveClick = this.handleBookingHeaderSaveClick.bind(this);
		this.onContextMenuChange = this.onContextMenuChange.bind(this);
		this.sendAPICallForValues = this.sendAPICallForValues.bind(this);
		this.handleNoDataSets = this.handleNoDataSets.bind(this);
		this.handleValueDataErrorMessages = this.handleValueDataErrorMessages.bind(this);
		this.handleChangeValue = this.handleChangeValue.bind(this);
		this.setIsOpenActionsContextMenu = this.setIsOpenActionsContextMenu.bind(this);
		this.handleBookingHeaderActionItemSelection = this.handleBookingHeaderActionItemSelection.bind(this);
		this.getValueData = this.getValueData.bind(this);
		this.setNotesCount = this.setNotesCount.bind(this); 
	}

	handleNoDataSets() {
		const { bookingDetailsLabelsData, copyBookingDetailsLabelsData } = this.props.bookingsProperties;
		if (this.state.isDataLoaded) {
			if ((bookingDetailsLabelsData && Object.keys(bookingDetailsLabelsData) && Object.keys(bookingDetailsLabelsData).length) &&
				copyBookingDetailsLabelsData && copyBookingDetailsLabelsData.length) {
				// do nothing here
			} else {
				this.props.setNoDataCallBackValue(true);
				const paramsString = window.location.search;
				if (paramsString && paramsString.length) {
					const paramsArray = paramsString.split('?');
					if (paramsArray && paramsArray.length && paramsArray.length > 1) {
						const params = paramsArray[1].split('&');
						const tabId = params[0].split('=')[1];
						const breadCrumbId = params[1].split('=')[1];
						this.props.removeCurrentRecordObj(tabId, breadCrumbId);
					}
				}
			}
		}
	}

	handleBookingHeaderFilterClick() {
		if (this.state.isFiltersChanged && this.props.bookingsProperties.isValueDataAPIFailure|| this.props.bookingsProperties?.hasNoPrevNext) {
			this.props.onSetFilterProps(this.state.previousFilterValues);
			this.props.setGlobalFilterProps(this.state.previousFilterValues);
			this.props.setChildTabFilterProps(this.state.previousFilterValues);
			this.setState({ isFiltersChanged: false });
			this.props.setValueDataAPIFailureFlag(false);
		}
		this.setState({ openFilterPopup: !this.state.openFilterPopup, noRecordForFilter: false });
	}

	getLabelValue(id) {
		return <FormattedMessageComponent id={id} />;
	}

	setFilterValuesFromState(values) {
		const filterValues = [];
		const { columnDefs } = this.state;
		if ((columnDefs && columnDefs.length) || (this.columnDefData && this.columnDefData.length)) {
			const colData = columnDefs && columnDefs.length ? columnDefs : this.columnDefData;
			values.forEach(value => {
				const isExists = colData.find(
					column => column[COLUMN_VALUE_ACCESSOR].trim() == value.accessor,
				);
				if (isExists) {
					filterValues.push(value);
				}
			});
			if (filterValues && filterValues.length) {
				this.props.onSetFilterProps(filterValues);
				this.props.setGlobalFilterProps(filterValues);
				return filterValues;
			}
		} else {
			this.props.onSetFilterProps(values);
			this.props.setGlobalFilterProps(values);
			return values;
		}
	}

	getApiObj(recordData, record, currentPage, pageProps) {
		let recordObj = false;
		if (record) {
			recordObj = record;
		}
		const apiObj = {
			recordData,
			pageProps,
			direction: pageProps.isForwardDirection,
			record: recordObj,
			currentPage,
			parentPage: BOOKINGS_LIST_PAGE,
		};
		return apiObj;
	}
	getApiFilterObj(filterProps, currentPage, pageProps) {

		let apiObj = {
			filterProps,
			pageProps: pageProps,
			direction: pageProps.isForwardDirection,
			currentPage: currentPage,
			parentPage: ORDER_LIST
		};
		return apiObj;
	}
	prepareHeaderDataJSON(obj) {
		const headerValues = this.state.headerValues;
		const { vendor, item, warehouse } = this.props.bookingsProperties;
		const prefix = getListPredecessor(BOOKINGS_LIST_PAGE);
		const key = `VNAME`;
		if (vendor && Object.keys(vendor) && Object.keys(vendor).length) {
			const vendorName = vendor[key];
			headerValues.VNAME = vendorName ? vendorName.trim() : vendorName;

		}

		const keyVendorId = `${prefix}VNDR`;
		const vendorId = obj[keyVendorId];
		headerValues.BKVNDR = vendorId ? vendorId.trim() : vendorId;

		if (warehouse && Object.keys(warehouse) && Object.keys(warehouse).length) {
			const warehouseName = warehouse["WNAME"];
			headerValues.WNAME = warehouseName ? warehouseName.trim() : warehouseName;
		}

		const keyWarehouseId = `${prefix}WHSE`;
		const warehouseId = obj[keyWarehouseId];
		headerValues.BKWHSE = warehouseId ? warehouseId.trim() : warehouseId;

		if (item && Object.keys(item) && Object.keys(item).length) {
			const itemName = item["INAME"];
			const subVendorName = item["ISUBV"];
			headerValues.INAME = itemName ? itemName.trim() : itemName;
			headerValues.BKSUBV = subVendorName ? subVendorName.trim() : subVendorName;
		}
		const keyItemId = `${prefix}ITEM`;

		const itemId = obj[keyItemId];
		headerValues.BKITEM = itemId ? itemId.trim() : itemId;
		this.setState({ headerValues: headerValues })
		return [headerValues];
	}

	forceUpdateHandler() {
		this.forceUpdate();
	}


	setStateWSVIds = (filterProps) => {
		let obj = JSON.parse(JSON.stringify(this.state.bracketsNotesFilterObj));
		for (let i = 0; i < filterProps.length; i++) {
			if (filterProps[i].accessor == 'WHSE') {
				obj["warehouseId"] = filterProps[i].fieldValue;
			} else if (filterProps[i].accessor == 'ITEM') {
				obj["itemId"] = filterProps[i].fieldValue;
			} else if (filterProps[i].accessor == 'SDAT') {
				obj["shipDt"] = filterProps[i].fieldValue;
			} else if (filterProps[i].accessor == 'CSID') {
				obj["custId"] = filterProps[i].fieldValue;
			}
		}
		this.setState({ bracketsNotesFilterObj: JSON.parse(JSON.stringify(obj)) });

	}

	makePrevNextAPICall = flag => {
		const { filterProps, valueData, sortProps } = this.props.bookingsProperties;
		const data = JSON.parse(JSON.stringify(INITIAL_PAGE_PROPS));
		data.isForwardDirection = flag;
		data.pageSize = 3;
		this.props.getPageUpDownFlagAPI(
			this.getApiObjForPageUpDownFlags(filterProps, valueData, BOOKINGS_LIST_PAGE, data, sortProps, flag)
		);
	};

	prepareTooltipData = () => {
		const { detailCallData, bookingColumnDefs } = this.props.bookingsProperties;
		let tooltipData = prepareTooltipValues(BOOKINGS_LIST_PAGE, detailCallData, bookingColumnDefs, 'bookingsproperties');
		this.props.setDataInTabs("toolTipData", JSON.parse(JSON.stringify(tooltipData)));
	}

	setHeaderAndSendAPI(jsonData, from) {
		let data = this.prepareHeaderDataJSON(jsonData);
		this.setState({ headerData: data });
		this.setState({ stateData: jsonData });
		let valueData = prepareValueDataForBookings(DEFAULT_VALUE_URL_DATA, jsonData, from);
		this.sendAPICallForValues(valueData, jsonData);
	}
	sendAPICallForValues(valueData, jsonData) {
		const { pageProps } = this.props.bookingsProperties;
		this.props.getValueList(this.getApiObj(valueData, null, BOOKINGS_PROPERTIES_PAGE, pageProps));
		this.checkForExistenceOfVendorItemWarehouse(jsonData)
	}

	handleValueDataErrorMessages(content) {
		this.setState({ showValueConfirmationDialog: true });
		this.setState({ dialogTitle: TEXT_ALERT });
		this.setState({ dialogContent: content });
	}

	closeValueDialog = () => {
		this.setState({ showValueConfirmationDialog: false });
		if (this.state.valueDataFailureMessages && this.state.valueDataFailureMessages.length) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.shift();
			this.setState({ valueDataFailureMessages: values });
		}
	}

	setRecordDataValues() {
		let isRecordValuesExists = false, isLocalStorageValuesExists = false, isFilterValuesExists = false;
		const { history } = this.props;
		var paramsString = window.location.search;
		if (paramsString && paramsString.length) {
			let paramsArray = paramsString.split("?");
			if (paramsArray && paramsArray.length && paramsArray.length > 1) {
				let params = paramsArray[1].split("&");
				let tabId = params[0].split("=")[1];
				let breadCrumbId = params[1].split("=")[1];
				let localStorageValues = getFilterDataFromLocalStorage(tabId, breadCrumbId);
				if (localStorageValues && Object.keys(localStorageValues) && Object.keys(localStorageValues).length) {
					isLocalStorageValuesExists = true;
					let itemData = localStorageValues.item_data, dbSelectorValues = [];
					if (itemData && itemData.recordData && localStorageValues.childType) {
						this.columnDefData = JSON.parse(JSON.stringify(itemData.recordData.columnDefs))
						this.setState({ columnDefs: itemData.recordData.columnDefs });
						this.props.setCurrentRecord(itemData.recordData.data);
						this.setState({ totalCount: itemData.recordData.totalCount });
						this.setState({ fromPage: itemData.recordData.fromPage });
						this.setState({ fromListPage: itemData.recordData.fromPage });
						this.props.setRowIndex(itemData.recordData.rowIndex);
						this.setHeaderAndSendAPI(itemData.recordData.data, itemData.recordData.fromPage);
						isRecordValuesExists = true;
						this.props.setSelectedRecord(false, false);
						if (itemData) {
							if (itemData.dbSelector && itemData.dbSelector.length) {
								dbSelectorValues = JSON.parse(JSON.stringify(itemData.dbSelector));
							}
							if (itemData.filterProps && itemData.filterProps.length) {
								this.setState({ hasFiltersChanged: false });
								isFilterValuesExists = true;
								let values = getDBSelectorFilterValues(dbSelectorValues, itemData.filterProps);
								this.setFilterValuesFromState(values);
							} else if (dbSelectorValues && dbSelectorValues.length) {
								this.setState({ hasFiltersChanged: false });
								isFilterValuesExists = true;
								let dbValues = getDBSelectorFilterValues(dbSelectorValues, []);
								this.setFilterValuesFromState(dbValues);
							}
							if (itemData.sortProps && itemData.sortProps.length) {
								this.setState({ hasSortChanged: false });
								this.props.sendPageSortProps(itemData.sortProps);
								this.props.onSetSortProps(itemData.sortProps);
							} else {
								//do nothing
							}
							if (itemData.defaultFilterInfo && Object.keys(itemData.defaultFilterInfo) && Object.keys(itemData.defaultFilterInfo).length) {
								this.props.setDefaultFilterpropsForTabs(itemData.defaultFilterInfo);
							}
							if (itemData.defaultSortInfo && Object.keys(itemData.defaultSortInfo) && Object.keys(itemData.defaultSortInfo).length) {
								this.props.setDefaultSortpropsForTabs(itemData.defaultSortInfo);
							}
						}
					}

				}
				if (!isLocalStorageValuesExists && tabId && breadCrumbId) {
					history.push({ pathname: '/Dashboard' });
				}
			}
		}

		let filterOptions = GLOBAL_FILTER_OPTIONS;
		const { dbSelector } = this.props;
		if (!isFilterValuesExists) {
			let gbValues = getDBSelectorFilterValues(dbSelector, filterOptions);
			this.setFilterValuesFromState(gbValues);
		}
		return isRecordValuesExists;
	}

	resetValues = () => {
		this.props.setInitialState();
		this.props.setValueDataFlag(false);
		this.props.setCurrentRecord(null);
		this.props.getBookingsColumnDefs({ type: BOOKINGS_LIST_PAGE });
	};

	componentDidMount() {
		this.resetValues();
		let currentPage = BOOKINGS_PROPERTIES_PAGE;
		this.props.onLoadCurrentPage(currentPage);
		const { detailCallData } = this.props.bookingsProperties;
		this.props.setIsShowContextMenu(true);
		let isFound = this.setRecordDataValues();

		if (!isFound) {
			if (this.props.location && this.props.location.state) {
				this.props.setCurrentRecord(this.props.location.state.data);
				this.setState({ columnDefs: this.props.location.state.columnDefs });
				this.setState({ fromPage: this.props.location.state.fromPage });
				this.props.setRowIndex(this.props.location.state.rowIndex);
				this.setHeaderAndSendAPI(this.props.location.state.data, BOOKINGS_LIST_PAGE);
			}
		}

		if (detailCallData && Object.keys(detailCallData) && Object.keys(detailCallData).length) {
			this.setState({ headerData: this.prepareHeaderDataJSON(detailCallData) });
			this.props.setSelectedRecord(detailCallData, BOOKINGS_LIST_PAGE);
		}
		let labelFilters = LABEL_LIST_URL_DATA;
		this.props.getLabelsList({ recordData: labelFilters, currentPage: 'vendorproperties' });
		this.setState({ isSaveDataDisabled: true });
		this.props.getBracketJson({ recordData: BRACKET_LABEL_URL_DATA, currentPage: 'vendorproperties' });
		let canUpdateComponent = getUpdateRestrictionOnComponent(capitalizeFirstLetter(BOOKINGS_LIST_PAGE), this.props.authorizedComponentsList);
		this.setState({ canUpdateComponent, canUpdateComponentSecurity: { ...canUpdateComponent } });
	}
	componentDidUpdate(prevProps, prevState) {
		const { pageUpDownData,
			isSaveSuccess,
			filterProps,
			isValueDataAPICall,
			isValueDataAPIFailure,
			bookingColumnDefs,
			sortProps,
			defaultSortProps,
			sortCriteriaDetails,
			filterCriteriaDetails,
			detailCallData,
			labelsDataFailure,
			isAPIforVendorList,
			isAPIforItemList,
			isAPIforWarehouseList,
			isAPIforBookingUpdate,
			previousNextFlagAPIFailure,
			isAPIforBookingCopy,
			isAPIforBookingDelete,
			isAPIforBookingColums,
			isCopySuccess,
			isDeleteSuccess,
			isAPIforBookingDeleteAll,
			itemNotFoundFlag,
			vendorNotFoundFlag,
			warehouseNotFoundFlag,
			hasNoPrevNext,
			prevNextApiSuccess
		} = this.props.bookingsProperties

		if (this.state.valueDataFailureMessages && this.state.valueDataFailureMessages.length
			&& (JSON.stringify(this.state.valueDataFailureMessages) != JSON.stringify(prevState.valueDataFailureMessages))) {
			this.handleValueDataErrorMessages(this.state.valueDataFailureMessages[0]);
		}

		if (labelsDataFailure && (labelsDataFailure != prevProps.bookingsProperties.labelsDataFailure)) {
			this.setState({ isDataLoaded: true })
			this.handleNoDataSets();
			this.props.setLabelDataFlags({ key: 'labelsDataFailure', value: false });
		}

		if (isAPIforVendorList && (isAPIforVendorList != prevProps.bookingsProperties.isAPIforVendorList)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to fetch Vendor List");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isAPIforVendorList', value: false });
		}

		if (isAPIforItemList && (isAPIforItemList != prevProps.bookingsProperties.isAPIforItemList)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to fetch Item list");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isAPIforItemList', value: false });
		}

		if (isAPIforWarehouseList && (isAPIforWarehouseList != prevProps.bookingsProperties.isAPIforWarehouseList)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to fetch Warehouse List");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isAPIforWarehouseList', value: false });
		}

		if (isAPIforBookingUpdate && (isAPIforBookingUpdate != prevProps.bookingsProperties.isAPIforBookingUpdate)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to Update Booking");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isAPIforBookingUpdate', value: false });
		}

		if (previousNextFlagAPIFailure && (previousNextFlagAPIFailure != prevProps.bookingsProperties.previousNextFlagAPIFailure)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to fetch Previous Next Flag");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'previousNextFlagAPIFailure', value: false });
		}
		if (isAPIforBookingDelete && (isAPIforBookingDelete != prevProps.bookingsProperties.isAPIforBookingDelete)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("E11603");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isAPIforBookingDelete', value: false });
		}

		if (isAPIforBookingColums && (isAPIforBookingColums != prevProps.bookingsProperties.isAPIforBookingColums)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to fetch Booking Columns");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isAPIforBookingColums', value: false });
		}
		if (isCopySuccess && (isCopySuccess != prevProps.bookingsProperties.isCopySuccess)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("E11738");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isCopySuccess', value: false });
		}
		if (isDeleteSuccess && (isDeleteSuccess != prevProps.bookingsProperties.isDeleteSuccess)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("E11739");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isDeleteSuccess', value: false });
		}
		if (isAPIforBookingDeleteAll && (isAPIforBookingDeleteAll != prevProps.bookingsProperties.isAPIforBookingDeleteAll)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to Delete All Bookings");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isAPIforBookingDeleteAll', value: false });
		}
		if (itemNotFoundFlag && (itemNotFoundFlag != prevProps.bookingsProperties.itemNotFoundFlag)) {
			this.setGridError('11606', [prevState.headerData["BKITEM"]])
			this.props.setLabelDataFlags({ key: 'itemNotFoundFlag', value: true });
		}
		if (vendorNotFoundFlag && (!vendorNotFoundFlag != prevProps.bookingsProperties.vendorNotFoundFlag)) {
			this.setGridError('11605', [prevState.headerData["BKVNDR"]])
			this.props.setLabelDataFlags({ key: 'vendorNotFoundFlag', value: true });
		}
		if (warehouseNotFoundFlag && (!warehouseNotFoundFlag != prevProps.bookingsProperties.warehouseNotFoundFlag)) {
			this.setGridError('11608', [prevState.headerData["BKWHSE"]])
			this.props.setLabelDataFlags({ key: 'warehouseNotFoundFlag', value: true });
		}
		if (sortProps && sortProps.length && !isEqual(sortProps, prevProps.bookingsProperties.sortProps)) {
			this.props.setDataInTabs("sortProps", JSON.parse(JSON.stringify(sortProps)));
			if (!this.state.isInitialAPICall) {
				if (this.state.fromPage != BOOKINGS_LIST_PAGE) {
					this.setHeaderAndSendAPI(this.state.stateData, this.state.fromPage)
				} else {
					this.makeAPICallForPageUpDown('down', {});
				}
			}
		}

		if ((JSON.stringify(filterProps) != JSON.stringify(prevProps.bookingsProperties.filterProps)) && filterProps && filterProps.length) {
			this.setState({ isFiltersChanged: true });
			this.props.setChildTabFilterProps(filterProps);
			this.setStateWSVIds(filterProps);
			if (!this.state.isInitialAPICall) {
				if (this.state.fromPage != BOOKINGS_LIST_PAGE && !this.state.hasFiltersChanged) {
					this.setHeaderAndSendAPI(this.state.stateData, this.state.fromPage)
				} else {
					this.makeAPICallForPageUpDown('down', {});
				}
			}
		}
		if ((defaultSortProps != prevProps.bookingsProperties.defaultSortProps) && (prevProps.bookingsProperties.defaultSortProps === null) && (sortProps == null || !sortProps || !(sortProps && sortProps.length))) {
			let list = setSortDataFromSortCriteria(defaultSortProps, bookingColumnDefs, BOOKINGS_LIST_PAGE);
			this.props.setDataInTabs("defaultSortInfo", JSON.parse(JSON.stringify(defaultSortProps)));
			if (list && list.length) {
				this.props.sendPageSortProps(list);
				this.props.onSetSortProps(list);
			} else {
				this.props.sendPageSortProps([]);
				this.props.onSetSortProps([]);
			}
		}

		if (JSON.stringify(sortCriteriaDetails) != JSON.stringify(prevProps.bookingsProperties.sortCriteriaDetails)) {
			this.props.setDataInTabs("defaultSortInfo", JSON.parse(JSON.stringify(sortCriteriaDetails)));
			let list = setSortDataFromSortCriteria(sortCriteriaDetails, bookingColumnDefs, BOOKINGS_LIST_PAGE);
			if (list && list.length) {
				this.props.sendPageSortProps(list);
				this.props.onSetSortProps(list);
			}
		}

		if ((filterCriteriaDetails != prevProps.bookingsProperties.filterCriteriaDetails)) {
			this.props.setDataInTabs("defaultFilterInfo", JSON.parse(JSON.stringify(filterCriteriaDetails)));
			if (filterCriteriaDetails && Object.keys(filterCriteriaDetails) && Object.keys(filterCriteriaDetails).length && bookingColumnDefs && bookingColumnDefs.length) {
				let list = getFilterDataFromCriteriaDetails(filterCriteriaDetails, bookingColumnDefs, BOOKINGS_LIST_PAGE);
				if (list && list.length) {
					this.props.setGlobalFilterProps(list);
					this.props.onSetFilterProps(list);
				}
			}
		}

		if (detailCallData && !isEqual(detailCallData, prevProps.bookingsProperties.detailCallData)) {
			if (Object.keys(detailCallData) && Object.keys(detailCallData).length) {
				if (bookingColumnDefs && bookingColumnDefs.length) {
					this.prepareTooltipData();
				}
				this.props.setSelectedRecord(detailCallData, BOOKINGS_LIST_PAGE);
				this.setState({ headerData: this.prepareHeaderDataJSON(detailCallData) });
				let disabled = detailCallData["BKTYPE"] == 40 ? true : false;
				let contextMenuList = [...this.state.contextMenuList]
				contextMenuList[1]["isDisable"] = disabled;
				this.setState({ contextMenuList })
			}
		}

		if (bookingColumnDefs && bookingColumnDefs.length && !isEqual(bookingColumnDefs, prevProps.bookingsProperties.bookingColumnDefs) &&
			(detailCallData && Object.keys(detailCallData) && Object.keys(detailCallData).length)) {
			if (!this.state.changeDataAPI) {
				this.prepareTooltipData();
			}
		}
		if (isValueDataAPICall != prevProps.bookingsProperties.isValueDataAPICall && isValueDataAPICall) {
			this.setState({ previousFilterValues: prevProps.bookingsProperties.filterProps })
			this.setState({ isInitialAPICall: false });
			this.makePrevNextAPICall(true);
			this.setState({ bracketsNotesFilterObj: {} });
			this.props.setValueDataFlag(false);
			if (this.state.isFiltersChanged) {
				this.setState({ openFilterPopup: false });
				this.setStateWSVIds(filterProps);
				this.setState({ isFiltersChanged: false });
			}
		}

		if (isValueDataAPIFailure != prevProps.bookingsProperties.isValueDataAPIFailure && isValueDataAPIFailure) {
			this.setState({ isInitialAPICall: false });
			if (this.state.isFiltersChanged) {
				this.setState({ showConfirmationDialog: true });
				this.setState({ hasWarning: true });
				this.setState({ dialogTitle: TEXT_ALERT });
				this.setState({ fromHeaderENG: true });
			} else {
				this.setState({ showConfirmationDialog: true });
				this.setState({ hasWarning: true });
				this.setState({ dialogTitle: TEXT_ALERT });
				this.setState({ fromHeaderENG: true });
			}
		}

		if (this.props.location.search != prevProps.location.search) {
			this.resetValues();
			this.forceUpdateHandler();
			this.setRecordDataValues();
			this.setState({ state: this.state });
		}
		if (pageUpDownData && JSON.stringify(pageUpDownData) != JSON.stringify(prevProps.bookingsProperties.pageUpDownData)) {
			this.props.setSelectedRecord(pageUpDownData, BOOKINGS_LIST_PAGE);
			this.setState({ fromPage: BOOKINGS_LIST_PAGE });
			this.setHeaderAndSendAPI(pageUpDownData, BOOKINGS_LIST_PAGE);
			let modifiedData = {
				data: JSON.parse(JSON.stringify(pageUpDownData)),
				fromPage: BOOKINGS_LIST_PAGE,
				rowIndex: this.props.bookingsProperties.rowIndex,
				totalCount: this.state.totalCount,
				fromParent: false,
				columnDefs: this.state.columnDefs,
			};
			this.props.setDataInTabs('recordData', modifiedData);
		}
		if (isSaveSuccess && isSaveSuccess !== prevProps.bookingsProperties.isSaveSuccess) {
			this.setState({ isSaveDataDisabled: true });
		}
		if (hasNoPrevNext && (prevProps.bookingsProperties.hasNoPrevNext !== hasNoPrevNext)) {
			if (this.state.isFiltersChanged) {
			  this.openNoDataPopUp(true)
			}
		  }
		  if (prevNextApiSuccess && (prevProps.bookingsProperties.prevNextApiSuccess !== prevNextApiSuccess)) {
			this.setState({ openFilterPopup: false });
			this.setStateWSVIds(filterProps);
			this.setState({ isFiltersChanged: false });
		  }
	}
	openNoDataPopUp = (val) => {
		this.setState({ showConfirmationDialog: val });
		this.setState({ hasWarning: val });
		this.setState({ dialogTitle: val ? TEXT_ALERT : '' });
		this.setState({ fromHeaderENG: val });
		this.setState({ dialogBody: val ? 'E28648' : '' });
		this.setState({ noRecordForFilter: true })
	  }

	handleBookingHeaderSaveClick() {
		const { newValueData, valueData, addAndDeleteFlag } = this.props.bookingsProperties;
		const detailValues = this.props.bookingsProperties.newValueData;
		const booking = this.props.bookingsProperties.valueData;
		let filterProps = [{ "accessor": "COMP", 'prefixFlag': 0, "operator": "=", "jOpr": "and", "fieldValue": "E3T" },
		{ "accessor": "VNDR", 'prefixFlag': 0, "operator": "=", "jOpr": "and", "fieldValue": detailValues["BKVNDR"] },
		{ "accessor": "ITEM", 'prefixFlag': 0, "operator": "=", "jOpr": "and", "fieldValue": detailValues["BKITEM"] },
		{ "accessor": "SDAT", 'prefixFlag': 0, "operator": "=", "jOpr": "and", "fieldValue": detailValues["BKSDAT"] },
		{ "accessor": "CSID", 'prefixFlag': 0, "operator": "=", "jOpr": "and", "fieldValue": detailValues["BKCSID"] },
		{ "accessor": "WHSE", 'prefixFlag': 0, "operator": "=", "jOpr": "and", "fieldValue": detailValues["BKWHSE"] }
		];

		if (this.onValid(detailValues, booking)) {
			if (JSON.stringify(newValueData) != JSON.stringify(valueData)) {
				const pageProps = { pageSize: 3 }
				this.props.bookingDetailsUpdate({
					addAndDeleteFlag: addAndDeleteFlag, filterProps: filterProps, updateRecord: detailValues,
					currentRecord: booking, currentPage: BOOKINGS_PROPERTIES_PAGE, pageProps, direction: true
				});
			}
		}
	}

	getApiObjForPageUpDown(filterData, record, currentPage, pageProps, sortData, pageType) {
		let recordObj = false
		if (record) {
			recordObj = record;
		}
		let apiObj = {
			sortProps: sortData,
			filterProps: filterData,
			pageProps: pageProps,
			direction: pageProps.isForwardDirection,
			record: recordObj,
			currentPage: currentPage,
			parentPage: BOOKINGS_LIST_PAGE,
			pageType: pageType
		};
		return apiObj;
	}

	getApiObjForPageUpDownFlags = (filterData, record, currentPage, pageProps, sortData, pageType) => {
		let recordObj = false
		if (record) {
			recordObj = {
				"record": record,
				"flagsOnly": true
			};
		}
		let apiObj = {
			sortProps: sortData,
			filterProps: filterData,
			pageProps: pageProps,
			direction: pageProps.isForwardDirection,
			record: recordObj,
			currentPage: currentPage,
			parentPage: BOOKINGS_LIST_PAGE,
			pageType: pageType
		};
		return apiObj;
	}

	makeAPICallForPageUpDown(type, currentRecordData) {
		const { filterProps, sortProps } = this.props.bookingsProperties;
		let data = JSON.parse(JSON.stringify(INITIAL_PAGE_PROPS));
		if (type == 'up') {
			data.isForwardDirection = false;
		} else {
			data.isForwardDirection = true;
		}
		let filterData = JSON.parse(JSON.stringify(filterProps));
		this.props.pageUpDownAPI(this.getApiObjForPageUpDown(filterData, currentRecordData, BOOKINGS_LIST_PAGE, data, sortProps))
	}
	handleBookingHeaderLeftArrowClick() {
		const { currentRecordData } = this.props.bookingsProperties;
		this.props.setCurrentType('down');
		this.makeAPICallForPageUpDown('down', currentRecordData);
		this.setState({ isSaveDataDisabled: true });
	}

	handleBookingHeaderRightArrowClick() {
		const { currentRecordData } = this.props.bookingsProperties;
		this.props.setCurrentType('up');
		this.makeAPICallForPageUpDown('up', currentRecordData);
		this.setState({ isSaveDataDisabled: true });
	}
	onValid = (newValueData, valueData) => {
		const { companyDetails } = this.props;
		if (newValueData["BKSDAT"] != valueData["BKSDAT"]) {
			if (newValueData["BKSDAT"] == '') {
				this.setGridError('11614');
				return false;
			}
			if (companyDetails && newValueData["BKSDAT"] < companyDetails.CJDATE) {
				this.setGridError('11615');
				return false;
			}
		}
		return true;
	}

	setGridError = (errorId, parameterValues = []) => {
		this.setState({ hasError: true, errorId, parameterValues }, () => {
			setTimeout(() => {
				this.setState({ hasError: false, errorId: false })
			}, 3e3);
		})
	}

	handleBookingHeaderActionItemSelection = action => {
		switch (action) {
			case LABEL_COPY:
				this.handleCopyDeletePopup('openCopyPopup', true)
				break;
			case LABEL_DELETE:
				this.handleCopyDeletePopup('openDeletePopup', true)
				break;
			//~~~CreateNewFramework--JVK
			case 'newnote':
				this.setState({ isOpenNote: true }); break;
			//~~~CreateNewFramework--JVK
		}
	}
	handleCopyDeletePopup = (popup, val) => {
		if (popup == 'openCopyPopup') {
			this.setState({ openCopyPopup: val })
		} else if (popup == 'openDeletePopup') {
			this.setState({ openDeletePopup: val })
		}
	}
	handleChangeValue(key, val, field) {
		this.props.setValueData({ key, val, field });
		this.setState({ isSaveDataDisabled: false })
	}

	onContextMenuChange = (e, value, check = false, filters = false, title = false) => {
		let defaultFilters = filters;
		let toPage = value;
		let displayName = title;
		onChangeContextMenu(this.props, e, toPage, defaultFilters, displayName);
		this.props.setSelectedValueForTabs('Show Me');
	}

	handleClose = bodyId => {
		this.setState({ showConfirmationDialog: false });
		switch (bodyId) {
			case 'E14029':
				//need to close the current Tab
				break;
		}
	}

	closeCurrentTab = () => {
		this.props.setNoDataCallBackValue(true);
		var paramsString = window.location.search;
		if (paramsString && paramsString.length) {
			let paramsArray = paramsString.split("?");
			if (paramsArray && paramsArray.length && paramsArray.length > 1) {
				let params = paramsArray[1].split("&");
				let tabId = params[0].split("=")[1];
				let breadCrumbId = params[1].split("=")[1];
				this.props.removeCurrentRecordObj(tabId, breadCrumbId);
			}
		}
	}

	checkForExistenceOfVendorItemWarehouse(data) {
		let filters = [{ "accessor": "COMP", "operator": "=", "jOpr": "and", "fieldValue": "E3T" },
					   { "accessor": "WHSE", "operator": "=", "jOpr": "and", "fieldValue": data["BKWHSE"] },
					   { "accessor": "VNDR", "operator": "=", "jOpr": "and", "fieldValue": data["BKVNDR"] }];
		this.props.getVendorList(filters);

		filters = [{ "accessor": "COMP", "operator": "=", "jOpr": "and", "fieldValue": "E3T" },
				   { "accessor": "WHSE", "operator": "=", "jOpr": "and", "fieldValue": data["BKWHSE"] },
				   { "accessor": "VNDR", "operator": "=", "jOpr": "and", "fieldValue": data["BKVNDR"] },
				   { "accessor": "ITEM", "operator": "=", "jOpr": "and", "fieldValue": data["BKITEM"] }];
		this.props.getItemsList(filters);

		filters = [{ "accessor": "COMP", "operator": "=", "jOpr": "and", "fieldValue": "E3T" }, { "accessor": "WHSE", "operator": "=", "jOpr": "and", "fieldValue": data["BKWHSE"] }];
		this.props.getWarehouseList(filters);

	}
	handleDisableUpArrow = () => {
		const { hasPrevious } = this.props.bookingsProperties;
		const { fromListPage } = this.state;
		return !hasPrevious || fromListPage != BOOKINGS_LIST_PAGE;
	};

	handleDisableDownArrow = () => {
		const { hasNext } = this.props.bookingsProperties;
		const { fromListPage } = this.state;
		return !hasNext || fromListPage != BOOKINGS_LIST_PAGE;
	};

	setIsOpenActionsContextMenu = event => {
		this.setState({ isOpenActionsContextMenu: Boolean(event) });
		this.setState({ menuRef: event.currentTarget ? event.currentTarget : event });
		if (event) {
			let contextMenuList = this.state.contextMenuList.map(action => {
			  return { ...action, isDisable: this.isActionDisabled(action.key) }
			})
			this.setState({ contextMenuList })
		  }
	}
	isActionDisabled = (action) => {
		const { detailCallData } = this.props.bookingsProperties;
		  switch (action) {
			case '25212':
				let disableCopy =detailCallData["BKTYPE"] == 40 ? true:false
			  return false || disableCopy || !this.state.canUpdateComponent.update;
			case '25211':
			  return false || !this.state.canUpdateComponent.update;
		}		  
	}
	getValueData(valueData, newValueData) {
		if (Object.keys(valueData).length && Object.keys(newValueData).length &&
			(JSON.parse(JSON.stringify(valueData)) !== JSON.parse(JSON.stringify(newValueData)))) {
			return newValueData;
		}
		return valueData;
	}
	
	//booking_notes get Notes count
	setNotesCount(count) {
		if (this.state.notesCount != count)
			this.setState({ notesCount: count })
	}

	updatedNotesData = () => {
		this.setState({ updatedNotes: true });
	}

	render() {
		const {
			classes, globalDateFormat, filterCriteriaDetails, pageFilterOptions, globalFilterOptions,
			columnDefs, currentPage, currentOwnerName, isShowContextMenu, removeChildCutdownTab, selectedValue, globalSecurityFilterList } = this.props;
		const {
			loading, bookingDetailsLabelsData, copyBookingDetailsLabelsData, bracketLabelJson,
			valueData, newValueData, vendor, item, warehouse, currentRecordData,bookingColumnDefs } = this.props.bookingsProperties;

		const { tabcards } = bookingDetailsLabelsData;
		const { canUpdateComponent, isSaveDataDisabled, headerData } = this.state;
		let contextMenu = updateBreadCrumbContextMenu(this.props) || [];
		return (
			<React.Fragment>
				{this.state.hasError ? (
					<div>
						<GridErrorMessages
							errorMessageLabels={this.props.errorMessageLabels}
							popUp
							sethaserror={this.sethaserror}
							replaceValues={this.state.parameterValues}
							id={this.state.errorId ? this.state.errorId : this.props.ServerError} />
					</div>) : ('')}
				<div className={classes.propertiesHeaderContainer}>
					{headerData && headerData.length && currentPage &&
						<div className={classes.boookingDetailContainer}>
							<Box className={classes.boookingDetailDetailsWrapper}>
								<Box className={classes.bookingArrowWrapper}>
									<Button color="primary" onClick={() => this.handleBookingHeaderRightArrowClick()} className={classes.boookingArrow} disabled={this.handleDisableUpArrow()}>
										<KeyboardArrowUpIcon />
									</Button>
									<Button color="primary" onClick={() => this.handleBookingHeaderLeftArrowClick()} className={classes.boookingArrow} disabled={this.handleDisableDownArrow()}>
										<KeyboardArrowDownIcon />
									</Button>
								</Box>
								<Box className={classes.vendorDetailRow}>
									<div className={classes.vendorIDSubID}>
										<div className={classes.vendorDetail}>
											<div className={classes.vendorIDBlock}>
												<div className={`${classes.vendorDetail} ${classes.vendorIdDetails}`}>
													<div className={classes.vendorLabel}>
														{this.getLabelValue(LABEL_VENDOR_ID)}
													</div>
													<div>{headerData[0].BKVNDR}</div>
												</div>
												<div className={`${classes.vendorDetail} ${classes.vendorSubVendorDetails}`}>
													<div className={classes.vendorLabel}>
														{this.getLabelValue(LABEL_SUB_VENDOR_ID)}
													</div>
													<div>{(item && item["ISUBV"])}</div>
												</div>
											</div>
										</div>
										<div className={`${classes.vendorName} ${classes.nameField}`}>
											<div className={`${classes.vendorLabel}`}>
												{this.getLabelValue(LABEL_VENDOR_NAME)}
											</div>
											<div>{(vendor && vendor["VNAME"])}</div>
										</div>
									</div>
									<div className={classes.IdNameBlock}>
										<div className={classes.vendorDetail}>
											<div className={classes.vendorLabel}> {this.getLabelValue(LABEL_ITEM_ID)} </div>
											<div className={classes.vendorValue}>{headerData[0].BKITEM}</div>
										</div>
										<div className={`${classes.vendorDetail} ${classes.nameField}`}>
											<div className={classes.vendorLabel}>{this.getLabelValue(LABEL_ITEM_NAME)}</div>
											<div className={classes.vendorValue}>{(item && item["INAME"])}</div>
										</div>
									</div>
									<div className={classes.IdNameBlock}>
										<div className={classes.vendorDetail}>
											<div className={classes.vendorLabel}> {this.getLabelValue(LABEL_WAREHOUSE_ID)} </div>
											<div className={classes.vendorValue}>{headerData[0].BKWHSE}</div>
										</div>
										<div className={`${classes.vendorDetail} ${classes.nameField}`}>
											<div className={classes.vendorLabel}>{this.getLabelValue(LABEL_WAREHOUSE_NAME)}</div>
											<div className={classes.vendorValue}>{(warehouse && warehouse["WNAME"])}</div>
										</div>
									</div>
								</Box>
								<Box className={classes.bookingActions}>
									<div className={classes.buttonActions}>
										<div className={isShowContextMenu || true ? 'showContextMenu' : 'hideContextMenu'}>
											<BreadcrumbContextMenu
												onOptionChange={(e, val) => this.onContextMenuChange(e, val)} menuItems={contextMenu}
												removeChildCutdownTab={removeChildCutdownTab}
												selectedValue={selectedValue} />
										</div>
									</div>
									<Button component="div" color="primary" onClick={this.handleBookingHeaderFilterClick} className={classes.bookingActionsFilter}>
										<img src={FilterIcon} alt="Filter Icon" />
									</Button>
									<Button component="div" color="primary" onClick={this.handleBookingHeaderSaveClick} disabled={isSaveDataDisabled} className={classes.bookingActionsFilter}>
										<SaveIcon fontSize="large" />
									</Button>
									<Box className={classes.menuButton}>
										<div
											onMouseEnter={(event) => this.setIsOpenActionsContextMenu(event)}
											onMouseLeave={() => this.setIsOpenActionsContextMenu(false)}>
											<MoreVertIcon color="primary" className="cPointer"></MoreVertIcon>
											<ContextMenuCreateNew
												className={classes.ActionsContextMenu}
												menuList={this.state.contextMenuList}
												isOpen={this.state.isOpenActionsContextMenu}
												menuRef={this.state.menuRef}
												handleItemSelection={(val) => this.handleBookingHeaderActionItemSelection(val)}
												handleMenuClose={(val) => this.setIsOpenActionsContextMenu(val)}
												//~~~CreateNewFramework--JVK
												currentPage={currentPage}
												currentRecord={currentRecordData}
												//~~~CreateNewFramework--JVK
											>
											</ContextMenuCreateNew>
										</div>
									</Box>
								</Box>
								<Box className={classes.references}>
									<Button component="div" color="primary" size="small" onClick={e => { document.getElementById("bookingNotes").scrollIntoView(); }}>
										{this.getLabelValue(LABEL_NOTE)}
									</Button>
									<Badge color="error" overlap="circle" anchorOrigin={{ vertical: "top", horizontal: "right" }} max={BADGE_MAX_COUNT} badgeContent={this.state.notesCount}>
									</Badge>
								</Box>
							</Box>
						</div>
					}
				</div>
				<div className={classes.propertiesContentWrapper}>
					<TabContainer>
						<div className={classes.pageContainer}>
							{!loading && valueData && newValueData && tabcards && tabcards.map(formCard => {
								if (formCard.cardkey == BOOKING_CONTROL_FACTORS) {
									formCard.cardfields[1]['disabled'] = newValueData["BKODAT"].trim() && Number(newValueData["BKODAT"].trim()) ? false : true
									return <CardComponent title={formCard.cardtitle} className={classes.card + ' ' + classes.marginLeftZero}>
										<FormFieldsGenerator
											currentOwnerName={currentOwnerName}
											className={classes.adjustCardFieldsInline}
											labelDisplayCharacters={25}
											valueDisplayCharacters={25}
											handleSubmitDataCallBack={() => { }}
											key={formCard.cardkey}
											fieldsArray={JSON.parse(JSON.stringify(formCard.cardfields))}
											valuesArray={this.getValueData(valueData, newValueData)}
											handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
											enableAddButton={() => { }}
											globalDateFormat={globalDateFormat}
											filterCriteriaDetails={filterCriteriaDetails}
											pageFilterOptions={pageFilterOptions}
											globalFilterOptions={globalFilterOptions}
											columnDefs={columnDefs}
											currentPage={currentPage}
											canUpdateComponent={canUpdateComponent}
											noMassMaintenance={true}
										/>
									</CardComponent>
								}
							})}
						</div>
						{loading && <Spinner loading type="list" />}
					</TabContainer>


					<div id="bookingNotes"><BookingNotes currentPage={BOOKINGS_LIST_PAGE}
						noteLabelJson={bracketLabelJson}
						bracketsNotesFilterObj={this.state.bracketsNotesFilterObj}
						fromPage={BOOKINGS_LIST_PAGE}
						currentRecordData={valueData}
						updatedNotesData={this.updatedNotesData}
						canUpdateComponent={this.state.canUpdateComponent}
						columnDefs={this.state.columnDefs}
						setNotesCount={this.setNotesCount}
						isOpenNote={this.state.isOpenNote}
						closeNote={(flag) => this.setState({ isOpenNote: flag })}
					></BookingNotes>
					</div>


					{this.state.openFilterPopup && (
						<Filter
							filterCriteriaDetails={filterCriteriaDetails}
							pageFilterOptions={pageFilterOptions}
							globalFilterOptions={globalFilterOptions}
							globalSecurityFilterList={globalSecurityFilterList}
							currentPage={currentPage}
							isOpen={Boolean(this.state.openFilterPopup)}
							ownerName={currentOwnerName}
							columnDefs={bookingColumnDefs}
							clearPopupComponent={this.handleBookingHeaderFilterClick}
							hasRecordsForFilter={!this.state.noRecordForFilter}
							showNoDataPopUp={(val) => this.openNoDataPopUp(val)}
						/>
					)}
					{this.state.openCopyPopup && copyBookingDetailsLabelsData && (
						<CopyDialog
							openCopyPopup={this.state.openCopyPopup}
							handleCopyDeletePopup={this.handleCopyDeletePopup}
							onSubmit={this.props.bookingDetailsCopy}
							onCopyAll={this.props.bookingDetailsCopyAll}
							copyLabels={copyBookingDetailsLabelsData}
							headerJson={{ ...this.state.headerValues, ...vendor, ...item, ...warehouse }}
							bookingDetailData={this.getValueData(valueData, newValueData)}
							currentOwnerName={currentOwnerName}
							globalDateFormat={globalDateFormat}
							filterCriteriaDetails={filterCriteriaDetails}
							pageFilterOptions={pageFilterOptions}
							globalFilterOptions={globalFilterOptions}
							columnDefs={columnDefs}
							currentPage={currentPage}
							canUpdateComponent={canUpdateComponent}
						/>)}
					{this.state.openDeletePopup && (
						<DeleteDialog
							openDeletePopup={this.state.openDeletePopup}
							handleCopyDeletePopup={this.handleCopyDeletePopup}
							onSubmit={this.props.bookingDetailsDelete}
							onDeleteAll={this.props.bookingDetailsDeleteAll}
							headerJson={{ ...this.state.headerValues, ...vendor, ...item, ...warehouse, ...currentRecordData }}
							currentRecord={currentRecordData}
							bookingDetailData={this.getValueData(valueData, newValueData)}
						/>)}
					{this.state.showConfirmationDialog && <ConfirmationDialog
						hasError={this.state.hasWarning}
						isOpen={this.state.showConfirmationDialog}
						dialogTitle={this.state.dialogTitle}
						submitText={TEXT_OK}
						handleClose={() => this.handleClose(false)}
						handleCancel={() => this.handleClose(false)}
						handleSubmit={() => this.handleClose(this.state.dialogBody)}>
						<div>
							{this.state.fromHeaderENG && this.getLabelValue("28648")}
							{!this.state.fromHeaderENG  && (this.props.errorMessageLabels && this.props.errorMessageLabels[this.state.dialogBody] &&
								this.props.errorMessageLabels[this.state.dialogBody].MTEXT || 'Warning')}
						</div>
					</ConfirmationDialog>
					}
					{this.state.showValueConfirmationDialog && <ConfirmationDialog
						hasError={this.state.hasWarning}
						isOpen={this.state.showValueConfirmationDialog}
						dialogTitle={this.state.dialogTitle}
						submitText={TEXT_OK}
						handleClose={() => this.closeValueDialog(false)}
						handleCancel={() => this.closeValueDialog(false)}
						handleSubmit={() => this.closeValueDialog(this.state.dialogBody)}>
						<div>
							{(this.props.errorMessageLabels[this.state.dialogContent] && this.props.errorMessageLabels[this.state.dialogContent].MTEXT)
								|| this.state.dialogContent}
						</div>
					</ConfirmationDialog>
					}
				</div>
			</React.Fragment>);
	}
}

export default withStyles(style)(BookingProperties);

/*
* * //==========================================================================
*
* * // Copyright 2021-2021, Blue Yonder Group, Inc.
*
* * // All Rights Reserved
*
* * //
*
* * // THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF
*
* * // BLUE YONDER GROUP, INC.
*
* * //
*
* * //
*
* * // The copyright notice above does not evidence any actual
*
* * // or intended publication of such source code.
*
* * //
*
* * // ===========================================================================
/* *******************************PATCH HISTORY******************************** */

/*** ChangeLog
E3C-32838 ; 2022.1.0.0 Unified Product 
    E3C-32900 -Rakesh, July 15, 2021 :  The logic for Min presentation stock added to Item Details
              Now ,we will display Min press, SS and Manual SS fileds. SSDays will always be DCOOD
              and SSQTY is CSSUT. 
              Remmoved the code for * symbol as the old logic is not valid with Min presentation stock
    Story E3C-33054: Rakesh, Aug 4, 2021 : Display override OUTL label based on switch ICHSW1
    Story E3C-33184: Rakesh, Oct 4, 2021: Implementation of Asterisk(*) to indicate the usage of Safety Stock, Manual SS or Minimum Presentation stock in OUTL calculation
*LogStart - 2021.1.0.2 AWR
    E3C-33251 - J Vamshi 19-Oct-2021 : After Deleting an Exception, re-pointing the itemproperties to next exception from the list.
    E3C-33108 - J Vamshi 20-Oct-2021 : When we assign a Demand profile, its displaying in both Demand Profiles and Event profile fields.
***/
/* E3C-33266 - SRK - AWR WEB UI graphs have hardcoded English labels
                     Removed hardcoding and retrieved label based on ID. 
                     (10-Nov-2021)
* * // ===========================================================================
 * LogStart --  E3C-33377 - Kumar A - 16 November,2021 - 2022.1.0.0 Unified Product
 *              Story: E3C-33377 --Item balance details display - Rows are not in the same sequence as Client; Cust Back Order is repeated
*/

import { withStyles } from '@material-ui/core/styles';
import { COLUMN_FIELD_TYPE, COLUMN_VALUE_ACCESSOR, DROPDOWN_FIELD, ITEMS_LIST_PAGE } from 'components/common/constants';
import PropTypes from 'prop-types';
import React from 'react';
import { getListPredecessor, getSortableColumns, setNumberFields, getFormattedNumber, getCompanyInfo, getLabelToDisplay} from '../../../utils/util';
import CardComponent from '../../common/CardComponent';
import FormFieldsGenerator from '../../common/FormFieldsGenerator';
import FormFieldComponent from '../../common/FormFieldsGenerator/formField';
import { CUSTOM_CARDS, ITEM_DETAIL_DEMAND_ORDER_COMPONENTS, STOCKSTATUS_TABLE_KEY_LABEL, CUSTOM_EXIT_NOT_FOUND, MONTHLY_LABEL_ID_START, WEEKLY13_LABEL_ID_START,  //E3C-33377, 11/16/21, Kumar
        WEEKLY52_LABEL_ID_START, FB_UNITS,  LT_QUOTED } from './constants';
import './style.scss';
import 'style.scss';
import { Box, Table, TableHead, TableRow, TableBody, Grid } from '@material-ui/core';
import { CustomTableCell } from '../../OrderProperties/OrderSummary';
import { ENGLISH_INDIA } from '../../common/constants';
import ItemOrderAdjustmentsEmbeddedList from 'containers/ItemEmbeddedListContainers/ItemOrderAdjustmentsEmbeddedList'
import { DEFAULT_VALUE_URL_DATA , ACTUAL_DAYS, WORK_DAYS} from '../constants.js';
import SalesGraph from './SalesGraph';
import DepletionGraph from './DepletionGraph';
import { getDateFormatValue } from 'utils/util.js';
import AccordionComponent from 'components/common/AccordionComponent';
import { isEqual } from 'lodash';

const propTypes = {
  setSaveData: PropTypes.func,
  ItemPropertiesData: PropTypes.object.isRequired,
  getApiObj: PropTypes.func.isRequired,
  getLabelValue: PropTypes.func.isRequired,
  loadItemDetailGraphData: PropTypes.func.isRequired,
};
export function TableComponent(props) {
  const { headLabels, rowMap, values, getLabelValue, classes } = props;
  return <Table className={classes.table}>
    <TableHead>
      <TableRow>
        {headLabels && headLabels.length && headLabels.map(label => <CustomTableCell key={label} className={classes.tableCell}>{getLabelValue(label)}</CustomTableCell>)}
      </TableRow>
    </TableHead>
    <TableBody>
      {values && rowMap && rowMap.map(row => (
        <TableRow key={row.label} className={classes.tableRow} hover>
          <CustomTableCell className={classes.tableCell}>{getLabelValue(row.label)}</CustomTableCell>
          <CustomTableCell className={`${classes.tableCell} ${classes.textAlignLast}`}>
            {values[row.key] && !row.dataType ? getFormattedNumber(+values[row.key], ENGLISH_INDIA, ',', null, '.', true) : 
            row.dataType === 'date' && values[row.key]?.length === 7 ? getDateFormatValue(values[row.key]) :""}
            </CustomTableCell>
        </TableRow>
      ))}
    </TableBody>
  </Table>
}
const style = (theme) => ({
  pageContainer: {
    display: 'flex',
    backgroundColor: 'var(--background-app)',
    borderTop: 'none',
    padding: '16px',
  },
  pageContainerFifty: {
    width: '50%',
  },
  card: {
    padding: '0px',
    backgroundColor: 'var(--background-content)',
    borderRadius: '4px',
    width: '100%',
    margin: '8px',
    '& .MuiCardHeader-root': {
      padding: '16px 32px'
    },
    '& .MuiCardContent-root': {
      padding: '16px 32px'
    }
  },
  simpleCardGroup: {
    width: '100%',
    display: 'flex',
    justifyContent: 'space-around',
    height: '100%'
  },
  marginLeftZero: {
    marginLeft: '0',
  },
  unitDaysHeading: {
    display: 'grid',
    gridTemplateColumns: '50% 50%',
    gridGap: '2ch',
    padding: '0 1rem',
    '& #days': {
      paddingLeft: '120pt'
    },
  },
  tablecard: {
    padding: '0px',
    backgroundColor: 'var(--background-content)',
    borderRadius: '4px',
    width: 'calc(100% - 16px)',
    margin: '8px',
    '& .MuiCardHeader-root': {
      padding: '22px 10px 0 20px'
    },
    '& .MuiCardContent-root': {
      padding: '16px 15px 10px 20px'
    }
  },
  tableRow: {
    '&:nth-of-type(even)': {
      backgroundColor: 'var(--list-alternate-row)',
      color: 'var(--text) !important'
    }
  },
  tableWidth: {
    width: 'auto'
  },
  tableCellBorder: {
    border: '2px solid var(--list-divider-line)'
  },
  ignoreChecks: {
    display: "inline-block",
    position: "absolute",
    left: "36%",
    paddingTop: 5,
    zIndex: 1,
    [theme.breakpoints.down('md')]: {
      left: '66%'
    }
  },
  cardHeight: {
    height: '96%'
  },
  cardWrapperForFloatTable: {
    position: 'relative'
  },
  tablesInCard: {
    display: 'flex',
    '& > table:first-child': {
      marginRight: '1rem'
    }
  },
  flexColumn: {
    display: 'flex',
    flexDirection: 'column',
    '& > div': {
      flex: 1,
    },
    '& > div:first-child': {
      flexBasis: '5%',
    }
  },
  flexGrid: {
    display: 'flex',
    flexDirection: 'column',
  },
  flexHeight: {
    flex: "1",
    '& > div': {
      '& > div': {
        height: 'calc(100% - 16px)'
      }
    }
  },
  textAlignLast: {
    textAlignLast: 'right',
  }
});

class ItemDetail extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      fields: false,
      values: false,
      hasError: false,
      errorId: false,
      customCards: false,
      hasHardError: false,
      buyerMinMaxSafetyStockArray:[],
      manuaSSDisabled: true,
      workOrActualDaysLabels: false,
      demandOrderComponentLabels: false,
      // actualDaysLabels: false,
      // workDayLabels: false,
      cardtitle : WORK_DAYS,
      conditionalFieldValues: false ,
      ForwardBuyUnits: FB_UNITS,
      overrideLabels: false,
      ignoreCheckboxesArray: false,
      effSSType: null,
      stockStausLabelOpt: '', //E3C-33377, 11/17/21, Kumar
    };
    this.getMessageText = this.getMessageText.bind(this)
  }
  componentDidMount() {
    let cards = CUSTOM_CARDS;
    const values = this.setCustomCards(cards);
    this.setState({ customCards: JSON.parse(JSON.stringify(values)) });
    this.toggleBuyerMinMaxSafetyStockFields();
    
    this.setConditionalFieldValues(); 
    this.setUnitsToDaysLabels(this.props.workOrActualDaysLabels || WORK_DAYS);
    this.setdemandOrderComponentLabels(); //E3C-33377, 11/17/21, Kumar:Start
    let stockStausLabelOpt = [];
    for (let k in STOCKSTATUS_TABLE_KEY_LABEL) {
      if(STOCKSTATUS_TABLE_KEY_LABEL[k]['key'] != 'IPIUNT' && STOCKSTATUS_TABLE_KEY_LABEL[k]['key'] != 'ISOQB') {
        stockStausLabelOpt.push(STOCKSTATUS_TABLE_KEY_LABEL[k]);
      }
    }
    this.setState({ stockStausLabelOpt: stockStausLabelOpt }); //E3C-33377, 11/17/21, Kumar:End
  }
  componentDidUpdate(prevProps, prevState) {
    const { salesGraphCheck, depletionGraphCheck } = this.props.graphChecks;
    const { pageUpDownData, buyerMinMaxFieldsArray = false, newValueData, itemDetailLabelsData, itemMiscData, currencySelected } = this.props.ItemPropertiesData;
    if (pageUpDownData && JSON.stringify(pageUpDownData) != JSON.stringify(prevProps.ItemPropertiesData.pageUpDownData)) {
      if (+salesGraphCheck)
        this.prepareAndCallGraphAPI('sales', pageUpDownData);
      if (+depletionGraphCheck)
        this.prepareAndCallGraphAPI('depletion', pageUpDownData);
    }
    this.checkLoading();

    //Do not move it from here -Load conditionalFieldValues for Enable/disable controls
    if (!this.state.conditionalFieldValues && newValueData && itemMiscData) {
      this.setConditionalFieldValues();
    }
    //Enable or disable Manual Safety Stock field
    if (this.state.buyerMinMaxSafetyStockArray.length == 0 && buyerMinMaxFieldsArray) {
      this.toggleBuyerMinMaxSafetyStockFields();
    }
    if ((this.props.workOrActualDaysLabels && this.props.workOrActualDaysLabels != prevProps.workOrActualDaysLabels)
      || (newValueData && !isEqual(newValueData, prevProps.ItemPropertiesData.newValueData))
      || (currencySelected && !isEqual(currencySelected, prevProps.ItemPropertiesData.currencySelected))
      ) {
      this.setUnitsToDaysLabels(this.props.workOrActualDaysLabels || WORK_DAYS);
    }
    //Load workOrActualDaysLabels only once into state variables
    if (!this.state.workOrActualDaysLabels && itemDetailLabelsData) {
      if (itemDetailLabelsData.hasOwnProperty('tabcards')) {
        this.setUnitsToDaysLabels(this.props.workOrActualDaysLabels || WORK_DAYS);
      }
    }
    //Load demandOrderComponentLabels into state variables
    if (!this.state.demandOrderComponentLabels && itemDetailLabelsData) {
      if (itemDetailLabelsData.hasOwnProperty('tabcards')) {
        this.setdemandOrderComponentLabels();
      }
    }
    //Load demandOrderComponentLabels when ValueData is loaded
    if ((newValueData != prevProps.ItemPropertiesData.newValueData && newValueData) ||
      (itemMiscData != prevProps.ItemPropertiesData.itemMiscData && itemMiscData)) {
      if (itemDetailLabelsData.hasOwnProperty('tabcards')) {
        this.setdemandOrderComponentLabels();
      }
    }

  }

  componentDidCatch() {
    this.setState({ hasHardError: true })
  }
  handleChangeValue = (key, val) => {
    if (val === undefined || val == null) return;
    this.props.setValueData({ key, val });
    this.toggleSSField(key, val);
  }

  toggleSSField = (key, val) => {
    if (key == 'IPROWK') {
      if ((val == "0" && this.state.manuaSSDisabled == false) ||
        (val != "0" && this.state.manuaSSDisabled == true)) {
        this.toggleBuyerMinMaxSafetyStockFields(key, val);
      }

    }
  }

  getValueData = (valueData, newValueData) => {
    if (Object.keys(valueData).length && Object.keys(newValueData).length &&
      (JSON.parse(JSON.stringify(valueData)) !== JSON.parse(JSON.stringify(newValueData)))) {
      return newValueData;
    }
    return valueData;
  }

  //-------------------------------------------------------------------------
  //Enable or disable SafetyStock field based on Type
  //-------------------------------------------------------------------------
  toggleBuyerMinMaxSafetyStockFields = (key = false, val = false) => {
    const { buyerMinMaxFieldsArray = [], newValueData = false } = this.props.ItemPropertiesData;
    let buyerMinMaxSafetyStockArray = this.state.buyerMinMaxSafetyStockArray.length ? this.state.buyerMinMaxSafetyStockArray :
      buyerMinMaxFieldsArray.length ? [...buyerMinMaxFieldsArray] : [];

    if (buyerMinMaxSafetyStockArray.length && newValueData) {
      this.setState(prevState => {
        const index = buyerMinMaxSafetyStockArray.findIndex((cardfield) => cardfield.FLDID == "3956"); //IDCMNQ = Manual SS days     
        if (index >= 0) {
          if (key && val && key == "IPROWK") { //When user changes SS switch
            let flag = (val == "0");
            if (buyerMinMaxSafetyStockArray[index].disabled != flag) {
              buyerMinMaxSafetyStockArray[index].disabled = flag;
              return { buyerMinMaxSafetyStockArray: buyerMinMaxSafetyStockArray, manuaSSDisabled: flag };
            }
          }
          else {  // Update the state at intial Load
            let flag = (newValueData.IPROWK == "0");
            buyerMinMaxSafetyStockArray[index].disabled = flag;
            return { buyerMinMaxSafetyStockArray: buyerMinMaxSafetyStockArray, manuaSSDisabled: flag };
          }
        }
        return prevState;
      })
    }
  }

  setCustomCards = (customCards) => {
    let { cardfields } = customCards[0];
    cardfields = getSortableColumns(cardfields, false, COLUMN_FIELD_TYPE, DROPDOWN_FIELD);
    cardfields = setNumberFields(cardfields);
    cardfields.forEach((card) => {
      if (card.FDFNAM && card.FDFNAM.trim()) {
        card.key = card.prefixFlag ? card.FDFNAM.trim() : getListPredecessor('items') + card[COLUMN_VALUE_ACCESSOR].trim()
      }
    });
    customCards[0].cardfields = JSON.parse(JSON.stringify(cardfields))
    return customCards;
  }

  getRoundedNumbers = data => {
    if (data && Object.keys(data).length) {
      for (let key in data) {
        data[key] = isNaN(+data[key]) ? data[key] : (+data[key]).toString();
        if (['ILTFOR', 'ISSDYS'].includes(key)) {
          data[key] = Math.round(data[key])
        }
      }
    }
    return data;
  }
  prepareAndCallGraphAPI = (graphType, data = false) => {
    let { valueData } = this.props.ItemPropertiesData;
    if (!data) {
      data = valueData;
    }
    const apiKeys = ['COMP', 'ITEM', 'VNDR', 'WHSE'] //need to include 'DATE';
    const apiRecordData = apiKeys.map(row => ({ ...DEFAULT_VALUE_URL_DATA[0], accessor: row, fieldValue: data['I' + row] }))
    const payload = this.props.getApiObj(apiRecordData);
    this.props.loadItemDetailGraphData(payload, graphType, this.props.globalDateFormat);
  }
  handleGraphChecks = (key, val) => {
    this.props.handleGraphChecks(key, val);
    if (val == '1' && key == 'salesGraphCheck' && !this.isGraphDataOfCurrentValueData('sales')) {
      this.prepareAndCallGraphAPI('sales');
    }
    else if (val == '1' && key == 'depletionGraphCheck' && !this.isGraphDataOfCurrentValueData('depletion')) {
      this.prepareAndCallGraphAPI('depletion');
    }
  }
  isGraphDataOfCurrentValueData = (graphType) => {
    const { salesData, valueData, depletionData } = this.props.ItemPropertiesData;
    if (graphType == 'sales' && salesData && Object.keys(salesData).length && salesData.DEMND) {
      return ['COMP', 'WHSE', 'VNDR', 'ITEM'].every(key => {
        if (valueData['I' + key] == salesData.DEMND['PV' + key])
          return true;
      })
    }
    else if (graphType == 'depletion' && depletionData && Object.keys(depletionData).length && depletionData.ONHND) {
      return ['COMP', 'WHSE', 'VNDR', 'ITEM'].every(key => {
        if (valueData['I' + key] == depletionData.ONHND['PV' + key])
          return true;
      })
    }
    else return false;
  }
  checkLoading = () => {
    const { itemDetailLabelsData: { tabcards = false }, ignoreCheckboxesArray = false,
      buyerMinMaxFieldsArray = false, itemDetailGraphChecksArray = false, } = this.props.ItemPropertiesData;
    if (tabcards && ignoreCheckboxesArray && ignoreCheckboxesArray.length && buyerMinMaxFieldsArray && buyerMinMaxFieldsArray.length && itemDetailGraphChecksArray && itemDetailGraphChecksArray.length && !this.state.orderAdjustmentLoader) {
      this.props.setChildLoading(false);
    }
    else {
      this.props.setChildLoading(true);
    }
  }
  setChildLoading = name => loading => {
    if (this.state[name] != loading) {
      this.setState({ [name]: loading })
    }
  }
  getDemandHistoryLabels = () => {
    const { valueData, valueData: { IPERDF = false } = false } = this.props.ItemPropertiesData || {};
    if (!valueData || !IPERDF) return false;
    let currentPeriod = valueData['IPER' + IPERDF];
    let labelId = {
      "12": (index = 0) => {
        const startId = MONTHLY_LABEL_ID_START;
        if (index < 0) {
          index = index + 12;
        }
        return startId + index;
      },
      "13": (index = 0) => {
        const startId = WEEKLY13_LABEL_ID_START;
        if (index < 0) {
          index = index + 13;
        }
        return startId + index;
      },
      "52": (index = 0) => {
        const startId = WEEKLY52_LABEL_ID_START;
        if (index < 0) {
          index = index + 52;
        }
        return startId + index;
      }
    }
    let label1 = (labelId[IPERDF](currentPeriod - 5)).toString();
    let label2 = (labelId[IPERDF](currentPeriod - 4)).toString();
    let label3 = (labelId[IPERDF](currentPeriod - 3)).toString();
    let label4 = (labelId[IPERDF](currentPeriod - 2)).toString();
    let keyLabels = [
      {
        key: 'IDMDV1',
        label: label1
      },
      {
        key: 'IDMDV2',
        label: label2
      },
      {
        key: 'IDMDV3',
        label: label3
      },
      {
        key: 'IDMDV4',
        label: label4
      },
      {
        key: 'IDMDVC',
        label: '51017'
      },
    ]
    return keyLabels;
  }
  isBalanceAdjusted = (data) => {
    if (!data) return false;
    // if total adjustment > 0 or E3TOPS understock/overstock > 0
    // return true, else return false.
    const totalAdjustments = ['IONBAC', 'IQRSVR', 'IQHELD', 'IOQHLD', 'IOOPRM', 'IOHPUB', 'IEOQDT', 'ISOQB']
      .reduce((sum, key) => (+data[key] || 0) + sum, 0);
    return (totalAdjustments > 0 || data.IPIUNT > 0);
  }
  //Update Units to Days Labels into state 
  setUnitsToDaysLabels = (action = false) => {
    const { itemDetailLabelsData, newValueData, valueData } = this.props.ItemPropertiesData;
    const { workOrActualDaysLabels } = this.props;
    const { tabcards, actualDaysLabels } = itemDetailLabelsData;
    let labels = {};
    if (tabcards && action) {
      if (action == ACTUAL_DAYS) {
        labels = labels ? JSON.parse(JSON.stringify(actualDaysLabels)) : false;
      }
      else {  //Work Days 
        labels = tabcards.find(formCard => formCard.cardkey == "50542")
        labels = labels ? JSON.parse(JSON.stringify(labels)) : false;
        if (labels) {
          labels.cardtitle = JSON.parse(localStorage["messageLabels"])["H52865"]["TLLAB"] /*E3C-33266 'Work Days' */;
          // this.setState({ workDayLabels: labels });
        }
      }

      let manualOverride = newValueData ? parseInt(newValueData.IREVDT) > 0 : false;
      let conditionalFieldValues = this.setConditionalFieldValues(action);
      let fbUnitsIndex = null;
      let fbUnitsExists = false;
      let shelfLifeIndex = null;

      if (labels && labels.cardfields) {
        for (let [index, field] of labels.cardfields.entries()) {
          //Display SOQ* for Manual override of SOQ
          if (field.FDFNAM && field.FDFNAM.trim() == "SOQA" && manualOverride) {
            let { displayLabel, fieldName } = getLabelToDisplay(field, this.getMessageText('56111'), 'replace');
            if (displayLabel && fieldName) {
              field[fieldName] = displayLabel;
            }
          }
          //Display Balance* when balance is Adjusted
          if (field.FLDID == "3687" && this.isBalanceAdjusted(valueData)) {
            let { displayLabel, fieldName } = getLabelToDisplay(field, this.getMessageText('50436'), 'replace');
            if (displayLabel && fieldName) {
              field[fieldName] = displayLabel;
            }
          }
          // Item Cycle units, Override Label if required
          if (field.FLDID && field.FLDID.trim() == "4239") { //Item Cycle units 
            if (conditionalFieldValues.hasOwnProperty('overrideItemCycleLabel') && conditionalFieldValues.overrideItemCycleLabel) {
              let { displayLabel, fieldName } = getLabelToDisplay(field, this.getMessageText('52926'), 'replace');
              if (displayLabel && fieldName) {
                field[fieldName] = displayLabel;
              }
            }
          }
          // Item Cycle days, set Days value
          if (field.FLDID && field.FLDID.trim() == "51055" && conditionalFieldValues.hasOwnProperty('itemCycleDays')) {
            field.FDFNAM = 'itemCycleDays';
            field.key = 'itemCycleDays';
            field.prefixFlag = 1;
          }
          // Vendor Cycle units, Override Label if required
          if (field.FLDID && field.FLDID.trim() == "4242") {
            if (conditionalFieldValues.hasOwnProperty('overrideVendorCycleLabel') && conditionalFieldValues.overrideVendorCycleLabel) {
              let { displayLabel, fieldName } = getLabelToDisplay(field, this.getMessageText('52927'), 'replace');
              if (displayLabel && fieldName) {
                field[fieldName] = displayLabel;
              }
            }
          }
          // Vendor Cycle days, set Days value
          if (field.FLDID && field.FLDID.trim() == "51056" && conditionalFieldValues.hasOwnProperty('vendorCycleDays')) {
            field.FDFNAM = 'vendorCycleDays';
            field.key = 'vendorCycleDays';
            field.prefixFlag = 1;
          }
          // Lead time units, Override Label if required
          if (field.FLDID && field.FLDID.trim() == "4241") {
            if (conditionalFieldValues.hasOwnProperty('overrideLeadTimeLabel') && conditionalFieldValues.overrideLeadTimeLabel) {
              let { displayLabel, fieldName } = getLabelToDisplay(field, this.getMessageText('52928'), 'replace');
              if (displayLabel && fieldName) {
                field[fieldName] = displayLabel;
              }
            }
          }
          //Lead time days, set Days value 
          if (field.FLDID && field.FLDID.trim() == "4466" && conditionalFieldValues.hasOwnProperty('leadTimeDays')) {
            field.FDFNAM = 'leadTimeDays';
            field.key = 'leadTimeDays';
            field.prefixFlag = 1;
            if (conditionalFieldValues.showVendorLTQ) {
              field.labelJson = { ...LT_QUOTED };
              field.hasLabel = true;
            } else {
              field.hasLabel = false;
            }
          }
          if (field.FLDID && field.FLDID.trim() == "3911") { //FB Units index
            fbUnitsIndex = index;
          }
          if (field.FLDID && field.FLDID.trim() == "51058") { //Invalid Shelf life entry
            shelfLifeIndex = index;
          }
          //Dsiaplay Override Manual Safety Stock Units Label if Manual SS type == 2
          if (field.FDFNAM && field.FDFNAM.trim() == "CMNUT") {
            let labelId = conditionalFieldValues.overrideManualSS ? '40155' : '38382';
            let { displayLabel, fieldName } = getLabelToDisplay(field, this.getMessageText(labelId), 'replace');
            if (displayLabel && fieldName) {
              field[fieldName] = displayLabel;
            }
          }
          //Display Safety Stock days varies with Manual SS type switch
          if (field.FDFNAM && field.FDFNAM.trim() == "SSDYS" && conditionalFieldValues.ssDaysField) {
            field.FDFNAM = conditionalFieldValues.ssDaysField;
          }
          if (field.FDFNAM && field.FDFNAM.trim() == "SSQTY" && conditionalFieldValues.ssQtyField) {
            field.FDFNAM = conditionalFieldValues.ssQtyField;
          }
          //E3C-32838 -Begin - override VOP and OUTL labels if required
          if (field.FDFNAM && field.FDFNAM.trim() == 'MAXUF' && conditionalFieldValues.overrideOutlLabel) {
            let { displayLabel, fieldName } = getLabelToDisplay(field, this.getMessageText('52679'), 'replace');
            if (displayLabel && fieldName) {
              field[fieldName] = displayLabel;
            }

          }
          if (field.FDFNAM && field.FDFNAM.trim() == 'MINUF' && conditionalFieldValues.overrideVOPLabel) {
            let { displayLabel, fieldName } = getLabelToDisplay(field, this.getMessageText('52680'), 'replace');
            if (displayLabel && fieldName) {
              field[fieldName] = displayLabel;
            }

          }
          // E3C-32838: Display a * symbol for effective Safety Stock used in IOP calculations
          const EFFECTIVE_SSTYPE_LABEL_MAP = {
            'CSSUT': '33706',
            'CMNUT': '33956',
            'NUM2': '37002'
          }
          if (field.FDFNAM && EFFECTIVE_SSTYPE_LABEL_MAP[field.FDFNAM.trim()]) {
            let { displayLabel, fieldName } = getLabelToDisplay(field, this.getMessageText(EFFECTIVE_SSTYPE_LABEL_MAP[field.FDFNAM.trim()]), 'replace');
            if (conditionalFieldValues.effSSType == "I"+ field.FDFNAM.trim()) displayLabel = displayLabel + '*';
            if (displayLabel && fieldName) {
              field[fieldName] = displayLabel;
            }
          }
          //E3C-32838 -End
        }
        if (!fbUnitsExists) {
          // Change forward buy label and insert into the Cardfields.
          let ForwardBuyUnits = this.state.ForwardBuyUnits;
          let { displayLabel, fieldName } = getLabelToDisplay(ForwardBuyUnits, this.getMessageText('34174'), 'replace');
          if (displayLabel && fieldName) {
            ForwardBuyUnits[fieldName] = displayLabel;
          }
          labels.cardfields.splice(fbUnitsIndex, 0, this.state.ForwardBuyUnits);
        }
        if (shelfLifeIndex) {
          fbUnitsIndex ? labels.cardfields.splice(shelfLifeIndex + 1, 1) :
            labels.cardfields.splice(shelfLifeIndex, 1);
        }

      }
      if (labels && labels.cardtitle) {
        this.setState({ workOrActualDaysLabels: labels.cardfields });
        this.setState({ cardtitle: labels.cardtitle })
      }

      // let ignoreCheckboxesArray = {... this.state.overrideLabels} 
      // customLabels.cardfields.push(LT_QUOTED);
      // ignoreCheckboxesArray
    }
  }
  //=============================================================================================================
  //Set conditional switches like Calendar switch e.t.c
  setConditionalFieldValues = (action = false) => {
    const { newValueData, itemMiscData, ignoreCheckboxesArray = false,
      currencySelected = 'foreign',
      currencyConversion: { MCFTOL = false } = false,
    } = this.props.ItemPropertiesData;
    let conditionalFieldValues = this.state.conditionalFieldValues ? { ...this.state.conditionalFieldValues } : {};
    if (newValueData && itemMiscData) {
      //set Calendar Switch
      if (!conditionalFieldValues.WCALSW) {
        conditionalFieldValues.WCALSW = this.props.isCalendarActive();
      }
      conditionalFieldValues.IFNLPR = itemMiscData.IFNLPR;
      //---------------------------------------------------------------------------------------
      if (action) {
        let overrideItemCycleLabel = false;
        let overrideVendorCycleLabel = false;
        let overrideLeadTimeLabel = false;
        let overrideOutlLabel = false ;
        let overrideVOPLabel = false;
        let hasCalendars = this.props.isCalendarActive();
        let itemCycleDays = 0;
        let vendorCycleDays = 0
        let leadTimeDays = 0;
        let ssDaysField = 'SSDYS';
        let ssQtyField = 'SSQTY';
        let overrideManualSS = false;
        let showVendorLTQ = false;
        let effSSType = 'ICSSUT'; //E3C-33184

        let customLabels = JSON.parse(JSON.stringify(ignoreCheckboxesArray))

        if (hasCalendars) {
          if (action == WORK_DAYS) { //Work days with Calendar days
            overrideItemCycleLabel = parseInt(itemMiscData.CIOWDY) > 0;  //item cycle work days
            overrideVendorCycleLabel = parseInt(itemMiscData.CVWOCY) > 0; //Vendor cycle actual days
            overrideLeadTimeLabel = parseInt(itemMiscData.CLTWDY) > 0;
            itemCycleDays = overrideItemCycleLabel ? itemMiscData.CIOWDY : newValueData.IOCDYS;
            vendorCycleDays = overrideVendorCycleLabel ? itemMiscData.CVWOCY : newValueData.VORCYC;
            leadTimeDays = overrideLeadTimeLabel ? itemMiscData.CLTWDY : newValueData.ILTFOR;
          }
          if (action == ACTUAL_DAYS) { // Actual days ( with calendar)
            overrideItemCycleLabel = parseInt(itemMiscData.CIOCDY) > 0; //item cycle actual days
            overrideVendorCycleLabel = parseInt(itemMiscData.CVORCY) > 0; //Vendor cycle actual days
            overrideLeadTimeLabel = parseInt(itemMiscData.CLTCDY) > 0;
            itemCycleDays = overrideItemCycleLabel ? itemMiscData.CIOCDY : newValueData.IOCDYS;
            vendorCycleDays = overrideVendorCycleLabel ? itemMiscData.CVORCY : newValueData.VORCYC;
            leadTimeDays = overrideLeadTimeLabel ? itemMiscData.CLTCDY : newValueData.ILTFOR;
          }
        }
        else {  //no calendar 
          itemCycleDays = newValueData.IOCDYS;
          vendorCycleDays = newValueData.VORCYC;
          leadTimeDays = newValueData.ILTFOR;
        }
      
        //Display Lead time quoted if Shelf life days > 0
        if (newValueData.ISHELF > 0 && ignoreCheckboxesArray) {
          // customLabels.push(LT_QUOTED);
          showVendorLTQ = true;
        }
        this.setState({ ignoreCheckboxesArray: customLabels })
        //-------------------------------------------------------------------
        //Safety Stock Days field to display
        //-------------------------------------------------------------------
        // E3C-32838-Begin
        ssDaysField = 'DCOOD';
        ssQtyField = 'CSSUT';
        
        // if (this.getManualSafetyStockType(newValueData) == 2 ||
        //   (this.getManualSafetyStockType(newValueData) == 1 && this.getManualSafetyStockDays(newValueData) < this.getCalculatedSafetyStockDays(newValueData))) {
        //   overrideManualSS = true;
        //   // ssDaysField = (action == ACTUAL_DAYS) ? 'DCMNQ' : 'DCOOD';
        //   ssQtyField = 'CSSUT';
        // }
        //E3C-32838-End
        //-----------------------------------------------------------------------------
        //E3C-32838-Begin - logic for override VOP and OUTL
        //-----------------------------------------------------------------------------
        if (newValueData) {
          //validate buyer min and buyer max restrictions
          if (['D', 'U'].includes(newValueData.IDYUNT)) {
            overrideVOPLabel = ((newValueData.IDYUNT == 'D' && newValueData.IMINDF == newValueData.IPMINI && newValueData.IPMINI > 0) ||
              (newValueData.IDYUNT == 'U' && newValueData.IMINUF == newValueData.IPMINI && newValueData.IPMINI > 0))

            overrideOutlLabel = ((newValueData.IDYUNT == 'D' && newValueData.IMAXDF == newValueData.IPMAXI && newValueData.IPMAXI > 0) ||
              (newValueData.IDYUNT == 'U' && newValueData.IMAXUF == newValueData.IPMAXI && newValueData.IPMAXI > 0))
          }
          //OUTL Hardmax check
          if (!overrideOutlLabel) {
            overrideOutlLabel = parseInt(newValueData.ICHSW1) > 0;
            overrideVOPLabel = overrideOutlLabel && newValueData.IMAXUF == newValueData.IMINUF ;
          }
          // E3C-32838: Display a * symbol for effective Safety Stock used in IOP calculations
          switch (newValueData.IPROWK) {
            case '0':   //Ignore Manual SS
              // Effective SS = Hardmax when Hardmax > 0 & = Safety Stock & != Sys Calculated SS 
              // otherwise Effective SS = Sys Calculated SS  
              effSSType =
                (newValueData.INUM2 > 0 && newValueData.INUM2 > itemMiscData.ICSSUT) ? 'INUM2' :
                  'ICSSUT';
              break;
            case '1':   //Lesser of
              // Effective SS = Hardmax when Hardmax > 0 & = Safety Stock & != Sys Calculated SS 
              // otherwise Effective SS = Sys Calculated SS 
              effSSType =
                (itemMiscData.ICSSUT <= itemMiscData.ICMNUT && itemMiscData.ICSSUT >= newValueData.INUM2) ? 'ICSSUT' :
                  (itemMiscData.ICMNUT > 0 && itemMiscData.ICMNUT <= itemMiscData.ICSSUT & itemMiscData.ICMNUT >= newValueData.INUM2) ? 'ICMNUT' :
                    (newValueData.INUM2 > 0 && newValueData.INUM2 > itemMiscData.ICSSUT && newValueData.INUM2 > itemMiscData.ICMNUT) ? 'INUM2'
                      : 'ICSSUT';
              break;
            case '2':   //Always Manual SS ; Greater of Manual SS or Min Press
              effSSType =
                (itemMiscData.ICMNUT >= newValueData.INUM2) ? 'ICMNUT' :
                  (newValueData.INUM2 > itemMiscData.ICMNUT) ? 'INUM2' :
                    'ICMNUT';
              break;
            case '3':   //Greater of  SS, Manual SS or Min Press
              effSSType =
                (itemMiscData.ICSSUT >= itemMiscData.ICMNUT && itemMiscData.ICSSUT >= newValueData.INUM2) ? 'ICSSUT' :
                  (itemMiscData.ICMNUT >= itemMiscData.ICSSUT && itemMiscData.ICMNUT >= newValueData.INUM2) ? 'ICMNUT' :
                    (newValueData.INUM2 > itemMiscData.ICMNUT) ? 'INUM2' :
                      'ICSSUT';
              break;
          }
        }
        //E3C-32838-End
        conditionalFieldValues.overrideItemCycleLabel = overrideItemCycleLabel;
        conditionalFieldValues.overrideVendorCycleLabel = overrideVendorCycleLabel;
        conditionalFieldValues.itemCycleDays = itemCycleDays;
        conditionalFieldValues.vendorCycleDays = vendorCycleDays;
        conditionalFieldValues.leadTimeDays = leadTimeDays;
        conditionalFieldValues.showVendorLTQ = showVendorLTQ;
        conditionalFieldValues.overrideManualSS = overrideManualSS;
        conditionalFieldValues.ssDaysField = ssDaysField;
        conditionalFieldValues.ssQtyField = ssQtyField;
        conditionalFieldValues.overrideLeadTimeLabel = overrideLeadTimeLabel;
        //E3C-32838-Begin -override VOP & OUTL labels
        conditionalFieldValues.overrideOutlLabel = overrideOutlLabel ;
        conditionalFieldValues.overrideVOPLabel = overrideVOPLabel;
        conditionalFieldValues.effSSType = effSSType; // E3C-32838
        //E3C-32838-End
      }
      if (newValueData?.ICURCD?.trim?.()) {
        conditionalFieldValues.disableOverridePrice = currencySelected !== 'foreign';
        let currencyConversion = 1;
        if (+MCFTOL && currencySelected !== 'foreign') currencyConversion = MCFTOL;
        conditionalFieldValues.IOVRPR = (newValueData.IOVRPR * currencyConversion).toFixed(3);
        conditionalFieldValues.IPCHPR = (newValueData.IPCHPR * currencyConversion).toFixed(3);
        conditionalFieldValues.IEFFPR = (newValueData.IEFFPR * currencyConversion).toFixed(3);
        conditionalFieldValues.IFNLPR = (itemMiscData.IFNLPR * currencyConversion).toFixed(3);
      }
      //---------------------------------------------------------------------------------------
      this.setState({ conditionalFieldValues })
    }
    //-----------------------------------------------------------------------
    return conditionalFieldValues;
  }

  //Set Demand Order Component Labels (state update) 
  setdemandOrderComponentLabels = () => {
    const { canUpdateComponent } = this.props;
    const { itemDetailLabelsData } = this.props.ItemPropertiesData;
    const { tabcards } = itemDetailLabelsData;
    const { companyDetails } = this.props;
    let restrictOverridePrice = canUpdateComponent && canUpdateComponent.ITEMUI_IDA_RESTRICT_FIELDS ? true : false;
    let seasonalSwitch = getCompanyInfo(companyDetails, 'displaySeasonalForecastSwitch');
    let labels = false;

    if (tabcards && companyDetails && !this.state.demandOrderComponentLabels) {
      labels = tabcards.find(formCard => formCard.cardkey == ITEM_DETAIL_DEMAND_ORDER_COMPONENTS)
      labels = JSON.parse(JSON.stringify(labels)) ;
      if (restrictOverridePrice || seasonalSwitch) {
        for (let field of labels.cardfields) {
          if (field.FDFNAM.trim().substring(0, 3) == "DEM") { //Add (S) seasonal flag
            if (seasonalSwitch) {
              let { displayLabel, fieldName } = getLabelToDisplay(field, '(S)', 'add');
              if (displayLabel && fieldName) {
                field[fieldName] = displayLabel;
              }
            }
          }
          if (restrictOverridePrice) {
            if (field.FDFNAM.trim() == "OVRPR") {
              field.dataType = 'labels';  //Restrict if security doesn't allow
              break;
            }
          }
        }
      }
    }
    if (labels) {
      this.setState({ demandOrderComponentLabels: labels })
    }
  }

  getManualSafetyStockDays(itemData = false){
    if(itemData){
      return parseInt(itemData.IDCMNQ)
    }
    return false;
  }
  getCalculatedSafetyStockDays(itemData = false){
    if(itemData){
      return parseInt(itemData.IDCOOD)
    }
    return false;
  }
  getManualSafetyStockType(itemData = false){
    if(itemData){
      return parseInt(itemData.IPROWK)
    }
    return false;
  }
  getMessageText = id => {
    const { messages } = this.props;
    if (messages && messages['H' + id]) {
      return messages['H' + id].TLLAB;
    }
    else if (+id) return id;
    else return '';
  }

  getCombinedValueData(valueData, newValueData, conditionalFieldValues){
    //E3C-33108, 20-oCT-2021, J Vamshi
    //Hide EventProfile(IDMPRF) when pBO->GetItemPromoProfileID() == pBO->GetItemDemandProfileID();
    const IDMPRF = valueData?.IPRPRF === valueData?.IDMPRF ? "" : valueData.IDMPRF || "";
    return ({ ...this.getValueData(valueData, newValueData), ...conditionalFieldValues, IDMPRF });
  }
  //E3C-32367 -- Start
  getCondtionalDemands = cardfields => {
    const { demandsMeta, valueData,
      currencySelected = 'foreign',
      currencyConversion: { MCFTOL = false } = false
     } = this.props.ItemPropertiesData;
    let fields = JSON.parse(JSON.stringify(cardfields));
    if (valueData?.IPERDF && demandsMeta?.length) {
      let fieldToDisplay = ({
        '12': '3760',
        '13': '3761',
        '52': '3763',
      })[valueData.IPERDF];
      fieldToDisplay = demandsMeta.find(field => field.FLDID === fieldToDisplay);
      if (fieldToDisplay) {
        fields.shift();//First field is demand field which not conditional. So removing it and adding a conditional field;
        fields.unshift(fieldToDisplay);
      }
    }
    if (valueData?.ICURCD?.trim?.()) {
      return fields.map(field => {
        if (field.FLDID === '3852' && MCFTOL) {
          field.disabled = currencySelected !== 'foreign';
        }
        return field;
      })
    }
    return fields;
  }
    //E3C-32367 --End
  render() {
    const { classes, setSaveData, globalDateFormat, filterCriteriaDetails, pageFilterOptions,
      globalFilterOptions, columnDefs, currentPage, getLabelValue, companyDetails, canUpdateComponent } = this.props;
    const { loading, valueData, newValueData, itemDetailLabelsData, itemMiscData, ignoreCheckboxesArray = false,
      buyerMinMaxFieldsArray = false, itemDetailGraphChecksArray = false, salesData, depletionData, userDefinedFieldsArray, userDefinedData } = this.props.ItemPropertiesData;
    const { tabcards } = itemDetailLabelsData;
    const { salesGraphCheck, depletionGraphCheck } = this.props.graphChecks;
    if (this.state.hasHardError) {
      return <h2> Oops Something Went Wrong </h2>
    }
    return (
      <div>
        {(!loading && tabcards && tabcards.length && ignoreCheckboxesArray && ignoreCheckboxesArray.length && buyerMinMaxFieldsArray && itemDetailGraphChecksArray) ? (
          <>
            <Grid container className={classes.pageContainer}>
              <Grid item xs={12} sm={12} lg className={`${classes.pageContainerFifty} ${classes.flexColumn}`}>
                <div>
                  <div className={classes.simpleCardGroup}>
                    {!loading && this.state.workOrActualDaysLabels &&  
                      tabcards.map(formCard => {
                        if (formCard.cardkey == "50542") {
                          return <CardComponent title={
                            <Box className={classes.unitDaysHeading}>
                              <label id="days" className={'MuiCardHeader-title'}>{this.getMessageText('53045')}</label>
                              <label className={'MuiCardHeader-title'}>{`${this.state.cardtitle}`}</label>
                            </Box>
                          } className={`${classes.card}`}>
                            <>
                              <Box className={classes.ignoreChecks}>
                                <FormFieldsGenerator
                                  handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                                  key={formCard.cardkey + '1'}
                                  parentPage={ITEMS_LIST_PAGE}
                                  fieldsArray={this.state.ignoreCheckboxesArray}
                                  valuesArray={{ ...newValueData , ...itemMiscData}}
                                  handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                  enableAddButton={(e) => { setSaveData(e) }}
                                  globalDateFormat={globalDateFormat}
                                  filterCriteriaDetails={filterCriteriaDetails}
                                  pageFilterOptions={pageFilterOptions}
                                  globalFilterOptions={globalFilterOptions}
                                  columnDefs={columnDefs}
                                  currentPage={currentPage}
                                  parentData={newValueData}
                                  labelDisplayCharacters={10}
                                  valueDisplayCharacters={5}
                                  className="IGNORE_CHECKS"
                                  canUpdateComponent={canUpdateComponent}
                                />
                              </Box>
                              <Box>
                                <FormFieldsGenerator
                                  handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                                  key={formCard.cardkey}
                                  parentPage={ITEMS_LIST_PAGE}
                                  className="ITEM_DETAIL_UNITS_DAYS"
                                  // fieldsArray={formCard.cardfields}
                                  fieldsArray = {this.state.workOrActualDaysLabels}
                                  valuesArray={this.getRoundedNumbers({ ...newValueData, ...itemMiscData, ...this.state.conditionalFieldValues})}
                                  handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                  enableAddButton={(e) => { setSaveData(e) }}
                                  globalDateFormat={globalDateFormat}
                                  filterCriteriaDetails={filterCriteriaDetails}
                                  pageFilterOptions={pageFilterOptions}
                                  globalFilterOptions={globalFilterOptions}
                                  columnDefs={columnDefs}
                                  currentPage={currentPage}
                                  parentData={newValueData}
                                  cardHasCheckBox={true}
                                  canUpdateComponent={canUpdateComponent}
                                  cardHasLabel
                                />
                              </Box>
                            </>
                          </CardComponent>
                        }
                      })}
                  </div>
                </div>
                <div>
                  <div className={classes.simpleCardGroup}>
                    {!loading && this.state.conditionalFieldValues && this.state.demandOrderComponentLabels && 
                      tabcards.map(formCard => {
                        if (formCard.cardkey == ITEM_DETAIL_DEMAND_ORDER_COMPONENTS) {
                          return <CardComponent title={formCard.cardtitle} className={`${classes.card}`}>
                            <Box className={classes.cardWrapperForFloatTable}>
                              <FormFieldsGenerator
                                handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                                key={formCard.cardkey}
                                parentPage={ITEMS_LIST_PAGE}
                                className="ITEM_DETAIL_DEMAND_ORDER_COMPONENTS"
                                fieldsArray={this.getCondtionalDemands(this.state.demandOrderComponentLabels.cardfields)}
                                valuesArray={this.getCombinedValueData(valueData, newValueData, this.state.conditionalFieldValues)}
                                handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                enableAddButton={(e) => { setSaveData(e) }}
                                globalDateFormat={globalDateFormat}
                                filterCriteriaDetails={filterCriteriaDetails}
                                pageFilterOptions={pageFilterOptions}
                                globalFilterOptions={globalFilterOptions}
                                columnDefs={columnDefs}
                                currentPage={currentPage}
                                parentData={newValueData}
                                labelDisplayCharacters={17}
                                valueDisplayCharacters={12}
                                cardHasCheckBox={true}
                                canUpdateComponent={canUpdateComponent}
                              />
                              <FormFieldsGenerator
                                handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                                key={'buyerMinMax'}
                                parentPage={ITEMS_LIST_PAGE}
                                className="ITEM_DETAIL_DEMAND_ORDER_COMPONENTS_BUYERMINMAX"
                                fieldsArray={this.state.buyerMinMaxSafetyStockArray}
                                valuesArray={this.getValueData(valueData, newValueData)}
                                handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                enableAddButton={(e) => { setSaveData(e) }}
                                globalDateFormat={globalDateFormat}
                                filterCriteriaDetails={filterCriteriaDetails}
                                pageFilterOptions={pageFilterOptions}
                                globalFilterOptions={globalFilterOptions}
                                columnDefs={columnDefs}
                                currentPage={currentPage}
                                parentData={newValueData}
                                labelDisplayCharacters={17}
                                valueDisplayCharacters={12}
                                canUpdateComponent={canUpdateComponent}
                              />
                            </Box>
                          </CardComponent>
                        }
                      })}
                  </div>
                </div>
              </Grid>
              <Grid item xs={12} sm={12} lg className={`${classes.pageContainerFifty} ${classes.flexGrid}`} >
                <Grid container item>
                  <div className={classes.simpleCardGroup}>
                      <Box className={`${classes.tablecard}`}>
                        <AccordionComponent
                          label={"50387"}
                          className={`${classes.tablecard}`}
                          onChange={() => {}}
                        >
                          {companyDetails && !!+companyDetails.CCSTSW && !!+companyDetails.CITPRG && userDefinedData &&
                            userDefinedFieldsArray && !!userDefinedFieldsArray.length &&
                            <FormFieldsGenerator
                              handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                              parentPage={ITEMS_LIST_PAGE}
                              className="ITEM_DETAIL_USERDEFINEDFIELDS"
                              fieldsArray={userDefinedFieldsArray}
                              valuesArray={userDefinedData}
                              handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                              enableAddButton={() => { }}
                              globalDateFormat={globalDateFormat}
                              filterCriteriaDetails={filterCriteriaDetails}
                              pageFilterOptions={pageFilterOptions}
                              globalFilterOptions={globalFilterOptions}
                              columnDefs={columnDefs}
                              currentPage={currentPage}
                              parentData={newValueData}
                              labelDisplayCharacters={10}
                              valueDisplayCharacters={20}
                              canUpdateComponent={canUpdateComponent}
                            />
                          }
                          {
                            companyDetails && !!+companyDetails.CCSTSW && !+companyDetails.CITPRG &&
                            <Box lineHeight='1.5'>
                              {this.props.getErrorMessage(CUSTOM_EXIT_NOT_FOUND)}
                            </Box>
                          }
                        </AccordionComponent>
                      </Box>
                  </div>
                </Grid>

                <Grid container item>
                  {itemDetailGraphChecksArray && !!itemDetailGraphChecksArray.length &&
                    <CardComponent className={classes.tablecard}>
                      <Box marginBottom="-10px" className={"ITEM_DETAIL_GRAPH_CHECKS"}>
                        {itemDetailGraphChecksArray.map((field, i) =>
                          <FormFieldComponent
                            parentPage={ITEMS_LIST_PAGE}
                            field={field}
                            valuesArray={this.props.graphChecks}
                            handleChangeValue={(key, val, field) => this.handleGraphChecks(key, val, field)}
                            enableAddButton={() => { }}
                            globalDateFormat={globalDateFormat}
                            filterCriteriaDetails={filterCriteriaDetails}
                            pageFilterOptions={pageFilterOptions}
                            globalFilterOptions={globalFilterOptions}
                            columnDefs={columnDefs}
                            currentPage={currentPage}
                            valueDisplayCharacters={3}
                            labelDisplayCharacters={i == 1 ? 15 : 13}
                            canUpdateComponent={canUpdateComponent}
                          />
                        )}
                      </Box>
                    </CardComponent>
                  }
                  <Box className={classes.tablecard}>
                    {(!!+salesGraphCheck && salesData && salesData.BOOKN && salesData.BOOKN.graphData.length) ?
                      <Box width='100%'>
                        <SalesGraph
                          data={this.props.ItemPropertiesData.salesData}
                          // startDate={getDateFormatValue(salesData.BOOKN.PVDATE) || new Date(2020)}
                          height={455}
                          getMessageText={this.getMessageText}
                        />
                      </Box>
                      :
                      (<ItemOrderAdjustmentsEmbeddedList itemData={valueData} setChildLoading={this.setChildLoading('orderAdjustmentLoader')} {...this.props} />)
                    }
                  </Box>
                </Grid>
                <Grid container item direction='row' className={classes.flexHeight}>
                  <Grid item xs>
                    {(!!+depletionGraphCheck && depletionData && depletionData.ONHND && depletionData.ONHND.graphData.length) ?
                      <Box width='100%' className={classes.tablecard}>
                        <DepletionGraph
                          data={this.props.ItemPropertiesData.depletionData}
                          // startDate={getDateFormatValue(depletionData.ONHND.PVDATE) || new Date(2020)}
                          height={455}
                          getMessageText={this.getMessageText}
                        />
                      </Box>
                      :
                      (<CardComponent className={classes.tablecard + ' ' + classes.marginLeftZero}>
                        <Box className={classes.tablesInCard}>
                          <TableComponent classes={{ table: classes.tableWidth, tableRow: classes.tableRow, tableCell: classes.tableCellBorder, textAlignLast: classes.textAlignLast }}
                            headLabels={['25426', '25425']}
                            rowMap={companyDetails && companyDetails.CTOPS == "1" ? STOCKSTATUS_TABLE_KEY_LABEL :  this.state.stockStausLabelOpt} //E3C-33377, 11/16/21, Kumar
                            values={newValueData}
                            getLabelValue={getLabelValue}
                          />
                          <TableComponent classes={{ table: classes.tableWidth, tableRow: classes.tableRow, tableCell: classes.tableCellBorder, textAlignLast: classes.textAlignLast }}
                            headLabels={['51006', '25425']}
                            rowMap={this.getDemandHistoryLabels()}
                            values={itemMiscData}
                            getLabelValue={getLabelValue}
                          />
                        </Box>
                      </CardComponent>)
                    }
                  </Grid>
                </Grid>
              </Grid>
            </Grid>
          </>
        ) : null
        }
      </div>
    );
  }
}

ItemDetail.propTypes = propTypes;

export default withStyles(style)(ItemDetail);

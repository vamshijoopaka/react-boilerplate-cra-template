import React from 'react';
import { PropTypes } from 'prop-types';
import { withStyles, Card, CardHeader, CardContent } from '@material-ui/core';

const proptypes = {
    title : PropTypes.string,
    subheader : PropTypes.string,
    children : PropTypes.shape({}),
}

const style = theme => ({

});

class CardComponent extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
        }
    }

    render() {
        return (
            <Card className={this.props.className}>
                {!!this.props.title &&
                    <CardHeader
                        // action={<IconButton aria-label="settings"><MoreVertIcon /></IconButton>}
                        title={this.props.title}
                        subheader={this.props.subheader}
                    />
                }
                <CardContent>
                    {this.props.children}
                </CardContent>
            </Card>
        );
    }
}

CardComponent.proptypes = proptypes;
export default withStyles(style)(CardComponent);
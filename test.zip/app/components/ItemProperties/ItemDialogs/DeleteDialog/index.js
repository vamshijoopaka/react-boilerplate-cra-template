import React from 'react';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import injectSaga from 'utils/injectSaga';
import { withStyles } from '@material-ui/core/styles';
import DialogComponent from 'components/common/DialogComponent';
import EmbeddedList from 'containers/common/EmbeddedList';
import { Box, Typography } from '@material-ui/core';
import theme from 'jda-gcp-theme';
import {
    ITEMS_DELETE,
    MENU_ITEMS,
    FILTER_OBJ,
    ITEM_ID,
    VENDOR_ID,
    DELETE_ITEMS,
} from './constants';
import {
    INITIAL_PAGE_PROPS,
    TEXT_CANCEL,
    TEXT_OK,
} from 'components/common/constants';
import { getListPredecessor } from 'utils/util';
import Spinner from 'components/Common/Spinner';
import injectReducer from 'utils/injectReducer';

import {
    rowDataSelector,
    columnDefsSelector,
    loadingSelector,
    columnFlagSelector,
    pagePropsSelector,
    filterPropsSelector,
    columnInfoSelector,
    isAPIProgressSelector,
    totalCountSelector,
    moreRecordsSelector,
    apiCallCountSelector,
    updateColumnsListSelector,
    errorMessageLabels
} from './selector';
import reducer from './reducer';
import saga from './saga';
import {
    getItemDeleteList,
    setApiCallCount,
    onSetPageProps,
    getItemDeleteColumnDefs,
    setFilterValues,
    setColumnDefsLoaded,
    updateShowHide,
    resetStateData,
    resetDefault
} from './action';
import ConfirmationDialog from 'components/common/ConfirmationDialog';

const styles = () => ({
    gridHeight: {
        minHeight: '300px'
    },
    headerWrapper: {
        borderRadius: '4px',
        border: '1px solid var(--divider-line)',
    },
    flexWrapper: {
        display: 'flex',
        flexWrap: 'wrap',
        padding: '24px',
        borderRadius: '4px',
    },
    fieldLabel: {
        color: 'var(--header-label-color)',
        padding: '0 0px 8px 0',
        width: '23ch',
    },
    childBlock: {
        display: 'flex',
        flexDirection: 'column',
        paddingRight: '60px',
        maxWidth: '33%'
    },
    fieldValue: {
        color: 'var(--value)'
    },
    fieldValuesParent: {
        display: 'flex'
    },
    idValue: {
        marginRight: '20px',
        minWidth: '8ch'
    }
});

class DeleteDialog extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            menuItems: [...MENU_ITEMS],
            rowSelection: 'multiple',
            selectedRows: false,
            selectAllFlag: false,
            selectedRecordsObject: {},
            deleteConfirmationDialog: false,
            selectedCount: 0
        }

    }
    componentDidMount() {
        const { itemData: data, isColumnDefsLoaded = false } = this.props;
        let filterData = [];
        filterData.push({ ...FILTER_OBJ, fieldValue: data.ICOMP });
        filterData.push({ ...FILTER_OBJ, accessor: 'VNDR', fieldValue: data.IVNDR });
        filterData.push({ ...FILTER_OBJ, accessor: 'ITEM', fieldValue: data.IITEM });
        this.props.setFilterValues(filterData);
        this.setPageForwardDirection(true);
        if (!isColumnDefsLoaded) {
            this.props.getItemDeleteColumnDefs({ type: ITEMS_DELETE });
        }
        else
            this.initialLoad({ pageProps: INITIAL_PAGE_PROPS, filterProps: filterData })
    }

    componentDidUpdate(prevProps, prevState) {
        const { columnDefs, rowData, isColumnDefsLoaded, filterProps, pageProps, updateColumnsList } = this.props;
        if ((pageProps != prevProps.pageProps) && pageProps.isPageSizeChanged) {
            let initialPageData = {
                ...pageProps,
                actualPage: 0,
                currentPage: 0,
                totalCount: 10,
                isForwardDirection: true,
            };
            this.props.onSetPageProps({
                ...pageProps,
                isPageSizeChanged: false
            });
            this.props.setApiCallCount(0);
            this.props.getItemDeleteList(this.getApiObj(filterProps, false, initialPageData));
        }

        if (columnDefs != prevProps.columnDefs && isColumnDefsLoaded != prevProps.isColumnDefsLoaded) {
            if (isColumnDefsLoaded) {
                this.props.getItemDeleteList(this.getApiObj(filterProps, false, pageProps));
            }
        }
        if (rowData != prevProps.rowData) {
            this.setAssociativeArrayObject(rowData)
        }

        if ((updateColumnsList != prevProps.updateColumnsList) && updateColumnsList) {
            this.props.getItemDeleteColumnDefs({ type: ITEMS_DELETE });
        }
        if ((prevState.selectAllFlag != this.state.selectAllFlag) || prevState.selectedCount != this.state.selectedCount) {
            if (this.state.selectAllFlag) {
                let deselectAllDisable = false, selectAllDisable = true;
                this.disableMenuItem(deselectAllDisable, selectAllDisable);
            }
            else if (!this.state.selectedCount) {
                let deselectAllDisable = true, selectAllDisable = false;
                this.disableMenuItem(deselectAllDisable, selectAllDisable);
            }
            else {
                this.disableMenuItem(false);

            }
        }
    }

    componentWillUnmount() {
        this.props.setColumnDefsLoaded(false);
        this.props.resetStateData(false)
    }

    updateMenuItems = (menuItems) => {
        this.setState({ menuItems: menuItems });
    }

    setAssociativeArrayObject = (rowData) => {
        const { apiCallCount } = this.props;
        let str = apiCallCount + "buffer";
        let data = this.state.selectedRecordsObject;
        if (data && Object.keys(data) && rowData && rowData.length) {
            for (let key in data) {
                let recordData = data[key];
                if (recordData && recordData.length && (key == str)) {
                    recordData.forEach((record, index) => {
                        rowData[index]["isSelected"] = record.isSelected;
                    })
                }
            }
        }
        data[str] = rowData;
        this.setState({ selectedRecordsObject: data })
    }

    changeValuesOnSelectDeselect = (flag) => {
        let recordObj = this.state.selectedRecordsObject;
        if (recordObj && Object.keys(recordObj)) {
            for (let key in recordObj) {
                if (recordObj[key] && recordObj[key].length) {
                    recordObj[key].forEach((record) => {
                        record.isSelected = flag;
                    })
                }
            }
        }
        this.setState({ selectedRecordsObject: recordObj })
    }

    updateSelectAllFlag = (flag) => {
        const { rowData = [] } = this.props;
        this.setState({ selectAllFlag: flag, selectedCount: flag ? rowData.length : 0 });
    }

    onRowSelected = (event) => {
        if (this.grid && this.grid.api) {
            const { apiCallCount, pageProps } = this.props;
            const { actualPageSize, actualPage } = pageProps;
            let data = this.state.selectedRecordsObject;
            if (data && Object.keys(data) && Object.keys(data).length) {
                let key = apiCallCount + "buffer";
                let rowIndex = (event.rowIndex + (actualPageSize * actualPage)) % 100;
                const { selected } = event.node;
                data[key][rowIndex]['isSelected'] = selected;
                this.setState({ selectedRecordsObject: data });
                this.setState(() => ({ selectedCount: this.grid.api.getSelectedRows().length || 0 }))
            }
        }
    }

    getApiObj = (filterProps, record, pageProps) => {
        let apiObj = {
            filterProps, filterProps,
            pageProps: pageProps,
            direction: pageProps.isForwardDirection,
            record: record,
            currentPage: 'items'
        };
        return apiObj;
    }


    setPageForwardDirection = (flag) => {
        let initialPageData = {
            ...INITIAL_PAGE_PROPS,
            actualPage: 0,
            currentPage: 0,
            totalCount: 10,
            isForwardDirection: flag
        };
        this.setState({ initialPageData });
        this.props.onSetPageProps(initialPageData);
    }

    getRecordDataOnDirection = (direction) => {
        const { rowData } = this.props;
        if (!rowData) {
            return;
        }
        if (!direction) {
            let count = this.props.apiCallCount;
            this.props.setApiCallCount(count - 1);
            return rowData[0];
        } else {
            let count = this.props.apiCallCount;
            this.props.setApiCallCount(count + 1);
            return rowData[rowData.length - 1];
        }
    }

    initialLoad = (props, flag = true) => {
        const { filterProps, pageProps } = props;
        let record;
        if (flag) {
            record = {}
        } else {
            record = this.getRecordDataOnDirection(pageProps.isForwardDirection);
        }
        if (pageProps && filterProps) {
            this.props.getItemDeleteList(this.getApiObj(filterProps, record, pageProps));
        }
    }


    disableMenuItem = (deselectAllDisable, selectAllDisable) => {
        this.setState({
            menuItems: MENU_ITEMS.map(row => {
                let item = { ...row };
                if (item.key == 'deselectAll')
                    item.isDisable = deselectAllDisable;
                else if (item.key == 'selectAll' && selectAllDisable != undefined)
                    item.isDisable = selectAllDisable;
                return item;
            })
        })
    }

    getSelectedRowsForAPI = () => {
        let selectedRows = [];
        let recordObj = this.state.selectedRecordsObject;
        if (recordObj && Object.keys(recordObj)) {
            for (let key in recordObj) {
                let dataRecord = recordObj[key];
                if (dataRecord && dataRecord.length) {
                    dataRecord.forEach((record) => {
                        if (record.isSelected) {
                            selectedRows.push(record);
                        }
                    })
                }
            }
        }
        return selectedRows;
    }


    handleSubmit = () => {
        const { parentFilters: filterProps, itemData, parentSort: sortProps } = this.props;
        let currentRecord = {};
        for (let key in itemData) {
            if (itemData[key].trim()) {
                currentRecord[key] = itemData[key];
            }
        }
        if (this.state.selectAllFlag) {
            let selectAllFilterProps = [{ ...FILTER_OBJ, fieldValue: currentRecord.ICOMP }];
            selectAllFilterProps.push({ ...FILTER_OBJ, accessor: 'VNDR', fieldValue: currentRecord.IVNDR });
            selectAllFilterProps.push({ ...FILTER_OBJ, accessor: 'ITEM', fieldValue: currentRecord.IITEM });
            this.props.deleteItems([], true, { filterProps, sortProps, record: currentRecord, pageProps: { pageSize: 3 }, direction: true, currentPage: 'items', selectAllFlag: true, selectAllFilterProps })
            this.handleClose();
            return;
        }
        let selectedRows = this.getSelectedRowsForAPI();
        let keyFields = ['ICOMP', 'IWHSE', 'IVNDR', 'ISUBV', 'ISUPV'];
        let includesCurrent = selectedRows.find(row => keyFields.every(key => (row[key] && row[key].trim()) == (itemData[key] && itemData[key].trim())));
        if (includesCurrent) {
            this.props.deleteItems(selectedRows, true, { filterProps, sortProps, record: currentRecord, pageProps: { pageSize: 3 }, direction: true, currentPage: 'items' })
            this.handleClose(); return;
        }
        this.props.deleteItems(selectedRows);
        this.handleClose();
    }
    handleConfirmBeforeSubmit = (flag = true) => {
        this.setState({ deleteConfirmationDialog: flag, hasWarning: flag })
    }

    handleClose = () => {
        if (this.props.closeDialog) {
            this.props.closeDialog();
        }
    }

    onGridReady = (params) => {
        this.grid = params;
    }

    render() {
        const { itemData, columnDefs, rowData, loading, getLabelValue, errorMessages } = this.props;
        const { classes, ...other } = this.props;
        return (
            <div>
                <DialogComponent
                    isOpen={true}
                    dialogTitle={getLabelValue(DELETE_ITEMS)}
                    handleClose={this.handleClose}
                    cancelText={TEXT_CANCEL}
                    submitText={TEXT_OK}
                    handleCancel={this.handleClose}
                    handleSubmit={() => this.handleConfirmBeforeSubmit()}
                    disableSubmit={(this.getSelectedRowsForAPI() && this.getSelectedRowsForAPI().length) ? false : true}>
                    <Box className={classes.headerWrapper} m={theme.spacing(1)}>
                        <Box className={classes.flexWrapper}>
                            <Box className={classes.childBlock}>
                                <div className={classes.fieldLabel}>{getLabelValue(ITEM_ID)}</div>
                                <div className={classes.fieldValuesParent}>
                                    <Typography className={classes.fieldValue + ' ' + classes.idValue}>{itemData.IITEM}</Typography>
                                </div>
                            </Box>
                            <Box className={classes.childBlock}>
                                <div className={classes.fieldLabel}>{getLabelValue(VENDOR_ID)}</div>
                                <div className={classes.fieldValuesParent}>
                                    <Typography className={classes.fieldValue + ' ' + classes.idValue}>{itemData.IVNDR}</Typography>
                                </div>
                            </Box>
                        </Box>
                    </Box>
                    <div className={classes.gridHeight}>
                        {columnDefs && columnDefs.length ?
                            <React.Fragment>
                                {loading && <Spinner loading type={this.props.nameSpace} />}
                                <EmbeddedList
                                    {...other}
                                    selectAllFlag={this.state.selectAllFlag}
                                    updateSelectAllFlag={this.updateSelectAllFlag}
                                    selectedRecordsObject={this.state.selectedRecordsObject}
                                    hasSelectDeselectAll={true}
                                    changeValuesOnSelectDeselect={this.changeValuesOnSelectDeselect}
                                    updateMenuItems={() => { }}
                                    suppressRowClickSelection={false}
                                    onRowSelected={this.onRowSelected}
                                    currentPage={"itemsDelete"}
                                    listPredecessor={getListPredecessor(this.props.currentPage)}
                                    rowSelection={this.state.rowSelection}
                                    props={this.props}
                                    listProps={this.props}
                                    suppressSizeToFit={true}
                                    nameSpace={"itemsDelete"}
                                    onGridReady={this.onGridReady}
                                    rowData={rowData}
                                    updateShowHide={(data) => this.props.updateShowHide(data)}
                                    menuItems={this.state.menuItems}
                                    onSelectAll={(data) => this.onSelectAll(data)}
                                    columnDefs={columnDefs}
                                    gridHeight={'350px'}
                                    resetDefault={(data) => this.props.resetDefault(data)}
                                    hasGridActions={true}
                                    rowMultiSelectWithClick={true}
                                >
                                </EmbeddedList>
                            </React.Fragment>
                            : <Spinner loading type={this.props.nameSpace} />
                        }
                    </div>
                </DialogComponent>
                {this.state.deleteConfirmationDialog &&
                    <ConfirmationDialog
                        isOpen={this.state.deleteConfirmationDialog}
                        dialogTitle={getLabelValue('52891')}
                        cancelText={TEXT_CANCEL}
                        submitText={TEXT_OK}
                        hasWarning={this.state.hasWarning}
                        handleClose={() => this.handleConfirmBeforeSubmit(false)}
                        handleCancel={() => this.handleConfirmBeforeSubmit(false)}
                        handleSubmit={() => this.handleSubmit(true)}>
                        <div>
                            {errorMessages ? errorMessages['E6791']['MTEXT'] : 'Confirmation'}
                        </div>
                    </ConfirmationDialog>
                }
            </div>
        )
    }
}
const mapStateToProps = createStructuredSelector({
    rowData: rowDataSelector(),
    columnDefs: columnDefsSelector(),
    loading: loadingSelector(),
    pageProps: pagePropsSelector(),
    isColumnDefsLoaded: columnFlagSelector(),
    filterProps: filterPropsSelector(),
    columnInfo: columnInfoSelector(),
    isAPIProgress: isAPIProgressSelector(),
    totalCount: totalCountSelector(),
    moreRecordsAvailable: moreRecordsSelector(),
    apiCallCount: apiCallCountSelector(),
    updateColumnsList: updateColumnsListSelector(),
    errorMessages: errorMessageLabels()
})

function mapDispatchToProps(dispatch) {
    return {
        dispatch,
        getItemDeleteColumnDefs: (data) => { dispatch(getItemDeleteColumnDefs(data)) },
        getItemDeleteList: (data) => { dispatch(getItemDeleteList(data)) },
        onSetPageProps: (data) => { dispatch(onSetPageProps(data)) },
        resetDefault: (data) => dispatch(resetDefault(data)),
        resetStateData: (data) => { dispatch(resetStateData(data)) },
        setApiCallCount: (data) => { dispatch(setApiCallCount(data)) },
        setColumnDefsLoaded: (data) => { dispatch(setColumnDefsLoaded(data)) },
        setFilterValues: (data) => { dispatch(setFilterValues(data)) },
        updateShowHide: (data) => { dispatch(updateShowHide(data)) },
    }
}

const withConnect = connect(
    mapStateToProps,
    mapDispatchToProps,
);
const withReducer = injectReducer({ key: 'itemDeleteReducer', reducer });
const withSaga = injectSaga({ key: 'itemDeleteSaga', saga });
export default compose(
    withReducer,
    withSaga,
    withConnect,
    withStyles(styles),
)(DeleteDialog);

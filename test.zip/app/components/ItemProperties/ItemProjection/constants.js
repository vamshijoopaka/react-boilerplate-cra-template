export const ITEM_DETAIL_UNITS_WORKDAYS = '50387';
export const ITEM_DETAIL_USER_DEFINED_FIELDS = '50387';
export const ITEM_PROJECTIONS_OPTIONS = '27526';
export const ITEM_PROJECTIONS_OCF = '50916';
export const ITEM_PROJECTIONS_MTGRAPH = '50758';
export const CUSTOM_CARD_ONE = '4434';
export const CUSTOM_CARD_TWO = '4501';
export const CUSTOM_CARD_THREE = '3331';
export const CUSTOM_CARD_FOUR = '4452';

export const CUSTOM_CARD_KEY = '50916';

export const CONTEXT_MENU_ITEM_OPTIONS = [
  {
    label: '53360',
    key: 'Re-Project',
    hasSubMenu: false,
  },
  {
    label: '53206',
    key: 'Re-MADP',
    hasSubMenu: false,
  },
];

export const DEFAULT_FILTER_PROPS = [
  { "accessor": "COMP", 'prefixFlag': 0, "key": "COMP", "operator": "=", "fieldValue": "", "jOpr": 'and' },
  { "accessor": "WHSE", 'prefixFlag': 0, "key": "WHSE", "operator": "=", "fieldValue": "", "jOpr": 'and' },
  { "accessor": "ITEM", 'prefixFlag': 0, "key": "ITEM", "operator": "=", "fieldValue": "", "jOpr": 'and' },
]

export const OPTIONS_LABLES = [
  {value: "12", label: "12 - Monthly"},
  {value: "13", label: "13 - 13 - 4 Weekly"},
  {value: "364", label: "364 - Daily"},
  {value: "52", label: "52 - Weekly"}
];

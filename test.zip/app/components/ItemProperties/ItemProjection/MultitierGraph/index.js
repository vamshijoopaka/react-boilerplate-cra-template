import React from 'react';
import PropTypes from 'prop-types';
import HightchartsReact from 'highcharts-react-official';
import Highcharts from 'highcharts/highstock';

class MultitierGraph extends React.PureComponent {
  constructor(props) {
    super(props);
    
  }

  render() {
    const { series, categories } = this.props;

    const options = {
      title: {
        text: 'Multi-Tier Graph',
      },
      yAxis: {
        title: {
          text: '',
        },
      },
      xAxis: {
        categories,
      },
      legend: {
        layout: 'vertical',
        align: 'right',
        verticalAlign: 'middle',
      },
      plotOptions: {
        series: {
          label: {
            connectorAllowed: false,
          },
        },  
      },
      credits: {
        enabled: false,
      },
      series,
      responsive: {
        rules: [
          {
            condition: {
              maxWidth: 500,
            },
            chartOptions: {
              legend: {
                layout: 'horizontal',
                align: 'center',
                verticalAlign: 'bottom',
              },
            },
          },
        ],
      },
    };
    return <HightchartsReact highcharts={Highcharts} options={options} />;
  }
}


export default MultitierGraph;

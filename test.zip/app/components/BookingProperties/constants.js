export const HeaderAPIValuesJSON = [
	{
		"BKNAME": "",//VENDOR NAME
		"BKSUBV": "", //subvendor 
		"BKVNDR": "",//VENDOR ID
		"BKITEM": "",//itemid
		"INAME": "",//Item name
		"WNAME": "",//WAREHOUSE NAME
		"BKWHSE": "",//WAREHOUSE ID
	}
];
export const BRACKET_LABEL_URL_DATA = [
    { "accessor": "TRIMBO", "operator": "=", "fieldValue": "TrimCommon", "prefixFlag": 0 },
    { "accessor": "LANGID", "operator": "=", "fieldValue": "ENG", "prefixFlag": 0 }
]
export const LABEL_LIST_URL_DATA = [
	{ "accessor": "TRIMBO", "operator": "=", "fieldValue": "TrimBookingsUI", "prefixFlag": 0 },
	{ "accessor": "LANGID", "operator": "=", "fieldValue": "ENG", "prefixFlag": 0 }
]
export const DEFAULT_VALUE_URL_DATA = [
	{ "accessor": "COMP", "operator": "=", "fieldValue": "", "prefixFlag": 0 },
	{ "accessor": "WHSE", "operator": "=", "fieldValue": "", "prefixFlag": 0 },
	{ "accessor": "ITEM", "operator": "=", "fieldValue": "", "prefixFlag": 0 },
	{ "accessor": "SDAT", "operator": "=", "fieldValue": "", "prefixFlag": 0 },
	{ "accessor": "CSID", "operator": "=", "fieldValue": "", "prefixFlag": 0 }
]
export const FILTER_DATA = ["COMP", "VNDR", "ITEM", "WHSE"];
export const BOOKING_CONTROL_FACTORS = "50861";
export const LABEL_VENDOR_ID = "34433";
export const LABEL_SUB_VENDOR_ID = "34435";
export const LABEL_VENDOR_NAME = "33989";
export const LABEL_WAREHOUSE_NAME = "36479";
export const LABEL_WAREHOUSE_ID = "33161";
export const LABEL_ITEM_ID = "33670";
export const LABEL_ITEM_NAME = "33990";
export const LABEL_COPY = "25212";
export const LABEL_DELETE = "25211";

export const CONTEXT_MENU_BOOKING_ACTIONS = [
	{
		label: LABEL_COPY,
		key: LABEL_COPY,
		hasSubMenu: false,
		isDisable: false
	},
	{
		label: LABEL_DELETE,
		key: LABEL_DELETE,
		hasSubMenu: false,
		isDisable: false
	},
];


import { createSelector } from 'reselect';
import { initialState } from './reducer';
import { VENDOR_COLUMN_HEADER_ACCESSOR, VENDOR_COLUMN_VALUE_ACCESSOR, VENDOR_COLUMN_POSITION } from './../../containers/VendorsListPage/constants';

const errorMessageLabels = (state) => state.get('root').get('errorMessageLabels')

const selectColumnData = (state) => { console.log("state", state); return state.get('customGrid').columnDefs || initialState.columnDefs };

const selectGlobalDateFormat = (state) => state.get('root').get('dateFormat').toUpperCase();//Preferences fix

const selectGlobalNumberFormat = (state) => state.get('root').get('numberFormatter');

const selectGlobalNumberSeparator = (state) => state.get('root').get('numberSeparator');

const selectGlobalDecimalSeparator = (state) => state.get('root').get('decimalSeparator');

const columnDefsSelector = createSelector(
    selectColumnData,
    data => {
        console.log(data);
        if (data.length && data[0].VENDOR_COLUMN_VALUE_ACCESSOR) {
            data = data.sort((val1, val2) => Number(val1.VENDOR_COLUMN_POSITION.trim()) - Number(val2.VENDOR_COLUMN_POSITION.trim()));
            data = data.map(col => Object.assign({}, col, { field: col.VENDOR_COLUMN_VALUE_ACCESSOR ? col.VENDOR_COLUMN_VALUE_ACCESSOR.trim() : col.field }));
            return data;
        } else if (data.length && !data[0].VENDOR_COLUMN_VALUE_ACCESSOR) {
            return data;
        } else if (data.length && !data[0].FDFNAM) {
            return data;
        }
        return [];
    }
)

export {
    columnDefsSelector, selectColumnData,
    errorMessageLabels, selectGlobalDateFormat, selectGlobalNumberFormat, selectGlobalNumberSeparator, selectGlobalDecimalSeparator
};
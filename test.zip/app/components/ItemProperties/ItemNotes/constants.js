export const LABEL_NOTE = '25297';
export const ITEM_NOTES = 'itemnotes';
export const ITEM_NOTES_FILTER_PROPS = [
    {"accessor":"FLID","operator":"=","jOpr":"and","key":"FLID","fieldValue":""},
    {"accessor":"FKEY","operator":"=","jOpr":"and","key":"FKEY","fieldValue":""}
]

export const FILTER_DATA = ["COMP", "ITEM", "VNDR", "WHSE"];

export const GET_ITEM_NOTES = 'GET_ITEM_NOTES';
export const GET_ITEM_NOTES_SUCCESS = 'GET_ITEM_NOTES_SUCCESS';
export const GET_ITEM_NOTES_FAILURE = 'GET_ITEM_NOTES_FAILURE';
export const CLEAR_NOTES_DATA = 'CLEAR_NOTES_DATA';
export const GET_ITEM_NOTE_DETAILS = 'GET_ITEM_NOTE_DETAILS';
export const GET_ITEM_NOTE_DETAILS_SUCCESS = 'GET_ITEM_NOTE_DETAILS_SUCCESS';
export const GET_ITEM_NOTE_DETAILS_FAILURE = 'GET_ITEM_NOTE_DETAILS_FAILURE';
export const GET_ITEM_NOTES_ALL_SUCCESS = 'GET_ITEM_NOTES_ALL_SUCCESS';
export const SET_ITEM_SELECTED_NOTE_DETAILS = 'SET_ITEM_SELECTED_NOTE_DETAILS';
export const CONTROL_ITEM_NOTE_CREATION = 'CONTROL_ITEM_NOTE_CREATION';
export const CONTROL_ITEM_NOTE_CREATION_SUCCESS = 'CONTROL_ITEM_NOTE_CREATION_SUCCESS';
export const CONTROL_ITEM_NOTE_CREATION_FAILURE = 'CONTROL_ITEM_NOTE_CREATION_FAILURE';
export const SET_ITEM_NOTE_CONTROL_COUNT = 'SET_ITEM_NOTE_CONTROL_COUNT';
export const REMOVE_ITEM_NOTE_OF_KEY = 'REMOVE_ITEM_NOTE_OF_KEY';
export const CLEAR_ITEM_NOTES = 'CLEAR_ITEM_NOTES';
export const SET_IS_EMBEDDED_LIST = 'SET_IS_EMBEDDED_LIST';
export const CLEAR_STATE_VALUES = "CLEAR_STATE_VALUES";

export const NOTES_TEXT_ACCESSOR = 'MFTEXT';
export const NOTES_KEY_ACCESSOR = 'MFKEY';
export const NO_NOTES_TO_SHOW_TEXT = 'No Notes To Show'


export const MENU_ITEMS = [
    {
        label: '51170',
        key: 'Remove All',
        hasSubMenu: false,
        isDisable: false,
    },
    {
        label: '25651',
        key: 'note',
        hasSubMenu: false,
        isDisable: false,
    }
]


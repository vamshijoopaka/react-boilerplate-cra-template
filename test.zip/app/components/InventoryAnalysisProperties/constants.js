export const INVENTORY_ANALYSIS_PROPERTIES = 'inventoryAnalysisProperties';
export const LABEL_LIST_URL_DATA = [
  {
    accessor: 'TRIMBO',
    operator: '=',
    fieldValue: 'TrimVendorUIModified',
    prefixFlag: 0,
  },
  { accessor: 'LANGID', operator: '=', fieldValue: 'ENG', prefixFlag: 0 },
];

export const HeaderAPIValuesJSON = {
  NAME: '', // VENDOR NAME
  VNDR: '', // VENDOR ID
  WNAME: '', // WAREHOUSE NAME
  WHSE: '', // WAREHOUSE ID
  'IUPC#': '',
  MFGID: '',
  OPCDT: '',
  LSODT: '',
  SUPER: '',
};

export const DEFAULT_VALUE_URL_DATA = [
  { accessor: 'COMP', operator: '=', fieldValue: '', prefixFlag: 0 },
  { accessor: 'WHSE', operator: '=', fieldValue: '', prefixFlag: 0 },
  { accessor: 'VNDR', operator: '=', fieldValue: '', prefixFlag: 0 },
  { accessor: 'SUBV', operator: '=', fieldValue: '', prefixFlag: 0 },
  { accessor: 'SUPV', operator: '=', fieldValue: '', prefixFlag: 0 },
  { accessor: 'ITEM', operator: '=', fieldValue: '', prefixFlag: 0 },
  { accessor: 'PERDF', operator: '=', fieldValue: '', prefixFlag: 0}
];

const INVESTMENT_ANALYSIS = 'Investment Analysis...';
const LAYERED_SUMMARY = 'Layered Summary...';

export const CONTEXT_MENU_ITEM_HEADER = [
  {
    label: '50746',
    key: INVESTMENT_ANALYSIS,
    hasSubMenu: false,
    isDisable: false
  },
  {
    label: '50747',
    key: LAYERED_SUMMARY,
    hasSubMenu: false,
		isDisable: false
  },
];
export const MENU_ITEMS = [
  {
    label: '2812',
    key: 'showHide',
    hasSubMenu: false,
    isDisable: false
  },
  {
    label: '2857',
    key: 'resetDefaults',
    hasSubMenu: false,
    isDisable: false
  }
]

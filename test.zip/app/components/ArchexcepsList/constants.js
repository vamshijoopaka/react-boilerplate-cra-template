import {
    COLUMN_HEADER_ACCESSOR, 
    COLUMN_VALUE_ACCESSOR,
    COLUMN_SHOW_HIDE_FLAG,
    COLUMN_POSITION,
    COLUMN_HEADER_PREFIX_FLAG
} from '../common/constants';


export const DEFAULT_ACTION = 'app/ArchexcepsListPage/DEFAULT_ACTION';
export const LOAD_ARCHEXCEPS = 'app/ArchexcepsListPage/LOAD_ARCHEXCEPS';
export const LOAD_ARCHEXCEPS_ERROR = 'app/ArchexcepsListPage/LOAD_ARCHEXCEPS_ERROR';
export const LOAD_ARCHEXCEPS_SUCCESS = 'app/ArchexcepsListPage/LOAD_ARCHEXCEPS_SUCCESS';
export const LOAD_ARCHEXCEPS_COUNT = 'app/ArchexcepsListPage/LOAD_ARCHEXCEPS_COUNT';
export const LOAD_ARCHEXCEPS_COUNT_ERROR = 'app/ArchexcepsListPage/LOAD_ARCHEXCEPS_COUNT_ERROR';
export const LOAD_ARCHEXCEPS_COUNT_SUCCESS = 'app/ArchexcepsListPage/LOAD_ARCHEXCEPS_COUNT_SUCCESS';
export const SET_SEARCHPROPS = 'app/ArchexcepsListPage/SET_SEARCHPROPS';
export const SET_SORTPROPS = 'app/ArchexcepsListPage/SET_SORTPROPS';
export const SET_FILTERID = 'app/ArchexcepsListPage/SET_FILTERID';
export const SET_ADVANCED_FILTERS = 'app/ArchexcepsListPage/SET_ADVANCED_FILTERS';
export const SET_FILTERPROPS = 'app/ArchexcepsListPage/SET_FILTERPROPS';
export const SET_PAGEPROPS = 'app/ArchexcepsListPage/SET_PAGEPROPS';
export const SET_PROPERTIESPROPS = 'app/ArchexcepsListPage/SET_PROPERTIESPROPS';
export const SET_ARCHEXCEP_COLUMN_DEF = 'app/ArchexcepsListPage/SET_ARCHEXCEP_COLUMN_DEF';
export const LOAD_HEADER = 'app/LOAD_HEADER';
export const GET_ARCHEXCEP_COLUMN_DEF = 'app/ArchexcepsListPage/GET_ARCHEXCEP_COLUMN_DEF';

export const ARCHEXCEP_COLUMN_HEADER_ACCESSOR = "TLLAB";
export const ARCHEXCEP_COLUMN_VALUE_ACCESSOR = "FDFNAM";
export const ARCHEXCEP_COLUMN_POSITION = "FLDPOS";
export const ARCHEXCEP_COLUMN_SHOW_HIDE_FLAG = "FLDSHW"
export const ARCHEXCEP_COLUMN_HEADER_PREFIX_FLAG = "FDPRFX";

export const ARCHEXCEP_PROPERTIES = {
    "headerName": COLUMN_HEADER_ACCESSOR,
    "field": COLUMN_VALUE_ACCESSOR,
    "showHideFlag": COLUMN_SHOW_HIDE_FLAG,
    "columnPosition": COLUMN_POSITION,
    "prefixFlag": COLUMN_HEADER_PREFIX_FLAG
}

export const PAGE_SIZES = [10, 20, 30];

export const ARCHEXCEP_LIST_PAGE = "archexcepsListPage";

export const SET_ARCHEXCEP_GLOBAL_FILTER_PROPS = "SET_ARCHEXCEP_GLOBAL_FILTER_PROPS";

export const INITIAL_PAGE_PROPS = {
    actualPage: 0,
    currentPage: 0,
    totalCount: 10,
    actualPageSize: 10,
    pageSize: 100,
    isPageSizeChanged: false,
    isForwardDirection: true
}

export const HAS_PAGINATION = true;
export const addFilter = (accessor, operator, fieldValue, prefixFlag=0) => ({ "accessor": accessor, "operator": operator || "=", "fieldValue": fieldValue, "prefixFlag": prefixFlag})

export const prepareFilterForArchexcepMembers = archexcep => {
    let filter = [];

        filter.push(addFilter('COMP', '=', archexcep.ECOMP));

    return filter;
}
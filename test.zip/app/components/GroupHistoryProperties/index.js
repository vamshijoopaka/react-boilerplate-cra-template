/**
 *
 * GroupHistoryProperties
 *
 */
/* Change Log
 * LogStart --  E3C-32847 - Vamshi J- 08-08-2021 - 2022.1.0.0 Unified Product
 *              Story: E3C-33056 --Group History Properties related Jira.
                Implemented Radio Buttons, Table, Graph, PageUp/Down functionalities.
 * LogStart --  E3C-33049 - Sravanthi D- 31-08-2021 - 2022.1.0.0 Unified Product
 *              Story: E3C-33049 --Group History Properties related Jira.
                Implemented Show me.
*/
import React, { memo } from 'react';
import { makeStyles, Box, FormControlLabel } from '@material-ui/core';
// import PropTypes from 'prop-types';
// import styled from 'styled-components';
import Header from './Header';
import CustomTable from './Table';
import GroupHistoryGraph from './GroupHistoryGraph';
import GroupHistoryTable from './GroupHistoryTable';
import BoxBorder from '../../containers/common/BoxBorder';
import { FieldInput } from '../common/Form';
import { RADIO_OPTIONS } from './constants';
import FormFieldsGenerator from '../common/FormFieldsGenerator';
import Spinner from '../common/Spinner';
import AssignItems from './AssignItems';
const useStyles = makeStyles(theme => ({
  contentWrapper: {
    padding: '1rem',
    borderRadius: '4px',
    overflow: 'hidden',
    boxShadow: '0 2px 4px var(--secondary-s10)',
    background: 'var(--background-content)'
  },
  tablesWrapper: {
    display: 'flex',
    flexWrap: 'wrap',
  },
  radioWrapper: {
    padding: '0.5rem 1rem',
    '& label.MuiFormControlLabel-root:first-child': {
      marginRight: '1rem',
    },
  },
  boxMarin: {
    margin: '1rem 0',
  }
}));
function GroupHistoryProperties(props) {
  const classes = useStyles();
  const [isOpenAssignItems, setIsOpenAssignItems] = React.useState(false);
  const {
    labelsArray,
    currentRecordData,
    graphData,
    tableData,
    simInProgress = false,
    radioSelected = 'show13',
    moreRecordsAvailable,
    direction,
    detailListIndex,
    loading,
    detailList,
    listLoading,
    currentDetailRecord,
  } = props.groupHistoryPropertiesPage;
  let masterLoader = !labelsArray.length || loading || listLoading;
  const formFieldProps = {
    labelDisplayCharacters: 18,
    valueDisplayCharacters: 12,
    currentPage: "grouphistory",
    valuesArray: props.formData,
    noMassMaintenance: true,
    canUpdateComponent: { update: false },
  }
  return <div>
    <Spinner loading={masterLoader} type="groupHistoryComponent" />
    <Header
      simInProgress={simInProgress}
      setSimInProgress={props.setSimInProgress}
      currentRecordData={currentRecordData || {}}
      getLabelFromId={props.getLabelFromId}
      isFreezeHeader={!!+props.isFreezeHeader}
      detailKeyRecord={props.detailKeyRecord}
      moreRecordsAvailable={moreRecordsAvailable}
      direction={direction}
      handleArrowClick={props.handleArrowClick}
      detailListIndex={detailListIndex}
      detailList={detailList}
      disableNext={props.disableNext}
      disablePrevious={props.disablePrevious}
      setIsOpenAssignItems={setIsOpenAssignItems}
      acceptProfile={props.acceptProfile}
      currentDetailRecord={currentDetailRecord}
      selectedValue={props.selectedValue}
      removeChildCutdownTab={props.removeChildCutdownTab}
      setSelectedValueForTabs={props.setSelectedValueForTabs}
      breadCrumbList={props.breadCrumbList}
      activeTabId={props.activeTabId}
      activeTabData={props.activeTabData}
      activeBreadcrumbId={props.activeBreadcrumbId}
      authorizedComponentsList={props.authorizedComponentsList}
      tabs={props.tabs}
      setIsShowContextMenu={props.setIsShowContextMenu}
      history={props.history}
      addItem={props.addItem}
      canUpdateComponent={props.canUpdateComponent}
    />
    <div className={classes.contentWrapper}>
      <Box className={classes.tablesWrapper}>
        <Box flex="1">
          <CustomTable
            title={props.getLabelFromId("52555")}//"Summarization Criteria"
            rowData={props.summarizationRowData}
          />
        </Box>
        <Box flex="1">
          <CustomTable
            title={props.getLabelFromId("52675")}//"Filter Criteria"
            rowData={props.criteriaRowData}
          />
        </Box>
      </Box>
      <Box display="flex">
        <Box flexBasis="66.66%">
          <Box margin="1.5rem 0.5rem 0.5rem 0.5rem">
            <GroupHistoryGraph
              simInProgress={simInProgress}
              radioSelected={radioSelected}
              graphData={graphData}
              title={props.getLabelFromId("52583")}
              handleInputChange={props.handleInputChange}
            />
          </Box>
        </Box>
        <Box flexBasis="33.34%" padding="0.5rem 1rem">
          <div className={classes.boxMarin}>
            <BoxBorder
              title={props.getLabelFromId("50894")}//"Manual Controls"
            >
              <Box className={classes.radioWrapper}>
                <FormControlLabel
                  control={<FieldInput
                    formatMessage={true}
                    options={RADIO_OPTIONS}
                    value={radioSelected}
                    field={{ key: 'items', type: 'radio', options: RADIO_OPTIONS.map(ele => ({ ...ele, disabled: false })) }}
                    onChange={props.setRadioSelected}
                    isHorizontal={true}
                  // disabled={disableRadio}
                  />}
                  labelPlacement={'end'}
                />
              </Box>
            </BoxBorder>
          </div>
          <div className={classes.boxMarin}>
            <BoxBorder
              title={props.getLabelFromId("52581")}//"Profile Control"
            >
              {
                !!labelsArray?.length && !!labelsArray[0]?.cardfields?.length &&
                <FormFieldsGenerator
                  {...formFieldProps}
                  fieldsArray={labelsArray[0].cardfields.filter(ele => ele.FLDID === '3332')}
                />
              }
            </BoxBorder>
          </div>
          <div className={classes.boxMarin}>
            <BoxBorder
              title={props.getLabelFromId("50888")}//"Demand Forecasat"
            >
              {
                !!labelsArray?.length && !!labelsArray[0]?.cardfields?.length &&
                <FormFieldsGenerator
                  {...formFieldProps}
                  fieldsArray={labelsArray[0].cardfields.filter(ele => ele.FLDID !== '3332')}
                />
              }
            </BoxBorder>
          </div>
        </Box>
      </Box>
      <Box margin="0.5rem" /* width="145vh" */ overflow="auto">
        <GroupHistoryTable
          rowData={tableData}
          simInProgress={simInProgress}
          periodLabel={props.getLabelFromId("50791")}
          globalNumberFormat={props.globalNumberFormat}
          globalNumberSeparator={props.globalNumberSeparator}
          globalDecimalSeparator={props.globalDecimalSeparator}
          handleInputChange={props.handleInputChange}
          errorMessageLabels={props.errorMessageLabels}
          demandLabel={props.getLabelFromId("33758")}
        />
      </Box>
    </div>
    {
      isOpenAssignItems ?
        <AssignItems
          assignItemsLabelsArray={props.groupHistoryPropertiesPage.assignItemsLabelsArray}
          currentRecordData={currentRecordData}
          currentDetailRecord={currentDetailRecord}
          setIsOpenAssignItems={setIsOpenAssignItems}
          getLabelFromId={props.getLabelFromId}
          assignItems={props.assignItems}
          companyDetails={props.companyDetails}
          assignItemSuccess={props.groupHistoryPropertiesPage.assignItemSuccess}
          setStoreKeyValue={props.setStoreKeyValue}
        />
        : null
    }
  </div>;
}

GroupHistoryProperties.propTypes = {};

export default memo(GroupHistoryProperties);

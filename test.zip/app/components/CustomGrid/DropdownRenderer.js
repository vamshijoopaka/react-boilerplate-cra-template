import React from 'react';
import Form from 'components/common/Form/Form';
import FieldInput from 'components/common/Form/FieldInput';
import theme from '../../jda-gcp-theme';
import { withStyles } from '@material-ui/core';

const styles = theme => ({
    selectClass: {
        width: '100% !important',
        '& [class*="MuiSelect-select"]': {
            display: 'inline-block'
        }
    }
})

class DropdownRenderer extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            inputValue: null
        }
        this.setOnChangeValue = this.setOnChangeValue.bind(this);
    }

    setOnChangeValue(dataValue){
        this.setState({
            inputValue: dataValue
        }, () => {
            const { rowIndex, column, colDef, agGridReact, data } = this.props;
            let dataRender = !colDef.prefixFlag ? agGridReact.props.listPredecessor +  colDef['FDFNAM'].trim() : colDef['FDFNAM'].trim();
            let updatedData = data;
            if(data[dataRender] != this.state.inputValue){
                updatedData[dataRender] = this.state.inputValue;
                agGridReact.props.onValueChanged(dataValue, rowIndex, column.colId, 'dropdown', updatedData, colDef, dataRender, this.state.inputValue);
            }
        })
    }

    componentDidMount() {
        let { value, data, colDef, agGridReact } = this.props;
        if(value){
            let dataRender = !colDef.prefixFlag ? agGridReact.props.listPredecessor +  colDef['FDFNAM'].trim() : colDef['FDFNAM'].trim();
            this.setState({
                inputValue: data[dataRender]
            })
        }
    }

    render() {
        return (
            <div width='100%'>
                <Form>
                    {form => (
                        <FieldInput
                            value={this.state.inputValue}
                            field={{
                                type: 'select',
                                options: this.props.colDef.valueSuggestionList,
                            }}
                            disabled={this.props.colDef.disabled}
                            onKeyDown={() => { }}
                            className={this.props.classes.selectClass}
                            onChange={(key, val) => {
                                this.setOnChangeValue(val);
                            }}
                        />
                    )}
                </Form>
            </div>
        );
    }
}


export default withStyles(styles)(DropdownRenderer);
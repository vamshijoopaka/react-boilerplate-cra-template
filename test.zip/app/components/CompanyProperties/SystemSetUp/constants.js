/** Change Log
 * LogStart --  E3C-33195 - Kumar A- 16 September,2021 - 2022.1.0.0 Unified Product
 *              Story: E3C-33195 --Code Cleanup
*/
export const COMPANY_TECHNICAL_FACTORS = '29004';
export const COMPANY_CALENDAR_FACTORS = '50381';
export const COMPANY_MULTITIER_FACTORS = '53226';
export const COMPANY_FUNCTION_CONTROL_FACTORS = '50375';
export const COMPANY_DELIMITTERS = '50396';
export const COMPANY_UPDATE_SWITCHES = '50397';
export const COMPANY_ORDER_FLAGS = '50386';

export const SYSTEM_SETUP_GET_FIELD_LIST = 'SYSTEM_SETUP_GET_FIELD_LIST';
export const SYSTEM_SETUP_GET_FIELD_LIST_SUCCESS = 'SYSTEM_SETUP_GET_FIELD_LIST_SUCCESS';
export const SYSTEM_SETUP_GET_FIELD_LIST_FAILURE = 'SYSTEM_SETUP_GET_FIELD_LIST_FAILURE';

export const SYSTEM_SETUP = 'systemSetupFactors';
export const COMPANY_DATA_RESERVED = "VRSRVD";

export const CUSTOM_CARD_ONE = "4434";
export const CUSTOM_CARD_TWO = "4501";
export const CUSTOM_CARD_THREE = "3331";
export const CUSTOM_CARD_FOUR = "4452";
export const LABEL_COMPANY_CAH="27037";

export const CUSTOM_CARD_KEY = "50916";

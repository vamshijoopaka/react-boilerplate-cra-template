/**
 *
 * EventitemProperties
 *
 */

import React, { Component } from 'react'
import { withStyles, Button, Box } from '@material-ui/core';
import KeyboardArrowDownIcon from '@material-ui/icons/KeyboardArrowDown';
import Typography from '@material-ui/core/Typography';
import KeyboardArrowUpIcon from '@material-ui/icons/KeyboardArrowUp';
import SaveIcon from '@material-ui/icons/Save';
import MoreVertIcon from '@material-ui/icons/MoreVert';
import FilterIcon from "../../images/icon_filter.png";
import { isEqual } from 'lodash';
import FormattedMessageComponent from '../common/FormattedMessageComponent';
import AppBar from '@material-ui/core/AppBar';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import moment from 'moment';
import Spinner from 'components/Common/Spinner';
import ContextMenu from '../common/ContextMenu';
import ContextMenuCreateNew from '../common/ContextMenuCreateNew';
import ConfirmationDialog from 'components/common/ConfirmationDialog';
import BreadcrumbContextMenu from 'components/common/BreadcrumbContextMenu';

import Filter from 'containers/common/Filter';
import GridErrorMessages from 'components/common/GridErrorMessages';

import DetailDialog from "./PlanDialog";

import EventitemDefaults from 'containers/common/EventitemDefaults';



import EventItemDetailsEffects from 'containers/common/EventItemDetailsEffects';
import EventItemDetailsTab from 'containers/common/EventItemDetailsTab';

import {
	EVENTITEMS_PROPERTIES_PAGE,
	GLOBAL_FILTER_OPTIONS,
	COLUMN_VALUE_ACCESSOR,
	INITIAL_PAGE_PROPS,
	EVENTITEMS_LIST_PAGE,
	TEXT_OK, TEXT_ALERT, TEXT_CANCEL,
	ITEMS_LIST_PAGE, VENDORS_LIST_PAGE
} from '../common/constants';

import {
	getListPredecessor,
	prepareValueDataForEvents,
	getFilterDataFromLocalStorage,
	getFilterDataFromCriteriaDetails,
	getDateFormatValue,
	getItemDetailsBodyEvents,
	getEventItemDetailBody,
	getUpdateRestrictionOnComponent,
	capitalizeFirstLetter,
	getDateFromJulian
} from 'utils/util';
import { getDateFormatted } from 'components/common/Form/dateTimeUtils';


import { getDBSelectorFilterValues, prepareTooltipValues } from 'utils/filterData';
import { onChangeContextMenu, updateBreadCrumbContextMenu } from 'utils/contextMenu';
import {
	HeaderAPIValuesJSON,
	LABEL_EVENTITEM_DETAIL,
	LABEL_EVENTITEM_EFFECTS,
	LABEL_COMPANY_ID,
	CONTEXT_MENU_EVENTITEM_ACTIONS,
	LABEL_DELETE,
	LABEL_LIST_URL_DATA,
	DEFAULT_VALUE_URL_DATA,
	LABEL_VENDOR_ID,
	LABEL_SUB_VENDOR_ID,
	LABEL_VENDOR_NAME,
	LABEL_WAREHOUSE_NAME,
	LABEL_WAREHOUSE_ID,
	LABEL_ITEM_ID,
	LABEL_ITEM_NAME,
	LABEL_DATES,
	LABEL_WEEKS,
	LABEL_EVENT_ID,
	LABEL_EVENT_NAME,
	CONTEXT_MENU_ACTIONS,
	LABEL_ACTIONS,

} from "./constants";

import { EVENT_DETAILS_TABS, EVENT_ITEM_LIST_FILTERS } from './constants';
import CustomizedTooltip from '../common/CustomizedTooltip';//E3C-32891, J Vamshi

const style = theme => ({
	propertiesContentWrapper: {
		margin: '10px auto',
		borderRadius: '4px',
		overflow: 'hidden',
		boxShadow: '0 2px 4px var(--secondary-s10)',
		overflowX: 'auto'
	},
	propertiesHeaderContainer: {
		width: '100%',
		marginBottom: '1.5rem',
		backgroundColor: 'var(--background-app)',
		borderRadius: '4px',
		borderTopLeftRadius: '0px',
		borderTopRightRadius: '0px',
		overflow: 'hidden',
		boxShadow: '0 4px 4px var(--secondary-s10)',
		overflowX: 'auto'
	},
	vendorContainer: {
		display: 'flex',
		width: '100%',
		backgroundColor: 'var(--background-content)',
		fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
		alignItems: 'center',
		padding: '0 0 0 24px',
		position: 'relative',
		minWidth: '630px'
	},
	vendorDetailsWrapper: {
		width: '100%',
		display: 'flex',
	},
	vendorDetailWarehouse: {
	},
	pageContainer: {
		display: 'flex',
		backgroundColor: 'var(--background-app)',
		borderTop: 'none',
		padding: '10px 10px',
	},
	vendorNameLabel: {
		paddingBottom: '0'
	},
	card: {
		padding: '0px',
		backgroundColor: 'var(--background-content)',
		borderRadius: '4px',
		width: '100%',
		margin: '10px',
		'& .MuiCardHeader-root': {
			padding: '22px 20px 0 20px'
		},
		'& .MuiCardContent-root': {
			padding: '16px 15px 10px 15px'
		}
	},
	marginLeftZero: {
		marginLeft: '0',
	},
	vendorName: {
		paddingTop: '8px'
	},
	vendorArrow: {
		padding: '0 !important',
		margin: '0',
		minWidth: '16px',
		background: 'none',
		height: '16px',
		width: '16px',
	},
	vendorArrowWrapper: {
		display: 'flex',
		flexDirection: 'column',
		border: '1px solid var(--primary-default)',
		borderRadius: '4px',
		justifyContent: 'center',
		alignItems: 'baseline',
		height: '38px',
		marginTop: '24px',
		padding: '2px',

	},
	vendorDetailRow: {
		width: '100%',
		display: 'flex',
		flexWrap: 'wrap',
		padding: '0px 0 24px 0',
		paddingLeft: '15px'
	},
	vendorDetail: {
		padding: '0px 0px 0 0px',
		lineHeight: '1.1',
	},
	vendorIDBlock: {
		display: 'flex',
	},
	vendorIdDetails: {
		width: '15ch',
		padding: '0 30px 0 0px',
		lineHeight: '1.1'
	},
	vendorLabel: {
		color: 'var(--header-label-color)',
		paddingBottom: '6px',
		width: '12ch',
		whiteSpace: 'nowrap',//E3C-32891, J Vamshi
	},
	vendorSubVendorDetails: {
		display: 'flex',
		flexDirection: 'column',
		width: '16ch',
		padding: '0 30px 0 0px',
		lineHeight: '1.1'
	},
	nameField: {
		// paddingBottom: '32px'
	},
	vendorValue: {
		color: 'var(--value)',
		paddingBottom: '24px'
	},
	paddingRight: {
		paddingRight: '1rem'
	},
	IdNameBlock: {
		paddingTop: '24px',
		// whiteSpace: 'break-spaces'
	},
	IdNameBlockItem: {
		width: '12%',
		paddingTop: '24px',
		whiteSpace: 'break-spaces'
	},
	poAlign: {
		alignSelf: 'flex-end',
		paddingBottom: '17px'
	},
	vendorIDBlock: {
		display: 'flex',
	},
	vendorActions: {
		top: '24px',
		padding: '0px 0px 20px 20px',
		right: '16px',
		display: 'flex',
		position: 'absolute',
		alignItems: 'center',
		justifyContent: 'space-between',
		'@media (max-width: 1220px)': {
			flexWrap: 'wrap',
			width: '250px'
		}
	},
	buttonActions: {
		display: 'flex',
		alignItems: 'center',
		'@media (max-width: 1220px)': {
			marginBottom: '20px'
		},
		'& .MuiButton-root': {
			borderRadius: '4px',
			fontSize: '14px',
			width: '120px',
			lineHeight: '14px',
		},
		'& .MuiButton-sizeLarge': {
			fontSize: '18px',
		},
		'& .MuiButton-sizeSmall': {
			fontSize: '12px',
			padding: '8px 16px',
		},
	},
	vendorActionsFilter: {
		minWidth: '37px',
		border: '1px solid var(--primary-default)',
		height: '32px',
		marginLeft: '15px',
		'@media (max-width: 1220px)': {
			marginLeft: '0px'
		},
		'& img': {
			width: '14px',
			height: '14px'
		},
		'& svg': {
			width: '18px',
			height: '18px'
		}
	},
	menuButton: {
		minWidth: '37px',
		border: '1px solid var(--primary-default)',
		height: '32px',
		marginLeft: '15px',
		borderRadius: '4px',
		display: 'flex',
		alignItems: 'center',
		justifyContent: 'center',
		'@media (max-width: 1220px)': {
			marginLeft: '0px'
		},
	},
	adjustCardFieldsInline: {
		display: 'grid !important',
		width: '100%',
		gridTemplateColumns: 'auto auto',
		paddingRight: '22px'
	},

	label: {
		color: 'var(--header-label-color)',
		paddingBottom: '6px',
		width: '20ch',
	},
	detail: {
		padding: '0px 0px 0px 0px',
		lineHeight: '1.1',
	},

	dateWrapper: {
		display: 'flex',
		flexDirection: 'column',
		alignSelf: 'center'
	},
	highLightColor: {
		color: 'var(--label)',
		paddingRight: '10px',
		width: '150px'
	},
	childBlock: {
		margin: '5px'
	},
	headerWrapper: {
		paddingBottom: '8px',
		borderBottom: '1px solid var(--divider-line)',
	},
	contentWrapper: {
		minWidth: '750px'
	},
	gridErrorWrapper: {
		position: "fixed",
		top: "10px",
		left: "0px",
		right: "0px",
		zIndex: 1300,
	},
	detail: {
		padding: '0px 0px 0px 0px',
		lineHeight: '1.1',
	},
	buttonActionsSecondChild: {
		marginRight: '15px',
		'& .MuiButton-outlinedPrimary': {
			width: '100px',
			height: '28px'
		}
	},

	itemName: {
		width: '9rem',
	},
	//E3C-32891, J Vamshi
	ellipsis: {
        whiteSpace: 'nowrap',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        // maxWidth: '95%',
	},
	eventName: {
		width: '5rem',
	}
});


function TabContainer(props) {
	return (
		<Typography className={'minWidth1100'} component="div">
			{props.children}
		</Typography>
	);
}

class EventitemProperties extends Component {
	constructor(props) {
		super(props);
		this.state = {
			tab: 0,
			isSaveDataDisabled: true,
			headerData: false,
			columnDefs: [],
			stateData: false,
			totalCount: 0,
			fromPage: false,
			hasError: false,
			errorId: false,
			canUpdateComponent: false,
			changeDataAPI: false,
			openFilterPopup: false,
			previousFilterValues: false,
			showConfirmationDialog: false,
			dialogTitle: '',
			hasWarning: false,
			fromListPage: null,
			hasFiltersChanged: false,
			isDataLoaded: false,
			isInitialAPICall: true,
			valueDataFailureMessages: [],
			headerValues: HeaderAPIValuesJSON[0],
			saveDisabled: false,
			isOpenActionsContextMenu: false,
			menuRef: null,
			contextMenuList: [...CONTEXT_MENU_EVENTITEM_ACTIONS],
			isFiltersChanged: false,
			dialogBody: false,
			actionList: CONTEXT_MENU_ACTIONS,
			isOpenActions: false,
			actionMenuRef: null,
			openPlanDialog: false,
			replaceValues: [],
			propertyValues: {},
			hasReassigedChanged: JSON.parse(JSON.stringify(HeaderAPIValuesJSON[0]))

		};
		this.prepareHeaderDataJSON = this.prepareHeaderDataJSON.bind(this);
		this.handleEventitemHeaderRightArrowClick = this.handleEventitemHeaderRightArrowClick.bind(this);
		this.handleEventitemHeaderLeftArrowClick = this.handleEventitemHeaderLeftArrowClick.bind(this);
		this.getApiObj = this.getApiObj.bind(this);
		this.makeAPICallForPageUpDown = this.makeAPICallForPageUpDown.bind(this);
		this.getApiObjForPageUpDown = this.getApiObjForPageUpDown.bind(this);
		this.getLabelValue = this.getLabelValue.bind(this);
		this.setRecordDataValues = this.setRecordDataValues.bind(this);
		this.forceUpdateHandler = this.forceUpdateHandler.bind(this);
		this.setFilterValuesFromState = this.setFilterValuesFromState.bind(this);
		this.handleEventitemHeaderFilterClick = this.handleEventitemHeaderFilterClick.bind(this);
		this.handleEventitemHeaderSaveClick = this.handleEventitemHeaderSaveClick.bind(this);
		this.onContextMenuChange = this.onContextMenuChange.bind(this);
		this.sendAPICallForValues = this.sendAPICallForValues.bind(this);
		this.handleNoDataSets = this.handleNoDataSets.bind(this);
		this.handleValueDataErrorMessages = this.handleValueDataErrorMessages.bind(this);
		this.setIsOpenActionsContextMenu = this.setIsOpenActionsContextMenu.bind(this);
		this.handleEventitemHeaderActionItemSelection = this.handleEventitemHeaderActionItemSelection.bind(this);
	}
	componentDidCatch() {
		this.setState({ hasHardError: true });
	}
	handleNoDataSets() {
		const { eventitemDetailsLabelsData } = this.props.eventitemsProperties;
		if (this.state.isDataLoaded) {
			if ((eventitemDetailsLabelsData && Object.keys(eventitemDetailsLabelsData) && Object.keys(eventitemDetailsLabelsData).length)) {
				// do nothing here
			} else {
				this.closeCurrentTab();
			}
		}
	}

	handleChangeTab = (value) => {
		this.setState({ tab: value });
		this.props.setDataInTabs("selectedPropertiesTab", value);//Ajit Saving previously visitedtab
	};


	handleEventitemHeaderFilterClick() {
		if (this.state.isFiltersChanged && this.props.eventitemsProperties.isValueDataAPIFailure) {
			this.props.onSetFilterProps(this.state.previousFilterValues);
			this.props.setGlobalFilterProps(this.state.previousFilterValues);
			this.props.setChildTabFilterProps(this.state.previousFilterValues);
			this.setState({ isFiltersChanged: false });
			this.props.setValueDataAPIFailureFlag(false);
		}
		this.setState({ openFilterPopup: !this.state.openFilterPopup });
	}

	getLabelValue(id) {
		return <FormattedMessageComponent id={id} />;
	}

	setFilterValuesFromState(values) {
		const filterValues = [];
		const { columnDefs } = this.state;
		if ((columnDefs && columnDefs.length) || (this.columnDefData && this.columnDefData.length)) {
			const colData = columnDefs && columnDefs.length ? columnDefs : this.columnDefData;
			values.forEach(value => {
				const isExists = colData.find(
					column => column[COLUMN_VALUE_ACCESSOR].trim() == value.accessor,
				);
				if (isExists) {
					filterValues.push(value);
				}
			});
			if (filterValues && filterValues.length) {
				this.props.onSetFilterProps(filterValues);
				this.props.setGlobalFilterProps(filterValues);
				return filterValues;
			}
		} else {
			this.props.onSetFilterProps(values);
			this.props.setGlobalFilterProps(values);
			return values;
		}
	}

	getApiObj(recordData, record, currentPage, pageProps) {
		let recordObj = false;
		if (record) {
			recordObj = record;
		}
		const apiObj = {
			recordData,
			pageProps,
			direction: pageProps.isForwardDirection,
			record: recordObj,
			currentPage,
			parentPage: EVENTITEMS_LIST_PAGE,
		};
		return apiObj;
	}
	getApiFilterObj(filterProps, currentPage, pageProps) {

		let apiObj = {
			filterProps,
			pageProps: pageProps,
			direction: pageProps.isForwardDirection,
			currentPage: currentPage,
			parentPage: ORDER_LIST
		};
		return apiObj;
	}
	prepareHeaderDataJSON(obj) {
		const headerValues = this.state.headerValues;
		const prefix = getListPredecessor(EVENTITEMS_LIST_PAGE);

		let key = `${prefix}VNDR`;
		let value = obj[key];
		headerValues.EIVNDR = value ? value.trim() : value;

		key = `${prefix}SUBV`;
		value = obj[key];
		headerValues.EISUBV = value ? value.trim() : value;

		key = `${prefix}WHSE`;
		value = obj[key];
		headerValues.EIWHSE = value ? value.trim() : value;

		key = `${prefix}ITEM`;
		value = obj[key];
		headerValues.EIITEM = value ? value.trim() : value;

		key = `${prefix}INAM`;
		value = obj[key];
		headerValues.EIINAM = value ? value.trim() : value;

		key = `${prefix}EVNT`;
		value = obj[key];
		headerValues.EIEVNT = value ? value.trim() : value;

		key = `${prefix}RDES`;
		value = obj[key];
		headerValues.EIRDES = value ? value.trim() : value;

		key = `${prefix}BGDT`;
		value = obj[key];
		// value = Number(value) ? getDateFormatValue(value) : '';
		headerValues.EIBGDT = value ? value.trim() : value;

		key = `${prefix}ENDT`;
		value = obj[key];
		// value = Number(value) ? getDateFormatValue(value) : '';
		headerValues.EIENDT = value ? value.trim() : value;

		key = `${prefix}BGPD`;
		value = obj[key];
		headerValues.EIBGPD = value ? value.trim() : value;

		key = `${prefix}ENPD`;
		value = obj[key];
		headerValues.EIENPD = value ? value.trim() : value;

		key = `${prefix}COMP`;
		value = obj[key];
		headerValues.EICOMP = value ? value.trim() : value;

		this.setState({ headerValues: headerValues })
		return [headerValues];
	}

	forceUpdateHandler() {
		this.forceUpdate();
	}
	makePrevNextAPICall = flag => {
		const { filterProps, valueData } = this.props.eventitemsProperties;
		const data = JSON.parse(JSON.stringify(INITIAL_PAGE_PROPS));
		data.isForwardDirection = flag;
		data.pageSize = 3;
		this.props.getPageUpDownFlagAPI(
			this.getApiObjForPageUpDownFlags(filterProps, valueData, EVENTITEMS_LIST_PAGE, data, false, flag)
		);
	};

	prepareTooltipData = () => {
		const { detailCallData, eventitemColumnDefs } = this.props.eventitemsProperties;
		let tooltipData = prepareTooltipValues(EVENTITEMS_LIST_PAGE, detailCallData, eventitemColumnDefs, 'eventitemsproperties');
		this.props.setDataInTabs("toolTipData", JSON.parse(JSON.stringify(tooltipData)));
	}

	setHeaderAndSendAPI(jsonData, from) {
		let data = this.prepareHeaderDataJSON(jsonData);
		this.setState({ headerData: data });
		this.setState({ stateData: jsonData });
		let valueData = prepareValueDataForEvents(DEFAULT_VALUE_URL_DATA, jsonData, from);
		let body = getItemDetailsBodyEvents(jsonData, getListPredecessor('eventItems'), getListPredecessor('EventItemDetails'));
		this.props.getEventItemDetails({ body });
		this.setState({ isSaveDataDisabled: true });
		this.sendAPICallForValues(valueData, jsonData);
	}

	sendAPICallForValues(valueData, jsonData) {
		let page = { pageSize: 3 };
		this.props.getValueList(valueData, page, true, {});
		let filterProps = valueData.filter?.(row => ['COMP', 'EVNT'].includes(row.accessor));
		this.props.getEventHeaderList({ filterProps, valueData, pageProps: { pageSize: 3 }, currentPage: 'events', direction: true });
		this.checkForExistenceOfVendorItemWarehouse(jsonData)
	}

	handleValueDataErrorMessages(content) {
		this.setState({ showValueConfirmationDialog: true });
		this.setState({ dialogTitle: TEXT_ALERT });
		this.setState({ dialogContent: content });
	}

	closeValueDialog = () => {
		this.setState({ showValueConfirmationDialog: false });
		if (this.state.valueDataFailureMessages && this.state.valueDataFailureMessages.length) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.shift();
			this.setState({ valueDataFailureMessages: values });
		}
	}

	setRecordDataValues() {
		let isRecordValuesExists = false, isLocalStorageValuesExists = false, isFilterValuesExists = false;
		const { history } = this.props;
		var paramsString = window.location.search;
		if (paramsString && paramsString.length) {
			let paramsArray = paramsString.split("?");
			if (paramsArray && paramsArray.length && paramsArray.length > 1) {
				let params = paramsArray[1].split("&");
				let tabId = params[0].split("=")[1];
				let breadCrumbId = params[1].split("=")[1];
				let localStorageValues = getFilterDataFromLocalStorage(tabId, breadCrumbId);
				if (localStorageValues && Object.keys(localStorageValues) && Object.keys(localStorageValues).length) {
					isLocalStorageValuesExists = true;
					let itemData = localStorageValues.item_data, dbSelectorValues = [];
					if (itemData && itemData.recordData && localStorageValues.childType) {
						this.columnDefData = JSON.parse(JSON.stringify(itemData.recordData.columnDefs))
						this.setState({ columnDefs: itemData.recordData.columnDefs });
						this.props.setCurrentRecord(itemData.recordData.data);
						this.setState({ totalCount: itemData.recordData.totalCount });
						this.setState({ fromPage: itemData.recordData.fromPage });
						this.setState({ fromListPage: itemData.recordData.fromPage });
						this.props.setRowIndex(itemData.recordData.rowIndex);
						this.setHeaderAndSendAPI(itemData.recordData.data, itemData.recordData.fromPage);
						isRecordValuesExists = true;
						this.props.setSelectedRecord(false, false);
						if (itemData) {
							if (itemData.dbSelector && itemData.dbSelector.length) {
								dbSelectorValues = JSON.parse(JSON.stringify(itemData.dbSelector));
							}
							if (itemData.filterProps && itemData.filterProps.length) {
								this.setState({ hasFiltersChanged: false });
								isFilterValuesExists = true;
								let values = getDBSelectorFilterValues(dbSelectorValues, itemData.filterProps);
								this.setFilterValuesFromState(values);
							} else if (dbSelectorValues && dbSelectorValues.length) {
								this.setState({ hasFiltersChanged: false });
								isFilterValuesExists = true;
								let dbValues = getDBSelectorFilterValues(dbSelectorValues, []);
								this.setFilterValuesFromState(dbValues);
							}
							if (itemData.defaultFilterInfo && Object.keys(itemData.defaultFilterInfo) && Object.keys(itemData.defaultFilterInfo).length) {
								this.props.setDefaultFilterpropsForTabs(itemData.defaultFilterInfo);
							}
							if (itemData.selectedPropertiesTab) {
								this.setState({ tab: itemData.selectedPropertiesTab });//Ajit Saving previously visitedtab
							}
						}
					}

				}
				if (!isLocalStorageValuesExists && tabId && breadCrumbId) {
					history.push({ pathname: '/Dashboard' });
				}
			}
		}

		let filterOptions = GLOBAL_FILTER_OPTIONS;
		const { dbSelector } = this.props;
		if (!isFilterValuesExists) {
			let gbValues = getDBSelectorFilterValues(dbSelector, filterOptions);
			this.setFilterValuesFromState(gbValues);
		}
		return isRecordValuesExists;
	}

	resetValues = () => {
		this.props.setInitialState();
		this.props.setValueDataFlag(false);
		this.props.setCurrentRecord(null);
		this.props.getEventitemsColumnDefs({ type: EVENTITEMS_LIST_PAGE });
		this.setState(({ canUpdateComponentSecurity }) => ({ canUpdateComponent: canUpdateComponentSecurity }));
	};

	componentDidMount() {
		this.resetValues();
		let currentPage = EVENTITEMS_PROPERTIES_PAGE;
		this.props.onLoadCurrentPage(currentPage);
		this.props.setCurrentPage(currentPage);
		const { detailCallData } = this.props.eventitemsProperties;
		this.props.setIsShowContextMenu(true);
		let isFound = this.setRecordDataValues();

		if (!isFound) {
			if (this.props.location && this.props.location.state) {
				this.props.setCurrentRecord(this.props.location.state.data);
				this.setState({ columnDefs: this.props.location.state.columnDefs });
				this.setState({ fromPage: this.props.location.state.fromPage });
				this.props.setRowIndex(this.props.location.state.rowIndex);
				this.setHeaderAndSendAPI(this.props.location.state.data, EVENTITEMS_LIST_PAGE);
			}
		}

		if (Object.keys(this.state.headerValues).length !== 0) {
			let body = getItemDetailsBodyEvents(this.state.headerValues, getListPredecessor('eventItems'), getListPredecessor('EventItemDetails'));
			this.props.getEventItemDetails({ body });
		}


		if (detailCallData && Object.keys(detailCallData) && Object.keys(detailCallData).length) {
			this.setState({ headerData: this.prepareHeaderDataJSON(detailCallData) });
			this.props.setSelectedRecord(detailCallData, EVENTITEMS_LIST_PAGE);
		}
		let labelFilters = LABEL_LIST_URL_DATA;
		this.props.getLabelsList({ recordData: labelFilters, currentPage: 'eventitemproperties' });
		this.setState({ isSaveDataDisabled: true });
		let canUpdateComponent = getUpdateRestrictionOnComponent(capitalizeFirstLetter(EVENTITEMS_LIST_PAGE), this.props.authorizedComponentsList);
		this.setState({ canUpdateComponent, canUpdateComponentSecurity: { ...canUpdateComponent } });
		this.setState(({ contextMenuList }) => ({ contextMenuList: contextMenuList.map(ele => ({ ...ele, isDisable: !canUpdateComponent.update })) }));
	}
	componentDidUpdate(prevProps, prevState) {
		const { pageUpDownData,
			isSaveSuccess,
			filterProps,
			isValueDataAPICall,
			isValueDataAPIFailure,
			eventitemColumnDefs,
			filterCriteriaDetails,
			detailCallData,
			labelsDataFailure,
			isAPIforItemList,
			isAPIforEventitemUpdate,
			previousNextFlagAPIFailure,
			isAPIforEventitemDelete,
			isAPIforEventitemColums,
			isDeleteSuccess,
			itemNotFoundFlag,
			eventitemNotFoundFlag,
			formValuesInitialized,
			eventitemDetailsLabelsData,
			effectChanged,
			invalidDeal,
			eventDetails,
		} = this.props.eventitemsProperties


		/**************************************************************************************************** */

		const { itemDetails, itemListDetails, formValues } = this.props.eventitemsProperties;
		if (effectChanged && effectChanged !== prevProps.eventitemsProperties.effectChanged) {
			let body = getItemDetailsBodyEvents(this.state.headerValues, getListPredecessor('eventItems'), getListPredecessor('EventItemDetails'));
			this.props.getEventItemDetails({ body });
			this.setState({ isSaveDataDisabled: true });
		}
		if (itemDetails && Object.keys(itemDetails).length && !isEqual(itemDetails, prevProps.eventitemsProperties.itemDetails)) {

			let filters = JSON.parse(JSON.stringify(EVENT_ITEM_LIST_FILTERS));
			filters[1].fieldValue = itemDetails['EIITEM'].trim();
			filters[2].fieldValue = itemDetails['EIWHSE'].trim();
			// let pageProps = JSON.parse(JSON.stringify(INITIAL_PAGE_PROPS))
			// this.props.getItemList({ filterProps: filters, pageProps, currentPage: ITEMS_LIST_PAGE, direction: pageProps.isForwardDirection });
			let prefix = 'EI'; //getListPredecessor(CURRENT_PAGE);
			this.setState({
				propertyValues: {
					vendorId: itemDetails[prefix + 'VNDR'],
					vendorName: itemDetails[prefix + 'VNAM'],
					itemId: itemDetails[prefix + 'ITEM'],
					itemName: itemDetails[prefix + 'INAM'],
					warehouseId: itemDetails[prefix + 'WHSE'],
					warehouseName: itemDetails[prefix + 'WNAM'],
					eventId: itemDetails[prefix + 'EVNT'].replace(/^0+/g, ''),
					companyId: itemDetails[prefix + 'COMP'],
					vendorId: itemDetails[prefix + 'VNDR'],

				}
			})
			this.setReassignedValue(itemDetails);
		}

		if (itemListDetails && itemDetails && eventitemDetailsLabelsData && !formValuesInitialized) {
			this.setReassignedValue({ ...itemListDetails, ...itemDetails });
			this.props.initialiseState({
				prefix: getListPredecessor(ITEMS_LIST_PAGE), item: itemListDetails,
				eventItem: itemDetails
			});
		}

		if (!Object.keys(prevProps.eventitemsProperties.formValues).length && Object.keys(formValues).length) {
			this.setReassignedValue(formValues);
		}

		/**************************************************************************************************** */

		if (this.state.valueDataFailureMessages && this.state.valueDataFailureMessages.length
			&& (JSON.stringify(this.state.valueDataFailureMessages) != JSON.stringify(prevState.valueDataFailureMessages))) {
			this.handleValueDataErrorMessages(this.state.valueDataFailureMessages[0]);
		}

		if (labelsDataFailure && (labelsDataFailure != prevProps.eventitemsProperties.labelsDataFailure)) {
			this.setState({ isDataLoaded: true })
			this.handleNoDataSets();
			this.props.setLabelDataFlags({ key: 'labelsDataFailure', value: false });
		}

		if (isAPIforItemList && (isAPIforItemList != prevProps.eventitemsProperties.isAPIforItemList)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to fetch Item list");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isAPIforItemList', value: false });
		}

		if (isAPIforEventitemUpdate && (isAPIforEventitemUpdate != prevProps.eventitemsProperties.isAPIforEventitemUpdate)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to Update Eventitem");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isAPIforEventitemUpdate', value: false });
		}

		if (previousNextFlagAPIFailure && (previousNextFlagAPIFailure != prevProps.eventitemsProperties.previousNextFlagAPIFailure)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to fetch Previous Next Flag");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'previousNextFlagAPIFailure', value: false });
		}
		if (isAPIforEventitemDelete && (isAPIforEventitemDelete != prevProps.eventitemsProperties.isAPIforEventitemDelete)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to Delete Event Item");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isAPIforEventitemDelete', value: false });
		}

		if (isAPIforEventitemColums && (isAPIforEventitemColums != prevProps.eventitemsProperties.isAPIforEventitemColums)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to fetch Eventitem Columns");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isAPIforEventitemColums', value: false });
		}
		if (itemNotFoundFlag && (itemNotFoundFlag != prevProps.eventitemsProperties.itemNotFoundFlag)) {
			this.setGridError(true, '11606')
			this.props.setLabelDataFlags({ key: 'itemNotFoundFlag', value: true });
		}
		if (eventitemNotFoundFlag && (!eventitemNotFoundFlag != prevProps.eventitemsProperties.eventitemNotFoundFlag)) {
			this.setGridError(true, '11605', [prevState.headerData["BKVNDR"]])
			this.props.setLabelDataFlags({ key: 'eventitemNotFoundFlag', value: true });
		}

		if ((JSON.stringify(filterProps) != JSON.stringify(prevProps.eventitemsProperties.filterProps)) && filterProps && filterProps.length) {
			this.setState({ isFiltersChanged: true });
			this.props.setChildTabFilterProps(filterProps);
			if (!this.state.isInitialAPICall) {
				if (this.state.fromPage != EVENTITEMS_LIST_PAGE && !this.state.hasFiltersChanged) {
					this.setHeaderAndSendAPI(this.state.stateData, this.state.fromPage)
				} else {
					this.makeAPICallForPageUpDown('down', {});
				}
			}
		}

		if ((filterCriteriaDetails != prevProps.eventitemsProperties.filterCriteriaDetails)) {
			this.props.setDataInTabs("defaultFilterInfo", JSON.parse(JSON.stringify(filterCriteriaDetails)));
			if (filterCriteriaDetails && Object.keys(filterCriteriaDetails) && Object.keys(filterCriteriaDetails).length && eventitemColumnDefs && eventitemColumnDefs.length) {
				let list = getFilterDataFromCriteriaDetails(filterCriteriaDetails, eventitemColumnDefs, EVENTITEMS_LIST_PAGE);
				if (list && list.length) {
					this.props.setGlobalFilterProps(list);
					this.props.onSetFilterProps(list);
				}
			}
		}

		if (detailCallData && !isEqual(detailCallData, prevProps.eventitemsProperties.detailCallData)) {
			if (Object.keys(detailCallData) && Object.keys(detailCallData).length) {
				if (eventitemColumnDefs && eventitemColumnDefs.length) {
					this.prepareTooltipData();
				}
				this.props.setSelectedRecord(detailCallData, EVENTITEMS_LIST_PAGE);
				this.setState({ headerData: this.prepareHeaderDataJSON(detailCallData) });
			}
		}

		if (eventitemColumnDefs && eventitemColumnDefs.length && !isEqual(eventitemColumnDefs, prevProps.eventitemsProperties.eventitemColumnDefs) &&
			(detailCallData && Object.keys(detailCallData) && Object.keys(detailCallData).length)) {
			if (!this.state.changeDataAPI) {
				this.prepareTooltipData();
			}
		}
		if (isValueDataAPICall != prevProps.eventitemsProperties.isValueDataAPICall && isValueDataAPICall) {
			this.setState({ previousFilterValues: prevProps.eventitemsProperties.filterProps })
			this.setState({ isInitialAPICall: false });
			this.makePrevNextAPICall(true);
			this.props.setValueDataFlag(false);
			if (this.state.isFiltersChanged) {
				this.setState({ openFilterPopup: false });
				this.setState({ isFiltersChanged: false });
			}
		}

		if (isValueDataAPIFailure != prevProps.eventitemsProperties.isValueDataAPIFailure && isValueDataAPIFailure) {
			this.setState({ isInitialAPICall: false });
			if (this.state.isFiltersChanged) {
				this.setState({ showConfirmationDialog: true });
				this.setState({ hasWarning: true });
				this.setState({ dialogTitle: TEXT_ALERT });
				this.setState({ fromHeaderENG: true });
			} else {
				this.setState({ showConfirmationDialog: true });
				this.setState({ hasWarning: true });
				this.setState({ dialogTitle: TEXT_ALERT });
				this.setState({ fromHeaderENG: true });
			}
		}

		if (this.props.location.search != prevProps.location.search) {
			this.resetValues();
			this.forceUpdateHandler();
			this.setRecordDataValues();
			this.setState({ state: this.state });
		}

		if (pageUpDownData && JSON.stringify(pageUpDownData) != JSON.stringify(prevProps.eventitemsProperties.pageUpDownData)) {
			this.props.setSelectedRecord(pageUpDownData, EVENTITEMS_LIST_PAGE);
			this.setState({ fromPage: EVENTITEMS_LIST_PAGE });
			this.setHeaderAndSendAPI(pageUpDownData, EVENTITEMS_LIST_PAGE);
			let modifiedData = {
				data: JSON.parse(JSON.stringify(pageUpDownData)),
				fromPage: EVENTITEMS_LIST_PAGE,
				rowIndex: this.props.eventitemsProperties.rowIndex,
				totalCount: this.state.totalCount,
				fromParent: false,
				columnDefs: this.state.columnDefs,
			};
			this.props.setDataInTabs('recordData', modifiedData);
			this.setState({ hasReassigedChanged: {} });
			this.props.setLabelDataFlags({ key: 'formValuesInitialized', value: false });
		}

		if (isSaveSuccess && isSaveSuccess !== prevProps.eventitemsProperties.isSaveSuccess) {
			this.setState({ isSaveDataDisabled: true });
		}

		if (isDeleteSuccess && (isDeleteSuccess != prevProps.eventitemsProperties.isDeleteSuccess)) {
			this.props.setLabelDataFlags({ key: 'isDeleteSuccess', value: false });

			this.props.setSelectedRecord(pageUpDownData, EVENTITEMS_LIST_PAGE);
			this.setState({ fromPage: EVENTITEMS_LIST_PAGE });
			this.setHeaderAndSendAPI(pageUpDownData, EVENTITEMS_LIST_PAGE);
			let modifiedData = {
				data: JSON.parse(JSON.stringify(pageUpDownData)),
				fromPage: EVENTITEMS_LIST_PAGE,
				rowIndex: this.props.eventitemsProperties.rowIndex,
				totalCount: this.state.totalCount,
				fromParent: false,
				columnDefs: this.state.columnDefs,
			};
			this.props.setDataInTabs('recordData', modifiedData);
		}
		if (invalidDeal && invalidDeal !== prevProps.eventitemsProperties.invalidDeal) {
			this.setGridError(true, '19709');
		}
		if (eventDetails && !isEqual(eventDetails, prevProps.eventitemsProperties.eventDetails)) {
			let isReadOnly = !!+eventDetails?.EHOPT || false;
			this.props.setDataInTabs('isReadOnly', isReadOnly);
			this.setState(({ contextMenuList }) => ({ contextMenuList: contextMenuList.map(ele => ({ ...ele, isDisable: isReadOnly })) }))
			this.setState(({ actionList }) => ({ actionList: actionList.map(ele => ({ ...ele, isDisable: isReadOnly })) }))
			this.setState(({ canUpdateComponentSecurity: { update = true, view } } = false) => ({ canUpdateComponent: { update: update && !isReadOnly, view } }))
		}
	}


	componentWillUnmount() {
		this.props.resetState();
	}

	handleEventitemHeaderSaveClick() {
		this.changeItemEffects({});
	}

	getApiObjForPageUpDown(filterData, record, currentPage, pageProps, sortData, pageType) {
		let recordObj = false
		if (record) {
			recordObj = record;
		}
		let apiObj = {
			sortProps: sortData,
			filterProps: filterData,
			pageProps: pageProps,
			direction: pageProps.isForwardDirection,
			record: recordObj,
			currentPage: currentPage,
			parentPage: EVENTITEMS_LIST_PAGE,
			pageType: pageType
		};
		return apiObj;
	}

	getApiObjForPageUpDownFlags = (filterData, record, currentPage, pageProps, sortData, pageType) => {
		let recordObj = false
		if (record) {
			recordObj = {
				"record": record,
				"flagsOnly": true
			};
		}
		let apiObj = {
			sortProps: sortData,
			filterProps: filterData,
			pageProps: pageProps,
			direction: pageProps.isForwardDirection,
			record: recordObj,
			currentPage: currentPage,
			parentPage: EVENTITEMS_LIST_PAGE,
			pageType: pageType
		};
		return apiObj;
	}

	makeAPICallForPageUpDown(type, currentRecordData) {
		const { filterProps } = this.props.eventitemsProperties;
		let data = JSON.parse(JSON.stringify(INITIAL_PAGE_PROPS));
		if (type == 'up') {
			data.isForwardDirection = false;
		} else {
			data.isForwardDirection = true;
		}
		let filterData = JSON.parse(JSON.stringify(filterProps));
		this.props.pageUpDownAPI(this.getApiObjForPageUpDown(filterData, currentRecordData, EVENTITEMS_LIST_PAGE, data, false))
	}
	handleEventitemHeaderLeftArrowClick() {
		const { currentRecordData } = this.props.eventitemsProperties;
		this.props.setCurrentType('down');
		this.makeAPICallForPageUpDown('down', currentRecordData);
		this.setState({ isSaveDataDisabled: true });
	}

	handleEventitemHeaderRightArrowClick() {
		const { currentRecordData } = this.props.eventitemsProperties;
		this.props.setCurrentType('up');
		this.makeAPICallForPageUpDown('up', currentRecordData);
		this.setState({ isSaveDataDisabled: true });
	}
	onValid = () => {
		return true;
	}

	onValid = values => {
		let valid = true;
		if (values.EIACCT == "" && (values.EIPDAT == '0' || values.PEIRDAT == "0")) {
			valid = false;
			this.setGridError(true, '10707');
			this.props.setError(false);
		}
		if (values.EIPBEG > values.EIPEND && values.EIPEND != '0') {
			valid = false;
			this.setGridError(true, '10711');
			this.props.setError(false);
		}
		if (values.EIHBEG != '0' && values.EIHEND == '0') {
			valid = false;
			this.setGridError(true, '10710');
			this.props.setError(false);
		}
		else if (values.EIHBEG > values.EIHEND) {
			valid = false;
			this.setGridError(true, '10722');
			this.props.setError(false);
		}
		return valid;
	};


	setGridError = (hasError, errorId = false, replaceValues = []) => {
		this.setState({ hasError, errorId, replaceValues })
	}

	handleEventitemHeaderActionItemSelection = action => {
		switch (action) {
			case LABEL_DELETE:
				this.handleCopyDeletePopup('openDeletePopup', true)
				break;
		}
	}
	handleCopyDeletePopup = (popup, val) => {
		if (popup == 'openCopyPopup') {
			this.setState({ openCopyPopup: val })
		} else if (popup == 'openDeletePopup') {
			if (this.validToDelete())
				this.setState({
					showConfirmationDialog: true,
					dialogBody: 'E19912',
					fromHeaderENG: false,
					hasWarning: true,
					cancelText: TEXT_CANCEL,
				});
		}
		else if (popup == 'openPlanDialog') {
			this.setState({ openPlanDialog: val })
		}
	}
	validToDelete = () => {
		const {
			eventitemsProperties: { itemDetails = false } = false,
			companyDetails: { CJDATE = false } = false
		} = this.props;
		if (!itemDetails || !CJDATE) return false;
		if (+itemDetails.EIENDT < +CJDATE) {
			this.setGridError(true, '19729');
			return false;
		}
		else return true;
	}
	handleChangeForm = (form) => {
		this.props.setDetailsForm(form)
		this.setState({ isSaveDataDisabled: false })
	}

	onContextMenuChange = (e, value, check = false, filters = false, title = false) => {
		let defaultFilters = filters;
		let toPage = value;
		let displayName = title;
		onChangeContextMenu(this.props, e, toPage, defaultFilters, displayName);
		this.props.setSelectedValueForTabs('Show Me');
	}

	handleClose = bodyId => {
		this.setState({ showConfirmationDialog: false, fromHeaderENG: false, dialogBody: false, hasWarning: false, cancelText: false });
		switch (bodyId) {
			case 'E14029':
				this.closeCurrentTab();
				break;
			case 'E19912': {
				this.deleteItem(); return;
			}
		}
	}
	deleteItem = () => {
		const { itemDetails, filterProps } = this.props.eventitemsProperties;
		let listParams = {
			filterProps,
			pageProps: { pageSize: 3 },
			direction: true,
			currentPage: "eventitems",
		}
		this.props.eventitemDetailsDelete({ ...itemDetails, EISTAT: 'D' }, listParams);
	}

	closeCurrentTab = () => {
		this.props.setNoDataCallBackValue(true);
		var paramsString = window.location.search;
		if (paramsString && paramsString.length) {
			let paramsArray = paramsString.split("?");
			if (paramsArray && paramsArray.length && paramsArray.length > 1) {
				let params = paramsArray[1].split("&");
				let tabId = params[0].split("=")[1];
				let breadCrumbId = params[1].split("=")[1];
				this.props.removeCurrentRecordObj(tabId, breadCrumbId);
			}
		}
	}

	checkForExistenceOfVendorItemWarehouse(data) {
		let pageProps = JSON.parse(JSON.stringify(INITIAL_PAGE_PROPS))
		let filters = [{ "accessor": "COMP", "operator": "=", "jOpr": "and", "fieldValue": "E3T" }, { "accessor": "ITEM", "operator": "=", "jOpr": "and", "fieldValue": data["EIITEM"] }];
		this.props.getItemList({ filterProps: filters, pageProps, currentPage: ITEMS_LIST_PAGE, direction: pageProps.isForwardDirection });
	}

	handleDisableUpArrow = () => {
		const { hasPrevious } = this.props.eventitemsProperties;
		const { fromListPage } = this.state;
		return !hasPrevious || fromListPage != EVENTITEMS_LIST_PAGE;
	};

	handleDisableDownArrow = () => {
		const { hasNext } = this.props.eventitemsProperties;
		const { fromListPage } = this.state;
		return !hasNext || fromListPage != EVENTITEMS_LIST_PAGE;
	};

	onModifyRadioSelect = (key, value, recordFlag) => {
	}

	setIsOpenActionsContextMenu = eventitem => {
		this.setState({ isOpenActionsContextMenu: Boolean(eventitem) });
		this.setState({ menuRef: eventitem.currentTarget ? eventitem.currentTarget : eventitem });
	}

	setReassignedValue = (form, method) => {
		if (this.state.hasReassigedChanged) {
			this.setState({ hasReassigedChanged: Object.assign({}, this.state.hasReassigedChanged, { ...form }) }, () => {
				if (method)
					method(this.state.hasReassigedChanged);
			});
		} else {
			this.setState({ hasReassigedChanged: form }, () => {
				if (method)
					method(this.state.hasReassigedChanged);
			})
		}
	}

	handleDetailSubmit = (val) => {
		if (this.state.hasReassigedChanged) {
			this.props.changeEventItemDetails(this.state.hasReassigedChanged, true);
		}
		this.props.submitDetails(true);
	}

	handleCancel = (val) => {
		if (this.state.hasReassigedChanged) {
			this.props.changeEventItemDetails(this.state.hasReassigedChanged, true);
		}
		this.props.handleDetailsClose(true);
	}


	changeItemEffects = (form) => {
		const { siblingSelectedRows, eventitemsProperties } = this.props;
		const { propertyValues } = this.state;
		// let row = Object.assign({}, this.state.hasReassigedChanged, form);
		let row = { ...eventitemsProperties.itemDetails, ...this.state.hasReassigedChanged, ...form };
		this.setReassignedValue(form);
		let prefix = 'EI';
		let isRelativeGrid = this.props.eventitemsProperties.itemDetails['EITYPE'].trim() == 'R';
		let body = getEventItemDetailBody({
			addType: 'C',
			companyId: propertyValues.companyId,
			eventId: propertyValues.eventId,
			eventItemType: this.props.eventitemsProperties.itemDetails['EITYPE'].trim(),

			eventBRDate: eventitemsProperties.itemDetails[prefix + 'BRDT'],
			eventBeginDate: row[prefix + 'BGDT'],
			eventEndDate: row[prefix + 'ENDT'],
			eventBeginPeriod: row[prefix + 'BGPD'],
			eventEndPeriod: row[prefix + 'ENPD'],
			warehouseId: row[prefix + 'WHSE'],
			vendorId: row[prefix + 'VNDR'],
			subVendorId: row[prefix + 'SUBV'],
			itemId: row[prefix + 'ITEM'],
			relatedEffect: isRelativeGrid ? row[prefix + 'RELE'] : "",
			profileId: row[prefix + 'PRFL'],
			profileType: row[prefix + 'PTYP'],
			profileAction: row[prefix + 'PACT'],
			primaryWarehouseId: isRelativeGrid && siblingSelectedRows && siblingSelectedRows.length ? siblingSelectedRows[0]['EIWHSE'] : "",
			primaryVendorId: isRelativeGrid && siblingSelectedRows && siblingSelectedRows.length ? siblingSelectedRows[0]['EIVNDR'] : "",
			primarySubVendorId: isRelativeGrid && siblingSelectedRows && siblingSelectedRows.length ? siblingSelectedRows[0]['EISUBV'] : "",
			primaryItemId: isRelativeGrid && siblingSelectedRows && siblingSelectedRows.length ? siblingSelectedRows[0]['EIITEM'] : "",
		}, prefix, row);
		this.props.changeEventItem(body);
	}

	setIsOpenActionsButtonContextMenu = event => {
		this.setState({ isOpenActions: Boolean(event) });
		this.setState({ actionMenuRef: event.currentTarget ? event.currentTarget : event });
	}
	handleActionSelection = action => {
		switch (action) {
			case "52707":
				this.setState({ openPlanDialog: true })
				break;
		}
	};

	setIsActionClose = () => {
		this.setState({ isOpenActions: false });
	};



	setChildLoading = childLoading => {
		if (this.state.childLoading !== childLoading) {
			this.setState({ childLoading })
		}
	}
	//E3C-32891, J Vamshi: begin
    isEllipsisActive = id => {
        const doc = document.getElementById(id);
        let title = false;
        if(doc && doc.offsetWidth < doc.scrollWidth) {
            title = this.props.eventitemsProperties?.itemDetails?.[id];
        }
        return title;
	}
	//E3C-32891, J Vamshi: End
	render() {
		const {
			classes, globalDateFormat, filterCriteriaDetails, pageFilterOptions, globalFilterOptions,
			columnDefs, currentPage, currentOwnerName, isShowContextMenu, removeChildCutdownTab, selectedValue, globalSecurityFilterList, errorMessages
		} = this.props;

		const { itemDetails, loading, itemListDetails, tabJson, formValues, effectChanged,
			apiInProgress, eventItemEffectsLabelsData, assignSalesLabelsData,
			eventitemColumnDefs, plansLabelsData, commentFieldArray, valueData, newValueData
		} = this.props.eventitemsProperties;
		const { canUpdateComponent, isSaveDataDisabled, tab, childLoading } = this.state;
		let headerData = [itemDetails];
		let contextMenu = updateBreadCrumbContextMenu(this.props) || [];
		if (this.state.hasHardError)
			return <h2>Oops Something Went Wrong</h2>
		return (
			<React.Fragment>
				{loading || apiInProgress || !itemDetails || childLoading ? <Spinner loading={true} type="EventItemsPropertiesMain" /> : null}
				{this.state.hasError && this.state.errorId ? (
					<div className={classes.gridErrorWrapper}>
						<GridErrorMessages
							errorMessageLabels={this.props.errorMessageLabels}
							popUp
							sethaserror={this.setGridError}
							replaceValues={this.state.replaceValues}
							id={this.state.errorId} />
					</div>)
					: null}

				<div className={classes.propertiesHeaderContainer}>
					{itemDetails && headerData && headerData.length &&
						<div className={classes.vendorContainer}>
							<Box className={classes.vendorDetailsWrapper}>
								<Box className={classes.vendorArrowWrapper}>

									<Button color="primary" onClick={() => this.handleEventitemHeaderRightArrowClick()} className={classes.vendorArrow} disabled={this.handleDisableUpArrow()}>
										<KeyboardArrowUpIcon />
									</Button>
									<Button color="primary" onClick={() => this.handleEventitemHeaderLeftArrowClick()} className={classes.vendorArrow} disabled={this.handleDisableDownArrow()}>

										<KeyboardArrowDownIcon />
									</Button>
								</Box>

								<Box className={classes.vendorDetailRow}>

									<div className={classes.IdNameBlock}>
										<div className={`${classes.vendorDetail} ${classes.vendorDetailWarehouse}`}>
											<div className={classes.vendorLabel}>
												{this.getLabelValue(LABEL_EVENT_ID)}
											</div>
											<div className={classes.vendorValue}>{headerData[0].EIEVNT} </div>
										</div>
										<div className={`${classes.vendorDetail} ${classes.vendorDetailWarehouse} ${classes.nameField}`}>
											<div className={classes.vendorLabel}>
												{this.getLabelValue(LABEL_EVENT_NAME)}
											</div>
											{/* //E3C-32891, J Vamshi Begin */}
											<CustomizedTooltip title={this.isEllipsisActive("EIRDES")}>
												<div className={`${classes.vendorValue} ${classes.ellipsis} ${classes.eventName}`} id={"EIRDES"}>{headerData[0].EIRDES}</div>
											</CustomizedTooltip>
											{/* //E3C-32891, J Vamshi: End */}
										</div>
									</div>




									<div className={classes.IdNameBlock}>
										<div className={classes.vendorDetail}>
											<div className={classes.vendorIDBlock}>
												<div className={`${classes.vendorDetail} ${classes.vendorIdDetails}`}>
													<div className={classes.vendorLabel}>
														{this.getLabelValue(LABEL_VENDOR_ID)}
													</div>
													<div className={classes.vendorValue}>{headerData[0].EIVNDR}</div>
												</div>
												<div className={`${classes.vendorDetail} ${classes.vendorSubVendorDetails}`}>
													<div className={classes.vendorLabel}>
														{this.getLabelValue(LABEL_SUB_VENDOR_ID)}
													</div>
													<div className={classes.vendorValue}>{headerData[0].EISUBV}</div>
												</div>
											</div>
										</div>


										<div className={classes.vendorDetail}>
											<div className={classes.vendorIDBlock}>
												<div className={`${classes.vendorDetail} ${classes.vendorIdDetails}`}>
													<div className={classes.vendorLabel}>
														{this.getLabelValue(LABEL_VENDOR_NAME)}
													</div>
													{/* //E3C-32891, J Vamshi */}
													<CustomizedTooltip title={this.isEllipsisActive("EIVNAM")}>
														<div className={`${classes.vendorValue} ${classes.ellipsis}`} id="EIVNAM">{headerData[0].EIVNAM}</div>
													</CustomizedTooltip>
												</div>
												<div className={`${classes.vendorDetail} ${classes.vendorSubVendorDetails}`}>
													<div className={classes.vendorLabel}>
														{this.getLabelValue(LABEL_COMPANY_ID)}
													</div>
													<div className={classes.vendorValue}>{headerData[0].EICOMP}</div>
												</div>
											</div>
										</div>

									</div>

									<div className={classes.IdNameBlock + " " + classes.paddingRight + " " + classes.itemName}>
										<div className={`${classes.vendorDetail} ${classes.vendorDetailWarehouse}`}>
											<div className={classes.vendorLabel}>
												{this.getLabelValue(LABEL_WAREHOUSE_ID)}
											</div>
											<div className={classes.vendorValue}>{headerData[0].EIWHSE} </div>
										</div>
										<div className={`${classes.vendorDetail} ${classes.vendorDetailWarehouse} ${classes.nameField}`}>
											<div className={classes.vendorLabel}>
												{this.getLabelValue(LABEL_WAREHOUSE_NAME)}
											</div>
											{/* //E3C-32891, J Vamshi */}
											<CustomizedTooltip title={this.isEllipsisActive("EIWNAM")}>
												<div className={`${classes.vendorValue} ${classes.ellipsis}`} id="EIWNAM">{headerData[0].EIWNAM}</div>
											</CustomizedTooltip>
										</div>
									</div>

									<div className={classes.IdNameBlock + " " + classes.paddingRight + " " + classes.itemName}>
										<div className={classes.vendorDetail}>
											<div className={classes.vendorLabel}>
												{this.getLabelValue(LABEL_ITEM_ID)}
											</div>
											<div className={classes.vendorValue}>
												{headerData[0].EIITEM}
											</div>
										</div>
										<div className={`${classes.vendorDetail} ${classes.nameField}`}>
											<div className={classes.vendorLabel}>
												{this.getLabelValue(LABEL_ITEM_NAME)}
											</div>
											{/* //E3C-32891, J Vamshi */}
											<CustomizedTooltip title={this.isEllipsisActive("EIINAM")}>
												<div className={`${classes.vendorValue} ${classes.ellipsis}`} id="EIINAM">
													{headerData[0].EIINAM}
												</div>
											</CustomizedTooltip>
										</div>
									</div>

									<div className={classes.IdNameBlock}>
										<div className={classes.vendorDetail}>
											<div className={classes.vendorLabel}>
												{this.getLabelValue(LABEL_WEEKS)}
											</div>
											<div className={classes.vendorValue}>
												{headerData[0].EIBGPD}  to  {headerData[0].EIENPD}
											</div>
										</div>
										<div className={`${classes.vendorDetail} ${classes.nameField}`}>
											<div className={classes.vendorLabel}>
												{this.getLabelValue(LABEL_DATES)}
											</div>
											<div className={classes.vendorValue}>
												{/*{getDateFormatValue(headerData[0].EIBGDT)} to  {getDateFormatValue(headerData[0].EIENDT)} */}
												{getDateFormatted(getDateFromJulian(headerData[0].EIBGDT), globalDateFormat)}  to  {getDateFormatted(getDateFromJulian(headerData[0].EIENDT), globalDateFormat)}   {/*//E3C-31921:Ajit using getDateFormatted instead of getDateFormatValue */}                               </div>
										</div>
									</div>

								</Box>
							</Box>


							<Box className={classes.vendorActions}>
								<div className={classes.buttonActionsSecondChild} onClick={(event) => this.setIsOpenActionsButtonContextMenu(event)}>
									<Button color="primary" size="small" variant="outlined" className={classes.vendorArrow} /* disabled={this.handleDisableDownArrow()} */>
										<div>{this.getLabelValue(LABEL_ACTIONS)}</div>
										<KeyboardArrowDownIcon />
									</Button>
									<ContextMenu
										className={classes.ActionsContextMenu}
										menuList={this.state.actionList}
										isOpen={this.state.isOpenActions}
										menuRef={this.state.actionMenuRef}
										handleItemSelection={(val) => this.handleActionSelection(val)}
										handleMenuClose={(val) => this.setIsActionClose(val)}>
									</ContextMenu>
								</div>
								<div className={classes.buttonActions}>
									<div className={isShowContextMenu || true ? 'showContextMenu' : 'hideContextMenu'}>
										<BreadcrumbContextMenu
											onOptionChange={(e, val) => this.onContextMenuChange(e, val)} menuItems={contextMenu}
											removeChildCutdownTab={removeChildCutdownTab}
											selectedValue={selectedValue} />
									</div>
								</div>
								<Button component="div" color="primary" onClick={this.handleEventitemHeaderFilterClick} className={classes.vendorActionsFilter}>
									<img src={FilterIcon} alt="Filter Icon" />
								</Button>
								<Button component="div" color="primary" onClick={this.handleEventitemHeaderSaveClick} disabled={isSaveDataDisabled} className={classes.vendorActionsFilter}>
									<SaveIcon fontSize="large" />
								</Button>
								<Box className={classes.menuButton}>
									<div
										onMouseEnter={(eventitem) => this.setIsOpenActionsContextMenu(eventitem)}
										onMouseLeave={() => this.setIsOpenActionsContextMenu(false)}>
										<MoreVertIcon color="primary" className="cPointer"></MoreVertIcon>
										<ContextMenuCreateNew
											className={classes.ActionsContextMenu}
											menuList={this.state.contextMenuList}
											isOpen={this.state.isOpenActionsContextMenu}
											menuRef={this.state.menuRef}
											handleItemSelection={(val) => this.handleEventitemHeaderActionItemSelection(val)}
											handleMenuClose={(val) => this.setIsOpenActionsContextMenu(val)}
											currentPage={currentPage}
											currentRecord={valueData}
										>
										</ContextMenuCreateNew>
									</div>
								</Box>
							</Box>



						</div>
					}
				</div>
				<div className={classes.propertiesContentWrapper}>
					<AppBar
						position="static"
						color="default"
						className="minWidth1100"
					>
						<Tabs
							value={this.state.tab}
							onChange={(evt, val) => {
								this.handleChangeTab(val);
							}}
							indicatorColor="primary"
							textColor="primary"
						>
							<Tab value={0} label={this.getLabelValue(LABEL_EVENTITEM_EFFECTS)} />
							<Tab value={1} label={this.getLabelValue(LABEL_EVENTITEM_DETAIL)} />
						</Tabs>
					</AppBar>

					{itemDetails && (
						<div className={tab === 0 ? 'showContextMenu' : 'hideContextMenu'}>
							<TabContainer>
								<div className={classes.pageContainer}>
									<EventItemDetailsEffects
										// eventItemDetails={this.state.hasReassigedChanged}

										eventItemDetails={this.state.hasReassigedChanged?.EIEVNT?.trim?.() !== "" ? { ...itemDetails, ...this.state.hasReassigedChanged } : itemDetails}

										currentPage={"eventItems"}
										sendEffectsObject={this.setReassignedValue}
										hasReassigedChanged={(val) => this.setReassignedValue(val)}
										changeItemEffects={(form) => this.changeItemEffects(form)}
										itemDetailsParent={itemDetails}
										hasWeeklyEffectApplied={effectChanged}
										itemListDetails={itemListDetails}
										eventItemEffectsLabelsData={eventItemEffectsLabelsData}
										assignSalesLabelsData={assignSalesLabelsData}
										setGridError={this.setGridError}
										canUpdateComponent={canUpdateComponent}
										setParentLoader={this.setChildLoading}
									></EventItemDetailsEffects>
								</div>
							</TabContainer>
						</div>
					)}

					{itemDetails && (
						<TabContainer>
							<div className={tab === 1 ? 'showContextMenu' : 'hideContextMenu'}>
								<div className={classes.pageContainer}>
									<EventItemDetailsTab
										setDetailsForm={(form) => { this.setReassignedValue(form); this.handleChangeForm(form) }}
										tabJson={tabJson}
										formValues={formValues}
										eventItemDetails={this.state.hasReassigedChanged?.EIEVNT?.trim?.() !== "" ? this.state.hasReassigedChanged : itemDetails}
										itemListDetails={itemListDetails}
										currentPage={"eventItems"}
										canUpdateComponent={canUpdateComponent}
									// sendDetailsForm={this.setReassignedValue}
									></EventItemDetailsTab>
								</div>
							</div>
						</TabContainer>
					)}
					{this.state.openFilterPopup && (
						<Filter
							filterCriteriaDetails={filterCriteriaDetails}
							pageFilterOptions={pageFilterOptions}
							globalFilterOptions={globalFilterOptions}
							globalSecurityFilterList={globalSecurityFilterList}
							currentPage={currentPage}
							isOpen={Boolean(this.state.openFilterPopup)}
							ownerName={currentOwnerName}
							columnDefs={eventitemColumnDefs}
							clearPopupComponent={this.handleEventitemHeaderFilterClick}
						/>
					)}
					{this.state.openPlanDialog && plansLabelsData && (
						<DetailDialog
							isOpen={this.state.openPlanDialog}
							classes={classes}
							closeDialog={this.handleCopyDeletePopup}
							headerData={headerData[0]}
							itemDetails={itemDetails}
							commentFieldArray={commentFieldArray}
							setGridError={this.setGridError}
							setIsShowContextMenu={this.props.setIsShowContextMenu}
							plansLabelsData={plansLabelsData}
							newPlanData={this.props.eventitemsProperties}
							onValid={this.onValid}
							currentOwnerName={currentOwnerName}
							globalDateFormat={globalDateFormat}
							filterCriteriaDetails={filterCriteriaDetails}
							pageFilterOptions={pageFilterOptions}
							globalFilterOptions={globalFilterOptions}
							columnDefs={columnDefs}
							currentPage={currentPage}
							canUpdateComponent={canUpdateComponent}
							valueData={valueData}
						/>)}


					{this.state.showConfirmationDialog && <ConfirmationDialog
						hasError={this.state.hasWarning}
						isOpen={this.state.showConfirmationDialog}
						dialogTitle={this.state.dialogTitle || "52891"}
						submitText={TEXT_OK}
						cancelText={this.state.cancelText || false}
						handleClose={() => this.handleClose(false)}
						handleCancel={() => this.handleClose(false)}
						handleSubmit={() => this.handleClose(this.state.dialogBody)}>
						<div>
							{this.state.fromHeaderENG ? this.getLabelValue("28648") : null}
							{!this.state.fromHeaderENG ? this.props.errorMessageLabels && this.props.errorMessageLabels[this.state.dialogBody] &&
								this.props.errorMessageLabels[this.state.dialogBody].MTEXT : null || 'Warning'}
						</div>
					</ConfirmationDialog>
					}
					{this.state.showValueConfirmationDialog && <ConfirmationDialog
						hasError={this.state.hasWarning}
						isOpen={this.state.showValueConfirmationDialog}
						dialogTitle={this.state.dialogTitle}
						submitText={TEXT_OK}
						handleClose={() => this.closeValueDialog(false)}
						handleCancel={() => this.closeValueDialog(false)}
						handleSubmit={() => this.closeValueDialog(this.state.dialogBody)}>
						<div>
							{(this.props.errorMessageLabels[this.state.dialogContent] && this.props.errorMessageLabels[this.state.dialogContent].MTEXT)
								|| this.state.dialogContent}
						</div>
					</ConfirmationDialog>
					}
				</div>
			</React.Fragment>);
	}
}

export default withStyles(style)(EventitemProperties);
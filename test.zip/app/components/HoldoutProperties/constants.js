export const HOLDOUT_PROPERTIES = 'holdoutProperties';

export const HeaderAPIValuesJSON = [
    {
        "HOVNAME": "",//VENDOR NAME
        "HOVNDR": "",//VENDOR ID
        "HOSUBV": "",//SUB VENDOR
        "HOWNAME": "",//WAREHOUSE NAME
        "HOWHSE": "",//WAREHOUSE ID
        "HOITEM": "",//ITEM ID
        "HOINAME": "",//ITEM NAME
        "HOBUYR": "",//Buyer ID
    }
];

// PLEASE NOTE THAT THE KEYS USED FOR HEADER VALUES MAY NOT BE SAME FOR FUTURE WORK.
// PLEASE CHANGE THE KEY VALUES TO REQUIRED KEYS AS NECCESSARY.
export const KEY_VENDOR_NAME = "HOVNAME";
export const KEY_VENDOR_ID = "HOVNDR";
export const KEY_SUB_VENDOR_ID = "HOSUBV";
export const KEY_WAREHOUSE_NAME = "HOWNAME";
export const KEY_WAREHOUSE_ID = "HOWHSE";
export const KEY_ITEM_ID = "HOITEM";
export const KEY_ITEM_NAME = "HOINAME";
export const KEY_BUYR_ID = "HOBUYR";

export const LABEL_HOLDOUT_INFO = "25018"; // ! needs to be included in Header_ENG.json
export const LABEL_VENDOR_NAME = "33989";
export const LABEL_VENDOR_ID = "34433"; // ! needs to be included in Header_ENG.json
export const LABEL_WAREHOUSE_NAME = "36479";// ! needs to be included in Header_ENG.json
export const LABEL_WAREHOUSE_ID = "33161";// ! needs to be included in Header_ENG.json
export const LABEL_ITEM_ID = "33670";
export const LABEL_ITEM_NAME = "33990";
export const LABEL_SUB_VENDOR_ID = "34435";
export const LABEL_BUYR_ID = '33174'; // buyer

export const LABEL_HOLDOUT_CONTROL_FACTORS = "50855";
export const LABEL_COPY_HOLDOUT = "25022";

export const LABEL_ACTIONS = '28310';
export const LABEL_SAVE = '28650';

export const KEY_NEW = "New";
export const KEY_COPY = "Copy";
export const KEY_POSITION_TO = "PositionTo";
export const KEY_DELETE = "Delete";


export const CONTEXT_MENU_HOLDOUT_HEADER = [
    {
        label: '2910',
        key: KEY_COPY,
        hasSubMenu: false,
        isDisable: false
    },
    {
        label: '28642',
        key: KEY_DELETE,
        hasSubMenu: false,
        isDisable: false
    },

];

export const DEFAULT_FIELD_URL_DATA = [
    { "accessor": "DSNAME", "operator": "=", "fieldValue": "DSVNDR", "prefixFlag": 1 },
    { "accessor": "BONAME", "operator": "=", "fieldValue": "TrimHoldoutBusObj", "prefixFlag": 1 }
]
export const DEFAULT_VALUE_URL_DATA = [
    { "accessor": "COMP", "operator": "=", "fieldValue": "", "prefixFlag": 0 },
    { "accessor": "WHSE", "operator": "=", "fieldValue": "", "prefixFlag": 0 },
    { "accessor": "VNDR", "operator": "=", "fieldValue": "", "prefixFlag": 0 },
    { "accessor": "ITEM", "operator": "=", "fieldValue": "", "prefixFlag": 0 },
    { "accessor": "SDAT", "operator": "=", "fieldValue": "", "prefixFlag": 0 },
    { "accessor": "EDAT", "operator": "=", "fieldValue": "", "prefixFlag": 0 },
    { "accessor": "ACCT", "operator": "=", "fieldValue": "", "prefixFlag": 0 }
];

export const LABEL_LIST_URL_DATA = [
    { "accessor": "TRIMBO", "operator": "=", "fieldValue": "TrimHoldoutUI", "prefixFlag": 0 },
    { "accessor": "LANGID", "operator": "=", "fieldValue": "ENG", "prefixFlag": 0 }
]

export const HOLDOUT_ITEMLIST_PROPS = [
    { "accessor": "COMP", "operator": "=", "jOpr": "and", "key": "COMP", "fieldValue": "" },
    { "accessor": "VNDR", "operator": "=", "jOpr": "and", "key": "VNDR", "fieldValue": "" },
    { "accessor": "ITEM", "operator": "=", "jOpr": "and", "key": "ITEM", "fieldValue": "" },
    { "accessor": "WHSE", "operator": "=", "jOpr": "and", "key": "WHSE", "fieldValue": "" }
]

export const BRACKET_LABEL_URL_DATA = [
    { "accessor": "TRIMBO", "operator": "=", "fieldValue": "TrimCommon", "prefixFlag": 0 },
    { "accessor": "LANGID", "operator": "=", "fieldValue": "ENG", "prefixFlag": 0 }
]

export const FILTER_DATA = ["COMP", "VNDR", "ITEM", "WHSE"];

export const ITEM_LIST = 'items';


/*
* * //==========================================================================
*
* * // Copyright 2021-2021, Blue Yonder Group, Inc.
*
* * // All Rights Reserved
*
* * //
*
* * // THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF
*
* * // BLUE YONDER GROUP, INC.
*
* * //
*
* * //
*
* * // The copyright notice above does not evidence any actual
*
* * // or intended publication of such source code.
*
* * //
*
* * // ===========================================================================
*/
import React, { Component } from 'react';
import PropTypes from 'prop-types';
import TextField from '@material-ui/core/TextField';
import { ALLOWED_MODIFY_KEYS, ALLOWED_OPERATION_KEYS, PROJECTION_QUEUE_LIB, PROJECTION_QUEUE } from '../../../components/common/constants';
import { validateInputText, checkBlankInput, postValidateInputText, getSelectionReplaceString } from 'utils/fieldValidations';
import { getErrorLabels } from 'utils/handleErrorLabels';
import ErrorMessageComponent from '../ErrorMessageComponent';
import { POPUP_TIMEOUT } from 'utils/constants';
import { withStyles } from '@material-ui/core';
import GridErrorMessages from '../GridErrorMessages';
import { checkGlobalSecuritOnFilters } from 'utils/util';
import CustomizedTooltip from '../CustomizedTooltip';

const defaultProps = { className: '', autoComplete: true, autoFocus: false };

const propTypes = {
  className: PropTypes.string,
  field: PropTypes.shape({}).isRequired,
  onChange: PropTypes.func.isRequired,
  // onKeyDown: PropTypes.func.isRequired,
  value: PropTypes.any,
  autoComplete: PropTypes.bool,
  autoFocus: PropTypes.bool,
  onFocus: PropTypes.func,
  onClick: PropTypes.func,
  showTooltip: PropTypes.any
};

const style = theme => ({
  inputTextWrapper: {
    position: 'relative',
    display: 'flex',
    width: '100%'
  },
  inputContainer: {
    width: '100%',
  },
  errorMessageWrapper: {
    position: 'relative',
    display: 'flex'
  }
})

class InputText extends Component {
  state = {
    isError: false,
    errorId: 0
  }
  constructor() {
    super();
    this.onChange = this.onChange.bind(this);
    this.checkInputValueChange = this.checkInputValueChange.bind(this);
    this.setErrorId = this.setErrorId.bind(this);
    this.showErrorTooltipPostValidate = this.showErrorTooltipPostValidate.bind(this);
    this.onBlur = this.onBlur.bind(this);
    this.onPaste = this.onPaste.bind(this);
  }

  onChange(e) {
    const { field, onChange, toUppercase } = this.props;
    const { key } = field;
    let value = e.currentTarget.value;
    if (toUppercase) {
      if (field.Attr && !field.Attr.includes('M'))        //Fix for E3C-31972 
        value = value.toUpperCase();
    }
    onChange(key, value);
  }

  onPaste(e) {
    const { maxLength, enableAddButton, updateFieldError, field } = this.props;
    let value = this.props.value + e.clipboardData.getData('Text');
    if (!((value && maxLength && value.length <= maxLength) || (!value && maxLength))) {
      e.preventDefault()
      if (updateFieldError) {
        updateFieldError(field, true)
      }
      this.setErrorId(517);
      this.showErrorTooltipPostValidate();
      this.setState({ isError: true })
      setTimeout(
        () => {
          if (updateFieldError) {
            updateFieldError(field, false)
          }
          if (enableAddButton) {
            enableAddButton(true);        //Added by Sachin
          }
          this.setState({ isError: false });
        }, POPUP_TIMEOUT);
    }
  }

  onBlur(value, event) {
    const { onFocusOut, selectedFieldLabel, globalSecurityFilterList, updateFieldError, field, enableAddButton, errorMessageLabel } = this.props;
    let errorId;
    if (value) {
      if (globalSecurityFilterList && globalSecurityFilterList.length) {
        if (selectedFieldLabel == 'VNDR' || selectedFieldLabel == 'WHSE' || selectedFieldLabel == 'BUYR') {
          if (!checkGlobalSecuritOnFilters(selectedFieldLabel, value, globalSecurityFilterList)) {
            this.setState({ errorId: 198, isError: true });
            if (enableAddButton) {
              enableAddButton(false);
            }
          }
        }
      }
    }

    if (onFocusOut) onFocusOut();
  }

  setErrorId = (id) => {
    this.setState({ errorId: id });
  }

  showErrorTooltipPostValidate() {
    const { updateFieldError, field } = this.props;
    this.setState({ isError: true });
    if (updateFieldError) {
      updateFieldError(field, true)
    }
    return false;
  }

  checkInputValueChange(keyEvent, enableAddButton) {
    const { value, maxLength, toUppercase, isCheckWildCard,
      gridCallBack, errorMessageLabel, updateFieldError, field, namespace } = this.props;
    let isWildCard = field.key?.trim() === PROJECTION_QUEUE || field.key?.trim() === PROJECTION_QUEUE_LIB ? false : isCheckWildCard
    let obj = validateInputText(keyEvent, value, maxLength, isWildCard, this.setErrorId)
    //E3C-32111:Begin Allow for * even though it exceeds maxlengh ex: for whse : 001* is valid
    if (namespace == 'filterFilterGrid') {
      let replaceInput = getSelectionReplaceString(keyEvent, value);
      if ((replaceInput[replaceInput.length - 1] == '*' && replaceInput.length == maxLength + 1) || (replaceInput == '*BLANK')) {
        obj.isValid = true;
        obj.errorId = '';
      }
    }
    //E3C-32111:End
    if (obj.isValid) {
      if (updateFieldError) {
        updateFieldError(field, false)
      }
      this.setState({ isError: false });
      if (enableAddButton) {
        enableAddButton(true);
        if (!checkBlankInput(value, keyEvent)) {
          enableAddButton(false);
        }
      }
      return true;
    }
    else {
      keyEvent.preventDefault();
      if (gridCallBack && obj.errorId) {
        gridCallBack("text",
          obj.errorId,
          errorMessageLabel,
          maxLength);
      }
      if (updateFieldError) {
        updateFieldError(field, true)
      }
      this.setState({ isError: true });
      if (enableAddButton) {
        enableAddButton(false);
      }
      setTimeout(
        () => {
          if (updateFieldError) {
            updateFieldError(field, false)
          }
          if (enableAddButton) {
            enableAddButton(true);        //Added by Sachin
          }
          this.setState({ isError: false });
        }, POPUP_TIMEOUT);
      return false;
    }

  }

  componentDidUpdate(prevProps) {
    if (prevProps.value !== this.props.value && this.props.value === "") {
      this.setState({ isError: false })
    }
  }

  render() {
    const { classes, className, field, value, autoComplete, autoFocus, onKeyDown, onFocus, onClick, isFromGrid,
      disabled, maxLength, errorMessageLabel, enableAddButton,
      showTooltip, parentErrorClass } = this.props;
    const { key, placeholder, type } = field;
    const { fieldStyle } = this.props;
    let mL = maxLength ? Number(maxLength) : undefined;
    //Fix for E3C-31971
    let allign='left'
    if (field.Attr && field.Attr.includes('R')) {
      allign='right'
    }
    return (
      <div className={classes.inputTextWrapper}>
        <div onClick={onFocus} onBlur={() => { this.onBlur(value, event) }}
          className={classes.inputContainer}>
          <CustomizedTooltip title={showTooltip && value ? value : ''}>
            <TextField
              className={className +
                (this.state.isError && errorMessageLabel ? ' error-input' : '')}
              autoFocus={autoFocus}
              id={key}
              onChange={this.onChange}
              onKeyDown={e => { this.checkInputValueChange(e, enableAddButton); }}
              onPaste={e => { this.onPaste(e) }}
              placeholder={placeholder}
              type={type}
              value={value}
              onFocus={onFocus}
              inputProps={{style: { textAlign: allign } }}
              {...fieldStyle}
              {...(autoComplete ? {} : { autoComplete: 'off' })}
              onClick={onClick}
              disabled={disabled}
              autoComplete="off"
            >
            </TextField>
          </CustomizedTooltip>
        </div>

        {this.state.isError && errorMessageLabel && !isFromGrid &&
          <div className={classes.errorMessageWrapper} >
            <div className={"error-icon-pure-css " + parentErrorClass}></div>
            <ErrorMessageComponent
              id={this.state.errorId}
              replaceValues={getErrorLabels(
                this.state.errorId,
                errorMessageLabel,
                maxLength
              )}
            >
            </ErrorMessageComponent>
          </div>
        }

      </div>
    );
  }
}

InputText.defaultProps = defaultProps;
InputText.propTypes = propTypes;

export default withStyles(style)(InputText);
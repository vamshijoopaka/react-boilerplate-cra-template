/** Change Log
 * LogStart --  E3C-33195 - Kumar A- 16 September,2021 - 2022.1.0.0 Unified Product
 *              Story: E3C-33195 --Code Cleanup
*/
import React from 'react';
import { withStyles } from '@material-ui/core/styles';
import Checkbox from '@material-ui/core/Checkbox';
import CheckedIcon from '../../common/CheckedIcon';
import { createMuiTheme } from '@material-ui/core/styles';

const styles = theme => ({
    paper: {
        margin: 10,
        height: '100px'
    },
    root: {
        flexGrow: 1,
        width: '100%'
    },
    cardHeader: {
        color: 'white',
        height: '34px',
        backgroundColor: '#01A9E0',
        marginBottom: 15,
        fontSize: '16px'
    },
    cardTitle: {
        fontSize: '1.2rem',
    },
    cardHeaderContent: {
        textAlign: 'left',
        fontSize: '14px',
        paddingTop: '0px'
    },
    cardItemContent: {
        textAlign: 'center',
        fontWeight: 'bold',
        fontSize: '25px',
        paddingTop: '0px'
    },
    gridItemHeader: {
        [theme.breakpoints.down("sm")]: {
            width: '100%',
        },
        [theme.breakpoints.between("sm", "md")]: {
            width: '50%',
        },
        [theme.breakpoints.between("md", "lg")]: {
            width: '25%',
        },
    },
    gridItem: {
        [theme.breakpoints.down("sm")]: {
            width: '100%',
        },
        [theme.breakpoints.between("sm", "md")]: {
            width: '50%',
        },
        [theme.breakpoints.between("md", "lg")]: {
            width: '20%',
        },
    },
    card: {
        height: '100%'
    },
    buttonCard: {
        textAlign: 'left'
    },
    cardItem: {
        boxShadow: '-10px -10px 30px 4px rgba(0,0,0,.1), 10px 10px 30px 4px rgba(45,78,255,.2)',
        borderRadius: '8px'
    },
    table: {
        minWidth: 700,
    },
    row: {
        '&:nth-of-type(odd)': {
            backgroundColor: '#F6F9FB',
        },
    },
    chip: {
        margin: theme.spacing.unit,
    },
    button: {
        margin: theme.spacing.unit,
        backgroundColor: '#007AB4',
        fontSize: '11px',
        color: '#FAFAFA',
        fontStyle: 'medium',
        borderRadius: '4px',
        height: '24px',
        marginLeft: theme.spacing.unit * 3,
    },
    leftIcon: {
        marginRight: theme.spacing.unit,
    },
    rightIcon: {
        marginLeft: theme.spacing.unit,
    },
    close: {
        padding: theme.spacing.unit / 2,
    },
    textField: {
        marginLeft: theme.spacing.unit * 3,
        width: 200,
        fontSize: '12px !important',
    },
    textField1: {
        marginLeft: theme.spacing.unit * 0,
        width: 210,
        fontSize: '12px !important',
    },
    checkboxfield: {
        marginLeft: theme.spacing.unit * -6,
        width: 480,
    },
    checkboxfield1: {
        marginLeft: theme.spacing.unit * 21,
    },
    checkboxfield2: {
        marginLeft: theme.spacing.unit * -8.5,
        width: 500,
    },
    checkboxfield3: {
        marginLeft: theme.spacing.unit * 24.5,
    },
    checkboxfield5: {
        marginLeft: theme.spacing.unit * 19.5,
    },
    checkboxfield7: {
        marginLeft: theme.spacing.unit * 15.2,
    },
    checkboxfield9: {
        marginLeft: theme.spacing.unit * 12.7,
    },
    checkboxfield11: {
        marginLeft: theme.spacing.unit * 10.7,
    },
    checkboxfield13: {
        marginLeft: theme.spacing.unit * 27.2,
    },
    checkboxfield14: {
        marginLeft: theme.spacing.unit * -8.5,
        width: 480,
    },
    checkboxfield15: {
        marginLeft: theme.spacing.unit * 25,
    },
    checkboxfield16: {
        marginLeft: theme.spacing.unit * -22,
        width: 590,
    },
    checkboxfield17: {
        marginLeft: theme.spacing.unit * 27,
    },
    checkboxfield18: {
        marginLeft: theme.spacing.unit * -22,
        width: 590,
        marginBottom: theme.spacing.unit * 8.5,
    },
    checkboxfield19: {
        marginLeft: theme.spacing.unit * 26.3,

    },
    checkboxfield21: {
        marginLeft: theme.spacing.unit * 27.6,
    },
    checkboxfield22: {
        marginLeft: theme.spacing.unit * 14.6,
    },
    checkboxfield23: {
        marginLeft: theme.spacing.unit * 24.5,
    },
    poCard: {
        textAlign: 'left'
    },
    date: {
        marginRight: theme.spacing.unit,
    },
    formControl: {
        margin: theme.spacing.unit,
        minWidth: 120,
    },
    textField2: {
        marginLeft: theme.spacing.unit * -12.9,
        width: 510,
        fontSize: '12px !important',
    },
    textField3: {
        marginLeft: theme.spacing.unit * 16,
        width: 148,
        fontSize: '12px !important',
    },
    textField4: {
        marginLeft: theme.spacing.unit * 0,
        width: 147,
        fontSize: '12px !important',
    },
    formLabel: {
        padding: "7px 7px 7px",
        width: '50%',
        fontSize: '14px',
        color: 'black',
        marginLeft: theme.spacing.unit * 1.5,
    },
    input: {
        width: '32%',
        fontSize: '14px',
        marginBottom: theme.spacing.unit * 1,
        marginLeft: theme.spacing.unit * 0.6,
        textAlignLast: 'end'
    },
});

const theme = createMuiTheme({
    props: {
        MuiCheckbox: {
            checkedIcon: <CheckedIcon />
        }
    }
});

class CheckboxRenderer extends React.PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            value: props.value
        };
        this.handleCheckboxChange = this.handleCheckboxChange.bind(this);
    }

    handleCheckboxChange(event) {
        this.props.data.checkbox = !this.props.data.checkbox;
        this.setState({ value: this.props.data.checkbox });
    }

    render() {
        return (
            <div>
                <Checkbox
                    checked={this.state.value}
                    onChange={this.handleCheckboxChange}></Checkbox>
            </div>)
    }

}

export default (withStyles(styles)(CheckboxRenderer));
import React, { Component } from 'react';
import ItemsSuperTypeEmbeddedList from 'containers/ItemEmbeddedListContainers/ItemSuperType';
 
class ItemsSuperTypeDialog extends Component {
    constructor(props) {
        super(props);
        this.state = {
            finalLabel: false,
        }
    }

    componentDidMount() {
        let finalLabel = this.enableDisableFields();
        this.setState({ finalLabel: finalLabel })
    }
    enableDisableFields = () => {
        let labels = this.props.superTypeLabelData;
        if (this.props.superType == "U") {
            labels.tabcards.forEach(arr => {
                if (arr["cardkey"] == "0") {
                    arr.cardfields.forEach(element => {
                        if (element["key"] == "IVNDR" || element["key"] == "IACHS" || element["key"] == "IACBL" || element["key"] == "SWMULT") {
                            element.disabled = true;
                        }
                        else {
                            element.disabled = false;
                        }
                    })
                }
            }
            )
        }
        if (this.props.superType == "B") {
            labels.tabcards.forEach(arr => {
                if (arr["cardkey"] == "0") {
                    arr.cardfields.forEach(element => {
                        if (element["key"] == "IVNDR" || element["key"] == "IACHS" || element["key"] == "IACBL" || element["key"] == "SWMULT" || element["key"] == "IBMIN") {
                            element.disabled = true;
                        }
                        else {
                            element.disabled = false;
                        }
                    })
                }
            }
            )
        }
        if (this.props.superType == "C") {
            labels.tabcards.forEach(arr => {
                if (arr["cardkey"] == "0") {
                    arr.cardfields.forEach(element => {
                        if (element["key"] == "IVNDR" || element["key"] == "IBMIN") {
                            element.disabled = true;
                        }
                        else {
                            element.disabled = false;
                        }
                    })
                }
            }
            )
        }
        return labels;
    }
    render() {
        return (
            <>
                {
                    this.props.isOpen && this.state.finalLabel &&
                    <ItemsSuperTypeEmbeddedList
                        finalLabel={this.state.finalLabel}
                        {...this.props}
                    />
                }
            </>);
    }
}
export default ItemsSuperTypeDialog;
export const HeaderAPIValuesJSON = [
    {
        "VNAME": "",//VENDOR NAME
        "EVNDR": "",//VENDOR ID
        "ESUBV": "",//VENDOR ID
        "INAME": "",//ITEM NAME
        "EITEM": "",//ITEM ID
        "EWNAME": "",//WAREHOUSE NAME
        "EWHSE": "",//WAREHOUSE ID
        "EBUYR": "",//BUYER ID
        "IGRP1": "",//ITEM GROUP 1
        "IGRP2": "",//ITEM GROUP 2
        "IGRP3": "",//ITEM GROUP 3
        "IGRP4": "",//ITEM GROUP 4
        "ESUPER": "",//SUPER ITEM TYPE
        "EUPC#": "",//UPC CODE
        "EMFGID": "",//MFG ID
        "EREGON": "",//REGION ID
        "ETIEHI": "",//REGION ID
    }
];


// PLEASE NOTE THAT THE KEYS USED FOR HEADER VALUES MAY NOT BE SAME FOR FUTURE WORK.
// PLEASE CHANGE THE KEY VALUES TO REQUIRED KEYS AS NECCESSARY.
export const KEY_VENDOR_NAME = "VNAME";
export const KEY_VENDOR_ID = "EVNDR";
export const KEY_ITEM_NAME = "INAME";
export const KEY_ITEM_ID = "EITEM";
export const KEY_WAREHOUSE_NAME = "EWNAME";
export const KEY_WAREHOUSE_ID = "EWHSE";
export const KEY_BUYER_ID = "EBUYR";
export const KEY_ITEMGRP_1 = "IGRP1";
export const KEY_ITEMGRP_2 = "IGRP2";
export const KEY_ITEMGRP_3 = "IGRP3";
export const KEY_ITEMGRP_4 = "IGRP4";
export const KEY_SUPER = "ESUPER";
export const KEY_UPC = "EUPC#";
export const KEY_MFG_ID = "EMFGID";
export const KEY_REGION_ID = "EREGON";
export const KEY_TIEHI = "ETIEHI";
export const KEY_SUB_VENDOR_ID = "ESUBV";

export const LABEL_ARCHEXCEP_LIST = "25074"; // ! needs to be included in Header_ENG.json
export const LABEL_VENDOR_NAME = "33989";// ! needs to be included in Header_ENG.json
export const LABEL_VENDOR_ID = "34433"; // ! needs to be included in Header_ENG.json
export const LABEL_ITEM_NAME = "33990";// ! needs to be included in Header_ENG.json
export const LABEL_ITEM_ID = "33670";// ! needs to be included in Header_ENG.json
export const LABEL_WAREHOUSE_NAME = "36479";// ! needs to be included in Header_ENG.json
export const LABEL_WAREHOUSE_ID = "33161";// ! needs to be included in Header_ENG.json
export const LABEL_BUYER_ID = "33174";// ! needs to be included in Header_ENG.json
export const LABEL_ITEMGRP_1 = "38423";// ! needs to be included in Header_ENG.json
export const LABEL_ITEMGRP_2 = "38424";// ! needs to be included in Header_ENG.json
export const LABEL_ITEMGRP_3 = "38425";// ! needs to be included in Header_ENG.json
export const LABEL_ITEMGRP_4 = "38426";// ! needs to be included in Header_ENG.json
export const LABEL_SUPER = "33682";// ! needs to be included in Header_ENG.json
export const LABEL_UPC = "33676";// ! needs to be included in Header_ENG.json
export const LABEL_MFG_ID = "33674";// ! needs to be included in Header_ENG.json
export const LABEL_REGION_ID = "33169";// ! needs to be included in Header_ENG.json
export const LABEL_TIEHI = "33677";// ! needs to be included in Header_ENG.json
export const LABEL_SUB_VENDOR_ID = "34435";


export const DEFAULT_FIELD_URL_DATA = [
    { "accessor": "DSNAME", "operator": "=", "fieldValue": "DSEXAR", "prefixFlag": 1 },
    { "accessor": "BONAME", "operator": "=", "fieldValue": "TrimArchivedExceptionBusObj", "prefixFlag": 1 }
]


export const DEFAULT_VALUE_URL_DATA = [
    { "accessor": "COMP", "operator": "=", "fieldValue": "", "prefixFlag": 0 },
    { "accessor": "VNDR", "operator": "=", "fieldValue": "", "prefixFlag": 0 },
    { "accessor": "ITEM", "operator": "=", "fieldValue": "", "prefixFlag": 0 },
    { "accessor": "PERYR", "operator": "=", "fieldValue": "", "prefixFlag": 0 },
    { "accessor": "PER52", "operator": "=", "fieldValue": "", "prefixFlag": 0 },
    { "accessor": "XTYPE", "operator": "=", "fieldValue": "", "prefixFlag": 0 },
    { "accessor": "WHSE", "operator": "=", "fieldValue": "", "prefixFlag": 0 },
]


export const LABEL_LIST_URL_DATA = [
    { "accessor": "TRIMBO", "operator": "=", "fieldValue": "TrimArchivedExceptionUI", "prefixFlag": 0 },
    //somecomment// { "accessor": "TRIMBO", "operator": "=", "fieldValue": "TrimVendorUI", "prefixFlag": 0 },
    { "accessor": "LANGID", "operator": "=", "fieldValue": "ENG", "prefixFlag": 0 }
]


export const BRACKET_LABEL_URL_DATA = [
    { "accessor": "TRIMBO", "operator": "=", "fieldValue": "TrimCommon", "prefixFlag": 0 },
    { "accessor": "LANGID", "operator": "=", "fieldValue": "ENG", "prefixFlag": 0 }
]


export const ARCHEXCEP_PROPERTIES = 'archexcepProperties';


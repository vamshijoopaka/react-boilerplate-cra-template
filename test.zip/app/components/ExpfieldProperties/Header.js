import React from 'react';
import { withStyles, Button, Box } from '@material-ui/core';
import { injectIntl } from 'react-intl';
import FieldInput from 'components/common/Form/FieldInput';
import KeyboardArrowUpIcon from '@material-ui/icons/KeyboardArrowUp';
import KeyboardArrowDownIcon from '@material-ui/icons/KeyboardArrowDown';
import SaveIcon from '@material-ui/icons/Save';
import withFixedPosition from 'containers/common/withFixedPosition';
import {
	LABEL_EXF_REFERENCE,
	LABEL_EXF_DESCRIPTION,
	LABEL_EXF_OWNER,
	LABEL_EXF_TYPE,
	LABEL_EXF_LOCK,
	LABEL_ACTIONS,
	DESC_KEY,
	descFieldArray,
	CONTEXT_MENU_HEADER_EXPFIELD_ACTIONS

} from './constants';
import FormattedMessageComponent from '../common/FormattedMessageComponent';
import FormFieldsGenerator from '../common/FormFieldsGenerator';
import FormFieldComponent from 'components/common/FormFieldsGenerator/formField';
import FilterIcon from "../../images/icon_filter.png";
import { getDateFromJulian, getDateFormatValue, formatStringToTime } from 'utils/util';
import { getDateFormatted } from 'components/common/Form/dateTimeUtils';
import ContextMenu from '../common/ContextMenu';
import ContextMenuCreateNew from '../common/ContextMenuCreateNew';
import MoreVertIcon from '@material-ui/icons/MoreVert';
import BreadcrumbContextMenu from 'components/common/BreadcrumbContextMenu';
import { EXPFIELDS_LIST_PAGE } from 'components/common/constants';
import { isSaveDisable } from './../../utils/util';

const style = theme => ({
	propertiesContentWrapper: {
		margin: '10px auto',
		borderRadius: '4px',
		overflow: 'hidden',
		boxShadow: '0 2px 4px var(--secondary-s10)',
		overflowX: 'auto'
	},
	propertiesHeaderContainer: {
		width: '100%',
		marginBottom: '1.5rem',
		backgroundColor: 'var(--background-app)',
		borderRadius: '4px',
		borderTopLeftRadius: '0px',
		borderTopRightRadius: '0px',
		overflow: 'hidden',
		boxShadow: '0 4px 4px var(--secondary-s10)',
		overflowX: 'auto'
	},
	boookingDetailContainer: {
		display: 'flex',
		width: '100%',
		backgroundColor: 'var(--background-content)',
		fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
		alignItems: 'center',
		padding: '0 0 0 24px',
		position: 'relative',
		minWidth: '630px'
	},
	boookingDetailDetailsWrapper: {
		width: '100%',
		display: 'flex',
	},
	pageContainer: {
		display: 'flex',
		backgroundColor: 'var(--background-app)',
		borderTop: 'none',
		padding: '10px 10px',
	},
	card: {
		padding: '0px',
		backgroundColor: 'var(--background-content)',
		borderRadius: '4px',
		width: '100%',
		margin: '10px',
		'& .MuiCardHeader-root': {
			padding: '22px 20px 0 20px'
		},
		'& .MuiCardContent-root': {
			padding: '16px 15px 10px 15px'
		}
	},
	marginLeftZero: {
		marginLeft: '0',
	},
	boookingArrow: {
		padding: '0 !important',
		margin: '0',
		minWidth: '16px',
		background: 'none',
		height: '16px',
		width: '16px',
	},
	bookingArrowWrapper: {
		display: 'flex',
		flexDirection: 'column',
		border: '1px solid var(--primary-default)',
		borderRadius: '4px',
		justifyContent: 'center',
		alignItems: 'baseline',
		height: '38px',
		marginTop: '24px',
		padding: '2px',
	},
	vendorDetailRow: {
		width: '75%',
		display: 'flex',
		flexWrap: 'wrap',
		padding: '0px 0 24px 0',
		paddingLeft: '15px'
	},
	vendorDetail: {
		padding: '0px 0px 0 0px',
		lineHeight: '1.1',
	},
	vendorIDBlock: {
		display: 'flex',
	},
	vendorIdDetails: {
		width: '50ch',
		padding: '0 30px 10px 0px',
		lineHeight: '1.1'
	},
	vendorLabel: {
		color: 'var(--header-label-color)',
		paddingBottom: '10px',
		width: '50ch',
	},
	vendorIdDetails11: {
		width: '25ch',
		padding: '0 30px 10px 0px',
		lineHeight: '1.1'
	},
	vendorLabel11: {
		color: 'var(--header-label-color)',
		paddingBottom: '10px',
		width: '25ch',
	},
	vendorSubVendorDetails: {
		display: 'flex',
		flexDirection: 'column',
		width: '16ch',
		padding: '0 30px 0 0px',
		lineHeight: '1.1'
	},
	nameField: {
		paddingTop: '32px'
	},
	vendorValue: {
		color: 'var(--value)',
	},
	vendorIDSubID: {
		paddingRight: '24px',
		paddingTop: '24px'
	},
	IdNameBlock: {
		paddingTop: '24px',
		paddingRight: '40px',
	},
	bookingActions: {
		top: '24px',
		padding: '0px 20px 20px 20px',
		right: '20px',
		display: 'flex',
		position: 'absolute',
		alignItems: 'center',
		justifyContent: 'space-between',
		'@media (max-width: 1220px)': {
			flexWrap: 'wrap',
			width: '250px'
		}
	},
	buttonActions: {
		display: 'flex',
		alignItems: 'center',
		'@media (max-width: 1220px)': {
			marginBottom: '20px'
		},
		'& .MuiButton-root': {
			borderRadius: '4px',
			fontSize: '14px',
			width: '120px',
			lineHeight: '14px',
		},
		'& .MuiButton-sizeLarge': {
			fontSize: '18px',
		},
		'& .MuiButton-sizeSmall': {
			fontSize: '12px',
			padding: '8px 16px',
		},
		'& .MuiButton-containedPrimary': {
			backgroundColor: theme.palette.primary.default,
			border: '1px solid rgba(0, 0, 0, 0)',
			boxShadow: 'none',
			color: 'var(--background-content)',
			'&:hover': {
				backgroundColor: theme.palette.primary.hover,
				color: 'var(--background-content)',
				border: '1px solid rgba(0, 0, 0, 0)',
			},
			'&:focus': {
				backgroundColor: theme.palette.primary.focus,
				color: 'var(--background-content)',
				border: '1px solid rgba(0, 0, 0, 0)',
			},
			'&:active': {
				backgroundColor: theme.palette.primary.active,
				color: 'var(--background-content)',
				border: '1px solid rgba(0, 0, 0, 0)',
			}
		},
		'& .MuiButton-containedSecondary': {
			backgroundColor: 'var(--background-content)',
			border: '1px solid var(--button-tertiary-color)',
			color: 'var(--button-tertiary-color)',
			boxShadow: '0px 4px 14px rgba(0, 0, 0, 0.05)',
			'&:hover': {
				backgroundColor: 'var(--background-content)',
				color: 'var(--button-tertiary-hover-color)',
				border: '1px solid var(--button-tertiary-hover-color)',
			},
			'&:focus': {
				backgroundColor: 'var(--background-content)',
				color: 'var(--button-tertiary-focused)',
				border: '1px solid var(--button-tertiary-focused)',
			},
			'&:active': {
				backgroundColor: 'var(--background-content)',
				color: 'var(--button-tertiary-hover-color)',
				border: '1px solid var(--button-tertiary-hover-color)',
			},
			'&.Mui-disabled': {
				color: theme.palette.primary.disabled,
				textDecoration: 'unset',
				backgroundColor: 'unset',
				textShadow: 'unset'
			}
		},
		'& .MuiButton-outlinedPrimary': {
			border: `${'1px solid '}${theme.palette.primary.default}`,
			boxShadow: '0px 4px 14px rgba(0, 0, 0, 0.05)',
			backgroundColor: 'var(--background-content)',
			color: theme.palette.primary.default,
			'&:hover': {
				backgroundColor: 'var(--background-content)',
				border: '1px solid var(--button-secondary-hover-border)',
				color: 'var(--button-secondary-hover-border)',
			},
			'&:focus': {
				backgroundColor: 'var(--background-content)',
				border: `${'1px solid '}${theme.palette.primary.default}`,
				color: theme.palette.primary.default
			},
			'&:active': {
				backgroundColor: 'var(--background-content)',
				border: '1px solid var(--primary-button-pressed)',
				color: 'var(--primary-button-pressed)'
			},
			'&.Mui-disabled': {
				color: theme.palette.primary.disabled,
				textDecoration: 'unset',
				backgroundColor: 'unset',
				textShadow: 'unset'
			}
		},
		'& .MuiButton-outlinedSecondary': {
			backgroundColor: 'var(--background-content)',
			border: '1px solid var(--button-tertiary-color)',
			color: 'var(--button-tertiary-color)',
			boxShadow: '0px 4px 14px rgba(0, 0, 0, 0.05)',
			'&:hover': {
				backgroundColor: 'var(--background-content)',
				color: 'var(--button-tertiary-hover-color)',
				border: '1px solid var(--button-tertiary-hover-color)',
			},
			'&:focus': {
				backgroundColor: 'var(--background-content)',
				color: 'var(--button-tertiary-focused)',
				border: '1px solid var(--button-tertiary-focused)',
			},
			'&:active': {
				backgroundColor: 'var(--background-content)',
				color: 'var(--button-tertiary-hover-color)',
				border: '1px solid var(--button-tertiary-hover-color)',
			},
			'&.Mui-disabled': {
				color: theme.palette.primary.disabled,
				textDecoration: 'unset',
				backgroundColor: 'unset',
				textShadow: 'unset'
			}
		},
	},
	bookingActionsFilter: {
		minWidth: '37px',
		border: '1px solid var(--primary-default)',
		height: '32px',
		marginLeft: '15px',
		// marginRight: '15px',
		'@media (max-width: 1220px)': {
			marginLeft: '0px'
		},
		'& img': {
			width: '14px',
			height: '14px'
		},
		'& svg': {
			width: '18px',
			height: '18px'
		}
	},
	menuButton: {
		minWidth: '37px',
		border: '1px solid var(--primary-default)',
		height: '32px',
		marginLeft: '15px',
		borderRadius: '4px',
		display: 'flex',
		alignItems: 'center',
		justifyContent: 'center',
		'@media (max-width: 1220px)': {
			marginLeft: '0px'
		},
	},
	adjustCardFieldsInline: {
		display: 'grid !important',
		width: '100%',
		gridTemplateColumns: 'auto auto',
		paddingRight: '22px'
	},
	buttonActionsSecondChild: {
		marginRight: '15px',
		'& .MuiButton-outlinedPrimary': {
			width: '100%',
			height: '28px'
		}
	},
});

class Header extends React.Component {
	constructor() {
		super();
		this.state = {
			expfieldName: false,
			tabValue: 1,
			expfieldDetailsArray: false,
			actionList: [...CONTEXT_MENU_HEADER_EXPFIELD_ACTIONS],
			isOpenActionsContextMenu: false,
			isOpenActions: false,
			actionMenuRef: null,
			menuRef: null,
		}
		this.setIsOpenActionsContextMenu = this.setIsOpenActionsContextMenu.bind(this);
		this.setIsOpenActionsButtonContextMenu = this.setIsOpenActionsButtonContextMenu.bind(this);
		this.onClickDownArrow = this.onClickDownArrow.bind(this);
		this.onClickUpArrow = this.onClickUpArrow.bind(this);
		this.getLabelValue = this.getLabelValue.bind(this);
	}

	getLabelValue(id) {
		return <FormattedMessageComponent id={id}></FormattedMessageComponent>;
	}

	handleDisableUpArrow = () => {
		const { hasPrevious, fromListPage } = this.props;
		return !hasPrevious || fromListPage != EXPFIELDS_LIST_PAGE;
	};

	handleDisableDownArrow = () => {
		const { hasNext, fromListPage } = this.props;
		return !hasNext || fromListPage != EXPFIELDS_LIST_PAGE;
	};

	setIsOpenActionsContextMenu = event => {
		this.setState({ isOpenActionsContextMenu: Boolean(event) });
		this.setState({ menuRef: event.currentTarget ? event.currentTarget : event });
	}

	setIsOpenActionsButtonContextMenu = event => {
		this.setState({ isOpenActions: Boolean(event) });
		this.setState({ actionMenuRef: event.currentTarget ? event.currentTarget : event });
	}

	onClickDownArrow() {
		const { rowIndex, totalCount } = this.props;
		this.props.handleExpfieldHeaderLeftArrowClick(rowIndex, totalCount);
	}

	onClickUpArrow() {
		const { rowIndex, totalCount } = this.props;
		this.props.handleExpfieldHeaderRightArrowClick(rowIndex, totalCount);
	}

	handleActionSelection = action => {
		const { currentRecordData } = this.props
		switch (action) {
			case "delete":
				this.props.handleConfirmBeforeSubmit(true)
				break;
		}
	};
	setIsActionClose = () => {
		this.setState({ isOpenActions: false });
	};

	render() {
		const { classes, handleExpfieldHeaderFilterClick, handleExpfieldHeaderSaveClick, handleChangeValue,expfieldData, currentOwnerName, globalDateFormat, filterCriteriaDetails, columnDefs, currentPage, canUpdateComponent,
			globalFilterOptions, pageFilterOptions, saveDisabled, isShowContextMenu, selectedValue, removeChildCutdownTab, contextMenu, onContextMenuChange, currentRecordData, freezeComponentStyle } = this.props;
			
		let dislockfld = false;
		let fldarr = descFieldArray;
		fldarr[0].disabled = false;
		let displayDelete = this.state.actionList;
		displayDelete[0].isDisable = false;
		if (currentOwnerName != false && expfieldData.EFOWNR != currentOwnerName){
			dislockfld = true;
			if (expfieldData.EFLOCK == '1'){
				fldarr[0].disabled = true;
				displayDelete[0].isDisable = true;
			}
		}

		let dsptype = expfieldData.EFTYPE;
		switch (expfieldData['EFTYPE']) {
			case 'IT':
				dsptype = 'IT - Item';
				break;
			case 'VN':
				dsptype = 'VN - Vendor';
				break;
			case 'OR':
				dsptype = 'OR - Order';
				break;
			case 'AX':
				dsptype = 'AX - Archived Exceptions';
				break;
			case 'EX':
				dsptype = 'EX - Exceptions';
				break;
		}

		return (
			<div className={classes.propertiesHeaderContainer} style={freezeComponentStyle}>
				<div className={classes.boookingDetailContainer}>
					<Box className={classes.boookingDetailDetailsWrapper}>
						<Box className={classes.bookingArrowWrapper}>
							<Button color="primary" onClick={() => this.onClickUpArrow()} className={classes.boookingArrow} disabled={this.handleDisableUpArrow()}>
								<KeyboardArrowUpIcon />
							</Button>
							<Button color="primary" onClick={() => this.onClickDownArrow()} className={classes.boookingArrow} disabled={this.handleDisableDownArrow()}>
								<KeyboardArrowDownIcon />
							</Button>
						</Box>
						<Box className={classes.vendorDetailRow}>
							<div className={classes.vendorIDSubID}>
								<div className={classes.vendorDetail}>
									<div className={classes.vendorIDBlock}>
										<div className={`${classes.vendorDetail} ${classes.vendorIdDetails11}`}>
											<div className={classes.vendorLabel11}>
												{this.getLabelValue(LABEL_EXF_REFERENCE)}
											</div>
											<div> {expfieldData.EFREFN}</div>
										</div>
										<div className={`${classes.vendorDetail} ${classes.vendorIdDetails}`}>
											<div className={classes.vendorLabel}>
												{this.getLabelValue(LABEL_EXF_DESCRIPTION)}
											</div>
											<div className={classes.vendorLabel}>
												<FormFieldsGenerator
													key={DESC_KEY}
													className={classes.vendorNameInput}
													isHeader
													fieldsArray={fldarr}
													valuesArray={expfieldData}
													handleSubmitDataCallBack={() => { }}
													handleChangeValue={(key, val) => this.props.handleChangeValue(key, val)}
													enableAddButton={() => { }}
													currentPage={currentPage}
													noMassMaintenance
													hideLabels></FormFieldsGenerator>
											</div>
										</div>
										<div className={`${classes.vendorDetail} ${classes.vendorIdDetails11}`}>
											<div className={classes.vendorLabel11}>
												{this.getLabelValue(LABEL_EXF_OWNER)}
											</div>
											<div> {expfieldData.EFOWNR}</div>
										</div>
										<div className={`${classes.vendorDetail} ${classes.vendorIdDetails11}`}>
											<div className={classes.vendorLabel11}>
												{this.getLabelValue(LABEL_EXF_TYPE)}
											</div>
											<div> {dsptype} </div>
										</div>
										<div className={`${classes.vendorDetail} ${classes.vendorIdDetails11}`}>
											<div className={classes.vendorLabel11}>
												{this.getLabelValue(LABEL_EXF_LOCK)}
												<FieldInput field={{ type: 'checkbox', key: 'EFLOCK' }}
												value={(expfieldData['EFLOCK'] && Number(expfieldData['EFLOCK'])) || 0} 
												onChange={(key, val) => this.props.handleChangeValue(key, val)}
												disabled={dislockfld} />
											</div>
										</div>
									</div>
								</div>
							</div>
						</Box>

						<Box className={classes.bookingActions}>
							<div className={classes.buttonActions}>
							</div>
							<Button component="div" color="primary" onClick={handleExpfieldHeaderFilterClick} className={classes.bookingActionsFilter}>
								<img src={FilterIcon} alt="Filter Icon" />
							</Button>
							<Button component="div" color="primary" onClick={handleExpfieldHeaderSaveClick} disabled={saveDisabled} className={classes.bookingActionsFilter}>
								<SaveIcon fontSize="large" />
							</Button>
							<div className={classes.menuButton}
								onMouseEnter={(event) => this.setIsOpenActionsButtonContextMenu(event)}
								onMouseLeave={() => this.setIsOpenActionsButtonContextMenu(false)}>
								<MoreVertIcon color="primary" className="cPointer"></MoreVertIcon>
								<ContextMenuCreateNew
									className={classes.ActionsContextMenu}
									menuList={displayDelete}
									isOpen={this.state.isOpenActions}
									menuRef={this.state.actionMenuRef}
									handleItemSelection={(val) => this.handleActionSelection(val)}
									handleMenuClose={(val) => this.setIsActionClose(val)}
									currentPage={currentPage}
									currentRecord={currentRecordData}
									>
								</ContextMenuCreateNew>
							</div>
						</Box>
					</Box>
				</div>
			</div>
		);
	}
}

export default injectIntl(withStyles(style)(withFixedPosition(Header)));

import React, { Component } from 'react';
import MultiSourceDistribution from 'containers/ItemEmbeddedListContainers/MultiSourceDistribution';
class MultiSourceDistributionDialog extends Component {
    render() {
        return (
            <>
                {
                    this.props.isOpen &&
                    <MultiSourceDistribution
                        ItemPropertiesData={this.props.ItemPropertiesData}
                        closeDialog={this.props.closeDialog}
                        isOpen={this.props.isOpen}
                        getLabelValue={this.props.getLabelValue}
                        errorMessageLabels={this.props.errorMessageLabels}
                        loadItemDetails={this.props.loadItemDetails}
                        closeDialog={this.props.closeDialog}
                        item={this.props.itemData}
                        multiSourceOrderDeatailLabelsData={this.props.multiSourceOrderDeatailLabelsData}
                        balanceDetails={this.props.balanceDetails}
                        pageProps={this.props.pageProps}
                    />
                }
            </>);
    }
}
export default MultiSourceDistributionDialog;
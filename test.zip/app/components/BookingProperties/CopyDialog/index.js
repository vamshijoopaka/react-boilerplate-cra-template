import React, { Component } from 'react';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import { withStyles, Box, Typography } from '@material-ui/core';
import DialogComponent from 'components/common/DialogComponent';
import theme from '../../../jda-gcp-theme';
import FormattedMessageComponent from '../../common/FormattedMessageComponent';
import FormFieldsGenerator from '../../common/FormFieldsGenerator';
import EmbeddedList from 'containers/common/EmbeddedList';
import Spinner from 'components/Common/Spinner';
import FieldInput from 'components/common/Form/FieldInput';
import {
	DIALOG_TITLE_COPY, TEXT_COPY,
	TO_BOOKING, BOOKING_INFORMATION, WAREHOUSE,
	ITEM, VENDOR_ID, SHIP_DATE_TO_CUSTOMER, CUSTOMER_ID,
	MENU_ITEMS, BOOKINGS_FILTER_VALUES, BOOKINGS,
	TO_WAREHOUSES, WAREHOUSE_PAGE, ITEMS_PAGE
} from "./constants";
import { TEXT_CANCEL, TEXT_ALERT, TEXT_OK } from '../../common/constants';
import { INITIAL_PAGE_PROPS } from 'components/common/constants';
import { getListPredecessor, getDateFormatValue } from 'utils/util';
import reducer from './reducer';
import saga from './saga';
import ConfirmationDialog from 'components/common/ConfirmationDialog';
import {
	rowDataSelector,
	columnDefsSelector,
	loadingSelector,
	columnFlagSelector,
	pagePropsSelector,
	filterPropsSelector,
	columnInfoSelector,
	isAPIProgressSelector,
	totalCountSelector,
	moreRecordsSelector,
	apiCallCountSelector,
	updateColumnsListSelector,
	errorMessageLabels,
	itemsListSelector,
	makeSelectBookingCopy
} from './selector';
import {
	getBookingCopyList,
	setApiCallCount,
	onSetPageProps,
	getBookingCopyColumnDefs,
	setFilterValues,
	setColumnDefsLoaded,
	updateShowHide,
	resetStateData,
	resetDefault,
	getItemsList,
	setLabelDataFlags
} from './action';

const styles = theme => ({
	adjustDialog1: {
		maxHeight: '93vh',
		'& .MuiDialogContent-root': {
			padding: '12px'
		},
	},
	notesForBlock: {
		display: 'flex',
		flexDirection: 'column',
		marginTop: '25px',
		border: '1px solid var(--divider-line)',
		padding: '10px 10px 0 10px',
		position: 'relative'
	},
	notesForLabel: {
		position: 'absolute',
		top: '-7px',
		left: '10px',
		background: 'var(--background-content)',
		padding: '0 8px',
	},
	adjustCardFieldsInline: {
		display: 'grid !important',
		width: '100%',
		gridTemplateColumns: 'auto auto',
	},
	fieldLabel: {
		color: 'var(--header-label-color)',
		padding: '0 0px 8px 0',
		width: '22ch',
	},
	childBlock: {
		display: 'flex',
		padding: '6px'
	},
	adjustShowDetail: {
		display: 'flex',
		bottom: '10px',
		left: '22px',
		position: 'fixed'
	},
	fieldValue: {
		color: 'var(--value)'
	},
	fieldValuesParent: {
		display: 'flex'
	},
	idValue: {
		marginRight: '20px',
		minWidth: '15ch'
	},
	showDetail: {
		paddingTop: '10px',
	}
});

class CopyDialog extends Component {
	constructor(props) {
		super(props);
		this.state = {
			selectAllFlag: false,
			selectedCount: 0,
			selectedRecordsObject: {},
			menuItems: [...MENU_ITEMS],
			rowSelection: 'multiple',
			selectedRows: false,
			valueArrayToBooking: {},
			valueDataFailureMessages: [],
			showValueConfirmationDialog: false,
		}
		this.handleValueDataErrorMessages = this.handleValueDataErrorMessages.bind(this);
	}
	getLabelValue(id) {
		return <FormattedMessageComponent id={id}></FormattedMessageComponent>;
	}
	setAssociativeArrayObject = (rowData) => {
		const { apiCallCount, pageProps } = this.props;
		let str = apiCallCount + "buffer";
		let data = this.state.selectedRecordsObject;
		if (data && Object.keys(data) && rowData && rowData.length) {
			for (let key in data) {
				let recordData = data[key];
				if (recordData && recordData.length && (key == str)) {
					recordData.forEach((record, index) => {
						rowData[index]["isSelected"] = record.isSelected;
					})
				}
			}
		}
		data[str] = rowData;
		this.setState({ selectedRecordsObject: data })
	}

	updateSelectAllFlag = (flag) => {
		const { rowData = [] } = this.props;
		this.setState({ selectAllFlag: flag, selectedCount: flag ? rowData.length : 0 });
	}
	changeValuesOnSelectDeselect = (flag) => {
		let recordObj = this.state.selectedRecordsObject;
		if (recordObj && Object.keys(recordObj)) {
			for (let key in recordObj) {
				if (recordObj[key] && recordObj[key].length) {
					recordObj[key].forEach((record, index) => {
						record.isSelected = flag;
					})
				}
			}
		}
		this.setState({ selectedRecordsObject: recordObj })
	}

	onRowSelected = (event) => {
		if (this.grid && this.grid.api) {
			const { apiCallCount, pageProps } = this.props;
			const { actualPageSize, actualPage } = pageProps;
			let data = this.state.selectedRecordsObject;
			if (data && Object.keys(data) && Object.keys(data).length) {
				let key = apiCallCount + "buffer";
				let rowIndex = (event.rowIndex + (actualPageSize * actualPage)) % 100;
				const { selected } = event.node;
				data[key][rowIndex]['isSelected'] = selected;
				this.setState({ selectedRecordsObject: data });
				this.setState((state) => ({ selectedCount: this.grid.api.getSelectedRows().length || 0 }))
			}
		}
	}
	getApiObj = (filterProps, record, pageProps, currentPage) => {
		let apiObj = {
			filterProps, filterProps,
			pageProps: pageProps,
			direction: pageProps.isForwardDirection,
			record: record,
			currentPage: currentPage
		};
		return apiObj;
	}

	setPageForwardDirection = (flag) => {
		let initialPageData = {
			...INITIAL_PAGE_PROPS,
			actualPage: 0,
			currentPage: 0,
			totalCount: 10,
			isForwardDirection: flag
		};
		this.setState({ initialPageData: initialPageData });
		this.props.onSetPageProps(initialPageData);
	}

	componentWillUnmount() {
		this.props.setColumnDefsLoaded(false);
		this.props.resetStateData(false)
	}

	componentDidMount() {
		const { headerJson, bookingDetailData } = this.props;
		let valueArrayToBooking = { ...bookingDetailData }
		valueArrayToBooking["BKTDAT"] = valueArrayToBooking["BKSDAT"];
		valueArrayToBooking["BKTCSD"] = valueArrayToBooking["BKCSID"];
		valueArrayToBooking["showDetail"] = 0;
		this.setState({ valueArrayToBooking });

		let filterData = [...BOOKINGS_FILTER_VALUES];
		this.props.setFilterValues(filterData);
		this.setPageForwardDirection(true);
		this.props.getBookingCopyColumnDefs({ type: BOOKINGS });
	}

	componentDidUpdate(prevProps, prevState) {
		const { columnDefs, rowData, isColumnDefsLoaded, filterProps, pageProps, updateColumnsList } = this.props;
		const { valueArrayToBooking } = this.state;
		const {
			isAPIforBookingCopyList,
			isAPIforColumns,
			isAPIforColumnsUpdate,
			isAPIforResetColumns,
			isAPIforItemList,
			resetDefaultsCols 
		} = this.props.bookingCopy

		if (this.state.valueDataFailureMessages && this.state.valueDataFailureMessages.length
			&& (JSON.stringify(this.state.valueDataFailureMessages) != JSON.stringify(prevState.valueDataFailureMessages))) {
			this.handleValueDataErrorMessages(this.state.valueDataFailureMessages[0]);
		}
		if (isAPIforBookingCopyList && (isAPIforBookingCopyList != prevProps.bookingCopy.isAPIforBookingCopyList)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to fetch Warehouse List");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isAPIforBookingCopyList', value: false });
		}

		if (isAPIforColumns && (isAPIforColumns != prevProps.bookingCopy.isAPIforColumns)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to fetch columns For Warehouse Embeddedlist");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isAPIforColumns', value: false });
		}

		if (isAPIforColumnsUpdate && (isAPIforColumnsUpdate != prevProps.bookingCopy.isAPIforColumnsUpdate)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to update columns For Warehouse Embeddedlist");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isAPIforColumnsUpdate', value: false });
		}

		if (isAPIforResetColumns && (isAPIforResetColumns != prevProps.bookingCopy.isAPIforResetColumns)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to Rest columns For Warehouse Embeddedlist");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isAPIforResetColumns', value: false });
		}

		if (isAPIforItemList && (isAPIforItemList != prevProps.bookingCopy.isAPIforItemList)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to fetch Items List");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isAPIforItemList', value: false });
		}

		let filterData = [...BOOKINGS_FILTER_VALUES];
		filterData.push({ "accessor": "VNDR", "operator": "=", "jOpr": "and", "fieldValue": valueArrayToBooking["BKVNDR"], "prefixFlag": 0 });
		filterData.push({ "accessor": "ITEM", "operator": "=", "jOpr": "and", "fieldValue": valueArrayToBooking["BKITEM"], "prefixFlag": 0 });

		if ((pageProps != prevProps.pageProps) && pageProps.isPageSizeChanged) {
			let initialPageData = {
				...pageProps,
				actualPage: 0,
				currentPage: 0,
				totalCount: 10,
				isForwardDirection: true,
			};
			this.props.onSetPageProps({
				...pageProps,
				isPageSizeChanged: false
			});
			this.props.setApiCallCount(0);
			this.props.getBookingCopyList(this.getApiObj(filterProps, false, initialPageData, WAREHOUSE_PAGE));
			this.props.getItemsList(this.getApiObj(filterData, false, initialPageData, ITEMS_PAGE));
		}

		if (columnDefs != prevProps.columnDefs && isColumnDefsLoaded != prevProps.isColumnDefsLoaded) {
			if (isColumnDefsLoaded) {
				this.props.getBookingCopyList(this.getApiObj(filterProps, false, pageProps, WAREHOUSE_PAGE));
				this.props.getItemsList(this.getApiObj(filterData, false, pageProps, ITEMS_PAGE));
			}
		}

		if (rowData != prevProps.rowData) {
			this.setAssociativeArrayObject(rowData)
		}

		if ((updateColumnsList != prevProps.updateColumnsList) && updateColumnsList) {
			this.props.getBookingCopyColumnDefs({ type: BOOKINGS });
		}
		if ((resetDefaultsCols != prevProps.bookingCopy.resetDefaultsCols) && resetDefaultsCols) {
			this.props.setLabelDataFlags({ key: 'resetDefaultsCols', value: false });
			this.props.updateShowHide({ type: BOOKINGS, actionCode:"D" });
		}
		if ((prevState.selectAllFlag != this.state.selectAllFlag) || prevState.selectedCount != this.state.selectedCount) {
			if (this.state.selectAllFlag) {
                let deselectAllDisable = false, selectAllDisable = true;
                this.disableMenuItem(deselectAllDisable, selectAllDisable);
            }
            else if (!this.state.selectedCount) {
                let deselectAllDisable = true, selectAllDisable = false;
                this.disableMenuItem(deselectAllDisable, selectAllDisable);
            }
            else {
                this.disableMenuItem(false);
            }
		}
	}
	disableMenuItem = (deselectAllDisable, selectAllDisable) => {
        this.setState({
            menuItems: MENU_ITEMS.map(row => {
                let item = { ...row };
                if (item.key == 'deselectAll')
                    item.isDisable = deselectAllDisable;
                else if (item.key == 'selectAll' && selectAllDisable != undefined)
                    item.isDisable = selectAllDisable;
                return item;
            })
        })
    }
	getSelectedRowsForAPI = () => {
		let selectedRows = [];
		let recordObj = this.state.selectedRecordsObject;
		if (recordObj && Object.keys(recordObj)) {
			for (let key in recordObj) {
				let dataRecord = recordObj[key];
				if (dataRecord && dataRecord.length) {
					dataRecord.forEach((record) => {
						if (record.isSelected) {
							selectedRows.push(record);
						}
					})
				}
			}
		}
		return selectedRows;
	}

	handleSubmit = () => {
		let rowdata = this.getSelectedRowsForAPI();
		const { items } = this.props;
		let selectedRows = rowdata.filter(row => items.find(item => item.IWHSE === row.WWHSE));
		const { valueArrayToBooking, selectAllFlag } = this.state
		const showDetailCheck = Boolean(valueArrayToBooking["showDetail"])
		let finalArray = [];
		let listParams = {};
		if (selectAllFlag) {
			let row = [];
			row.push(selectedRows[0])
			finalArray = this.prepareData(row)
			listParams = this.prepareListParamsCopyAll(selectedRows, valueArrayToBooking);
			this.props.onCopyAll({ ...finalArray[0] }, showDetailCheck, listParams)
			this.handleClose();
		} else {
			finalArray = this.prepareData(selectedRows)
			listParams = showDetailCheck ? this.prepareListParams(selectedRows, valueArrayToBooking) : {}
			this.props.onSubmit(finalArray, showDetailCheck, listParams);
			this.handleClose();
		}
	}
	prepareData = data => {
		let dataArray = []
		const { valueArrayToBooking } = this.state
		const { headerJson } = this.props;
		data.forEach(row => {
			let obj = {};
			obj["BCFCMP"] = "E3T",
				obj["BCFWHS"] = headerJson["BKWHSE"];
			obj["BCFITM"] = headerJson["BKITEM"];
			obj["BCFCSD"] = valueArrayToBooking["BKCSID"],
				obj["BCFDAT"] = valueArrayToBooking["BKSDAT"],
				obj["BCTCMP"] = "E3T",
				obj["BCTWHS"] = row["WWHSE"]
			obj["BCTITM"] = headerJson["BKITEM"];
			obj["BCTCSD"] = valueArrayToBooking["BKTCSD"],
				obj["BCTDAT"] = valueArrayToBooking["BKTDAT"],
				obj["BCMCPY"] = ''
			obj["BCRPLC"] = ''
			dataArray.push(obj);
		});
		return dataArray;
	}
	prepareListParams = (rowData, keyData) => {
		let firstRow = rowData[0];
		const { headerJson } = this.props;
		let filterProps = [{ "accessor": "COMP", 'prefixFlag': 0, "operator": "=", "jOpr": "and", "fieldValue": "E3T" },
		{ "accessor": "VNDR", 'prefixFlag': 0, "operator": "=", "jOpr": "and", "fieldValue": headerJson["BKVNDR"] },
		{ "accessor": "ITEM", 'prefixFlag': 0, "operator": "=", "jOpr": "and", "fieldValue": headerJson["BKITEM"] },
		{ "accessor": "SDAT", 'prefixFlag': 0, "operator": "=", "jOpr": "and", "fieldValue": keyData["BKTDAT"] },
		{ "accessor": "CSID", 'prefixFlag': 0, "operator": "=", "jOpr": "and", "fieldValue": keyData["BKTCSD"] },
		{ "accessor": "WHSE", 'prefixFlag': 0, "operator": "=", "jOpr": "and", "fieldValue": firstRow["WWHSE"] }
		];
		let pageProps = { pageSize: 3 }
		return {
			filterProps, pageProps, direction: true, currentPage: 'bookings'
		}
	}
	prepareListParamsCopyAll = (rowData, keyData) => {
		let firstRow = rowData[0];
		const { headerJson } = this.props;
		let filterData = [{ "accessor": "ICOMP", 'prefixFlag': 1, "operator": "=", "jOpr": "and", "fieldValue": "E3T" }];
		filterData.push({ "accessor": "IVNDR", "operator": "=", "jOpr": "and", "fieldValue": headerJson["BKVNDR"], "prefixFlag": 1 });
		filterData.push({ "accessor": "IITEM", "operator": "=", "jOpr": "and", "fieldValue": headerJson["BKITEM"], "prefixFlag": 1 });

		let pageFilter = [...BOOKINGS_FILTER_VALUES];
		pageFilter.push({ "accessor": "VNDR", 'prefixFlag': 0, "operator": "=", "jOpr": "and", "fieldValue": headerJson["BKVNDR"] });
		pageFilter.push({ "accessor": "ITEM", 'prefixFlag': 0, "operator": "=", "jOpr": "and", "fieldValue": headerJson["BKITEM"] });
		pageFilter.push({ "accessor": "SDAT", 'prefixFlag': 0, "operator": "=", "jOpr": "and", "fieldValue": keyData["BKTDAT"] });
		pageFilter.push({ "accessor": "CSID", 'prefixFlag': 0, "operator": "=", "jOpr": "and", "fieldValue": keyData["BKTCSD"] });
		pageFilter.push({ "accessor": "WHSE", 'prefixFlag': 0, "operator": "=", "jOpr": "and", "fieldValue": firstRow["WWHSE"] });

		let pageProps = { pageSize: 3 }
		return {
			filterProps: filterData, pageProps, direction: true, currentPage: 'bookings', pageFilter
		}
	}
	handleClose = () => {
		this.props.handleCopyDeletePopup('openCopyPopup', false)
	}

	onGridReady = (params) => {
		this.grid = params;
	}
	handleChangeValue = (key, val) => {
		const valueArrayToBooking = { ...this.state.valueArrayToBooking };
		valueArrayToBooking[key] = val;
		this.setState({ valueArrayToBooking });
	}

	closeValueDialog = () => {
		this.setState({ showValueConfirmationDialog: false });
		if (this.state.valueDataFailureMessages && this.state.valueDataFailureMessages.length) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.shift();
			this.setState({ valueDataFailureMessages: values });
			if (values && values.length == 0) {
				this.handleClose();
			}
		}
	}
	handleValueDataErrorMessages(content) {
		this.setState({ showValueConfirmationDialog: true, dialogContent: content });
	}

	render() {
		const { classes, globalDateFormat, filterCriteriaDetails,
			pageFilterOptions, globalFilterOptions, columnDefs, currentOwnerName,
			currentPage, canUpdateComponent, loading, copyLabels, rowData, headerJson, bookingDetailData, items, apiCallCount } = this.props;
		const { tabcards } = copyLabels;
		const { valueArrayToBooking } = this.state;
		return (
			<DialogComponent
				className={classes.adjustDialog1}
				isOpen={this.props.openCopyPopup}
				dialogTitle={this.getLabelValue(DIALOG_TITLE_COPY)}
				cancelText={TEXT_CANCEL}
				submitText={TEXT_COPY}
				handleClose={e => this.handleClose()}
				handleCancel={e => this.handleClose()}
				handleSubmit={() => this.handleSubmit()}
				disableSubmit={(this.getSelectedRowsForAPI() && this.getSelectedRowsForAPI().length) ? false : true}>
				<React.Fragment>
					<div className={classes.notesForBlock}>
						<Box mb={theme.spacing(0.5)} className={classes.notesForLabel}>
							<FormattedMessageComponent id={BOOKING_INFORMATION}></FormattedMessageComponent>
						</Box>
						<Box className={classes.childBlock}>
							<div className={classes.fieldLabel}>{this.getLabelValue(VENDOR_ID)}</div>
							<div className={classes.fieldValuesParent}>
								<Typography className={classes.fieldValue + ' ' + classes.idValue}>{headerJson["BKVNDR"]}</Typography>
								<Typography className={classes.fieldValue + ' ' + classes.idValue}>{headerJson["BKSUBV"]}</Typography>
								<Typography className={classes.fieldValue + ' ' + classes.idValue}>{headerJson["VNAME"]}</Typography>
							</div>
						</Box>
						<Box className={classes.childBlock}>
							<div className={classes.fieldLabel}>{this.getLabelValue(ITEM)}</div>
							<div className={classes.fieldValuesParent}>
								<Typography className={classes.fieldValue + ' ' + classes.idValue}>{headerJson["BKITEM"]}</Typography>
								<Typography className={classes.fieldValue + ' ' + classes.idValue}>{headerJson["INAME"]}</Typography>
							</div>
						</Box>
						<Box className={classes.childBlock}>
							<div className={classes.fieldLabel}>{this.getLabelValue(WAREHOUSE)}</div>
							<div className={classes.fieldValuesParent}>
								<Typography className={classes.fieldValue + ' ' + classes.idValue}>{headerJson["BKWHSE"]}</Typography>
								<Typography className={classes.fieldValue + ' ' + classes.idValue}>{headerJson["WNAME"]}</Typography>
							</div>
						</Box>
						<Box className={classes.childBlock}>
							<div className={classes.fieldLabel}>{this.getLabelValue(SHIP_DATE_TO_CUSTOMER)}</div>
							<Typography className={classes.fieldValue + ' ' + classes.idValue}>{(Number(bookingDetailData["BKSDAT"])) && getDateFormatValue(bookingDetailData["BKSDAT"])}</Typography>
							<div className={classes.fieldLabel}>{this.getLabelValue(CUSTOMER_ID)}</div>
							<Typography className={classes.fieldValue + ' ' + classes.idValue}>{bookingDetailData["BKCSID"]} </Typography>
						</Box>
					</div>
					<div className={classes.notesForBlock}>
						<Box mb={theme.spacing(0.5)} className={classes.notesForLabel}>
							<FormattedMessageComponent id={TO_BOOKING}></FormattedMessageComponent>
						</Box>
						{!loading && valueArrayToBooking && tabcards && tabcards.map(formCard => {
							if (formCard.cardkey == TO_BOOKING) {
								return <FormFieldsGenerator
									labelDisplayCharacters={22}
									valueDisplayCharacters={18}
									className={classes.adjustCardFieldsInline}
									currentOwnerName={currentOwnerName}
									handleSubmitDataCallBack={() => { }}
									key={formCard.cardkey}
									fieldsArray={JSON.parse(JSON.stringify(formCard.cardfields))}
									valuesArray={JSON.parse(JSON.stringify(valueArrayToBooking))}
									handleChangeValue={(key, val) => { this.handleChangeValue(key, val) }}
									enableAddButton={() => { }}
									globalDateFormat={globalDateFormat}
									filterCriteriaDetails={filterCriteriaDetails}
									pageFilterOptions={pageFilterOptions}
									globalFilterOptions={globalFilterOptions}
									columnDefs={columnDefs}
									currentPage={currentPage}
									canUpdateComponent={canUpdateComponent}
									noMassMaintenance={true}
								/>
							}
						})}

						{!loading && columnDefs && columnDefs.length && rowData && rowData.length ?
							<EmbeddedList
								embeddedListTitle={this.getLabelValue(TO_WAREHOUSES)}
								pageProps={this.props.pageProps}
								columnInfo={this.props.columnInfo}
								selectAllFlag={this.state.selectAllFlag}
								updateSelectAllFlag={this.updateSelectAllFlag}
								selectedRecordsObject={this.state.selectedRecordsObject}
								hasSelectDeselectAll={true}
								changeValuesOnSelectDeselect={this.changeValuesOnSelectDeselect}
								updateMenuItems={() => { }}
								suppressRowClickSelection={true}
								onRowSelected={this.onRowSelected}
								props={this.props}
								listProps={this.props}
								currentPage={"bookingsCopy"}
								listPredecessor={getListPredecessor("warehouses")}
								rowSelection={this.state.rowSelection}
								suppressSizeToFit={true}
								nameSpace={"bookingsCopy"}
								onGridReady={this.onGridReady}
								rowData={rowData.filter(row => items.find(item => item.IWHSE === row.WWHSE))}
								updateShowHide={(data, currentPage) => this.props.updateShowHide(data, 'bookingsCopy')}
								menuItems={this.state.menuItems}
								onSelectAll={(data) => this.onSelectAll(data)}
								columnDefs={columnDefs}
								gridHeight={'250px'}
								totalCount={apiCallCount * 100 + (rowData.filter(row => items.find(item => item.IWHSE === row.WWHSE)).length)}
								resetDefault={(data) => this.props.resetDefault(data)}
								hasGridActions={true}>
							</EmbeddedList> : <Spinner loading type="list" />}
					</div>
					<Box className={classes.adjustShowDetail}>
						<FieldInput field={{ type: 'checkbox', key: 'showDetail' }} value={Number(valueArrayToBooking["showDetail"])}
							onChange={(key, val) => this.handleChangeValue(key, val)} />
						<div className={classes.showDetail}>{this.getLabelValue("25566")}</div>
					</Box>
					{this.state.showValueConfirmationDialog && <ConfirmationDialog
						hasError={true}
						isOpen={this.state.showValueConfirmationDialog}
						dialogTitle={TEXT_ALERT}
						submitText={TEXT_OK}
						handleClose={e => this.closeValueDialog()}
						handleCancel={e => this.closeValueDialog()}
						handleSubmit={e => this.closeValueDialog()}
					>
						<div>
							{this.state.dialogContent}
						</div>
					</ConfirmationDialog>
					}
				</React.Fragment>
			</DialogComponent>
		);
	}
}
const mapStateToProps = createStructuredSelector({
	bookingCopy: makeSelectBookingCopy(),
	rowData: rowDataSelector(),
	columnDefs: columnDefsSelector(),
	loading: loadingSelector(),
	pageProps: pagePropsSelector(),
	isColumnDefsLoaded: columnFlagSelector(),
	filterProps: filterPropsSelector(),
	columnInfo: columnInfoSelector(),
	isAPIProgress: isAPIProgressSelector(),
	totalCount: totalCountSelector(),
	moreRecordsAvailable: moreRecordsSelector(),
	apiCallCount: apiCallCountSelector(),
	updateColumnsList: updateColumnsListSelector(),
	errorMessages: errorMessageLabels(),
	items: itemsListSelector(),
})

function mapDispatchToProps(dispatch, ownProps) {
	return {
		dispatch,
		getBookingCopyList: (data) => dispatch(getBookingCopyList(ownProps.nameSpace, data)),
		setApiCallCount: (data) => dispatch(setApiCallCount(ownProps.nameSpace, data)),
		onSetPageProps: (data) => dispatch(onSetPageProps(ownProps.namespace, data)),
		getBookingCopyColumnDefs: (data) => dispatch(getBookingCopyColumnDefs(ownProps.nameSpace, data)),
		setFilterValues: (data) => dispatch(setFilterValues(ownProps.nameSpace, data)),
		setColumnDefsLoaded: (data) => dispatch(setColumnDefsLoaded(ownProps.nameSpace, data)),
		updateShowHide: (data) => dispatch(updateShowHide(ownProps.nameSpace, data)),
		resetStateData: (data) => dispatch(resetStateData(ownProps.nameSpace, data)),
		resetDefault: (data) => dispatch(resetDefault(data)),
		getItemsList: (data) => dispatch(getItemsList(ownProps.nameSpace, data)),
		setLabelDataFlags: (data) => dispatch(setLabelDataFlags(ownProps.nameSpace, data)),
	}
}

const withConnect = connect(
	mapStateToProps,
	mapDispatchToProps,
);
const withReducer = injectReducer({ key: 'bookingCopyReducer', reducer });
const withSaga = injectSaga({ key: 'bookingCopySaga', saga });
export default compose(
	withReducer,
	withSaga,
	withConnect,
	withStyles(styles),
)(CopyDialog);
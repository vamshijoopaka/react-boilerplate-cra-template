import React, { useEffect } from 'react';
import { INITIAL_PAGE_PROPS } from '../../../../common/constants';
import {
    TableContainer,
    TableHead,
    Table,
    TableRow,
    TableCell,
    TableBody,
} from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import { getDateFormatted } from 'components/common/Form/dateTimeUtils';
import clsx from 'clsx';

const useStyles = makeStyles({
    tableContainer1: {
        width: 500,
        '& > table': {
            width: '100% !important',
        },
        float: 'left',
        overflow: 'hidden',
        '& th': {
            height: 28,
        },
        '& td': {
            height: 28,
        },
        marginBottom: '1.5rem',
    },
    tableContainer: {
        width: 'calc(100% - 500px)',
        float: 'right',
        '& td': {
            height: 28,
        },
        marginBottom: '1.5rem',
    },
    table: {
        width: 'calc(100% - 200px)',
    },
    tableCell1: {
        whiteSpace: 'nowrap',
        backgroundColor: '#f5f5f6',
        color: '#000000',
        border: 'solid 1px #000000',
        padding: 5,
        minWidth: 100,
        minHeight: 28,
    },
    tableCell2: {
        whiteSpace: 'nowrap',
        backgroundColor: '#FFFFFF',
        color: '#000000',
        border: 'solid 1px #000000',
        padding: 5,
        minWidth: 100,
        minHeight: 28,
    },
    tableHeaderCell: {
        textAlign: 'center',
    },
    tableCell: {
        textAlign: 'right',
    },
    selected: {
        backgroundColor: '#d3f0fa !important',
    },
});

const SuperItemHistoryTable = props => {
    const classes = useStyles();
    const { itemData, rolledTo13, columnDefs, rowData, getLabelFromId } = props;
    const period = itemData.IPERDF === '12' ? '12' : rolledTo13 ? '13' : '52';
    const prefix = ({
        '12': 'SM',
        '13': 'SP',
        '52': 'SW',
    })[period];
    const prepareListParams = () => {
        const filterProps = ['COMP', 'ITEM', 'WHSE', 'VNDR'].map(key => {
            if (itemData['I' + key]) {
                return { accessor: prefix + key, fieldValue: itemData['I' + key], operator: '=', prefixFlag: 1 };
            }
        }).filter(Boolean);
        return {
            pageProps: { ...INITIAL_PAGE_PROPS },
            direction: true,
            filterProps,
        }
    }
    useEffect(() => {
        const payload = {
            period,
            listParams: prepareListParams(),
            datesQuery: `KCOMP=${itemData.ICOMP}`,
            prefix,
            systemDate: props.systemDate,
            globalDateFormat: props.globalDateFormat,
        }
        props.getSuperItemHistory(payload);
    }, ['ICOMP', 'IITEM', 'IWHSE', 'IVNDR'].map(key => itemData[key]).concat(period))

    useEffect(() => {
        const tableElement = document.getElementById('superHistoryTable');
        tableElement.scrollLeft = tableElement.scrollWidth;
    }, [columnDefs])

    const getColumnLabel = columnDef => {
        if (/text|number/.test(columnDef?.dataType) && columnDef.labelId) {
            return getLabelFromId(columnDef.labelId);
        }
        if (columnDef?.dataType === 'date' && +columnDef.label) {
            return getDateFormatted(columnDef.label, period === '12' ? "MM/YYYY" : props.globalDateFormat);
        }
        return '';
    }

    return (
        <>
            <TableContainer className={classes.tableContainer1}>
                <Table>
                    <TableHead>
                        <TableRow>
                            {
                                columnDefs?.length ? columnDefs.map(columnDef => (columnDef.pinned &&
                                    <TableCell key={columnDef.key + 'header'} className={classes[`tableCell1`]} >
                                        {getColumnLabel(columnDef)}
                                    </TableCell>
                                ))
                                    : null
                            }
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {rowData?.length ? rowData.map((ele, index) => {
                            const i = index % 2 === 0 ? 2 : 1;
                            return (
                                <TableRow key={'fixedRow' + index} hover>
                                    {
                                        columnDefs?.length ? columnDefs.map(columnDef => (columnDef.pinned &&
                                            <TableCell className={classes[`tableCell${i}`]} >
                                                {ele[columnDef.key] === 'T' ? 'T - ' + getLabelFromId('2370') : ele[columnDef.key]}
                                            </TableCell>
                                        ))
                                            : null
                                    }
                                </TableRow>
                            )
                        }) : null}
                    </TableBody>
                </Table>
            </TableContainer>

            <TableContainer
                className={classes.tableContainer}
                id="superHistoryTable"
            >
                <Table className={classes.table}>
                    <TableHead>
                        <TableRow>
                            {columnDefs && columnDefs.length ? (
                                columnDefs.map(columnDef => (!columnDef.pinned &&
                                    <TableCell
                                        key={columnDef.key + 'header'}
                                        className={clsx(classes.tableCell1, classes.tableHeaderCell)}
                                    >
                                        {getColumnLabel(columnDef)}
                                    </TableCell>
                                ))
                            ) : null}
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {rowData?.length ?
                            rowData.map((ele, index) => {
                                const i = index % 2 === 0 ? 2 : 1;
                                return (
                                    <TableRow hover key={'scrollableRow' + index}>
                                        {columnDefs?.length ?
                                            columnDefs.map(columnDef => (!columnDef.pinned &&
                                                <TableCell className={clsx(classes[`tableCell${i}`], classes.tableCell)}
                                                    key={columnDef.key}
                                                >
                                                    {props.getFormattedNumber(ele[columnDef.key]) || ''}
                                                </TableCell>
                                            )) : null
                                        }
                                    </TableRow>
                                )
                            })
                            : null
                        }
                    </TableBody>
                </Table>
            </TableContainer>
        </>
    )
}

export default SuperItemHistoryTable;
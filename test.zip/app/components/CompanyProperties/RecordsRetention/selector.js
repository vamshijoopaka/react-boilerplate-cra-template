/** Change Log
 * LogStart --  E3C-33195 - Kumar A- 16 September,2021 - 2022.1.0.0 Unified Product
 *              Story: E3C-33195 --Code Cleanup
*/

const selectData = (state) => state.get('RecordRetentions');

export {
    selectData
};

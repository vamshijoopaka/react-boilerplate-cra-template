import HeaderMenu from "../common/FrameWorkComponents/HeaderMenu";

export const UPDATE_COLUMN_DEFS = 'UPDATE_COLUMN_DEFS';
export const frameWorkObj = {
    agColumnHeader: HeaderMenu
}
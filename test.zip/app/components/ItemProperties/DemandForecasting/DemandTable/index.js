import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import CheckIcon from '@material-ui/icons/Check';
import MoreVertIcon from '@material-ui/icons/MoreVert';
import {
  TableContainer,
  TableHead,
  Table,
  TableRow,
  TableCell,
  TableBody,
  Menu,
  MenuItem,
  Button,
} from '@material-ui/core';
import FormattedMessageComponent from '../../../common/FormattedMessageComponent';
import ContextMenu from '../../../common/ContextMenu';
import { ACTIONS_CONTEXT_MENU, superHistoryMenuItem, RADIO_OPTIONS } from './constants';
import SuperItemHistoryTable from './SuperItemHistoryTable';
import { FormControlLabel, Box } from '@material-ui/core';
import FieldInput from 'components/common/Form/FieldInput';
import SuperHistoryGraph from './SuperHistoryGraph';

const styles = () => ({  
  tableContainer1: {
    width: 165,
    '& > table': {
      width: '100% !important',
    },
    float: 'left',
    overflow: 'hidden',
    '& th': {
      fontWeight: 'bold',
      height: 28,
    },
    '& td': {
      height: 28,
    },
  },
  tableContainer: {
    width: 'calc(100% - 165px)',
    float: 'right',
    '& td': {
      height: 28,
    },
  },
  table1: {
    width: 200,
  },
  table: {
    width: 'calc(100% - 200px)',
  },
  tableHead: {
    color: '#000',
  },
  tableCell1: {
    whiteSpace: 'nowrap',
    backgroundColor: '#f5f5f6',
    color: '#000000',
    border: 'solid 1px #000000',
    padding: 5,
    minWidth: 100,
    minHeight: 28,
  },
  tableCell2: {
    whiteSpace: 'nowrap',
    backgroundColor: '#FFFFFF',
    color: '#000000',
    border: 'solid 1px #000000',
    padding: 5,
    minWidth: 100,
    minHeight: 28,
  },
  tableHeaderCell: {
    textAlign: 'center',
  },
  tableCell: {
    textAlign: 'right',
    cursor: 'pointer',
  },
  underline: {
    textDecoration: 'underline',
  },
  bold: {
    fontWeight: 600,
  },
  actions: {
    float: 'right',
  },
  selected: {
    backgroundColor: '#d3f0fa !important',
  },
  titleDisplay: {
    display: 'flex',
    alignItems: 'center',
    width: 'max-content',
    marginLeft: '1rem',
},
});

const checkIcon = <CheckIcon color="primary" />;

class DemandTable extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      mousepos: {
        mouseX: -1,
        mouseY: -1,
      },
      contextMenuOpen: false,
      date: '',
      ignoreHistoryCheck: null,
      selectedRow: '',
      selectedCell: '',
      menuItems: JSON.parse(JSON.stringify(ACTIONS_CONTEXT_MENU)),
      isContextMenuOpen: false,
      isItDisabled: false,
      week: 0,
      radioSelected: 'graph',
      disableRadio: false,
    };
  }

  componentDidMount(){
    const { canUpdateComponent, series, getIgnoreHistory } = this.props;

    if (getIgnoreHistory) {
      getIgnoreHistory();
    }

    if (canUpdateComponent && Object.keys(canUpdateComponent) && Object.keys(canUpdateComponent).length) {
      this.setMenuItems();
      if (!canUpdateComponent.update) 
        this.setState({ isItDisabled : true});
    }
    if (series?.length) {
      let tableElement = document.getElementById('demandTable');
      tableElement.scrollLeft = tableElement.scrollWidth;
    }
  }
  componentDidUpdate(prevProps) {
    const { series, historyIgnored, ignoreHistoryData, rolledTo13, itemData = {} } = this.props;
    if (series && JSON.stringify(series) !== JSON.stringify(prevProps.series)) {
      let tableElement = document.getElementById('demandTable');
      tableElement.scrollLeft = tableElement.scrollWidth;
    }
    if (historyIgnored && historyIgnored !== prevProps.historyIgnored) {
      this.props.getIgnoreHistory();
    }
    if (ignoreHistoryData && JSON.stringify(ignoreHistoryData) !== JSON.stringify(prevProps.ignoreHistoryData)) {
      if (this.state.selectedCell) {
        const { selectedRow, week } = this.state;
        this.onCellSelect(null, selectedRow, week - 1, week);
      }
      else if (this.state.selectedRow) {
        this.onRowSelect(this.state.selectedRow)();
      }
    }
    if (rolledTo13 !== prevProps.rolledTo13) {
      this.setState({ 
        selectedCell: '',
        selectedRow: '',
        ignoreHistoryCheck: null
    })
    }
    if (itemData.ISUPER && itemData.ISUPER !== prevProps.itemData.ISUPER
      || itemData.IPERDF && itemData.IPERDF !== prevProps.itemData.IPERDF
      || rolledTo13 !== prevProps.rolledTo13
      ) {
      this.setMenuItems();
    }
    if (this.props.show3Dots && JSON.stringify(itemData) !== JSON.stringify(prevProps.itemData)) {
      this.props.getIgnoreHistory?.();
      this.setState({
        ignoreHistoryCheck: null,
        selectedRow: '',
        selectedCell: '',
        ignoreYear: false,
        week: 0,
      })
    }
  }
  setMenuItems = () => {
    if (!this.props.show3Dots) return;
    let menuItems = JSON.parse(JSON.stringify(ACTIONS_CONTEXT_MENU));
    const { canUpdateComponent = {}, itemData = {}, rolledTo13, promoIncluded } = this.props;
    //Disable menu items if "no update" authority
    menuItems.forEach((menuItem) => {
      //RollTo13 and IncludePromo are always enalbed regardless of security;
      // menuItem.isDisable = canUpdateComponent.update ? false : true; //E3C30659-apply security restrictions in addition to field check 
      if (menuItem.key === 'rollTo13' && rolledTo13) {
        menuItem.isChecked = true;
      }
      if (menuItem.key === 'includePromo' && promoIncluded) {
        menuItem.isChecked = true;
      }
    });
    if (itemData?.IPERDF === '12') {
      menuItems = menuItems.filter(ele => ele.key !== 'rollTo13');//For 12-Monthly there is no rollTo13
    }
    if (/C|P|R/.test(itemData.ISUPER)) {
      const superHistoryChecked = this.state.menuItems.find?.(ele => ele.key === 'superItemHistory')?.isChecked;
      menuItems.push(JSON.parse(JSON.stringify({ ...superHistoryMenuItem, isChecked: !!superHistoryChecked})));

      const isConsistsOf = itemData.ISUPER === 'C';
      this.setState({ radioSelected: isConsistsOf ? 'detail' : 'graph', disableRadio: isConsistsOf ? true : false });

    } else {
      this.setState({ isOpenSuperItemHistory: false });
    }
    this.setState({ menuItems });
  }
  sum = cells => cells.reduce((sum, cell) => sum + cell, 0);

  onRightClick = (event, year, week) => {
    this.setState({
      mousepos: {
        mouseX: event.clientX,
        mouseY: event.clientY,
      },
      contextMenuOpen: true,
    });
  };

  onContextMenu = event => {
    event.preventDefault();
  };

  onMenuClick = () => {
    this.handleClose();
  };

  handleClose = () => {
    this.setState({
      contextMenuOpen: false,
    });
  };

  setIgnoreHistoryFlag = (event, period, year) => {
    this.setState({
      date: `${period}/${year}`,
    });
  };

  ignoreHistory = () => {
    const { itemData, ignoreHistoryData, rolledTo13 = false, isMonthly } = this.props;
    const { selectedRow, week, ignoreHistoryCheck, ignoreYear = false } = this.state;
    this.props.ignoreHistory({
      itemData,
      year: parseInt(selectedRow, 10),
      week,
      ignoreHistoryData,
      rolledTo13,
      ignoreCheck: !ignoreHistoryCheck ? '1' : '0',
      isMonthly,
      ignoreYear,
    });
  };

  onRowSelect = year => () => {
    if (!this.props.show3Dots) return;

    if (!isNaN(parseInt(year, 10))) {
      const { ignoreHistoryData = {} } = this.props;
      const ignoreCheck = ignoreHistoryData[year]?.every(ele => ele === '1') ? checkIcon : null;
      this.setState({
        selectedRow: year,
        selectedCell: '',
        ignoreHistoryCheck: ignoreCheck,
        ignoreYear: true,
      });
    }
  };

  onCellSelect = (event, year, index, week) => {

    if (!this.props.show3Dots) return;

    const { columnDefs, rolledTo13, ignoreHistoryData, isMonthly } = this.props;
    if (!isNaN(parseInt(year, 10))) {
      const ignoreFlag = ignoreHistoryData[year][index] === '1';

      if (!this.props.hideValuesFromCurrentDate({data: ignoreHistoryData[year][index], year, index, columnDefs})) return;

      let ignoreHistoryCheck = ignoreFlag ? checkIcon : null;
      if (rolledTo13) {
        let data = ignoreHistoryData[year];
        let indices = [
          4 * (index + 1) - 1, 
          4 * (index + 1) - 2, 
          4 * (index + 1) - 3, 
          4 * (index + 1) - 4, 
        ];
        ignoreHistoryCheck = indices.every(i => data[i] == '1') ? checkIcon : null; 
      }
      const selectedCell = isMonthly && !columnDefs[index] ? `${week}/${year}`: `${columnDefs[index] || ''}/${year}`;
      this.setState({
        selectedCell,
        selectedRow: year,
        ignoreHistoryCheck,
        week,
        ignoreYear: false
      });
    }
  };

  setIsOpenContextMenu = (evnt = false, type = '') => {
    this.setState({
      isContextMenuOpen: evnt ? true : false,
      [`menuRef${type}`]: evnt.currentTarget ? evnt.currentTarget : evnt,
    });
  };

  handleItemHeaderActionItemSelection = value => {
    const rollChecked = this.state.menuItems.find(ele => ele.key === 'rollTo13')?.isChecked;
    const promoChecked = this.state.menuItems.find(ele => ele.key === 'includePromo')?.isChecked;
    const superHistoryChecked = this.state.menuItems.find(ele => ele.key === 'superItemHistory')?.isChecked;
    const keyChecked = ({
      'rollTo13': rollChecked,
      'includePromo': promoChecked,
      'superItemHistory': superHistoryChecked,
    })[value]
    switch (value) {
      case 'rollTo13':
        if (!rollChecked) {
          promoChecked ? this.props.rollGraphTo13WithPromo() : this.props.rollGraphTo13();
        } else {
          promoChecked ? this.props.showWeeklyDataWithPromo() : this.props.showWeeklyData();
        }
        break;
      case 'includePromo':
        if (rollChecked) {
          !promoChecked ? this.props.rollGraphTo13WithPromo() : this.props.rollGraphTo13();
        } else {
          !promoChecked ? this.props.showWeeklyDataWithPromo() : this.props.showWeeklyData();
        }
        break;
      case 'superItemHistory': {
        this.setState({
          isOpenSuperItemHistory: !superHistoryChecked
        });break;
      }
      default:
        break;
    }
    this.setState(prevState => {
      return {
        menuItems: prevState.menuItems.map(ele => {
          if (ele.key === value) ele.isChecked = !keyChecked;
          return ele;
        })
      }
    })
  };
getIgnoreClass = (year, index) => {
  const { ignoreHistoryData: { [year]: data = false }, classes, rolledTo13, show3Dots } = this.props;
  if (!show3Dots) return '';
  if (!data) return '';
  if (rolledTo13) {
    // let week = Math.ceil(index / 4);
    let indices = [
      4 * (index + 1) - 1, 
      4 * (index + 1) - 2, 
      4 * (index + 1) - 3, 
      4 * (index + 1) - 4, 
    ];
    if (indices.every(i => data[i] === '1')) return classes.underline;
    if (indices.some(i => data[i] === '1')) return classes.bold;
    return '';
  }
   return data[index] === '1'? classes.underline : '';
}
handleSuperRadio = (key, value) => {
  this.setState({ radioSelected: value });
}
  render() {
    const { classes, series, columnDefs, ignoreHistoryData, show3Dots, getLabelFromId } = this.props;
    const yearlySeries =
      series && series.length ? series.filter(s => !isNaN(s.key)) : [];

    const compositeSeries = series.find(s => s.key === 'Composite');
    const { radioSelected, disableRadio } = this.state;
    return (
      <>
        <div style={{ height: 300 }}>
          <div style={{ height: 36 }}>
            <div
              onMouseEnter={(event) => this.setIsOpenContextMenu(event,'3dots')}
              onMouseLeave={(event) => this.setIsOpenContextMenu(false,'3dots')}
              style={{
                float: 'right',
                paddingTop: 9,
                display: show3Dots ? 'block' : 'none',
              }}
            >
              <MoreVertIcon color="primary" className="cPointer"></MoreVertIcon>
              <ContextMenu
                className={classes.menuButton}
                menuList={this.state.menuItems}
                isOpen={this.state.isContextMenuOpen}
                menuRef={this.state.menuRef3dots}
                handleItemSelection={val =>
                  this.handleItemHeaderActionItemSelection(val)
                }
                handleMenuClose={val => this.setIsOpenContextMenu(val,'3dots')}
              />
            </div>
            <div
              className={classes.actions}
              style={{
                visibility:
                  this.state.selectedRow || this.state.selectedCell
                    ? 'visible'
                    : 'hidden',
              }}
            >
              <Button
                variant="text"
                color="primary"
                onClick={this.ignoreHistory}
                disabled={this.state.isItDisabled}
              >
                <span style={{ paddingRight: 5 }}>
                  {this.state.ignoreHistoryCheck}
                </span>
                <FormattedMessageComponent id={27542} />
                <span style={{ paddingLeft: 5 }}>
                  {this.state.selectedCell
                    ? ` ${this.state.selectedCell}`
                    : ` ${this.state.selectedRow}`}
                </span>
              </Button>
            </div>
          </div>
          <div>
            <TableContainer className={classes.tableContainer1}>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell className={classes.tableCell1}  />
                  </TableRow>
                </TableHead>
                <TableBody>
                  {yearlySeries && yearlySeries.length ? yearlySeries.map((series, index) => {
                    const i = index % 2 === 0 ? 2 : 1;
                    return (
                      <TableRow>
                        <TableCell className={classes[`tableCell${i}`]} onClick={this.onRowSelect(series.key)} >
                          {series.name}
                        </TableCell>
                      </TableRow>
                  )}) : null}
                  <TableRow>
                    <TableCell className={classes.tableCell2} />
                  </TableRow>
                  <TableRow>
                    <TableCell className={classes.tableCell1}>
                      {getLabelFromId(compositeSeries?.displayId) || 'Composite'}
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell className={classes.tableCell2} />
                  </TableRow>
                </TableBody>
              </Table>
            </TableContainer>
            <TableContainer
              className={classes.tableContainer}
              onContextMenu={e => e.preventDefault()}
              id="demandTable"
            >            
              <Table className={classes.table}>
                <TableHead>
                  <TableRow>
                    {columnDefs && columnDefs.length ? (
                      columnDefs.map(column => (
                        <TableCell
                          className={`${classes.tableCell1} ${
                            classes.tableHeaderCell
                            }`}
                        >
                          {column}
                        </TableCell>
                      ))
                    ) :
                      yearlySeries?.length ? Array(yearlySeries[0].data.length).fill('').map(ele => (
                        <TableCell
                          className={`${classes.tableCell1} ${
                            classes.tableHeaderCell
                            }`}
                        >
                          {""}
                        </TableCell>
                      )) : null
                    }
                    <TableCell className={classes.tableCell1}><FormattedMessageComponent id="37245" /></TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {yearlySeries && yearlySeries.length
                    ? yearlySeries.map((s, index) => {
                      const i = index % 2 === 0 ? '2' : '1';
                      return (
                          <TableRow
                            className={
                              this.state.selectedRow === s.key
                                ? classes.selected
                                : ''
                            }
                          >
                          {s.data && s.data.length
                            ? s.data.map((data, index2) => (
                                  <TableCell
                                    className={
                                      classes[`tableCell${i}`] +
                                      ' ' +
                                      classes.tableCell + ' ' + (this.getIgnoreClass(s.key, index2)) + ' ' + (this.state.selectedRow === s.key ? classes.selected : '')
                                    }
                                    onClick={event =>
                                      this.onCellSelect(
                                        event,
                                        s.key,
                                        index2,
                                        index2 + 1,
                                      )
                                    }
                                  >
                                {this.props.hideValuesFromCurrentDate?.({data, year: s.key, index:index2, columnDefs})}
                              </TableCell>
                            ))
                            : null}
                          <TableCell className={classes[`tableCell${i}`] + ' ' + classes.tableCell}>
                            {this.sum(s.data).toLocaleString('en')}
                          </TableCell>
                        </TableRow>
                      );
                    })
                    : null}
                  <TableRow>
                    <TableCell
                      colSpan={
                        columnDefs && columnDefs.length ? columnDefs.length + 1 : 1
                      }
                      className={classes.tableCell2}
                      style={{ height: 28 }}
                    />
                  </TableRow>
                  {compositeSeries ? (
                    <TableRow>
                      {compositeSeries.data && compositeSeries.data.length
                        ? compositeSeries.data.map(data => (
                          <TableCell className={classes.tableCell1 + ' ' + classes.tableCell}>
                            {data}
                          </TableCell>
                        ))
                        : null}
                      <TableCell className={classes.tableCell1 + ' ' + classes.tableCell}>
                        {this.sum(compositeSeries.data)}
                      </TableCell>
                    </TableRow>
                  ) : null}
                  <TableRow>
                    <TableCell
                      colSpan={
                        columnDefs && columnDefs.length ? columnDefs.length + 1 : 1
                      }
                      className={classes.tableCell2}
                      style={{ height: 28 }}
                    />
                  </TableRow>
                </TableBody>
              </Table>
            </TableContainer>
          </div>
        </div>
        <Menu
          keepMounted
          open={this.state.contextMenuOpen}
          onClose={this.handleClose}
          anchorReference="anchorPosition"
          anchorPosition={
            this.state.contextMenuOpen
              ? {
                top: this.state.mousepos.mouseY,
                left: this.state.mousepos.mouseX,
              }
              : undefined
          }
        >
          <MenuItem onClick={this.onMenuClick}>
            {this.state.ignoreHistoryCheck ? (
              this.state.ignoreHistoryCheck
            ) : (
              <span />
            )}
            <FormattedMessageComponent id="25635"/>
            <span> {this.state.date} </span>
          </MenuItem>
        </Menu>
        {
          this.state.isOpenSuperItemHistory ?
            <>
              <Box className={classes.titleDisplay}>
                <FormControlLabel
                  control={<FieldInput
                    formatMessage={true}
                    options={RADIO_OPTIONS}
                    value={radioSelected}
                    field={{ key: 'items', type: 'radio', options: RADIO_OPTIONS.map(ele => ({ ...ele, disabled: disableRadio })) }}
                    onChange={this.handleSuperRadio}
                    isHorizontal={true}
                    disabled={disableRadio}
                  ></FieldInput>}
                  labelPlacement={'end'}
                />
              </Box>
              <Box display={radioSelected === 'detail' ? 'block' : 'none'}>
                <SuperItemHistoryTable
                  itemData={this.props.itemData}
                  getSuperItemHistory={this.props.getSuperItemHistory}
                  rolledTo13={this.props.rolledTo13}
                  rowData={this.props.superHistoryRowData}
                  columnDefs={this.props.superHistoryColDefs}
                  getLabelFromId={getLabelFromId}
                  globalDateFormat={this.props.globalDateFormat}
                  systemDate={this.props.systemDate}
                  getFormattedNumber={this.props.getFormattedNumber}
                />
              </Box>
              <Box display={radioSelected === 'graph' ? 'block' : 'none'}>
                <SuperHistoryGraph
                  series={this.props.superHistorySeries}
                  categories={this.props.superHistoryCategories}
                  isMonthly={this.props.isMonthly}
                  getLabelFromId={getLabelFromId}
                />
              </Box>
            </>
            : null
        }
      </>
    );
  }
}

DemandTable.propTypes = {
  classes: PropTypes.object,
  columnDefs: PropTypes.array,
  series: PropTypes.array,
  ignoreHistoryData: PropTypes.array,
  itemData: PropTypes.object,
  ignoreHistory: PropTypes.func,
  show3Dots: PropTypes.bool,
};

export default withStyles(styles)(DemandTable);

/*
* LogStart --  E3C-33049 - Sravanthi D- 31-08-2021 - 2022.1.0.0 Unified Product
*              Story: E3C-33049 --Group History Properties related Jira.
               Implemented Show me.
*/
import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import KeyboardArrowUpIcon from '@material-ui/icons/KeyboardArrowUp';
import KeyboardArrowDownIcon from '@material-ui/icons/KeyboardArrowDown';
import ContextMenu from '../common/ContextMenu';
import BreadcrumbContextMenu from 'components/common/BreadcrumbContextMenu';
import clsx from 'clsx';
import { ACTIONS_MENULIST } from './constants';
import { onChangeContextMenu, updateBreadCrumbContextMenu } from 'utils/contextMenu';


const useStyles = makeStyles(theme => ({
    mainContainer: {
        width: '100%',
        backgroundColor: 'var(--background-content)',
        borderRadius: '0 0 4px 4px',
        overflow: 'hidden',
        boxShadow: '0 4px 4px var(--secondary-s10)',
        overflowX: 'auto',
        padding: theme.spacing(1),
        paddingTop: 0,
        display: 'flex',
        flexWrap: 'wrap',
    },
    fieldVerticaL: {
        display: 'flex',
        flexDirection: 'column',
        '& label': {
            color: 'var(--value)',
        },
        '& label:first-child': {
            color: 'var(--header-label-color)',
            paddingBottom: theme.spacing(0),
        },
        margin: '0 0.5rem',
    },
    arrows: {
        padding: '0 !important',
        minWidth: '16px',
        background: 'none',
        width: '16px',
    },
    arrowsWrapper: {
        display: 'flex',
        flexDirection: 'column',
        border: '1px solid var(--primary-default)',
        borderRadius: '4px',
        margin: '5px 0.5rem',
        padding: '2px',
    },
    floatRightFlex: {
        marginLeft: 'auto'
    },
    flex: {
        display: 'flex',
    },
    childSpacing: {
        '& > div': {
            padding: "0 0.5rem"
        }
    },
    FREEZE_STYLE: {
        position: 'sticky',
        top: 50,
        zIndex: 10,
        backgroundColor: 'rgb(111,175,214)',
        borderRadius: 0,
        paddingBottom: 20
    }
}))
function Header(props) {
    const classes = useStyles();
    const {
        simInProgress,
        currentRecordData,
        getLabelFromId,
        disableNext,
        disablePrevious,
        removeChildCutdownTab,
        selectedValue,
        canUpdateComponent,
        currentDetailRecord,
    } = props;
    const getActionsContextMenu = (simInProgress) => ACTIONS_MENULIST.filter(e => simInProgress ? e.simInProgress : !e.simInProgress);
    const [state, setState] = React.useState({
        isOpenActionsContextMenu: false,
        menuRef: false,
        actionsContextMenu: getActionsContextMenu(simInProgress),
    })
    React.useEffect(() => {
        setState(state => ({
            ...state,
            actionsContextMenu: getActionsContextMenu(simInProgress)
        }));
    }, [simInProgress])
    const setIsOpenActionsContextMenu = (e = false) => {
        setState(state => ({
            ...state,
            isOpenActionsContextMenu: !!e,
            menuRef: event.currentTarget ? e.currentTarget : e
        }));
        if (e) {
            setState(prevState => {
                const profileId = currentDetailRecord?.GDMPRF?.trim?.();
                const actionsContextMenu = prevState.actionsContextMenu.map(action => {
                    let isDisable = false;
                    if (
                        !canUpdateComponent.update ||
                        (action.key === "assignitems" && !profileId)
                    ) {
                        isDisable = true;
                    }
                    return { ...action, isDisable };
                });
                return { ...prevState, actionsContextMenu };
            })
        }
    }
    const handleActionSelection = type => {
        ({
            'simulateprofile': () => props.setSimInProgress(true),
            'cancel': () => props.setSimInProgress(false),
            'assignitems': () => props.setIsOpenAssignItems(true),
            'acceptprofile': () => props.acceptProfile(),
        })[type]?.();
        setIsOpenActionsContextMenu(false);
    }
    let contextMenu = updateBreadCrumbContextMenu(props) || [];
    const onContextMenuChange = (e, value, check = false, filters = false, title = false) => {
		let defaultFilters = filters;
		let toPage = value;
		let displayName = title;
		onChangeContextMenu(props, e, toPage, defaultFilters, displayName);
		props.setSelectedValueForTabs('Show Me');
	}
    return <div className={props.isFreezeHeader ? classes.FREEZE_STYLE : ""}>
        <div className={classes.mainContainer}>
            <div className={classes.arrowsWrapper}>
                <Button
                    className={classes.arrows}
                    disabled={disablePrevious}
                    onClick={props.handleArrowClick("up")}
                >
                    <KeyboardArrowUpIcon />
                </Button>
                <Button
                    disabled={disableNext}
                    onClick={props.handleArrowClick("down")}
                    className={classes.arrows}
                >
                    <KeyboardArrowDownIcon />
                </Button>
            </div>
            <div className={classes.fieldVerticaL}>
                <label>{getLabelFromId("38413")}</label>
                <label>{currentRecordData.GPMBNM}</label>
            </div>
            <div className={classes.fieldVerticaL}>
                <label>{getLabelFromId("33096")}</label>
                <label>{currentRecordData.GPHEAD?.trim?.()}</label>
            </div>
            <div className={clsx(classes.floatRightFlex, classes.flex, classes.childSpacing)}>
                <div>
                    <Button
                        color="primary"
                        size="small"
                        variant="outlined"
                        className={classes.orderArrow}
                        onClick={setIsOpenActionsContextMenu}
                    >
                        <div>Actions</div>
                        <KeyboardArrowDownIcon />
                    </Button>
                    <ContextMenu
                        className={classes.ActionsContextMenu}
                        menuList={state.actionsContextMenu}
                        isOpen={state['isOpenActionsContextMenu']}
                        menuRef={state['menuRef']}
                        handleItemSelection={handleActionSelection}
                        handleMenuClose={setIsOpenActionsContextMenu}
                    />
                </div>
                <div>
                    <BreadcrumbContextMenu
                        menuItems={contextMenu}
                        onOptionChange={(e, val) => onContextMenuChange(e, val)}
                        removeChildCutdownTab={removeChildCutdownTab}
                        selectedValue={selectedValue}
                    />
                </div>
            </div>
        </div>
    </div>;
}
export default Header;
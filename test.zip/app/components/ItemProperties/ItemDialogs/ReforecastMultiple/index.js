import React, { Component } from 'react';
import ReforecastMultipleContainer from 'containers/ItemEmbeddedListContainers/ReforecastMultipleContainer';
class ReforecastMultipleDialog extends Component {
    render() {
        return (
            <>
                {
                    this.props.isOpen &&
                    <ReforecastMultipleContainer
                        {...this.props}
                    />
                }
            </>);
    }
}
export default ReforecastMultipleDialog;
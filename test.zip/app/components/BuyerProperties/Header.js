import React from 'react';
import { withStyles, Button, Box } from '@material-ui/core';
import { injectIntl } from 'react-intl';
import KeyboardArrowUpIcon from '@material-ui/icons/KeyboardArrowUp';
import KeyboardArrowDownIcon from '@material-ui/icons/KeyboardArrowDown';
import MoreVertIcon from '@material-ui/icons/MoreVert';
import SaveIcon from '@material-ui/icons/Save';
import PropTypes from 'prop-types';
import { getDateFromJulian } from 'utils/util';
import withFixedPosition from 'containers/common/withFixedPosition';
import { LABEL_NOTE } from './BuyerNotes/constants';
import {Badge} from '@material-ui/core'; 
import { BADGE_MAX_COUNT } from 'components/common/constants';
import {
  KEY_WAREHOUSE_ID,
  KEY_WAREHOUSE_NAME,
  KEY_ITEM_ID,
  KEY_ITEM_NAME,
  LABEL_WAREHOUSE_NAME,
  LABEL_WAREHOUSE_ID,
  LABEL_ITEM_ID,
  LABEL_ITEM_NAME,
  CONTEXT_MENU_BUYER_ACTIONS,
  CONTEXT_MENU_BUYER_HEADER,
  LABEL_BUYR_ID,
  KEY_BUYR_ID,
  LABEL_COMPANY_ID,
  KEY_COMPANY_ID,
  LABEL_BUYER_ID,
  KEY_BUYER_ID,
  LABEL_BUYER_NAME,
  KEY_BUYER_NAME,
} from './constants';
import { BUYERS_LIST_PAGE } from '../common/constants';

import { getDateFormatted } from '../common/Form/dateTimeUtils';
import FormattedMessageComponent from '../common/FormattedMessageComponent';
import FilterIcon from '../../images/icon_filter.png';
import ContextMenuCreateNew from '../common/ContextMenuCreateNew';
import FormFieldsGenerator from '../common/FormFieldsGenerator';

import BreadcrumbContextMenu from 'components/common/BreadcrumbContextMenu';
const defaultProps = {
  buyerData: [],
  saveDisabled: true,
};

const propTypes = {
  buyerData: PropTypes.array.isRequired,
  saveDisabled: PropTypes.bool.isRequired,
  handleBuyerHeaderFilterClick: PropTypes.func,
  handleBuyerHeaderSaveClick: PropTypes.func,
  handleBuyerHeaderLeftArrowClick: PropTypes.func,
  handleBuyerHeaderRightArrowClick: PropTypes.func,
  handleBuyerHeaderActionItemSelection: PropTypes.func,
};

const style = theme => ({
  propertiesHeaderContainer: {
    width: '100%',
    marginBottom: '1.5rem',
    backgroundColor: 'var(--background-app)',
    borderRadius: '4px',
    borderTopLeftRadius: '0px',
    borderTopRightRadius: '0px',
    overflow: 'hidden',
    boxShadow: '0 4px 4px var(--secondary-s10)',
    overflowX: 'auto',
  },
  buyerContainer: {
    display: 'flex',
    width: '100%',
    backgroundColor: 'var(--background-content)',
    fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
    alignItems: 'center',
    padding: '0 0 0 24px',
    position: 'relative',
    minWidth: '630px',
  },
  buyerDetailsWrapper: {
    width: '100%',
    display: 'flex',
  },
  buyerDetailRow: {
    width: '100%',
    display: 'flex',
    flexWrap: 'wrap',
    padding: '0px 0 24px 0',
    paddingLeft: '15px',
  },
  buyerDetail: {
    padding: '0px 0px 0px 0px',
    lineHeight: '1.1',
  },
  buyerDetailx: {
    padding: '0px 0px 0 0px',
    lineHeight: '1.1',
  },
  buyerDetailWarehouse: {},
  buyerLabel: {
    color: 'var(--header-label-color)',
    paddingBottom: '6px',
    width: '20ch',
  },
  buyerItemLabel: {
    color: 'var(--header-label-color)',
    paddingBottom: '6px',
    width: '48ch',
    height: '42px',
  },
  buyerItemValue: {
    color: 'var(--value)',
    width: '25ch',
    height: '42px',
  },
  buyerValue: {
    color: 'var(--value)',
  },
  buyerID: {
    width: '100%',
    display: 'flex',
    paddingLeft: '45px',
  },
  buyerName: {
    paddingTop: '8px',
  },
  buyerNameInput: {
    padding: '5px 0 5px 0',
    height: '42px',
    '& .MuiFormControlLabel-label': {
      padding: '10px 17px 10px 0px',
    },
    '& input': {
      width: '30ch',
    },
    '& svg': {
      top: '4px',
    },
  },
  buyerArrowIcon: {
    height: '16px',
    width: '12px',
    borderRadius: '4px',
    fontSize: '10px',
    backgroundColor: 'var(--background-app)',
    margin: '0 4px',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    color: 'var(--secondary-s21)',
    lineHeight: '40px',
    cursor: 'pointer',
  },
  buyerActions: {
    top: '24px',
		padding: '0px 20px 20px 20px',
		right: '16px',
		display: 'flex',
		position: 'absolute',
		alignItems: 'center',
		justifyContent: 'space-between',
		'@media (max-width: 1220px)': {
			flexWrap: 'wrap',
			width: '250px'
		}
  },
  buyerRightLables: {
    top: '80px',
    padding: '10px 140px 20px 20px',
    right: '16px',
    display: 'flex',
    position: 'absolute',
    alignItems: 'center',
    justifyContent: 'space-between',
    '@media (max-width: 1220px)': {
      flexWrap: 'wrap',
      width: '250px',
    },
  },
  buyerActionsFilter: {
    minWidth: '37px',
    border: '1px solid var(--primary-default)',
    height: '32px',
    marginLeft: '15px',
    '@media (max-width: 1220px)': {
      marginLeft: '0px',
    },
    '& img': {
      width: '14px',
      height: '14px',
    },
    '& svg': {
      width: '18px',
      height: '18px',
    },
  },
  BuyerReferences: {
		position: 'absolute',
		right: '3rem',
		bottom: '0px',
	
		'&& .MuiBadge-root': {              //Styling for Badge
			'& .MuiBadge-badge': {
					fontSize: '0.6 rem',
					padding: '2px 5px',
					height: '13.5px',
					minWidth: props => (props.notesCountWidth || '21px'),                                     
			}
		}
	},
  buyerActionsButton: {
    border: '1px solid var(--logo)',
    color: 'var(--logo)',
    '&:hover': {
      border: '1px solid var(--link-button)',
    },
  },
  buyerArrow: {
    padding: '0 !important',
    margin: '0',
    minWidth: '16px',
    background: 'none',
    height: '16px',
    width: '16px',
  },
  buyerArrowWrapper: {
    display: 'flex',
    flexDirection: 'column',
    border: '1px solid var(--primary-default)',
    borderRadius: '4px',
    justifyContent: 'center',
    alignItems: 'baseline',
    height: '38px',
    marginTop: '24px',
    padding: '2px',
  },
  ActionsContextMenu: {},
  BuyerReferences: {
    position: 'absolute',
    right: '3rem',
    bottom: '0px',
  },
  buyerIDBlock: {
    display: 'flex',
  },
  subBuyerId: {
    marginLeft: '20px',
  },
  idLabel: {
    paddingRight: '8px',
    width: '35px',
  },
  buyerSubBuyerDetails: {
    display: 'flex',
    flexDirection: 'column',
    width: '16ch',
    padding: '0 30px 0 0px',
    lineHeight: '1.1',
  },
  buyerIdDetails: {
    width: '16ch',
    padding: '0 30px 0 0px',
    lineHeight: '1.1',
  },
  buyerNameLabel: {
    paddingBottom: '0',
  },
  buttonActions: {
    display: 'flex',
    alignItems: 'center',
    '@media (max-width: 1220px)': {
      marginBottom: '20px',
    },
    '& .MuiButton-root': {
      borderRadius: '4px',
      fontSize: '14px',
      width: '120px',
      lineHeight: '14px',
    },
    '& .MuiButton-sizeLarge': {
      fontSize: '18px',
    },
    '& .MuiButton-sizeSmall': {
      fontSize: '12px',
      padding: '8px 16px',
    },
    '& .MuiButton-containedPrimary': {
      backgroundColor: theme.palette.primary.default,
      border: '1px solid rgba(0, 0, 0, 0)',
      boxShadow: 'none',
      color: 'var(--background-content)',
      '&:hover': {
        backgroundColor: theme.palette.primary.hover,
        color: 'var(--background-content)',
        border: '1px solid rgba(0, 0, 0, 0)',
      },
      '&:focus': {
        backgroundColor: theme.palette.primary.focus,
        color: 'var(--background-content)',
        border: '1px solid rgba(0, 0, 0, 0)',
      },
      '&:active': {
        backgroundColor: theme.palette.primary.active,
        color: 'var(--background-content)',
        border: '1px solid rgba(0, 0, 0, 0)',
      },
    },
    '& .MuiButton-containedSecondary': {
      backgroundColor: 'var(--background-content)',
      border: '1px solid var(--button-tertiary-color)',
      color: 'var(--button-tertiary-color)',
      boxShadow: '0px 4px 14px rgba(0, 0, 0, 0.05)',
      '&:hover': {
        backgroundColor: 'var(--background-content)',
        color: 'var(--button-tertiary-hover-color)',
        border: '1px solid var(--button-tertiary-hover-color)',
      },
      '&:focus': {
        backgroundColor: 'var(--background-content)',
        color: 'var(--button-tertiary-focused)',
        border: '1px solid var(--button-tertiary-focused)',
      },
      '&:active': {
        backgroundColor: 'var(--background-content)',
        color: 'var(--button-tertiary-hover-color)',
        border: '1px solid var(--button-tertiary-hover-color)',
      },
      '&.Mui-disabled': {
        color: theme.palette.primary.disabled,
        textDecoration: 'unset',
        backgroundColor: 'unset',
        textShadow: 'unset',
      },
    },
    '& .MuiButton-outlinedPrimary': {
      border: `${'1px solid '}${theme.palette.primary.default}`,
      boxShadow: '0px 4px 14px rgba(0, 0, 0, 0.05)',
      backgroundColor: 'var(--background-content)',
      color: theme.palette.primary.default,
      '&:hover': {
        backgroundColor: 'var(--background-content)',
        border: '1px solid var(--button-secondary-hover-border)',
        color: 'var(--button-secondary-hover-border)',
      },
      '&:focus': {
        backgroundColor: 'var(--background-content)',
        border: `${'1px solid '}${theme.palette.primary.default}`,
        color: theme.palette.primary.default,
      },
      '&:active': {
        backgroundColor: 'var(--background-content)',
        border: '1px solid var(--primary-button-pressed)',
        color: 'var(--primary-button-pressed)',
      },
      '&.Mui-disabled': {
        color: theme.palette.primary.disabled,
        textDecoration: 'unset',
        backgroundColor: 'unset',
        textShadow: 'unset',
      },
    },
    '& .MuiButton-outlinedSecondary': {
      backgroundColor: 'var(--background-content)',
      border: '1px solid var(--button-tertiary-color)',
      color: 'var(--button-tertiary-color)',
      boxShadow: '0px 4px 14px rgba(0, 0, 0, 0.05)',
      '&:hover': {
        backgroundColor: 'var(--background-content)',
        color: 'var(--button-tertiary-hover-color)',
        border: '1px solid var(--button-tertiary-hover-color)',
      },
      '&:focus': {
        backgroundColor: 'var(--background-content)',
        color: 'var(--button-tertiary-focused)',
        border: '1px solid var(--button-tertiary-focused)',
      },
      '&:active': {
        backgroundColor: 'var(--background-content)',
        color: 'var(--button-tertiary-hover-color)',
        border: '1px solid var(--button-tertiary-hover-color)',
      },
      '&.Mui-disabled': {
        color: theme.palette.primary.disabled,
        textDecoration: 'unset',
        backgroundColor: 'unset',
        textShadow: 'unset',
      },
    },
  },
  buttonActionsSecondChild: {
    marginRight: '15px',
    '& .MuiButton-outlinedPrimary': {
      width: '100px',
      height: '28px',
    },
  },
  IdNameBlock: {
    display: 'flex',
    paddingTop: '24px',
    whiteSpace: 'break-spaces',
  },
  IdNameBlockBuyer: {
    paddingTop: '24px',
    whiteSpace: 'break-spaces',
    width: '39ch',
  },
  buyerIdNameBlock: {},
  hideArrows: {
    display: 'none',
  },
  nameField: {
    paddingTop: '32px',
  },
  buyerIDSubID: {
    paddingTop: '24px',
  },
  menuButton: {
    minWidth: '37px',
    border: '1px solid var(--primary-default)',
    height: '32px',
    marginLeft: '15px',
    borderRadius: '4px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    '@media (max-width: 1220px)': {
      marginLeft: '0px',
    },
  },
  poAlign: {
    alignSelf: 'flex-end',
    paddingBottom: '17px',
  },
  label: {
    color: 'var(--header-label-color)',
    paddingBottom: '6px',
    width: '20ch',
  },
  detail: {
    padding: '0px 0px 0px 0px',
    lineHeight: '1.1',
  },
  value: {
    color: 'var(--value)',
    height: '1rem',
  },
});

class Header extends React.Component {
  constructor() {
    super();
    this.state = {
      buyerName: false,
      tabValue: 1,
      buyerDetailsArray: false,
      contextMenuList: CONTEXT_MENU_BUYER_HEADER,
      isOpenActionsContextMenu: false,
      menuRef: null,

      actionList: CONTEXT_MENU_BUYER_ACTIONS,
      isOpenActions: false,
      actionMenuRef: null,
      popupComponent: null,
      open: false,
      subBuyer: false,
      data: {},
    };
    this.getDatefromBuyerData = this.getDatefromBuyerData.bind(this);
    this.getBuyerLabels = this.getBuyerLabels.bind(this);
    this.getHeaderDetails = this.getHeaderDetails.bind(this);
    this.setIsOpenActionsContextMenu = this.setIsOpenActionsContextMenu.bind(
      this,
    );
    this.onClickDownArrow = this.onClickDownArrow.bind(this);
    this.onClickUpArrow = this.onClickUpArrow.bind(this);
    this.setBuyerName = this.setBuyerName.bind(this);
    this.getLabelValue = this.getLabelValue.bind(this);
    this.handleDisableUpArrow = this.handleDisableUpArrow.bind(this);
    this.handleDisableDownArrow = this.handleDisableDownArrow.bind(this);
  }

  getLabelValue(id) {
    return <FormattedMessageComponent id={id} />;
  }

  handleDisableUpArrow = () => {
    const { hasPrevious, fromListPage } = this.props;
    return !hasPrevious || fromListPage != BUYERS_LIST_PAGE;
  };

  handleDisableDownArrow = () => {
    const { hasNext, fromListPage } = this.props;
    return !hasNext || fromListPage != BUYERS_LIST_PAGE;
  };

  getDatefromBuyerData(buyerData, tabValue, key) {
    let date = buyerData[tabValue - 1][key];

    if (date === '0' || !date || (date && date.trim() === '')) return ' ';
    date = getDateFormatted(getDateFromJulian(date));
    return date;
  }

  handleChange = (event, val) => {
    this.setState({ tabValue: val });
  };

  getBuyerLabels(key) {
    switch (key) {
      case KEY_WAREHOUSE_ID:
        return '33161';
      case KEY_COMPANY_ID:
        return '33303';
      case KEY_BUYER_NAME:
        return '36476';
      case KEY_BUYER_ID:
        return '33174';
      default:
    }
  }

  getHeaderDetails(detail) {
    let arr = [];
    if (detail && detail.length) {
      detail.forEach((ele, index) => {
        let element = [];
        Object.keys(ele).forEach(key => {
          let obj = {
            key: key,
            label: this.getBuyerLabels(key),
            value: detail[index][key],
          };
          element.push(obj);
        });
        arr.push(element);
      });
      this.setState({ buyerDetailsArray: arr });
    }
  }

  setIsOpenActionsContextMenu = event => {
    this.setState({ isOpenActionsContextMenu: Boolean(event) });
    this.setState({
      menuRef: event.currentTarget ? event.currentTarget : event,
    });
  };

  componentDidMount() {
    this.getHeaderDetails(this.props.buyerData);
    this.setBuyerName();
  }

  setBuyerName() {
    if (this.props.buyerData) {
      this.setState(
        {
          buyerName: this.props.buyerData[this.state.tabValue - 1][
            KEY_BUYER_NAME
          ],
        },
        () => {
          this.props.updateBuyerName(
            this.props.buyerData[this.state.tabValue - 1][KEY_BUYER_NAME],
          );
        },
      );
    }
  }

  componentDidUpdate(prevProps) {
    const { buyerData ,canUpdateComponent,notesCount} = this.props;

    if (buyerData !== prevProps.buyerData) {
      this.getHeaderDetails(this.props.buyerData);
      this.setBuyerName();
    }
  }

  onClickDownArrow() {
    this.props.handleBuyerHeaderLeftArrowClick();
  }

  onClickUpArrow() {
    this.props.handleBuyerHeaderRightArrowClick();
  }

  handleClickOpen = name => {
    this.setState({ [name]: true });
  };
  handleClose = name => {
    this.setState({ [name]: false });
  };
  handleBuyerNameChange = val => {
    this.setState({ buyerName: val });
    this.props.updateBuyerName(val);
  };

  onClickActions = () => {
    this.setState({ isOpenActions: true });
  };

  setIsActionClose = () => {
    this.setState({ isOpenActions: false });
  };

  render() {
    const {
      classes,
      buyerData,
      handleBuyerHeaderFilterClick,
      handleBuyerHeaderSaveClick,
      saveDisabled,
      handleBuyerHeaderActionItemSelection,
      currentPage,
      parentPage,
      headerFieldJson,
      valuesArray,
      setSaveData,
      globalDateFormat,
      pageFilterOptions,
      filterCriteriaDetails,
      globalFilterOptions,
      columnDefs,
      fromListPage,
      canUpdateComponent, 
      notesCount,
      onContextMenuChange,
      selectedValue,
      removeChildCutdownTab,
      contextMenu,
      freezeComponentStyle,
      currentRecordData,
    } = this.props;
    const { tabValue } = this.state;
    return (
      <div
        className={classes.propertiesHeaderContainer}
        style={freezeComponentStyle}
      >
        {buyerData && buyerData.length && currentPage && (
          <div className={classes.buyerContainer}>
            <Box className={classes.buyerDetailsWrapper}>
              <Box className={classes.buyerArrowWrapper}>
                <Button
                  color="primary"
                  onClick={() => this.onClickUpArrow()}
                  className={classes.buyerArrow}
                  disabled={this.handleDisableUpArrow()}
                >
                  <KeyboardArrowUpIcon />
                </Button>
                <Button
                  color="primary"
                  onClick={() => this.onClickDownArrow()}
                  className={classes.buyerArrow}
                  disabled={this.handleDisableDownArrow()}
                >
                  <KeyboardArrowDownIcon />
                </Button>
              </Box>
              <Box className={classes.buyerDetailRow}>
                <div className={classes.buyerIDSubID}>
                  <div className={classes.buyerDetailRow}>
                    <div className={classes.buyerIDBlock}>
                      <div
                        className={`${classes.buyerDetail} ${
                          classes.buyerIdDetails
                        }`}
                      >
                        <div className={classes.buyerLabel}>
                          {this.getLabelValue(LABEL_WAREHOUSE_ID)}
                        </div>
                        <div className={classes.buyerValue}>
                          {buyerData[tabValue - 1][KEY_WAREHOUSE_ID]}
                        </div>
                      </div>
                      <div
                        className={`${classes.buyerDetail} ${
                          classes.buyerSubBuyerDetails
                        }`}
                      >
                        <div className={classes.buyerLabel}>
                          {this.getLabelValue(LABEL_COMPANY_ID)}
                        </div>
                        <div className={classes.buyerValue}>
                          {buyerData[tabValue - 1][KEY_COMPANY_ID]}
                        </div>
                      </div>
                    </div>
                    <div
                      className={`${classes.buyerIDBlock} ${
                        classes.buyerItemLabel
                      }`}
                    >
                      <div
                        className={`${classes.buyerDetail} ${
                          classes.buyerIdDetails
                        }`}
                      >
                        <div className={classes.buyerLabel}>
                          {this.getLabelValue(LABEL_BUYER_ID)}
                        </div>
                        <div className={classes.buyerValue}>
                          {buyerData[tabValue - 1][KEY_BUYER_ID]}
                        </div>
                      </div>
                      <div
                        className={`${classes.buyerDetail} ${
                          classes.buyerSubBuyerDetails
                        }`}
                      >
                        <div className={classes.buyerItemLabel}>
                          {this.getLabelValue(LABEL_BUYER_NAME)}
                        </div>
                        <FormFieldsGenerator
                          handleSubmitDataCallBack={
                            this.props.handleSubmitDataCallBack
                          }
                          parentSubPage={this.props.parentSubPage}
                          key="header"
                          className={classes.buyerNameInput}
                          noMassMaintenance={true}
                          isHeader
                          parentPage={parentPage}
                          fieldsArray={headerFieldJson}
                          valuesArray={valuesArray}
                          handleChangeValue={(key, val, field) =>
                            this.handleBuyerNameChange(val)
                          }
                          enableAddButton={e => {
                            setSaveData(e);
                          }}
                          globalDateFormat={globalDateFormat}
                          filterCriteriaDetails={filterCriteriaDetails}
                          pageFilterOptions={pageFilterOptions}
                          globalFilterOptions={globalFilterOptions}
                          columnDefs={columnDefs}
                          currentPage={currentPage}
                          parentData={buyerData[0]}
                          canUpdateComponent={this.props.canUpdateComponent}
                          hideLabels
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </Box>
            </Box>
            <Box className={classes.buyerActions}>
								<div>
									<BreadcrumbContextMenu
										onOptionChange={(e, val) => onContextMenuChange(e, val)} menuItems={contextMenu}
										removeChildCutdownTab={removeChildCutdownTab}
										selectedValue={selectedValue} 
                    />
								</div>
              <Button
                component="div"
                color="primary"
                onClick={handleBuyerHeaderFilterClick}
                className={classes.buyerActionsFilter}
              >
                <img src={FilterIcon} alt="Filter Icon" />
              </Button>

              <Button
                component="div"
                color="primary"
                onClick={handleBuyerHeaderSaveClick}
                disabled={saveDisabled}
                className={classes.buyerActionsFilter}
              >
                <SaveIcon fontSize="large" />
              </Button>
              <Box className={classes.menuButton}>
                <div
                  onMouseEnter={event =>
                    this.setIsOpenActionsContextMenu(event)
                  }
                  onMouseLeave={() => this.setIsOpenActionsContextMenu(false)}
                >
                  <MoreVertIcon color="primary" className="cPointer" />
                  <ContextMenuCreateNew
                    className={classes.ActionsContextMenu}
                    menuList={this.state.contextMenuList}
                    isOpen={this.state.isOpenActionsContextMenu}
                    menuRef={this.state.menuRef}
                    handleItemSelection={val =>
                      handleBuyerHeaderActionItemSelection(val)
                    }
                    handleMenuClose={val =>
                      this.setIsOpenActionsContextMenu(val)
                    }
                    currentPage={currentPage}
                    currentRecord={currentRecordData}
                  />
                </div>
              </Box>
              
            </Box>
            <Box className={classes.BuyerReferences}>
              <Button component="div" color="primary" size="small" onClick={e => { document.getElementById("buyerNotes").scrollIntoView(); }}>
                {this.getLabelValue(LABEL_NOTE)}
              </Button>
              <Badge color="error" overlap="circle" anchorOrigin={{ vertical: "top", horizontal: "right" }} max={BADGE_MAX_COUNT} badgeContent={notesCount}>
              </Badge>
            </Box>
          </div>
          
        )}
      </div>
    );
  }
}

Header.defaultProps = defaultProps;
Header.propTypes = propTypes;

export default injectIntl(withStyles(style)(withFixedPosition(Header)));

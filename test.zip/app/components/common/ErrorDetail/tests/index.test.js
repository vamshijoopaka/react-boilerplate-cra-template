/**
 * Copyright © 2018, JDA Software Group, Inc. ALL RIGHTS RESERVED.
 * <p>
 * This software is the confidential information of JDA Software, Inc., and is licensed
 * as restricted rights software. The use,reproduction, or disclosure of this software
 * is subject to restrictions set forth in your license agreement with JDA.
 */
import React from 'react';
import { shallowWithIntl } from 'test-helpers/test-helper';
import { intlShape } from 'react-intl';

import { ErrorDetail } from '../index';

describe('<ErrorDetail />', () => {
  let wrapper;
  let props;
  it('should matchsnapshot when props is undefined', () => {
    props = {
      intl: intlShape,
    };
    wrapper = shallowWithIntl(
      <ErrorDetail
        {...props}
      />
    );
    expect(wrapper).toMatchSnapshot();
  });

  it('should matchsnapshot when props is no_data', () => {
    props = {
      type: 'no_data',
      intl: intlShape,
    };
    wrapper = shallowWithIntl(
      <ErrorDetail
        {...props}
      />
    );
    expect(wrapper).toMatchSnapshot();
    // expect(ErrorDetail('no_data', props.intl)).toEqual('<div>No data to be displayed</div>');
  });
  it('should matchsnapshot when props.type is no_alerts', () => {
    props = {
      type: 'no_alerts',
      intl: intlShape,
    };
    wrapper = shallowWithIntl(
      <ErrorDetail
        {...props}
      />
    );
    expect(wrapper).toMatchSnapshot();
  });
});

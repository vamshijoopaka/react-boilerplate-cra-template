import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { compose } from 'redux';
import { injectIntl, intlShape, FormattedMessage } from 'react-intl';
import { selectMessages } from './selector';
import './style.css';

const defaultProps = {
  isErrorToolTip: true
}

class ErrorMessageComponent extends React.Component {
  constructor(props) {
    super(props);
    this.formatDisplayLabel = this.formatDisplayLabel.bind(this);
    this.replacePercentValues = this.replacePercentValues.bind(this);
  }

  getDispalyLabel = label => {
    if (this.props.toUpperCase) return label.toUpperCase();
    label = this.formatDisplayLabel(label);
    return label;
  }

  replacePercentValues(value) {
    const len = value.split('%');
    const charLength = len - 1;
    if (this.props.replaceValues && this.props.replaceValues.length) {
      this.props.replaceValues.forEach((item, index) => {
        index += 1;
        value = value.replace(`%${index}`, item);
      });
    }
    return value;
  }

  formatDisplayLabel(label) {
    if (label && label.indexOf('%') != -1) {
      return this.replacePercentValues(label);
    }
    return label;
  }

  render() {
    const { messages, id, isErrorToolTip, parentErrorClass } = this.props;
    const key = 'E' + id;
    let label = ''; // messages ? this.getDispalyLabel(messages[key]['MMTYP'].trim())+"! " : '';
    label += messages ? this.getDispalyLabel(messages[key]?.MTEXT.trim()) : '';
    return (
      <div className={isErrorToolTip ? "error-tooltip" : parentErrorClass}>
        {messages ? (
          <FormattedMessage id={key} defaultMessage={label} value={label} />
        ) : (
          ''
        )}
      </div>
    );
  }
}

const mapStateToProps = function(state) {
  return {
    messages: selectMessages(state),
  };
};

const withConnect = connect(
  mapStateToProps,
  null,
  null,
);

ErrorMessageComponent.defaultProps = defaultProps;
export default compose(
  withConnect 
)(ErrorMessageComponent);

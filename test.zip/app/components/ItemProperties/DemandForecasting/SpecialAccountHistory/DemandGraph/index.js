import React from 'react';
import PropTypes from 'prop-types';
 import Highcharts from "highcharts";
import more from "highcharts/highcharts-more";
import draggable from "highcharts/modules/draggable-points";
import HighchartsReact from 'highcharts-react-official';

if (typeof Highcharts === "object") {
  more(Highcharts);
  draggable(Highcharts);
}
class DemandGraph extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {};
  }
  getGraphPointValue = (e) => {
    console.log((e.newPoint.y));
    if(e.target.series.name.trim() == "Special Account History")
    this.props.yAxisPointValueChange((e.newPoint.y).toFixed(2), e.target.category);
}

  render() {
    const { categories, series } = this.props;
    const modifiedSeries = JSON.parse(JSON.stringify(series));
    if (modifiedSeries && modifiedSeries.length && modifiedSeries[0]) {
      modifiedSeries[0].color = '#048bd0';
      modifiedSeries[0].name = 'Total Demand History';
    }
    const options = {
      chart: {
        type: 'column',
        scrollablePlotArea: {
          minWidth: 6400,
          scrollPositionX: 0,
        },
        scrollbar: {
          enabled: true,
        },
      },
      title: {
        text: '',
      },
      xAxis: {
        categories,
      },
      yAxis: {
        title: {
          text: '',
        },
        stackLabels: {
          enabled: true,
          style: {
            fontWeight: 'bold',
            color: 'gray',
          },
        },
      },
      legend: {
        layout: 'vertical',
        align: 'right',
        verticalAlign: 'middle',
      },
      plotOptions: {
        series: {
          stickyTracking: false,
          // label: {
          //   connectorAllowed: false,
          // },
          dragDrop: {
            draggableY: true,
            dragMinY: 0,
        },
          point: {
            events: {
              drag: this.getGraphPointValue.bind(this),
            },
          },
        },
      },
      credits: {
        enabled: false,
      },
      series: modifiedSeries,
      responsive: {
        rules: [
          {
            condition: {
              maxWidth: 500,
            },
            chartOptions: {
              legend: {
                layout: 'horizontal',
                align: 'center',
                verticalAlign: 'bottom',
              },
            },
          },
        ],
      },
    };
    return modifiedSeries && modifiedSeries.length && modifiedSeries[0] ? (
      <HighchartsReact options={options}>

      </HighchartsReact>
    ) : null;
  }
}

DemandGraph.propTypes = {
  categories: PropTypes.array,
  series: PropTypes.array,
};

export default DemandGraph;

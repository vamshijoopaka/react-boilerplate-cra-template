import React, { memo } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import injectSaga, { useInjectSaga } from 'utils/injectSaga';
import { withStyles } from '@material-ui/core/styles';
import DialogComponent from '../DialogComponent';
import CustomGrid from '../../CustomGrid';
import {
    TEXT_CANCEL,
    TEXT_OK
} from '../../../containers/common/constants';
import FormattedMessageComponent from 'components/common/FormattedMessageComponent';
import ConfirmationDialog from 'components/common/ConfirmationDialog';
import EmbeddedList from '../../../containers/common/EmbeddedList';
import Form from '../Form/Form';
import { Table, TableBody, TableRow, Box, TableCell, FormControlLabel, Typography } from '@material-ui/core';
import FieldInput from '../Form/FieldInput';
import theme from '../../../jda-gcp-theme';
import {
    WAREHOUSES,
    MENU_ITEMS,
    WAREHOUSE_FILTER_VALUES
} from './constants';
import {
    TEXT_ALERT,
    MAX_NUMBER_OF_SELECTIONS,
    MAX_SELECTION_EXCEEDS,
    SOMETHING_WENT_WRONG
} from 'components/common/constants';
import { INITIAL_PAGE_PROPS } from '../constants';
import {
    getListPredecessor,
    prepareRemoveObject,
    prepareRemoveAllObject,
    prepareModelAllAPIObject
} from '../../../utils/util';
import Spinner from 'components/Common/Spinner';
import HeaderComponent from '../HeaderComponent';

const styles = theme => ({
    wrapper: {
        '@media (max-width: 560px)': {
            minWidth: '520px'
        }
    },
    checkboxValues: {
        paddingBottom: '10px'
    },
    radioValues: {
        paddingLeft: '30px'
    },
    radioButtons: {
        paddingLeft: '10px'
    },
    gridHeight: {
        minHeight: '300px'
    },
    headerWrapper: {
        boxShadow: '0 2px 4px var(--secondary-s10)',
        borderRadius: '4px',
        marginBottom: '1.5rem',
        backgroundColor: 'var(--background-content)',
    },
    flexWrapper: {
        display: 'flex',
        flexWrap: 'wrap',
        // margin: '1rem 0',
        padding: '24px',
        boxShadow: '0 2px 4px var(--secondary-s10)',
        borderRadius: '4px',
        marginBottom: '1.5rem',
        backgroundColor: 'var(--background-content)',
    },
    fieldLabel: {
        color: 'var(--header-label-color)',
        padding: '0 0px 8px 0',
        width: '23ch',
    },
    childBlock: {
        display: 'flex',
        flexDirection: 'column',
        paddingRight: '60px',
        maxWidth: '33%'
    },
    fieldValue: {
        color: 'var(--value)'
    },
    fieldValuesParent: {
        display: 'flex'
    },
    idValue: {
        marginRight: '20px',
        minWidth: '8ch'
    },
    checkBoxLabel: {
        maxWidth:'30ch',
        '& span': {
			maxWidth:'30ch',
		},
    }
});

class RemoveModelAll extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            menuItems: MENU_ITEMS,
            rowSelection: 'multiple',
            selectedRows: false,
            udpateOrders: false,
            submit: false,
            replaceExistingValues: false,
            replaceExistingValueRadioButtonValues: false,
            disableRadioButtons: true,
            radioButtonDefaultData: false,
            selectAllFlag: false,
            selectedRecordsObject: {},
            showConfirmationDialog: false,
            dialogTitle: '',
            dialogContent: '',
            isDataLoaded: false,
            valueDataFailureMessages: []
        }
        this.handleSubmit = this.handleSubmit.bind(this);
        this.selectCheckbox = this.selectCheckbox.bind(this);
        this.getApiObj = this.getApiObj.bind(this);
        this.getRecordDataOnDirection = this.getRecordDataOnDirection.bind(this);
        this.initialLoad = this.initialLoad.bind(this);
        this.setPageForwardDirection = this.setPageForwardDirection.bind(this);
        this.onGridReady = this.onGridReady.bind(this);
        this.onRowSelected = this.onRowSelected.bind(this);
        this.selectRadioButton = this.selectRadioButton.bind(this);
        this.setAssociativeArrayObject = this.setAssociativeArrayObject.bind(this);
        this.getSelectedRowsForAPI = this.getSelectedRowsForAPI.bind(this);
        this.changeValuesOnSelectDeselect = this.changeValuesOnSelectDeselect.bind(this);
        this.updateMenuItems = this.updateMenuItems.bind(this);
        this.updateSelectAllFlag = this.updateSelectAllFlag.bind(this);
        this.handleNoDataSets = this.handleNoDataSets.bind(this);
        this.handleValueDataErrorMessages = this.handleValueDataErrorMessages.bind(this);
    }

    handleNoDataSets(isColumns) {
        const { history } = this.props;
        const { columnDefs, rowData } = this.props;
        if (this.state.isDataLoaded) {
            if (isColumns && columnDefs && columnDefs.length) {
                //do nothing here
            } else if (rowData && rowData.length && columnDefs && columnDefs.length) {

            } else {
                let errValues = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
                errValues.push(SOMETHING_WENT_WRONG);
                this.setState({ valueDataFailureMessages: errValues });
            }
        }
    }

    updateMenuItems(menuItems) {
        this.setState({ menuItems: menuItems });
    }

    setAssociativeArrayObject(rowData) {
        const { apiCallCount, pageProps } = this.props;
        let str = apiCallCount + "buffer";
        let data = this.state.selectedRecordsObject;
        if (data && Object.keys(data) && rowData && rowData.length) {
            for (let key in data) {
                let recordData = data[key];
                if (recordData && recordData.length && (key == str)) {
                    recordData.forEach((record, index) => {
                        rowData[index]["isSelected"] = record.isSelected;
                    })
                }
            }
        }
        data[str] = rowData;
        this.setState({ selectedRecordsObject: data })
    }

    changeValuesOnSelectDeselect(flag) {
        let recordObj = this.state.selectedRecordsObject;
        if (recordObj && Object.keys(recordObj)) {
            for (let key in recordObj) {
                if (recordObj[key] && recordObj[key].length) {
                    recordObj[key].forEach((record, index) => {
                        record.isSelected = flag;
                    })
                }
            }
        }
        this.setState({ selectedRecordsObject: recordObj })
    }

    updateSelectAllFlag(flag) {
        this.setState({ selectAllFlag: flag });
    }

    setMaxSelectionExceedsDialog = () => {
        let errValues = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
        errValues.push(MAX_SELECTION_EXCEEDS);
        this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(errValues)) });
    }

    onRowSelected(event) {
        let arr = this.getSelectedRowsForAPI();
        if (!this.state.selectAllFlag && arr && arr.length > MAX_NUMBER_OF_SELECTIONS) {
            if (event.node.selected) {
                if (arr.length + 1 >= MAX_NUMBER_OF_SELECTIONS) {
                    event.node.setSelected(false);
                    this.setMaxSelectionExceedsDialog();
                } else {
                    this.setMaxSelectionExceedsDialog();
                }
            } else {
                this.setMaxSelectionExceedsDialog();
            }
            return;
        }
        if (this.grid && this.grid.api) {
            const { apiCallCount, pageProps } = this.props;
            const { actualPageSize, actualPage } = pageProps;
            let data = this.state.selectedRecordsObject;
            if (data && Object.keys(data) && Object.keys(data).length) {
                let key = apiCallCount + "buffer";
                let rowIndex = (event.rowIndex + (actualPageSize * actualPage)) % 100;
                data[key][rowIndex]['isSelected'] = event.node.selected;
                this.setState({ selectedRecordsObject: data });
            }
        }
    }

    handleCloseDialog = (flag) => {
        if (this.state.dialogContent == MAX_SELECTION_EXCEEDS) {
            this.grid.api.deselectAll();
            this.changeValuesOnSelectDeselect(false);
        }
        this.setState({ showConfirmationDialog: false });
        if (this.state.valueDataFailureMessages && this.state.valueDataFailureMessages.length) {
            let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
            values.shift();
            this.setState({ valueDataFailureMessages: values });
        }

    }

    getApiObj(filterProps, record, pageProps) {
        let apiObj = {
            filterProps, filterProps,
            pageProps: pageProps,
            direction: pageProps.isForwardDirection,
            record: record,
            currentPage: WAREHOUSES
        };
        return apiObj;
    }


    setPageForwardDirection(flag) {
        let initialPageData = {
            ...INITIAL_PAGE_PROPS,
            actualPage: 0,
            currentPage: 0,
            totalCount: 10,
            isForwardDirection: flag
        };
        this.setState({ initialPageData: initialPageData });
        this.props.onSetPageProps(initialPageData);
    }

    componentWillUnmount() {
        this.props.setColumnDefsLoaded(false);
        this.props.resetStateData(false)
    }

    getRecordDataOnDirection(direction) {
        const { rowData } = this.props;
        if (!rowData) {
            return;
        }
        if (!direction) {
            let count = this.props.apiCallCount;
            this.props.setApiCallCount(count - 1);
            return rowData[0];
        } else {
            let count = this.props.apiCallCount;
            this.props.setApiCallCount(count + 1);
            return rowData[rowData.length - 1];
        }
    }

    initialLoad(props, flag) {
        const { filterProps, pageProps } = props;
        let record;
        if (flag) {
            record = {}
        } else {
            record = this.getRecordDataOnDirection(pageProps.isForwardDirection);
        }
        if (pageProps && filterProps) {
            this.props.getWarehousesList(this.getApiObj(filterProps, record, pageProps));
        }
    }

    componentDidMount() {
        this.setState({ isDataLoaded: false });
        let filterData = WAREHOUSE_FILTER_VALUES;
        this.props.setFilterValues(filterData);
        this.setPageForwardDirection(true);
        this.props.getWarehouseColumnDefs({ type: WAREHOUSES });
    }

    handleValueDataErrorMessages(content) {
        this.setState({ showDialogPopup: true });
        this.setState({ dialogTitle: TEXT_ALERT });
        this.setState({ dialogContent: content });
        this.setState({ hasWarning: true });
    }

    componentDidUpdate(prevProps, prevState) {
        const { columnDefs, rowData, isColumnDefsLoaded, filterProps, pageProps, updateColumnsList } = this.props;
        const { isValueDataAPICallFailure, isUpdateColumnsFailure } = this.props.removeModelAllData;

        if (isValueDataAPICallFailure && (isValueDataAPICallFailure != prevProps.removeModelAllData.isValueDataAPICallFailure)) {
            this.props.resetFlagsData({ key: 'isValueDataAPICallFailure', value: false });
            this.handleNoDataSets();
        }

        if (isUpdateColumnsFailure && (isUpdateColumnsFailure != prevProps.removeModelAllData.isUpdateColumnsFailure)) {
            this.props.resetFlagsData({ key: 'isUpdateColumnsFailure', value: false });
            let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
            values.push("Failed to update the columns list");
            this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
        }
        
        if (this.state.valueDataFailureMessages && this.state.valueDataFailureMessages.length &&
            (JSON.stringify(this.state.valueDataFailureMessages) != JSON.stringify(prevState.valueDataFailureMessages))) {
            this.handleValueDataErrorMessages(this.state.valueDataFailureMessages[0]);
        }
        if ((pageProps != prevProps.pageProps) && pageProps.isPageSizeChanged) {
            let initialPageData = {
                ...pageProps,
                actualPage: 0,
                currentPage: 0,
                totalCount: 10,
                isForwardDirection: true,
            };
            this.props.onSetPageProps({
                ...pageProps,
                isPageSizeChanged: false
            });
            this.props.setApiCallCount(0);
            this.props.getWarehousesList(this.getApiObj(filterProps, false, initialPageData));
        }

        if (columnDefs != prevProps.columnDefs && isColumnDefsLoaded != prevProps.isColumnDefsLoaded) {
            if (isColumnDefsLoaded) {
                this.props.getWarehousesList(this.getApiObj(filterProps, false, pageProps));
            }
        }

        if ((JSON.stringify(columnDefs) != JSON.stringify(prevProps.columnDefs)) && !prevProps.columnDefs) {
            if (columnDefs && columnDefs.length) {

            } else if (!this.state.isDataLoaded) {
                this.setState({ isDataLoaded: true }, () => {
                    this.handleNoDataSets(true);
                });
            }
        }

        if (rowData != prevProps.rowData) {
            if (rowData && rowData.length) {
                this.setAssociativeArrayObject(rowData)
            }
        }

        if ((updateColumnsList != prevProps.updateColumnsList) && updateColumnsList) {
            this.props.getWarehouseColumnDefs({ type: WAREHOUSES });
        }

    }


    getSelectedRowsForAPI() {
        let selectedRows = [];
        let recordObj = this.state.selectedRecordsObject;
        if (recordObj && Object.keys(recordObj)) {
            for (let key in recordObj) {
                let dataRecord = recordObj[key];
                if (dataRecord && dataRecord.length) {
                    dataRecord.forEach((record) => {
                        if (record.isSelected) {
                            selectedRows.push(record);
                        }
                    })
                }
            }
        }
        return selectedRows;
    }


    handleSubmit() {
        let selectedRows = this.getSelectedRowsForAPI();
        if (this.props.namespace == 'deleteAllRecord') {
            let data = prepareRemoveAllObject(this.props.currentPage, this.state.udpateOrders, this.state.submit, this.props.propertyValues, selectedRows, this.state.selectAllFlag);
            this.props.sendDetailAll("delete", data, selectedRows);
        } else if (this.props.namespace == 'modelAllRecord') {
            let data = prepareModelAllAPIObject(this.props.currentPage, this.state.udpateOrders, this.state.replaceExistingValues, this.state.replaceExistingValueRadioButtonValues, this.state.submit, this.props.propertyValues, selectedRows, this.state.selectAllFlag);
            this.props.sendDetailAll("modelall", data, selectedRows);
        }
        this.handleClose();
    }

    selectCheckbox(key, val, form, radioKey) {
        if (key == '35144') {
            this.setState({ udpateOrders: val });
        }
        if (key == '25532') {
            this.setState({ submit: val });
        }
        if (key == '28138') {
            this.setState({ replaceExistingValues: val });
            if (val && val != "0") {
                this.setState({ disableRadioButtons: false }, () => {
                    form.onChange(radioKey, 'zero');
                })
            } else {
                this.setState({ disableRadioButtons: true }, () => {
                    form.onChange(radioKey, '');
                })
            }
        }
    }

    selectRadioButton(key, val, form, radioKey) {
        form.onChange(radioKey, val);
        if (key == '28130') {
            this.setState({ replaceExistingValueRadioButtonValues: 'O' })
        } else if (key == '28131') {
            this.setState({ replaceExistingValueRadioButtonValues: 'M' })
        }
    }

    handleClose = () => {
        if (this.props.clearPopupComponent) {
            this.props.clearPopupComponent();
        }
    }

    onGridReady(params) {
        this.grid = params;
    }
    loadItems = () => {
		if (!this.props.isAPIProgress) {
			this.initialLoad(this.props, false);
		}
	}
    render() {
        const { headerJson, propertyValues, classes, columnDefs, rowData, loading,moreRecordsAvailable } = this.props;
        let textCancel = TEXT_CANCEL, textOk = TEXT_OK;
        return (
            <div>
                <DialogComponent
                    isOpen={this.props.isOpen}
                    dialogTitle={this.props.title}
                    handleClose={this.handleClose}
                    cancelText={textCancel}
                    submitText={textOk}
                    handleCancel={this.handleClose}
                    handleSubmit={() => this.handleSubmit()}
                    disableSubmit={(this.getSelectedRowsForAPI() && this.getSelectedRowsForAPI().length) ? false : true}>
                    <div className={classes.wrapper}>
                        <Box className={classes.headerWrapper} m={theme.spacing(1)}>
                            {/* <HeaderComponent
                                headerJson={headerJson}
                                propertyValues={propertyValues}
                                isColumnDisplay={true}>
                            </HeaderComponent> */}
                            <Box className={classes.flexWrapper}>
                                {headerJson && headerJson.map(value => {
                                    return <Box className={classes.childBlock} key={value.idAccessor}>
                                        <div className={classes.fieldLabel}><FormattedMessageComponent id={value.label}></FormattedMessageComponent></div>
                                        <div className={classes.fieldValuesParent}>
                                            <Typography className={classes.fieldValue + ' ' + classes.idValue}>{propertyValues[value.idAccessor]}</Typography>
                                            <Typography className={classes.fieldValue}>{propertyValues[value.nameAccessor]}</Typography>
                                        </div>
                                    </Box>
                                })}
                            </Box>
                        </Box>
                        <div className={classes.gridHeight}>
                            {!loading && columnDefs && columnDefs.length && rowData && rowData.length ?
                                <EmbeddedList
                                    {...this.props}
                                    moreRecordsAvailable={moreRecordsAvailable}
                                    selectAllFlag={this.state.selectAllFlag}
                                    updateSelectAllFlag={this.updateSelectAllFlag}
                                    selectedRecordsObject={this.state.selectedRecordsObject}
                                    hasSelectDeselectAll={true}
                                    changeValuesOnSelectDeselect={this.changeValuesOnSelectDeselect}
                                    updateMenuItems={this.updateMenuItems}
                                    suppressRowClickSelection={true}
                                    onRowSelected={this.onRowSelected}
                                    currentPage={WAREHOUSES}
                                    listPredecessor={getListPredecessor(WAREHOUSES)}
                                    rowSelection={this.state.rowSelection}
                                    props={this.props}
                                    width={'450px'}
                                    listProps={this.props}
                                    suppressSizeToFit={true}
                                    nameSpace={"bracketDetails"}
                                    onGridReady={this.onGridReady}
                                    rowData={rowData}
                                    updateShowHide={(data, currentPage) => this.props.updateShowHide(data, currentPage)}
                                    menuItems={this.state.menuItems}
                                    onSelectAll={(data) => this.onSelectAll(data)}
                                    columnDefs={columnDefs}
                                    gridHeight={'350px'}
                                    hasGridActions={true}
                                    gridAPI={this.grid}
                                    sendApi={this.loadItems}
                                    >

                                </EmbeddedList> : <Spinner loading type={this.props.nameSpace} />}

                        </div>
                        <Box margin={theme.spacing(1)}>
                            <Form>
                                {form => (
                                    <div>
                                        <div>
                                            {this.props.checkBoxValues.map(ele => {
                                                return <div key={ele.key}>
                                                    <FormControlLabel
                                                        control={<FieldInput
                                                            disabled={ele.isDisable}
                                                            value={form.values[ele.key]}
                                                            onKeyDown={() => { }}
                                                            field={{ key: ele.key, type: 'checkbox' }}
                                                            onChange={(key, val1) => { form.onChange(key, val1); this.selectCheckbox(key, val1, form, (ele.radioButtonsData && ele.radioButtonsData.key) ? ele.radioButtonsData.key : '') }}
                                                        ></FieldInput>}
                                                        label={<FormattedMessageComponent id={ele.key}></FormattedMessageComponent>}
                                                        className={classes.checkBoxLabel}
                                                        labelPlacement={'end'}
                                                    />
                                                    {ele.radioButtonsData &&
                                                        <div className={classes.radioValues} disabled={this.state.disableRadioButtons}>
                                                            {ele.radioButtonsData.data && ele.radioButtonsData.data.length && form.values[ele.radioButtonsData.key] &&
                                                                <div>
                                                                    <label><FormattedMessageComponent id={ele.radioButtonsData.title}></FormattedMessageComponent></label>
                                                                    <div key={ele.radioButtonsData.data.key} className={classes.radioButtons}>
                                                                        <FormControlLabel
                                                                            control={<FieldInput
                                                                                formatMessage={true}
                                                                                value={form.values[ele.radioButtonsData.key]}
                                                                                field={{ key: ele.radioButtonsData.key, type: 'radio', options: ele.radioButtonsData.data }}
                                                                                onChange={(key, val1) => { form.onChange(key, val1); this.selectRadioButton(key, val1, form, ele.radioButtonsData.key) }}
                                                                            ></FieldInput>}
                                                                            labelPlacement={'end'}
                                                                        />
                                                                    </div>
                                                                </div>
                                                            }
                                                        </div>
                                                    }
                                                </div>
                                            })}
                                        </div>

                                    </div>
                                )}
                            </Form>
                        </Box>
                    </div>

                </DialogComponent>
                <ConfirmationDialog
                    isOpen={this.state.showConfirmationDialog}
                    dialogTitle={this.state.dialogTitle}
                    submitText={TEXT_OK}
                    handleClose={e => this.handleCloseDialog(false)}
                    handleCancel={e => this.handleCloseDialog(false)}
                    handleSubmit={e => this.handleCloseDialog(true)}>
                    <div>
                        {this.state.dialogContent}
                    </div>
                </ConfirmationDialog>
            </div>
        )
    }
}

export default compose(
    withStyles(styles),
)(RemoveModelAll);

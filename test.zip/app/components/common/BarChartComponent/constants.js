export const BAR_GRAPH_CONSTANTS = {
    chart: {
        type: 'column'
    },
    title: {
        text: ''
    },
    credits: {
        enabled: false
    },
    xAxis: {
        type: 'category',
        labels: {
            rotation: -45,
            style: {
                fontSize: '13px',
                fontFamily: 'Verdana, sans-serif'
            },
            legend: {
                enabled: true
            },
        },
        legend: {
            enabled: true
        },
    },
    yAxis: {
        min: 0,
        title: {
            text: 'Values'
        },
    },
    legend: {
        enabled: false
    },
    tooltip: {
        pointFormat: 'Value: <b>{point.y:.0f}</b>'
    },
    series: [{
        name: 'Overstock',
        legend: {
            enabled: true
        },
        data: [],
        dataLabels: {
            enabled: true,
            rotation: -90,
            color: '#FFFFFF',
            align: 'right',
            format: '{point.y:.0f}', // one decimal
            y: 10, // 10 pixels down from the top
            style: {
                fontSize: '13px',
                fontFamily: 'Verdana, sans-serif'
            },
            showInLegend: true
        }
    }]
};
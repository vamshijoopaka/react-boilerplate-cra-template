const TabItem = () => null;

export default TabItem;

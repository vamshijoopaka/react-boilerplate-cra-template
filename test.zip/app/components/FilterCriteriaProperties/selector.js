import { createSelector } from 'reselect';

const selectVendorItemData = (state) => state.get('SelectItemsVendors')

const makeVendorItemData = () => createSelector(
  selectVendorItemData,
  selectVendorItemData => selectVendorItemData ? selectVendorItemData?.toJS() : false
)

export {
  makeVendorItemData
}
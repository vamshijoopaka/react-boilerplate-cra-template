
/*
* * //==========================================================================
*
* * // Copyright 2021-2021, Blue Yonder Group, Inc.
*
* * // All Rights Reserved
*
* * //
*
* * // THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF
*
* * // BLUE YONDER GROUP, INC.
*
* * //
*
* * //
*
* * // The copyright notice above does not evidence any actual
*
* * // or intended publication of such source code.
*
* * //
*
* * // ===========================================================================
*/
import PropTypes from 'prop-types';
import React, { Component } from 'react';
import Stepper from '@material-ui/core/Stepper';
import Step from '@material-ui/core/Step';
import StepButton from '@material-ui/core/StepButton';
import FormattedMessageComponent from '../FormattedMessageComponent';

const defaultProps = {
    lastActiveStep: 0,
    activeStep: 0,
    width: '100%'
};

const propTypes = {
    steps: PropTypes.array.isRequired,
    lastActiveStep: PropTypes.number,
    handleStepChange: PropTypes.func,
    activeStep: PropTypes.number,
    width: PropTypes.string
};

class StepperComponent extends Component {
    constructor() {
        super();
        this.handleStep = this.handleStep.bind(this);
    }

    handleStep(index) {
        const { lastActiveStep, handleStepChange } = this.props;
        if (index <= lastActiveStep)
            handleStepChange(index);
    }

    render() {
        const { steps, lastActiveStep, activeStep, width } = this.props;

        return (
            <Stepper nonLinear activeStep={activeStep} style={{ width: width, margin: '0 auto' }}>
                {steps.map((label, index) => (
                    <Step key={label}>
                        <StepButton onClick={() => this.handleStep(index)} completed={index <= lastActiveStep}>
                            {Boolean(Number(label)) && <FormattedMessageComponent id={label}></FormattedMessageComponent>
                            }
                            {!Boolean(Number(label)) && label}
                        </StepButton>
                    </Step>
                ))}
            </Stepper>
        );
    }
}

StepperComponent.defaultProps = defaultProps;
StepperComponent.propTypes = propTypes;

export default StepperComponent;

import {
    GET_COLUMN_DEFS,
    GET_COLUMN_DEFS_SUCCESS,
    GET_COLUMN_DEFS_ERROR,
    SET_API_CALL_COUNT,
    SET_PAGEPROPS,
    REMOVE_RECORD,
    GET_ITEMS_LIST,
    GET_ITEMS_LIST_SUCCESS,
    GET_ITEMS_LIST_FAILURE,
    GET_VENDOR_LIST,
    GET_VENDOR_LIST_SUCCESS,
    GET_VENDOR_LIST_FAILURE,
    GET_WAREHOUSE_LIST,
    GET_WAREHOUSE_LIST_SUCCESS,
    GET_WAREHOUSE_LIST_FAILURE,
    UPDATE_SHOW_HIDE_COLUMNS,
    UPDATE_SHOW_HIDE_COLUMNS_SUCCESS,
    UPDATE_SHOW_HIDE_COLUMNS_FAILURE,
    RESET_DEFAULTS,
    RESET_DEFAULTS_SUCCESS,
    RESET_DEFAULTS_FAILURE,
    SET_COLUMN_DEFS_LOADED,
    UPDATE_VALUE_ON_EDIT,
    ADD_RECORD,
    ADD_FROM_NON_STOCK_AND_ITEMS,
    LABEL_DATA_FLAGS,
    GET_HOLDOUTS_LIST,
    GET_HOLDOUTS_LIST_FAILURE,
    GET_HOLDOUTS_LIST_SUCCESS,
    RESET_DATA,
    PLANS_RECALC,
    PLANS_RECALC_ERROR,
    PLANS_RECALC_SUCCESS,
    SET_ERROR,
    PLANS_UPDATE,
PLANS_UPDATE_SUCCESS,
PLANS_UPDATE_ERROR,
} from './constants';

export function resetStateData(data) {
    return {
        type: RESET_DATA,
        data,
    };
}

export function getcolumnDefs(data) {
    return {
        type: GET_COLUMN_DEFS,
        data,
    };
}

export function getcolumnDefsSuccess(data) {
    return {
        type: GET_COLUMN_DEFS_SUCCESS,
        data,
    };
}

export function getcolumnDefsError(error) {
    return {
        type: GET_COLUMN_DEFS_ERROR,
        error,
    };
}

export function updateShowHide(data) {
    return {
        type: UPDATE_SHOW_HIDE_COLUMNS,
        data,
    };
}

export function updateShowHideSuccess(data) {
    return {
        type: UPDATE_SHOW_HIDE_COLUMNS_SUCCESS,
        data,
    };
}

export function updateShowHideFailure(error) {
    return {
        type: UPDATE_SHOW_HIDE_COLUMNS_FAILURE,
        error,
    };
}

export function resetDefault(data) {
    return {
        type: RESET_DEFAULTS,
        data,
    };
}

export function resetDefaultSuccess(data) {
    return {
        type: RESET_DEFAULTS_SUCCESS,
        data,
    };
}

export function resetDefaultFailure(error) {
    return {
        type: RESET_DEFAULTS_FAILURE,
        error,
    };
}

export function addRec(data, detail, rowIndex) {
    return {
        type: ADD_RECORD,
        data,
        detail,
        rowIndex,
    };
}

export function setApiCallCount(data) {
    return {
        type: SET_API_CALL_COUNT,
        data,
    };
}

export function setPageProps(data) {
    return {
        type: SET_PAGEPROPS,
        data,
    };
}

export function onSetPageProps(data) {
    return {
        type: SET_PAGEPROPS,
        data,
    };
}

export function removeRecord(data) {
    return {
        type: REMOVE_RECORD,
        data,
    };
}

export function addRecordsfromNonStockAndItems(data) {
    return {
        type: ADD_FROM_NON_STOCK_AND_ITEMS,
        data,
    };
}

// export function removeRecordSuccess(data) {
//     return {
//         type: REMOVE_RECORD_SUCCESS,
//         data
//     }
// }

// export function removeRecordFailure(error) {
//     return {
//         type: REMOVE_RECORD_FAILURE,
//         error
//     }
// }

// export function updateRecord(data) {
//     return {
//         type: UPDATE_RECORD,
//         data
//     }
// }

// export function updateRecordsSuccess(data) {
//     return {
//         type: UPDATE_RECORD_SUCCESS,
//         data
//     }
// }

// export function updateRecordsFailure(data) {
//     return {
//         type: UPDATE_RECORD_FAILURE,
//         data
//     }
// }

export function setColumnDefsLoaded(data) {
    return {
        type: SET_COLUMN_DEFS_LOADED,
        data,
    };
}

export function onSetDataValueChange(data) {
    return {
        type: UPDATE_VALUE_ON_EDIT,
        data,
    };
}

export function getVendorList(filterProps) {
    const pageName = 'vendors';
    return {
        type: GET_VENDOR_LIST,
        filterProps,
        currentPage: pageName,
        pageProps: { pageSize: 100 },
        direction: true,
    };
}

export function getVendorListSuccess(data) {
    return {
        type: GET_VENDOR_LIST_SUCCESS,
        data,
    };
}

export function getVendorListFailure(data) {
    return {
        type: GET_VENDOR_LIST_FAILURE,
        data,
    };
}

export function getItemsList(filterProps) {
    const pageName = 'items';
    return {
        type: GET_ITEMS_LIST,
        filterProps,
        currentPage: pageName,
        pageProps: { pageSize: 100 },
        direction: true,
    };
}

export function getItemsListSuccess(data) {
    return {
        type: GET_ITEMS_LIST_SUCCESS,
        data,
    };
}

export function getItemsListFailure(data) {
    return {
        type: GET_ITEMS_LIST_FAILURE,
        data,
    };
}

export function getWarehouseList(value, filterProps) {
    const pageName = 'warehouses';
    return {
        type: GET_WAREHOUSE_LIST,
        value,
        filterProps,
        currentPage: pageName,
        pageProps: { pageSize: 100 },
        direction: true,
    };
}

export function getWarehouseListSuccess(data) {
    return {
        type: GET_WAREHOUSE_LIST_SUCCESS,
        data,
    };
}

export function getWarehouseListFailure(data) {
    return {
        type: GET_WAREHOUSE_LIST_FAILURE,
        data,
    };
}

export function getHoldoutsList(filterProps) {
    const pageName = 'planHoldouts';
    return {
        type: GET_HOLDOUTS_LIST,
        filterProps,
        currentPage: pageName,
        pageProps: { pageSize: 100 },
        direction: true,
    };
}

export function getHoldoutsListSuccess(data) {
    return {
        type: GET_HOLDOUTS_LIST_SUCCESS,
        data,
    };
}

export function getHoldoutsListFailure(data) {
    return {
        type: GET_HOLDOUTS_LIST_FAILURE,
        data,
    };
}

export function setLabelDataFlags(data) {
    return {
        type: LABEL_DATA_FLAGS,
        data,
    };
}

export function plansRecalcQty(data) {
    return {
        type: PLANS_RECALC,
        data,
    };
}
export function plansRecalcQtySuccess(data) {
    return {
        type: PLANS_RECALC_SUCCESS,
        data,
    };
}
export function plansRecalcQtyFailure(data) {
    return {
        type: PLANS_RECALC_ERROR,
        data,
    };
}

export function setError(error) {
    return {
        type: SET_ERROR,
        error,
    };
}

export function plansUpdate(data) {
    return {
        type: PLANS_UPDATE,
        data
    }
}
export function plansUpdateSuccess(data) {
    return {
        type: PLANS_UPDATE_SUCCESS,
        data
    }
}
export function plansUpdateFailure(data) {
    return {
        type: PLANS_UPDATE_ERROR,
        data
    }
}
  /* ------------------- above is perfect code-------------*/

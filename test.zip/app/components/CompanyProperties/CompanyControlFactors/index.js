/** Change Log
 * LogStart --  E3C-33195 - Kumar A- 16 September,2021 - 2022.1.0.0 Unified Product
 *              Story: E3C-33195 --Code Cleanup
*/
import React from 'react';
import { connect } from 'react-redux';
import { compose } from 'redux';
import { withStyles } from '@material-ui/core/styles';
import PropTypes from 'prop-types';

import FormFieldsGenerator from '../../common/FormFieldsGenerator';
import Spinner from '../../common/Spinner';
import { selectData } from './selector';
import {
    COMPANY_CONTROL_FACTORS_ORDER_CONTROLS,
    COMPANY_FORWARD_BUYING_FACTORS,
    COMPANY_EVENT_CONTROL_FACTORS,
    COMPANY_CALCULATION_CONTROL_FACTORS,
} from './constants';
import './style.scss';
import { COMPANYS_LIST_PAGE, COLUMN_VALUE_ACCESSOR } from 'components/common/constants';
import CardComponent from '../../common/CardComponent';

const propTypes = {
    setSaveData: PropTypes.func,
};

const style = theme => ({
    pageContainer: {
        display: 'flex',
        backgroundColor: 'var(--background-app)',
        borderTop: 'none',
        padding: '10px 20px',
    },
    pageContainer1: {
        display: 'flex',
        backgroundColor: 'var(--background-app)',
        borderTop: 'none',
        padding: '0px 20px',
        marginTop: '-10px'
    },
    simpleCardGroup: {
        width: '100%',
        display: 'flex',
        justifyContent: 'space-around',
    },
    simpleCardGroup1: {
        width: '30%',
        display: 'flex',
        justifyContent: 'space-around',
        marginTop: '680px',
        marginLeft: '-730px',
        height: '750px',
    },
    pageContainerSeventy: {
        width: '100%',
        flexFlow: 'wrap',
        display: 'flex',
    },
    pageContainerThirty1: {
        marginLeft: '400px',
        width: '400%',
    },
    pageContainerThirty2: {
        marginLeft: '10px',
        width: '85%',
    },
    pageContainerThirty3: {
        width: '60%',
        display: 'flex',
        justifyContent: 'space-around',
        marginLeft: '-130px',
    },
    cardWithborder: {
        border: '1px solid var(--secondary-s3)',
        borderRadius: '4px',
        padding: '10px',
        margin: '10px',
        width: '100%',
        backgroundColor: 'var(--secondary-s5)',
    },
    card: {
        padding: '0px',
        backgroundColor: 'var(--background-content)',
        borderRadius: '4px',
        width: '100%',
        margin: '8px',
        '& .MuiCardHeader-root': {
            padding: '22px 10px 0 20px'
        },
        '& .MuiCardContent-root': {
            padding: '16px 15px 10px 15px'
        }
    },
    card1: {
        padding: '0px',
        backgroundColor: 'var(--background-content)',
        borderRadius: '4px',
        width: '170%',
        margin: '10px',
        marginLeft: '0px',
        '& .MuiCardHeader-root': {
            padding: '16px 32px'
        },
        '& .MuiCardContent-root': {
            padding: '16px 32px'
        }
    },
    cardName: {
        fontWeight: '500',
        margin: '10px 0 20px 5px',
    },
    dashedBottomBorder: {
        borderBottom: '1px dashed var(--secondary-s21)',
        marginBottom: '20px',
    },
    marginLeftZero: {
        marginLeft: '0',
    },
    marginRightZero: {
        marginRight: '0',
    },
    propertiesOrderExpediteContainer: {
        width: '70%',
        height: '650px',
        marginBottom: '1.5rem',
        backgroundColor: 'white',
        borderRadius: '4px',
        overflow: 'hidden',
        boxShadow: '0 2px 4px var(--secondary-s10)',
        marginTop: '0px',
        marginLeft: '30px',
    },
    widthOfCardComponent: {
        width: '65%',
        marginLeft: '0px',
        height: '700px',
    },
    propertiesOrderExpediteContainer1: {
        width: '70%',
        height: '650px',
        marginBottom: '1.5rem',
        backgroundColor: 'white',
        borderRadius: '4px',
        overflow: 'hidden',
        boxShadow: '0 2px 4px var(--secondary-s10)',
        marginTop: '0px',
        marginLeft: '30px',
    },
    widthOfCardComponent1: {
        width: '60%',
        marginLeft: '0px',
        height: '700px',
    },
    propertiesOrderExpediteContainer2: {
        width: '31.5%',
        height: '750px',
        marginBottom: '1.5rem',
        backgroundColor: 'white',
        borderRadius: '4px',
        overflow: 'hidden',
        boxShadow: '0 2px 4px var(--secondary-s10)',
        marginTop: '-20px',
        marginLeft: '30px',
    },
    widthOfCardComponent2: {
        width: '60%',
        marginLeft: '0px',
        height: '700px',
    },
});

class CompanyControlFactors extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            fields: false,
            values: false,
            hasError: false,
            errorId: false,
            tabcards: false,
        };
        this.handleChangeValue = this.handleChangeValue.bind(this);
    }

    handleChangeValue(key, val, field, setEnableDisable = true) {
        if (val != null) {
            this.props.setValueData({ key, val });
            if (field.dataType == "checkbox" || field.dataType == 'select' || field.dataType == 'date') {
                if (setEnableDisable) {
                    let tabsData = this.setFieldEnableDisable(key, val, field, this.state.tabcards);
                    this.setState({ tabcards: tabsData });
                }
            }
        }
    }

    setFieldEnableDisable = (key, value, field, tabsData, isInitialLoad = false) => {
        const { valueData } = this.props.CompanyPropertiesData;
        let valueDataUpdated = JSON.parse(JSON.stringify(valueData));
        valueDataUpdated = Object.assign({}, valueDataUpdated, { [key]: value });
        // fieldKey --- field changed
        // cardFieldKey --- field to be disabled
        let cardFieldKey, fieldKey = field[COLUMN_VALUE_ACCESSOR].trim();
        let tabcards = JSON.parse(JSON.stringify(tabsData));
        tabcards = tabcards.map(card => {
            card.cardfields = card.cardfields.map(cardField => {
                cardFieldKey = cardField[COLUMN_VALUE_ACCESSOR] ? cardField[COLUMN_VALUE_ACCESSOR].trim() : "";
                if ((fieldKey === 'EVTTO') && (cardFieldKey === 'EVTT1' || cardFieldKey === 'EVTT2' ||
                    cardFieldKey === 'EVTT3' || cardFieldKey === 'EVTT4')) {
                    if (value == 0) {
                        cardField['disabled'] = true;
                    } else {
                        cardField['disabled'] = false;
                    }
                }
                return cardField;
            })
            return card;
        })
        return tabcards;
    }

    setValueDataOnFocutOut = (key, value, field) => {
        if (value != null && key != 'CEVTTO') {
            let tabsData = this.setFieldEnableDisable(key, value, field, this.state.tabcards);
            this.setState({ tabcards: tabsData });
        }
    }

    getValueData(valueData, newValueData) {
        if (Object.keys(valueData).length && Object.keys(newValueData).length &&
            (JSON.parse(JSON.stringify(valueData)) !== JSON.parse(JSON.stringify(newValueData)))) {
            return newValueData;
        }
        return valueData;
    }

    componentDidMount() {
        let tabsData = this.props.CompanyPropertiesData.companyControlFactorsLabelsData.tabcards;
        let valueForm = this.props.CompanyPropertiesData.valueData;
        tabsData.forEach(card => {
            card.cardfields.forEach(field => {
                if (field.key) {
                    tabsData = this.setFieldEnableDisable(field.key, valueForm[field.key], field, tabsData, true);
                    if (field.hasCheckbox) {
                        tabsData = this.setFieldEnableDisable(field.checkfieldJson.key, valueForm[field.checkfieldJson.key], field.checkfieldJson, tabsData, true);
                    }
                }
            })
        })
        this.setState({ tabcards: tabsData });
    }

    render() {
        const { classes, setSaveData, globalDateFormat, filterCriteriaDetails, pageFilterOptions,
            globalFilterOptions, columnDefs, currentPage } = this.props;
        const { loading, valueData, newValueData } = this.props.CompanyPropertiesData;
        const { tabcards } = this.state;
        if (valueData['CSRVGL'].length > 4) {
            valueData['CSRVGL'] = valueData['CSRVGL'].slice(0, -1);
            newValueData['CSRVGL'] = newValueData['CSRVGL'].slice(0, -1);
        }
        return (
            <div>
                {(!loading && tabcards && tabcards.length && currentPage) ? (
                    <div className={classes.pageContainer}>
                        <div className={classes.simpleCardGroup}>
                            <div className={classes.pageContainerSeventy}>
                                <div className={classes.simpleCardGroup}>

                                    {!loading && tabcards.map(formCard => {
                                        if (formCard.cardkey == COMPANY_CONTROL_FACTORS_ORDER_CONTROLS) {
                                            return <CardComponent title={formCard.cardtitle} className={classes.card}>
                                                <FormFieldsGenerator
                                                    cardHasDotsBtn={false}
                                                    cardHasCheckBox={false}
                                                    noMassMaintenance
                                                    labelDisplayCharacters={22}
                                                    valueDisplayCharacters={15}
                                                    handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                                                    key={formCard.cardkey}
                                                    parentPage={COMPANYS_LIST_PAGE}
                                                    className="COMPANY_CONTROL_FACTORS_ORDER_CONTROL_FACTORS"
                                                    fieldsArray={formCard.cardfields}
                                                    enableAddButton={(e) => { setSaveData(e) }}
                                                    valuesArray={this.getValueData(valueData, newValueData)}
                                                    handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                                    globalDateFormat={globalDateFormat}
                                                    handleFocusOut={(key, val, field) => this.setValueDataOnFocutOut(key, val, field)}
                                                    filterCriteriaDetails={filterCriteriaDetails}
                                                    pageFilterOptions={pageFilterOptions}
                                                    globalFilterOptions={globalFilterOptions}
                                                    columnDefs={columnDefs}
                                                    currentPage={currentPage}
                                                    parentData={this.props.companyData}
                                                    canUpdateComponent={this.props.canUpdateComponent}
                                                />
                                            </CardComponent>
                                        }
                                    })}
                                    {!loading && tabcards.map(formCard => {
                                        if (formCard.cardkey == COMPANY_FORWARD_BUYING_FACTORS) {
                                            return <CardComponent title={formCard.cardtitle} className={classes.card}>
                                                <FormFieldsGenerator
                                                    cardHasDotsBtn={false}
                                                    cardHasCheckBox={false}
                                                    noMassMaintenance
                                                    labelDisplayCharacters={22}
                                                    valueDisplayCharacters={15}
                                                    handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                                                    key={formCard.cardkey}
                                                    parentPage={COMPANYS_LIST_PAGE}
                                                    className="COMPANY_FORWARD_BUYING_FACTORS"
                                                    fieldsArray={formCard.cardfields}
                                                    enableAddButton={(e) => { setSaveData(e) }}
                                                    valuesArray={this.getValueData(valueData, newValueData)}
                                                    handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                                    globalDateFormat={globalDateFormat}
                                                    handleFocusOut={(key, val, field) => this.setValueDataOnFocutOut(key, val, field)}
                                                    filterCriteriaDetails={filterCriteriaDetails}
                                                    pageFilterOptions={pageFilterOptions}
                                                    globalFilterOptions={globalFilterOptions}
                                                    columnDefs={columnDefs}
                                                    currentPage={currentPage}
                                                    parentData={this.props.companyData}
                                                    canUpdateComponent={this.props.canUpdateComponent}
                                                />
                                            </CardComponent>
                                        }
                                    })}
                                    {!loading && tabcards.map(formCard => {
                                        if (formCard.cardkey == COMPANY_EVENT_CONTROL_FACTORS) {
                                            return <CardComponent title={formCard.cardtitle} className={classes.card}>
                                                <FormFieldsGenerator
                                                    cardHasDotsBtn={false}
                                                    cardHasCheckBox={false}
                                                    noMassMaintenance
                                                    labelDisplayCharacters={22}
                                                    valueDisplayCharacters={19}
                                                    handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                                                    key={formCard.cardkey}
                                                    parentPage={COMPANYS_LIST_PAGE}
                                                    className="COMPANY_EVENT_CONTROL_FACTORS"
                                                    fieldsArray={formCard.cardfields}
                                                    valuesArray={this.getValueData(valueData, newValueData)}
                                                    handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                                    globalDateFormat={globalDateFormat}
                                                    enableAddButton={(e) => { setSaveData(e) }}
                                                    handleFocusOut={(key, val, field) => this.setValueDataOnFocutOut(key, val, field)}
                                                    filterCriteriaDetails={filterCriteriaDetails}
                                                    pageFilterOptions={pageFilterOptions}
                                                    globalFilterOptions={globalFilterOptions}
                                                    columnDefs={columnDefs}
                                                    currentPage={currentPage}
                                                    parentData={this.props.companyData}
                                                    canUpdateComponent={this.props.canUpdateComponent}
                                                />
                                            </CardComponent>
                                        }
                                    })}
                                </div>
                            </div>
                        </div>
                    </div>
                ) : (<Spinner loading type="list" />)
                }
                {(!loading && tabcards && tabcards.length) ? (
                    <div className={classes.pageContainer1}>
                        {!loading && tabcards.map(formCard => {
                            if (formCard.cardkey == COMPANY_CALCULATION_CONTROL_FACTORS) {
                                return <CardComponent title={formCard.cardtitle} className={classes.card}>
                                    <FormFieldsGenerator
                                        cardHasDotsBtn={false}
                                        cardHasCheckBox={false}
                                        noMassMaintenance
                                        labelDisplayCharacters={22}
                                        valueDisplayCharacters={15}
                                        handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                                        key={formCard.cardkey}
                                        parentPage={COMPANYS_LIST_PAGE}
                                        enableAddButton={(e) => { setSaveData(e) }}
                                        className="COMPANY_CALCULATION_CONTROL_FACTORS"
                                        fieldsArray={formCard.cardfields}
                                        valuesArray={this.getValueData(valueData, newValueData)}
                                        handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                                        globalDateFormat={globalDateFormat}
                                        handleFocusOut={(key, val, field) => this.setValueDataOnFocutOut(key, val, field)}
                                        filterCriteriaDetails={filterCriteriaDetails}
                                        pageFilterOptions={pageFilterOptions}
                                        globalFilterOptions={globalFilterOptions}
                                        columnDefs={columnDefs}
                                        currentPage={currentPage}
                                        parentData={this.props.companyData}
                                        canUpdateComponent={this.props.canUpdateComponent}
                                    />
                                </CardComponent>
                            }
                        })}
                    </div>
                ) : (<Spinner loading type="list" />)
                }
            </div>
        );
    }
}

const mapStateToProps = function (state) {
    return {
        CompanyControlFactorsData: selectData(state)
    }
};

const withConnect = connect(
    mapStateToProps,
);

CompanyControlFactors.propTypes = propTypes;

export default compose(
    withConnect,
    withStyles(style)
)(CompanyControlFactors);

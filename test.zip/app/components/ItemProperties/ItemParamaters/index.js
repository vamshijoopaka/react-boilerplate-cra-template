/** Change Log
 * LogStart --  E3C-33259 - Sachin- 13 october,2021 - 2022.1.0.0 Unified Product
                Save for Item Service Level Goal is not working
*/

import { withStyles } from '@material-ui/core/styles';
import { COLUMN_FIELD_TYPE, COLUMN_VALUE_ACCESSOR, DROPDOWN_FIELD, ITEMS_LIST_PAGE } from 'components/common/constants';
import PropTypes from 'prop-types';
import React from 'react';
import {
  getListPredecessor, getSortableColumns, setNumberFields, prepareValueDataForItems,
  getCompanyInfo
} from '../../../utils/util';
import CardComponent from '../../common/CardComponent';
import FormFieldsGenerator from '../../common/FormFieldsGenerator';
import './style.scss';
import { Grid } from '@material-ui/core';
import DiscountsEmbeddedList from '../../../containers/ItemEmbeddedListContainers/DiscountsEmbeddedList'
import SkuGroupFields from '../../../containers/SkuGroupFields';
import { MENU_DAILY_PROFILES, MENU_PROFILES, DEFAULT_VALUE_URL_DATA, ITEM_PROPERTIES, ITEM_BRACKET_PRICES } from './constants';

const propTypes = {
  setSaveData: PropTypes.func,
};

const style = () => ({

  pageContainer: {
    display: 'flex',
    backgroundColor: 'var(--background-app)',
    borderTop: 'none',
    padding: '14px 14px 24px 24px',
  },
  pageContainerFifty: {
    width: '50%',
  },
  pageContainerSeventy: {
    width: '70%',
  },
  card: {
    padding: '0px',
    backgroundColor: 'var(--background-content)',
    borderRadius: '4px',
    width: '100%',
    marginTop: '10px',
    marginRight: '10px',
    '& .MuiCardHeader-root': {
      padding: '16px 32px'
    },
    '& .MuiCardContent-root': {
      padding: '16px 32px'
    }
  },
  card_ItemGroup: {
    padding: '0px',
    backgroundColor: 'var(--background-content)',
    borderRadius: '4px',
    width: '100%',
    marginTop: '10px',
    marginRight: '10px',
    '& .MuiCardHeader-root': {
      padding: '16px 32px'
    },
    '& div.MuiCardContent-root': {
      padding: '16px 32px',
      '& > div': {
        '& > div': {
          display: 'grid',
          gridTemplateColumns: '50% 50%',
        },
      },
    },
  },

  simpleCardGroup: {
    width: '100%',
    display: 'flex',
    justifyContent: 'space-around',
  },
  marginLeftZero: {
    marginLeft: '0',
  },
  additionalOpaFactorsCardStyle: {
    minHeight: '194px !important',//E3C-32916 sravanthi 14 jul 
  },
  serviceLevelCardStyle: {
    minHeight: '410px !important',
  },
  itemGroupsCardStyle: {
    minHeight: '468px !important',
  },
  bracketPricesCardStyle: {
    minHeight: '570px !important',
  },
  itemQtyDiscountCardStyle: {
    minHeight: '569px !important',
  }

});

class ItemParamater extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      fields: false,
      values: false,
      hasError: false,
      errorId: false,
      customCards: false,
      unCondDiscounts: {},

      openDailyProfilesDialog: false,
      menuDailyprofiles: MENU_DAILY_PROFILES,
      valuedlyprf: { 'IDLYPR': '' },

      openProfilesDialog: false,
      menuProfiles: MENU_PROFILES,
      valueprf: { 'ILTPRF': '' },
      ItemGroupsOrderforCard: false,
      dailyProfileModuleSwitch: {},
      canUpdatePriceFields: {},
      allowUpdate: true,
    }

    this.dailyProfiles = this.dailyProfiles.bind(this),
      this.Profiles = this.Profiles.bind(this),
      this.setDiscountFields = this.setDiscountFields.bind(this),
      this.loadItemBrackets = this.loadItemBrackets.bind(this);
    this.canUpdateDailyProfileComponent = this.canUpdateDailyProfileComponent.bind(this);
  }

  componentDidMount() {

    const { itemParametersLabelsData } = this.props.ItemPropertiesData;
    const { companyDetails, authorizedComponentsList } = this.props;
    // const canUpdateComponent = this.props.canUpdateComponent; 
    let allowUpdate = null;
    let canUpdateDailyProfile = null;
    this.loadItemBrackets();
    this.props.resetItemParametersSave(); //reset Save Item Parameters flag

    //Is Item Module has allow Update authority ?
    if (this.props.canUpdateComponent && Object.keys(this.props.canUpdateComponent) && Object.keys(this.props.canUpdateComponent).length) {
      allowUpdate = this.props.canUpdateComponent.update ? true : false
      this.setState({ allowUpdate })
    }

    //Check daily profile module, disable if off 
    if (companyDetails) {
      let canUpdateComponent = { ... this.props.canUpdateComponent };
      if (canUpdateComponent.update) {
        getCompanyInfo(companyDetails, 'dailyProfileModuleSwitch') ? canUpdateComponent : canUpdateComponent.update = false;
        this.setState({ dailyProfileModuleSwitch: canUpdateComponent });
      }
      else {
        canUpdateComponent.update = false;
        this.setState({ dailyProfileModuleSwitch: canUpdateComponent });
      }
    }

    //check RestrictedFields
    if (this.props.canUpdateComponent) {
      let canUpdateComponent = { ... this.props.canUpdateComponent };
      if (canUpdateComponent.hasOwnProperty('ITEMUI_IDA_RESTRICT_FIELDS')) {
        if (canUpdateComponent.ITEMUI_IDA_RESTRICT_FIELDS) {
          canUpdateComponent.update = false;
        }
      }
      this.setState({ canUpdatePriceFields: canUpdateComponent });
    }
  }

  componentDidUpdate(prevProps) {
    const { isBracketSaveSuccess, newValueData, currencySelected, currencyConversion, foreignValuesForLocal } = this.props.ItemPropertiesData;
    const { itemData } = this.props;

    this.checkLoading();
    //Reload Item Price brackets after Save
    if ((isBracketSaveSuccess && isBracketSaveSuccess !== prevProps.ItemPropertiesData.isBracketSaveSuccess)) {
      this.setState({ isSaveDataDisabled: true });
      this.loadItemBrackets();
    }

    //When switching between tabs or after applying filter, reload respective item brackets
    if (itemData && prevProps.itemData && (itemData !== prevProps.itemData)) {
      this.loadItemBrackets();
    }
    if (currencySelected === 'foreign' && currencySelected !== prevProps.ItemPropertiesData.currencySelected) {
      // Object.keys(newValueData)
      //   .filter(key => key.includes('local') && newValueData[key] !== 'empty')
      //   .forEach(keyLocal => {
      //     if (typeof keyLocal !== 'string') return;
      //     const key = keyLocal.replace('local', '');
      //     const precision = newValueData[keyLocal].split('.')?.[1]?.length || 0;
      //     const val = (newValueData[key] * currencyConversion.MCLTOF).toFixed(precision);
      //     if (newValueData[key] !== newValueData[keyLocal] || newValueData[key] !== val) {
      //       this.props.setValueData({ key, val });
      //       this.props.setValueData({ key: keyLocal, val: 'empty' });
      //     }
      //   });
      //*******Local Edited Values are now converted to Foreign and replaced in newValueData**************//
      Object.keys(foreignValuesForLocal)
        .forEach(key => {
          if (newValueData[key] !== foreignValuesForLocal[key]) {
            this.props.setValueData({ key, val: foreignValuesForLocal[key] });
          }
        });
      this.props.setStoreKeyValue('foreignValuesForLocal', {});
    }
  }

  componentDidCatch() {
    this.setState({ hasHardError: true })
  }

  setDiscountFields = (itemDiscountObj) => {
    if (itemDiscountObj) {
      const unCondDiscounts = itemDiscountObj.unConditionalDiscounts ? itemDiscountObj.unConditionalDiscounts : {};
      this.setState({ unCondDiscounts: unCondDiscounts })
      this.props.loadItemDiscounts(itemDiscountObj);

    }
  }

  handleChangeValue = (key, val, field) => {
    if ([undefined, null].includes(val)) return;
    this.props.setValueData({ key, val });
    if (key == 'ILTFSW' || key == 'ILTVSW' || key == 'ISRVSW') {      //Fix for E3C-33259
      this.props.setSaveDataValue(true);
    }
    if (key == 'ILTFSW' && val == '0') {
      this.props.setValueData({ key: 'ILTFOR', val: this.props.ItemPropertiesData.valueData.ILTFOR, field });
    }
    if (key == 'ILTVSW' && val == '0') {
      this.props.setValueData({ key: 'ILTVAR', val: this.props.ItemPropertiesData.valueData.ILTVAR, field });
    }
  }
  handleFocusOut = (key, val, field) => {
    if (field.isEdited) {
      //***********foreignValuesForLocal is the variable object to store the converted foreign currency that are edited in localMode.***********//
      const { foreignValuesForLocal, currencyConversion } = this.props.ItemPropertiesData;
      let value = val;
      if (currencyConversion?.MCLTOF)
        value = (val * currencyConversion.MCLTOF).toFixed(field.precisionLength || 0);
      this.props.setStoreKeyValue('foreignValuesForLocal', { ...foreignValuesForLocal, [key]: value });
      // this.props.setValueData({ key: key + 'local', val });
    }
  }
  handleChangeUnConDiscValue = (key, val) => {
    let data = this.state.unCondDiscounts;
    if (val || val == "") {
      let temp = { ...data, [key]: val }
      this.setState({ unCondDiscounts: temp });
      this.props.unCondDiscounts(temp);
    }
  }

  handleChangeBracketValue = (key, val) => {
    this.props.setBracketValueData({ key, val });
  }

  getValueData = (valueData, newValueData) => {
    if (Object.keys(valueData).length && Object.keys(newValueData).length &&
      (JSON.parse(JSON.stringify(valueData)) !== JSON.parse(JSON.stringify(newValueData)))) {
      return newValueData;
    }
    return valueData;
  }

  setCustomCards = (customCards) => {
    let { cardfields } = customCards[0];
    cardfields = getSortableColumns(cardfields, false, COLUMN_FIELD_TYPE, DROPDOWN_FIELD);
    cardfields = setNumberFields(cardfields);
    cardfields.forEach((card) => {
      if (card.FDFNAM && card.FDFNAM.trim()) {
        card.key = card.prefixFlag ? card.FDFNAM.trim() : getListPredecessor('items') + card[COLUMN_VALUE_ACCESSOR].trim()
      }
    });
    customCards[0].cardfields = JSON.parse(JSON.stringify(cardfields))
    return customCards;
  }

  changeItemGroupOrder = (itemGroupCardFields) => {
    let newItemGroupOrder = [];
    if (Object.keys(itemGroupCardFields).length && !this.state.ItemGroupsOrderforCard) {
      for (let i = 0; i < 6; i++) {
        newItemGroupOrder.push(itemGroupCardFields[i]);
        newItemGroupOrder.push(itemGroupCardFields[i + 6])
      }
      this.setState({ ItemGroupsOrderforCard: newItemGroupOrder })
    }
    return this.state.ItemGroupsOrderforCard;
  }

  loadItemBrackets = () => {
    const { pageProps, valueData } = this.props.ItemPropertiesData;
    const { itemData } = this.props;
    const itemDataObj = prepareValueDataForItems(DEFAULT_VALUE_URL_DATA, itemData);
    this.props.loadItemBrackets(this.getApiObj(itemDataObj, null, ITEM_PROPERTIES, pageProps));
  }

  getApiObj = (recordData, record = false, currentPage = ITEM_PROPERTIES, pageProps = false) => {
    let recordObj = false;
    if (record) {
      recordObj = record;
    }
    const apiObj = {
      recordData,
      pageProps,
      direction: pageProps.isForwardDirection,
      record: recordObj,
      currentPage,
      parentPage: ITEMS_LIST_PAGE,
    };
    return apiObj;
  }

  dialogClose = flag => {
    let newState = { ...this.state, };
    newState[flag] = false;
    this.setState(newState);
  }

  sendSelectedRows = (data) => {
    this.setState({ selectSelectedRows: data });
  }

  setSelectSubmit = (val) => {
    this.setState({ enableSelectSubmit: val });
  }

  onSelectGridReady = (paramsApi) => {
    this.filterCriteriaGridApi = paramsApi;
  }

  deleteGridReady = params => {
    this.deleteGridApi = params;
  }

  updateMenuDailyprofiles = items => {
    this.setState({ menuDailyprofiles: items })
  }

  updateMenuProfiles = items => {
    this.setState({ menuProfiles: items })
  }

  dailyProfiles = (payload) => {
    if (this.state.selectSelectedRows && this.state.selectSelectedRows.length) {
      this.state.valuedlyprf = { 'IDLYPR': this.state.selectSelectedRows[0].DPRFL };
    }
    this.dialogClose("openDailyProfilesDialog")
  }

  Profiles = (payload) => {
    if (this.state.selectSelectedRows && this.state.selectSelectedRows.length) {
      this.state.valueprf = { 'ILTPRF': this.state.selectSelectedRows[0].PPRFL };
    }
    this.dialogClose("openProfilesDialog")
  }

  handleActionSelection_dlyprf = action => {
    this.setState({ openDailyProfilesDialog: true });
  }

  handleActionSelection_prf = action => {
    this.setState({ openProfilesDialog: true });
  }

  getMessageText = id => {
    const { messages } = this.props;
    if (messages && messages['H' + id]) {
      return messages['H' + id].TLLAB;
    }
    else return '';
  }

  checkLoading = () => {
    const { itemParametersLabelsData: { tabcards = false } } = this.props.ItemPropertiesData;
    if (tabcards && !this.state.itemDiscountsLoader) {
      this.props.setChildLoading(false);
    }
    else {
      this.props.setChildLoading(true);
    }
  }

  setChildLoading = name => loading => {
    if (this.state[name] != loading) {
      this.setState({ [name]: loading })
    }
  }

  canUpdateDailyProfileComponent() {
    if (this.state.allowUpdate) {
      let canUpdateComponent = { ... this.props.canUpdateComponent };
      return this.state.dailyProfileModuleSwitch && this.state.allowUpdate ? canUpdateComponent : canUpdateComponent.update = false;
    }
    return false;
  }

  render() {
    const { classes, setSaveData, globalDateFormat, filterCriteriaDetails, pageFilterOptions,
      globalFilterOptions, columnDefs, currentPage, ItemPropertiesData, canUpdateComponent } = this.props;
    const { loading, valueData, newValueData, itemParametersLabelsData, stockStatusLabelsData, newItembrackets } = this.props.ItemPropertiesData;
    const { tabcards } = itemParametersLabelsData;
    const { currencySelected = 'foreign',
      currencyConversion = false,
    } = ItemPropertiesData;

    if (this.state.hasHardError) {
      return <h2> Oops Something Went Wrong </h2>
    }
    const canConvertCurrency = Boolean(valueData?.ICURCD?.trim?.());
    return (
      <div>
        {!loading && tabcards && tabcards.length && currentPage && stockStatusLabelsData && stockStatusLabelsData.tabcards &&
          <div>
            <Grid container className={classes.pageContainer}>
              <Grid item xs={4} className={classes.pageContainerSeventy}>
                <div className={classes.simpleCardGroup}>
                  {!loading && tabcards.map(formCard => {
                    //Quantity Translations
                    if (formCard.cardkey == "50905") {
                      return <CardComponent title={formCard.cardtitle} className={classes.card + ' ' + classes.marginLeftZero}>
                        <FormFieldsGenerator
                          handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                          key={formCard.cardkey}
                          parentPage={ITEMS_LIST_PAGE}
                          className=".ITEM_DETAIL_CARD"
                          fieldsArray={formCard.cardfields}
                          valuesArray={this.getValueData(valueData, newValueData)}
                          handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                          enableAddButton={(e) => { setSaveData(e) }}
                          globalDateFormat={globalDateFormat}
                          filterCriteriaDetails={filterCriteriaDetails}
                          pageFilterOptions={pageFilterOptions}
                          globalFilterOptions={globalFilterOptions}
                          columnDefs={columnDefs}
                          currentPage={currentPage}
                          parentData={this.props.itemData}
                          cardHasCheckBox={true}
                          labelDisplayCharacters={22}
                          valueDisplayCharacters={10}
                          canUpdateComponent={canUpdateComponent}
                        />
                      </CardComponent>
                    }
                  })}
                </div>
                <div className={classes.simpleCardGroup}>
                  {!loading && tabcards.map(formCard => {
                    //Daily Profile
                    if (formCard.cardkey == "52835") {
                      return <CardComponent title={formCard.cardtitle} className={classes.card + ' ' + classes.marginLeftZero}>
                        <FormFieldsGenerator
                          handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                          key={formCard.cardkey}
                          parentPage={ITEMS_LIST_PAGE}
                          className=".ITEM_DETAIL_CARD"
                          fieldsArray={formCard.cardfields}
                          valuesArray={this.getValueData(valueData, newValueData)}

                          handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                          enableAddButton={(e) => { setSaveData(e) }}
                          globalDateFormat={globalDateFormat}
                          filterCriteriaDetails={filterCriteriaDetails}
                          pageFilterOptions={pageFilterOptions}
                          globalFilterOptions={globalFilterOptions}
                          columnDefs={columnDefs}
                          currentPage={currentPage}
                          parentData={this.props.itemData}
                          cardHasCheckBox={true}
                          labelDisplayCharacters={10}
                          valueDisplayCharacters={15}
                          cardHasDotsBtn={true}
                          canUpdateComponent={this.state.dailyProfileModuleSwitch}
                        />
                      </CardComponent>
                    }
                  })}
                </div>
              </Grid>
              <Grid item xs={4} className={classes.pageContainerSeventy}>
                <div className={classes.simpleCardGroup}>
                  {!loading && tabcards.map(formCard => {
                    //Ordering Restrictions
                    if (formCard.cardkey == "50907") {
                      return <CardComponent title={formCard.cardtitle} className={classes.card + ' ' + classes.marginLeftZero}>
                        <FormFieldsGenerator
                          handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                          key={formCard.cardkey}
                          parentPage={ITEMS_LIST_PAGE}
                          className=".ITEM_DETAIL_CARD"
                          fieldsArray={formCard.cardfields}
                          valuesArray={this.getValueData(valueData, newValueData)}
                          handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                          enableAddButton={(e) => { setSaveData(e) }}
                          globalDateFormat={globalDateFormat}
                          filterCriteriaDetails={filterCriteriaDetails}
                          pageFilterOptions={pageFilterOptions}
                          globalFilterOptions={globalFilterOptions}
                          columnDefs={columnDefs}
                          currentPage={currentPage}
                          parentData={this.props.itemData}
                          cardHasCheckBox={true}
                          labelDisplayCharacters={23}
                          valueDisplayCharacters={10}
                          canUpdateComponent={canUpdateComponent}
                        />
                      </CardComponent>
                    }
                  })}
                </div>
                <div className={classes.simpleCardGroup}>
                  {!loading && tabcards.map(formCard => {
                    //Additional OPA Facotrs
                    if (formCard.cardkey == "51010") {
                      return <CardComponent title={formCard.cardtitle} className={`${classes.card} ${classes.marginLeftZero} ${classes.additionalOpaFactorsCardStyle}`}>
                        <FormFieldsGenerator
                          handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                          key={formCard.cardkey}
                          parentPage={ITEMS_LIST_PAGE}
                          className=".ITEM_DETAIL_CARD"
                          fieldsArray={formCard.cardfields}
                          valuesArray={this.getValueData(valueData, newValueData)}
                          handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                          enableAddButton={(e) => { setSaveData(e) }}
                          globalDateFormat={globalDateFormat}
                          filterCriteriaDetails={filterCriteriaDetails}
                          pageFilterOptions={pageFilterOptions}
                          globalFilterOptions={globalFilterOptions}
                          columnDefs={columnDefs}
                          currentPage={currentPage}
                          parentData={this.props.itemData}
                          cardHasCheckBox={true}
                          labelDisplayCharacters={20}
                          valueDisplayCharacters={10}
                          canUpdateComponent={canUpdateComponent}
                        />
                      </CardComponent>
                    }
                  })}
                </div>

              </Grid>
              <Grid item xs={4} className={classes.pageContainerSeventy}>
                <div className={classes.simpleCardGroup}>
                  {!loading && stockStatusLabelsData && stockStatusLabelsData.tabcards.map(formCard => {
                    //Lead Time Information
                    if (formCard.cardkey == "50896") {
                      return <CardComponent title={formCard.cardtitle} className={classes.card + ' ' + classes.marginLeftZero}>
                        <FormFieldsGenerator
                          handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                          key={formCard.cardkey}
                          parentPage={ITEMS_LIST_PAGE}
                          className=".ITEM_DETAIL_CARD"
                          fieldsArray={formCard.cardfields}
                          valuesArray={this.getValueData(valueData, newValueData)}
                          // valuesArray= {this.state.valueprf}
                          handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                          enableAddButton={(e) => { setSaveData(e) }}
                          globalDateFormat={globalDateFormat}
                          filterCriteriaDetails={filterCriteriaDetails}
                          pageFilterOptions={pageFilterOptions}
                          globalFilterOptions={globalFilterOptions}
                          columnDefs={columnDefs}
                          currentPage={currentPage}
                          parentData={this.props.itemData}
                          cardHasCheckBox={true}
                          labelDisplayCharacters={23}
                          valueDisplayCharacters={10}
                          cardHasDotsBtn={true}
                          canUpdateComponent={canUpdateComponent}
                        />
                      </CardComponent>
                    }
                  })}
                </div>
                <div className={classes.simpleCardGroup}>
                  {!loading && tabcards.map(formCard => {
                    //Service Level Goal
                    if (formCard.cardkey == "50897") {
                      return <CardComponent title={formCard.cardtitle} className={` ${classes.serviceLevelCardStyle} ${classes.card} ${classes.marginLeftZero} `}>
                        <FormFieldsGenerator
                          handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                          key={formCard.cardkey}
                          parentPage={ITEMS_LIST_PAGE}
                          className=".ITEM_DETAIL_CARD"
                          fieldsArray={formCard.cardfields}
                          valuesArray={this.getValueData(valueData, newValueData)}
                          handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                          enableAddButton={(e) => { setSaveData(e) }}
                          globalDateFormat={globalDateFormat}
                          filterCriteriaDetails={filterCriteriaDetails}
                          pageFilterOptions={pageFilterOptions}
                          globalFilterOptions={globalFilterOptions}
                          columnDefs={columnDefs}
                          currentPage={currentPage}
                          parentData={this.props.itemData}
                          cardHasCheckBox={true}
                          labelDisplayCharacters={18}
                          valueDisplayCharacters={16}
                          canUpdateComponent={canUpdateComponent}
                        />
                      </CardComponent>
                    }
                  })}
                </div>
              </Grid>
              <Grid item xs={4} className={classes.pageContainerSeventy}>
                <div className={classes.simpleCardGroup}>
                  {!loading && tabcards.map(formCard => {
                    //Regular Prices 
                    if (formCard.cardkey == "50910") {
                      return <CardComponent title={formCard.cardtitle} className={classes.card + ' ' + classes.marginLeftZero}>
                        <FormFieldsGenerator
                          handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                          key={formCard.cardkey}
                          parentPage={ITEMS_LIST_PAGE}
                          className=".ITEM_DETAIL_CARD"
                          fieldsArray={formCard.cardfields}
                          valuesArray={this.getValueData(valueData, newValueData)}
                          handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                          handleFocusOut={this.handleFocusOut}
                          enableAddButton={(e) => { setSaveData(e) }}
                          globalDateFormat={globalDateFormat}
                          filterCriteriaDetails={filterCriteriaDetails}
                          pageFilterOptions={pageFilterOptions}
                          globalFilterOptions={globalFilterOptions}
                          columnDefs={columnDefs}
                          currentPage={currentPage}
                          parentData={this.props.itemData}
                          cardHasCheckBox={true}
                          labelDisplayCharacters={13}
                          valueDisplayCharacters={15}
                          canUpdateComponent={this.state.canUpdatePriceFields}
                          canConvertCurrency={canConvertCurrency}
                          currencySelected={currencySelected}
                          currencyConversion={currencyConversion}
                        />
                      </CardComponent>
                    }
                  })}
                </div>
                <div className={classes.simpleCardGroup}>
                  {!loading && tabcards.map(formCard => {
                    //Unconditional Discounts
                    if (formCard.cardkey == "50911") {
                      return <CardComponent title={formCard.cardtitle} className={classes.card + ' ' + classes.marginLeftZero}>
                        <FormFieldsGenerator
                          handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                          key={formCard.cardkey}
                          parentPage={ITEMS_LIST_PAGE}
                          className=".ITEM_DETAIL_CARD"
                          fieldsArray={formCard.cardfields}
                          valuesArray={this.state.unCondDiscounts}
                          handleChangeValue={(key, val, field) => this.handleChangeUnConDiscValue(key, val, field)}
                          enableAddButton={(e) => { setSaveData(e) }}
                          globalDateFormat={globalDateFormat}
                          filterCriteriaDetails={filterCriteriaDetails}
                          pageFilterOptions={pageFilterOptions}
                          globalFilterOptions={globalFilterOptions}
                          columnDefs={columnDefs}
                          currentPage={currentPage}
                          parentData={this.props.itemData}
                          cardHasCheckBox={true}
                          labelDisplayCharacters={15}
                          valueDisplayCharacters={10}
                          canUpdateComponent={this.state.canUpdatePriceFields}
                          canConvertCurrency={canConvertCurrency}
                          currencySelected={currencySelected}
                          currencyConversion={currencyConversion}
                        />
                      </CardComponent>
                    }
                  })}
                </div>
              </Grid>
              <Grid item xs={8} className={classes.pageContainerFifty}>
                <div className={classes.simpleCardGroup}>
                  {!loading && tabcards.map(formCard => {
                    //Item Group Codes
                    if (formCard.cardkey == "50906") {
                      return <CardComponent title={formCard.cardtitle} className={` ${classes.card_ItemGroup}  ${classes.marginLeftZero} ${classes.itemGroupsCardStyle} `} >
                        <SkuGroupFields
                          handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                          key={formCard.cardkey}
                          parentPage={ITEMS_LIST_PAGE}
                          className=".ITEM_DETAIL_CARD"
                          fieldsArray={this.changeItemGroupOrder(formCard.cardfields) ? this.changeItemGroupOrder(formCard.cardfields) : []}
                          valuesArray={this.getValueData(valueData, newValueData)}
                          handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                          enableAddButton={(e) => { setSaveData(e) }}
                          globalDateFormat={globalDateFormat}
                          filterCriteriaDetails={filterCriteriaDetails}
                          pageFilterOptions={pageFilterOptions}
                          globalFilterOptions={globalFilterOptions}
                          columnDefs={columnDefs}
                          currentPage={currentPage}
                          parentData={this.props.itemData}
                          cardHasCheckBox={true}
                          labelDisplayCharacters={20}
                          valueDisplayCharacters={10}
                          canUpdateComponent={canUpdateComponent}
                        />
                      </CardComponent>
                    }
                  })}
                </div>
              </Grid>
              <Grid item xs={4} className={classes.pageContainerFifty}>
                <div className={classes.simpleCardGroup}>
                  {!loading && tabcards.map(formCard => {
                    //Bracket Prices
                    if (formCard.cardkey == "50912") {
                      return <CardComponent title={formCard.cardtitle} className={` ${classes.card}  ${classes.marginLeftZero} ${classes.bracketPricesCardStyle}`}>
                        <FormFieldsGenerator
                          handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                          key={formCard.cardkey}
                          parentPage={ITEMS_LIST_PAGE}
                          className=".ITEM_DETAIL_CARD"
                          // fieldsArray={
                          //   isLocalCurrency ? 
                          //   formCard.cardfields.map(ele => ({ ...ele, disabled: true }))
                          //   :formCard.cardfields
                          // }
                          fieldsArray={formCard.cardfields}
                          valuesArray={newItembrackets}
                          handleChangeValue={(key, val, field) => this.handleChangeBracketValue(key, val, field)}
                          enableAddButton={(e) => { setSaveData(e) }}
                          globalDateFormat={globalDateFormat}
                          filterCriteriaDetails={filterCriteriaDetails}
                          pageFilterOptions={pageFilterOptions}
                          globalFilterOptions={globalFilterOptions}
                          columnDefs={columnDefs}
                          currentPage={ITEM_BRACKET_PRICES}
                          parentData={this.props.itemData}
                          cardHasCheckBox={true}
                          labelDisplayCharacters={10}
                          valueDisplayCharacters={14}
                          canUpdateComponent={this.state.canUpdatePriceFields}
                          canConvertCurrency={canConvertCurrency}
                          currencySelected={currencySelected}
                          currencyConversion={currencyConversion}
                        />
                      </CardComponent>
                    }
                  })}
                </div>
              </Grid>
              <Grid item xs={8} className={classes.pageContainerFifty}>
                <div className={classes.simpleCardGroup}>
                  {!loading && valueData ?
                    <CardComponent title={this.getMessageText('25412')} className={`${classes.card} ${classes.marginLeftZero} ${classes.itemQtyDiscountCardStyle} `}>
                      <DiscountsEmbeddedList
                        ItemPropertiesData={ItemPropertiesData}
                        currentPage={currentPage}
                        bracketLabelJson={itemParametersLabelsData}
                        itemData={valueData}
                        setChildLoading={this.setChildLoading('itemDiscountsLoader')}
                        setDiscountFields={this.setDiscountFields} //Send Vendor Bracket & Unconditional discounts from DiscountsEmbeddedList to itemParameters
                        canUpdateComponent={this.state.canUpdatePriceFields}
                      />
                    </CardComponent> : ""
                  }

                </div>
              </Grid>
            </Grid>
          </div>
        }
      </div>
    );
  }
}

ItemParamater.propTypes = propTypes;

export default withStyles(style)(ItemParamater);
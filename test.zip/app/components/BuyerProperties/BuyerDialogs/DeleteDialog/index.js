import React, { Component } from 'react';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';
import { withStyles, Box, Typography } from '@material-ui/core';
import theme from '../../../../jda-gcp-theme';
import DialogComponent from 'components/common/DialogComponent';
import FormattedMessageComponent from '../../../common/FormattedMessageComponent';
import FormFieldsGenerator from '../../../common/FormFieldsGenerator';
import EmbeddedList from 'containers/common/EmbeddedList';
import Spinner from 'components/Common/Spinner';
import {
    DIALOG_TITLE_DELETE, TEXT_DELETE,
    FROM_WAREHOUSES, BUYER_INFORMATION, WAREHOUSE,
    ITEM, VENDOR_ID, SHIP_DATE_TO_CUSTOMER, CUSTOMER_ID,
    MENU_ITEMS, BUYERS_FILTER_VALUES, BUYERS,
    WAREHOUSE_PAGE, BUYERS_PAGE
} from "./constants";
import { TEXT_CANCEL, TEXT_ALERT, TEXT_OK } from '../../../common/constants';
import { INITIAL_PAGE_PROPS } from 'components/common/constants';
import { getListPredecessor, getDateFormatValue } from 'utils/util';
import reducer from './reducer';
import saga from './saga';
import ConfirmationDialog from 'components/common/ConfirmationDialog';
import {
    rowDataSelector,
    columnDefsSelector,
    loadingSelector,
    columnFlagSelector,
    pagePropsSelector,
    filterPropsSelector,
    columnInfoSelector,
    isAPIProgressSelector,
    totalCountSelector,
    moreRecordsSelector,
    apiCallCountSelector,
    updateColumnsListSelector,
    errorMessageLabels,
    buyersListSelector,
    makeSelectBuyerDelete
} from './selector';
import {
    getBuyerDeleteList,
    setApiCallCount,
    onSetPageProps,
    getBuyerDeleteColumnDefs,
    setFilterValues,
    setColumnDefsLoaded,
    updateShowHide,
    resetStateData,
    resetDefault,
    getBuyersList,
    setLabelDataFlags
} from './action';
import { BLANK_BUYERID_FILTER_OPTIONS } from '../../../../containers/BuyersListPage/constants';

const styles = theme => ({
    adjustDialog1: {
        maxHeight: '93vh',
        '& .MuiDialogContent-root': {
            padding: '12px'
        },
    },
    notesForBlock: {
        display: 'flex',
        flexDirection: 'column',
        marginTop: '25px',
        border: '1px solid var(--divider-line)',
        padding: '10px 10px 0 10px',
        position: 'relative'
    },
    notesForLabel: {
        position: 'absolute',
        top: '-7px',
        left: '10px',
        background: 'var(--background-content)',
        padding: '0 8px',
    },
    fieldLabel: {
        color: 'var(--header-label-color)',
        padding: '0 0px 8px 0',
        width: '22ch',
    },
    childBlock: {
        display: 'flex',
        padding: '6px'
    },
    fieldValue: {
        color: 'var(--value)'
    },
    fieldValuesParent: {
        display: 'flex'
    },
    idValue: {
        marginRight: '20px',
        minWidth: '15ch'
    },
    adjustCardFieldsInline: {
        display: 'grid !important',
        width: '100%',
        gridTemplateColumns: 'auto auto',
    },
});

class DeleteDialog extends Component {
    constructor(props) {
        super(props);
        this.state = {
            selectAllFlag: false,
            selectedCount: 0,
            selectedRecordsObject: {},
            menuItems: [...MENU_ITEMS],
            rowSelection: 'multiple',
            selectedRows: false,
            valueArrayToBuyer: {},
            deleteConfirmationDialog: false,
            valueDataFailureMessages: [],
            showValueConfirmationDialog: false,
        }
        this.handleValueDataErrorMessages = this.handleValueDataErrorMessages.bind(this);
    }
    getLabelValue(id) {
        return <FormattedMessageComponent id={id}></FormattedMessageComponent>;
    }
    setAssociativeArrayObject = (rowData) => {
        const { apiCallCount, pageProps } = this.props;
        let str = apiCallCount + "buffer";
        let data = this.state.selectedRecordsObject;
        if (data && Object.keys(data) && rowData && rowData.length) {
            for (let key in data) {
                let recordData = data[key];
                if (recordData && recordData.length && (key == str)) {
                    recordData.forEach((record, index) => {
                        rowData[index]["isSelected"] = record.isSelected;
                    })
                }
            }
        }
        data[str] = rowData;
        this.setState({ selectedRecordsObject: data })
    }
    updateSelectAllFlag = (flag) => {
        const { rowData = [] } = this.props;
        this.setState({ selectAllFlag: flag, selectedCount: flag ? rowData.length : 0 });
    }
    changeValuesOnSelectDeselect = (flag) => {
        let recordObj = this.state.selectedRecordsObject;
        if (recordObj && Object.keys(recordObj)) {
            for (let key in recordObj) {
                if (recordObj[key] && recordObj[key].length) {
                    recordObj[key].forEach((record, index) => {
                        record.isSelected = flag;
                    })
                }
            }
        }
        this.setState({ selectedRecordsObject: recordObj })
    }
    onRowSelected = (event) => {
        if (this.grid && this.grid.api) {
            const { apiCallCount, pageProps } = this.props;
            const { actualPageSize, actualPage } = pageProps;
            let data = this.state.selectedRecordsObject;
            if (data && Object.keys(data) && Object.keys(data).length) {
                let key = apiCallCount + "buffer";
                let rowIndex = (event.rowIndex + (actualPageSize * actualPage)) % 100;
                const { selected } = event.node;
                data[key][rowIndex]['isSelected'] = selected;
                this.setState({ selectedRecordsObject: data });
                this.setState((state) => ({ selectedCount: this.grid.api.getSelectedRows().length || 0 }))
            }
        }
    }
    getApiObj = (filterProps, record, pageProps, currentPage) => {
        let apiObj = {
            filterProps, filterProps,
            pageProps: pageProps,
            direction: pageProps.isForwardDirection,
            record: record,
            currentPage: currentPage //'warehouses'
        };
        return apiObj;
    }

    setPageForwardDirection = (flag) => {
        let initialPageData = {
            ...INITIAL_PAGE_PROPS,
            actualPage: 0,
            currentPage: 0,
            totalCount: 10,
            isForwardDirection: flag
        };
        this.setState({ initialPageData: initialPageData });
        this.props.onSetPageProps(initialPageData);
    }

    componentWillUnmount() {
        this.props.setColumnDefsLoaded(false);
        this.props.resetStateData(false)
    }
    componentDidMount() {
        const { headerJson, buyerDetailData } = this.props;
        let ValueData = buyerDetailData.valueData;
        let valueArrayToBuyer = ValueData; 
      
        let filterData = [...BUYERS_FILTER_VALUES];
        this.props.setFilterValues(filterData);
        this.setPageForwardDirection(true);
        this.props.getBuyerDeleteColumnDefs({ type: BUYERS });

        this.setState({ valueArrayToBuyer });
    }

    componentDidUpdate(prevProps, prevState) {
        const { columnDefs, rowData, isColumnDefsLoaded, filterProps, pageProps, updateColumnsList, buyerDetailData } = this.props;
        const {
            isAPIforBuyerCopyList,
            isAPIforColumns,
            isAPIforColumnsUpdate,
            isAPIforResetColumns,
            isAPIforBuyerList,
        } = this.props.buyersDelete
        if (this.state.valueDataFailureMessages && this.state.valueDataFailureMessages.length
            && (JSON.stringify(this.state.valueDataFailureMessages) != JSON.stringify(prevState.valueDataFailureMessages))) {
            this.handleValueDataErrorMessages(this.state.valueDataFailureMessages[0]);
        }

        if (isAPIforBuyerCopyList && (isAPIforBuyerCopyList != prevProps.buyersDelete.isAPIforBuyerCopyList)) {
            let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
            values.push("Failed to fetch Warehouse List");
            this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
            this.props.setLabelDataFlags({ key: 'isAPIforBuyerCopyList', value: false });
        }

        if (isAPIforColumns && (isAPIforColumns != prevProps.buyersDelete.isAPIforColumns)) {
            let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
            values.push("Failed to fetch columns For Warehouse Embeddedlist");
            this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
            this.props.setLabelDataFlags({ key: 'isAPIforColumns', value: false });
        }

        if (isAPIforColumnsUpdate && (isAPIforColumnsUpdate != prevProps.buyersDelete.isAPIforColumnsUpdate)) {
            let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
            values.push("Failed to update columns For Warehouse Embeddedlist");
            this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
            this.props.setLabelDataFlags({ key: 'isAPIforColumnsUpdate', value: false });
        }

        if (isAPIforResetColumns && (isAPIforResetColumns != prevProps.buyersDelete.isAPIforResetColumns)) {
            let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
            values.push("Failed to Rest columns For Warehouse Embeddedlist");
            this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
            this.props.setLabelDataFlags({ key: 'isAPIforResetColumns', value: false });
        }

        if (isAPIforBuyerList && (isAPIforBuyerList != prevProps.buyersDelete.isAPIforBuyerList)) {
            let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
            values.push("Failed to fetch Buyers List");
            this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
            this.props.setLabelDataFlags({ key: 'isAPIforBuyerList', value: false });
        }

        let filterData = [...BUYERS_FILTER_VALUES];
        filterData.push({ "accessor": "BUYR", "operator": "=", "jOpr": "and", "fieldValue": buyerDetailData.currentRecordData["BBUYR"], "prefixFlag": 0 });
      
        if ((pageProps != prevProps.pageProps) && pageProps.isPageSizeChanged) {
            let initialPageData = {
                ...pageProps,
                actualPage: 0,
                currentPage: 0,
                totalCount: 10,
                isForwardDirection: true,
            };
            this.props.onSetPageProps({
                ...pageProps,
                isPageSizeChanged: false
            });
            this.props.setApiCallCount(0);
            this.props.getBuyerDeleteList(this.getApiObj(filterData, false, initialPageData, BUYERS_PAGE));
            this.props.getBuyersList(this.getApiObj(filterData, false, initialPageData, BUYERS_PAGE));
        }

        if (columnDefs != prevProps.columnDefs && isColumnDefsLoaded != prevProps.isColumnDefsLoaded) {
            if (isColumnDefsLoaded) {
                this.props.getBuyerDeleteList(this.getApiObj(filterData, false, pageProps, BUYERS_PAGE));
                this.props.getBuyersList(this.getApiObj(filterData, false, pageProps, BUYERS_PAGE));
            }
        }

        if (rowData != prevProps.rowData) {
            this.setAssociativeArrayObject(rowData)
        }

        if ((updateColumnsList != prevProps.updateColumnsList) && updateColumnsList) {
            this.props.getBuyerDeleteColumnDefs({ type: BUYERS });
        }
        if ((prevState.selectAllFlag != this.state.selectAllFlag) || prevState.selectedCount != this.state.selectedCount) {
            if (this.state.selectAllFlag) {
                this.disableMenuItem('deselectAll', false);
            }
            else if (!this.state.selectedCount) {
                this.disableMenuItem('deselectAll', true);
            }
            else {
                this.disableMenuItem('deselectAll', false);
            }
        }
    }
    disableMenuItem = (menuItem, disable) => {
        this.setState({
            menuItems: MENU_ITEMS.map(row => {
                let item = { ...row };
                if (item.key == menuItem)
                    item.isDisable = disable;
                return item;
            })
        })
    }

    getSelectedRowsForAPI = () => {
        let selectedRows = [];
        let recordObj = this.state.selectedRecordsObject;
        if (recordObj && Object.keys(recordObj)) {
            for (let key in recordObj) {
                let dataRecord = recordObj[key];
                if (dataRecord && dataRecord.length) {
                    dataRecord.forEach((record) => {
                        if (record.isSelected) {
                            selectedRows.push(record);
                        }
                    })
                }
            }
        }
        return selectedRows;
    }

    handleClose = () => {
        this.props.handleCopyDeletePopup('delete', false)
        this.setState({ deleteConfirmationDialog: false });
    }

    onGridReady = (params) => {
        this.grid = params;
    }

    //Create an array of Objects and send to api 
    handleSubmit = () => {
        const { buyerDetailData, headerJson } = this.props;
        let filterProps = this.getMergedDefaultFilters(this.props.filterProps);//E3C-32871, J Vamshi:
        let currentRecord = buyerDetailData.currentRecordData;
        let rowdata = this.getSelectedRowsForAPI();
        const { buyers } = this.props;
        let selectedRows = rowdata.filter(row => buyers.find(buyer => buyer.HOWHSE === row.WWHSE));
        if (this.state.selectAllFlag) {
            let filters = [{ "accessor": "BBUYR", 'prefixFlag': 1, "operator": "=", "jOpr": "and", "fieldValue": buyerDetailData.currentRecordData["BBUYR"] },
            { "accessor": "BWHSE", 'prefixFlag': 1, "operator": "!=", "jOpr": "and", "fieldValue": "" }];
            let pageFilter = [...filterProps]
            this.props.onDeleteAll(selectedRows, { filterProps: filters, pageFilter: pageFilter, record: currentRecord, pageProps: { pageSize: 100 }, direction: true, currentPage: 'buyers' });
        } else {
            let includesCurrent = selectedRows;
            let finalArray = this.prepareData(selectedRows);
            let listParams = includesCurrent ? {currentRecord: buyerDetailData.currentRecordData, filterProps, pageProps: { pageSize: 3 }, direction: true, currentPage: 'buyers' } : {}
            this.props.onSubmit(finalArray, includesCurrent, listParams);
            this.handleClose();
        }
        this.handleClose();
    }
    prepareData = data => {
        let dataArray = []
        const { headerJson, buyerDetailData } = this.props;
        data.forEach(row => {
            let obj = {};
            obj['BRECD'] = buyerDetailData.currentRecordData['BRECD'],
                obj['BSTAT'] = 'D',
                obj['BCOMP'] = buyerDetailData.currentRecordData['BCOMP'],
                obj['BBUYR'] = buyerDetailData.currentRecordData['BBUYR'],
                obj['BWHSE'] = row['BWHSE'],
                obj['BNAME'] = buyerDetailData.currentRecordData['BNAME'],
                obj['WNAME'] = buyerDetailData.currentRecordData['WNAME'],
    
                dataArray.push(obj);
        });
        return dataArray;
    }
    handleConfirmBeforeSubmit = (flag = true) => {
        this.setState({ deleteConfirmationDialog: flag })
    }

    closeValueDialog = () => {
        this.setState({ showValueConfirmationDialog: false });
        if (this.state.valueDataFailureMessages && this.state.valueDataFailureMessages.length) {
            let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
            values.shift();
            this.setState({ valueDataFailureMessages: values });
            if (values && values.length == 0) {
                this.handleClose();
            }
        }
    }
    handleValueDataErrorMessages(content) {
        this.setState({ showValueConfirmationDialog: true, dialogContent: content });
    }
   //E3C-32871, J Vamshi:Begin
    getMergedDefaultFilters = filterProps => {
        if (!filterProps?.length) {
            filterProps = [];
        }
        const fieldsToRemoveFromDefault = [];

        filterProps.forEach(ele => ['BUYR', 'WHSE'].includes(ele.accessor) && fieldsToRemoveFromDefault.push(ele.accessor));

        const defaultFilters = BLANK_BUYERID_FILTER_OPTIONS.filter(ele => !fieldsToRemoveFromDefault.includes(ele.accessor));
        return [...filterProps, ...defaultFilters];
    }
    //E3C-32871, J Vamshi:End
    render() {
        const { classes, columnDefs, apiCallCount, loading, rowData, headerJson,
            buyerDetailData, errorMessages, buyers, deleteLabels, currentOwnerName,
            globalDateFormat, filterCriteriaDetails, pageFilterOptions, canUpdateComponent,
            currentPage, globalFilterOptions } = this.props;

        const { valueArrayToBuyer } = this.state;

        const { tabcards } = deleteLabels;

        return (<React.Fragment>
            <DialogComponent
                className={classes.adjustDialog1}
                isOpen={this.props.openDeletePopup}
                dialogTitle={this.getLabelValue(DIALOG_TITLE_DELETE)}
                cancelText={TEXT_CANCEL}
                submitText={TEXT_DELETE}
                handleClose={e => this.handleClose()}
                handleCancel={e => this.handleClose()}
                handleSubmit={() => this.handleConfirmBeforeSubmit()}
                disableSubmit={(this.getSelectedRowsForAPI() && this.getSelectedRowsForAPI().length) ? false : true}>
                <React.Fragment>
                    <div className={classes.notesForBlock}>
                        <Box mb={theme.spacing(0.5)} className={classes.notesForLabel}>
                            <FormattedMessageComponent id={BUYER_INFORMATION}></FormattedMessageComponent>
                        </Box>
                        {!loading && valueArrayToBuyer && tabcards && tabcards.map(formCard => {
                            if (formCard.cardkey == BUYER_INFORMATION) {
                                return <FormFieldsGenerator
                                    labelDisplayCharacters={22}
                                    valueDisplayCharacters={18}
                                    className={classes.adjustCardFieldsInline}
                                    currentOwnerName={currentOwnerName}
                                    handleSubmitDataCallBack={() => { }}
                                    key={formCard.cardkey}
                                    fieldsArray={JSON.parse(JSON.stringify(formCard.cardfields))}
                                    valuesArray={JSON.parse(JSON.stringify(valueArrayToBuyer))}
                                    handleChangeValue={(key, val) => { this.handleChangeValue(key, val) }}
                                    enableAddButton={() => { }}
                                    globalDateFormat={globalDateFormat}
                                    filterCriteriaDetails={filterCriteriaDetails}
                                    pageFilterOptions={pageFilterOptions}
                                    globalFilterOptions={globalFilterOptions}
                                    columnDefs={columnDefs}
                                    currentPage={currentPage}
                                    canUpdateComponent={canUpdateComponent}
                                    noMassMaintenance={true}
                                />
                            }
                        })}
                    </div>
                    <div className={classes.notesForBlock}>
                        <Box mb={theme.spacing(0.5)} className={classes.notesForLabel}>
                            <FormattedMessageComponent id={FROM_WAREHOUSES}></FormattedMessageComponent>
                        </Box>
                       
                        {!loading && columnDefs && columnDefs.length && rowData && rowData.length ?
                            <EmbeddedList
                                pageProps={this.props.pageProps}
                                selectAllFlag={this.state.selectAllFlag}
                                updateSelectAllFlag={this.updateSelectAllFlag}
                                selectedRecordsObject={this.state.selectedRecordsObject}
                                hasSelectDeselectAll={true}
                                changeValuesOnSelectDeselect={this.changeValuesOnSelectDeselect}
                                updateMenuItems={() => { }}
                                suppressRowClickSelection={true}
                                onRowSelected={this.onRowSelected}
                                currentPage={"buyers"}
                                listPredecessor={getListPredecessor("buyers")}
                                rowSelection={this.state.rowSelection}
                                suppressSizeToFit={true}
                                nameSpace={"buyersDelete"}
                                onGridReady={this.onGridReady}
                                rowData={rowData}
                                updateShowHide={(data, currentPage) => this.props.updateShowHide(data, { type: currentPage, userId: this.props.columnInfo['USERID'].trim(), 'record': showHideColumns })}
                                menuItems={this.state.menuItems}
                                onSelectAll={(data) => this.onSelectAll(data)}
                                columnDefs={columnDefs}
                                gridHeight={'250px'}
                                totalCount={apiCallCount * 100 + (rowData.filter(row => buyers.find(buyer => buyer.BWHSE === row.WWHSE)).length)}
                                hasGridActions={true}>
                            </EmbeddedList> : <Spinner loading type="list" />}


                    </div>
                    {this.state.deleteConfirmationDialog &&
                        <ConfirmationDialog
                            isOpen={this.state.deleteConfirmationDialog}
                            dialogTitle={this.getLabelValue('52891')}
                            cancelText={TEXT_CANCEL}
                            submitText={TEXT_OK}
                            handleClose={e => this.handleConfirmBeforeSubmit(false)}
                            handleCancel={e => this.handleConfirmBeforeSubmit(false)}
                            handleSubmit={e => this.handleSubmit()}
                            hasWarning={true}>
                                                      
                            <div>
                                {errorMessages ? errorMessages?.['E8449']?.['MTEXT'] : 'Confirmation'}
                            </div>
                        </ConfirmationDialog>
                    }
                    {this.state.showValueConfirmationDialog && <ConfirmationDialog
                        hasError={true}
                        isOpen={this.state.showValueConfirmationDialog}
                        dialogTitle={TEXT_ALERT}
                        submitText={TEXT_OK}
                        handleClose={e => this.closeValueDialog()}
                        handleCancel={e => this.closeValueDialog()}
                        handleSubmit={e => this.closeValueDialog()}
                    >
                        <div>
                            {this.state.dialogContent}
                        </div>
                    </ConfirmationDialog>
                    }
                </React.Fragment>
            </DialogComponent>

        </React.Fragment>
        );
    }
}
const mapStateToProps = createStructuredSelector({
    buyersDelete: makeSelectBuyerDelete(),
    rowData: rowDataSelector(),
    columnDefs: columnDefsSelector(),
    loading: loadingSelector(),
    pageProps: pagePropsSelector(),
    isColumnDefsLoaded: columnFlagSelector(),
    filterProps: filterPropsSelector(),
    columnInfo: columnInfoSelector(),
    isAPIProgress: isAPIProgressSelector(),
    totalCount: totalCountSelector(),
    moreRecordsAvailable: moreRecordsSelector(),
    apiCallCount: apiCallCountSelector(),
    updateColumnsList: updateColumnsListSelector(),
    errorMessages: errorMessageLabels(),
    buyers: buyersListSelector(),
})

function mapDispatchToProps(dispatch, ownProps) {
    return {
        dispatch,
        getBuyerDeleteList: (data) => dispatch(getBuyerDeleteList(ownProps.nameSpace, data)),
        setApiCallCount: (data) => dispatch(setApiCallCount(ownProps.nameSpace, data)),
        onSetPageProps: (data) => dispatch(onSetPageProps(ownProps.namespace, data)),
        getBuyerDeleteColumnDefs: (data) => dispatch(getBuyerDeleteColumnDefs(ownProps.nameSpace, data)),
        setFilterValues: (data) => dispatch(setFilterValues(ownProps.nameSpace, data)),
        setColumnDefsLoaded: (data) => dispatch(setColumnDefsLoaded(ownProps.nameSpace, data)),
        updateShowHide: (data) => dispatch(updateShowHide(ownProps.nameSpace, data)),
        resetStateData: (data) => dispatch(resetStateData(ownProps.nameSpace, data)),
        resetDefault: (data) => dispatch(resetDefault(data)),
        getBuyersList: (data) => dispatch(getBuyersList(ownProps.nameSpace, data)),
        setLabelDataFlags: (data) => dispatch(setLabelDataFlags(ownProps.nameSpace, data)),
    }
}

const withConnect = connect(
    mapStateToProps,
    mapDispatchToProps,
);
const withReducer = injectReducer({ key: 'buyerDeleteReducer', reducer });
const withSaga = injectSaga({ key: 'buyerDeleteSaga', saga });
export default compose(
    withReducer,
    withSaga,
    withConnect,
    withStyles(styles),
)(DeleteDialog);

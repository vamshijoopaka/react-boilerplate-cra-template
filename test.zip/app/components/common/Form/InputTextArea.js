
/*
* * //==========================================================================
*
* * // Copyright 2021-2021, Blue Yonder Group, Inc.
*
* * // All Rights Reserved
*
* * //
*
* * // THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF
*
* * // BLUE YONDER GROUP, INC.
*
* * //
*
* * //
*
* * // The copyright notice above does not evidence any actual
*
* * // or intended publication of such source code.
*
* * //
*
* * // ===========================================================================
*/
import React from 'react';
import { TextareaAutosize, withStyles } from '@material-ui/core';
import PropTypes from 'prop-types';
import theme from '../../../jda-gcp-theme';

const propTypes = {
    rowsMax: PropTypes.number,
    rowsMin: PropTypes.number,
    onChange: PropTypes.func
}
const defaultProps = {
    rowsMax: 3,
    rowsMin: 1
}

const styles = theme => ({
    wrapper: {
        width: '100%',
        resize: 'none',
        lineHeight: '1rem'
    }
})

class InputTextArea extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            cursorPosition: false,
            updateCount: 0,
            textFieldCleared: false,
        }
    }

    componentDidMount() {
        this.textFieldValue = this.props.value;
        this.setState({ updateCount: 0 });
    }

    componentDidUpdate(prevProps) {
        const { value } = this.props;
        if (value && (value != prevProps.value)) {
            this.textFieldValue = this.props.value;
            let elm = document.getElementById(this.props.field.key);
            if (elm) {
                elm.setSelectionRange(this.state.cursorPosition, this.state.cursorPosition);
            }
        }
    }

    onChange = (event) => {
        this.textFieldValue = event.currentTarget.value;
        this.setState({ cursorPosition: event.target.selectionStart });
        if (this.state.updateCount == 0 || this.textFieldValue == '' || this.state.textFieldCleared == true) {
            this.setState({ updateCount: this.state.updateCount + 1 });
            this.props.onChange(this.props.field.key, this.textFieldValue)
        }

        /**E3C-29977-RRUDRA- onChange not triggered in few scenarios: 
        1. Enter some text, Select All and Delete/BackSpace; 
        3. Enter text again, -> onChange not triggered
        Solution: trigger event everytime you start entering the text **/

        if (this.textFieldValue.trim().length == 0 && this.state.textFieldCleared == false) {
            this.setState({ textFieldCleared: true })
        }
        else if (this.textFieldValue.trim().length > 0 && this.state.textFieldCleared == true) {
            this.setState({ textFieldCleared: false })
        }
        //E3C-29977-End
    }

    onBlur = () => {
        this.setState({ updateCount: 0 });
        this.props.onChange(this.props.field.key, this.textFieldValue)
    }

    render() {
        const { value, rowsMax, rowsMin, classes, field } = this.props;
        return (
            <TextareaAutosize
                id={field.key}
                className={classes.wrapper}
                rowsMin={rowsMin}
                onBlur={this.onBlur}
                value={this.textFieldValue}
                rowsMax={rowsMax}
                onChange={this.onChange}
            ></TextareaAutosize>
        )
    }
}

InputTextArea.defaultProps = defaultProps;
InputTextArea.propTypes = propTypes;
export default withStyles(styles)(InputTextArea);
export const STOCK_STATUS_CARD_KEY = "25426";
export const ADJ_TO_STOCK_STS_CARD_KEY = "51015";
export const INFORMATION_ONLY_CARD_KEY = "51014";
export const PERIOD_TO_DATE_CARD_KEY = "51016";
export const UNIT_DISTRIBUTION_CARD_KEY = "50891";

export const ITEM_STOCK_CLASSIFICATION = {
    "IOVUNT_PCT" :0,
    "IPOUNT_PCT": 0, 
    "IPRUNT_PCT": 0, 
    "IFBUNT_PCT": 0, 
    "IDLUNT_PCT": 0,
    "IRPUNT_PCT": 0,
    "ISSUNT_PCT": 0
};
 
export const ITEM_STOCK_STATUS_DEMAND_TO_DATE = 

{
  FDDATR: "                                                  "
  ,FDDDIV: "0"
  ,FDDECP: "0"
  ,FDDEFN: "                                                  "
  ,FDDPRN: "0"
  ,FDFCLS: "S"
  ,FDFILD: "1092"
  ,FDFLEN: "7"
  ,FDFNAM: "DEMPD"
  ,FDFTYP: "N"
  ,FDLTRL: "                                                  "
  ,FDMASK: "                                                  "
  ,FDMAXV: "9999999.0000"
  ,FDMINV: ".0000"
  ,FDPRFX: "0"
  ,FDPROD: " "
  ,FDVLDT: "N"
  ,FDZAPO: "M"
  ,FLDID: "1092"
  ,FLDTYPE: "RightLabel"
  ,FLDVLD: ""
  ,TDEFN: "IDT_51017                                     "
  ,TIDNO: "51017"
  ,TLANG: "ENG"
  ,TLLAB: "Demand to Date"
  ,TPROD: " "
  ,TSLAB: ""
  ,TULLB: ""
  ,TUSLB: ""
  ,dataType: "labels"
  ,defaultValue: ""
  ,isCheckWildCard: true
  ,isColumnEditable: false
  ,key: "IDEMPD"
  ,labelPlacement: "start"
  ,maxLength: 7
  ,prefixFlag: 0
  ,toUppercase: true
  ,width: 78
}
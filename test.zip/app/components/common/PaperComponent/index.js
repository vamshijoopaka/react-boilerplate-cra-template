import React from 'react';
import Draggable from 'react-draggable';
import Paper from '@material-ui/core/Paper';


class PaperComponent extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <Draggable cancel = { '[class*="MuiDialogContent-root"]'} >
                <Paper {...this.props} />
            </Draggable >
        );
    }
}

export default PaperComponent;


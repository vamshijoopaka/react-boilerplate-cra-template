import React from 'react';
import PropTypes from 'prop-types';
import { Grid, withStyles } from '@material-ui/core';
import DemandGraph from './DemandGraph';
import AccountTable from './AccountTable';
import AccountDetailTable from './AccountDetailTable';
import AddSubtractDemandPopup from './AddSubtractDemandPopup';

const styles = () => ({
  btn: {
    width: '100%',
    margin: '10px',
  },
});

class SpecialAccountHistory extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = this.getTableData();
  }

  getTableData = () => {
    const { categories, series, specialAccountHistoryOptions } = this.props;
    const yearsSeries = series.filter(s => !isNaN(parseInt(s.name, 10)));
    const years = yearsSeries.map(s => s.name);
    const filterYear = years[years.length - 1];
    return {
      categories,
      series: series.filter(s => s.name === filterYear),
      selectedYear: filterYear,
      specialAccountHistorySeries:
        specialAccountHistoryOptions && specialAccountHistoryOptions.series
          ? specialAccountHistoryOptions.series[filterYear]
          : null,
      selectedAccountID: null,
      isAddSubtractDemandPopupOpen: false,
      addSubtractDemandPopupTitle: '',
      currentSelectedSpclAccount:false,
    };
  };

  onRowSelect = name => {
    const { series, specialAccountHistoryOptions } = this.props;
    this.setState({
      series: series.filter(s => s.name === name),
      selectedYear: name,
      specialAccountHistorySeries:
        specialAccountHistoryOptions && specialAccountHistoryOptions.series
          ? specialAccountHistoryOptions.series[name]
          : null,
    });
  };

  onChange = (period, year, data) => {
    let d = parseInt(data, 10);
    if (isNaN(d)) {
      d = 0;
    }
    this.props.updateSpecialAccountHistoryData(
      period,
      year,
      d,
      this.state.selectedAccountID,
    );
    this.props.onChange('saveSpecialAccount');
  };

  selectSpecialAccountHistory = accountID => {
    this.setState({
      selectedAccountID: accountID,
    });
    this.props.selectSpecialAccountHistory(accountID);
  };

  onAction = value => {
    switch (value) {
      case 'addToTotalDemand':
       this.props.specialAccountUpd(this.spclAccountUpd('C',this.props.specialAccountHistoryOptions.series,this.props.ItemData,this.state.currentSelectedSpclAccount,'N',this.props.specialAccountHistoryOptions.categories));
        this.setState({
          isAddSubtractDemandPopupOpen: true,
          addSubtractDemandPopupTitle: 'Add to Total Demand',
        });
        break;
      case 'subtractFromTotalDemand':
        this.props.specialAccountUpd(this.spclAccountUpd('C',this.props.specialAccountHistoryOptions.series,this.props.ItemData,this.state.currentSelectedSpclAccount,'Y',this.props.specialAccountHistoryOptions.categories));
        this.setState({
          isAddSubtractDemandPopupOpen: true,
          addSubtractDemandPopupTitle: 'Subtract from Total Demand',
        });
        break;
      default:
        break;
    }
  };

  onClose = () => {
    this.setState({
      isAddSubtractDemandPopupOpen: false,
      addSubtractDemandPopupTitle: '',
    });
  };
  yAxisPointValueChange=(newYval,category)=>{
    if(newYval && category){
    let rowData = {...this.props.specialAccountHistoryOptions.series}
    let colDefs = {...this.props.specialAccountHistoryOptions.categories}
    let weekNumber;
    Object.keys(colDefs).map(key => {if(colDefs[key]==category){
      weekNumber = key;
    }})
    rowData[this.state.selectedYear].data[weekNumber] = parseInt(newYval);
    this.setState({ refreshCellsAfterDrag: true }, () => { this.setState({ refreshCellsAfterDrag: false }) })
    return rowData;

  }else{
    return this.props.specialAccountHistoryOptions.series;
  }
}

spclAccountUpd=(actionCode,rowsData,ItemData,currentSelectedSpclAccount,addSubCode,categories)=>{
  const rowKeys = Object.keys(rowsData);
  let obj ={
    WRECD: "6426",
    WSTAT: actionCode,
    WCOMP: "E3T",
    WWHSE: ItemData.IWHSE,
    WVNDR: ItemData.IVNDR,
    WITEM: ItemData.IITEM,
    WSTYPE: "G",
    WACCT: currentSelectedSpclAccount,
    WINCD: addSubCode,
    }
    //Loops to frame -> WDM101-WDM152, WDM201-WDM252, WDM301-WDM352, WDM401-WDM452
    for (let wdm_i = 1; wdm_i <= 4; wdm_i++) {

      for (let i = 0; i < 52; i++) {
        const objKey = 'WDM' + wdm_i + `${i + 1}`.padStart(2, '0');
        obj[objKey] = rowsData[rowKeys[4 - wdm_i]].data[`${i}`].toString();
        
        //need WDAT01 TO WDAT52 only
        if (wdm_i === 1) {
          obj['WDAT' + `${i + 1}`.padStart(2, '0')] = categories[i];
        }
      }

      //WYEAR1 to WYEAR4 = rowKeys[3] to rowKeys[0];
      obj['WYEAR' + wdm_i] = rowKeys[4 - wdm_i];
    }
    return obj;
}

getSelectedSpclAccount=(selectedRow)=>{
  this.setState({currentSelectedSpclAccount : selectedRow[0].WACCT})
}

  componentDidUpdate(prevProps) {
    const { specialAccountHistoryOptions } = this.props
    if (specialAccountHistoryOptions && specialAccountHistoryOptions != prevProps.specialAccountHistoryOptions) {
      this.setState({ refreshCells: true }, () => { this.setState({ refreshCells: false }) })
    }

  }

  render() {
    const {
      specialAccountHistoryOptions,
      specialAccountIDTableData,
      cardfields,
      canUpdateComponent,
    } = this.props;
    const { categories } = specialAccountHistoryOptions;
    const {
      columnDefs,
      columnInfo,
      pageProps,
      rowData,
    } = specialAccountIDTableData;
    return (
      <React.Fragment>
        <Grid container>
          <Grid item xs={12} sm={12} md={8} lg={9} xl={10}>
            {categories && this.state.series && this.state.specialAccountHistorySeries ? (
              <DemandGraph
              categories={categories}
              series={[
                ...this.state.series,
                this.state.specialAccountHistorySeries,
              ]}
              yAxisPointValueChange = {this.yAxisPointValueChange}
            />) : null}
          </Grid>
          <Grid item xs={12} sm={12} md={4} lg={3} xl={2}>
            <AccountTable
              specialAccountIDTableData={specialAccountIDTableData}
              selectSpecialAccountHistory={this.selectSpecialAccountHistory}
              columnDefs={columnDefs}
              columnInfo={columnInfo}
              pageProps={pageProps}
              rowData={rowData}
              onAction={this.onAction}
              canUpdateComponent={canUpdateComponent}
              getSelectedSpclAccount = {this.getSelectedSpclAccount}
            />
          </Grid>
          <Grid
            item
            xs={12}
            sm={12}
            md={12}
            lg={12}
            xl={12}
            style={{ marginTop: 10 }}
          >
            <AccountDetailTable
              columnDefs={
                specialAccountHistoryOptions
                  ? specialAccountHistoryOptions.categories
                  : []
              }
              rowsData={
                specialAccountHistoryOptions &&
                specialAccountHistoryOptions.series
                  ? this.yAxisPointValueChange()
                  : {}
              }
              onRowSelect={this.onRowSelect}
              selectedYear={this.state.selectedYear}
              onChange={this.onChange}
              canUpdateComponent={canUpdateComponent}
              refreshCells = {this.state.refreshCells} 
              refreshCellsAfterDrag={this.state.refreshCellsAfterDrag}
            />
          </Grid>
          <AddSubtractDemandPopup
            isOpen={this.state.isAddSubtractDemandPopupOpen}
            onClose={this.onClose}
            title={this.state.addSubtractDemandPopupTitle}
            getItemsEmbeddedListColumns={this.props.getItemsEmbeddedListColumns}
            itemsEmbeddedList={this.props.itemsEmbeddedList}
            cardfields={cardfields}
            specialAccountHistoryAction={this.props.specialAccountHistoryAction}
            canUpdateComponent={canUpdateComponent}
          />
        </Grid>
      </React.Fragment>
    );
  }
}

SpecialAccountHistory.propTypes = {
  classes: PropTypes.object,
  categories: PropTypes.array,
  series: PropTypes.array,
  specialAccountHistoryOptions: PropTypes.object,
  updateSpecialAccountHistoryData: PropTypes.func,
  specialAccountIDTableData: PropTypes.object,
  openSpecialAccountHistoryDialog: PropTypes.bool,
  onClose: PropTypes.func,
  selectSpecialAccountHistory: PropTypes.func,
  getItemsEmbeddedListColumns: PropTypes.func,
  onChange: PropTypes.func,
  itemsEmbeddedList: PropTypes.object,
};

export default withStyles(styles)(SpecialAccountHistory);

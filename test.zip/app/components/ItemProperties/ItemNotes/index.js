/** Change Log
 * LogStart --  Story: E3C-33260 --Note is not getting saved. Check after some time, the note is not there.
*/
import React from 'react';
import { connect } from 'react-redux';
import { compose } from 'redux';
import { withStyles } from '@material-ui/core/styles';
import injectReducer from 'utils/injectReducer';
import injectSaga from 'utils/injectSaga';


import { createMuiTheme, Box, Typography } from '@material-ui/core';
import theme from '../../../jda-gcp-theme';

import reducer from './reducer';
import saga from './saga';
import FormattedMessageComponent from '../../common/FormattedMessageComponent';
import {
    LABEL_NOTE, ITEM_NOTES_FILTER_PROPS,
    ITEM_NOTES,
    NO_NOTES_TO_SHOW_TEXT,
    FILTER_DATA,
    NOTES_TEXT_ACCESSOR,
    MENU_ITEMS,
    NOTES_KEY_ACCESSOR
} from './constants';
import {
    getItemNotes, clearNotesData, getNoteDetails, setSelectedNoteDetails, controlNoteCreation, setControlNoteCount,
    removeNoteByKey, clearAllItemNotes, setIsEmbeddedList, clearStateValues
} from './action';
import { selectData , makeSelectCompanyDetails} from './selector';
import AccordionComponent from '../../common/AccordionComponent';
import {
    COLUMN_FIELD_LEN,
    COLUMN_VALUE_ACCESSOR
} from '../../common/constants';

import {
    getListPredecessor,
    handleFieldValuesByLength,
    prepareValueWithSpaces
} from 'utils/util';
import NoteProperties from '../../../containers/common/NoteProperties';
import ContextMenu from '../../common/ContextMenu';
import MoreVertIcon from '@material-ui/icons/MoreVert';
import { NOTE_DETAILS_FILTER } from '../../../containers/common/NoteProperties/constants';
import { isEqual } from 'lodash';
import { leftPad } from '../../../utils/util';
import { getNewNoteCreationControlBody } from '../../../utils/noteUtils';

const propTypes = {

}

const themes = createMuiTheme(theme);

const style = theme => ({
    ItemNotesPanelWrapper: {
        borderRadius: '4px',
        overflow: 'hidden',
        border: '1.5px solid var(--divider-line)',
        fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
        marginBottom: '1rem',
    },
    ItemNotesPanelDetails: {
        display: 'flex',
        flexDirection: 'column',
        width: '100%',
        maxHeight: '300px',
        overflowY: 'auto'
    },
    ItemNotesCount: {
        padding: '2px 10px 1px 10px',
        border: '1.5px solid var(--divider-line)',
        borderRadius: '10px',
        margin: '0 16px',
        backgroundColor: 'var(--secondary-s5)',
    },
    ItemNotesNote: {
        padding: '1rem',
        border: '1px',
        borderBottom: '1px solid var(--divider-line)',
        '&:last-child': {
            borderBottom: 'none',
        },
        '&:hover': {
            backgroundColor: 'var(--list-hover)',
        }
    },
    NoNotesToShow: {
        display: 'flex',
        width: '100%',
        justifyContent: 'center',
        alignItems: 'center',
        padding: '1rem'
    },
    selectedNote: {
        backgroundColor: 'var(--list-hover)'
    },
    notesActionWrapper: {
        display: 'flex',
        alignSelf: 'flex-end',
        paddingBottom: '10px'
    },
    notesParent: {
        display: 'flex',
        flexDirection: 'column',
        width: '100%'
    },
});

class ItemNotes extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            isItemNotesPanelExpanded: true,
            notesCount: 0,
            notesArray: false,
            isOpenProperties: false,
            isOpenContextMenu: false,
            menuRef: null,
            isUpdateType: false,
            selectedIndex: -1,
            hasToDeleteAll: false,
            hasToDelete: false,
            noteKeyForDetails: false,
            menuList: MENU_ITEMS,
            allowUpdateSecurity: true,
        }
        this.prepareKeyValue = this.prepareKeyValue.bind(this);
        this.prepareFilterProps = this.prepareFilterProps.bind(this);
    }

    getApiObj(filterProps, currentPage, pageProps) {

        let apiObj = {
            filterProps,
            pageProps: pageProps,
            direction: pageProps.isForwardDirection,
            currentPage: currentPage,
            parentPage: ITEM_NOTES
        };
        return apiObj;
    }

    prepareKeyValue(jsonData) {
        const { columnDefs, currentPage } = this.props;
        let headerKey = COLUMN_VALUE_ACCESSOR;
        let fieldLenKey = COLUMN_FIELD_LEN;
        let filterValues = FILTER_DATA;
        if (columnDefs && columnDefs.length) {
            let filterData = '';
            filterValues.forEach((filter) => {
                let columnData = columnDefs.find((column) => {
                    let columnKey = column[headerKey].trim();
                    return columnKey == filter;
                });
                if (columnData && Object.keys(columnData) && Object.keys(columnData).length) {
                    let fieldLen = Number(columnData[fieldLenKey].trim());
                    let columnKey = columnData.prefixFlag ? (columnData[headerKey].trim()) : (getListPredecessor(currentPage) + columnData[headerKey].trim());
                    let dataValue = jsonData[columnKey] ? jsonData[columnKey].trim() : jsonData[columnKey];
                    let str = handleFieldValuesByLength(dataValue, fieldLen);
                    filterData = filterData + str;
                }
            })
            filterData = filterData + prepareValueWithSpaces("", 22);
            return filterData;
        }
        return '';
    }

    prepareFilterProps(data) {
        let filterData = JSON.parse(JSON.stringify(data));
        const { currentPage, currentRecordData, fromPage } = this.props;
        filterData[0]["fieldValue"] = getListPredecessor(fromPage) + " ";
        filterData[1]["fieldValue"] = this.prepareKeyValue(currentRecordData);
        return filterData;
    }

    componentWillUnmount(){
        this.props.clearStateValues();
    }

    componentDidMount() {
        const { filterProps, columnDefs , canUpdateComponent} = this.props;
        const { pageProps, notesArray } = this.props.ItemNotesData;
        this.props.clearNotesData();
        this.props.setNotesCount(0); //E3C30273_RRUDRA_Set counts to zero when switching from one tab to other

        //E3C30273_RRUDRA_Disable removeAll if Notes count is zero
        let menuList = this.state.menuList;
        menuList[0].isDisable = true;
        this.setState({ menuList: menuList });
        this.setState({ notesCount: notesArray.length });
        if (columnDefs && columnDefs.length) {
            this.loadItemNotes();
        }
        //If security 
        if (canUpdateComponent && Object.keys(canUpdateComponent) && Object.keys(canUpdateComponent).length) {

            menuList.forEach((menuItem) =>{
                menuItem['isDisable'] = canUpdateComponent.update ? false : true; //E3C30659-apply security restrictions in addition to field check 
            })
            this.setState({ menuList });
            canUpdateComponent.update ? this.setState({allowUpdateSecurity: true}) : this.setState({allowUpdateSecurity: false});
        }
    }

    loadItemNotes = () => {
        const { bracketsNotesFilterObj, currentRecordData } = this.props;
        if (bracketsNotesFilterObj && currentRecordData) {
            this.prepareChangedFilterObj();
        } else{
            let filterData = this.prepareFilterProps(ITEM_NOTES_FILTER_PROPS);
            //RRUDRA_send company date along with reach request for notes list
            let record = {CJDATE : this.props.companyDetails['CJDATE']}
            if (record.CJDATE != undefined) { //E3C-33260, 10/14/21, Kumar:Start
                this.props.getItemNotes({body :this.getApiObj(filterData, ITEM_NOTES, this.props.ItemNotesData.pageProps), record});
            } //E3C-33260, 10/14/21, Kumar:End
        }
    }

    changeJSONObjectValues = (key, value, jsonObj) => {
        let headerKey = COLUMN_VALUE_ACCESSOR;
        let fieldLenKey = COLUMN_FIELD_LEN;
        const { bracketsNotesFilterObj, currentPage, currentRecordData, fromPage, columnDefs } = this.props;
        let filterData = FILTER_DATA;
        if (columnDefs && columnDefs.length && jsonObj) {
            let columnData = columnDefs.find((column) => {
                let columnKey = column[headerKey].trim();
                return columnKey == key;
            });
            if (columnData && Object.keys(columnData) && Object.keys(columnData).length) {
                let columnKey = columnData.prefixFlag ? (columnData[headerKey].trim()) : (getListPredecessor(currentPage) + columnData[headerKey].trim());
                jsonObj[columnKey] = value;
            }
        }
        return jsonObj;
    }

    prepareChangedFilterObj = () => {
        const { pageProps } = this.props.ItemNotesData;
        const { bracketsNotesFilterObj, currentPage, currentRecordData, fromPage, columnDefs } = this.props;
        let jsonObj = JSON.parse(JSON.stringify(currentRecordData));
        let filterValues = FILTER_DATA;

        if (bracketsNotesFilterObj) {
            if (bracketsNotesFilterObj.warehouseId) {
                jsonObj = this.changeJSONObjectValues(filterValues[3], bracketsNotesFilterObj.warehouseId, jsonObj);
            }
            if (bracketsNotesFilterObj.itemId) {
                jsonObj = this.changeJSONObjectValues(filterValues[1], bracketsNotesFilterObj.itemId, jsonObj);
            }
            if (bracketsNotesFilterObj.subitemId) {
                jsonObj = this.changeJSONObjectValues(filterValues[2], bracketsNotesFilterObj.subitemId, jsonObj);
            }
        }

        let filterData = JSON.parse(JSON.stringify(ITEM_NOTES_FILTER_PROPS));
        filterData[0]["fieldValue"] = getListPredecessor(fromPage) + " ";
        filterData[1]["fieldValue"] = this.prepareKeyValue(jsonObj);
        //RRUDRA_send company date along with reach request for notes list
        let record = {CJDATE : this.props.companyDetails['CJDATE']}
        if (record.CJDATE != undefined) { //E3C-33260, 10/14/21, Kumar:Start
            this.props.getItemNotes({body: this.getApiObj(filterData, ITEM_NOTES, pageProps), record});
        } //E3C-33260, 10/14/21, Kumar:End
    }

    componentDidUpdate(prevProps) {
        const { notesArray, pageProps, selectedNoteDetails, controlCount, allNotesDetails, combinedNotes, isSetEmbeddedList } = this.props.ItemNotesData;
        const { columnDefs, currentRecordData, bracketsNotesFilterObj, canUpdateComponent, companyDetails } = this.props; //E3C-33260, 10/14/21, Kumar

        if (isSetEmbeddedList != prevProps.ItemNotesData.isSetEmbeddedList && isSetEmbeddedList) {
            if (this.props.updatedNotesData)
                this.props.updatedNotesData();
            this.props.setIsEmbeddedList();
        }

        if (bracketsNotesFilterObj && (JSON.stringify(bracketsNotesFilterObj) != JSON.stringify(prevProps.bracketsNotesFilterObj))) {
            this.props.clearNotesData(); //E3C30273
            this.loadItemNotes();
        }

        if (notesArray && !isEqual(notesArray,  prevProps.ItemNotesData.notesArray)) {
            if(notesArray['listArray'])
              this.setState({ notesCount: notesArray.listArray.length });
            else 
              this.setState({ notesCount: notesArray.length });
        }
        if (columnDefs && (JSON.stringify(columnDefs) != JSON.stringify(prevProps.columnDefs))) {
            this.loadItemNotes();
        }
        if ((JSON.stringify(currentRecordData) != JSON.stringify(prevProps.currentRecordData)) && currentRecordData) {
            this.props.clearNotesData(); //E3C30273
            this.loadItemNotes();
        }
        if ((controlCount == 0) && (prevProps.ItemNotesData.controlCount != 0) && (this.state.hasToDelete || this.state.hasToDeleteAll)) {
            this.setState({ hasToDelete: false, hasToDeleteAll: false });
            this.loadItemNotes();
        }
        if (companyDetails && !isEqual(companyDetails,  prevProps.companyDetails)) { //E3C-33260, 10/14/21, Kumar:Start
            this.props.clearNotesData(); //E3C30273
            this.loadItemNotes();
        } //E3C-33260, 10/14/21, Kumar:End
        if (!this.state.noteKeyForDetails && combinedNotes && combinedNotes.length && !isEqual(combinedNotes, prevProps.ItemNotesData.combinedNotes) && (!allNotesDetails.length)) {
            this.setState({ noteKeyForDetails: false });
            combinedNotes.forEach((note, index) => {
                this.getNoteDetails(note[0][NOTES_KEY_ACCESSOR], true, true);
            })
        }
        // After adding new node or updating
        if (this.state.noteKeyForDetails && combinedNotes && combinedNotes.length && (!isEqual(combinedNotes, prevProps.ItemNotesData.combinedNotes) || !isEqual(allNotesDetails, prevProps.ItemNotesData.allNotesDetails))) {
            this.setState({ noteKeyForDetails: false });
            this.getNoteDetails(this.state.noteKeyForDetails, false, true);
        }
        //~~~CreateNewFramework--JVK
        if (this.props.isOpenNote && this.props.isOpenNote !== prevProps.isOpenNote) {
            this.setNotePropertiesOpen(true, false);
        }
        //~~~CreateNewFramework--JVK

        if (allNotesDetails && !isEqual(allNotesDetails, prevProps.ItemNotesData.allNotesDetails)) {
            //update notes in Header
            this.props.setNotesCount(allNotesDetails.length);

            //Disable or Enable right menu 'Remove All' options of Notes based on notes count  
            if (allNotesDetails.length == 0 && this.state.menuList[0].isDisable == false) {
                let menuList = this.state.menuList;
                menuList[0].isDisable = true;
                this.setState({ menuList: menuList });
            }

            if (allNotesDetails.length > 0 && this.state.menuList[0].isDisable == true) {
                let menuList = this.state.menuList;
                //Enable RemoveAll if updateAuthority is true;
                if (canUpdateComponent && Object.keys(canUpdateComponent) && Object.keys(canUpdateComponent).length) {
                    canUpdateComponent.update ? menuList[0].isDisable = false : menuList[0].isDisable = true ; 
                } else {
                    menuList[0].isDisable = false ; //Enable RemoveAll 
                }
                this.setState({ menuList: menuList });
            }

        }
    }

    setNotePropertiesOpen = (val, noteType) => {
        this.props.setSelectedNoteDetails(false);
        if (!val) {
            this.setState({ hasToDelete: false, hasToDeleteAll: false });
        }
        this.setState({ isOpenProperties: val });
        this.setState({ isUpdateType: noteType ? noteType : false });
        //~~~CreateNewFramework--JVK
        if (typeof this.props.closeNote === 'function' && (noteType && noteType == false)) {
            this.props.closeNote(val);
        }
        //~~~CreateNewFramework--JVK
    }

    // Close or open context menu
    setIsOpenContextMenu(val) {
        this.setState({ isOpenContextMenu: Boolean(val) });
        this.setState({ menuRef: val.currentTarget ? val.currentTarget : val });
    }

    handleItemSelection = (val) => {
        switch (val) {
            case this.state.menuList[1].key: this.setNotePropertiesOpen(true); break;
            case this.state.menuList[0].key: this.deleteAllNotes(); break;
        }
        this.setIsOpenContextMenu(false);
    }
    deleteAllNotes = () => {
        this.setState({ hasToDeleteAll: true });
        this.props.clearAllItemNotes();
        this.props.ItemNotesData.allNotesDetails.forEach((note, index) => {
            this.deleteNote(note[0]);
        })
    }
    getNoteDetails = (indexOrKey, allFlag, isKey) => {
        const { combinedNotes, pageProps, allNotesDetails } = this.props.ItemNotesData;
        let filters = JSON.parse(JSON.stringify(NOTE_DETAILS_FILTER));
        let key = isKey ? indexOrKey : allNotesDetails[indexOrKey][0][NOTES_KEY_ACCESSOR];
        key = leftPad(key, 7, '0');
        filters[0].fieldValue = key;
        let record = {CJDATE:this.props.companyDetails['CJDATE'] }
        if (record.CJDATE != undefined) { //E3C-33260, 10/14/21, Kumar:Start
            this.props.getNoteDetails({ body: this.getApiObj(filters, ITEM_NOTES, pageProps), allFlag, record })
        } //E3C-33260, 10/14/21, Kumar:End
    }

    getApiObj(filterProps, currentPage, pageProps) {

        let apiObj = {
            filterProps,
            pageProps: pageProps,
            direction: pageProps.isForwardDirection,
            currentPage: currentPage,
        };
        return apiObj;
    }

    onClickRemove = () => {
        // delete selectedIndex row
        this.setState({ hasToDelete: true });
        let data = this.props.ItemNotesData.allNotesDetails[this.state.selectedIndex][0]
        this.deleteNote(data);
        this.props.removeNoteByKey({ key: data[NOTES_KEY_ACCESSOR], filterAllNotes: true, filterCombined: true });
    }

    noteSelection = (index) => {
        this.setState({ selectedIndex: index });
    }

    deleteNote = (data) => {
        const { currentRecordData, currentPage } = this.props;
        let body = getNewNoteCreationControlBody(data, 'D', currentPage, ITEM_NOTES, currentRecordData, data[NOTES_KEY_ACCESSOR]);
        this.props.controlNoteCreation({ body });
    }

    reloadNotes = (noteKey, isFutureDate) => {
        let key = leftPad(noteKey, 7, '0');
        if (!isFutureDate) {
            if (this.state.isUpdateType) {
                this.props.removeNoteByKey({ key, filterAllNotes: true });
            } else {
                this.loadItemNotes();
            }
            this.setState({ noteKeyForDetails: key });
        } else {
            if (this.state.isUpdateType)  this.props.removeNoteByKey({ key, filterAllNotes: true, filterCombined: true });
        }
    }

    render() {

        const { classes, noteLabelJson , canUpdateComponent} = this.props;
        const { isItemNotesPanelExpanded, notesCount } = this.state;
        const { notesArray, combinedNotes, selectedNoteDetails, allNotesDetails } = this.props.ItemNotesData;
        return (
            <div className={classes.ItemNotesPanelWrapper}>
                <AccordionComponent
                    isPanelExpanded={isItemNotesPanelExpanded}
                    onChange={(event, expanded) => this.setState({ isItemNotesPanelExpanded: expanded })}
                    label={LABEL_NOTE}
                    count={allNotesDetails.length}
                    badgeWidth = {allNotesDetails.length < 10 ? '22px': '27px'}
                >
                    <div className={classes.notesParent}>
                        <div className={classes.notesActionWrapper}>
                        {(notesCount > 0) && (this.state.selectedIndex > -1) && <Box mr={theme.spacing(1)}><Typography onClick={() => { this.setNotePropertiesOpen(true, true) }} className={'cPointer'}>{<FormattedMessageComponent id={'51182'}></FormattedMessageComponent>}</Typography></Box>}
                        {(notesCount > 0) && (this.state.selectedIndex > -1) && (this.state.allowUpdateSecurity) && <Box mr={theme.spacing(1)}><Typography onClick={() => this.onClickRemove()} className={'cPointer'}>{<FormattedMessageComponent id={'25303'}></FormattedMessageComponent>}</Typography> </Box>}
                            {MENU_ITEMS && MENU_ITEMS.length &&
                                <div onMouseEnter={(event) => this.setIsOpenContextMenu(event)}
                                    onMouseLeave={(event) => this.setIsOpenContextMenu(false)}>
                                    <MoreVertIcon className={'cPointer'}></MoreVertIcon>
                                    <ContextMenu menuList={this.state.menuList} isOpen={this.state.isOpenContextMenu} handleItemSelection={(val) => this.handleItemSelection(val)} handleMenuClose={(val) => this.setIsOpenContextMenu(val)} menuRef={this.state.menuRef}></ContextMenu>
                                </div>
                            }
                        </div>
                        {combinedNotes && allNotesDetails && allNotesDetails.length && (combinedNotes.length == allNotesDetails.length) ? <Box className={classes.ItemNotesPanelDetails}>
                            {combinedNotes && allNotesDetails && allNotesDetails.length && (combinedNotes.length == allNotesDetails.length) ? allNotesDetails.map((note, index) => {
                                return (<div onClick={() => this.noteSelection(index)} key={"noteslist" + index} className={classes.ItemNotesNote + ' ' + (this.state.selectedIndex == index ? classes.selectedNote : "")}>
                                    <span>{note.length > 1 ? (note[0][NOTES_TEXT_ACCESSOR] + '...') : note[0][NOTES_TEXT_ACCESSOR]}</span>
                                </div>);
                            }) : (
                                    <div className={classes.NoNotesToShow}>{NO_NOTES_TO_SHOW_TEXT}</div>
                                )}
                        </Box> : ""}
                    </div>
                    {/* <Spinner loading={true} type="notes"></Spinner>} */}
                </AccordionComponent>
                {this.state.isOpenProperties && (!this.state.isUpdateType || (this.state.isUpdateType && allNotesDetails[this.state.selectedIndex])) && <NoteProperties
                    reloadNotes={(noteKey, isFutureDate) => { this.reloadNotes(noteKey, isFutureDate) }}
                    currentRecordData={this.props.currentRecordData}
                    notesCurrentPage={ITEM_NOTES}
                    isUpdateType={this.state.isUpdateType}
                    noteKey={this.state.isUpdateType ? allNotesDetails[this.state.selectedIndex][0][NOTES_KEY_ACCESSOR] : false}
                    noteDetails={this.state.isUpdateType ? allNotesDetails[this.state.selectedIndex] : false}
                    currentPage={this.props.currentPage}
                    isOpen={this.state.isOpenProperties}
                    noteLabelJson={noteLabelJson}
                    canUpdateComponent = {canUpdateComponent}
                    clearPopupComponent={(val) => this.setNotePropertiesOpen(false)}>
                </NoteProperties>}
            </div>
        );
    }
}

ItemNotes.propTypes = propTypes;

function mapDispatchToProps(dispatch) {
    return {
        dispatch,
        getItemNotes: (data) => {
            dispatch(getItemNotes(data));
        },
        clearNotesData: () => {
            dispatch(clearNotesData());
        },
        getNoteDetails: (data) => {
            dispatch(getNoteDetails(data))
        },
        setSelectedNoteDetails: (data) => {
            dispatch(setSelectedNoteDetails(data))
        },
        controlNoteCreation: (data) => {
            dispatch(controlNoteCreation(data))
        },
        setControlNoteCount: (data) => {
            dispatch(setControlNoteCount(data))
        },
        removeNoteByKey: (data) => dispatch(removeNoteByKey(data)),
        clearAllItemNotes: () => dispatch(clearAllItemNotes()),
        setIsEmbeddedList: () => dispatch(setIsEmbeddedList()),
        clearStateValues: () => dispatch(clearStateValues())
    }
}

const mapStateToProps = function (state) {
    return {
        ItemNotesData: selectData(state),
        //RRUDRA_get company details from Global App selector
        companyDetails: makeSelectCompanyDetails(state)
        //RRUDRA_end
    }
}

const withReducer = injectReducer({ key: 'ItemNotes', reducer });
const withSaga = injectSaga({ key: 'ItemNotesSaga', saga });

const withConnect = connect(
    mapStateToProps,
    mapDispatchToProps
);

export default compose(
    withReducer,
    withConnect,
    withSaga,
    withStyles(style)
)(ItemNotes);
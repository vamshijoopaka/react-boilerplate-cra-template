import React, { Component } from 'react';
import { Tooltip } from '@material-ui/core';

class CustomizedTooltip extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    const { children, title, placement, arrow } = this.props;

    return (
      <Tooltip
        arrow={ arrow || true }
        placement= { placement || 'top' }
        title={ title ? title : '' }
      >
        {children}
      </Tooltip>
    );
  }
}

export default CustomizedTooltip;

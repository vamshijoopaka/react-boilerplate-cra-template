/**
 *
 * MassmaintenancejobProperties
 *
 */

import React from 'react';
import Typography from '@material-ui/core/Typography';
import { Paper, Box } from '@material-ui/core';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import TableContainer from '@material-ui/core/TableContainer';
import FieldInput from 'components/common/Form/FieldInput';
import ConfirmationDialog from 'components/common/ConfirmationDialog';
import {
	getListPredecessor,
	prepareValueDataForMassmaintenancejobs,
	setSortDataFromSortCriteria,
	getFilterDataFromLocalStorage,
	getFilterDataFromCriteriaDetails,
	getDateFormatValue,
	getFieldNameFromRegex
} from 'utils/util';

import { withStyles } from '@material-ui/core';
import Filter from 'containers/common/Filter';
import FormattedMessageComponent from 'components/common/FormattedMessageComponent';

import {
	getDBSelectorFilterValues,
	prepareTooltipValues
} from 'utils/filterData';


import {
	HeaderAPIValuesJSON,
	DEFAULT_VALUE_URL_DATA,
	EQUALS_TO, GREATER_THAN,
	GREATER_THAN_OR_EQUALS_TO,
	LESS_THAN, LESS_THAN_OR_EQUALS_TO,
	NOT_EQUALS_TO
} from './constants';

import {
	MASSMAINTENANCEJOBS_LIST_PAGE,
	MASSMAINTENANCEJOB_PROPERTIES_PAGE,
	INITIAL_PAGE_PROPS,
	COLUMN_VALUE_ACCESSOR,
	GLOBAL_FILTER_OPTIONS,
	TEXT_ALERT, TEXT_OK,MASSMAINTENANCEJOBS_FILTER_OPTIONS
} from '../common/constants';

import { isEqual } from 'lodash';
import Spinner from '../common/Spinner';
import './styles.scss';
import { updateBreadCrumbContextMenu, onChangeContextMenu } from 'utils/contextMenu';
import Header from './Header';

function TabContainer(props) {
	return (
		<Typography className="minWidth1100" component="div">
			{props.children}
		</Typography>
	);
}

const style = () => ({
	propertiesContentWrapper: {
		margin: '10px auto',
		fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
		borderRadius: '4px',
		overflow: 'hidden',
		boxShadow: '0 2px 4px var(--secondary-s10)',
		overflowX: 'auto',
	},
	hideContent: {
		display: 'none',
	},
	showContent: {
		display: 'block',
	},
	pageContainer: {
		display: 'flex',
		backgroundColor: 'var(--background-app)',
		borderTop: 'none',
		padding: '10px 10px',
	},

	pageContainerFifty: {
		width: '50%',
		display: 'flex',
		flexDirection: 'column',
	},
	pageContainerMax: {
		paddingBottom: '10px',
	},

	simpleCardGroup: {
		width: '100%',
		display: 'flex',
		justifyContent: 'space-around',
	},
	card: {
		padding: '0px',
		backgroundColor: 'var(--background-content)',
		borderRadius: '4px',
		width: '100%',
		'& .MuiCardHeader-root': {
			padding: '22px 20px 0 20px'
		},
		'& .MuiCardContent-root': {
			padding: '16px 15px 10px 15px'
		}
	},
	marginLeftZero: {
		marginLeft: '10px',
	},
	marginRightZero: {
		marginRight: '10px',
	},
	table1: {
		borderRadius: '4px !important'
	},
	table: {
		width: '100%',
	},
	border1: {
		lineHeight: '2rem',
		fontWeight: '500',
		fontSize: '14px',
		paddingLeft: '22px',
		fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
		backgroundColor: 'var(--background-content)',
		color: 'var(--text)',
	},
	border: {
		paddingTop: '12px',
		paddingBottom: '12px',
		paddingLeft: '22px',
		textAlign: 'left',
		color: 'var(--text)',
		fontSize: '14px',
		width: '50%',
		fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
	},
	adjustShowDetail: {
		display: 'flex',
		padding: '10px'
	},
	showDetail: {
		paddingTop: '10px',
	},
	inlineDisplay: {
		display: 'flex',
		'& > div':{
			'& > span':{
				paddingLeft: '5px',
				paddingRight: '5px',
			}
		}
	}
});

class MassmaintenancejobProperties extends React.Component {
	constructor() {
		super();
		this.state = {
			isSaveDataDisabled: true,
			headerData: false,
			columnDefs: [],
			stateData: false,
			totalCount: 0,
			fromPage: false,
			hasError: false,
			errorId: false,
			changeDataAPI: false,
			openFilterPopup: false,
			previousFilterValues: false,
			showConfirmationDialog: false,
			dialogTitle: '',
			hasWarning: false,
			fromListPage: null,
			hasFiltersChanged: false,
			hasSortChanged: false,
			isDataLoaded: false,
			isInitialAPICall: true,
			valueDataFailureMessages: [],
			headerValues: HeaderAPIValuesJSON[0],
			isFiltersChanged: false,
			dialogBody: false,
			parameterValues: [],
			canUpdateComponent: false,
			valueArray: { rerun: '0' },
			predecessor: false
		};

		this.prepareHeaderDataJSON = this.prepareHeaderDataJSON.bind(this);
		this.handleMassmaintenancejobHeaderLeftArrowClick = this.handleMassmaintenancejobHeaderLeftArrowClick.bind(this);
		this.handleMassmaintenancejobHeaderRightArrowClick = this.handleMassmaintenancejobHeaderRightArrowClick.bind(this);
		this.getApiObj = this.getApiObj.bind(this);
		this.makeAPICallForPageUpDown = this.makeAPICallForPageUpDown.bind(this);
		this.getApiObjForPageUpDown = this.getApiObjForPageUpDown.bind(this);
		this.getLabelValue = this.getLabelValue.bind(this);
		this.setRecordDataValues = this.setRecordDataValues.bind(this);
		this.forceUpdateHandler = this.forceUpdateHandler.bind(this);
		this.setFilterValuesFromState = this.setFilterValuesFromState.bind(this);
		this.handleMassmaintenancejobHeaderFilterClick = this.handleMassmaintenancejobHeaderFilterClick.bind(this);
		this.onSaveData = this.onSaveData.bind(this);
		this.onContextMenuChange = this.onContextMenuChange.bind(this);
		this.sendAPICallForValues = this.sendAPICallForValues.bind(this);
		this.handleNoDataSets = this.handleNoDataSets.bind(this);
		this.handleValueDataErrorMessages = this.handleValueDataErrorMessages.bind(this);
		this.handleChangeValue = this.handleChangeValue.bind(this);
	}

	handleNoDataSets() {
		if (this.state.isDataLoaded) {
			this.props.setNoDataCallBackValue(true);
			const paramsString = window.location.search;
			if (paramsString && paramsString.length) {
				const paramsArray = paramsString.split('?');
				if (paramsArray && paramsArray.length && paramsArray.length > 1) {
					const params = paramsArray[1].split('&');
					const tabId = params[0].split('=')[1];
					const breadCrumbId = params[1].split('=')[1];
					this.props.removeCurrentRecordObj(tabId, breadCrumbId);
				}
			}
		}
	}

	handleMassmaintenancejobHeaderFilterClick() {
		if (this.state.isFiltersChanged && this.props.massmaintenancejobPropertiesPage.isValueDataAPIFailure) {
			this.props.onSetFilterProps(this.state.previousFilterValues);
			this.props.setGlobalFilterProps(this.state.previousFilterValues);
			this.props.setChildTabFilterProps(this.state.previousFilterValues);
			this.setState({ isFiltersChanged: false });
			this.props.setValueDataAPIFailureFlag(false);
		}
		this.setState({ openFilterPopup: !this.state.openFilterPopup });
	}

	getLabelValue(id) {
		return <FormattedMessageComponent id={id} />;
	}

	setFilterValuesFromState(values) {
		const filterValues = [];
		const { columnDefs } = this.state;
		if ((columnDefs && columnDefs.length) || (this.columnDefData && this.columnDefData.length)) {
			const colData = columnDefs && columnDefs.length ? columnDefs : this.columnDefData;
			values.forEach(value => {
				const isExists = colData.find(
					column => column[COLUMN_VALUE_ACCESSOR].trim() == value.accessor,
				);
				if (isExists) {
					filterValues.push(value);
				}
			});
			if (filterValues && filterValues.length) {
				this.props.onSetFilterProps(filterValues);
				this.props.setGlobalFilterProps(filterValues);
				return filterValues;
			}
		} else {
			this.props.onSetFilterProps(values);
			this.props.setGlobalFilterProps(values);
			return values;
		}
	}

	getApiObj(recordData, record, currentPage, pageProps) {
		let recordObj = false;
		if (record) {
			recordObj = record;
		}
		const apiObj = {
			recordData,
			pageProps,
			direction: pageProps.isForwardDirection,
			record: recordObj,
			currentPage,
			parentPage: MASSMAINTENANCEJOBS_LIST_PAGE,
		};
		return apiObj;
	}

	getApiFilterObj(filterProps, currentPage, pageProps) {

		let apiObj = {
			filterProps,
			pageProps: pageProps,
			direction: pageProps.isForwardDirection,
			currentPage: currentPage,
			parentPage: ORDER_LIST
		};
		return apiObj;
	}

	prepareHeaderDataJSON(obj) {
		const headerValues = HeaderAPIValuesJSON[0];
		const prefix = getListPredecessor(MASSMAINTENANCEJOBS_LIST_PAGE);

		let keyJOBN = `${prefix}JOBN`;
		let JOBN = obj[keyJOBN];
		headerValues["JBJOBN"] = JOBN ? JOBN.trim() : JOBN;

		let keyJDES = `${prefix}JDES`;
		let JDES = obj[keyJDES];
		headerValues["JBJDES"] = JDES ? JDES.trim() : JDES;

		const keyJTYP = `${prefix}JTYP`;
		const JTYP = obj[keyJTYP];
		headerValues["JBJTYP"] = JTYP ? JTYP.trim() : JTYP;

		const keyRUND = `${prefix}RUND`;
		const RUND = obj[keyRUND];
		headerValues["JBRUND"] = RUND ? RUND.trim() : RUND;


		const keyRUNT = `${prefix}RUNT`;
		const RUNT = obj[keyRUNT];
		headerValues["JBRUNT"] = RUNT ? RUNT.trim() : RUNT;

		const keyRSTS = `${prefix}RSTS`;
		const RSTS = obj[keyRSTS];
		headerValues["JBRSTS"] = RSTS ? RSTS.trim() : RSTS;

		const keyJSTS = `${prefix}JSTS`;
		const JSTS = obj[keyJSTS];
		headerValues["JBJSTS"] = JSTS ? JSTS.trim() : JSTS;

		// const keyJSTS = `${prefix}JSTS`;
		// const JSTS = obj[keyJSTS];   check projection here
		// headerValues["JBJSTS"] = JSTS ? JSTS.trim() : JSTS;
		const { currentRecordData } = this.props.massmaintenancejobPropertiesPage;
		headerValues["PJPROJ"] = currentRecordData ? currentRecordData["PJPROJ"] : ''

		return [headerValues];
	}


	forceUpdateHandler() {
		this.forceUpdate();
	}

	makePrevNextAPICall = flag => {
		const { filterProps, sortProps, currentRecordData } = this.props.massmaintenancejobPropertiesPage;
		const data = JSON.parse(JSON.stringify(INITIAL_PAGE_PROPS));
		data.isForwardDirection = flag;
		data.pageSize = 3;
		this.props.getPageUpDownFlagAPI(
			this.getApiObjForPageUpDownFlags(filterProps, currentRecordData, MASSMAINTENANCEJOBS_LIST_PAGE, data, sortProps, flag)
		);
	};

	prepareTooltipData = () => {
		const { detailCallData, massmaintenancejobColumnDefs } = this.props.massmaintenancejobPropertiesPage;
		let tooltipData = prepareTooltipValues('mmjobs', detailCallData, massmaintenancejobColumnDefs, MASSMAINTENANCEJOB_PROPERTIES_PAGE);
		this.props.setDataInTabs("toolTipData", JSON.parse(JSON.stringify(tooltipData)));
	}

	setHeaderAndSendAPI(jsonData, from) {
		let data = this.prepareHeaderDataJSON(jsonData);
		this.setState({ headerData: data });
		this.setState({ stateData: jsonData });
		let valueData = prepareValueDataForMassmaintenancejobs(DEFAULT_VALUE_URL_DATA, jsonData, from);
		this.sendAPICallForValues(valueData);
	}
	sendAPICallForValues(valueData) {

		this.props.getValueList({ KJOBN: valueData[1].fieldValue });
		this.props.loadMassmaintenancejobParseData({ KJOBN: valueData[1].fieldValue });
	}
	handleValueDataErrorMessages(content) {
		this.setState({ showValueConfirmationDialog: true });
		this.setState({ dialogTitle: TEXT_ALERT });
		this.setState({ dialogContent: content });
		this.setState({ hasWarning: content == 'E10184' ? true : false });
	}

	closeValueDialog = () => {
		this.setState({ showValueConfirmationDialog: false });
		if (this.state.valueDataFailureMessages && this.state.valueDataFailureMessages.length) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.shift();
			this.setState({ valueDataFailureMessages: values });
		}
	}

	setRecordDataValues() {
		let isRecordValuesExists = false, isLocalStorageValuesExists = false, isFilterValuesExists = false;
		const { history } = this.props;
		var paramsString = window.location.search;
		if (paramsString && paramsString.length) {
			let paramsArray = paramsString.split("?");
			if (paramsArray && paramsArray.length && paramsArray.length > 1) {
				let params = paramsArray[1].split("&");
				let tabId = params[0].split("=")[1];
				let breadCrumbId = params[1].split("=")[1];
				let localStorageValues = getFilterDataFromLocalStorage(tabId, breadCrumbId);
				if (localStorageValues && Object.keys(localStorageValues) && Object.keys(localStorageValues).length) {
					isLocalStorageValuesExists = true;
					let itemData = localStorageValues.item_data, dbSelectorValues = [];
					if (itemData && itemData.recordData && localStorageValues.childType) {
						this.columnDefData = JSON.parse(JSON.stringify(itemData.recordData.columnDefs))
						this.setState({ columnDefs: itemData.recordData.columnDefs });
						this.props.setCurrentRecord(itemData.recordData.data);
						this.setState({ totalCount: itemData.recordData.totalCount });
						this.setState({ fromPage: itemData.recordData.fromPage });
						this.setState({ fromListPage: itemData.recordData.fromPage });
						this.props.setRowIndex(itemData.recordData.rowIndex);
						this.setHeaderAndSendAPI(itemData.recordData.data, itemData.recordData.fromPage);
						isRecordValuesExists = true;
						this.props.setSelectedRecord(false, false);
						if (itemData) {
							if (itemData.dbSelector && itemData.dbSelector.length) {
								dbSelectorValues = JSON.parse(JSON.stringify(itemData.dbSelector));
							}
							if (itemData.filterProps && itemData.filterProps.length) {
								this.setState({ hasFiltersChanged: false });
								isFilterValuesExists = true;
								let values = getDBSelectorFilterValues(dbSelectorValues, itemData.filterProps);
								this.setFilterValuesFromState(values);
							} else if (dbSelectorValues && dbSelectorValues.length) {
								this.setState({ hasFiltersChanged: false });
								isFilterValuesExists = true;
								let dbValues = getDBSelectorFilterValues(dbSelectorValues, []);
								this.setFilterValuesFromState(dbValues);
							}
							if (itemData.sortProps && itemData.sortProps.length) {
								this.setState({ hasSortChanged: false });
								this.props.sendPageSortProps(itemData.sortProps);
								this.props.onSetSortProps(itemData.sortProps);
							} else {
								//do nothing
							}
							if (itemData.defaultFilterInfo && Object.keys(itemData.defaultFilterInfo) && Object.keys(itemData.defaultFilterInfo).length) {
								this.props.setDefaultFilterpropsForTabs(itemData.defaultFilterInfo);
							}
							if (itemData.defaultSortInfo && Object.keys(itemData.defaultSortInfo) && Object.keys(itemData.defaultSortInfo).length) {
								this.props.setDefaultSortpropsForTabs(itemData.defaultSortInfo);
							}
						}
					}

				}
				if (!isLocalStorageValuesExists && tabId && breadCrumbId) {
					history.push({ pathname: '/Dashboard' });
				}
			}
		}

		let filterOptions = GLOBAL_FILTER_OPTIONS;
		const { dbSelector } = this.props;
		if (!isFilterValuesExists) {
			let gbValues = getDBSelectorFilterValues(dbSelector, filterOptions);
			this.setFilterValuesFromState(gbValues);
		}
		return isRecordValuesExists;
	}

	resetValues = () => {
		this.props.setInitialState();
		this.props.setValueDataFlag(false);
		this.props.setCurrentRecord(null);
		this.props.getMassmaintenancejobsColumnDefs({ type: MASSMAINTENANCEJOBS_LIST_PAGE });
	};

	componentDidMount() {
		this.resetValues();
		let currentPage = MASSMAINTENANCEJOB_PROPERTIES_PAGE;
		this.props.onLoadCurrentPage(currentPage);
		const { detailCallData } = this.props.MassmaintenancejobPropertiesData;
		this.props.setIsShowContextMenu(true);
		let isFound = this.setRecordDataValues();
		if (!isFound) {
			if (this.props.location && this.props.location.state) {
				this.props.setCurrentRecord(this.props.location.state.data);
				this.setState({ columnDefs: this.props.location.state.columnDefs });
				this.setState({ fromPage: this.props.location.state.fromPage });
				this.props.setRowIndex(this.props.location.state.rowIndex);
				this.setHeaderAndSendAPI(this.props.location.state.data, MASSMAINTENANCEJOBS_LIST_PAGE);
			}
		}

		if (detailCallData && Object.keys(detailCallData) && Object.keys(detailCallData).length) {
			this.setState({ headerData: this.prepareHeaderDataJSON(detailCallData) });
			this.props.setSelectedRecord(detailCallData, MASSMAINTENANCEJOBS_LIST_PAGE);
			const { valueArray } = this.state;
			valueArray['rerun'] = detailCallData.JDTCAT
			this.setState({ valueArray })
		}

		this.setState({ isSaveDataDisabled: true });
	}

	componentDidUpdate(prevProps, prevState) {
		const { pageUpDownData,
			isSaveSuccess,
			filterProps,
			isValueDataAPICall,
			isValueDataAPIFailure,
			massmaintenancejobColumnDefs,
			sortProps,
			defaultSortProps,
			sortCriteriaDetails,
			filterCriteriaDetails,
			detailCallData,
			isApiForMassmaintenancejobParse,
			isApiForMassmaintenancejobColumnDefs,
			isApiForFilterableColumnDefs,
			isApiForPrevNextData,
			isApiPrevNextFlags,
			isApiForsendDataToServer,
			isApiFormassMaintenceRunNowData,
			isApiFormassMaintenceSubmitData,
			isApiFormassMaintenanceUpdateData,
		} = this.props.massmaintenancejobPropertiesPage

		if (this.state.valueDataFailureMessages && this.state.valueDataFailureMessages.length
			&& (JSON.stringify(this.state.valueDataFailureMessages) != JSON.stringify(prevState.valueDataFailureMessages))) {
			this.handleValueDataErrorMessages(this.state.valueDataFailureMessages[0]);
		}

		if (isApiForMassmaintenancejobParse && (isApiForMassmaintenancejobParse != prevProps.massmaintenancejobPropertiesPage.isApiForMassmaintenancejobParse)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to fetch Vendor Detail");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isApiForMassmaintenancejobParse', value: false });
		}
		if (isApiForMassmaintenancejobColumnDefs && (isApiForMassmaintenancejobColumnDefs != prevProps.massmaintenancejobPropertiesPage.isApiForMassmaintenancejobColumnDefs)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to fetch column Definations");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isApiForMassmaintenancejobColumnDefs', value: false });
		}
		if (isApiForFilterableColumnDefs && (isApiForFilterableColumnDefs != prevProps.massmaintenancejobPropertiesPage.isApiForFilterableColumnDefs)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to fetch filter Columns");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isApiForFilterableColumnDefs', value: false });
		}

		if (isApiForPrevNextData && (isApiForPrevNextData != prevProps.massmaintenancejobPropertiesPage.isApiForPrevNextData)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to fetch previous Next data");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isApiForPrevNextData', value: false });
		}
		if (isApiPrevNextFlags && (isApiPrevNextFlags != prevProps.massmaintenancejobPropertiesPage.isApiPrevNextFlags)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to fetch previous next Flags");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isApiPrevNextFlags', value: false });
		}

		if (isApiForsendDataToServer && (isApiForsendDataToServer != prevProps.massmaintenancejobPropertiesPage.isApiForsendDataToServer)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to fetch Save Job defination");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isApiForsendDataToServer', value: false });
		}

		if (isApiFormassMaintenceRunNowData && (isApiFormassMaintenceRunNowData != prevProps.massmaintenancejobPropertiesPage.isApiFormassMaintenceRunNowData)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to fetch run the Job");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isApiFormassMaintenceRunNowData', value: false });
		}
		if (isApiFormassMaintenceSubmitData && (isApiFormassMaintenceSubmitData != prevProps.massmaintenancejobPropertiesPage.isApiFormassMaintenceSubmitData)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to fetch Submit the job");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isApiFormassMaintenceSubmitData', value: false });

		} if (isApiFormassMaintenanceUpdateData && (isApiFormassMaintenanceUpdateData != prevProps.massmaintenancejobPropertiesPage.isApiFormassMaintenanceUpdateData)) {
			let values = JSON.parse(JSON.stringify(this.state.valueDataFailureMessages));
			values.push("Failed to fetch Update the job");
			this.setState({ valueDataFailureMessages: JSON.parse(JSON.stringify(values)) });
			this.props.setLabelDataFlags({ key: 'isApiFormassMaintenanceUpdateData', value: false });
		}

		if (sortProps && sortProps.length && !isEqual(sortProps, prevProps.massmaintenancejobPropertiesPage.sortProps)) {
			this.props.setDataInTabs("sortProps", JSON.parse(JSON.stringify(sortProps)));
			if (!this.state.isInitialAPICall) {
				if (this.state.fromPage != MASSMAINTENANCEJOBS_LIST_PAGE) {
					this.setHeaderAndSendAPI(this.state.stateData, this.state.fromPage)
				} else {
					this.makeAPICallForPageUpDown('down', {});
				}
			}
		}

		if ((JSON.stringify(filterProps) != JSON.stringify(prevProps.massmaintenancejobPropertiesPage.filterProps)) && filterProps && filterProps.length) {
			this.setState({ isFiltersChanged: true });
			this.props.setChildTabFilterProps(filterProps);
			if (!this.state.isInitialAPICall) {
				if (this.state.fromPage != MASSMAINTENANCEJOBS_LIST_PAGE && !this.state.hasFiltersChanged) {
					this.setHeaderAndSendAPI(this.state.stateData, this.state.fromPage)
				} else {
					this.makeAPICallForPageUpDown('down', {});
				}
			}
		}
		if ((defaultSortProps != prevProps.massmaintenancejobPropertiesPage.defaultSortProps) && (prevProps.massmaintenancejobPropertiesPage.defaultSortProps === null) && (sortProps == null || !sortProps || !(sortProps && sortProps.length))) {
			let list = setSortDataFromSortCriteria(defaultSortProps, massmaintenancejobColumnDefs, MASSMAINTENANCEJOBS_LIST_PAGE);
			this.props.setDataInTabs("defaultSortInfo", JSON.parse(JSON.stringify(defaultSortProps)));
			if (list && list.length) {
				this.props.sendPageSortProps(list);
				this.props.onSetSortProps(list);
			} else {
				this.props.sendPageSortProps([]);
				this.props.onSetSortProps([]);
			}
		}

		if (JSON.stringify(sortCriteriaDetails) != JSON.stringify(prevProps.massmaintenancejobPropertiesPage.sortCriteriaDetails)) {
			this.props.setDataInTabs("defaultSortInfo", JSON.parse(JSON.stringify(sortCriteriaDetails)));
			let list = setSortDataFromSortCriteria(sortCriteriaDetails, massmaintenancejobColumnDefs, MASSMAINTENANCEJOBS_LIST_PAGE);
			if (list && list.length) {
				this.props.sendPageSortProps(list);
				this.props.onSetSortProps(list);
			}
		}

		if ((filterCriteriaDetails != prevProps.massmaintenancejobPropertiesPage.filterCriteriaDetails)) {
			this.props.setDataInTabs("defaultFilterInfo", JSON.parse(JSON.stringify(filterCriteriaDetails)));
			if (filterCriteriaDetails && Object.keys(filterCriteriaDetails) && Object.keys(filterCriteriaDetails).length && massmaintenancejobColumnDefs && massmaintenancejobColumnDefs.length) {
				let list = getFilterDataFromCriteriaDetails(filterCriteriaDetails, massmaintenancejobColumnDefs, MASSMAINTENANCEJOBS_LIST_PAGE);
				if (list && list.length) {
					this.props.setGlobalFilterProps(list);
					this.props.onSetFilterProps(list);
				}
			}
		}

		if (detailCallData && !isEqual(detailCallData, prevProps.massmaintenancejobPropertiesPage.detailCallData)) {
			if (Object.keys(detailCallData) && Object.keys(detailCallData).length) {
				if (massmaintenancejobColumnDefs && massmaintenancejobColumnDefs.length) {
					this.prepareTooltipData();
				}
				this.props.setSelectedRecord(detailCallData, MASSMAINTENANCEJOBS_LIST_PAGE);
				this.setState({ headerData: this.prepareHeaderDataJSON(detailCallData) });
				const { valueArray } = this.state;
				valueArray['rerun'] = detailCallData.JDTCAT
				this.setState({ valueArray })
			}
		}

		if (massmaintenancejobColumnDefs && massmaintenancejobColumnDefs.length && !isEqual(massmaintenancejobColumnDefs, prevProps.massmaintenancejobPropertiesPage.massmaintenancejobColumnDefs) &&
			(detailCallData && Object.keys(detailCallData) && Object.keys(detailCallData).length)) {
			if (!this.state.changeDataAPI) {
				this.prepareTooltipData();
			}
		}
		if (isValueDataAPICall != prevProps.massmaintenancejobPropertiesPage.isValueDataAPICall && isValueDataAPICall) {
			this.setState({ previousFilterValues: prevProps.massmaintenancejobPropertiesPage.filterProps })
			this.setState({ isInitialAPICall: false });
			this.makePrevNextAPICall(true);
			this.props.setValueDataFlag(false);
			if (this.state.isFiltersChanged) {
				this.setState({ openFilterPopup: false });
				this.setState({ isFiltersChanged: false });
			}
			const { detailCallData } = this.props.massmaintenancejobPropertiesPage
			if (detailCallData && detailCallData.JDDEFN) {
				const data = detailCallData.JDDEFN.substring(12, 18);
				switch (data) {
					case '007001':
					case '007005':
					case '007002':
						this.setState({ predecessor: 'vendors' })
						this.props.getFilterableColumnsList("vendorfiltercolumns");
						break;
					case '006301':
					case '008812':
						this.setState({ predecessor: 'items' })
						this.props.getFilterableColumnsList("itemfiltercolumns");
						break;
					case '010104':
						this.setState({ predecessor: 'itemondeal' })
						this.props.getFilterableColumnsList("dealheaderfiltercolumns");
						break;
					case '010103':
						this.setState({ predecessor: 'deals' })
						this.props.getFilterableColumnsList("dealitemsfiltercolumns");
						break;
					case '014901':
						this.setState({ predecessor: 'openpos' })
						this.props.getFilterableColumnsList("openpofiltercolumns");
						break;
					case '014905':
						this.setState({ predecessor: 'polines' })
						this.props.getFilterableColumnsList("openpolinesfiltercolumns");
						break;
					default:
						break;
				}

			}
		}
		if (isValueDataAPIFailure != prevProps.massmaintenancejobPropertiesPage.isValueDataAPIFailure && isValueDataAPIFailure) {
			this.setState({ isInitialAPICall: false });
			if (this.state.isFiltersChanged) {
				this.setState({ showConfirmationDialog: true });
				this.setState({ hasWarning: true });
				this.setState({ dialogTitle: TEXT_ALERT });
				this.setState({ fromHeaderENG: true });
			} else {
				this.setState({ showConfirmationDialog: true });
				this.setState({ hasWarning: true });
				this.setState({ dialogTitle: TEXT_ALERT });
				this.setState({ fromHeaderENG: true });
			}
		}

		if (this.props.location.search != prevProps.location.search) {
			this.resetValues();
			this.forceUpdateHandler();
			this.setRecordDataValues();
			this.setState({ state: this.state });
		}
		if (pageUpDownData && JSON.stringify(pageUpDownData) != JSON.stringify(prevProps.massmaintenancejobPropertiesPage.pageUpDownData) && Object.keys(pageUpDownData).length) {
			this.props.setSelectedRecord(pageUpDownData, MASSMAINTENANCEJOBS_LIST_PAGE);
			this.setState({ fromPage: MASSMAINTENANCEJOBS_LIST_PAGE });
			this.setHeaderAndSendAPI(pageUpDownData, MASSMAINTENANCEJOBS_LIST_PAGE);
			let modifiedData = {
				data: JSON.parse(JSON.stringify(pageUpDownData)),
				fromPage: MASSMAINTENANCEJOBS_LIST_PAGE,
				rowIndex: this.props.massmaintenancejobPropertiesPage.rowIndex,
				totalCount: this.state.totalCount,
				fromParent: false,
				columnDefs: this.state.columnDefs,
			};
			this.props.setDataInTabs('recordData', modifiedData);
		}
		if (isSaveSuccess && isSaveSuccess !== prevProps.massmaintenancejobPropertiesPage.isSaveSuccess) {
			this.setState({ isSaveDataDisabled: true });
		}
	}

	onSaveData = () => {
		const { detailCallData, currentRecordData } = this.props.massmaintenancejobPropertiesPage;
		const { valueArray } = this.state

		let job = { ...detailCallData }
		job.JDTCAT = valueArray["rerun"].toString()
		job.JDSTAT = "C"
		this.props.massMaintenceUpdate(job);

		job = { ...currentRecordData }
		job.JBK4RR = valueArray["rerun"].toString()
		this.props.massMaintenceJobUpdate(job)
	}

	getApiObjForPageUpDown(filterData, record, currentPage, pageProps, sortData, pageType) {
		let recordObj = false
		if (record) {
			recordObj = record;
		}
		let apiObj = {
			sortProps: sortData,
			filterProps: filterData,
			pageProps: pageProps,
			direction: pageProps.isForwardDirection,
			record: recordObj,
			currentPage: currentPage,
			parentPage: MASSMAINTENANCEJOBS_LIST_PAGE,
			pageType: pageType
		};
		return apiObj;
	}

	getApiObjForPageUpDownFlags = (filterData, record, currentPage, pageProps, sortData, pageType) => {
		let recordObj = false
		if (record) {
			recordObj = {
				"record": record,
				"flagsOnly": true
			};
		}
		let apiObj = {
			sortProps: sortData,
			filterProps: filterData,
			pageProps: pageProps,
			direction: pageProps.isForwardDirection,
			record: recordObj,
			currentPage: currentPage,
			parentPage: MASSMAINTENANCEJOBS_LIST_PAGE,
			pageType: pageType
		};
		return apiObj;
	}

	makeAPICallForPageUpDown(type, currentRecordData) {
		const { filterProps, sortProps } = this.props.massmaintenancejobPropertiesPage;
		let data = JSON.parse(JSON.stringify(INITIAL_PAGE_PROPS));
		if (type == 'up') {
			data.isForwardDirection = false;
		} else {
			data.isForwardDirection = true;
		}
		let filterData = JSON.parse(JSON.stringify(filterProps));
		this.props.pageUpDownAPI(this.getApiObjForPageUpDown(filterData, currentRecordData, MASSMAINTENANCEJOBS_LIST_PAGE, data, sortProps))
	}

	handleMassmaintenancejobHeaderLeftArrowClick() {
		const { currentRecordData } = this.props.massmaintenancejobPropertiesPage;
		this.props.setCurrentType('down');
		this.makeAPICallForPageUpDown('down', currentRecordData);
		this.setState({ isSaveDataDisabled: true });
	}

	handleMassmaintenancejobHeaderRightArrowClick() {
		const { currentRecordData } = this.props.massmaintenancejobPropertiesPage;
		this.props.setCurrentType('up');
		this.makeAPICallForPageUpDown('up', currentRecordData);
		this.setState({ isSaveDataDisabled: true });
	}

	sethaserror = val => {
		this.setState({ hasError: val });
	};

	onContextMenuChange = (e, value, check = false, filters = false, title = false) => {
		let defaultFilters = filters;
		let toPage = value;
		let displayName = title;
		onChangeContextMenu(this.props, e, toPage, defaultFilters, displayName);
		this.props.setSelectedValueForTabs('Show Me');
	}

	handleClose = bodyId => {
		this.setState({ showConfirmationDialog: false });
		switch (bodyId) {
			case 'E14029':
				//need to close the current Tab
				this.closeCurrentTab();
				break;
		}
	}

	closeCurrentTab = () => {
		this.props.setNoDataCallBackValue(true);
		var paramsString = window.location.search;
		if (paramsString && paramsString.length) {
			let paramsArray = paramsString.split("?");
			if (paramsArray && paramsArray.length && paramsArray.length > 1) {
				let params = paramsArray[1].split("&");
				let tabId = params[0].split("=")[1];
				let breadCrumbId = params[1].split("=")[1];
				this.props.removeCurrentRecordObj(tabId, breadCrumbId);
			}
		}
	}

	handleChangeValue = (key, val) => {
		const valueArray = { ...this.state.valueArray };
		valueArray[key] = val;
		this.setState({ valueArray });
		this.setState({ isSaveDataDisabled: false })
	}

	handleOperator = (opr) => {
		switch (opr) {
			case '=': return EQUALS_TO;

			case '>': return GREATER_THAN;

			case '>=': return GREATER_THAN_OR_EQUALS_TO;

			case '<': return LESS_THAN;

			case '<=': return LESS_THAN_OR_EQUALS_TO;

			case '!=': return NOT_EQUALS_TO;

			default:
				return ' '
		}
	}
	handleFieldName = (key) => {
		const { filterableColumns } = this.props.massmaintenancejobPropertiesPage;
		const { predecessor } = this.state
		let pre = predecessor ? getListPredecessor(predecessor).trim() : false;
		let field
		if (filterableColumns && filterableColumns.length && predecessor) {
			if(isNaN(parseInt(key))){
			field = filterableColumns.find(field => Number(field.FDPRFX) ? field.FDFNAM.trim() == key.trim() : pre + field.FDFNAM.trim() == key)
			return field && field.TLLAB ? field.TLLAB : ' '
			}
			else{
				field = filterableColumns.find(field => Number(field.FDFILD) ? field.FDFILD.trim() == key.trim() : false)
				return field && field.TLLAB ? field.TLLAB : ' '
			}
		} else {
			return ' ';
		}
	}

	handleFieldval = (dataField) => {
		const { filterableColumns } = this.props.massmaintenancejobPropertiesPage;
		const { predecessor } = this.state
		let pre = predecessor ? getListPredecessor(predecessor).trim() : false;
		let field
		if (filterableColumns && filterableColumns.length && predecessor) {
			field = filterableColumns.find(field => Number(field.FDPRFX) ? field.FDFNAM.trim() == dataField.key.trim() : pre + field.FDFNAM.trim() == dataField.key)
			return field && field.FDFTYP == "D" ? getDateFormatValue(dataField.val) : getFieldNameFromRegex(dataField.val,filterableColumns)
		} else {
			return dataField.val;
		}
	}

	render() {

		const {
			classes, globalDateFormat, filterCriteriaDetails, pageFilterOptions, globalFilterOptions,
			isShowContextMenu } = this.props;
		const {
			loading, valueData, rowIndex, currentRecordData, hasNext, hasPrevious, vendorData, massmaintenancejobColumnDefs, filterableColumns, massmaintenancejob } = this.props.massmaintenancejobPropertiesPage;
		const { isSaveDataDisabled, headerData, valueArray, predecessor } = this.state;
		let contextMenu = updateBreadCrumbContextMenu(this.props) || [];
		return (
			<React.Fragment>
				<Header
					filters={this.props.filters}
					parentSubPage={MASSMAINTENANCEJOB_PROPERTIES_PAGE}
					contextMenu={contextMenu}
					fromListPage={this.state.fromListPage}
					onContextMenuChange={this.onContextMenuChange}
					rowIndex={rowIndex}
					massmaintenancejobPropertiesPage={this.props.massmaintenancejobPropertiesPage}
					handleMassmaintenancejobHeaderFilterClick={this.handleMassmaintenancejobHeaderFilterClick}
					hasNext={hasNext}
					hasPrevious={hasPrevious}
					massmaintenancejobData={headerData}
					vendorData={vendorData}
					currentRecordData={currentRecordData}
					handleMassmaintenancejobHeaderSaveClick={() => this.onSaveData()}
					handleMassmaintenancejobHeaderLeftArrowClick={this.handleMassmaintenancejobHeaderLeftArrowClick}
					handleMassmaintenancejobHeaderRightArrowClick={this.handleMassmaintenancejobHeaderRightArrowClick}
					saveDisabled={isSaveDataDisabled}
					setSaveData={val => { this.setState({ isSaveDataDisabled: !val }); }}
					globalDateFormat={globalDateFormat}
					filterCriteriaDetails={filterCriteriaDetails}
					pageFilterOptions={pageFilterOptions}
					globalFilterOptions={globalFilterOptions}
					columnDefs={this.state.columnDefs}
					currentPage={MASSMAINTENANCEJOBS_LIST_PAGE}
					parentPage={MASSMAINTENANCEJOBS_LIST_PAGE}
					canUpdateComponent={this.state.canUpdateComponent}
					isShowContextMenu={isShowContextMenu}
					massMaintenceRunNow={this.props.massMaintenceRunNow}
					massMaintenceSubmit={this.props.massMaintenceSubmit}
					massmaintenancejobColumnDefs={massmaintenancejobColumnDefs}
					valueArray={valueArray}
				/>
				<div className={classes.propertiesContentWrapper}>
					<TabContainer>
						<div className={classes.pageContainer}>
							<div className={classes.pageContainerFifty + ' ' + classes.marginRightZero}>
								<div className={classes.simpleCardGroup + ' ' + classes.card}>
									{filterableColumns && filterableColumns.length && valueData && massmaintenancejob &&
										<TableContainer component={Paper} className={classes.table1} >
											<Table className={classes.table} aria-label="simple table">
												<TableHead className={classes.table} >
													<TableRow>
														<TableCell className={classes.border1} size='small' >{this.getLabelValue('25727')}</TableCell>
													</TableRow>
												</TableHead>
												<TableBody>
													{massmaintenancejob["JDDEFN"] && massmaintenancejob.JDDEFN.map((data,index) => {
														if (data.jOpr) {
															return <TableRow key={data.key} >
																<TableCell className={classes.border + ' ' + classes.inlineDisplay} size='small'>{this.handleFieldName(data.key)} {this.getLabelValue(this.handleOperator(data.opr))} {data.val} {massmaintenancejob["JDDEFN"][index + 1].jOpr ? data.jOpr :" " }</TableCell>
															</TableRow>
														}
													})
													}
												</TableBody>
											</Table>
										</TableContainer>
									}</div>
							</div>
							<div className={classes.pageContainerFifty + ' ' + classes.marginLeftZero}>
								<div className={classes.pageContainerMax}>
									<div className={classes.card}>
										<Box className={classes.adjustShowDetail}>
											<FieldInput field={{ type: 'checkbox', key: 'rerun' }} value={(valueArray['rerun'] && Number(valueArray['rerun'])) || 0}
												onChange={(key, val) => this.handleChangeValue(key, val)} />
											<div className={classes.showDetail}>{this.getLabelValue("2350")}</div>
										</Box>
									</div>
								</div>
								<div className={classes.simpleCardGroup + ' ' + classes.card}>
									{filterableColumns && filterableColumns.length && valueData && massmaintenancejob &&
										<TableContainer component={Paper} className={classes.table1} >
											<Table className={classes.table} aria-label="simple table">
												<TableHead className={classes.table} >
													<TableRow>
														<TableCell className={classes.border1} size='small' >{this.getLabelValue('2837')}</TableCell>
														<TableCell className={classes.border1} size='small' >{this.getLabelValue('2900')}</TableCell>
													</TableRow>
												</TableHead>
												<TableBody>
												{predecessor&&massmaintenancejob["JDDEFN"] && massmaintenancejob.JDDEFN.map(field => {
														if (!field.jOpr) {
															return <TableRow key={field.key} >
																<TableCell className={classes.border} size='small'>{this.handleFieldName(field.key)}</TableCell>
																<TableCell className={classes.border} size='small'>{this.handleFieldval(field)}</TableCell>
															</TableRow>
														}
													})}
												</TableBody>
											</Table>
										</TableContainer>
									}</div>
							</div>
						</div>
					</TabContainer>
					{(loading || !filterableColumns) && <Spinner loading type="list" />}
				</div>

				{this.state.openFilterPopup && (
					<Filter
						filterCriteriaDetails={this.props.filterCriteriaDetails}
						pageFilterOptions={this.props.pageFilterOptions}
						globalFilterOptions={this.props.globalFilterOptions}
						globalSecurityFilterList={this.props.globalSecurityFilterList}
						currentPage={MASSMAINTENANCEJOB_PROPERTIES_PAGE}
						isOpen={Boolean(this.state.openFilterPopup)}
						ownerName={this.props.currentOwnerName}
						columnDefs={massmaintenancejobColumnDefs}
						clearPopupComponent={this.handleMassmaintenancejobHeaderFilterClick}
						disableRows = {MASSMAINTENANCEJOBS_FILTER_OPTIONS.map(row => row.accessor)}
					/>
				)}
				{this.state.showConfirmationDialog && <ConfirmationDialog
					hasError={this.state.hasWarning}
					isOpen={this.state.showConfirmationDialog}
					dialogTitle={this.state.dialogTitle}
					submitText={TEXT_OK}
					handleClose={() => this.handleClose(this.state.dialogBody)}
					handleCancel={() => this.handleClose(this.state.dialogBody)}
					handleSubmit={() => this.handleClose(this.state.dialogBody)}>
					<div>
						{this.state.fromHeaderENG && this.getLabelValue("28648")}
						{!this.state.fromHeaderENG && (this.props.errorMessageLabels && this.props.errorMessageLabels[this.state.dialogBody] &&
							this.props.errorMessageLabels[this.state.dialogBody].MTEXT || 'Warning')}
					</div>
				</ConfirmationDialog>
				}
				{this.state.showValueConfirmationDialog && <ConfirmationDialog
					hasError={!this.state.hasWarning}
					hasWarning={this.state.hasWarning}
					isOpen={this.state.showValueConfirmationDialog}
					dialogTitle={this.state.dialogTitle}
					submitText={TEXT_OK}
					handleClose={() => this.closeValueDialog(false)}
					handleCancel={() => this.closeValueDialog(false)}
					handleSubmit={() => this.closeValueDialog(this.state.dialogBody)}>
					<div>
						{(this.props.errorMessageLabels[this.state.dialogContent] && this.props.errorMessageLabels[this.state.dialogContent].MTEXT)
							|| this.state.dialogContent}
					</div>
				</ConfirmationDialog>
				}
			</React.Fragment>
		);
	}
}

export default withStyles(style)(MassmaintenancejobProperties);

import React, { Component } from 'react';
import ManageItemsContainer from 'containers/DealsEmbeddedListPage/ManageItems/ManageItemsContainer';
class ManageItems extends Component {
	constructor(props) {
		super(props);
		this.state = {

		}
	}

	render() {
		return (
			<div>
				<ManageItemsContainer
					{...this.props} />
			</div>)
	}
}
export default ManageItems;
import React from 'react';
import { withStyles, Button, Box } from '@material-ui/core';
import { injectIntl } from 'react-intl';
import KeyboardArrowUpIcon from '@material-ui/icons/KeyboardArrowUp';
import KeyboardArrowDownIcon from '@material-ui/icons/KeyboardArrowDown';
import SaveIcon from '@material-ui/icons/Save';
import withFixedPosition from 'containers/common/withFixedPosition';
import { getDateFormatted } from 'components/common/Form/dateTimeUtils';//E3C-31950:Ajit added to format in globaldateformat
import {
	LABEL_JOB_RERUN_STATUS,
	LABEL_JOB_NUMBER,
	LABEL_JOB_DESCRIPTION,
	LABEL_JOB_TYPE,
	LABEL_JOB_RUNDATE,
	LABEL_JOB_RUNTIME,
	LABEL_ACTIONS,
	CONTEXT_MENU_HEADER_MASSMAINTENANCEJOB_ACTIONS

} from './constants';
import FormattedMessageComponent from '../common/FormattedMessageComponent';
import FilterIcon from "../../images/icon_filter.png";
import { getDateFormatValue, formatStringToTime, getListPredecessor, getDateFromJulian } from 'utils/util';
import ContextMenu from '../common/ContextMenu';
import BreadcrumbContextMenu from 'components/common/BreadcrumbContextMenu';
import { MASSMAINTENANCEJOBS_LIST_PAGE, TEXT_OK, TEXT_CANCEL } from 'components/common/constants';
import ConfirmationDialog from 'components/common/ConfirmationDialog';
import MoreVertIcon from '@material-ui/icons/MoreVert';
import ContextMenuCreateNew from '../common/ContextMenuCreateNew';

const style = theme => ({
	propertiesContentWrapper: {
		margin: '10px auto',
		borderRadius: '4px',
		overflow: 'hidden',
		boxShadow: '0 2px 4px var(--secondary-s10)',
		overflowX: 'auto'
	},
	propertiesHeaderContainer: {
		width: '100%',
		marginBottom: '1.5rem',
		backgroundColor: 'var(--background-app)',
		borderRadius: '4px',
		borderTopLeftRadius: '0px',
		borderTopRightRadius: '0px',
		overflow: 'hidden',
		boxShadow: '0 4px 4px var(--secondary-s10)',
		overflowX: 'auto'
	},
	boookingDetailContainer: {
		display: 'flex',
		width: '100%',
		backgroundColor: 'var(--background-content)',
		fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
		alignItems: 'center',
		padding: '0 0 0 24px',
		position: 'relative',
		minWidth: '630px'
	},
	boookingDetailDetailsWrapper: {
		width: '100%',
		display: 'flex',
	},
	pageContainer: {
		display: 'flex',
		backgroundColor: 'var(--background-app)',
		borderTop: 'none',
		padding: '10px 10px',
	},
	card: {
		padding: '0px',
		backgroundColor: 'var(--background-content)',
		borderRadius: '4px',
		width: '100%',
		margin: '10px',
		'& .MuiCardHeader-root': {
			padding: '22px 20px 0 20px'
		},
		'& .MuiCardContent-root': {
			padding: '16px 15px 10px 15px'
		}
	},
	marginLeftZero: {
		marginLeft: '0',
	},
	boookingArrow: {
		padding: '0 !important',
		margin: '0',
		minWidth: '16px',
		background: 'none',
		height: '16px',
		width: '16px',
	},
	bookingArrowWrapper: {
		display: 'flex',
		flexDirection: 'column',
		border: '1px solid var(--primary-default)',
		borderRadius: '4px',
		justifyContent: 'center',
		alignItems: 'baseline',
		height: '38px',
		marginTop: '24px',
		padding: '2px',
	},
	vendorDetailRow: {
		width: '75%',
		display: 'flex',
		flexWrap: 'wrap',
		padding: '0px 0 24px 0',
		paddingLeft: '15px'
	},
	vendorDetail: {
		padding: '0px 0px 0 0px',
		lineHeight: '1.1',
	},
	vendorIDBlock: {
		display: 'flex',
	},
	vendorIdDetails: {
		width: '15ch',
		padding: '0 30px 0 0px',
		lineHeight: '1.1'
	},
	vendorLabel: {
		color: 'var(--header-label-color)',
		paddingBottom: '6px',
		width: '15ch',
	},
	vendorSubVendorDetails: {
		display: 'flex',
		flexDirection: 'column',
		width: '16ch',
		padding: '0 30px 0 0px',
		lineHeight: '1.1'
	},
	nameField: {
		paddingTop: '32px'
	},
	vendorValue: {
		color: 'var(--value)',
	},
	vendorIDSubID: {
		paddingRight: '40px',
		paddingTop: '24px'
	},
	IdNameBlock: {
		paddingTop: '24px',
		paddingRight: '24px',
	},
	bookingActions: {
		top: '24px',
		padding: '0px 20px 20px 20px',
		right: '20px',
		display: 'flex',
		position: 'absolute',
		alignItems: 'center',
		justifyContent: 'space-between',
		'@media (max-width: 1220px)': {
			flexWrap: 'wrap',
			width: '250px'
		}
	},
	buttonActions: {
		display: 'flex',
		alignItems: 'center',
		'@media (max-width: 1220px)': {
			marginBottom: '20px'
		},
		'& .MuiButton-root': {
			borderRadius: '4px',
			fontSize: '14px',
			width: '120px',
			lineHeight: '14px',
		},
		'& .MuiButton-sizeLarge': {
			fontSize: '18px',
		},
		'& .MuiButton-sizeSmall': {
			fontSize: '12px',
			padding: '8px 16px',
		},
		'& .MuiButton-containedPrimary': {
			backgroundColor: theme.palette.primary.default,
			border: '1px solid rgba(0, 0, 0, 0)',
			boxShadow: 'none',
			color: 'var(--background-content)',
			'&:hover': {
				backgroundColor: theme.palette.primary.hover,
				color: 'var(--background-content)',
				border: '1px solid rgba(0, 0, 0, 0)',
			},
			'&:focus': {
				backgroundColor: theme.palette.primary.focus,
				color: 'var(--background-content)',
				border: '1px solid rgba(0, 0, 0, 0)',
			},
			'&:active': {
				backgroundColor: theme.palette.primary.active,
				color: 'var(--background-content)',
				border: '1px solid rgba(0, 0, 0, 0)',
			}
		},
		'& .MuiButton-containedSecondary': {
			backgroundColor: 'var(--background-content)',
			border: '1px solid var(--button-tertiary-color)',
			color: 'var(--button-tertiary-color)',
			boxShadow: '0px 4px 14px rgba(0, 0, 0, 0.05)',
			'&:hover': {
				backgroundColor: 'var(--background-content)',
				color: 'var(--button-tertiary-hover-color)',
				border: '1px solid var(--button-tertiary-hover-color)',
			},
			'&:focus': {
				backgroundColor: 'var(--background-content)',
				color: 'var(--button-tertiary-focused)',
				border: '1px solid var(--button-tertiary-focused)',
			},
			'&:active': {
				backgroundColor: 'var(--background-content)',
				color: 'var(--button-tertiary-hover-color)',
				border: '1px solid var(--button-tertiary-hover-color)',
			},
			'&.Mui-disabled': {
				color: theme.palette.primary.disabled,
				textDecoration: 'unset',
				backgroundColor: 'unset',
				textShadow: 'unset'
			}
		},
		'& .MuiButton-outlinedPrimary': {
			border: `${'1px solid '}${theme.palette.primary.default}`,
			boxShadow: '0px 4px 14px rgba(0, 0, 0, 0.05)',
			backgroundColor: 'var(--background-content)',
			color: theme.palette.primary.default,
			'&:hover': {
				backgroundColor: 'var(--background-content)',
				border: '1px solid var(--button-secondary-hover-border)',
				color: 'var(--button-secondary-hover-border)',
			},
			'&:focus': {
				backgroundColor: 'var(--background-content)',
				border: `${'1px solid '}${theme.palette.primary.default}`,
				color: theme.palette.primary.default
			},
			'&:active': {
				backgroundColor: 'var(--background-content)',
				border: '1px solid var(--primary-button-pressed)',
				color: 'var(--primary-button-pressed)'
			},
			'&.Mui-disabled': {
				color: theme.palette.primary.disabled,
				textDecoration: 'unset',
				backgroundColor: 'unset',
				textShadow: 'unset'
			}
		},
		'& .MuiButton-outlinedSecondary': {
			backgroundColor: 'var(--background-content)',
			border: '1px solid var(--button-tertiary-color)',
			color: 'var(--button-tertiary-color)',
			boxShadow: '0px 4px 14px rgba(0, 0, 0, 0.05)',
			'&:hover': {
				backgroundColor: 'var(--background-content)',
				color: 'var(--button-tertiary-hover-color)',
				border: '1px solid var(--button-tertiary-hover-color)',
			},
			'&:focus': {
				backgroundColor: 'var(--background-content)',
				color: 'var(--button-tertiary-focused)',
				border: '1px solid var(--button-tertiary-focused)',
			},
			'&:active': {
				backgroundColor: 'var(--background-content)',
				color: 'var(--button-tertiary-hover-color)',
				border: '1px solid var(--button-tertiary-hover-color)',
			},
			'&.Mui-disabled': {
				color: theme.palette.primary.disabled,
				textDecoration: 'unset',
				backgroundColor: 'unset',
				textShadow: 'unset'
			}
		},
	},
	bookingActionsFilter: {
		minWidth: '37px',
		border: '1px solid var(--primary-default)',
		height: '32px',
		marginLeft: '15px',
		// marginRight: '15px',
		'@media (max-width: 1220px)': {
			marginLeft: '0px'
		},
		'& img': {
			width: '14px',
			height: '14px'
		},
		'& svg': {
			width: '18px',
			height: '18px'
		}
	},
	menuButton: {
		minWidth: '37px',
		border: '1px solid var(--primary-default)',
		height: '32px',
		marginLeft: '15px',
		borderRadius: '4px',
		display: 'flex',
		alignItems: 'center',
		justifyContent: 'center',
		'@media (max-width: 1220px)': {
			marginLeft: '0px'
		},
	},
	adjustCardFieldsInline: {
		display: 'grid !important',
		width: '100%',

		gridTemplateColumns: 'auto auto',
		paddingRight: '22px'
	},
	buttonActionsSecondChild: {
		marginRight: '15px',
		'& .MuiButton-outlinedPrimary': {
			width: '100%',
			height: '28px'
		}
	},
	poAlign: {
		alignSelf: 'flex-end',
		// paddingBottom: '13px'
	},
	descField: {
		paddingTop : '19px'
	}
});

class Header extends React.Component {
	constructor() {
		super();
		this.state = {
			massmaintenancejobName: false,
			tabValue: 1,
			massmaintenancejobDetailsArray: false,
			isOpenActionsContextMenu: false,
			isOpenActions: false,
			showConfirmationDialog: false,
			dialogContent: false,
			submitValue: false
		}
		this.setIsOpenActionsContextMenu = this.setIsOpenActionsContextMenu.bind(this);
		this.setIsOpenActionsButtonContextMenu = this.setIsOpenActionsButtonContextMenu.bind(this);
		this.onClickDownArrow = this.onClickDownArrow.bind(this);
		this.onClickUpArrow = this.onClickUpArrow.bind(this);
		this.getLabelValue = this.getLabelValue.bind(this);
	}

	getLabelValue(id) {
		return <FormattedMessageComponent id={id}></FormattedMessageComponent>;
	}

	handleDisableUpArrow = () => {
		const { hasPrevious, fromListPage } = this.props;
		return !hasPrevious || fromListPage != MASSMAINTENANCEJOBS_LIST_PAGE;
	};

	handleDisableDownArrow = () => {
		const { hasNext, fromListPage } = this.props;
		return !hasNext || fromListPage != MASSMAINTENANCEJOBS_LIST_PAGE;
	};

	setIsOpenActionsContextMenu = event => {
		this.setState({ isOpenActionsContextMenu: Boolean(event) });
		this.setState({ menuRef: event.currentTarget ? event.currentTarget : event });
	}

	setIsOpenActionsButtonContextMenu = event => {
		this.setState({ isOpenActions: Boolean(event) });
		this.setState({ actionMenuRef: event.currentTarget ? event.currentTarget : event });
	}

	onClickDownArrow() {
		const { rowIndex, totalCount } = this.props;
		this.props.handleMassmaintenancejobHeaderLeftArrowClick(rowIndex, totalCount);
	}

	onClickUpArrow() {
		const { rowIndex, totalCount } = this.props;
		this.props.handleMassmaintenancejobHeaderRightArrowClick(rowIndex, totalCount);
	}

	handleActionSelection = action => {
		this.setState({ showConfirmationDialog: true })
		const { currentRecordData } = this.props
		this.setState({ submitValue: action })
		switch (action) {
			case "runnow":
				this.setState({ dialogContent: 'Are you sure you want to run job ' + currentRecordData.JBJOBN + '?'})
				break;
			case "submit":
				this.setState({ dialogContent: 'Are you sure you want to submit job ' + currentRecordData.JBJOBN + '?' })
				break;

		}
	};
	handleActionSubmit = action => {
		const { currentRecordData } = this.props
		this.setState({ showConfirmationDialog: false })
		this.setState({ submitValue: false })
		switch (action) {
			case "runnow":
				this.props.massMaintenceRunNow({ KJOBN: currentRecordData.JBJOBN })
				break;
			case "submit":
				let record ={
					"KJOBN":currentRecordData.JBJOBN,
					"KTYPE" :"B"
				}
				this.props.massMaintenceSubmit({ KJOBN: currentRecordData.JBJOBN, record:record })
				break;

		}
	};
	setIsActionClose = () => {
		this.setState({ isOpenActions: false });
	};
	handleDisplay = (id, value) => {
		const { massmaintenancejobColumnDefs } = this.props
		let predecessor = getListPredecessor(MASSMAINTENANCEJOBS_LIST_PAGE);
		if (massmaintenancejobColumnDefs && massmaintenancejobColumnDefs.length) {
			let field = massmaintenancejobColumnDefs.find(x => (Boolean(Number(x.FDPRFX)) ? x.FDFNAM.trim() : predecessor + x.FDFNAM.trim()) == id)
			if (field) {
				const { valueSuggestionList } = field
				let valueSuggestion = valueSuggestionList.find(x => x.value.trim() == value);
				if (valueSuggestion) {
					return valueSuggestion.label
				}
			}
		}
		return '';
	}
	render() {
		const { classes, handleMassmaintenancejobHeaderFilterClick, handleMassmaintenancejobHeaderSaveClick,valueArray,
			saveDisabled, isShowContextMenu, selectedValue, removeChildCutdownTab, contextMenu, onContextMenuChange, currentRecordData, freezeComponentStyle, globalDateFormat } = this.props;
			
			let actionList = [...CONTEXT_MENU_HEADER_MASSMAINTENANCEJOB_ACTIONS];
			if (valueArray && valueArray["rerun"] && Boolean(Number(valueArray["rerun"]))) {
				actionList[0].isDisable = false;
				actionList[1].isDisable = false;
			} else {
				actionList[0].isDisable = true;
				actionList[1].isDisable = true;
			}

		return (
			<div className={classes.propertiesHeaderContainer} style={freezeComponentStyle}>
				<div className={classes.boookingDetailContainer}>
					<Box className={classes.boookingDetailDetailsWrapper}>
						<Box className={classes.bookingArrowWrapper}>
							<Button color="primary" onClick={() => this.onClickUpArrow()} className={classes.boookingArrow} disabled={this.handleDisableUpArrow()}>
								<KeyboardArrowUpIcon />
							</Button>
							<Button color="primary" onClick={() => this.onClickDownArrow()} className={classes.boookingArrow} disabled={this.handleDisableDownArrow()}>
								<KeyboardArrowDownIcon />
							</Button>
						</Box>
						<Box className={classes.vendorDetailRow}>
							<div className={classes.vendorIDSubID}>
								<div className={classes.vendorDetail}>
									<div className={classes.vendorIDBlock}>
										<div className={`${classes.vendorDetail} ${classes.vendorIdDetails}`}>
											<div className={classes.vendorLabel}>
												{this.getLabelValue(LABEL_JOB_NUMBER)}
											</div>
											<div> {currentRecordData.JBJOBN}</div>
										</div>
										<div className={`${classes.vendorDetail} ${classes.vendorSubVendorDetails}`}>
											<div className={classes.vendorLabel}>
												{this.getLabelValue(LABEL_JOB_TYPE)}
											</div>
											<div> {currentRecordData.JBJTYP && this.handleDisplay('JBJTYP', currentRecordData.JBJTYP)} </div>
										</div>
									</div>
								</div>
								<div className={`${classes.vendorName} ${classes.descField}`}>
									<div className={`${classes.vendorLabel}`}>
										{this.getLabelValue(LABEL_JOB_DESCRIPTION)}
									</div>
									<div> {currentRecordData.JBJDES}</div>
								</div>
							</div>
							<div className={classes.IdNameBlock}>
								<div className={classes.vendorDetail}>
									<div className={classes.vendorLabel}> {this.getLabelValue(LABEL_JOB_RUNDATE)} </div>
									{/* <div className={classes.vendorValue}>{currentRecordData.JBRUND && getDateFormatValue(currentRecordData.JBRUND)}</div> //E3C-31950:Ajit added to format in globaldateformat*/}
									<div className={classes.vendorValue}>{currentRecordData.JBRUND && getDateFormatted(getDateFromJulian(currentRecordData.JBRUND), globalDateFormat)}</div>

								</div>
								<div className={`${classes.vendorDetail} ${classes.nameField}`}>
									<div className={classes.vendorLabel}>{this.getLabelValue(LABEL_JOB_RUNTIME)}</div>
									<div className={classes.vendorValue}>{currentRecordData.JBRUNT && formatStringToTime(currentRecordData.JBRUNT)}</div>
								</div>
							</div>
							<div className={classes.IdNameBlock}>
								<div className={classes.vendorDetail}>
									<div className={classes.vendorLabel}> {this.getLabelValue(LABEL_JOB_RERUN_STATUS)} </div>
									<div className={classes.vendorValue}>{currentRecordData.JBRSTS && this.handleDisplay('JBRSTS', currentRecordData.JBRSTS)}</div>
								</div>
								<div className={`${classes.vendorDetail} ${classes.nameField}`}>
									<div className={classes.vendorLabel}>{this.getLabelValue('41210')}</div>
									<div className={classes.vendorValue}>{currentRecordData.PJPROJ}</div>
								</div>

							</div>
							<div className={classes.IdNameBlock + " " + classes.poAlign}>
								<div className={classes.vendorDetail}>
									<div className={classes.vendorLabel}> {this.getLabelValue('2305')} </div>
									<div className={classes.vendorValue}>{this.handleDisplay('JBJSTS', currentRecordData.JBJSTS)}</div>
								</div>
							</div>
						</Box>
						<Box className={classes.bookingActions}>
							<div className={classes.buttonActions}>
								<div className={classes.buttonActionsSecondChild}
									onClick={(event) => this.setIsOpenActionsButtonContextMenu(event)}
									onMouseLeave={() => this.setIsOpenActionsButtonContextMenu(false)}>
									<Button color="primary" size="small" variant="outlined" className={classes.vendorArrow} /* disabled={this.handleDisableDownArrow()} */>
										<div>{this.getLabelValue(LABEL_ACTIONS)}</div>
										<KeyboardArrowDownIcon />
									</Button>
									<ContextMenu
										className={classes.ActionsContextMenu}
										menuList={actionList}
										isOpen={this.state.isOpenActions}
										menuRef={this.state.actionMenuRef}
										handleItemSelection={(val) => this.handleActionSelection(val)}
										handleMenuClose={(val) => this.setIsActionClose(val)}>
									</ContextMenu>
								</div>
								<div className={isShowContextMenu || true ? 'showContextMenu' : 'hideContextMenu'}>
									<BreadcrumbContextMenu
										onOptionChange={(e, val) => onContextMenuChange(e, val)} menuItems={contextMenu}
										removeChildCutdownTab={removeChildCutdownTab}
										selectedValue={selectedValue} />
								</div>
							</div>
							<Button component="div" color="primary" onClick={handleMassmaintenancejobHeaderFilterClick} className={classes.bookingActionsFilter}>
								<img src={FilterIcon} alt="Filter Icon" />
							</Button>
							<Button component="div" color="primary" onClick={handleMassmaintenancejobHeaderSaveClick} disabled={saveDisabled} className={classes.bookingActionsFilter}>
								<SaveIcon fontSize="large" />
							</Button>
							{/* //~~~CreateNewFramework--JVK 
							<Box className={classes.menuButton}>
								<div
									onMouseEnter={(event) => this.setIsOpenActionsContextMenu(event)}
									onMouseLeave={(event) => this.setIsOpenActionsContextMenu(false)}>
									<MoreVertIcon color="primary" className="cPointer"></MoreVertIcon>
									<ContextMenuCreateNew
										className={classes.ActionsContextMenu}
										menuList={[]}
										isOpen={this.state.isOpenActionsContextMenu}
										menuRef={this.state.menuRef}
										handleItemSelection={(val) => { }}
										handleMenuClose={(val) => this.setIsOpenActionsContextMenu(val)}
									>
									</ContextMenuCreateNew>
								</div>
							</Box>
							{/* //~~~CreateNewFramework--JVK */}
						</Box>
					</Box>
				</div>
				{this.state.showConfirmationDialog && <ConfirmationDialog
					hasWarning={true}
					isOpen={this.state.showConfirmationDialog}
					dialogTitle={this.getLabelValue(52891)}
					submitText={TEXT_OK}
					cancelText={TEXT_CANCEL}
					handleClose={() => this.setState({ showConfirmationDialog: false })}
					handleCancel={() => this.setState({ showConfirmationDialog: false })}
					handleSubmit={() => this.handleActionSubmit(this.state.submitValue)}>
					{this.state.dialogContent}
				</ConfirmationDialog>
				}
			</div>
		);
	}
}

export default injectIntl(withStyles(style)(withFixedPosition(Header)));

import produce from 'immer';
import { fromJS } from 'immutable';

import {
	GET_ITEM_ON_DEAL_LIST,
	GET_ITEM_ON_DEAL_LIST_SUCCESS,
	GET_ITEM_ON_DEAL_LIST_FAILURE,
	GET_ITEM_ON_DEAL_COLUMN_DEFINITION,
	GET_ITEM_ON_DEAL_COLUMN_DEFINITION_SUCCESS,
	GET_ITEM_ON_DEAL_COLUMN_DEFINITION_FAILURE,
	GET_ITEM_ON_DEAL_UPDATE_COLUMN_DEFINITION,
	GET_ITEM_ON_DEAL_UPDATE_COLUMN_DEFINITION_SUCCESS,
	GET_ITEM_ON_DEAL_UPDATE_COLUMN_DEFINITION_FAILURE,
	RESET_DEFAULTS,
	RESET_DEFAULTS_SUCCESS,
	RESET_DEFAULTS_FAILURE,
	SET_FILTER_VALUES,
	SET_COLUMN_DEFS_LOADED,
	SET_PAGEPROPS,
	SET_APICALL_COUNT,
	GET_ITEMS_LIST,
	GET_ITEMS_LIST_SUCCESS,
	GET_ITEMS_LIST_FAILURE,
	RESET_DATA,
	LABEL_DATA_FLAGS,
	GET_DEAL_COLUMN_DEFS,
	GET_DEAL_COLUMN_DEFS_SUCCESS,
	GET_DEAL_COLUMN_DEFS_FAILURE,

	GET_DEAL_ALLOWANCE_DETAIL,
	GET_DEAL_ALLOWANCE_DETAIL_SUCCESS,
	GET_DEAL_ALLOWANCE_DETAIL_FAILURE,

	ITEM_ON_DEAL_DETAIL,
	ITEM_ON_DEAL_DETAIL_SUCCESS,
	ITEM_ON_DEAL_DETAIL_ERROR,
	ITEM_ON_DEAL_LABEL_TAB_KEY,
	ADD_RECORD,
	ADD_RECORD_SUCCESS,
	ADD_RECORD_FAILURE,
	REMOVE_RECORD,
	REMOVE_RECORD_SUCCESS,
	REMOVE_RECORD_FAILURE,
	UPDATE_RECORD,
	UPDATE_RECORD_SUCCESS,
	UPDATE_RECORD_FAILURE,
	SET_UPDATE_RECORD_FLAG,
	UPDATE_VALUE_ON_EDIT,
	embeddedListFields,
	ITEM_ON_DEAL_UPDATE,
	ITEM_ON_DEAL_UPDATE_SUCCESS,
	ITEM_ON_DEAL_UPDATE_ERROR,
	ITEM_ON_DEAL_UPDATE_ON_EDIT
} from './constants';

import {
	COLUMN_VALUE_ACCESSOR,
	COLUMN_POSITION, COLUMN_FIELD_TYPE,
	DROPDOWN_FIELD, INITIAL_PAGE_PROPS,
} from "components/common/constants";

import {
	getSortableColumns,
	prepareBaseJSONwithFieldData,
	setNumberFields,
	prepareValuesFromReserved,
	getListPredecessor,
	getPrecisionLength,
	getFormattedNumber, getUnformattedValue,
} from 'utils/util';

const initialState = fromJS({
	columnDefs: false,
	columnInfo: false,
	updateColumnsList: false,
	filterProps: false,
	isColumnDefsLoaded: false,
	rowData: [],
	loading: true,
	isAPIProgress: false,
	pageProps: false,
	totalCount: 0,
	moreRecordsAvailable: false,
	apiCallCount: 0,
	itemsOnDealLabelsData: [],
	itemListArray: false,
	isAPIforItemOnDealList: false,
	isAPIforColumns: false,
	isAPIforColumnsUpdate: false,
	isAPIforResetColumns: false,
	isAPIforItemList: false,
	rowDataAllowance: [],
	addUpdateDeleteFlag: false,
	itemOnDealIsSaveSuccess: false,
	removeRecordFlag: false,
	resetDefaultsCols:false
});

const itemOnDealReducer = (state = initialState, action) => {
	switch (action.type) {
		case GET_ITEM_ON_DEAL_LIST: return state.set('loading', true).set('isAPIforItemOnDealList', false);
		case GET_ITEM_ON_DEAL_LIST_SUCCESS:
			let direction = state.get('pageProps').isForwardDirection;
			let data = action.data;
			if (data && data.listArray && data.listArray.length) {
				let count = state.get('apiCallCount');
				let totalCount = 100 * count + data.listArray.length;
				let dataList = data.listArray;
				dataList.forEach((row) => {
					row["isSelected"] = false;
				})

				if (!direction) {
					dataList.reverse();
				}
				return state
					.set('isAPIProgress', false)
					.set('rowData', dataList)
					.set('moreRecordsAvailable', data.moreRecordsAvailable)
					.set('totalCount', totalCount)
					.set('loading', false);
			}
			return state.set('rowData', action.data);
		case GET_ITEM_ON_DEAL_LIST_FAILURE: return state.state.set('loading', false)
			.set('rowData', []).set('isAPIforItemOnDealList', true);

		case GET_ITEM_ON_DEAL_COLUMN_DEFINITION: return state.set('loading', true).set('isAPIforColumns', false);
		case GET_ITEM_ON_DEAL_COLUMN_DEFINITION_SUCCESS:
			if (action.data && action.data.fields && action.data.fields.length) {
				let columnFields = action.data.fields.filter(col => Object.keys(col).length);
				columnFields.forEach(x => {
					let field = embeddedListFields.find(y => x.FLDNUM == y.FLDNUM);
					if (field) {
						x.FDPRFX = "1";
						x.FDFNAM = field.FDFNAM;
					}
					x["sortable"] = false;
				})
				columnFields.forEach(item => {
					if (item.hasOwnProperty("FLDNUM") && item.FLDNUM == "5319")
					{
						item.FDFILD = '3016';
						item.FDFNAM = 'SEQ#';
						item.FLDNUM = '3016';
						item.TSLAB = 'Seq';
						item.TIDNO = '33016';
						item.TLLAB = 'Display Sequence';
					}
					
				})
				let list = getSortableColumns(columnFields, COLUMN_POSITION, COLUMN_FIELD_TYPE, DROPDOWN_FIELD);
				return state
					.set('loading', false)
					.set('isColumnDefsLoaded', true)
					.set('updateColumnsList', false)
					.set('columnInfo', action.data.info)
					.set('columnDefs', list)
			}
		case GET_ITEM_ON_DEAL_COLUMN_DEFINITION_FAILURE: return state
			.set('loading', false).set('isAPIforColumns', true);

		case GET_ITEM_ON_DEAL_UPDATE_COLUMN_DEFINITION: return state.set('loading', true).set('isAPIforColumnsUpdate', false);
		case GET_ITEM_ON_DEAL_UPDATE_COLUMN_DEFINITION_SUCCESS:
			let updateData = action.data;
			if (updateData.message && updateData.message.length && updateData.message.toLowerCase() == 'success') {
				return state.set('updateColumnsList', true)
					.set('loading', true)
					.set('columnDefs', []);
			}
			return state;
		case GET_ITEM_ON_DEAL_UPDATE_COLUMN_DEFINITION_FAILURE:
			return state.set('loading', false).set('isAPIforColumnsUpdate', true);

		case RESET_DEFAULTS:
			return state.set('loading', true).set('resetDefaultsCols',false)
				.set('isAPIforResetColumns', false);
		case RESET_DEFAULTS_SUCCESS:
			return state.set('loading', false).set('resetDefaultsCols',true);
		case RESET_DEFAULTS_FAILURE:
			return state.set('loading', false).set('resetDefaultsCols',false)
				.set('isAPIforResetColumns', true);
		case RESET_DATA: return initialState;

		case SET_APICALL_COUNT: return state.set('apiCallCount', action.data);
		case SET_PAGEPROPS: return state.set('pageProps', JSON.parse(JSON.stringify(action.data)));
		case SET_FILTER_VALUES: return state.set('filterProps', JSON.parse(JSON.stringify(action.data)));
		case SET_COLUMN_DEFS_LOADED: return state.set('loading', true);

		case GET_ITEMS_LIST: return state.set('loading', true).set('itemListArray',false).set('isAPIforItemList', false)
		case GET_ITEMS_LIST_SUCCESS:
			return state.set('loading', false).set('itemListArray', action.data);
		case GET_ITEMS_LIST_FAILURE:
			return state.set('loading', false).set('isAPIforItemList', true);

		case GET_DEAL_COLUMN_DEFS:
			return state.set('loading', true);
		case GET_DEAL_COLUMN_DEFS_SUCCESS:
			let tabTitles = [];
			let itemsOnDealLabelsData = {};
			let propertiesLabels = JSON.parse(JSON.stringify(action.data));
			if (propertiesLabels.tabs && propertiesLabels.tabs.length) {
				propertiesLabels.tabs.forEach((tab) => {
					let propertyTab = JSON.parse(JSON.stringify(tab));
					tabTitles.push(propertyTab);
					propertyTab.tabcards.forEach((card, index) => {
						let cardData = JSON.parse(JSON.stringify(card.cardfields));
						if (cardData && cardData.length) {
							let cardfields = cardData.filter(x => x.FLDID != "3014");
							cardfields.forEach((card) => {
								if (card[COLUMN_VALUE_ACCESSOR]) {
									card.key = Number(card.FDPRFX) ? card[COLUMN_VALUE_ACCESSOR].trim() : getListPredecessor('itemondeal') + card[COLUMN_VALUE_ACCESSOR].trim();
									card["TSLAB"] = "";
								}
							});
							cardfields = getSortableColumns(cardfields, false, COLUMN_FIELD_TYPE, DROPDOWN_FIELD);
							cardfields = setNumberFields(cardfields);
							propertyTab.tabcards[index].cardfields = cardfields;
						}
					});
					if (propertyTab.tabkey == ITEM_ON_DEAL_LABEL_TAB_KEY) {
						itemsOnDealLabelsData = propertyTab;
					}
				});
			}
			return state.set('loading', false)
				.set('itemsOnDealLabelsData', itemsOnDealLabelsData)
				.set('labelsDataFailure', false)
		case GET_DEAL_COLUMN_DEFS_FAILURE:
			return state.set('loading', false).set('labelsDataFailure', true);

		case ITEM_ON_DEAL_DETAIL:
			return state.set('loading', true);
		case ITEM_ON_DEAL_DETAIL_SUCCESS:
			let values = {};
			data = action.data;
			if (data && Array.isArray(data)) {
				return state.set('loading', false)
					.set('isValueDataAPIFailure', true)
					.set('valueData', false)
			} if (data && Object.values(data) && Object.values(data).length) {
				Object.values(data).forEach((el, index) => {
					if (el.toString().replace(/\s/g, '').length) {
						values[Object.keys(data)[index]] = Object.values(data)[index].trim();//Keep the value if not an empty string
					} else {
						values[Object.keys(data)[index]] = '';//Change to empty string if only string onl contains SPACE/TAB
					}
				});
				let finalValues = { ...values };
				return state.set('loading', false)
					.set('isValueDataAPICall', true)
					.set('detailCallData', JSON.parse(JSON.stringify(values)))
					.set('newDetailCallData', JSON.parse(JSON.stringify(values)))
					.set('valueData', JSON.parse(JSON.stringify(values)))
					.set('finalApiData', finalValues)
					.set('newValueData', values)
					.set('headerRefreshAfterSuccess', true)
					.set('oldvendor', values)
			}

			return state.set('loading', false)
				.set('isValueDataAPIFailure', true)
				.set('valueData', values)
				.set('newValueData', values)
				.set('headerRefreshAfterSuccess', true)

		case ITEM_ON_DEAL_DETAIL_ERROR:
			return state.set('loading', false)
				.set('isValueDataAPIFailure', true)
		case GET_DEAL_ALLOWANCE_DETAIL:
			return state.set('loading', true)
		case GET_DEAL_ALLOWANCE_DETAIL_SUCCESS:
			let rowDataAllowance = state.get('rowDataAllowance');
			if (action.data && Array.isArray(action.data) && action.data.length) {
				rowDataAllowance = [...action.data];
				rowDataAllowance.forEach(row => {
					row["DAXCLD"] = row["DAXCLD"] == "" ? ' ' : row["DAXCLD"];
				})
				return state.set('rowDataAllowance', rowDataAllowance).set('loading', false).set('isAPIforDealAllowance', false)
			}
			return state.set('loading', false).set('rowDataAllowance', []).set('isAPIforDealAllowance', false)
		case GET_DEAL_ALLOWANCE_DETAIL_FAILURE:
			return state.set('loading', false).set('isAPIforDealAllowance', true)

		case LABEL_DATA_FLAGS:
			return state.set(action.data.key, action.data.value);

		case ADD_RECORD:
			return state.set('loading', true).set('addUpdateDeleteFlag', false);
		case ADD_RECORD_SUCCESS:
			let rows = [...state.get('rowDataAllowance')];
			let addedData = action.data.data
			addedData['DAXCLD'] = addedData['DAXCLD'] == '' ? " " : addedData['DAXCLD'];
			rows.push(addedData);

			return state.set('loading', false)
				.set('addUpdateDeleteFlag', true).set('rowDataAllowance', rows);
		case ADD_RECORD_FAILURE:
			return state.set('loading', false).set('addUpdateDeleteFlag', false);

		case REMOVE_RECORD:
			return state.set('loading', true).set('addUpdateDeleteFlag', false);
		case REMOVE_RECORD_SUCCESS:
			rows = [...state.get('rowDataAllowance')];
			let removeRecord = action.data.data;
			const rowsAfterRemove = rows.filter(x => x.DAALOW != removeRecord.DAALOW)

			return state.set('loading', false)
				.set('addUpdateDeleteFlag', true).set('rowDataAllowance', rowsAfterRemove);;
		case REMOVE_RECORD_FAILURE:
			return state.set('loading', false).set('addUpdateDeleteFlag', false);

		case UPDATE_RECORD:
			return state.set('loading', true).set('addUpdateDeleteFlag', false);
		case UPDATE_RECORD_SUCCESS:
			rows = [...state.get('rowDataAllowance')];
			let updatedRows = action.data.data || [];
			updatedRows.forEach(row => {
				let index = rows.findIndex(x => x.DAALOW == row.DAALOW);
				if (index != -1) {
					row['DAXCLD'] = row['DAXCLD'] == '' ? " " : row['DAXCLD'];
					rows[index] = { ...row }
				}
			});
			return state.set('loading', false)
				.set('addUpdateDeleteFlag', true)
				.set('rowDataAllowance', rows);
		case UPDATE_RECORD_FAILURE:
			return state.set('loading', false).set('addUpdateDeleteFlag', false);
		case SET_UPDATE_RECORD_FLAG:
			return state.set(action.data.key, action.data.value);
		case UPDATE_VALUE_ON_EDIT:
			if (action.data.colId) {
				let rowDataValues = [...state.get('rowDataAllowance')];
				rowDataValues[action.data.rowIndex][action.data.columnName] = action.data.value;
				rowDataValues[action.data.rowIndex]["isRowDataChanged"] = true;
				return state.set('rowDataAllowance', rowDataValues)
					.set('redrawRows', true)
			} else {
				let rowDataValues = [...state.get('rowDataAllowance')];
				let redrawRows = true;
				let valueObj = { ...action.data }
				rowDataValues[action.data.rowIndex] = valueObj.data;
				rowDataValues[action.data.rowIndex]["isRowDataChanged"] = true;
				return state.set('rowDataAllowance', rowDataValues)
					.set('redrawRows', redrawRows)
			}
		case ITEM_ON_DEAL_UPDATE:
			return state.set('itemOnDealIsSaveSuccess', false)
				.set('loading', true)

		case ITEM_ON_DEAL_UPDATE_SUCCESS:
			const valueDatax = state.get('valueData');
			const newValueDatax = state.get('newValueData');
			return state.set('itemOnDealIsSaveSuccess', true)
				.set('valueData', valueDatax)
				.set('newValueData', newValueDatax)
				.set('loading', false)
		case ITEM_ON_DEAL_UPDATE_ERROR:
			return state.set('itemOnDealIsSaveSuccess', false)
				.set('updated', false)
				.set('loading', false)
		case ITEM_ON_DEAL_UPDATE_ON_EDIT:
			let key = action.data.key, val = action.data.val, obj = state.get('newValueData'), finalApiData = JSON.parse(JSON.stringify(state.get('finalApiData')));
			obj = { ...obj };
			obj[key] = val;
			finalApiData = { ...finalApiData };
			finalApiData[key] = val;
			return state.set('newValueData', obj)
				.set('finalApiData', finalApiData)
		default: return state;
	}
}

export default itemOnDealReducer;
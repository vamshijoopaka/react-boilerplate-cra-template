/**
 *
 * Asynchronously loads the component for BookingsList
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));

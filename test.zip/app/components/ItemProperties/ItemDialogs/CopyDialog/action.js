import * as itemCopyConstants from './constants';

export function getItemCopyList(data) {
    return {
        type: itemCopyConstants.GET_ITEMCOPY_LIST,
        data
    }
}

export function setItemCopyListSuccess(data) {
    return {
        type: itemCopyConstants.GET_ITEMCOPY_LIST_SUCCESS,
        data
    }
}

export function setItemCopyListFailure(data) {
    return {
        type: itemCopyConstants.GET_ITEMCOPY_LIST_FAILURE,
        data
    }
}


export function getItemCopyColumnDefs(data) {
    return {
        type: itemCopyConstants.GET_ITEMCOPY_COLUMN_DEFINITION,
        data
    }
}

export function setItemCopyListColumnDefs(data) {
    return {
        type: itemCopyConstants.GET_ITEMCOPY_COLUMN_DEFINITION_SUCCESS,
        data
    }
}

export function setItemCopyListColumnDefsFailure(data) {
    return {
        type: itemCopyConstants.GET_ITEMCOPY_COLUMN_DEFINITION_FAILURE,
        data
    }
}

export function updateShowHide(data) {
    return {
        type: itemCopyConstants.GET_ITEMCOPY_UPDATE_COLUMN_DEFINITION,
        data
    }
}

export function updateColumnDefsSuccess(data) {
    return {
        type: itemCopyConstants.GET_ITEMCOPY_UPDATE_COLUMN_DEFINITION_SUCCESS,
        data
    }
}

export function updateColumnDefsFailure(data) {
    return {
        type: itemCopyConstants.GET_ITEMCOPY_UPDATE_COLUMN_DEFINITION_FAILURE,
        data
    }
}

export function resetDefault(data) {
    return {
        type: itemCopyConstants.RESET_DEFAULTS,
        data
    }
}

export function resetDefaultSuccess(data) {
    return {
        type: itemCopyConstants.RESET_DEFAULTS_SUCCESS,
        data
    }
}

export function resetDefaultFailure(data) {
    return {
        type: itemCopyConstants.RESET_DEFAULTS_FAILURE,
        data
    }
}

export function setFilterValues(data) {
    return {
        type: itemCopyConstants.SET_FILTER_VALUES,
        data
    }
}

export function setColumnDefsLoaded(data) {
    return {
        type: itemCopyConstants.SET_COLUMN_DEFS_LOADED,
        data
    }
}

export function resetStateData(data) {
    return {
        type: itemCopyConstants.RESET_DATA,
        data
    }
}


export function setApiCallCount(data) {
    return {
        type: itemCopyConstants.SET_APICALL_COUNT,
        data
    }
}

export function onSetPageProps(data) {
    return {
        type: itemCopyConstants.SET_PAGEPROPS,
        data
    }
}

export function getItemsList(data) {
    return {
        type: itemCopyConstants.GET_ITEMS_LIST,
        data
    }
}

export function setItemsListSuccess(data) {
    return {
        type: itemCopyConstants.GET_ITEMS_LIST_SUCCESS,
        data
    }
}

export function setItemsListFailure(data) {
    return {
        type: itemCopyConstants.GET_ITEMS_LIST_FAILURE,
        data
    }
}

export function setLabelDataFlags(data) {
    return {
        type: itemCopyConstants.LABEL_DATA_FLAGS,
        data
    }
}
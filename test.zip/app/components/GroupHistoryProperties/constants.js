export const ACTIONS_MENULIST = [
    {
        key: 'simulateprofile',
        label: '50102',
    },
    {
        key: 'assignitems',
        label: '32772',
    },
    {
        key: 'acceptprofile',
        label: '50773',
        simInProgress: true,
    },
    {
        key: 'cancel',
        label: '2',
        simInProgress: true,
    },
]
export const RADIO_OPTIONS = [
    { key: '52562', fieldValue: 'show13' },
    { key: '52563', fieldValue: 'show52' },
];

export const ASSIGN_ITEMS_MENUITEMS = [
    {
      label: '2812',
      key: 'showHide',
    },
    {
      label: '2857',
      key: 'resetDefaults',
    },
    {
      label: '2976',
      key: 'selectAll',
    },
    {
      label: '2977',
      key: 'deselectAll',
    },
]

/*
* * //==========================================================================
*
* * // Copyright 2021-2021, Blue Yonder Group, Inc.
*
* * // All Rights Reserved
*
* * //
*
* * // THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF
*
* * // BLUE YONDER GROUP, INC.
*
* * //
*
* * //
*
* * // The copyright notice above does not evidence any actual
*
* * // or intended publication of such source code.
*
* * //
*
* * // ===========================================================================
/* *******************************PATCH HISTORY******************************** */

/* E3C-33266 - SRK - AWR WEB UI graphs have hardcoded English labels
                     Removed hardcoding and retrieved label based on ID. 
                     (10-Nov-2021)
* * // ===========================================================================
*/

import React from 'react';
import PropTypes from 'prop-types';
import HightchartsReact from 'highcharts-react-official';
import Highcharts from 'highcharts/highstock';

class PurchaseSummaryByMonthChart extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    const { series, categories } = this.props;
    const options = {
      chart: {
        type: 'column',
        scrollbar: {
          enabled: false,
        },
      },
      title: {
        text: JSON.parse(localStorage["messageLabels"])["H25267"]["TLLAB"] /*E3C-33266 'Inventory Analysis - Purchases Summary by Month' */,
      },
      xAxis: {
        categories,
      },
      yAxis: {
        title: {
          text: '',
        },
        stackLabels: {
          enabled: true,
          style: {
            fontWeight: 'bold',
            color:
              // theme
              (Highcharts.defaultOptions.title.style &&
                Highcharts.defaultOptions.title.style.color) ||
              'gray',
          },
        },
      },
      legend: {
        layout: 'horizontal',
        align: 'center',
        verticalAlign: 'bottom',
      },
      plotOptions: {
        series: {
          label: {
            connectorAllowed: false,
          },
        },
        column: {
          stacking: 'normal',
          dataLabels: {
            enabled: false,
          },
        },
      },
      credits: {
        enabled: false,
      },
      series,
      responsive: {
        rules: [
          {
            condition: {
              maxWidth: 500,
            },
            chartOptions: {
              legend: {
                layout: 'horizontal',
                align: 'center',
                verticalAlign: 'bottom',
              },
            },
          },
        ],
      },
    };
    return ( 
    <div style={{ maxWidth: '101%', width: '100%' }}>
      <HightchartsReact highcharts={Highcharts} options={options} />  .
    </div>
    )
  }
}

PurchaseSummaryByMonthChart.propTypes = {
  series: PropTypes.array,
  categories: PropTypes.array,
};

export default PurchaseSummaryByMonthChart;

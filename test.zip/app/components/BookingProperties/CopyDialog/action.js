import {
	GET_BOOKINGCOPY_LIST,
	GET_BOOKINGCOPY_LIST_SUCCESS,
	GET_BOOKINGCOPY_LIST_FAILURE,
	GET_BOOKINGCOPY_COLUMN_DEFINITION,
	GET_BOOKINGCOPY_COLUMN_DEFINITION_SUCCESS,
	GET_BOOKINGCOPY_COLUMN_DEFINITION_FAILURE,
	GET_BOOKINGCOPY_UPDATE_COLUMN_DEFINITION,
	GET_BOOKINGCOPY_UPDATE_COLUMN_DEFINITION_SUCCESS,
	GET_BOOKINGCOPY_UPDATE_COLUMN_DEFINITION_FAILURE,
	RESET_DEFAULTS,
	RESET_DEFAULTS_SUCCESS,
	RESET_DEFAULTS_FAILURE,
	SET_FILTER_VALUES,
	SET_COLUMN_DEFS_LOADED,
	SET_PAGEPROPS,
	SET_APICALL_COUNT,
	GET_ITEMS_LIST,
	GET_ITEMS_LIST_SUCCESS,
	GET_ITEMS_LIST_FAILURE,
	RESET_DATA,
	LABEL_DATA_FLAGS,
} from './constants';

export function getBookingCopyList(namespace, data) {
	return {
		type: GET_BOOKINGCOPY_LIST,
		data
	}
}

export function setBookingCopyListSuccess(data) {
	return {
		type: GET_BOOKINGCOPY_LIST_SUCCESS,
		data
	}
}

export function setBookingCopyListFailure(data) {
	return {
		type: GET_BOOKINGCOPY_LIST_FAILURE,
		data
	}
}


export function getBookingCopyColumnDefs(namespace, data) {
	return {
		type: GET_BOOKINGCOPY_COLUMN_DEFINITION,
		data
	}
}

export function setBookingCopyListColumnDefs(data) {
	return {
		type: GET_BOOKINGCOPY_COLUMN_DEFINITION_SUCCESS,
		data
	}
}

export function setBookingCopyListColumnDefsFailure(data) {
	return {
		type: GET_BOOKINGCOPY_COLUMN_DEFINITION_FAILURE,
		data
	}
}

export function updateShowHide(namespace, data) {
	return {
		type: GET_BOOKINGCOPY_UPDATE_COLUMN_DEFINITION,
		data
	}
}

export function updateColumnDefsSuccess(data) {
	return {
		type: GET_BOOKINGCOPY_UPDATE_COLUMN_DEFINITION_SUCCESS,
		data
	}
}

export function updateColumnDefsFailure(data) {
	return {
		type: GET_BOOKINGCOPY_UPDATE_COLUMN_DEFINITION_FAILURE,
		data
	}
}

export function resetDefault(data) {
	return {
		type: RESET_DEFAULTS,
		data
	}
}

export function resetDefaultSuccess(data) {
	return {
		type: RESET_DEFAULTS_SUCCESS,
		data
	}
}

export function resetDefaultFailure(data) {
	return {
		type: RESET_DEFAULTS_FAILURE,
		data
	}
}

export function setFilterValues(namespace, data) {
	return {
		type: SET_FILTER_VALUES,
		data
	}
}

export function setColumnDefsLoaded(namespace, data) {
	return {
		type: SET_COLUMN_DEFS_LOADED,
		data
	}
}

export function resetStateData(namespace, data) {
	return {
		type: RESET_DATA,
		data
	}
}


export function setApiCallCount(namespace, data) {
	return {
		type: SET_APICALL_COUNT,
		data
	}
}

export function onSetPageProps(namespace, data) {
	return {
		type: SET_PAGEPROPS,
		data
	}
}

export function getItemsList(namespace, data) {
	return {
		type: GET_ITEMS_LIST,
		data
	}
}

export function setItemsListSuccess(data) {
	return {
		type: GET_ITEMS_LIST_SUCCESS,
		data
	}
}

export function setItemsListFailure(data) {
	return {
		type: GET_ITEMS_LIST_FAILURE,
		data
	}
}

export function setLabelDataFlags(namespace, data) {
	return {
		type: LABEL_DATA_FLAGS,
		data
	}
}
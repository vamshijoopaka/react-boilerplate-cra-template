import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core';
import EmbeddedList from 'containers/common/EmbeddedList';
import {MENU_ITEMS} from 'components/InventoryAnalysisProperties/constants';

const style = () => ({
  itemsEmbeddedList: {
    '& > div': {
      height: '80%',
      '& > div': {
        '& > div': {
          '&:last-child': {
            '& > div': {
              '&:first-child': {
                '& > div': {
                  '&:first-child': {
                    height: 'calc(100vh - 546px) !important',
                    minHeight: '390px',
                  },
                },
              },
            },
          },
          '&:first-child': {
          },
        },
      },
    },
    '& div.MuiTablePagination-root': {
      display: 'none',
    },
    '& div.ag-center-cols-container': {
      '& div.ag-cell': {
        '&:nth-child(3)': {
          display: 'inline-block',
          padding: '2px !important',
          paddingRight: '5px !important',
        },
        '&:nth-child(4)': {
          display: 'inline-block',
          padding: '2px !important',
          paddingRight: '5px !important',
        },
        '&:nth-child(5)': {
          display: 'inline-block',
          padding: '2px !important',
          paddingRight: '5px !important',
        },
        '&:nth-child(6)': {
          display: 'inline-block',
          padding: '2px !important',
          paddingRight: '5px !important',
        },
        '&:nth-child(7)': {
          display: 'inline-block',
          padding: '2px !important',
          paddingRight: '5px !important',
        },
      },
    },
  },
});

class PurchaseSummaryByMonthEmbeddedList extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      menuItems: MENU_ITEMS,
    };
  }

  onGridReady = params => {
    this.grid = params;
  };

  render() {
    const { classes, columnDefs, columnInfo, pageProps, rowData } = this.props;
    return (
      <div className={classes.itemsEmbeddedList}>
        {columnDefs && columnInfo ? (
          <EmbeddedList
            columnDefs={columnDefs}
            rowColumnID="PSMTH#"
            rowData={rowData}
            columnInfo={columnInfo}
            columnKey="PSKEY"
            listPredecessor="PS"
            gridAPI={this.grid}
            frameworkComponents={{}}
            menuItems={MENU_ITEMS}
            pageProps={pageProps}
            onGridReady={this.onGridReady}
            hasPagination={true}
            hasDeleteRowAction={false}
            rowSelection="single"
            hasGridActions={true}
            updateShowHide={(data, currentPage) => this.props.updateShowHide(data, currentPage)}
            handleItemSelection={this.handleItemSelection}
          />
        ) : null}
      . </div>
    );
  }
}

PurchaseSummaryByMonthEmbeddedList.propTypes = {
  classes: PropTypes.object,
  columnDefs: PropTypes.array,
  columnInfo: PropTypes.object,
  pageProps: PropTypes.object,
  rowData: PropTypes.array,
};

export default withStyles(style)(PurchaseSummaryByMonthEmbeddedList);

import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import Slider from 'react-slick';
import NextIcon from '@material-ui/icons/SkipNext';
import BeforeIcon from '@material-ui/icons/SkipPrevious';
import { withStyles } from '@material-ui/core';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import './slick.css';

const style = () => ({
  sliderClass: {
    '& > div': {
      '& > div.slick-list': {
        marginLeft: 100,
        marginRight: 10,
      },
    },
    '& svg': {
      '&:first-child': {
        left: 30,
      },
      '&:last-child': {
        right: 5,
      },
      fill: '#048bd0',
    },
    '& svg.slick-disabled': {
      fill: '#afafaf',
    },
  },
});

class SliderComponent extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    const { classes, data } = this.props;
    const settings = {
      dots: false,
      infinite: false,
      speed: 500,
      slidesToShow: 7,
      slidesToScroll: 1,
      nextArrow: <NextIcon />,
      prevArrow: <BeforeIcon />,
    };
    return (
      <>
        {data && data.length ? (
          <div className={classes.sliderClass}>
            <Slider {...settings}>{data.map(item => item)}</Slider>
          </div>
        ) : null}
      </>
    );
  }
}

SliderComponent.propTypes = {
  classes: PropTypes.object,
  data: PropTypes.array,
};

export default withStyles(style)(SliderComponent);

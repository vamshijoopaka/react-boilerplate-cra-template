/** Change Log
 * LogStart --  E3C-33195 - Kumar A- 16 September,2021 - 2022.1.0.0 Unified Product
 *              Story: E3C-33195 --Code Cleanup
 * LogStart --  E3C-33340 - Kumar A- 7 December,2021 - 2022.1.0.0 Unified Product
 *              Story: E3C-33340 --Company: Invalid 'NaN' value is being displayed in Parameter fields under Exception Maintenance tab
*/
import React from 'react';
import { Grid } from '@material-ui/core';
import {
  withStyles,
} from '@material-ui/core/styles';

import Checkbox from '@material-ui/core/Checkbox';
import Card from '@material-ui/core/Card';
import FormattedMessageComponent from 'components/common/FormattedMessageComponent';
import GridErrorMessages from '../../common/GridErrorMessages';
import NewExceptionsType from '../CompanyDialogs/NewExceptionsType';
import ExceptionsTypeDetail from '../CompanyDialogs/ExceptionsTypeDetail';

import Box from '@material-ui/core/Box';
import MoreVertIcon from '@material-ui/icons/MoreVert';
import ContextMenu from '../../common/ContextMenu';
import TableGrid from '../../TableGrid';
import {
  LABEL_COMPANY_CI,
  CONTEXT_MENU_EXCEPTION,
  ADD_EXCEPTION,
}
  from './constants';

const styles = theme => ({
  pageContainer: {
    display: 'flex',
    backgroundColor: 'var(--background-app)',
    borderTop: 'none',
    padding: '10px 20px',
  },
  root: {
    flexGrow: 1,
    width: '100%',
  },
  card: {
    height: '100%',
    width: '100%',
  },
  table: {
    marginLeft: theme.spacing(100),
  },
  cardheader2: {
    marginLeft: theme.spacing(10),
    fontSize: '14px',
    backgroundColor: 'white',
    width: 210,
    color: 'black',
    borderLeft: '1px solid black',
  },
  cardheader3: {
    fontSize: '14px',
    backgroundColor: 'white',
    color: 'black',
    width: 230,
    borderLeft: '1px solid black',
    textAlign: 'right',
  },
  checkboxfield: {
    height: 10,
    marginBottom: theme.spacing(12),
    marginLeft: theme.spacing(2.4),
  },
  ActionsContextMenu: {
  },
  contextMenu: {
    display: 'flex',
    justifyContent: 'flex-end',
    alignItems: 'center',
    textAlign: 'right',
    paddingBottom: '10px'
  },
});

class ExceptionsMaintenance extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      open: true,
      open1: true,
      rows: this.props.companyExceptionMaintenanceListData,
      selectedData: null,
      selected: false,
      rowNumberSelected: 0,
      isOpenActionsContextMenu: false,
      menuRef: null,
      rowsData: {},
      rowsDetailData: {},
      disableSubmit: true,
      disableDetailSubmit: true,
      menuList: CONTEXT_MENU_EXCEPTION,
      // error messaging
      hasError: false,
      errorId: false,
      parameterValues: [],
    };
    this.handleSendData = this.handleSendData.bind(this);
    this.handleSendSelectedRow = this.handleSendSelectedRow.bind(this);
    this.setIsOpenActionsContextMenu = this.setIsOpenActionsContextMenu.bind(this);
  }

  handleSendData(selectedDataFrom) {
    this.setState({
      selected: true,
      selectedData: selectedDataFrom[0],
    });
  }

  handleSendSelectedRow(rowNumberSelect) {
    this.setState({
      rowNumberSelected: rowNumberSelect,
    });
  }

  handleOpen = () => {
    this.setState({
      open: true
    });
  };

  formatObject = object => {
    const newObject = { ...object };
    for (const key in newObject) {
      if (typeof newObject[key] === 'boolean') {
        newObject[key] = newObject[key] ? "1" : "0";
      }
    }
    return newObject;
  };

  processModifyData = (values, rowNumberSelected) => {
    delete values['EXTYPE'];
    delete values['undefinedVAL1'];
    delete values['undefinedVAL2'];
    let value1 = values['ECVAL1'].trim() == "" ? 0 : Math.round(parseFloat(values['ECVAL1'])); //E3C-33340, 12/7/21, Kumar
    let value2 = values['ECVAL2'].trim() == "" ? 0 : Math.round(parseFloat(values['ECVAL2'])); //E3C-33340, 12/7/21, Kumar
    value1 = value1.toFixed(1).toString();
    value2 = value2.toFixed(1).toString();
    values['ECVAL1'] = value1;
    values['ECVAL2'] = value2;
    values = this.formatObject(values);
    switch (parseInt(values['ECTYPE'])) {
      case 100:
        values['EDESC'] = this.getMessageText('33152');
        break;
      case 110:
        values['EDESC'] = "Forecast Less than " + parseInt(values['ECVAL1']) + " AND Last 3 Avg. Greater than " + parseInt(values['ECVAL2']);
        break;
      case 120:
        values['EDESC'] = this.getMessageText('33154');
        break;
      case 130:
        values['EDESC'] = this.getMessageText('33155');
        break;
      case 140:
        values['EDESC'] = "MADP Greater than " + parseInt(values['ECVAL1']) + " AND Annual Sls Greater than $" + parseInt(values['ECVAL2']);
        break;
      case 150:
        values['EDESC'] = this.getMessageText('33157');
        break;
      case 160:
        values['EDESC'] = this.getMessageText('33158');
        break;
      case 170:
        values['EDESC'] = "Service Level Goal Greater than or Equal to " + parseInt(values['ECVAL1']) + " Percent";
        break;
      case 180:
        values['EDESC'] = "Service Level Goal Greater than or Equal to " + parseInt(values['ECVAL1']) + " Percent";
        break;
      case 200:
        values['EDESC'] = "Demand Forecast > " + parseInt(values['ECVAL1']) + " AND Act Demand is " + parseInt(values['ECVAL2']) + " % > Forecast Demand";
        break;
      case 210:
        values['EDESC'] = "Demand Forecast > " + parseInt(values['ECVAL1']) + " AND Act Demand is " + parseInt(values['ECVAL2']) + " % < Forecast Demand";
        break;
      case 220:
        values['EDESC'] = "3 pd Demand Forecast > " + parseInt(values['ECVAL1']) + " AND 3 pd Act Demand is " + parseInt(values['ECVAL2']) + " % > Forecast Demand";
        break;
      case 230:
        values['EDESC'] = "3 pd Demand Forecast > " + parseInt(values['ECVAL1']) + " AND 3 pd Act Demand is " + parseInt(values['ECVAL2']) + " % < Forecast Demand";
        break;
      case 250:
        values['EDESC'] = "Order Cycle Exceptions > " + parseInt(values['ECVAL1']) + " days difference or > " + parseInt(values['ECVAL2']) + " % profit difference";
        break;
      case 260:
        values['EDESC'] = "Order Cycle Exceptions > " + parseInt(values['ECVAL1']) + " days difference or > " + parseInt(values['ECVAL2']) + " % profit difference";
        break;
    }
    
    const rowData = this.state.rows;
    for (const key in rowData) {
      if (key === rowNumberSelected) {
        rowData[key] = values;
      }
    }
    this.setState({
      rows: [...this.state.rows, rowData],
      rowNumberSelected: 0,
      selected: false,
    });
    this.props.processModifyExceptionData(values);
    this.handleSendDetailDataValue(true);
  };

  getSortOrder = (prop) => {
    return function (a, b) {
      if (a[prop] > b[prop]) {
        return 1;
      } else if (a[prop] < b[prop]) {
        return -1;
      }
      return 0;
    }
  }

  onAddRow = values => {
    values['ECTYPE'] = values.EXTYPE;
    values['ECLANG'] = this.state.selectedData.ECLANG;
    values['ECRECD'] = this.state.selectedData.ECRECD;
    values['ECVAL3'] = this.state.selectedData.ECVAL3;
    values['ECVAL4'] = this.state.selectedData.ECVAL4;
    values['ECATG'] = this.state.selectedData.ECATG;
    let value1 = values['ECVAL1'].trim() == "" ? 0 : Math.round(parseFloat(values['ECVAL1'])); //E3C-33340, 12/7/21, Kumar
    let value2 = values['ECVAL2'].trim() == "" ? 0 : Math.round(parseFloat(values['ECVAL2'])); //E3C-33340, 12/7/21, Kumar
    value1 = value1.toFixed(1).toString();
    value2 = value2.toFixed(1).toString();
    values['ECVAL1'] = value1;
    values['ECVAL2'] = value2;

    const warehouseList = this.props.warehouseDataList;
    const warehouseMList = warehouseList.listArray;
    let warehouseExist = false;
    for (let key in warehouseMList) {
      if (values.ECWHSE.trim() == warehouseMList[key]['WWHSE'].trim()) {
        warehouseExist = true;
        break;
      }
    }

    switch (parseInt(values['ECTYPE'])) {
      case 100:
        values['EDESC'] = this.getMessageText('33152');
        break;
      case 110:
        values['EDESC'] = "Forecast Less than " + parseInt(values['ECVAL1']) + " AND Last 3 Avg. Greater than " + parseInt(values['ECVAL2']);
        break;
      case 120:
        values['EDESC'] = this.getMessageText('33154');
        break;
      case 130:
        values['EDESC'] = this.getMessageText('35313');
        break;
      case 140:
        values['EDESC'] = "MADP Greater than " + parseInt(values['ECVAL1']) + " AND Annual Sls Greater than $" + parseInt(values['ECVAL2']);
        break;
      case 150:
        values['EDESC'] = this.getMessageText('35315');
        break;
      case 160:
        values['EDESC'] = this.getMessageText('35316');
        break;
      case 170:
        values['EDESC'] = "Service Level Goal Greater than or Equal to " + parseInt(values['ECVAL1']) + " Percent";
        break;
      case 180:
        values['EDESC'] = "Service Level Goal Greater than or Equal to " + parseInt(values['ECVAL1']) + " Percent";
        break;
      case 200:
        values['EDESC'] = "Demand Forecast > " + parseInt(values['ECVAL1']) + " AND Act Demand is " + parseInt(values['ECVAL2']) + " % > Forecast Demand";
        break;
      case 210:
        values['EDESC'] = "Demand Forecast > " + parseInt(values['ECVAL1']) + " AND Act Demand is " + parseInt(values['ECVAL2']) + " % < Forecast Demand";
        break;
      case 220:
        values['EDESC'] = "3 pd Demand Forecast > " + parseInt(values['ECVAL1']) + " AND 3 pd Act Demand is " + parseInt(values['ECVAL2']) + " % > Forecast Demand";
        break;
      case 230:
        values['EDESC'] = "3 pd Demand Forecast > " + parseInt(values['ECVAL1']) + " AND 3 pd Act Demand is " + parseInt(values['ECVAL2']) + " % < Forecast Demand";
        break;
      case 250:
        values['EDESC'] = "Order Cycle Exceptions > " + parseInt(values['ECVAL1']) + " days difference or > " + parseInt(values['ECVAL2']) + " % profit difference";
        break;
      case 260:
        values['EDESC'] = "Order Cycle Exceptions > " + parseInt(values['ECVAL1']) + " days difference or > " + parseInt(values['ECVAL2']) + " % profit difference";
        break;
    }
    delete values['EXTYPE'];
    delete values['undefinedVAL1'];
    delete values['undefinedVAL2'];
    delete values['undefinedWHSE'];
    if (!warehouseExist) {
      this.setState({ hasError: true })
      this.setState({ errorId: '14331' })
      this.setState({ parameterValues: [values.ECWHSE.trim()] })
    } else {
      values = this.formatObject(values);
      let newSortedData = this.state.rows.concat(values);
      newSortedData.sort(function (a, b) {
        return a.ECTYPE - b.ECTYPE;
      });
      this.setState({
        rows: newSortedData,
        selected: false,
      });
      this.props.processAddExceptionData({ values });
      this.handleSendDataValue(true);
    }
  };

  onDeleteRow = () => {
    const sendDeleteData = this.state.selectedData;
    var newArr = this.state.rows.filter(function (a) {
      return a.ECWHSE != sendDeleteData.ECWHSE;
    });
    this.setState({
      rows: newArr
    });
    this.props.processModifyExceptionDeleteData({ sendDeleteData });
  };

  handleClose = () => {
    this.setState({
      open: false
    });
  };

  handleOpen1 = () => {
    this.setState({
      open1: true,
    });
  };

  handleClose1 = () => {
    this.setState({
      open1: false
    });
  };

  getLabelValue(id) {
    return <FormattedMessageComponent id={id} />;
  }

  setIsOpenActionsContextMenu = event => {
    this.setState({ isOpenActionsContextMenu: Boolean(event) });
    this.setState({ menuRef: event.currentTarget ? event.currentTarget : event });
  };

  componentDidMount() {
    this.setState({ rows: this.props.companyExceptionMaintenanceListData })
  }

  componentDidUpdate(prevProps) {
    if (this.state.selected) {
      this.state.menuList[0]['isDisable'] = false;
      if (this.state.selectedData.ECTYPE == '110' ||
        this.state.selectedData.ECTYPE == '140' ||
        this.state.selectedData.ECTYPE == '170' ||
        this.state.selectedData.ECTYPE == '180' ||
        this.state.selectedData.ECTYPE == '200' ||
        this.state.selectedData.ECTYPE == '210' ||
        this.state.selectedData.ECTYPE == '220' ||
        this.state.selectedData.ECTYPE == '230' ||
        this.state.selectedData.ECTYPE == '260') {
        this.state.menuList[1]['isDisable'] = false;
      } else {
        this.state.menuList[1]['isDisable'] = true;
      }
      if (this.state.selectedData.ECWHSE.trim() != '') {
        this.state.menuList[2]['isDisable'] = false;
      } else {
        this.state.menuList[2]['isDisable'] = true;
      }

    } else {
      this.state.menuList[0]['isDisable'] = true;
      this.state.menuList[1]['isDisable'] = true;
      this.state.menuList[2]['isDisable'] = true;
    }
  }

  handleActionSelection = action => {
    switch (action) {
      case "expDetail":
        let rowsDetailData = this.state.selectedData;
        rowsDetailData['EXTYPE'] = this.state.selectedData.ECTYPE;
        this.setState({ rowsDetailData: rowsDetailData });
        this.handleSendDetailDataValue(false);
        break;
      case "expAdd":
        let rowsData = ADD_EXCEPTION;
        rowsData['EXTYPE'] = this.state.selectedData.ECTYPE;
        rowsData['ECSTS'] = "1";
        this.setState({ rowsData: rowsData });
        this.handleSendDataValue(false);
        break;
      case "expRemove":
        this.onDeleteRow();
        break;
    }
  };

  handleSendDataValue = openClose => {
    this.setState({ open1: openClose });
  };

  handleSendDetailDataValue = openClose => {
    this.setState({ open: openClose });
  };

  handleChangeValue = (key, value, field) => {
    if (field.FDPRFX == '0') {
      if (key.includes("undefined")) {
        key = key.replace("undefined", "");
      }
      key = 'EC' + key;
    }
    let temp = { ...this.state.rowsData, [key]: value }
    this.setState({ rowsData: temp });
    if (key == 'ECWHSE') {
      if (value.trim() == '') {
        this.setState({ disableSubmit: true })
      } else {
        this.setState({ disableSubmit: false })
      }
    }
  }

  handleChangeDetailValue = (key, value, field) => {
    if (field.FDPRFX == '0') {
      if (key.includes("undefined")) {
        key = key.replace("undefined", "");
      }
      key = 'EC' + key;
    }
    let temp = { ...this.state.rowsDetailData, [key]: value }
    this.setState({ rowsDetailData: temp });
    this.setState({ disableDetailSubmit: false })
  }

  sethaserror = val => {
    this.setState({ hasError: val });
  }

  getMessageText = id => {
    const { messages } = this.props;
    if (messages && messages['H' + id]) {
      return messages['H' + id].TLLAB;
    }
    else return '';
  }

  render() {
    const { rows, rowNumberSelected } = this.state;
    const COMPANY_ID = this.getLabelValue(
      LABEL_COMPANY_CI,
    );
    const columnDefs = [
      {
        headerName: this.getMessageText('35136'), field: "ECCOMP", width: 80, cellStyle: { fontFamily: 'Roboto', fontSize: '12px', color: '#3F4756' }, editable: false
      },
      {
        headerName: this.getMessageText('34204'), field: "ECTYPE", width: 100, cellStyle: { fontFamily: 'Roboto', fontSize: '12px', color: '#3F4756' }, editable: false
      },
      {
        headerName: this.getMessageText('50608'), field: "EDESC", editable: false, cellStyle: { 'text-align': "left", fontFamily: 'Roboto', fontSize: '12px', color: '#3F4756' }, width: 450,
      },
      {
        headerName: this.getMessageText('39679'), field: "ECATG", editable: false, cellStyle: { 'text-align': "left", fontFamily: 'Roboto', fontSize: '12px', color: '#3F4756' }, width: 180,
      },
      {
        headerName: this.getMessageText('56117'), field: "ECWHSE", editable: false, border: '1px solid', cellStyle: { 'text-align': "left", fontFamily: 'Roboto', fontSize: '12px', color: '#3F4756' }, width: 100
      },
      {
        headerName: this.getMessageText('36594'), color: "red", field: "ECSTS", editable: false, cellStyle: { 'text-align': "center", fontFamily: 'Roboto', fontSize: '12px', color: '#3F4756' }, cellRendererFramework: params => {
          if (params.value === '0' || params.value === '1') {
            return <div>
              {
                <Checkbox color={"primary"} checked={params.value === '1' ? true : false} className={classes.checkboxfield} />
              }

            </div>
          } else {
            return '';
          }
        }, width: 110
      },
      {
        headerName: this.getMessageText('33625'), field: "ECVAL1", editable: false, cellStyle: { 'text-align': "left", fontFamily: 'Roboto', fontSize: '12px', color: '#3F4756' }, width: 100
      },
      {
        headerName: this.getMessageText('33626'), field: "ECVAL2", editable: false, cellStyle: { 'text-align': "left", fontFamily: 'Roboto', fontSize: '12px', color: '#3F4756' }, width: 100
      },
      {
        headerName: this.getMessageText('33627'), field: "ECVAL3", editable: false, cellStyle: { 'text-align': "left", fontFamily: 'Roboto', fontSize: '12px', color: '#3F4756' }, width: 100
      },
      {
        headerName: this.getMessageText('33628'), field: "ECVAL4", editable: false, cellStyle: { 'text-align': "left", fontFamily: 'Roboto', fontSize: '12px', color: '#3F4756' }, width: 100
      }]

    const { classes, newExceptionLabelsData, currentPage, detailExceptionLabelsData } = this.props;
    if (!this.state.open1 && newExceptionLabelsData) {
      if (this.state.rowsData.EXTYPE == '140' || this.state.rowsData.EXTYPE == '260') {
        newExceptionLabelsData.tabcards['0'].cardfields['4'].maxLength = 5;
        newExceptionLabelsData.tabcards['0'].cardfields['4'].maxValue = 9999.9;
      } else {
        newExceptionLabelsData.tabcards['0'].cardfields['4'].maxLength = 4;
        newExceptionLabelsData.tabcards['0'].cardfields['4'].maxValue = 999.9;
      }
    }
    if (!this.state.open && detailExceptionLabelsData) {
      if (this.state.selectedData.EXTYPE == '140' || this.state.selectedData.EXTYPE == '260') {
        detailExceptionLabelsData.tabcards['0'].cardfields['4'].maxLength = 5;
        detailExceptionLabelsData.tabcards['0'].cardfields['4'].maxValue = 9999.9;
      } else {
        detailExceptionLabelsData.tabcards['0'].cardfields['4'].maxLength = 4;
        detailExceptionLabelsData.tabcards['0'].cardfields['4'].maxValue = 999.9;
      }
    }
    return (
      <div className={classes.pageContainer}>
        {(this.state.hasError) ? <div>
          <GridErrorMessages
            errorMessageLabels={this.props.errorMessageLabels}
            popUp
            sethaserror={this.sethaserror}
            replaceValues={this.state.parameterValues}
            id={this.state.errorId ? this.state.errorId : this.props.ServerError}
          />
        </div> : ''}
        <Grid container spacing={0}>
          <Grid item xs={12} >
            <div style={{ padding: 0 }}>
              <div className={classes.root}>
                <Card className={classes.card}>
                  <Box className={classes.contextMenu}>
                    <div
                      onMouseEnter={(event) => this.setIsOpenActionsContextMenu(event)}
                      onMouseLeave={(event) => this.setIsOpenActionsContextMenu(false)}>
                      <MoreVertIcon color="primary" className="cPointer"></MoreVertIcon>
                      <ContextMenu
                        className={classes.ActionsContextMenu}
                        menuList={this.state.menuList}
                        isOpen={this.state.isOpenActionsContextMenu}
                        menuRef={this.state.menuRef}
                        handleItemSelection={(val) => this.handleActionSelection(val)}
                        handleMenuClose={(val) => this.setIsOpenActionsContextMenu(val)}>
                      </ContextMenu>
                    </div>
                  </Box>
                  {rows && <TableGrid
                    className={classes.table}
                    columnDefs={columnDefs}
                    rowSlectionCustom={this.props.canUpdateComponent && this.props.canUpdateComponent.update == false ? 'none' : 'single'}
                    handleSendData={this.handleSendData}
                    handleSendSelectedRow={this.handleSendSelectedRow}
                    rowData={rows}
                    disableColumns={this.props.canUpdateComponent && this.props.canUpdateComponent.update == true ? false : true}
                    style={{ height: '500px' }} />}
                </Card>
                {!this.state.open1 && newExceptionLabelsData &&
                  <NewExceptionsType
                    fieldData={newExceptionLabelsData.tabcards}
                    valueForm={this.state.rowsData}
                    currentPage={currentPage}
                    handleChangeValue={this.handleChangeValue}
                    handleDialogClose={(value) => this.handleSendDataValue(value)}
                    disableSubmit={this.state.disableSubmit}
                    onExceptionSubmit={this.onAddRow}
                  />
                }
                {!this.state.open && detailExceptionLabelsData &&
                  <ExceptionsTypeDetail
                    fieldData={detailExceptionLabelsData.tabcards}
                    valueForm={this.state.rowsDetailData}
                    currentPage={currentPage}
                    handleChangeValue={this.handleChangeDetailValue}
                    handleDialogClose={(value) => this.handleSendDetailDataValue(value)}
                    disableSubmit={this.state.disableDetailSubmit}
                    onExceptionSubmit={() => this.processModifyData(this.state.rowsDetailData, rowNumberSelected)}
                  />
                }
              </div>
            </div>
          </Grid>
        </Grid>
      </div>
    )
  }
}

export default withStyles(styles)(ExceptionsMaintenance);

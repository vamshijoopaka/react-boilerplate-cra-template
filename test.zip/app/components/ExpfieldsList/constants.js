import {
    COLUMN_HEADER_ACCESSOR, 
    COLUMN_VALUE_ACCESSOR,
    COLUMN_SHOW_HIDE_FLAG,
    COLUMN_POSITION,
    COLUMN_HEADER_PREFIX_FLAG
} from '../common/constants';


export const DEFAULT_ACTION = 'app/ExpfieldsListPage/DEFAULT_ACTION';
export const LOAD_EXPFIELDS = 'app/ExpfieldsListPage/LOAD_EXPFIELDS';
export const LOAD_EXPFIELDS_ERROR = 'app/ExpfieldsListPage/LOAD_EXPFIELDS_ERROR';
export const LOAD_EXPFIELDS_SUCCESS = 'app/ExpfieldsListPage/LOAD_EXPFIELDS_SUCCESS';
export const LOAD_EXPFIELDS_COUNT = 'app/ExpfieldsListPage/LOAD_EXPFIELDS_COUNT';
export const LOAD_EXPFIELDS_COUNT_ERROR = 'app/ExpfieldsListPage/LOAD_EXPFIELDS_COUNT_ERROR';
export const LOAD_EXPFIELDS_COUNT_SUCCESS = 'app/ExpfieldsListPage/LOAD_EXPFIELDS_COUNT_SUCCESS';
export const SET_SEARCHPROPS = 'app/ExpfieldsListPage/SET_SEARCHPROPS';
export const SET_SORTPROPS = 'app/ExpfieldsListPage/SET_SORTPROPS';
export const SET_FILTERID = 'app/ExpfieldsListPage/SET_FILTERID';
export const SET_ADVANCED_FILTERS = 'app/ExpfieldsListPage/SET_ADVANCED_FILTERS';
export const SET_FILTERPROPS = 'app/ExpfieldsListPage/SET_FILTERPROPS';
export const SET_PAGEPROPS = 'app/ExpfieldsListPage/SET_PAGEPROPS';
export const SET_PROPERTIESPROPS = 'app/ExpfieldsListPage/SET_PROPERTIESPROPS';
export const SET_EXPFIELD_COLUMN_DEF = 'app/ExpfieldsListPage/SET_EXPFIELD_COLUMN_DEF';
export const LOAD_HEADER = 'app/LOAD_HEADER';
export const GET_EXPFIELD_COLUMN_DEF = 'app/ExpfieldsListPage/GET_EXPFIELD_COLUMN_DEF';

export const EXPFIELD_COLUMN_HEADER_ACCESSOR = "TLLAB";
export const EXPFIELD_COLUMN_VALUE_ACCESSOR = "FDFNAM";
export const EXPFIELD_COLUMN_POSITION = "FLDPOS";
export const EXPFIELD_COLUMN_SHOW_HIDE_FLAG = "FLDSHW"
export const EXPFIELD_COLUMN_HEADER_PREFIX_FLAG = "FDPRFX";

export const EXPFIELD_PROPERTIES = {
    "headerName": COLUMN_HEADER_ACCESSOR,
    "field": COLUMN_VALUE_ACCESSOR,
    "showHideFlag": COLUMN_SHOW_HIDE_FLAG,
    "columnPosition": COLUMN_POSITION,
    "prefixFlag": COLUMN_HEADER_PREFIX_FLAG
}

export const PAGE_SIZES = [10, 20, 30];

export const EXPFIELD_LIST_PAGE = "expfieldsListPage";

export const SET_EXPFIELD_GLOBAL_FILTER_PROPS = "SET_EXPFIELD_GLOBAL_FILTER_PROPS";

export const INITIAL_PAGE_PROPS = {
    actualPage: 0,
    currentPage: 0,
    totalCount: 10,
    actualPageSize: 10,
    pageSize: 100,
    isPageSizeChanged: false,
    isForwardDirection: true
}

export const HAS_PAGINATION = true;
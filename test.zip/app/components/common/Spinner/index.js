/**
 * Copyright © 2018, JDA Software Group, Inc. ALL RIGHTS RESERVED.
 * <p>
 * This software is the confidential information of JDA Software, Inc., and is licensed
 * as restricted rights software. The use,reproduction, or disclosure of this software
 * is subject to restrictions set forth in your license agreement with JDA.
 */
/**
*
* Spinner
*
*/

import React from 'react';
import PropTypes from 'prop-types';
import SpinnerKit from 'react-spinkit';
import styled from '@emotion/styled';
// import ListWrapper from 'components/Common/ListPage';

const SpinnerContainer = styled.div((props) => ({
  display: 'flex',
  alignItems: 'center',
  zIndex: 9999,
  backgroundColor: 'rgba(0,0,0,0.5)',
  position: 'fixed',
  top: 0,
  left: 0,
  width: '100%',
  height: '100%',
  '& .ball-spin-fade-loader': {
    position: 'absolute',
    left: '49%',
    top: '46%',
  },
  // position: props.type === 'notesPanel' ? 'absolute' : 'relative',
  //justifyContent: props.type !== 'panel' && props.type !== 'notesPanel' && 'center',
  //height: (props.type === 'panelDetail' && '50px') || (props.type === 'panel' && 'calc(100vh - 100px)'),
  //// eslint-disable-next-line no-nested-ternary
  //top: props.type === 'panelDetail' ? '-50px' : (props.type === 'notesPanel' ? '50%' : 150),
  //// eslint-disable-next-line no-nested-ternary
  //left: props.type === 'panelDetail' ? '10%' : ((props.type === 'panel' || props.type === 'notesPanel') ? '50%' : 0),
  //right: props.type !== 'panelDetail' && props.type !== 'notesPanel' && props.type === 'panel' && 0,
}));

// ({ type }) => {
//   if (type === 'panelDetail') {
//     return ({
//       justifyContent: 'center', - done
//       height: '50px', -done
//       top: '10px', -done
//       left: '50%',-done
//     });
//   } else if (type === 'panel') {
//     return ({
//       left: '50%',-done
//       height: 'calc(100vh - 100px)', -done
//     });
//   } else if (type === 'notesPanel') {
//     return ({
//       left: '50%',-done
//       top: '50%',-done
//       position: 'absolute', -done
//     });
//   }
//   return ({
//     justifyContent: 'center', -done
//     top: 150,-done
//     right: 0, -done
//     left: 0,-done
//   });
// }

// type = "panelDetail" => used for loader in detail-panel inside expandable panel. For example : Alert Detail
// type = "panel" => used for loader in panel. For example : Alerts Panel
// type = "list" => used for loader in list pages
// type = "detail" => used for loader in detail pages
// type = "undefined" => used for loader in any page
class Spinner extends React.Component { // eslint-disable-line react/prefer-stateless-function
  render() {
    const { loading, type } = this.props;
    if (!loading) return null;
    if (type === 'list' || type === 'detail') {
      return (
        // <ListWrapper>
        <SpinnerContainer type={type} id="SpinnerContainer">
          <SpinnerKit name={'ball-spin-fade-loader'} fadeIn="none" color={'white'} />
        </SpinnerContainer>
        // </ListWrapper>
      );
    }
    return (
      <SpinnerContainer type={type}>
        <SpinnerKit name={'ball-spin-fade-loader'} fadeIn="none" color={'white'} />
      </SpinnerContainer>
    );
  }
}

Spinner.propTypes = {
  loading: PropTypes.bool,
  type: PropTypes.string,
};

export default Spinner;

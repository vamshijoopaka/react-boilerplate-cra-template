import {GET_COMPANY_NOTES, GET_COMPANY_NOTES_SUCCESS, GET_COMPANY_NOTES_FAILURE, CLEAR_NOTES_DATA, GET_COMPANY_NOTE_DETAILS, GET_COMPANY_NOTE_DETAILS_SUCCESS,
    GET_COMPANY_NOTE_DETAILS_FAILURE, SET_COMPANY_SELECTED_NOTE_DETAILS, GET_COMPANY_NOTES_ALL_SUCCESS, CONTROL_COMPANY_NOTE_CREATION,
    CONTROL_COMPANY_NOTE_CREATION_SUCCESS, CONTROL_COMPANY_NOTE_CREATION_FAILURE, SET_COMPANY_NOTE_CONTROL_COUNT,
    REMOVE_COMPANY_NOTE_OF_KEY, CLEAR_COMPANY_NOTES, SET_IS_EMBEDDED_LIST, CLEAR_STATE_VALUES,
 } from './constants';

export function getCompanyNotes(data){
   return {
       type: GET_COMPANY_NOTES,
       data
   }
}
export function getCompanyNotesSuccess(data){
   return {
       type: GET_COMPANY_NOTES_SUCCESS,
       data
   }
}
export function getCompanyNotesFailure(data){
   return {
       type: GET_COMPANY_NOTES_FAILURE,
       data
   }    
}

export function clearNotesData() {
   return {
       type: CLEAR_NOTES_DATA
   }
}
export function getNoteDetails(data) {
   return {
       type: GET_COMPANY_NOTE_DETAILS,
       data
   }
}
export function getNoteDetailsSuccess(data) {
   return {
       type: GET_COMPANY_NOTE_DETAILS_SUCCESS,
       data
   }
}
export function getNoteDetailsFailure(data) {
   return {
       type: GET_COMPANY_NOTE_DETAILS_FAILURE,
       data
   }
}
export function getNoteDetailsAllSuccess(data) {
   return {
       type: GET_COMPANY_NOTES_ALL_SUCCESS,
       data
   }
}
export function setSelectedNoteDetails(data) {
   return {
       type: SET_COMPANY_SELECTED_NOTE_DETAILS,
       data
   }
}
export function controlNoteCreation(data) {
   return {
       type: CONTROL_COMPANY_NOTE_CREATION,
       data
   }
}
export function controlNoteCreationSuccess(data) {
   return {
       type: CONTROL_COMPANY_NOTE_CREATION_SUCCESS,
       data
   }
}
export function controlNoteCreationFailure(data) {
   return {
       type: CONTROL_COMPANY_NOTE_CREATION_FAILURE,
       data
   }
}
export function setControlNoteCount(data) {
   return {
       type: SET_COMPANY_NOTE_CONTROL_COUNT,
       data
   }
}
export function removeNoteByKey(data) {
   return {
       type: REMOVE_COMPANY_NOTE_OF_KEY,
       data
   }
}
export function clearAllCompanyNotes() {
   return {
       type: CLEAR_COMPANY_NOTES
   }
}

export function setIsEmbeddedList() {
   return {
       type: SET_IS_EMBEDDED_LIST
   }
}
export function clearStateValues(){
   return{
       type: CLEAR_STATE_VALUES
   }
}
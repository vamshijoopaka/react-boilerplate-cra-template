/**
 *
 * Asynchronously loads the component for EventsList
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));

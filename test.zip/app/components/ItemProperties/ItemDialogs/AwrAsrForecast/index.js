import React from 'react';
import FormattedMessageComponent from 'components/common/FormattedMessageComponent';
import { filterGridColDefs } from '../../../../containers/common/constants'
import AwrAsrForecastEmbeddedList from '../../../../containers/ItemEmbeddedListContainers/AwrAsrForecastEmbeddedList'
import { DEFAULT_AWRASR_FILTER_PROPS } from '../../constants'
import PropTypes from 'prop-types';
const propTypes = {
}

class AwrAsrForecastDialog extends React.PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            dialogOpen: props.isOpen,
            filterProps: [],
            awrasrforecastvalues: {}
        };
    }

    getLabelValue = (id) => <FormattedMessageComponent id={id} />;

    handleClose = () => {
        this.setState({ dialogOpen: false })
    }

    render() {
        let filterGridNamespace = 'awrasrFilterGrid';
        return (
            <div>
                <div>
                    {(this.props.filterableColumnsList && this.props.filterableColumnsList.length) ? (

                        <div >
                            <AwrAsrForecastEmbeddedList
                                card={this.props.card}
                                isOpen={this.props.isOpen}
                                itemData={this.props.itemData}
                                namespace={filterGridNamespace}
                                gridColumnDefs={filterGridColDefs}
                                listTitle={'ADDED FILTERS'}
                                currentPage={'items'}
                                filterProps={DEFAULT_AWRASR_FILTER_PROPS}
                                closeDialog={this.props.closeDialog}
                            />
                        </div>
                    ) : null}
                </div>
            </div>);
    }
}
AwrAsrForecastDialog.propTypes = propTypes;

export default AwrAsrForecastDialog;
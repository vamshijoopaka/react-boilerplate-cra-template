import {
    GET_FILTER_DATA, GET_KEY_CHANGE_DATA, GET_FILTERCRITERIA_DATA, GET_FILTERCRITERIA_DATA_SUCCESS, GET_FILTERCRITERIA_DATA_FAIL,
    GET_COLUMN_DEFS, GET_COLUMN_DEFS_SUCCESS, GET_COLUMN_DEFS_FAILURE, UPDATE_STATE, GET_POLINES_LIST, GET_POLINES_LIST_SUCCESS,
    GET_POLINES_LIST_FAILURE, UPDATE_SHOW_HIDE_COLUMNS, UPDATE_SHOW_HIDE_COLUMNS_SUCCESS, UPDATE_SHOW_HIDE_COLUMNS_FAILURE,
    SET_PAGE_PROPS, APPLY_CANCEL_LINES, APPLY_CANCEL_LINES_SUCCESS, APPLY_CANCEL_LINES_FAILURE
} from './constants';

export function getFilterData(data) {
    return {
        type: GET_FILTER_DATA,
        data
    }
}

export function getKeyChangeData(data) {
    return {
        type: GET_KEY_CHANGE_DATA,
        data
    }
}
export function getFilterCriteriaData(data) {
    return {
        type: GET_FILTERCRITERIA_DATA,
        data
    }
}
export function getFilterCriteriaDataSuccess(data) {
    return {
        type: GET_FILTERCRITERIA_DATA_SUCCESS,
        data
    }
}
export function getFilterCriteriaDataFailure(data) {
    return {
        type: GET_FILTERCRITERIA_DATA_FAIL,
        data
    }
}
export function getColumnDefs(data) {
    return {
        type: GET_COLUMN_DEFS,
        data
    }
}
export function getColumnDefsSuccess(data) {
    return {
        type: GET_COLUMN_DEFS_SUCCESS,
        data
    }
}
export function getColumnDefsFailure(data) {
    return {
        type: GET_COLUMN_DEFS_FAILURE,
        data
    }
}
export function updateState(data) {
    return {
        type: UPDATE_STATE,
        data
    }
}
export function getPOLinesList(data) {
    return {
        type: GET_POLINES_LIST,
        data
    }
}
export function getPOLinesListSuccess(data) {
    return {
        type: GET_POLINES_LIST_SUCCESS,
        data
    }
}
export function getPOLinesListFailure(data) {
    return {
        type: GET_POLINES_LIST_FAILURE,
        data
    }
}
export function updateShowHide(data) {
    return {
        type: UPDATE_SHOW_HIDE_COLUMNS,
        data
    }
}
export function updateShowHideSuccess(data) {
    return {
        type: UPDATE_SHOW_HIDE_COLUMNS_SUCCESS,
        data
    }
}
export function updateShowHideFailure(data) {
    return {
        type: UPDATE_SHOW_HIDE_COLUMNS_FAILURE,
        data
    }
}
export function onSetPageProps(data) {
    return {
        type: SET_PAGE_PROPS,
        data
    }
}
export function applyCancelLines(data) {
    return {
        type: APPLY_CANCEL_LINES,
        data
    }
}
export function applyCancelLinesSuccess(data) {
    return {
        type: APPLY_CANCEL_LINES_SUCCESS,
        data
    }
}
export function applyCancelLinesFailure(data) {
    return {
        type: APPLY_CANCEL_LINES_FAILURE,
        data
    }
}
export const HeaderAPIValuesJSON = [
	{
		"DHVNAME": "",//VENDOR NAME
		"DHSUBV": "", //subvendor 
		"DHVNDR": "",//VENDOR ID
		"DHWNAME": "",//WAREHOUSE NAME
		"DHWHSE": "",//WAREHOUSE ID
		"DHDEAL": "",//Deal
		"DHBRDT": "",//CreationDate
	}
];

export const BRACKET_LABEL_URL_DATA = [
    { "accessor": "TRIMBO", "operator": "=", "fieldValue": "TrimCommon", "prefixFlag": 0 },
    { "accessor": "LANGID", "operator": "=", "fieldValue": "ENG", "prefixFlag": 0 }
]

export const LABEL_LIST_URL_DATA = [
	{ "accessor": "TRIMBO", "operator": "=", "fieldValue": "TrimDealsUI", "prefixFlag": 0 },
	{ "accessor": "LANGID", "operator": "=", "fieldValue": "ENG", "prefixFlag": 0 }
]
export const DEFAULT_VALUE_URL_DATA = [
	{ "accessor": "DEAL", "operator": "=", "fieldValue": "", "prefixFlag": 0 },
	{ "accessor": "COMP", "operator": "=", "fieldValue": "", "prefixFlag": 0 },
	{ "accessor": "WHSE", "operator": "=", "fieldValue": "", "prefixFlag": 0 }
]
export const DEFAULT_VALUE_URL_DATA_VENDOR = [
    { "accessor": "COMP", "operator": "=", "fieldValue": "", "prefixFlag": 0 },
    { "accessor": "WHSE", "operator": "=", "fieldValue": "", "prefixFlag": 0 },
    { "accessor": "VNDR", "operator": "=", "fieldValue": "", "prefixFlag": 0 },
    { "accessor": "SUBV", "operator": "=", "fieldValue": "", "prefixFlag": 0 }
]
export const FILTER_DATA = ["COMP", "VNDR", "ITEM", "WHSE"];
export const BOOKING_CONTROL_FACTORS = "50861";
export const LABEL_VENDOR_ID = "34433";
export const LABEL_SUB_VENDOR_ID = "34435";
export const LABEL_VENDOR_NAME = "33989";
export const LABEL_WAREHOUSE_NAME = "36479";
export const LABEL_WAREHOUSE_ID = "33161";
export const LABEL_DEAL = "33913";
export const LABEL_DEAL_CREATION_DATE = "33031";
export const LABEL_COPY = "25212";
export const LABEL_DELETE = "25211";

export const CONTEXT_MENU_DEAL_ACTIONS = [
	{
		label: LABEL_COPY,
		key: LABEL_COPY,
		hasSubMenu: false,
		isDisable: false
	},
	{
		label: LABEL_DELETE,
		key: LABEL_DELETE,
		hasSubMenu: false,
		isDisable: false
	},
];

export const DEAL_SUMMARY_LABEL_TAB_KEY = "25328";
export const ITEM_ON_DEAL_LABEL_TAB_KEY = "25329";
export const RESTRICTIONS_CARD_KEY = "25564";
export const BILL_BACK_CARD_KEY = "25343";
export const SPECIAL_TERMS_CARD_KEY = "25189";
export const GENERAL_CARD_KEY = "25314";
export const VENDOR_PROPERTIES = 'vendorProperties';
export const LABEL_ACTIONS = '28310';
export const TEXT_YES = '6';
export const TEXT_NO = '7';

export const CONTEXT_MENU_HEADER_DEAL_ACTIONS = [
    {
        label: '25525',
        key: 'modelDeal',
        hasSubMenu: false,
        isDisable: false
    },
    {
        label: '25413',
        key: 'manageItems',
        hasSubMenu: false,
        isDisable: false
    },
	{
		label: '50685',//display name can be change to 'apply changes to SKUs...'
		key: 'applyChangestoItems',
		hasSubMenu: false,
		isDisable: false
	},
];
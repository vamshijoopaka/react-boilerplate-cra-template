import { Box, Button, withStyles, Grid, FormControlLabel } from '@material-ui/core';
import KeyboardArrowDownIcon from '@material-ui/icons/KeyboardArrowDown';
import KeyboardArrowUpIcon from '@material-ui/icons/KeyboardArrowUp';
import MoreVertIcon from '@material-ui/icons/MoreVert';
import SaveIcon from '@material-ui/icons/Save';
import PropTypes from 'prop-types';
import React from 'react';
import { injectIntl } from 'react-intl';
import { getDateFromJulian } from 'utils/util';
import CustomizedTooltip from 'components/common/CustomizedTooltip';
import FilterIcon from '../../images/icon_filter.png';
import { LABEL_NOTE } from './ItemNotes/constants';
import ContextMenu from '../common/ContextMenu';
import { getDateFormatted } from '../common/Form/dateTimeUtils';
import FormattedMessageComponent from '../common/FormattedMessageComponent';
import FormFieldsGenerator from '../common/FormFieldsGenerator';
import { Badge } from '@material-ui/core';
import { BADGE_MAX_COUNT } from 'components/common/constants';
import withFixedPosition from 'containers/common/withFixedPosition';
import {
  CONTEXT_MENU_ITEM_HEADER,
  ACTIONS_CONTEXT_MENU_ITEM_HEADER,
  KEY_ITEM_NAME,
  KEY_MFG_ID,
  KEY_SUB_VENDOR_ID,
  KEY_SUPER_ITEM_TYPE,
  KEY_UPC_CODE,
  KEY_VENDOR_ID,
  KEY_WAREHOUSE_ID,
  KEY_WAREHOUSE_NAME,
  LABEL_LAST_ORDER_DATE,
  LABEL_LAST_OS_DATE,
  LABEL_MFG_ID,
  LABEL_SUPER_ITEM_TYPE,
  LABEL_UPC_CODE,
  LABEL_VENDOR_ID,
  LABEL_SUB_VENDOR_ID,
  LABEL_VENDOR_NAME,
  LABEL_WAREHOUSE_ID,
  LABEL_WAREHOUSE_NAME,
  LABEL_ITEM,
  LABEL_ITEM_NAME,
  LABEL_AUX_DESCRIPTION,
  LABEL_ORDER_TYPE,
  LABEL_CURRENCY_MODE,
  LABEL_TRSFR_WHSE,
  LABEL_LOCAL,
  DELETE_EXCEPTION,
  ACTUAL_DAYS,
  WORK_DAYS, valueDisplayCharacters, labelDisplayCharacters //E3C-32619:Ajit
} from './constants';
import BreadcrumbContextMenu from 'components/common/BreadcrumbContextMenu';
import ContextMenuCreateNew from '../common/ContextMenuCreateNew';

import FieldInput from 'components/common/Form/FieldInput';

const defaultProps = {
  itemData: [],
  saveDisabled: true,
};

const propTypes = {
  itemData: PropTypes.array.isRequired,
  saveDisabled: PropTypes.bool.isRequired,
  handleItemHeaderFilterClick: PropTypes.func,
  handleItemHeaderSaveClick: PropTypes.func,
  handleItemHeaderLeftArrowClick: PropTypes.func,
  handleItemHeaderRightArrowClick: PropTypes.func,
  handleItemHeaderActionItemSelection: PropTypes.func,
};

const style = theme => ({
  label: {
    color: 'var(--header-label-color)',
    padding: '0px 5px 5px 10px',
    whiteSpace: 'nowrap',
    '& label': {
      fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
      whiteSpace: 'nowrap',
      width: '100%',
      display: 'inline-block',
      textOverflow: 'ellipsis',
      overflow: 'hidden',
    },
    '& span': {
      fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
      whiteSpace: 'nowrap',
      width: '100%',
      display: 'inline-block',
      textOverflow: 'ellipsis',
      overflow: 'hidden',
    },
  },
  buttonActionsSecondChild: {
    '& span': {
      fontSize: '1.23em',
    },
  },
  left: {
    width: '100%',
    display: 'block',
    float: 'left',
  },
  right: {
    float: 'right',
    width: 400,
    position: 'absolute',
    right: 10,
  },
  mfgID: {
    maxWidth: 100,
  },
  superItemType: {
    maxWidth: 120,
  },
  warehouse: {
    maxWidth: 130,
  },
  orderType: {
    maxWidth: 100,
  },
  currencyMode: {
    maxWidth: 100,
  },
  data: {
    padding: '0px 5px 20px 10px',
    '& label': {
      fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
      whiteSpace: 'nowrap',
      width: '100%',
      display: 'inline-block',
      textOverflow: 'ellipsis',
      overflow: 'hidden',
    },
  },
  vendorIdDetails: {
    width: '15ch',
    padding: '0 30px 0 0px',
    lineHeight: '1.1',
  },
  propertiesHeaderContainer: {
    width: '100%',
    marginBottom: '1.5rem',
    backgroundColor: 'var(--background-app)',
    borderRadius: '0px 0px 4px 4px',
    overflow: 'hidden',
  },
  itemContainer: {
    display: 'flex',
    // width: '90%',
    backgroundColor: 'var(--background-content)',
    fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
    alignItems: 'center',
    padding: '0 0 0 16px',
    position: 'relative',
  },
  itemDetailsWrapper: {
    display: 'flex',
    // flexDirection: 'column',
    width: '100%',
  },
  vendorDetailRow: {
    width: '100%',
    display: 'flex',
    // gridTemplateColumns: '25% 25% 25% 25%',
    padding: '16px 0 16px 0',
    alignItems: 'baseline',
  },
  vendorDetail: {
    padding: '0px 0px 0px 0px',
    lineHeight: '1.1',
  },
  vendorSubVendorDetails: {
    display: 'flex',
    flexDirection: 'column',
    width: '16ch',
    padding: '0 30px 0 0px',
    lineHeight: '1.1',
  },
  vendorDetailWarehouse: {
    gridTemplateColumns: '35% 65% !important',
  },
  vendorLabel: {
    color: 'var(--header-label-color)',
    padding: '2px 0',
  },
  vendorName: {
    paddingTop: '8px',
  },
  vendorNameLabel: {
    paddingBottom: '0',
  },
  nameField: {
    paddingTop: '32px',
  },
  vendorValue: {
    color: 'var(--value)',
    padding: '2px 0',
  },
  vendorID: {
    display: 'flex',
    width: '100%',
    justifyContent: 'flex-end',
    paddingRight: '10px',
  },
  itemNameAndArrowsBlock: {
    display: 'flex',
    justifyContent: 'space-evenly',
    alignItems: 'center',
    padding: '10px 0',
    width: '100%',
  },
  itemName: {
    '& [class*="MuiInputBase-input"]': {
      padding: 0
    },
    '& [class*="MuiInput-root"]': {
      height: 'auto'
    },
  },
  itemNameInput: {
    '& input': {
      width: '12vw',
    },
  },
  itemArrowIcon: {
    height: '16px',
    width: '12px',
    borderRadius: '4px',
    fontSize: '10px',
    backgroundColor: 'var(--background-app)',
    margin: '0 4px',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    color: 'var(--secondary-s21)',
    lineHeight: '40px',
    cursor: 'pointer',
  },
  vendorActions: {
    width: '100px',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    position: 'absolute',
    top: "3rem",
    right: '5rem',
  },
  vendorActionsFilter: {
    minWidth: '37px',
    border: '1px solid var(--primary-default)',
    height: '32px',
    marginLeft: '15px',
    // minWidth: '37px',
    padding: '10px',
    '& img': {
      width: '14px',
      height: '14px',
    },
    '& svg': {
      width: '18px',
      height: '18px',
    },
  },
  vendorActionsButton: {
    border: '1px solid var(--logo)',
    color: 'var(--logo)',
    '&:hover': {
      border: '1px solid var(--link-button)',
    },
  },
  itemArrow: {
    padding: '0 !important',
    margin: '0',
    minWidth: '16px',
    background: 'none',
    height: '16px',
    width: '16px',
  },
  itemArrowWrapper: {
    display: 'flex',
    flexDirection: 'column',
    border: '1px solid var(--primary-default)',
    borderRadius: '4px',
    justifyContent: 'center',
    alignItems: 'baseline',
    height: '38px',
    padding: '2px',
  },
  ActionsContextMenu: {
    width: '100%',
  },
  ItemReferences: {
    position: 'absolute',
    right: '3rem',
    bottom: '0px',
  },
  vendorIDBlock: {
    display: 'flex',
    // gridTemplateColumns: '32% 68%',
  },
  subVendorId: {
    marginLeft: '20px',
  },
  menuButton: {
    minWidth: '37px',
    border: '1px solid var(--primary-default)',
    height: '32px',
    marginLeft: '15px',
    borderRadius: '4px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    '@media (max-width: 1220px)': {
      marginLeft: '0px'
    },
  },
  ItemReferences: {
    position: 'absolute',
    right: '3rem',
    bottom: '0px',

    '&& .MuiBadge-root': {              //Styling for Badge
      '& .MuiBadge-badge': {
        fontSize: '0.6 rem',
        padding: '2px 5px',
        height: '13.5px',
        minWidth: props => (props.notesCountWidth || '21px'),
      }
    }
  },
  sticky: {
    width: 'calc(100% - 80px)',
    position: 'fixed',
    paddingBottom: 20,
    top: 50,
    zIndex: 10,
    backgroundColor: 'rgb(111,175,214)',
    borderRadius: 0,
    '& > div': {
      paddingTop: 20,
      backgroundColor: '#FFF',
    },
  },
  noPaddingFFG: {
    '& [class*="FormFieldsGenerator-formControl"]': {
      padding: 0
    },
  }
});

class Header extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      itemName: false,
      contextMenuList: CONTEXT_MENU_ITEM_HEADER,
      ActionsContextMenu: ACTIONS_CONTEXT_MENU_ITEM_HEADER,
      isOpenActionsContextMenu: false,
      menuRef: null,
      menuRef3dots: null,
      prevDaysAction: false,
      data: props.ItemPropertiesData.valueData,
    };
  }
  //E3C-32619:Ajit

  getLabelValue = (id) => {
    let label = this.props.getLabelFromId(id);
    return (
      <CustomizedTooltip title={label.length > labelDisplayCharacters ? label : ''}>
        < div >
          <FormattedMessageComponent id={id} />
        </ div>
      </CustomizedTooltip>)
  };
  //E3C-32619:Ajit
  handleDisableUpArrow = () => {
    const { hasPrevious, fromListPage, ItemPropertiesData: { prevNextFlagLoading = false } } = this.props;
    return !hasPrevious || !(fromListPage.includes?.('items') || fromListPage.includes?.('multitieritems')) || prevNextFlagLoading;
  };

  handleDisableDownArrow = () => {
    const { hasNext, fromListPage, ItemPropertiesData: { prevNextFlagLoading = false } } = this.props;
    return !hasNext || !(fromListPage.includes?.('items') || fromListPage.includes?.('multitieritems')) || prevNextFlagLoading;
  };

  getDateFromData = (itemData, key) => {
    let date = itemData[key];
    if (!date) {
      return '';
    }
    date = getDateFormatted(getDateFromJulian(date), this.props.globalDateFormat);//E3C-32964, J Vamshi
    return date;
  };
  setIsOpenActionsContextMenu = (evnt = false, type = '') => {
    this.setState({ ["isOpenActionsContextMenu" + type]: Boolean(evnt) });
    this.setState({ ['menuRef' + type]: evnt.currentTarget ? evnt.currentTarget : evnt });
    if (evnt) {
      let ActionsContextMenu = ACTIONS_CONTEXT_MENU_ITEM_HEADER.map(action => {
        action.isHide = (action.key == ACTUAL_DAYS || action.key == WORK_DAYS) ?
          this.props.toggleActualWorkDays(action, this.state.prevDaysAction) : false;

        // if (action.key === DELETE_EXCEPTION && this.props.activeTabData.path === "/items") { //Hidden for Items (Not Hidden for Exception Items)
        //   action.isHide = true;
        // };

        const subMenuList = {};
        if (action.hasSubMenu && action.subMenuList?.length) {
          subMenuList.subMenuList = action.subMenuList.map(ele => ({ ...ele, isDisable: this.props.isActionDisabled(ele.key) }));
        }
        return { ...action, isDisable: this.props.isActionDisabled(action.key), ...subMenuList }
      })
      this.setState({ ActionsContextMenu })
    }
  }
  setIsOpenContextMenu = (evnt = false, type = '') => {
    this.setState({ ["isOpenActionsContextMenu" + type]: Boolean(evnt) });
    this.setState({ ['menuRef' + type]: evnt.currentTarget ? evnt.currentTarget : evnt });
    if (evnt) {
      let contextMenuList = CONTEXT_MENU_ITEM_HEADER.map(action => {
        action.isHide = (action.key == ACTUAL_DAYS || action.key == WORK_DAYS) ?
          this.props.toggleActualWorkDays(action) : false;
        return { ...action, isDisable: this.props.isActionDisabled(action.key) }
      })
      this.setState({ contextMenuList })
    }
  }
  handleActionSelection = (value, type = '') => {//type= '3dots' or empty for action dropdown
    if (value == ACTUAL_DAYS || value == WORK_DAYS) {
      this.setState({ prevDaysAction: value })
    }
    this.props.handleHeaderActionItemSelection(value);
    this.setIsOpenActionsContextMenu(false);
  }

  componentDidMount() {
    this.setItemName();
  }

  setItemName = () => {
    if (this.props.itemData) {
      this.setState({ itemName: this.props.itemData[KEY_ITEM_NAME] }, () => {
        this.props.updateName(
          this.props.itemData[KEY_ITEM_NAME],
          KEY_ITEM_NAME,
        );
      });
    }
  };

  componentDidUpdate(prevProps) {
    const { itemData, canUpdateComponent } = this.props;
    if (itemData != prevProps.itemData) {
      this.setItemName();
    }
    if (!canUpdateComponent.update) {
      this.state.contextMenuList[0]['isDisable'] = true;
      this.state.contextMenuList[1]['isDisable'] = true;
      this.state.contextMenuList[2]['isDisable'] = true;
    }
  }

  onClickDownArrow = () => {
    this.props.handleItemHeaderLeftArrowClick();
  };

  onClickUpArrow = () => {
    this.props.handleItemHeaderRightArrowClick();
  };

  handleItemNameChange = val => {
    this.setState({ itemName: val });
    this.props.updateItemName(val);
  };

  getItemValue = (itemData, key) => {
    if (itemData[key]) {
      return <label>{itemData[key]}</label>;
    }
    return <label style={{ visibility: 'hidden' }}>empty</label>;
  };
  getOrderType = () => {
    const { itemPropertiesLabels, itemMiscData: { IMOTYP = false } = {} } = this.props.ItemPropertiesData;
    if (!itemPropertiesLabels?.tabcards || IMOTYP === false) return "";
    let orderTypeMeta = itemPropertiesLabels.tabcards[0].cardfields?.find(field => field.FDFILD === '4261');
    if (!orderTypeMeta) return '';
    orderTypeMeta = orderTypeMeta.valueSuggestionList;
    return orderTypeMeta.find(ele => ele.value.trim?.() === IMOTYP)?.label || "";
  }
  handleChangeValue = (key, val) => {
    this.props.setValueData({ key, val });
  }
  currencyRadioJSX = () => {
    const { currencyConversion: { MCFTOL = false, MCCRCD: currencyLabel } = false, valueData, currencySelected } = this.props.ItemPropertiesData;
    const { classes, getLabelFromId } = this.props;
    if (!valueData?.ICURCD || !MCFTOL) return null;
    const RADIO_OPTIONS = [
      {
        key: currencyLabel || valueData.ICURCD,
        fieldValue: 'foreign',
      },
      {
        key: getLabelFromId(LABEL_LOCAL) || 'Local',
        fieldValue: 'local',
      },
    ];
    return (<Box className={classes.currencyRadios}>
      <FormControlLabel
        control={<FieldInput
          options={RADIO_OPTIONS}
          value={currencySelected}
          field={{ key: 'items', type: 'radio', options: RADIO_OPTIONS }}
          onChange={(key, value) => this.props.setStoreKeyValue('currencySelected', value)}
          isHorizontal={true}
        ></FieldInput>}
        label={<FormattedMessageComponent id={LABEL_CURRENCY_MODE} />}
        labelPlacement={'start'}
      />
    </Box>)
  }
  render() {
    const {
      classes,
      itemData,
      handleItemHeaderFilterClick,
      handleItemHeaderSaveClick,
      saveDisabled,
      setSaveData,
      globalDateFormat,
      filterCriteriaDetails,
      pageFilterOptions,
      globalFilterOptions,
      columnDefs,
      currentPage,
      canUpdateComponent,
      notesCount,
      isShowContextMenu,
      onContextMenuChange,
      contextMenu,
      removeChildCutdownTab,
      selectedValue,
      freezeComponentStyle,
    } = this.props;
    const { itemMiscData: { IMWNAM: warehouseName = "" } = {},
      itemPropertiesLabels: { tabcards } = {},
      newValueData,
    } = this.props.ItemPropertiesData;
    const orderType = this.getOrderType();
    return (
      <div
        className={classes.propertiesHeaderContainer}
        id="item_properties_header"
        style={freezeComponentStyle}
      >
        {itemData && itemData.length && (
          <div className={classes.itemContainer}>
            <Box className={classes.itemDetailsWrapper}>
              <Box className={classes.itemArrowWrapper}>
                <Button
                  color="primary"
                  onClick={() => this.onClickUpArrow()}
                  className={classes.itemArrow}
                  disabled={this.handleDisableUpArrow()}
                >
                  <KeyboardArrowUpIcon />
                </Button>
                <Button
                  color="primary"
                  onClick={() => this.onClickDownArrow()}
                  className={classes.itemArrow}
                  disabled={this.handleDisableDownArrow()}
                >
                  <KeyboardArrowDownIcon />
                </Button>
              </Box>
              <Box style={{ width: '100%' }}>
                <Box className={classes.left}>
                  <Grid container>
                    <Grid item xs={12} sm={6} md={3} lg={2} xl={2}>
                      <Grid container>
                        <Grid
                          item
                          xs={6}
                          sm={6}
                          md={6}
                          lg={6}
                          xl={6}
                          className={classes.label}
                        >
                          <label>{this.getLabelValue(LABEL_VENDOR_ID)}</label>
                        </Grid>
                        <Grid
                          item
                          xs={6}
                          sm={6}
                          md={6}
                          lg={6}
                          xl={6}
                          className={classes.label}
                        >
                          <label>{this.getLabelValue(LABEL_SUB_VENDOR_ID)}</label>
                        </Grid>
                        <Grid
                          item
                          xs={6}
                          sm={6}
                          md={6}
                          lg={6}
                          xl={6}
                          className={classes.data}
                        >
                          <CustomizedTooltip title={(itemData[0].IVNDR?.length) > valueDisplayCharacters ? itemData[0].IVNDR : ''}>
                            <label>{itemData[0].IVNDR}</label>
                          </CustomizedTooltip>
                        </Grid>
                        <Grid
                          item
                          xs={6}
                          sm={6}
                          md={6}
                          lg={6}
                          xl={6}
                          className={classes.data}
                        >
                          <CustomizedTooltip title={(itemData[0].ISUBV?.length) > valueDisplayCharacters ? itemData[0].ISUBV : ''}>
                            <label>{itemData[0].ISUBV}</label>
                          </CustomizedTooltip>
                        </Grid>
                        <Grid
                          item
                          xs={12}
                          sm={12}
                          md={12}
                          lg={12}
                          xl={12}
                          className={classes.label}
                        >
                          <label>{this.getLabelValue(LABEL_VENDOR_NAME)}</label>
                        </Grid>
                        <Grid
                          item
                          xs={12}
                          sm={12}
                          md={12}
                          lg={12}
                          xl={12}
                          className={classes.data}
                        >
                          <CustomizedTooltip title={(itemData[0].VNAME?.length) > valueDisplayCharacters ? itemData[0].VNAME : ''}>
                            <label>{itemData[0].VNAME}</label>
                          </CustomizedTooltip>
                        </Grid>
                      </Grid>
                    </Grid>
                    <Grid item xs={12} sm={6} md={6} lg={3} xl={2}>
                      <Grid container>
                        <Grid
                          item
                          xs={12}
                          sm={7}
                          md={7}
                          lg={7}
                          xl={7}
                          className={classes.label}
                        >
                          <label>{this.getLabelValue(LABEL_ITEM)}</label>
                        </Grid>
                        <Grid
                          item
                          xs={12}
                          sm={5}
                          md={5}
                          lg={5}
                          xl={5}
                          className={classes.label}
                        >
                          <label>
                            {this.getLabelValue(LABEL_SUPER_ITEM_TYPE)}
                          </label>
                        </Grid>
                        <Grid
                          item
                          xs={12}
                          sm={7}
                          md={7}
                          lg={7}
                          xl={7}
                          className={classes.data}
                        >
                          <CustomizedTooltip title={(itemData[0].IITEM?.length) > valueDisplayCharacters ? itemData[0].IITEM : ''}>
                            <label>{itemData[0].IITEM}</label>
                          </CustomizedTooltip>
                        </Grid>
                        <Grid
                          item
                          xs={12}
                          sm={5}
                          md={5}
                          lg={5}
                          xl={5}
                          className={classes.data}
                        >
                          {!['U', 'R', 'B', 'P', 'C', 'O'].includes(itemData[0].ISUPER) ? (
                            <label style={{ visibility: 'hidden' }}>
                              {'empty'}
                            </label>
                          ) : (
                            <label /* style={{ visibility: 'hidden' }} */>
                              {
                                itemData[0].ISUPER == 'U' ? "U - Superseded" :
                                  (itemData[0].ISUPER == 'R' ? "R - Replacement" :
                                    (itemData[0].ISUPER == 'B' ? "B - Sub-Item" :
                                      (itemData[0].ISUPER == 'P' ? "P - Parent" :
                                        (itemData[0].ISUPER == 'C' ? "C - Consists Of" :
                                          (itemData[0].ISUPER == 'O' ? "O - Part Of" : '')))))
                              }
                            </label>
                          )
                          }
                        </Grid>
                        <Grid
                          item
                          xs={12}
                          sm={7}
                          md={7}
                          lg={7}
                          xl={7}
                          className={classes.label}
                        >
                          <label>{this.getLabelValue(LABEL_ITEM_NAME)}</label>
                        </Grid>
                        <Grid
                          item
                          xs={12}
                          sm={5}
                          md={5}
                          lg={5}
                          xl={5}
                          className={classes.label}
                        >
                          <label>
                            {this.getLabelValue(LABEL_AUX_DESCRIPTION)}
                          </label>
                        </Grid>
                        <Grid
                          item
                          xs={12}
                          sm={7}
                          md={7}
                          lg={7}
                          xl={7}
                          className={classes.data}
                        >
                          {tabcards?.[0]?.cardfields.map(field => {
                            if (field.FDFILD === '3990')
                              return <div className={classes.noPaddingFFG}>
                                <FormFieldsGenerator
                                  handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                                  parentPage={currentPage}
                                  className={classes.itemName}
                                  fieldsArray={[field]}
                                  valuesArray={newValueData}
                                  handleChangeValue={this.handleChangeValue}
                                  enableAddButton={setSaveData}
                                  globalDateFormat={globalDateFormat}
                                  filterCriteriaDetails={filterCriteriaDetails}
                                  pageFilterOptions={pageFilterOptions}
                                  globalFilterOptions={globalFilterOptions}
                                  columnDefs={columnDefs}
                                  currentPage={currentPage}
                                  parentData={newValueData}
                                  labelDisplayCharacters={10}
                                  valueDisplayCharacters={20}
                                  canUpdateComponent={canUpdateComponent}
                                  hideLabels
                                  isHeader
                                />
                              </div>
                          })
                          }
                        </Grid>
                        <Grid
                          item
                          xs={12}
                          sm={5}
                          md={5}
                          lg={5}
                          xl={5}
                          className={classes.data}
                        >
                          {tabcards?.[0]?.cardfields.map(field => {
                            if (field.FDFILD === '7238')
                              return <div className={classes.noPaddingFFG}>
                                <FormFieldsGenerator
                                  className={classes.itemName}
                                  fieldsArray={[field]}
                                  valuesArray={newValueData}
                                  handleChangeValue={this.handleChangeValue}
                                  enableAddButton={setSaveData}
                                  currentPage={currentPage}
                                  valueDisplayCharacters={13.5}
                                  canUpdateComponent={canUpdateComponent}
                                  hideLabels
                                />
                              </div>
                          })
                          }
                        </Grid>
                      </Grid>
                    </Grid>
                    <Grid
                      item
                      xs={12}
                      sm={6}
                      md={3}
                      lg={2}
                      xl={1}
                      className={classes.warehouse}
                    >
                      <Grid container>
                        <Grid
                          item
                          xs={12}
                          sm={12}
                          md={12}
                          lg={12}
                          xl={12}
                          className={classes.label}
                        >
                          <label>{this.getLabelValue(LABEL_WAREHOUSE_ID)}</label>
                        </Grid>
                        <Grid
                          item
                          xs={12}
                          sm={12}
                          md={12}
                          lg={12}
                          xl={12}
                          className={classes.data}
                        >
                          <CustomizedTooltip title={(itemData[0].IWHSE?.length) > valueDisplayCharacters ? itemData[0].IWHSE : ''}>
                            <label>{itemData[0].IWHSE}</label>
                          </CustomizedTooltip>
                        </Grid>
                        <Grid
                          item
                          xs={12}
                          sm={12}
                          md={12}
                          lg={12}
                          xl={12}
                          className={classes.label}
                        >
                          <label>
                            {this.getLabelValue(LABEL_WAREHOUSE_NAME)}
                          </label>
                        </Grid>
                        <Grid
                          item
                          xs={12}
                          sm={12}
                          md={12}
                          lg={12}
                          xl={12}
                          className={classes.data}
                        >
                          <CustomizedTooltip title={(warehouseName?.length) > valueDisplayCharacters ? warehouseName : ''}>
                            <label>{warehouseName}</label>
                          </CustomizedTooltip>
                        </Grid>
                      </Grid>
                    </Grid>
                    <Grid
                      item
                      xs={12}
                      sm={6}
                      md={3}
                      lg={2}
                      xl={1}
                      className={classes.orderType}
                    >
                      <Grid container>
                        <Grid
                          item
                          xs={12}
                          sm={12}
                          md={12}
                          lg={12}
                          xl={12}
                          className={classes.label}
                        >
                          <label>{this.getLabelValue(LABEL_ORDER_TYPE)}</label>
                        </Grid>
                        <Grid
                          item
                          xs={12}
                          sm={12}
                          md={12}
                          lg={12}
                          xl={12}
                          className={classes.data}
                        >
                          <CustomizedTooltip title={(orderType?.length) > valueDisplayCharacters ? orderType : ''}>
                            <label>
                              {orderType}
                            </label>
                          </CustomizedTooltip>
                        </Grid>
                        <Grid
                          item
                          xs={12}
                          sm={12}
                          md={12}
                          lg={12}
                          xl={12}
                          className={classes.label}
                        >
                          <label>
                            {this.getLabelValue(LABEL_LAST_ORDER_DATE)}
                          </label>
                        </Grid>
                        <Grid
                          item
                          xs={12}
                          sm={12}
                          md={12}
                          lg={12}
                          xl={12}
                          className={classes.data}
                        >
                          <label>
                            {this.getDateFromData(itemData[0], 'ILSODT')}
                          </label>
                        </Grid>
                      </Grid>
                    </Grid>
                    <Grid
                      item
                      xs={12}
                      sm={6}
                      md={6}
                      lg={2}
                      xl={2}
                      className={classes.superItemType}
                    >
                      <Grid container>
                        <Grid
                          item
                          xs={12}
                          sm={12}
                          md={12}
                          lg={12}
                          xl={12}
                          className={classes.label}
                        >
                          <label style={{ visibility: 'hidden' }}>
                            {'empty'}
                          </label>
                        </Grid>
                        <Grid
                          item
                          xs={12}
                          sm={12}
                          md={12}
                          lg={12}
                          xl={12}
                          className={classes.data}
                        >
                          <label
                            style={{ visibility: 'hidden', marginBottom: 6 }}
                          >
                            {'empty'}
                          </label>
                        </Grid>
                        <Grid
                          item
                          xs={12}
                          sm={12}
                          md={12}
                          lg={12}
                          xl={12}
                          className={classes.label}
                        >
                          <label>{this.getLabelValue(LABEL_LAST_OS_DATE)}</label>
                        </Grid>
                        <Grid
                          item
                          xs={12}
                          sm={12}
                          md={12}
                          lg={12}
                          xl={12}
                          className={classes.data}
                        >
                          <label>
                            {this.getDateFromData(itemData[0], 'IOPCDT')}
                          </label>
                        </Grid>
                      </Grid>
                    </Grid>
                    <Grid
                      item
                      xs={12}
                      sm={6}
                      md={3}
                      lg={1}
                      xl={1}
                      className={classes.mfgID}
                    >
                      <Grid container>
                        <Grid
                          item
                          xs={12}
                          sm={12}
                          md={12}
                          lg={12}
                          xl={12}
                          className={classes.label}
                        >
                          <label style={{ visibility: 'hidden' }}>
                            {'empty'}
                          </label>
                        </Grid>
                        <Grid
                          item
                          xs={12}
                          sm={12}
                          md={12}
                          lg={12}
                          xl={12}
                          className={classes.data}
                        >
                          <label style={{ visibility: 'hidden', marginBottom: 6 }}>
                            {'empty'}
                          </label>
                        </Grid>
                        <Grid
                          item
                          xs={12}
                          sm={12}
                          md={12}
                          lg={12}
                          xl={12}
                          className={classes.label}
                        >
                          <label>{this.getLabelValue(LABEL_MFG_ID)}</label>
                        </Grid>
                        <Grid
                          item
                          xs={12}
                          sm={12}
                          md={12}
                          lg={12}
                          xl={12}
                          className={classes.data}
                        >
                          <label>
                            <CustomizedTooltip title={(itemData[0]['IMFGID']?.length) > valueDisplayCharacters ? itemData[0]['IMFGID'] : ''}>
                              <div>{itemData[0]['IMFGID']}</div>
                            </CustomizedTooltip>
                          </label>
                        </Grid>
                      </Grid>
                    </Grid>
                    <Grid
                      item
                      xs={12}
                      sm={6}
                      md={3}
                      lg={2}
                      xl={1}
                      className={classes.currencyMode}
                    >
                      <Grid container>
                        <Grid
                          item
                          xs={12}
                          sm={12}
                          md={12}
                          lg={12}
                          xl={12}
                          className={classes.label}
                        >
                          <label style={{ visibility: 'hidden' }}>
                            {'empty'}
                          </label>
                        </Grid>
                        <Grid
                          item
                          xs={12}
                          sm={12}
                          md={12}
                          lg={12}
                          xl={12}
                          className={classes.data}
                        >
                          <label style={{ visibility: 'hidden', marginBottom: 6 }}>
                            {'empty'}
                          </label>
                        </Grid>
                        <Grid
                          item
                          xs={12}
                          sm={12}
                          md={12}
                          lg={12}
                          xl={12}
                          className={classes.label}
                        >
                          <label>{this.getLabelValue(LABEL_UPC_CODE)}</label>
                        </Grid>
                        <Grid
                          item
                          xs={12}
                          sm={12}
                          md={12}
                          lg={12}
                          xl={12}
                          className={classes.data}
                        >
                          <label>
                            <CustomizedTooltip title={(itemData[0]['IUPC#']?.length) > valueDisplayCharacters ? itemData[0]['IUPC#'] : ''}>
                              <div>{itemData[0]['IUPC#']}</div>
                            </CustomizedTooltip>
                          </label>
                        </Grid>
                      </Grid>
                    </Grid>
                    <Grid item xs={12} sm={6} md={2} lg={1} xl={1}>
                      <Grid container>
                        <Grid
                          item
                          xs={12}
                          sm={12}
                          md={12}
                          lg={12}
                          xl={12}
                          className={classes.label}
                        >
                          <label style={{ visibility: 'hidden' }}>
                            {'empty'}
                          </label>
                        </Grid>
                        <Grid
                          item
                          xs={12}
                          sm={12}
                          md={12}
                          lg={12}
                          xl={12}
                          className={classes.data}
                        >
                          <label style={{ visibility: 'hidden', marginBottom: 6 }}>
                            {'empty'}
                          </label>
                        </Grid>
                        <Grid
                          item
                          xs={12}
                          sm={12}
                          md={12}
                          lg={12}
                          xl={12}
                          className={classes.label}
                        >
                          {newValueData && newValueData.IWHXFR.trim() != "" && <label>{this.getLabelValue(LABEL_TRSFR_WHSE)} </label>}
                        </Grid>
                        <Grid
                          item
                          xs={12}
                          sm={12}
                          md={12}
                          lg={12}
                          xl={12}
                          className={classes.data}
                        >
                          <label>
                            {newValueData && newValueData.IWHXFR.trim() ? newValueData.IWHXFR : null}
                          </label>
                        </Grid>
                      </Grid>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4} lg={4} xl={4}>
                      <Grid container>
                        <Box display="flex" margin="-1rem 0 0 -6px">
                          <label>{this.currencyRadioJSX()}</label>
                        </Box>
                      </Grid>
                    </Grid>
                  </Grid>
                </Box>
                <Box className={classes.right}>
                  <Grid container>
                    <Grid item xs={12} sm={12} md={12} lg={12} xl={12}>
                      <Grid container>
                        {/* <Grid item xs={4} sm={4} md={4} lg={4} xl={4} /> */}
                        <Grid item xs={3} sm={3} md={3} lg={3} xl={3}>
                          <div className={classes.buttonActionsSecondChild}>
                            <Button
                              color="primary"
                              size="small"
                              variant="outlined"
                              className={classes.orderArrow}
                              onClick={event =>
                                this.setIsOpenActionsContextMenu(event)
                              }
                            >
                              <div>{this.getLabelValue('28310')}</div>
                              <KeyboardArrowDownIcon />
                            </Button>
                            <ContextMenu
                              className={classes.ActionsContextMenu}
                              menuList={this.state.ActionsContextMenu}
                              isOpen={this.state['isOpenActionsContextMenu']}
                              menuRef={this.state['menuRef']}
                              handleItemSelection={(val) => this.handleActionSelection(val)}
                              handleMenuClose={(val) => this.setIsOpenActionsContextMenu(val)}
                            />
                          </div>
                        </Grid>
                        <Grid item xs={4} sm={4} md={4} lg={4} xl={4} style={{ paddingLeft: 18 }}>
                          <div className={isShowContextMenu || true ? 'showContextMenu' : 'hideContextMenu'}>
                            <BreadcrumbContextMenu
                              onOptionChange={(e, val) => onContextMenuChange(e, val)} menuItems={contextMenu}
                              removeChildCutdownTab={removeChildCutdownTab}
                              selectedValue={selectedValue} />
                          </div>
                        </Grid>
                        <Grid item xs={2} sm={2} md={2} lg={2} xl={2}>
                          <Button
                            component="div"
                            color="primary"
                            onClick={handleItemHeaderFilterClick}
                            className={classes.vendorActionsFilter}
                          >
                            <img src={FilterIcon} alt="Filter Icon" />
                          </Button>
                        </Grid>
                        <Grid
                          item
                          xs={1}
                          sm={1}
                          md={1}
                          lg={1}
                          xl={1}
                          style={{ marginRight: 10 }}
                        >
                          <Button
                            component="div"
                            color="primary"
                            onClick={handleItemHeaderSaveClick}
                            disabled={saveDisabled}
                            className={classes.vendorActionsFilter}
                            style={{ marginLeft: 0, marginRight: 0 }}
                          >
                            <SaveIcon fontSize="large" />
                          </Button>
                        </Grid>
                        <Grid
                          item
                          xs={1}
                          sm={1}
                          md={1}
                          lg={1}
                          xl={1}
                        >
                          <Button
                            component="div"
                            color="primary"
                            className={classes.vendorActionsFilter}
                            onMouseEnter={(event) => this.setIsOpenContextMenu(event, '3dots')}
                            onMouseLeave={(event) => this.setIsOpenContextMenu(false, '3dots')}>
                            <MoreVertIcon color="primary" className="cPointer"></MoreVertIcon>
                            <ContextMenuCreateNew
                              className={classes.menuButton}
                              menuList={this.state.contextMenuList}
                              isOpen={this.state.isOpenActionsContextMenu3dots}
                              menuRef={this.state.menuRef3dots}
                              handleItemSelection={val =>
                                this.props.handleHeaderActionItemSelection(val)
                              }
                              handleMenuClose={val => this.setIsOpenContextMenu(val, '3dots')}
                              currentPage={currentPage}
                              currentRecord={this.props.ItemPropertiesData?.currentRecordData || {}}
                            />
                          </Button>

                        </Grid>
                      </Grid>
                    </Grid>
                  </Grid>
                </Box>
                <Box className={classes.ItemReferences}>
                  <Button component="div" color="primary" size="small" onClick={e => { document.getElementById("itemNotes").scrollIntoView(); }}>
                    {this.getLabelValue(LABEL_NOTE)}
                  </Button>
                  <Badge color="error" overlap="circle" anchorOrigin={{ vertical: "top", horizontal: "right" }} max={BADGE_MAX_COUNT} badgeContent={notesCount}>
                  </Badge>
                </Box>
              </Box>

            </Box>

          </div>

        )}
      </div>

    );

  }
}

Header.defaultProps = defaultProps;
Header.propTypes = propTypes;

export default injectIntl(withStyles(style)(withFixedPosition(Header)));
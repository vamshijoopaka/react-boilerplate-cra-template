import produce from 'immer';
import { fromJS } from 'immutable';

import {
	GET_BOOKINGDELETE_LIST,
	GET_BOOKINGDELETE_LIST_SUCCESS,
	GET_BOOKINGDELETE_LIST_FAILURE,
	GET_BOOKINGDELETE_COLUMN_DEFINITION,
	GET_BOOKINGDELETE_COLUMN_DEFINITION_SUCCESS,
	GET_BOOKINGDELETE_COLUMN_DEFINITION_FAILURE,
	GET_BOOKINGDELETE_UPDATE_COLUMN_DEFINITION,
	GET_BOOKINGDELETE_UPDATE_COLUMN_DEFINITION_SUCCESS,
	GET_BOOKINGDELETE_UPDATE_COLUMN_DEFINITION_FAILURE,
	RESET_DEFAULTS,
	RESET_DEFAULTS_SUCCESS,
	RESET_DEFAULTS_FAILURE,
	SET_FILTER_VALUES,
	SET_COLUMN_DEFS_LOADED,
	SET_PAGEPROPS,
	SET_APICALL_COUNT,
	GET_BOOKINGS_LIST,
	GET_BOOKINGS_LIST_SUCCESS,
	GET_BOOKINGS_LIST_FAILURE,
	RESET_DATA,// needs to be handled carefully 
	LABEL_DATA_FLAGS
} from './constants';

import {
	COLUMN_POSITION,
	COLUMN_FIELD_TYPE,
	DROPDOWN_FIELD
} from 'components/common/constants';

import {
	getSortableColumns
} from 'utils/util';

const initialState = fromJS({
	columnDefs: false,
	columnInfo: false,
	updateColumnsList: false,
	filterProps: false,
	isColumnDefsLoaded: false,
	rowData: false,
	loading: true,
	isAPIProgress: false,
	pageProps: false,
	totalCount: 0,
	moreRecordsAvailable: false,
	apiCallCount: 0,
	bookingListArray: [],
	isAPIforBookingCopyList: false,
	isAPIforColumns: false,
	isAPIforColumnsUpdate: false,
	isAPIforResetColumns: false,
	isAPIforBookingList: false,
	resetDefaultsCols:false
});

const bookingDeleteReducer = (state = initialState, action) => {
	switch (action.type) {
		case GET_BOOKINGDELETE_LIST: return state.set('loading', true).set('isAPIforBookingCopyList', false);
		case GET_BOOKINGDELETE_LIST_SUCCESS:
			let direction = state.get('pageProps').isForwardDirection;
			let data = action.data;
			if (data && data.listArray && data.listArray.length) {
				let count = state.get('apiCallCount');
				let totalCount = 100 * count + data.listArray.length;
				let dataList = data.listArray;
				dataList.forEach((row) => {
					row["isSelected"] = false;
				})

				if (!direction) {
					dataList.reverse();
				}
				return state
					.set('isAPIProgress', false)
					.set('rowData', dataList)
					.set('moreRecordsAvailable', data.moreRecordsAvailable)
					.set('totalCount', totalCount)
					.set('loading', false);
			}
			return state.set('rowData', action.data);
		case GET_BOOKINGDELETE_LIST_FAILURE: return state.state.set('loading', false)
			.set('rowData', []).set('isAPIforBookingCopyList', true);

		case GET_BOOKINGDELETE_COLUMN_DEFINITION: return state.set('loading', true).set('isAPIforColumns', false);
		case GET_BOOKINGDELETE_COLUMN_DEFINITION_SUCCESS:
			if (action.data && action.data.fields && action.data.fields.length) {
				let columnFields = action.data.fields.filter(col => Object.keys(col).length);
				let list = getSortableColumns(columnFields, COLUMN_POSITION, COLUMN_FIELD_TYPE, DROPDOWN_FIELD, true, false, true);
				list.forEach( x =>{
					if(x.FLDNUM =='6479'){
						x.FDPRFX ='1'
					}
				})
				return state
					.set('loading', false)
					.set('isColumnDefsLoaded', true)
					.set('updateColumnsList', false)
					.set('columnInfo', action.data.info)
					.set('columnDefs', list)
			}
		case GET_BOOKINGDELETE_COLUMN_DEFINITION_FAILURE: return state
			.set('loading', false).set('isAPIforColumns', true).set('loading', false);

		case GET_BOOKINGDELETE_UPDATE_COLUMN_DEFINITION: return state.set('loading', true).set('isAPIforColumnsUpdate', false);
		case GET_BOOKINGDELETE_UPDATE_COLUMN_DEFINITION_SUCCESS:
			let updateData = action.data;
			if (updateData.message && updateData.message.length && updateData.message.toLowerCase() == 'success') {
				return state.set('updateColumnsList', true)
					.set('loading', true)
					.set('columnDefs', []);
			}
			return state;
		case GET_BOOKINGDELETE_UPDATE_COLUMN_DEFINITION_FAILURE:
			return state.set('loading', false).set('isAPIforColumnsUpdate', true);

		case RESET_DEFAULTS:
			return state.set('loading', true).set('isAPIforResetColumns', false).set('resetDefaultsCols',false);
		case RESET_DEFAULTS_SUCCESS:
			return state.set('loading', false).set('resetDefaultsCols',true);
		case RESET_DEFAULTS_FAILURE:
			return state.set('loading', false).set('isAPIforResetColumns', true).set('resetDefaultsCols',false);
		case RESET_DATA: return initialState;

		case SET_APICALL_COUNT: return state.set('apiCallCount', action.data);
		case SET_PAGEPROPS: return state.set('pageProps', JSON.parse(JSON.stringify(action.data)));
		case SET_FILTER_VALUES: return state.set('filterProps', JSON.parse(JSON.stringify(action.data)));
		case SET_COLUMN_DEFS_LOADED: return state.set('loading', true);

		case GET_BOOKINGS_LIST: return state.set('loading', true).set('isAPIforBookingList', false);
		case GET_BOOKINGS_LIST_SUCCESS:
			data = action.data;
			if (data && data.listArray && data.listArray.length) {
				return state.set('bookingListArray', data.listArray).set('loading', false)
			}
			return state.set('loading', false);
		case GET_BOOKINGS_LIST_FAILURE:
			return state.set('loading', false).set('isAPIforBookingList', true);;
		case LABEL_DATA_FLAGS:
			return state.set(action.data.key, action.data.value);
		default: return state;
	}
}

export default bookingDeleteReducer;
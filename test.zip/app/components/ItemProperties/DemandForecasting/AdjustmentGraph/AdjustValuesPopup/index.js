import React from 'react';
import PropTypes from 'prop-types';
import {
  Grid,
  withStyles,
  Select,
  MenuItem,
} from '@material-ui/core';
import FormattedMessageComponent from '../../../../common/FormattedMessageComponent';
import DialogComponent from 'components/common/DialogComponent';
import { FieldInput } from 'components/common/Form';
import { getFormattedNumber } from '../../../../../utils/util';
const styles = () => ({
  form: {
    border: 'solid 1px #AFAFAF',
    borderRadius: 4,
    margin: '10px 20px',
    boxSizing: 'border-box',
    width: 'calc(100% - 40px)',
    padding: 10,
  },
  formControl: {
    boxSizing: 'border-box',
    padding: '10px',
    '&:nth-child(2n)': {
      textAlign: 'right',
    },
  },
  btn: {
    padding: 3,
  },
  dialogClass: {
    minWidth: 'auto',
    maxWidth: '20rem',
    height: 'auto',
  },
  cellInput: {
    margin: "0 10px",
    width: "calc(100% - 20px)",
    '& [class*="MuiInputBase-input"]': {
      textAlign: 'right',
    }
  },
});


class AdjustValuesPopup extends React.Component {
  constructor(props) {
    super(props);
    const { values, isMonthly } = props;
    const {
      category,
      year,
      period,
      bookings,
      adjusted,
      lost,
      promotional,
      shipped,
    } = values;
    this.state = {
      category,
      year,
      period,
      bookings,
      adjusted,
      lost,
      promotional,
      shipped,
      isMonthly
    };
  }

  onClose = () => {
    this.props.onClose();
  };

  // onChange = name => (event) => {
  onChange = (name, value) => {
    const { lost, shipped, adjusted: adjustedOriginal } = this.props.values;
    // let value = parseInt(event.target.value.toString().replaceAll(',', ''), 10);
    value = +value;
    if (isNaN(value)) {
      value = 0;
    }
    if (['year', 'period'].includes(name)) {
      let year, period;
      if (name === 'year') {
        year = String(value);
        period = this.state.period;
      } else if (name === 'period') {
        year = this.state.year;
        period = value;
      }
      this.setState({
        ...this.getValues(year, period)
      })
      return;
    }
    let adjusted = this.state.adjusted || 0;

    if (name === 'shipped') {
      adjusted = (value - shipped) + (this.state.lost - lost) + adjustedOriginal;
    }
    if (name === 'lost') {
      adjusted = value - lost + (this.state.shipped - shipped) + adjustedOriginal;
    }
    this.setState({
      [name]: value,
      adjusted,
    });
  };
  getPeriods = () => {
    const { isMonthly } = this.props;
    const arr = [], maxIndex = isMonthly ? 12 : 52 ;
    for (let i = 1; i <= maxIndex; i += 1) {
      arr.push({ key: i, label: i });
    }
    return arr;
  }
getValues = (year, period) => {
  const { categories, series, adjustmentData, years, isSideBySide, isMonthly } = this.props;
  let category = "";
  let selectedIndex = (period - 1);
  let maxIndex = isMonthly ? 12 : 52;
  if (year && years) {
    let yearIndex = years.findIndex(y => y == year);
    if (yearIndex !== -1) {
      // const catIndex = (yearIndex * 52) + selectedIndex;
      // category = categories[catIndex - 1];
      selectedIndex = (yearIndex * maxIndex) + selectedIndex;
      category = categories[selectedIndex];
    }
  }
  if (isSideBySide) {
    let yearIndex = years.findIndex(y => y == year);
    if (yearIndex !== -1) {
      selectedIndex = yearIndex + ((period - 1) * 4);
      category = categories[selectedIndex];
    }
  }
  const values = {
    year,
    period,
    bookings: 0,
    lost: 0,
    shipped: 0,
    adjusted: 0,
    promotional: 0,
    category,
  };

  if (values.period === 1 && category.substring(0, 2) == '12') {
    values.year = String(+year + 1);
  }
  values.adjusted = adjustmentData[selectedIndex];
  series.forEach(s => {
    switch (s.key) {
      case 'Lost':
        if (s.data[selectedIndex]) {
          values.lost = parseInt(s.data[selectedIndex], 10);
        } else {
          values.lost = 0;
        }
        break;
      case 'Shipped':
        if (s.data[selectedIndex]) {
          values.shipped = parseInt(s.data[selectedIndex], 10);
        } else {
          values.shipped = 0;
        }
        break;
      case 'Bookings':
        if (s.data[selectedIndex]) {
          values.bookings = parseInt(s.data[selectedIndex], 10);
        } else {
          values.bookings = 0;
        }
        break;
      case 'Promo':
        if (s.data[selectedIndex]) {
          values.promotional = parseInt(s.data[selectedIndex], 10);
        } else {
          values.promotional = 0;
        }
        break;
      default:
        break;
    }
  });
  return values;
}
  onSubmit = () => {
    this.props.onSubmit(this.state);
    this.props.onClose();
  };
  handleChange = name => event => {
    this.onChange(name, event.target.value);
  }
  render() {
    const { classes, open, editable, years } = this.props;
    const {
      year,
      period,
      bookings,
      adjusted,
      lost,
      promotional,
      shipped,
    } = this.state;
    return (
      <DialogComponent
        isOpen={open}
        dialogTitle="25442"
        handleSubmit={this.onSubmit}
        handleCancel={this.onClose}
        handleClose={this.onClose}
        submitText={editable ? "52758" : false}
        cancelText={editable ? "50771" : "25554"}
        className={classes.dialogClass}
      >
        <Grid container className={classes.form}>
          <Grid
            item
            xs={12}
            sm={12}
            md={6}
            lg={6}
            xl={6}
            className={classes.formControl}
          >
            <FormattedMessageComponent id={39672} />
          </Grid>
          <Grid
            item
            xs={12}
            sm={12}
            md={6}
            lg={6}
            xl={6}
            className={classes.formControl}
          >
            {editable ? (
              <Select
                style={{ width: '100%', textAlign: 'right' }}
                onChange={this.handleChange('year')}
                value={year.toString()}
              >
                {years.map(year1 => (
                  <MenuItem
                    key={year1}
                    value={year1}
                    selected={year.toString() === year1}
                  >
                    {year1}
                  </MenuItem>
                ))}
              </Select>
            ) : (
                year
              )}
          </Grid>
          <Grid
            item
            xs={12}
            sm={12}
            md={6}
            lg={6}
            xl={6}
            className={classes.formControl}
          >
            <FormattedMessageComponent id={50791} />
          </Grid>
          <Grid
            item
            xs={12}
            sm={12}
            md={6}
            lg={6}
            xl={6}
            className={classes.formControl}
          >
            {editable ? (
              <Select
                style={{ width: '100%' }}
                onChange={this.handleChange('period')}
                value={period.toString()}
              >
                {this.getPeriods().map(menuItem => (
                  <MenuItem
                    key={menuItem.key}
                    value={menuItem.key}
                    selected={menuItem.key === period.toString()}
                  >
                    {menuItem.label}
                  </MenuItem>
                ))}
              </Select>
            ) : (
                period
              )}
          </Grid>
          <Grid
            item
            xs={12}
            sm={12}
            md={6}
            lg={6}
            xl={6}
            className={classes.formControl}
          >
            <FormattedMessageComponent id={25235} />
          </Grid>
          <Grid
            item
            xs={12}
            sm={12}
            md={6}
            lg={6}
            xl={6}
            className={classes.formControl}
          >
            {bookings.toLocaleString('en')}
          </Grid>
          <Grid
            item
            xs={12}
            sm={12}
            md={6}
            lg={6}
            xl={6}
            className={classes.formControl}
          >
            <FormattedMessageComponent id={50450} />
          </Grid>
          <Grid
            item
            xs={12}
            sm={12}
            md={6}
            lg={6}
            xl={6}
            className={classes.formControl}
          >
            {getFormattedNumber(adjusted, this.props.globalNumberFormat, this.props.globalNumberSeparator, 0, this.props.globalDecimalSeparator) }
          </Grid>
          <Grid
            item
            xs={12}
            sm={12}
            md={6}
            lg={6}
            xl={6}
            className={classes.formControl}
          >
            <FormattedMessageComponent id={50923} />
          </Grid>
          <Grid
            item
            xs={12}
            sm={12}
            md={6}
            lg={6}
            xl={6}
            className={editable ? "" :classes.formControl}
          >
            {editable ? (
              <FieldInput
                field={{
                  type: 'number', key: 'lost', Attr: ' '
                }}
                maxLength={7}
                numberType={'integer'}
                onChange={this.onChange}
                value={lost?.toString()}
                errorMessageLabel={this.props.getLabelFromId('33976')}
                errorMessageLabels={this.props.errorMessageLabels}
                className={classes.cellInput}
              />
            ) : (
                getFormattedNumber(lost, this.props.globalNumberFormat, this.props.globalNumberSeparator, 0, this.props.globalDecimalSeparator)
              )}
          </Grid>
          <Grid
            item
            xs={12}
            sm={12}
            md={6}
            lg={6}
            xl={6}
            className={classes.formControl}
          >
            <FormattedMessageComponent id={50785} />
          </Grid>
          <Grid
            item
            xs={12}
            sm={12}
            md={6}
            lg={6}
            xl={6}
            className={editable ? "" :classes.formControl}
          >
            {editable ? (
              <FieldInput
                field={{
                  type: 'number', key: 'promotional', Attr: ' '
                }}
                maxLength={7}
                numberType={'integer'}
                onChange={this.onChange}
                value={promotional?.toString()}
                errorMessageLabel={this.props.getLabelFromId('50785')}
                errorMessageLabels={this.props.errorMessageLabels}
                className={classes.cellInput}
              />
            ) : (
                getFormattedNumber(promotional, this.props.globalNumberFormat, this.props.globalNumberSeparator, 0, this.props.globalDecimalSeparator)
              )}
          </Grid>
          <Grid
            item
            xs={12}
            sm={12}
            md={6}
            lg={6}
            xl={6}
            className={classes.formControl}
          >
            <FormattedMessageComponent id={33978} />
          </Grid>
          <Grid
            item
            xs={12}
            sm={12}
            md={6}
            lg={6}
            xl={6}
            className={editable ? "" :classes.formControl}
          >
            {editable ? (
              <FieldInput
                field={{
                  type: 'number', key: 'shipped', Attr: ' '
                }}
                maxLength={7}
                numberType={'integer'}
                onChange={this.onChange}
                value={shipped?.toString()}
                errorMessageLabel={this.props.getLabelFromId('33978')}
                errorMessageLabels={this.props.errorMessageLabels}
                className={classes.cellInput}
              />
            ) : (
                getFormattedNumber(shipped, this.props.globalNumberFormat, this.props.globalNumberSeparator, 0, this.props.globalDecimalSeparator)
              )}
          </Grid>
        </Grid>
      </DialogComponent>
    );
  }
}

AdjustValuesPopup.propTypes = {
  classes: PropTypes.object,
  open: PropTypes.bool,
  onClose: PropTypes.func,
  editable: PropTypes.bool,
  values: PropTypes.object,
  onSubmit: PropTypes.func,
  getLabelFromId: PropTypes.func.isRequired,
  errorMessageLabels: PropTypes.object.isRequired,
  globalNumberFormat: PropTypes.string.isRequired,
  globalDecimalSeparator: PropTypes.string.isRequired,
  globalNumberSeparator: PropTypes.string.isRequired,
};

export default withStyles(styles)(AdjustValuesPopup);

import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import PaginationGrid from 'components/PaginationGrid';
import Spinner from 'components/common/Spinner';
import {
  COLUMN_HEADER_ACCESSOR,
  COLUMN_HEADER_PREFIX_FLAG,
  COLUMN_SHOW_HIDE_FLAG,
  COLUMN_VALUE_ACCESSOR,
  DATA_ACCESS_KEY,
  GLOBAL_FILTER_OPTIONS,
  INITIAL_PAGE_PROPS,
} from '../common/constants';
import NumberRenderer from '../CustomGrid/NumberRenderer';
import TextRenderer from '../CustomGrid/TextRenderer';
import DropdownRenderer from '../CustomGrid/DropdownRenderer';
import DateRenderer from '../CustomGrid/DateRenderer';
import LinkRenderer from '../CustomGrid/LinkRenderer';
import { isEqual } from 'lodash';
import { capitalizeAllLetters, getDefaultSortFilterProps, getDefaultSortInfo, getFilterDataFromCriteriaDetails, getFilterDataFromLocalStorage, setSortDataFromSortCriteria } from '../../utils/util';
import { getDBSelectorFilterValues, prepareTooltipValues } from '../../utils/filterData';

const frameworkComponent = {
  numberRenderer: NumberRenderer,
  textRenderer: TextRenderer,
  dropdownRenderer: DropdownRenderer,
  dateRenderer: DateRenderer,
  linkRenderer: LinkRenderer,
};

class InventoryAnalysisList extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      isFromTabs: false,
    };
  }

  componentDidMount = () => {
    const {
      getColumns,
      loadInventoryAnalysisList,
      inventoryAnalysisListPage,
      onLoadCurrentPage,
      onSetFilterProps,
      onSetGlobalFilterProps,
      setGlobalFilterProps,
    } = this.props;
    const { filterProps, sortProps, pageProps } = inventoryAnalysisListPage;
    if (getColumns) {
      getColumns();
    }

    if (loadInventoryAnalysisList) {
      loadInventoryAnalysisList(this.addInventoryAnalysisFilterIfNotPresent(filterProps), sortProps, pageProps, true, {});
    }

    if (onLoadCurrentPage) {
      onLoadCurrentPage('inventoryanalysis');
    }

    if (onSetFilterProps) {
      onSetFilterProps(this.addInventoryAnalysisFilterIfNotPresent(filterProps));
    }
    if (onSetGlobalFilterProps) {
      onSetGlobalFilterProps(filterProps);
      setGlobalFilterProps(filterProps);
    }
    this.setFilterValues();
  };

  componentDidUpdate = prevProps => {
    const {
      inventoryAnalysisListPage,
      loadInventoryAnalysisList,
      onSetPageProps,
      setDataInTabs,
      onSetGlobalFilterProps,
      onSetFilterProps,
    } = this.props;
    const {
      filterCriteriaDetails,
      filterProps,
      pageProps,
      sortProps,
      columnDefs,
      exportFilterProps,
      exportFields,
      showHideColumns,
      searchReplaceValues,
      updateColumnsList,
      items,
      isColumnDefsLoaded,
      currentLoadedProps,
      defaultSortProps,
      isSortPropsChanged,
      columnInfo,
      sortCriteriaDetails,
      closeFiltersPopup,
      isValueDataAPICall,
      isValueDataAPIFailure,
      hasToResetDefaults,
      apiCallCount,
    } = inventoryAnalysisListPage;
    if (
      !isEqual(pageProps, prevProps.inventoryAnalysisListPage.pageProps) &&
      pageProps.isPageSizeChanged
    ) {
      onSetPageProps(pageProps);
    }

    if (
      !isEqual(
        filterCriteriaDetails,
        prevProps.inventoryAnalysisListPage.filterCriteriaDetails,
      )
    ) {
      setDataInTabs('defaultFilterInfo', filterCriteriaDetails);
      if (
        filterCriteriaDetails &&
        Object.keys(filterCriteriaDetails) &&
        Object.keys(filterCriteriaDetails).length &&
        columnDefs &&
        columnDefs.length
      ) {
        const list = getFilterDataFromCriteriaDetails(
          filterCriteriaDetails,
          columnDefs,
          'inventoryAnalysis',
        );
        if (list && list.length) {
          onSetGlobalFilterProps(list);
          onSetFilterProps(this.addInventoryAnalysisFilterIfNotPresent(list));
        }
      }
    }

    if (
      !isEqual(filterProps, prevProps.inventoryAnalysisListPage.filterProps)
    ) {
      loadInventoryAnalysisList(this.addInventoryAnalysisFilterIfNotPresent(filterProps), sortProps, pageProps, true, {});
    }

    const { pageFilters } = this.props;

    if (
      !isEqual(
        closeFiltersPopup,
        prevProps.inventoryAnalysisListPage.closeFiltersPopup,
      ) &&
      closeFiltersPopup
    ) {
      this.handleFilterClose();
    }

    if (
      !isEqual(apiCallCount, prevProps.inventoryAnalysisListPage.apiCallCount)
    ) {
      this.props.setDataInTabs('apiCallCount', apiCallCount);
    }

    if (
      pageProps &&
      !isEqual(pageProps, prevProps.inventoryAnalysisListPage.pageProps)
    ) {
      this.props.setDataInTabs(
        'pageProps',
        JSON.parse(JSON.stringify(pageProps)),
      );
    }

    if (
      sortProps &&
      sortProps.length &&
      !isEqual(sortProps, prevProps.inventoryAnalysisListPage.sortProps)
    ) {
      this.props.setDataInTabs(
        'sortProps',
        JSON.parse(JSON.stringify(sortProps)),
      );
      this.props.setSortPropsChangeFlag(false);
    }

    if (
      isValueDataAPICall !==
        prevProps.inventoryAnalysisListPage.isValueDataAPICall &&
      isValueDataAPICall
    ) {
      this.setState({ isInitialAPICall: false });
      this.setState({ previousFilterValues: filterProps })
      this.props.setValueDataFlag(false);
      this.props.setValueDataAPIFailureFlag(false);
      if (this.state.isFiltersChanged) {
        this.setState({ isFiltersChanged: false });
        this.props.handleCloseIAFitler();
        this.props.closeFilterComponent(true);
      }
    }

    if (
      isValueDataAPIFailure !==
        prevProps.inventoryAnalysisListPage.isValueDataAPIFailure &&
      isValueDataAPIFailure
    ) {
      this.setState({ isInitialAPICall: false });
      if (!this.state.isDataLoaded && columnDefs && columnDefs.length) {
        this.setState({ isDataLoaded: true }, () => {
          this.handleNoDataSets();
        });
      }
      if (this.state.isFiltersChanged) {
        this.props.setValueDataAPIFailureFlag(false);
        this.setState({ showConfirmationDialog: true });
        this.setState({ hasWarning: true });
        this.setState({ dialogTitle: TEXT_ALERT });
        this.setState({ dialogInfoId: '28648' });
      }
    }

    if (
      JSON.stringify(items) !==
        JSON.stringify(prevProps.inventoryAnalysisListPage.items) &&
      !this.state.isDataLoaded &&
      items &&
      columnDefs &&
      columnDefs.length
    ) {
      this.setState({ isDataLoaded: true }, () => {
        this.handleNoDataSets();
      });
    }

    if (
      (!isEqual(sortProps, prevProps.inventoryAnalysisListPage.sortProps) ||
        (isSortPropsChanged && currentLoadedProps === 'sort')) &&
      !this.state.isInitialAPICall
    ) {
      this.props.setSortPropsChangeFlag(false);
      if (sortProps && sortProps.length) {
        this.resetPagePropsAndSendApiCall(
          filterProps,
          sortProps,
          pageProps,
          true,
          false,
        );
      }
    }

    if (this.props.location.search !== prevProps.location.search) {
      this.resetValues();
      this.forceUpdateHandler();
      this.setFilterValues();
      this.setState({ state: this.state });
      this.setState({ currentPage: window.location.pathname.slice(1) }, () => {
        this.props.onLoadCurrentPage(this.state.currentPage);
      });
    }

    if (
      !isEqual(pageProps, prevProps.inventoryAnalysisListPage.pageProps) &&
      pageProps.isPageSizeChanged
    ) {
      this.props.setApiCallCount(0);
      const initialPageData = {
        ...pageProps,
        actualPage: 0,
        currentPage: 0,
        totalCount: 10,
        isForwardDirection: true,
      };
      this.resetPagePropsAndSendApiCall(
        filterProps,
        sortProps,
        initialPageData,
        true,
        false,
      );
      this.props.onSetPageProps({
        ...initialPageData,
        isPageSizeChanged: false
      });
    }

    if (
      JSON.stringify(columnDefs) !==
        JSON.stringify(prevProps.inventoryAnalysisListPage.columnDefs) &&
      !prevProps.inventoryAnalysisListPage.columnDefs
    ) {
      if (columnDefs && columnDefs.length) {
        if (!isColumnDefsLoaded) {
          this.props.setFlagColumnDefsLoaded(true);
        }
      } else if (!this.state.isDataLoaded) {
        this.setState({ isDataLoaded: true }, () => {
          this.handleNoDataSets(true);
        });
      }
    }

    if (
      JSON.stringify(columnDefs) !==
      JSON.stringify(prevProps.inventoryAnalysisListPage.columnDefs)
    ) {
      if (columnDefs && columnDefs.length) {
        this.props.setGlobalColDefs(columnDefs);
        if (columnInfo) {
          this.props.setGlobalColumnInfo(columnInfo);
        }
      }
    }

    if (
      !isEqual(
        defaultSortProps,
        prevProps.inventoryAnalysisListPage.defaultSortProps,
      ) &&
      prevProps.inventoryAnalysisListPage.defaultSortProps === null &&
      (sortProps == null || !sortProps || !(sortProps && sortProps.length))
    ) {
      this.props.setLoadingFlag(true);
      const list = setSortDataFromSortCriteria(
        defaultSortProps,
        columnDefs,
        'inventoryAnalysis',
      );
      const defaultSortInfo = getDefaultSortInfo(defaultSortProps);
      this.props.setDataInTabs(
        'defaultSortInfo',
        JSON.parse(JSON.stringify(defaultSortProps)),
      );
      if (list && list.length) {
        this.props.sendPageSortProps(list);
        this.props.onSetSortProps(list);
        this.sendAPIWithExistingPageprops(
          filterProps,
          list,
          pageProps,
          true,
          false,
        );
      } else {
        this.props.sendPageSortProps([]);
        this.props.onSetSortProps([]);
        this.sendAPIWithExistingPageprops(
          filterProps,
          [],
          pageProps,
          true,
          false,
        );
      }
    }

    if (
      JSON.stringify(sortCriteriaDetails) !==
      JSON.stringify(prevProps.inventoryAnalysisListPage.sortCriteriaDetails)
    ) {
      this.props.setDataInTabs(
        'defaultSortInfo',
        JSON.parse(JSON.stringify(sortCriteriaDetails)),
      );
      const list = setSortDataFromSortCriteria(
        sortCriteriaDetails,
        columnDefs,
        'inventoryAnalysis',
      );
      if (list && list.length) {
        this.props.sendPageSortProps(list);
        this.props.onSetSortProps(list);
      }
    }

    if (
      !isEqual(
        currentLoadedProps,
        prevProps.inventoryAnalysisListPage.currentLoadedProps,
      ) &&
      currentLoadedProps === 'sort' &&
      sortProps &&
      filterProps &&
      pageProps
    ) {
      this.props.setSortPropsChangeFlag(false);
      this.props.setGlobalFilterProps(filterProps);
    }

    if (
      !isEqual(sortProps, prevProps.inventoryAnalysisListPage.sortProps) &&
      sortProps &&
      sortProps.length &&
      !this.state.isInitialAPICall
    ) {
      this.props.setApiCallCount(0);
      this.resetPagePropsAndSendApiCall(
        filterProps,
        sortProps,
        pageProps,
        true,
        false,
      );
    }

    if (
      isColumnDefsLoaded !==
        prevProps.inventoryAnalysisListPage.isColumnDefsLoaded &&
      isColumnDefsLoaded &&
      filterProps &&
      filterProps.length &&
      (sortProps === null || !sortProps || !(sortProps && sortProps.length))
    ) {
      this.props.getDefaultSortProps(
        getDefaultSortFilterProps('inventoryAnalysis'),
      );
    }

    if (
      isColumnDefsLoaded !==
        prevProps.inventoryAnalysisListPage.isColumnDefsLoaded &&
      isColumnDefsLoaded &&
      filterProps &&
      filterProps.length &&
      this.state.isInitialAPICall
    ) {
      if (sortProps && sortProps.length) {
        this.sendAPIWithExistingPageprops(
          filterProps,
          sortProps,
          pageProps,
          true,
          false,
        );
      }
    }

    if (
      !isEqual(
        filterCriteriaDetails,
        prevProps.inventoryAnalysisListPage.filterCriteriaDetails,
      )
    ) {
      this.props.setDataInTabs(
        'defaultFilterInfo',
        JSON.parse(JSON.stringify(filterCriteriaDetails)),
      );
      if (
        filterCriteriaDetails &&
        Object.keys(filterCriteriaDetails) &&
        Object.keys(filterCriteriaDetails).length &&
        columnDefs &&
        columnDefs.length
      ) {
        const list = getFilterDataFromCriteriaDetails(
          filterCriteriaDetails,
          columnDefs,
          'inventoryAnalysis',
        );
        if (list && list.length) {
          this.props.setGlobalFilterProps(list);
          this.props.onSetFilterProps(this.addInventoryAnalysisFilterIfNotPresent(list));
        }
      }
    }

    if (
      JSON.stringify(filterProps) !==
        JSON.stringify(prevProps.inventoryAnalysisListPage.filterProps) &&
      pageProps &&
      !pageFilters &&
      filterProps
    ) {
      this.props.setGlobalFilterProps(filterProps);
    }

    if (
      !isEqual(filterProps, prevProps.inventoryAnalysisListPage.filterProps) &&
      filterProps &&
      filterProps.length &&
      pageProps &&
      !this.state.isInitialAPICall
    ) {
      this.props.setApiCallCount(0);
      this.resetPagePropsAndSendApiCall(
        filterProps,
        sortProps,
        pageProps,
        true,
        false,
      );
    }

    if (
      JSON.stringify(filterProps) !==
        JSON.stringify(prevProps.inventoryAnalysisListPage.filterProps) &&
      filterProps &&
      filterProps.length
    ) {
      this.props.setChildTabFilterProps(filterProps);
      this.setState({ isFiltersChanged: true });
    }

    if (
      showHideColumns !== prevProps.inventoryAnalysisListPage.showHideColumns
    ) {
      this.props.getUpdatedColumnDefs({
        type: 'inventoryAnalysis',
        userId: this.props.inventoryAnalysisListPage.columnInfo.USERID.trim(),
        record: showHideColumns,
      });
    }

    if (
      !isEqual(
        updateColumnsList,
        prevProps.inventoryAnalysisListPage.updateColumnsList,
      ) &&
      updateColumnsList
    ) {
      this.props.getColumns({ type: 'inventoryAnalysis' });
      this.props.setUpdateColumnsList(true);
    }

    if (
      hasToResetDefaults &&
      prevProps.inventoryAnalysisListPage.hasToResetDefaults !==
        hasToResetDefaults
    ) {
      this.props.colResetDefault({
        type: 'inventoryAnalysis',
        userId: this.props.columnInfo.USERID.trim(),
      });
    }

    if (
      !isEqual(
        exportFilterProps,
        prevProps.inventoryAnalysisListPage.exportFilterProps,
      ) ||
      !isEqual(exportFields, prevProps.inventoryAnalysisListPage.exportFields)
    ) {
      this.resetPagePropsAndSendApiCall(
        filterProps,
        sortProps,
        pageProps,
        true,
        false,
        exportFilterProps,
        exportFields,
      );
    }

    if (
      searchReplaceValues !==
      prevProps.inventoryAnalysisListPage.searchReplaceValues
    ) {
      this.resetPagePropsAndSendApiCall(
        filterProps,
        sortProps,
        pageProps,
        true,
        false,
        false,
        false,
        false,
        searchReplaceValues,
      );
    }
  };

  handleNoDataSets = isColumns => {
    const { rowData, columnDefs } = this.props.inventoryAnalysisListPage;
    if (this.state.isDataLoaded) {
      if (isColumns && columnDefs && columnDefs.length) {
        //do nothing here
      } else if (rowData && rowData.length && columnDefs && columnDefs.length) {
        //do nothing here
      } else {
        this.props.setNoDataCallBackValue(true);
        this.showConfirmationDialog = true;
        this.noDatasets = true;
      }
    }
  };


  addInventoryAnalysisFilterIfNotPresent = (list) => {
    //dont push inventry filter if navigating through internal showMe flow.
    const { tab_id, item_id } = Object.fromEntries(new URLSearchParams(window.location.search)) || {};
    const localStorageValues = getFilterDataFromLocalStorage(
      tab_id,
      item_id,
    );
    if (localStorageValues && Object.keys(localStorageValues)?.length) {
      const itemData = localStorageValues[DATA_ACCESS_KEY];
      if (itemData && itemData.fromShowMeFlow) {
        return list;
      }
    }
    let found = false;
    list = list.map(i => {
      if (i.accessor === "IAFLTR") {
        found = true;
        i.prefixFlag = 1;
      }
      return i;
    });
    if (!found) list.push(
      { accessor: "IAFLTR", fieldValue: "1", operator: "=", prefixFlag: 1 }
    );
    return list;
  }

  sendAPIWithExistingPageprops = (
    filterProps,
    sortProps,
    pageData,
    direction,
    record,
    exportFilterProps,
    exportFields,
    showHideColumns,
    searchReplaceValues,
  ) => {
    let recordData = JSON.parse(JSON.stringify(record));
    const { pageProps } = this.props.inventoryAnalysisListPage;
    const existingPageProps = {
      ...pageProps,
      isForwardDirection: true,
    };
    this.props.onSetPageProps({
      ...pageProps,
      isForwardDirection: true,
    });
    if (
      this.state.paginationRecord &&
      Object.keys(this.state.paginationRecord) &&
      Object.keys(this.state.paginationRecord).length
    ) {
      recordData = JSON.parse(JSON.stringify(this.state.paginationRecord));
    }
    this.props.loadInventoryAnalysisList(
      this.addInventoryAnalysisFilterIfNotPresent(filterProps),
      sortProps,
      existingPageProps,
      direction,
      recordData,
      exportFilterProps,
      exportFields,
      showHideColumns,
      searchReplaceValues,
      this.state.currentPage,
    );
  };

  onRowSelected = event => {
    this.props.setSelectedRecord(
      JSON.parse(JSON.stringify(this.grid.api.getSelectedRows()[0])),
      'inventoryanalysis',
    );
    this.props.setIsShowContextMenu(true);
  };

  onValueChanged = value => {};

  modValues = values =>
    values
      .filter(value => value.accessor !== 'BTOTL')
      .map(value => ({
        ...value,
        prefixFlag: value.accessor.substr(1, 3) === 'GRP',
      }));

  setFilterValues = () => {
    const { history } = this.props;
    let isFilterValuesExists = false;
    let isLocalStorageValuesExists = false;
    const paramsString = window.location.search;
    if (paramsString && paramsString.length) {
      const paramsArray = paramsString.split('?');
      if (paramsArray && paramsArray.length > 1) {
        const params = paramsArray[1].split('&');
        const tabId = params[0].split('=')[1];
        const breadCrumbId = params[1].split('=')[1];
        if (tabId && breadCrumbId) {
          this.setState({
            isFromTabs: true,
          });
        }
        const localStorageValues = getFilterDataFromLocalStorage(
          tabId,
          breadCrumbId,
        );
        if (
          localStorageValues &&
          Object.keys(localStorageValues) &&
          Object.keys(localStorageValues).length
        ) {
          isLocalStorageValuesExists = true;
          const itemData = localStorageValues[DATA_ACCESS_KEY];
          let dbSelectorValues = [];
          this.props.setSelectedRecord(false, false);
          if (itemData) {
            if (itemData.dbSelector && itemData.dbSelector.length) {
              dbSelectorValues = [...itemData.dbSelector];
            }
            if (itemData.sortProps && itemData.sortProps.length) {
              this.previousSortValues = itemData.sortProps;
              this.props.sendPageSortProps(itemData.sortProps);
              this.props.onSetSortProps(itemData.sortProps);
              this.props.setSortPropsChangeFlag(false);
              this.setState({
                defaultSortProps: JSON.parse(
                  JSON.stringify(itemData.sortProps),
                ),
              });
            }
            if (itemData.filterProps && itemData.filterProps.length) {
              isFilterValuesExists = true;
              let values = getDBSelectorFilterValues(dbSelectorValues, itemData.filterProps);
              values = this.modValues(values);
              this.setState({
                currentFilterProps: JSON.parse(JSON.stringify(values)),
              });
              this.setFilterValuesFromState(values);
            } else if (dbSelectorValues && dbSelectorValues.length) {
              isFilterValuesExists = true;
              let dbValues = getDBSelectorFilterValues(dbSelectorValues, []);
              dbValues = this.modValues(dbValues);
              this.setFilterValuesFromState(dbValues);
            }
            if (
              itemData.defaultFilterInfo &&
              Object.keys(itemData.defaultFilterInfo) &&
              Object.keys(itemData.defaultFilterInfo).length
            ) {
              this.props.setDefaultFilterpropsForTabs(
                itemData.defaultFilterInfo,
              );
            }
            if (itemData.disableRows) {
              this.props.setGlobalFilterOptions(itemData.disableRows);
            }

            if (
              itemData.defaultSortInfo &&
              Object.keys(itemData.defaultSortInfo) &&
              Object.keys(itemData.defaultSortInfo).length
            ) {
              this.props.setDefaultSortpropsForTabs(itemData.defaultSortInfo);
            }
            if (
              itemData.pageProps &&
              Object.keys(itemData.pageProps) &&
              Object.keys(itemData.pageProps).length
            ) {
              this.props.onSetPageProps(itemData.pageProps);
            }
            if (
              itemData.paginationRecord &&
              Object.keys(itemData.paginationRecord) &&
              Object.keys(itemData.paginationRecord).length
            ) {
              this.setState({ paginationRecord: itemData.paginationRecord });
            }
            if (
              itemData.apiCallCount !== undefined &&
              parseInt(itemData.apiCallCount, 10) >= 0
            ) {
              this.props.setApiCallCount(itemData.apiCallCount);
            }
          }
        }
      }
    } else {
      history.push({ pathname: '/Dashboard' });
    }
    const filterOptions = { ...GLOBAL_FILTER_OPTIONS };
    const { dbSelector } = this.props;
    if (!isFilterValuesExists) {
      let gbValues = getDBSelectorFilterValues(dbSelector, filterOptions);
      gbValues = this.modValues(gbValues);
      this.setState({
        currentFilterProps: JSON.parse(JSON.stringify(gbValues)),
      });
      this.setFilterValuesFromState(gbValues);
    }
    return isFilterValuesExists;
  };

  setFilterValuesFromState = (values, isAPICall) => {
    let filterValues = [];
    const { columnDefs } = this.props.inventoryAnalysisListPage;
    if (columnDefs && columnDefs.length) {
      filterValues = values.filter(
        value =>
          columnDefs.find(
            column => column[COLUMN_VALUE_ACCESSOR].trim() === value.accessor,
          ) !== undefined,
      );
      if (filterValues && filterValues.length) {
        if (isAPICall) {
          this.resetPagePropsAndSendApiCall(
            filterValues,
            this.previousSortValues,
            INITIAL_PAGE_PROPS,
            true,
            false,
          );
        }
        this.props.onSetFilterProps(filterValues);
        this.props.setGlobalFilterProps(this.addInventoryAnalysisFilterIfNotPresent(filterValues));
      }
    } else {
      if (isAPICall) {
        this.resetPagePropsAndSendApiCall(
          values,
          this.previousSortValues,
          INITIAL_PAGE_PROPS,
          true,
          false,
        );
      }
      this.props.onSetFilterProps(this.addInventoryAnalysisFilterIfNotPresent(values));
      this.props.setGlobalFilterProps(values);
      return values;
    }
    return filterValues;
  };

  resetPagePropsAndSendApiCall = (
    filterProps,
    sortProps,
    pageProps,
    direction,
    record,
    exportFilterProps,
    exportFields,
    showHideColumns,
    searchReplaceValues,
  ) => {
    this.props.loadInventoryAnalysisList(
      this.addInventoryAnalysisFilterIfNotPresent(filterProps),
      sortProps,
      pageProps,
      direction,
      record,
      exportFilterProps,
      exportFields,
      showHideColumns,
      searchReplaceValues,
    );
  };

  onClickLink = (data, rowIndex) => {
    const {
      columnDefs,
      pageProps,
      filterProps,
      sortProps,
      defaultSortProps,
      filterCriteriaDetails,
    } = this.props.inventoryAnalysisListPage;
    const { actualPageSize, actualPage } = pageProps;
    if (this.state.isFromTabs) {
      const pathname = 'InventoryAnalysisProperties';
      const filterData = filterProps && filterProps.length ? filterProps : [];
      const sortData = sortProps && sortProps.length ? sortProps : [];
      const defaultFilterInfo =
        filterCriteriaDetails &&
        Object.keys(filterCriteriaDetails) &&
        Object.keys(filterCriteriaDetails).length
          ? filterCriteriaDetails
          : {};
      const defaultSortInfo =
        defaultSortProps &&
        Object.keys(defaultSortProps) &&
        Object.keys(defaultSortProps).length
          ? defaultSortProps
          : {};
      const tooltipData = prepareTooltipValues(
        'inventoryanalysis',
        data,
        columnDefs,
        'inventoryanalysisproperties',
      );

      const stateData = {
        data: { ...data },
        fromPage: 'inventoryanalysis',
        rowIndex: actualPageSize * actualPage + rowIndex,
        totalCount: this.props.inventoryAnalysisListPage.totalCount,
        fromParent: true,
        columnDefs,
      };
      this.props.setIsShowContextMenu(true);

      this.props.addChildTab(
        pathname,
        stateData,
        tooltipData,
        filterData,
        sortData,
        defaultSortInfo,
        defaultFilterInfo,
      );
    } else {
      this.props.push({
        pathname: '/InventoryAnalysisPropertiesPage',
        state: {
          data,
          fromPage: 'inventoryanalysis',
          rowIndex: actualPageSize * actualPage + rowIndex,
          totalCount: this.props.inventoryAnalysisListPage.totalCount,
          fromParent: true,
          columnDefs,
        },
      });
    }
  };

  onGridReady = grid => {
    this.grid = grid;
  };

  loadItems = () => {
    const { inventoryAnalysisListPage, loadInventoryAnalysisList } = this.props;
    const { filterProps, sortProps, pageProps } = inventoryAnalysisListPage;
    if (loadInventoryAnalysisList) {
      loadInventoryAnalysisList(
        this.addInventoryAnalysisFilterIfNotPresent(filterProps),
        sortProps,
        pageProps,
        true,
        this.getRecordDataOnDirection(typeof pageProps.isForwardDirection === "boolean" ? pageProps.isForwardDirection : true));
    }
  };

  getRecordDataOnDirection = (direction) => {
    const { rowData, apiCallCount } = this.props.inventoryAnalysisListPage;
    if (!rowData) {
      return {};
    }
    if (!direction) {
      this.props.setApiCallCount(apiCallCount - 1);
      return rowData[0];
    } else {
      this.props.setApiCallCount(apiCallCount + 1);
      return rowData[rowData.length - 1];
    }
  };

  render() {
    const { inventoryAnalysisListPage } = this.props;
    const {
      columnDefs,
      columnInfo,
      rowData,
      loading,
      pageProps,
      moreRecordsAvailable,
      totalCount,
    } = inventoryAnalysisListPage;
    return (
      <>
        {columnDefs && columnInfo ? (
          <div>
            <PaginationGrid
              columnData={columnDefs}
              columnInfo={columnInfo}
              rowData={rowData || []}
              rowSelection="single"
              onRowSelected={this.onRowSelected}
              onValueChanged={this.onValueChanged}
              frameworkComponent={frameworkComponent}
              onClickLink={this.onClickLink}
              height={500}
              listPredecessor="V"
              dataKey="inventoryAnalysisListPage"
              pageProps={pageProps}
              sendApi={this.loadItems}
              onGridReady={this.onGridReady}
              currentPage="inventoryAnalysis"
              columnKey={COLUMN_VALUE_ACCESSOR}
              titleKey={COLUMN_HEADER_ACCESSOR}
              columnShowFlag={COLUMN_SHOW_HIDE_FLAG}
              prefixFlag={COLUMN_HEADER_PREFIX_FLAG}
              props={this.props}
              moreRecordsAvailable={moreRecordsAvailable}
              totalCount={totalCount}
            />
            <Spinner loading={loading} type="list" />
          </div>
        ) : (
          <Spinner loading type="list" />
        )}
      </>
    );
  }
}

InventoryAnalysisList.propTypes = {
  getColumns: PropTypes.func,
  columnInfo: PropTypes.object,
  inventoryAnalysisListPage: PropTypes.object,
  loadInventoryAnalysisList: PropTypes.func,
  onSetPageProps: PropTypes.func,
  onLoadCurrentPage: PropTypes.func,
  onSetFilterProps: PropTypes.func,
  onSetGlobalFilterProps: PropTypes.func,
  setDataInTabs: PropTypes.func,
  addChildTab: PropTypes.func,
  push: PropTypes.func,
  setIsShowContextMenu: PropTypes.func,
  history: PropTypes.object,
  setSelectedRecord: PropTypes.func,
  sendPageSortProps: PropTypes.func,
  onSetSortProps: PropTypes.func,
  setSortPropsChangeFlag: PropTypes.func,
  setDefaultFilterpropsForTabs: PropTypes.func,
  setApiCallCount: PropTypes.func,
  dbSelector: PropTypes.object,
  setGlobalFilterProps: PropTypes.func,
  pageFilters: PropTypes.array,
  setValueDataFlag: PropTypes.func,
  setValueDataAPIFailureFlag: PropTypes.func,
  handleCloseIAFitler: PropTypes.func,
  closeFilterComponent: PropTypes.func,
  location: PropTypes.object,
  setFlagColumnDefsLoaded: PropTypes.func,
  setNoDataCallBackValue: PropTypes.func,
  setGlobalColDefs: PropTypes.func,
  setGlobalColumnInfo: PropTypes.func,
  setLoadingFlag: PropTypes.func,
  getDefaultSortProps: PropTypes.func,
  setChildTabFilterProps: PropTypes.func,
  getUpdatedColumnDefs: PropTypes.func,
  setUpdateColumnsList: PropTypes.func,
  colResetDefault: PropTypes.func,
};

export default InventoryAnalysisList;

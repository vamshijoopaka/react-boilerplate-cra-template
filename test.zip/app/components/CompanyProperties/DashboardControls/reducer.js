/** Change Log
 * LogStart --  E3C-33195 - Kumar A- 16 September,2021 - 2022.1.0.0 Unified Product
 *              Story: E3C-33195 --Code Cleanup
*/
import {
    DASHBOARD_CONTROL_GET_FIELD_LIST,
    DASHBOARD_CONTROL_GET_FIELD_LIST_SUCCESS,
    DASHBOARD_CONTROL_GET_FIELD_LIST_FAILURE,
    CUSTOM_CARDS
} from './constants';
import {
    COLUMN_POSITION, COLUMN_VALUE_ACCESSOR,
    COLUMN_FIELD_TYPE, DROPDOWN_FIELD
} from "../../common/constants";
import { getListPredecessor } from 'utils/util';
import { getSortableColumns, prepareBaseJSONwithFieldData, setNumberFields, prepareValuesFromReserved } from "../../../utils/util";

export const InitialState = {
    fieldData: false,
    customCards: getCustomCardsJson(CUSTOM_CARDS)
}

function getCustomCardsJson(customCards) {
    let cardfields = customCards[0].cardfields;
    cardfields = getSortableColumns(cardfields, false, COLUMN_FIELD_TYPE, DROPDOWN_FIELD);
    cardfields = setNumberFields(cardfields);
    cardfields.forEach((card) => {
        if (card["FDFNAM"] && card["FDFNAM"].trim()) {
            card.key = card.prefixFlag ? card["FDFNAM"].trim() : getListPredecessor('companys') + card[COLUMN_VALUE_ACCESSOR].trim()
        }
    });
    customCards[0].cardfields = JSON.parse(JSON.stringify(cardfields))
    return customCards;
}

const DashboardControls = (state = InitialState, action) => {
    switch (action.type) {
        case DASHBOARD_CONTROL_GET_FIELD_LIST:
            return Object.assign({}, state, { loading: true });
        case DASHBOARD_CONTROL_GET_FIELD_LIST_SUCCESS:
            let list = action.data.fields;
            let cards = prepareBaseJSONwithFieldData(list, state.CardData, COLUMN_POSITION, COLUMN_FIELD_TYPE, DROPDOWN_FIELD);
            let columnData = [];
            cards.map((formCard, index) => {
                columnData[index] = formCard;
                //Values array for a formCard are actually the fields on the card. setNumberFields will add field Metadata to them
                columnData[index].values = setNumberFields(JSON.parse(JSON.stringify(formCard.values)))
            })
            return Object.assign({}, state, { fieldData: list, CardData: columnData, loading: false });
        case DASHBOARD_CONTROL_GET_FIELD_LIST_FAILURE:
            return Object.assign({}, state, { loading: true });
        default: return { ...state }
    }
}

export default DashboardControls;
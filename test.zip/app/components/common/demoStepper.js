
/*
* * //==========================================================================
*
* * // Copyright 2021-2021, Blue Yonder Group, Inc.
*
* * // All Rights Reserved
*
* * //
*
* * // THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF
*
* * // BLUE YONDER GROUP, INC.
*
* * //
*
* * //
*
* * // The copyright notice above does not evidence any actual
*
* * // or intended publication of such source code.
*
* * //
*
* * // ===========================================================================
/* *******************************PATCH HISTORY******************************** */

/* E3C-33266 - SRK - AWR WEB UI graphs have hardcoded English labels
                     Removed hardcoding and retrieved label based on ID. 
                     (10-Nov-2021)
* * // ===========================================================================
*/

import React from 'react';
import StepperComponent from './Form/StepperComponent';
import { Button, Typography, TextField } from '@material-ui/core';
import theme from '../../jda-gcp-theme';
import { withStyles } from '@material-ui/core/styles';
import DialogComponent from './DialogComponent';
import { TEXT_OK, TEXT_NEXT, TEXT_CANCEL } from '../../containers/common/constants';

const styles = theme => ({
    showStep: {
        display: 'block'
    },
    hideStep: {
        display: 'none'
    },
    contentWrapper: {
        padding: '1rem'
    }
})
let actionsButtons = [
    {
        cancelText: TEXT_CANCEL,
        submitText: TEXT_OK,
        nextText: TEXT_NEXT
    },
    {
        cancelText: TEXT_CANCEL,
        submitText: TEXT_OK,
        nextText: TEXT_NEXT
    },
    {
        cancelText: TEXT_CANCEL,
        submitText: TEXT_OK
    }
]
const steps=['step 1', 'step 2', 'step 3'];
class DemoStepper extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            activeStep: 0,
            lastActiveStep: 0,
            completed: false,
            isOpen: true,
            disableSubmit: true,
            disableNext: true,
        }
        this.handleStepChange = this.handleStepChange.bind(this);
    }
    handleStepChange = (val) => {
        this.setState({ activeStep: val });
    }
    handleBack = () => {
        this.setState({ activeStep: this.state.activeStep - 1 });
    }
    handleNext = () => {
        if((this.state.activeStep + 1) > this.state.lastActiveStep) {
            this.setState({ lastActiveStep: this.state.activeStep + 1 });
        }
        if ((this.state.activeStep + 1) === steps.length-1) {
            this.setState({ completed: true });
        }
        this.setState({ activeStep: this.state.activeStep + 1 });
    }
    handleClose = () => {
        this.setState({ isOpen: false });
    }
    handleCancel = () => {
        this.setState({ isOpen: false });
    }
    handleSubmit = () => {
        this.setState({ isOpen: false });
    }
    setDisableFlag = () => {
        this.setState({ disableNext: false });
        this.setState({ disableSubmit: false });
    }
    render() {
        const { classes } = this.props;
        return (
            <DialogComponent
                dialogTitle={'39745'} /*E3C-33266 'Events'*/
                {...this.state.completed ? actionsButtons[steps.length-1] : actionsButtons[this.state.activeStep]}
                handleCancel={this.handleCancel}
                handleSubmit={this.handleSubmit}
                handleNext={this.handleNext}
                handleClose={this.handleClose}
                disableSubmit={this.state.disableSubmit}
                disableNext={this.state.disableNext}
                isOpen={this.state.isOpen}
            >
                <StepperComponent
                    steps={steps}
                    lastActiveStep={this.state.lastActiveStep}
                    activeStep={this.state.activeStep}
                    handleStepChange={this.handleStepChange}
                    // width={'500px'}
                >
                </StepperComponent>
                <div className={classes.contentWrapper} >
                    <div className={ this.state.activeStep === 0 ? classes.showStep : classes.hideStep}>Hii
                        <TextField onChange={this.setDisableFlag}></TextField>
                    </div>
                    <div className={ this.state.activeStep === 1 ? classes.showStep : classes.hideStep}>Hello
                    </div>
                    <div className={ this.state.activeStep === 2 ? classes.showStep : classes.hideStep}>Welcome</div>
                </div>
            </DialogComponent>
        )
    }
}

export default withStyles(styles)(DemoStepper);
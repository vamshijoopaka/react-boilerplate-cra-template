
/*
* * //==========================================================================
*
* * // Copyright 2021-2021, Blue Yonder Group, Inc.
*
* * // All Rights Reserved
*
* * //
*
* * // THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF
*
* * // BLUE YONDER GROUP, INC.
*
* * //
*
* * //
*
* * // The copyright notice above does not evidence any actual
*
* * // or intended publication of such source code.
*
* * //
*
* * // ===========================================================================
*/
import React from 'react';
import moment from 'moment';
import 'react-datepicker/dist/react-datepicker.css';
import DatePicker from 'react-datepicker';
import {ALLOWED_DATEPICKER_KEYS} from '../constants';
// import DatePicker from 'react-date-picker';

class DateTimePicker extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      startDate: new Date(),
    };
    this.datepickerRef = React.createRef();//E3C-31227:Ajit
  }

  onChangeRaw = e => {
    const m = moment(e.target.value);
    if (m.isValid()) {
      this.props.onChange(m);
    }
  };
  //E3C-31227:Ajit:Begin
  onKeyDown = (e,event) => {
    if (e.keyCode === 9 || e.which === 9) {
      this.datepickerRef.current.setOpen(false);
    }
    //E3C-31752:sravanthi:Begin
    else if(ALLOWED_DATEPICKER_KEYS.includes(e.key)){
        this.props.onChange(e, event);
        return
    }
    else 
      e.preventDefault();
    //E3C-31752:sravanthi:End
  };
  //E3C-31227:Ajit:End
  onChange = (val, event) => {
    this.props.onChange(val, event);
  };

  onInputClick = event => {
  };

  render() {
    return (
      <DatePicker
        id={this.props.id}
        ref={this.datepickerRef}//E3C-31227:Ajit
        className="myContainer"
        showMonthDropdown
        showYearDropdown
        dropdownMode="select"
        selected={
          this.props.value && this.props.value != 'Invalid date'
            ? moment(this.props.value).toDate() // ? new Date(this.props.value)
            : null
        }
        dateFormat={this.props.globalDateFormat}
        placeholderText={this.props.globalDateFormat}
        // onChange={(date) => this.setState({ startDate: date })}
        onChange={this.onChange}
        onBlur={this.onBlur}
        onKeyDown={this.onKeyDown}//E3C-31227:Ajit
        shouldCloseOnSelect={true}
        closeOnScroll
        disabled={this.props.disabled}
        onInputClick={this.onInputClick(event)}
        // popperPlacement="botom-start"
        popperModifiers={{
          flip: {
            enabled: false,
          },
          preventOverflow: {
            enabled: true,
            escapeWithReference: false,
          },
          options: {
            mainAxis: false, // true by default
          },
        }}
        isClearable={!this.props.disabled}
        disabled={this.props.disabled}
        autoComplete="off" //Removed autocomplete otherwise its displaying previous values
        // withPortal
        popperProps={{
          positionFixed: true, // use this to make the popper position: fixed,
          // options: {
          //     mainAxis: false, // true by default
          // },
        }}
      // customInput={<ExampleCustomInput />}
      />
      // <DatePicker
      //   className="form-control"
      //   selected={this.props.selected}
      //   onChange={this.props.onChange}
      //   onChangeRaw={this.onChangeRaw}
      //   dateFormat="LLL"
      // />
    );
  }
}
export default DateTimePicker;

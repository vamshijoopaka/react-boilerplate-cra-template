import React from 'react';
import FieldInput from '../Form/FieldInput';
import CustomGrid from '../../CustomGrid';
import InputText from '../Form/InputText';
import Form from 'components/common/Form/Form';
import { Button, IconButton, TextareaAutosize } from '@material-ui/core';
import { Box } from '@material-ui/core';
import { withStyles } from '@material-ui/core/styles';
import theme from '../../../jda-gcp-theme';
import { connect } from 'react-redux';
import injectReducer, { useInjectReducer } from 'utils/injectReducer';
import { compose } from 'redux';
import { range } from 'lodash';
import { expressionFieldsGridCols } from './constants';
import {
    COLUMN_HEADER_ACCESSOR,
    COLUMN_VALUE_ACCESSOR
} from '../../../components/common/constants';
import SearchIcon from '@material-ui/icons/Search';
import Addition from './../../../images/addition.png';
import Subtraction from './../../../images/subtract.png';
import Multiply from './../../../images/multiply.png';
import Division from './../../../images/divide.png';
import Forward from './../../../images/forward.png';
import OpenBracket from './../../../images/openingparenthesis.png';
import CloseBracket from './../../../images/closingparenthesis.png';
import UndoButton from './../../../images/undo.png';
import MoveArrow from '-!react-svg-loader!../../../images/MoveArrow.svg';
import {getShiftCharacter, getSpecialCharacter, isAlpha, replaceAt, findNextOccurence} from 'utils/util';
import FormattedMessageComponent from '../FormattedMessageComponent';
import { TEXT_CLEAR } from '../../../containers/common/constants';

const styles = theme => ({
    expressionInput: {
        width: '100%',
        height: '100% !important',
        backgroundColor: '#f3f3f3',
        lineHeight: 2,
        overflowY: 'auto'
    },
    expressionFieldNameBox: {
        width: '245px',
        marginLeft: '16px'
    },
    expressionBuildBox: {
        // width: 533,
        flexGrow: 1,
        height: 350,
        marginRight: 16
    },
    operatorBuilderBox: {
        display: 'flex',
        justifyContent: 'space-between',
        marginTop: 17,
        '@media (max-width: 720px)': {
            flexWrap: 'wrap'
        }
    },
    operatorBoxWrapper: {
        display: 'flex',
        marginBottom: '8px',
        flexWrap: 'wrap',
    },
    moveFieldNameOperator: {
        display: 'flex',
        alignItems: 'center',
        height: 'auto',
        margin: '0 13px'
    },
    parenthesisBox: {
        width: 68,
        height: 32,
        border: '1px solid #0066D0',
        display: 'flex',
        borderRadius: 3
    },
    parenthesisOperator: {
        width: '50%',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-around',
        cursor: 'pointer',
        '&:first-child': {
            borderRight: '1px solid #0066D0'
        }
    },
    undoBtnBox: {
        width: 32,
        height: 32,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-around',
        border: '1px solid #0066D0',
        borderRadius: 3,
        marginRight: 20
    },
    numericOperator: {
        width: '25%',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-around',
        cursor: 'pointer'
    },
    operatorBox: {
        width: 132,
        height: 32,
        marginLeft: 20,
        border: '1px solid #0066D0',
        display: 'flex',
        borderRadius: 3,
        '@media (max-width: 530px)': {
            marginLeft: '0px'
        }
    },
    disable: {
        pointerEvents: 'none',
        opacity: '0.5'
    },
    enableArrow: {
        cursor: 'pointer',
        stroke: '#0066D0'
    },
    disableArrow: {
        pointerEvents: 'none',
        stroke: '#979797'
    },
    gridLabel: {
        fontSize: '16px',
        '@media (max-width: 720px)': {
            width: '220px'
        },
        '@media (max-width: 560px)': {
            width: '180px'
        }
    }
})
class ExpressionComponent extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            expression: [],
            cursorPosition: null,
            colDefs: [],
            enableArrow: false
        }
        this.addField = this.addField.bind(this);
        this.addOperator = this.addOperator.bind(this);
        this.clearExpression = this.clearExpression.bind(this);
        this.undo = this.undo.bind(this);
        this.onKeyDown = this.onKeyDown.bind(this);
        this.backspaceAction = this.backspaceAction.bind(this);
        this.setCursorPosition = this.setCursorPosition.bind(this);
        this.onFilterTextBoxChanged = this.onFilterTextBoxChanged.bind(this);
    }
    onGridReady = (params) => {
        this.grid = params.api;
        this.grid.sizeColumnsToFit();
    }
    addField() {
        let newField = this.grid.getSelectedRows()[0];
        if (!newField) {
            return;
        }
        let expr = this.state.expression;
        expr = expr + '[' + newField[COLUMN_HEADER_ACCESSOR].trim() + ']';
        this.setState({ expression: expr });
        this.props.updateExpression(expr);
    }
    addOperator(operator) {
        let expr = this.state.expression;
        expr = expr + operator;
        this.setState({ expression: expr });
        this.props.updateExpression(expr);
    }
    clearExpression() {
        this.setState({ expression: '' });
        this.props.updateExpression('');
    }
    undo() {
        let expr = this.state.expression;
        let field = '';
        [expr, field] = this.backspaceAction(expr, expr.length);
        this.props.updateExpression(expr);
        this.setState({ expression: expr });
    }
    componentDidMount() {
        this.setState({ expression: this.props.expressionData });
    }
    componentWillMount() {
        let cols = expressionFieldsGridCols;
        cols[0].field = COLUMN_HEADER_ACCESSOR;
        this.setState({ colDefs: cols });
    }
    onKeyDown(event) {
        let expr = this.state.expression;
        let keyCode = event.keyCode || event.which;
        let field = '';
        if (keyCode === 13) {
            event.preventDefault();
            this.props.submitExpression();
        }
        else if (event.shiftKey && (keyCode && keyCode !== 16)) { // shift + key
            let insertIndex = findNextOccurence(expr, ']', event.target.selectionStart, ']');
            expr = expr.slice(0, insertIndex + 1) + getShiftCharacter(keyCode) + expr.slice(insertIndex + 1);
            this.setCursorPosition(insertIndex + 3);
        } else if (keyCode && (keyCode !== 16) && (getSpecialCharacter(keyCode))) { // special characters without pressing shift key
            let insertIndex = findNextOccurence(expr, ']', event.target.selectionStart, ']');
            expr = expr.slice(0, insertIndex + 1) + getSpecialCharacter(keyCode) + expr.slice(insertIndex + 1);
            this.setCursorPosition(insertIndex + 3);
        } else if ((keyCode <= 57) && (keyCode >= 48)) { //numbers
            let insertIndex = findNextOccurence(expr, ']', event.target.selectionStart, ']');
            expr = expr.slice(0, insertIndex + 1) + String.fromCharCode(keyCode) + expr.slice(insertIndex + 1);
            this.setCursorPosition(insertIndex + 3);
        } else if (((keyCode <= 90) && (keyCode >= 65)) || ([192, 186, 222, 219, 221, 220, 187].indexOf(keyCode) > -1)) { // alphabets
            this.setCursorPosition(event.target.selectionStart + 1);
        } else if (keyCode === 8) { // backspace
            [expr, field] = this.backspaceAction(expr, event.target.selectionStart);
        } else if (keyCode === 46) { // delete
            [expr, field] = this.backspaceAction(expr, event.target.selectionStart + 1);
        }
        else {
        }
        this.props.updateExpression(expr);
        this.setState({ expression: expr });
    }
    backspaceAction(expr, index) {
        let field = '';
        let expression = expr;
        if (!expr) {
            return ['', field];
        } else if (!expr[index - 1]) {
            return [expr, field];
        }
        let specialCharacters = ['.', ',', '+', '-', '/', '*', '(', ')', ' ', ...(range(0, 10).map(num => { return num.toString() }))];
        if (isAlpha(expression[index - 1]) || isAlpha(expression[index])) {
            let closeBracketIndex = findNextOccurence(expression, ']', index, ']');
            if (closeBracketIndex !== -1)
                [expression, field] = this.removeField(expression, closeBracketIndex);
        } else if (specialCharacters.indexOf(expression[index - 1]) > -1) {
            field = expression[index - 1];
            expression = replaceAt(expression, index - 1, '');
            this.setCursorPosition(index);
        } else if (expression[index - 1] === ']') {
            [expression, field] = this.removeField(expression, index - 1)
        }
        return [expression, field];
    }
    removeField(expression, index) {
        let field = '';
        for (let i = index; i >= 0; i--) {
            if (expression[i] === '[') {
                expression = replaceAt(expression, i, '');
                this.setState({ cursorPosition: i });
                this.setCursorPosition(i + 1);
                break;
            } else {
                field = expression[i] + field;
                expression = replaceAt(expression, i, '');
            }
        }
        field = field.replace(/\[|\]/g, '')
        return [expression, field];
    }
    setCursorPosition(index) {
        setTimeout(() => {
            var elem = document.getElementById('expression');
            if (!elem) return;
            elem.focus();
            elem.setSelectionRange(index - 1, index - 1);
        })
    }
    onFilterTextBoxChanged(e) {
        this.grid.setQuickFilter(e.target.value);
    }
    inputCursorChange = (event) => {
        if (event.target.selectionStart) {
            this.setCursorPosition(findNextOccurence(this.state.expression, ']', event.target.selectionStart, ']') + 2);
        }
    }
    onRowSelected = () => {
        this.setState({enableArrow: true });
    }
    render() {
        const { classes } = this.props;
        return (
            <Form>
                {form => (
                    <div style={{ 'display': 'flex', marginTop: 20 }}>
                        <div className={classes.expressionFieldNameBox}>
                            <Box mb={'20px'} className={classes.gridLabel}>{'Select Field'}</Box>
                            <div className={'search_box'}>
                                <IconButton className={'search_icon_placement'}>
                                    <SearchIcon></SearchIcon>
                                </IconButton>
                                <input autoComplete="off" type={"text"} id={"search_text_box"} placeholder={"Search by field name"} onKeyUp={e => this.onFilterTextBoxChanged(e)} />
                            </div>
                            <CustomGrid
                                className={'ag_grid_secondary'}
                                rowHeight={40}
                                columnData={this.state.colDefs}
                                suppressRowClickSelection={false}
                                suppressDragLeaveHidesColumns={true}
                                rowDragManaged={true}
                                onGridReady={this.onGridReady}
                                rowSelection={'single'}
                                onRowSelected={() => { this.onRowSelected() }}
                                height={'350px'}
                                rowData={this.props.columnDefs}
                                columnDefOptions={this.props.columnDefOptions}
                            >
                            </CustomGrid>
                        </div>
                        <div className={classes.moveFieldNameOperator}>
                            <MoveArrow className={this.state.enableArrow ? classes.enableArrow : classes.disableArrow} onClick={() => this.addField()} />
                        </div>
                        <div className={classes.expressionBuildBox}>
                            <div style={{fontSize: 16}}>{'Build Your Expression'}</div>
                            <Box className={classes.operatorBuilderBox}>
                                <div className={classes.operatorBoxWrapper}>
                                    <div className={classes.parenthesisBox}>
                                        <div className={classes.parenthesisOperator} onClick={() => this.addOperator('(')}><img src={OpenBracket} /></div>
                                        <div className={classes.parenthesisOperator} onClick={() => this.addOperator(')')}><img src={CloseBracket} /></div>
                                    </div>
                                    <div className={classes.operatorBox}>
                                        <div className={classes.numericOperator} onClick={() => this.addOperator('+')}><img src={Addition} /></div>
                                        <div className={classes.numericOperator} onClick={() => this.addOperator('-')}><img src={Subtraction} /></div>
                                        <div className={classes.numericOperator} onClick={() => this.addOperator('*')}><img src={Multiply} /></div>
                                        <div className={classes.numericOperator} onClick={() => this.addOperator('/')}><img src={Division} /></div>
                                    </div>
                                </div>
                                <div className={classes.operatorBoxWrapper}>
                                    <div className={classes.undoBtnBox+' '+ (!this.state.expression ? classes.disable : 'cPointer')} onClick={() => this.undo()}><img disabled={!this.state.expression} src={UndoButton} /></div>
                                    <Button size="small" color="primary" variant='outlined' className={!this.state.expression ? classes.disable : ''} onClick={() => { this.clearExpression() }}>
                                        <FormattedMessageComponent id={TEXT_CLEAR}></FormattedMessageComponent>
                                    </Button>
                                </div>
                            </Box>
                            <TextareaAutosize
                                rows={15}
                                className={classes.expressionInput}
                                id={'expression'}
                                field={{ key: 'expression', placeholder: '', type: 'text' }}
                                onChange={() => { }}
                                onKeyDown={(event) => { this.onKeyDown(event) }}
                                value={this.state.expression}
                                autoComplete={false}
                                onClick={(event) => { this.inputCursorChange(event) }}
                            />
                        </div>
                    </div>
                )}

            </Form>
        );
    }
}

const mapStateToProps = function (state) {
    return {
    }

}

function mapDispatchToProps(dispatch) {
    return {
        dispatch,
    };
}

const withConnect = connect(
    mapStateToProps,
    mapDispatchToProps,
);

export default compose(
    withConnect,
    withStyles(styles)
)(ExpressionComponent);
import React from 'react';
import { genericActions } from 'constants/genericActionMenu';
import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import ClickAwayListener from "@material-ui/core/ClickAwayListener";
import Grow from "@material-ui/core/Grow";
import Paper from "@material-ui/core/Paper";
import Popper from "@material-ui/core/Popper";
import MenuList from "@material-ui/core/MenuList";
import MenuItem from '@material-ui/core/MenuItem';
import Dialog from '@material-ui/core/Dialog';
import Draggable from 'react-draggable';
import Container from "@material-ui/core/Container";
import Menu from '@material-ui/core/Menu';
import MenuListComponent from 'components/common/MenuComponent/MenuListComponent';
import { Box } from '@material-ui/core';

const classes = makeStyles(theme => ({
    root: {
      display: 'flex',
    },
    paper: {
      marginRight: theme.spacing(2),
    },
  }));
  function PaperComponent(props) {
    return (
        <Draggable cancel={'[class*="MuiDialogContent-root"]'}>
            <Paper {...props} />
        </Draggable>
    );
}

class  GridRowButton extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            anchorEl: null,
            openNewSubMenu: null,
            openShowMeSubMenu: null,
        }
        this.openMenu = this.openMenu.bind(this);
        this.handleClose = this.handleClose.bind(this);
        this.handleItemClick = this.handleItemClick.bind(this);
        this.updateRef  =this.updateRef.bind(this);
    }
    openMenu(val) {
        this.setState({anchorEl: val.currentTarget});
        this.props.context.componentParent.openMenu({menuRef: val.currentTarget, rowIndex: this.props.node.rowIndex});
    }
    handleClose() {
        this.setState({anchorEl: null});
    }
    handleItemClick(val) {
        this.setState({anchorEl: null});
    }
    updateRef(val) {
        this.setState({anchorEl: val})
    }
    render() {
        return (
          <Box className={classes.root}>
            <Button
              ref={(ref) =>  {this.updateRef}}
              aria-controls="menu-list-grow"
              aria-haspopup="true"
              onClick={(event) => this.openMenu(event)}
            >
            More
            </Button>
            {this.state.anchorEl && <MenuListComponent itemselect={(val) => {this.handleItemClick(val);this.props.context.componentParent.handleMenuItemClick(val)}} menuitems={genericActions} onClose={(val) => this.handleClose()} menuRef={this.state.anchorEl}>
                </MenuListComponent>}
          </Box>
        )
    }
}
export default GridRowButton;
import React, { memo } from 'react';
import PropTypes from 'prop-types';
import HighchartsReact from 'highcharts-react-official';
import Highcharts from 'highcharts/highstock';

import {
    BAR_GRAPH_CONSTANTS
} from './constants';

class BarChartComponent extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            barChartData: BAR_GRAPH_CONSTANTS
        }
    }

    componentDidMount() {
        const { chartData, chartTitle, yAxisTitle, xAxisTitle } = this.props;
        let cData = JSON.parse(JSON.stringify(this.state.barChartData));
        cData.title.text = chartTitle;

        if (cData && cData.yAxis && cData.xAxis && cData.xAxis.title && cData.yAxis.title) {
            cData.yAxis.title.text = yAxisTitle;
            cData.xAxis.title.text = xAxisTitle;
        }

        this.setState({ barChartData: JSON.parse(JSON.stringify(cData)) });
    }

    componentDidUpdate(prevProps) {
        const { chartData, chartTitle } = this.props;
        let cData = JSON.parse(JSON.stringify(this.state.barChartData));
        if (JSON.stringify(chartData) != JSON.stringify(prevProps.chartData)) {
            cData.data = chartData;
            // cData.xAxis.categories = ['BLANK', 'A', 'B', 'C', '1', '2', '3', '4'];
            this.setState({ barChartData: JSON.parse(JSON.stringify(cData)) });
        }
    }

    render() {
        const { barChartData } = this.state;
        return (
            <div>
                {
                    barChartData && barChartData.data && barChartData.data.length &&
                    <HighchartsReact
                        // highcharts={Highcharts}
                        options={barChartData}
                    />
                }
            </div>
        )
    }
}

export default BarChartComponent;
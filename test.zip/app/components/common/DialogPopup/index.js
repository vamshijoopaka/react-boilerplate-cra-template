import React, { memo } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import { DialogTitle, IconButton } from '@material-ui/core';
import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import CloseIcon from '@material-ui/icons/Close';
import PaperComponent from 'components/common/PaperComponent';
import { Box } from '@material-ui/core';
import Button from '@material-ui/core/Button';
import { withStyles } from '@material-ui/core/styles';
import CloseImage from '../../../images/close.png';

const styles = theme => ({
    closeIcon: {
        position: 'absolute',
        top: '10px',
        right: '20px'
    },
    dialogWidthHeight: {
        position: 'relative'
    },
    spaceBetween: {
        display: 'flex',
        justifyContent: 'space-between'
    },
    positionLeft: {
        position: 'absolute',
        left: '16px',
        bottom: '8px',
    }
})

class DialogPopup extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            defaultOptions: {
                disableEscapeKeyDown: true
            }
        }
    }

    render() {
        const { classes, isBackArrow } = this.props;
        return (
            <div>
                <Dialog className={classes.dialogWidthHeight}
                    open={this.props.isOpen}
                    PaperComponent={PaperComponent}
                    aria-labelledby="draggable-dialog-title">
                    <DialogTitle style={{ cursor: 'move' }} id="draggable-dialog-title">
                        {isBackArrow &&
                            <IconButton onClick={this.props.handleClose}>
                                <ArrowBackIcon></ArrowBackIcon>
                            </IconButton>
                        }
                        {this.props.dialogTitle}
                        <div className={classes.closeIcon}>
                            <img onClick={this.props.handleClose} style={{ cursor: 'pointer' }} src={CloseImage} alt={'close_icon'} />
                        </div>
                    </DialogTitle>
                    <DialogContent>
                        {this.props.children}
                    </DialogContent>
                    <DialogActions>
                        {this.props.saveText && <Box>
                            <Button className={classes.positionLeft} size="large" color="primary" variant="outlined" onClick={this.props.handleSave} disabled={this.props.disableSave || false}>{this.props.saveText}</Button>
                        </Box>}
                        <Box>
                            {this.props.cancelText && <Button size="large" color="primary" variant="outlined" onClick={this.props.handleCancel}>
                                {this.props.cancelText}
                            </Button>}
                            {this.props.submitText && <Button style={{ marginLeft: '10px' }} size="large" variant="contained" color="primary" onClick={this.props.handleSubmit} disabled={this.props.disableSubmit || false}>
                                {this.props.submitText}
                            </Button>}
                        </Box>
                    </DialogActions>
                </Dialog>
            </div>
        );
    }
}

export default withStyles(styles)(DialogPopup);
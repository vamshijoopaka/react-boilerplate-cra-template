import { withStyles } from '@material-ui/core/styles';
import { ITEMS_LIST_PAGE } from 'components/common/constants';
import PropTypes from 'prop-types';
import React from 'react';
import CardComponent from '../../common/CardComponent';
import FormFieldsGenerator from '../../common/FormFieldsGenerator';
import Spinner from '../../common/Spinner';
import './styles.scss';
import 'style.scss';
import {
  UNITS_SHIPPED_CARD_KEY,
  UNITS_LOST_CARD_KEY,
  PROMOTIONAL_DEMAND_CARD_KEY,
  TOTAL_DEMAND_CARD_KEY,
  HISTORY_PERIOD_CARD_KEY,
  FORECAST_PERIOD_CARD_KEY, UNITS_SHIPPED, UNITS_LOST, TOTAL_DEMAND
} from './constants.js';
const propTypes = {
  setSaveData: PropTypes.func,
  ItemPropertiesData: PropTypes.object.isRequired,
  getApiObj: PropTypes.func.isRequired,
  getLabelValue: PropTypes.func.isRequired,
};

const style = () => ({
  pageContainer: {
    display: 'flex',
    backgroundColor: 'var(--background-app)',
    borderTop: 'none',
    padding: '16px',
  },
  pageContainerSeventy: {
    width: '100%',
  },
  card: {
    padding: '0px',
    backgroundColor: 'var(--background-content)',
    borderRadius: '4px',
    width: '100%',
    margin: '8px',
    '& .MuiCardHeader-root': {
      padding: '16px 32px'
    },
    '& .MuiCardContent-root': {
      padding: '16px 15px 10px 15px'
    }
  },
  simpleCardGroup: {
    width: '100%',
    display: 'flex',
    justifyContent: 'space-around',
  }
});

class MovementAccumulation extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      fields: false,
      values: false,
      hasError: false,
      errorId: false,
      hasHardError: false,
      totalDemand: {
        "IMA_01": Number(this.props.ItemPropertiesData.valueData.ILST01) + Number(this.props.ItemPropertiesData.valueData.ISHP01)-Number(this.props.ItemPropertiesData.valueData.IPRM01) == 0 ? "0" : Number(this.props.ItemPropertiesData.valueData.ILST01) + Number(this.props.ItemPropertiesData.valueData.ISHP01)-Number(this.props.ItemPropertiesData.valueData.IPRM01),
        "IMA_04": Number(this.props.ItemPropertiesData.valueData.ILST04) + Number(this.props.ItemPropertiesData.valueData.ISHP04)-Number(this.props.ItemPropertiesData.valueData.IPRM04)== 0 ? "0" : Number(this.props.ItemPropertiesData.valueData.ILST04) + Number(this.props.ItemPropertiesData.valueData.ISHP04)-Number(this.props.ItemPropertiesData.valueData.IPRM04),
        "IMA_12": Number(this.props.ItemPropertiesData.valueData.ILST12) + Number(this.props.ItemPropertiesData.valueData.ISHP12)-Number(this.props.ItemPropertiesData.valueData.IPRM12) == 0 ? "0" : Number(this.props.ItemPropertiesData.valueData.ILST12) + Number(this.props.ItemPropertiesData.valueData.ISHP12)-Number(this.props.ItemPropertiesData.valueData.IPRM12),
        "IMA_13": Number(this.props.ItemPropertiesData.valueData.ILST13) + Number(this.props.ItemPropertiesData.valueData.ISHP13)-Number(this.props.ItemPropertiesData.valueData.IPRM13) == 0 ? "0" : Number(this.props.ItemPropertiesData.valueData.ILST13) + Number(this.props.ItemPropertiesData.valueData.ISHP13)-Number(this.props.ItemPropertiesData.valueData.IPRM13),
        "IMA_26": Number(this.props.ItemPropertiesData.valueData.ILST26) + Number(this.props.ItemPropertiesData.valueData.ISHP26)-Number(this.props.ItemPropertiesData.valueData.IPRM26) == 0 ? "0" : Number(this.props.ItemPropertiesData.valueData.ILST26) + Number(this.props.ItemPropertiesData.valueData.ISHP26)-Number(this.props.ItemPropertiesData.valueData.IPRM26),
        "IMA_52": Number(this.props.ItemPropertiesData.valueData.ILST52) + Number(this.props.ItemPropertiesData.valueData.ISHP52)-Number(this.props.ItemPropertiesData.valueData.IPRM52) == 0 ? "0" : Number(this.props.ItemPropertiesData.valueData.ILST52) + Number(this.props.ItemPropertiesData.valueData.ISHP52)-Number(this.props.ItemPropertiesData.valueData.IPRM52),
      }

    };
  }
  componentDidMount() {
  }
  componentDidUpdate(prevProps) {
    const {valueData}=this.props.ItemPropertiesData;
    if(valueData != prevProps.ItemPropertiesData.valueData){
     let  totalDemand= {
        "IMA_01": Number(valueData.ILST01) + Number(valueData.ISHP01)-Number(valueData.IPRM01) == 0 ? "0" : Number(valueData.ILST01) + Number(valueData.ISHP01)-Number(valueData.IPRM01),
        "IMA_04": Number(valueData.ILST04) + Number(valueData.ISHP04)-Number(valueData.IPRM04)== 0  ? "0" : Number(valueData.ILST04) + Number(valueData.ISHP04)-Number(valueData.IPRM04),
        "IMA_12": Number(valueData.ILST12) + Number(valueData.ISHP12)-Number(valueData.IPRM12) == 0 ? "0" : Number(valueData.ILST12) + Number(valueData.ISHP12)-Number(valueData.IPRM12),
        "IMA_13": Number(valueData.ILST13) + Number(valueData.ISHP13)-Number(valueData.IPRM13) == 0 ? "0" : Number(valueData.ILST13) + Number(valueData.ISHP13)-Number(valueData.IPRM13),
        "IMA_26": Number(valueData.ILST26) + Number(valueData.ISHP26)-Number(valueData.IPRM26) == 0 ? "0" : Number(valueData.ILST26) + Number(valueData.ISHP26)-Number(valueData.IPRM26),
        "IMA_52": Number(valueData.ILST52) + Number(valueData.ISHP52)-Number(valueData.IPRM52) == 0 ? "0" : Number(valueData.ILST52) + Number(valueData.ISHP52)-Number(valueData.IPRM52),
      }
      this.setState({totalDemand})

    }

  }
  componentDidCatch() {
    this.setState({ hasHardError: true })
  }
  handleChangeValue = (key, val) => {
    this.props.setValueData({ key, val });
  }

  getValueData = (valueData, newValueData) => {

    if (valueData && newValueData && Object.keys(valueData).length && Object.keys(newValueData).length &&
      (JSON.parse(JSON.stringify(valueData)) !== JSON.parse(JSON.stringify(newValueData)))) {
      return newValueData;
    }
    return valueData;
  }
  render() {
    const { classes, setSaveData, globalDateFormat, filterCriteriaDetails, pageFilterOptions,
      globalFilterOptions, columnDefs, currentPage } = this.props;
    const { loading, valueData, newValueData, movementAccumLabelsData } = this.props.ItemPropertiesData;
    const { tabcards } = movementAccumLabelsData;

    if (this.state.hasHardError) {
      return <h2> Oops Something Went Wrong </h2>
    }
    return (
      <div>
        {(!loading && tabcards && tabcards.length) ? (
          <>
            <div className={classes.pageContainer}>
              <div className={classes.simpleCardGroup}>
                <div className={classes.pageContainerSeventy}>
                  <div className={classes.simpleCardGroup}>
                    {!loading &&
                      tabcards.map(formCard => {
                        if (formCard.cardkey == UNITS_LOST_CARD_KEY) {
                          return <CardComponent title={this.props.getLabelValue(UNITS_SHIPPED)} className={`${classes.card}`}>
                            <FormFieldsGenerator
                              handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                              key={formCard.cardkey}
                              parentPage={ITEMS_LIST_PAGE}
                              className="HISTORY_PERIOD_CARD_KEY"
                              fieldsArray={formCard.cardfields}
                              valuesArray={this.getValueData(valueData, newValueData)}
                              handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                              enableAddButton={(e) => { setSaveData(e) }}
                              globalDateFormat={globalDateFormat}
                              filterCriteriaDetails={filterCriteriaDetails}
                              pageFilterOptions={pageFilterOptions}
                              globalFilterOptions={globalFilterOptions}
                              columnDefs={columnDefs}
                              currentPage={currentPage}
                              parentData={valueData}
                              labelDisplayCharacters={25}
                              valueDisplayCharacters={15}
                            />
                          </CardComponent>
                        }
                      })}
                    {!loading &&
                      tabcards.map(formCard => {
                        if (formCard.cardkey == PROMOTIONAL_DEMAND_CARD_KEY) {
                          return <CardComponent title={formCard.cardtitle} className={`${classes.card}`}>
                            <FormFieldsGenerator
                              handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                              key={formCard.cardkey}
                              parentPage={ITEMS_LIST_PAGE}
                              className="HISTORY_PERIOD_CARD_KEY"
                              fieldsArray={formCard.cardfields}
                              valuesArray={this.getValueData(valueData, newValueData)}
                              handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                              enableAddButton={(e) => { setSaveData(e) }}
                              globalDateFormat={globalDateFormat}
                              filterCriteriaDetails={filterCriteriaDetails}
                              pageFilterOptions={pageFilterOptions}
                              globalFilterOptions={globalFilterOptions}
                              columnDefs={columnDefs}
                              currentPage={currentPage}
                              parentData={valueData}
                              labelDisplayCharacters={25}
                              valueDisplayCharacters={15}
                            />
                          </CardComponent>
                        }

                      })}
                    {!loading &&
                      movementAccumLabelsData.tabcards.map(formCard => {
                        if (formCard.cardkey == HISTORY_PERIOD_CARD_KEY) {
                          return <CardComponent title={formCard.cardtitle} className={`${classes.card}`}>
                            <FormFieldsGenerator
                              handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                              key={formCard.cardkey}
                              parentPage={ITEMS_LIST_PAGE}
                              className="HISTORY_PERIOD_CARD_KEY"
                              fieldsArray={formCard.cardfields}
                              valuesArray={this.getValueData(valueData, newValueData)}
                              handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                              enableAddButton={(e) => { setSaveData(e) }}
                              globalDateFormat={globalDateFormat}
                              filterCriteriaDetails={filterCriteriaDetails}
                              pageFilterOptions={pageFilterOptions}
                              globalFilterOptions={globalFilterOptions}
                              columnDefs={columnDefs}
                              currentPage={currentPage}
                              parentData={valueData}
                              labelDisplayCharacters={25}
                              valueDisplayCharacters={15}
                            />
                          </CardComponent>
                        }
                      })}
                  </div>
                  <div className={classes.simpleCardGroup}>
                    {!loading &&
                      tabcards.map(formCard => {
                        if (formCard.cardkey == TOTAL_DEMAND_CARD_KEY) {
                          return <CardComponent title={this.props.getLabelValue(UNITS_LOST)} className={`${classes.card}`}>
                            <FormFieldsGenerator
                              handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                              key={formCard.cardkey}
                              parentPage={ITEMS_LIST_PAGE}
                              className="HISTORY_PERIOD_CARD_KEY"
                              fieldsArray={formCard.cardfields}
                              valuesArray={this.getValueData(valueData, newValueData)}
                              handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                              enableAddButton={(e) => { setSaveData(e) }}
                              globalDateFormat={globalDateFormat}
                              filterCriteriaDetails={filterCriteriaDetails}
                              pageFilterOptions={pageFilterOptions}
                              globalFilterOptions={globalFilterOptions}
                              columnDefs={columnDefs}
                              currentPage={currentPage}
                              parentData={valueData}
                              labelDisplayCharacters={25}
                              valueDisplayCharacters={15}
                            />
                          </CardComponent>
                        }
                      })}
                    {!loading &&
                      tabcards.map(formCard => {
                        if (formCard.cardkey == UNITS_SHIPPED_CARD_KEY) {
                          return <CardComponent title={this.props.getLabelValue(TOTAL_DEMAND)} className={`${classes.card} `}>
                            <FormFieldsGenerator
                              handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                              key={formCard.cardkey}
                              parentPage={ITEMS_LIST_PAGE}
                              className=".HISTORY_PERIOD_CARD_KEY"
                              fieldsArray={formCard.cardfields}
                              valuesArray={this.state.totalDemand}
                              handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                              enableAddButton={(e) => { setSaveData(e) }}
                              globalDateFormat={globalDateFormat}
                              filterCriteriaDetails={filterCriteriaDetails}
                              pageFilterOptions={pageFilterOptions}
                              globalFilterOptions={globalFilterOptions}
                              columnDefs={columnDefs}
                              currentPage={currentPage}
                              parentData={valueData}
                              cardHasCheckBox={true}
                              labelDisplayCharacters={25}
                              valueDisplayCharacters={15}
                            />
                          </CardComponent>
                        }

                      })}
                    {!loading &&
                      movementAccumLabelsData.tabcards.map(formCard => {
                        if (formCard.cardkey == FORECAST_PERIOD_CARD_KEY) {
                          return <CardComponent title={formCard.cardtitle} className={`${classes.card}`}>
                            <FormFieldsGenerator
                              handleSubmitDataCallBack={this.props.handleSubmitDataCallBack}
                              key={formCard.cardkey}
                              parentPage={ITEMS_LIST_PAGE}
                              className="HISTORY_PERIOD_CARD_KEY"
                              fieldsArray={formCard.cardfields.filter(card => ["3321", "3320", "3319", "3318", "3317","3784"].find(field => field === card.FLDID))}
                              valuesArray={this.getValueData(valueData, newValueData)}
                              handleChangeValue={(key, val, field) => this.handleChangeValue(key, val, field)}
                              enableAddButton={(e) => { setSaveData(e) }}
                              globalDateFormat={globalDateFormat}
                              filterCriteriaDetails={filterCriteriaDetails}
                              pageFilterOptions={pageFilterOptions}
                              globalFilterOptions={globalFilterOptions}
                              columnDefs={columnDefs}
                              currentPage={currentPage}
                              parentData={valueData}
                              labelDisplayCharacters={25}
                              valueDisplayCharacters={15}
                            />
                          </CardComponent>
                        }
                      })}
                  </div>
                </div>
              </div>
            </div>
          </>
        ) : (<Spinner loading type="MovementAccumulationTab" />)
        }
      </div>
    );
  }
}

MovementAccumulation.propTypes = propTypes;

export default withStyles(style)(MovementAccumulation);

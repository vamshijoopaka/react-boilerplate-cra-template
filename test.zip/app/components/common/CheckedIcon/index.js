/* Vamshi J*/
import React from 'react';
import {SvgIcon} from '@material-ui/core'; 
export default function CheckedIcon(props){
    return(
      <SvgIcon {...props}>
        <path d="M5 3c-1.102 0-2 .898-2 2v14c0 1.102.898 2 2 2h14c1.102 0 2-.898 2-2V9.242l-2 2V19H5V5h11.758l2-2zm16.293.293L11 13.586l-3.293-3.293-1.414 1.414L11 16.414 22.707 4.707zm0 0" fill="#22b6e6"/>
      </SvgIcon>
    )
  }
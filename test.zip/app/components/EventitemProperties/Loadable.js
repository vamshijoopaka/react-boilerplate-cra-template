/**
 *
 * Asynchronously loads the component for EventitemProperties
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));


export const KEY_WAREHOUSE_ID = 'BWHSE';
export const KEY_BUYER_ID = 'BBUYR';
export const KEY_COMPANY_ID = 'BCOMP';
export const KEY_BUYER_NAME = 'BNAME';

export const LABEL_WAREHOUSE_ID = '33161'; // ! needs to be included in Header_ENG.json
export const LABEL_BUYER_ID = '33174'; // ! needs to be included in Header_ENG.json
export const LABEL_COMPANY_ID = '33303'; // ! needs to be included in Header_ENG.json
export const LABEL_BUYER_NAME = '36476'; // ! needs to be included in Header_ENG.json

export const KEY_NEW = 'New';

export const KEY_DELETE = 'Delete';

export const CONTEXT_MENU_BUYER_HEADER = [
  {
    label: '25250',
    key: KEY_NEW,
    hasSubMenu: false,
    isDisable: false,
  },
  {
    label: '28642',
    key: KEY_DELETE,
    hasSubMenu: false,
    isDisable: false,
  },
];

export const DEFAULT_VALUE_URL_DATA = [
  { accessor: 'COMP', operator: '=', fieldValue: '', prefixFlag: 0 },
  { accessor: 'WHSE', operator: '=', fieldValue: '', prefixFlag: 0 },
  { accessor: 'BUYR', operator: '=', fieldValue: '', prefixFlag: 0 },
];

export const LABEL_LIST_URL_DATA = [
  {
    accessor: 'TRIMBO',
    operator: '=',
    fieldValue: 'TrimBuyerUI',
    prefixFlag: 0,
  },
  { accessor: 'LANGID', operator: '=', fieldValue: 'ENG', prefixFlag: 0 },
];

export const BUYER_PROPERTIES = 'buyerProperties';

export const FILTER_DATA = ['COMP', 'VNDR', 'SUBV', 'WHSE'];

export const BRACKET_LABEL_URL_DATA = [
  { "accessor": "TRIMBO", "operator": "=", "fieldValue": "TrimCommon", "prefixFlag": 0 },
  { "accessor": "LANGID", "operator": "=", "fieldValue": "ENG", "prefixFlag": 0 }
]

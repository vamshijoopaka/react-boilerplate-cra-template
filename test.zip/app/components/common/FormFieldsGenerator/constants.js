export const filterCriteriaMenuItems = [
    {
        label: '2812',
        key: 'showHide',
        hasSubMenu: false,
        isDisable: false
    },
    {
        label: '2857',
        key: 'resetDefaults',
        hasSubMenu: false,
        isDisable: false
    }
];

export const MENU_ITEMS = [
    {
        label: '2812',
        key: 'showHide',
        hasSubMenu: false,
        isDisable: false
    }
]
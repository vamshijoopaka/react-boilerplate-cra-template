/*
ChangeLog
*LogStart - 2021.1.0.2 AWR
    E3C-33282 - J Vamshi 15-Dec-2021 :Dynamic List Height & List rows/page defaulted to 100.
*/
import React, { Component, useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';
// import { frameworkComponent } from 'containers/VendorsListPage/Json Schemas/VendorListColumns';
import vendorColumns from 'containers/VendorsListPage/Json Schemas/VendorListColumns';
import { connect } from 'react-redux';
import { compose } from 'redux';
import reducer from './reducer';
import {
    columnDefsSelector,
    errorMessageLabels,
    selectGlobalDateFormat,
    selectGlobalNumberFormat,
    selectGlobalNumberSeparator,
    selectGlobalDecimalSeparator
} from './selector';
import { updateColumnDefs } from './action';
import injectReducer, { useInjectReducer } from 'utils/injectReducer';
import { createStructuredSelector } from 'reselect';
import { VENDOR_COLUMN_HEADER_ACCESSOR, VENDOR_COLUMN_SHOW_HIDE_FLAG, VENDOR_COLUMN_VALUE_ACCESSOR, VENDOR_COLUMN_POSITION } from './../../containers/VendorsListPage/constants';
import { MASSMAINTENANCEJOB_COLUMN_HEADER_ACCESSOR, MASSMAINTENANCEJOB_COLUMN_SHOW_HIDE_FLAG, MASSMAINTENANCEJOB_COLUMN_VALUE_ACCESSOR, MASSMAINTENANCEJOB_COLUMN_POSITION } from './../../containers/MassmaintenancejobsListPage/constants';

import './styles.css';
import {
    getDateFromJulian, getMonthDateYearFormat, isColumnSortable,
    getDropdownValuesFromField, getColumnMenu, getFormattedNumber
} from 'utils/util';
import { POPUP_TIMEOUT } from 'utils/constants';
import { getErrorLabels } from 'utils/handleErrorLabels';
import moveTop from './../../images/move_top1.png';
import { frameWorkObj } from './constants';
import { COLUMN_ALIGNMENT_FIELD, COLUMN_VALUE_ACCESSOR, COLUMN_USER_SHORT_LABEL, COLUMN_USER_LONG_LABEL, COLUMN_SHORT_LABEL, COLUMN_HEADER_ACCESSOR } from '../../components/common/constants';
import ContextMenu from '../common/ContextMenu';
import GridErrorMessages from '../common/GridErrorMessages';
import { getDateFormatted } from '../common/Form/dateTimeUtils';

const labels = [COLUMN_USER_SHORT_LABEL, COLUMN_USER_LONG_LABEL, COLUMN_SHORT_LABEL, COLUMN_HEADER_ACCESSOR];

const getHeaderLabel = (coldef, headerKey) => {
    if (headerKey !== "headerName") {
        for (const label in labels) {
            if (coldef[labels[label]] && coldef[labels[label]].trim() !== '')
                return coldef[labels[label]].trim();
        }
    } else {
        if (coldef[headerKey] && coldef[headerKey].trim() !== '')
            return coldef[headerKey].trim();
    }
    return '';
}

class CustomGrid extends React.PureComponent {
    constructor(props) {
        super(props);

        let columnKey = props.columnKey ? props.columnKey : "field";
        let headerKey = props.titleKey ? props.titleKey : "headerName";
        this.state = {
            defaultColDef: {
                sortable: true,
                lockPosition: true,
                resizable: true,
                enableCellTextSelection: true,
                valueGetter: (params) => {
                    if (params.colDef[columnKey] && params.colDef[columnKey].length) {
                        let field;
                        if (props.listPredecessor && props.listPredecessor.length) {
                            let flag = Number(params.colDef[props.prefixFlag]);
                            if (!flag) {
                                field = props.listPredecessor + params.colDef[columnKey].trim();
                            } else {
                                field = params.colDef[columnKey].trim();
                            }
                        } else {
                            field = params.colDef[columnKey].trim();
                        }
                        if (params.data[field] && params.data[field].length) {
                            if (params.colDef.dataType == 'number') {
                                let value = Number(params.data[field].trim());

                                if (value) {
                                    if (params.colDef.numberType == 'integer') {
                                        value = Math.round(value);
                                    } else if (params.colDef.numberType == 'decimal') {
                                        let splittedValue = (value + '').split(this.props.globalDecimalSeparator);
                                        if (splittedValue.length > 1) {
                                            value = Number(Math.round(splittedValue[0]) + this.props.globalDecimalSeparator + splittedValue[1]);
                                        } else {
                                            value = Number(Math.round(splittedValue[0]));
                                        }
                                    }
                                }

                                if (getHeaderLabel(params.colDef, headerKey) == 'Year' || getHeaderLabel(params.colDef, headerKey) == 'Period Year')
                                    return value;
                                if (params.colDef['FDDATR'] && !params.colDef['FDDATR'].includes('G'))
                                    return getFormattedNumber(value, props.globalNumberFormat, props.globalNumberSeparator, params.colDef.precisionLength, this.props.globalDecimalSeparator, true);
                                return value
                            }
                            else if (params.colDef.dataType == 'date' && !params.colDef.isColumnEditable) {
                                let dateValue = (params.data[field] && params.data[field].trim()) ? Number(params.data[field].trim()).toString() : params.data[field].trim();
                                // return '2020010';
                                dateValue = getDateFromJulian(dateValue);
                                dateValue = Number(dateValue) ? getDateFormatted(dateValue, this.props.globalDateFormat) : "";
                                return dateValue;
                            } else if (params.colDef.dataType == 'select') {
                                return getDropdownValuesFromField(params.colDef.valueSuggestionList, params.data[field]?.trim())
                            }
                            else {

                                return params.data[field].trim();
                            }
                        }
                        else {
                            if (params.colDef.dataType == 'select')
                                return getDropdownValuesFromField(params.colDef.valueSuggestionList, params.data[field]?.trim())
                            else
                                return ""
                        }
                    }
                    return "";
                },
                headerValueGetter(params) {
                    return getHeaderLabel(params.colDef, headerKey);
                },
                getQuickFilterText: (params) => {
                    return params.data[this.props.filterByField || params.colDef.field]
                }
            },
            valueAccessor: columnKey,
            headerAccessor: headerKey,
            dataList: [],
            menuRowIndex: null,
            columnDefsFinal: [],
            visibleColumns: [],
            isOpenCOlumnMenu: null,
            menuColumn: null,

            hasError: false,
            errorMessage: false,
            errorId: false
        }
        this.onColumnResized = this.onColumnResized.bind(this);
        this.updateDisplayColumns = this.updateDisplayColumns.bind(this);
        this.gridErrorCallback = this.gridErrorCallback.bind(this);
    }

    getItemRanges = (pageSize, totalItems) => {
        return totalItems / pageSize;
    }

    setFilterDataList = (currentPage, pageSize, data, totalItems) => {
        var itemRange = this.getItemRanges(pageSize, totalItems);
        if (currentPage >= (itemRange - 1)) {
            currentPage = currentPage % itemRange;
        }
        var startPosition = (pageSize * currentPage);
        var endPosition = (pageSize * (currentPage + 1));
        var filteredItems = data.slice(startPosition, endPosition);
        this.setState({ dataList: filteredItems }, () => {
            if (this.props.gridDataChangeCallBack) {
                this.props.gridDataChangeCallBack();
            }
        });
    }

    gridErrorCallback(type, errorId, label, maxLength, precisionLength, minValue, maxValue) {
        this.setState({ hasError: true });
        this.setState({ errorId: errorId });
        let message = '';
        if (type == 'text') {
            message = getErrorLabels(errorId, label, maxLength)
        } else {
            message = getErrorLabels(errorId, label, maxLength, precisionLength, minValue, maxValue, this.props.globalDecimalSeparator)
        }
        this.setState({ errorMessage: message });

        setTimeout(() => {
            this.setState({ hasError: false });
            this.setState({ errorMessage: false });
        }, POPUP_TIMEOUT);
    }

    componentDidMount() {
        let showFlag = this.props.columnShowFlag;
        let alignField = COLUMN_ALIGNMENT_FIELD;
        // this.props.updateColumnDefs(this.props.columnData);
        let columnDefsFinal = [];
        if (this.props.columnData && this.props.columnData.length && this.props.columnData[0][this.state.valueAccessor]) {
            columnDefsFinal = this.props.columnData.map(col => Object.assign({}, col, { field: col[this.state.valueAccessor] ? col[this.state.valueAccessor].trim() : col.field }));
        } else if (this.props.columnData && this.props.columnData.length && !this.props.columnData[0][this.state.valueAccessor]) {
            columnDefsFinal = this.props.columnData;
        }
        //To Disable editable fields based on Security
        if (this.props.disableColumns) {
            columnDefsFinal = columnDefsFinal.map(col => ({ ...col, disabled: this.props.disableColumns }));
        }
        //To color the firest column value
        for (let i = 0; i < columnDefsFinal.length; i++) {
            if (this.props.isShowHideFlagReverse) {
                if (columnDefsFinal[i][showFlag] === "1") {
                    columnDefsFinal[i]['cellClass'] = 'text-color-font';
                    break;
                }
            }
            if (columnDefsFinal[i][showFlag] === "0") {
                columnDefsFinal[i]['cellClass'] = 'text-color-font';
                break;
            }
        }


        for (let i = 0; i < columnDefsFinal.length; i++) {
            if (columnDefsFinal[i][alignField] && columnDefsFinal[i][alignField].trim()) {
                let value = columnDefsFinal[i][alignField].trim();
                if (value == 'L') {
                    columnDefsFinal[i]['cellClass'] = "ag-grid-column-left";
                    columnDefsFinal[i]['headerClass'] = "ag-left-aligned-header"
                } else if (value.includes("L") || value.includes("M")) {//E3C-30319:Ajit
                    columnDefsFinal[i]['cellClass'] = "ag-grid-column-left";
                    columnDefsFinal[i]['headerClass'] = "ag-left-aligned-header"
                } else {
                    columnDefsFinal[i]['cellClass'] = "ag-grid-column-right";
                    columnDefsFinal[i]['headerClass'] = "ag-left-aligned-header"
                }

            } else if (columnDefsFinal[i]["dataType"] == 'number') {
                columnDefsFinal[i]['cellClass'] = "ag-grid-column-right";
                columnDefsFinal[i]['headerClass'] = "ag-right-aligned-header"
            } else {
                columnDefsFinal[i]['cellClass'] = "ag-grid-column-left";
                columnDefsFinal[i]['headerClass'] = "ag-left-aligned-header"
            }
        }

        // If move top row icon 
        if (this.props.moveTop) {
            columnDefsFinal.push({
                headerName: "", field: "move", width: 100,
                cellRenderer: (params) => {
                    let eGui = document.createElement('div');
                    let imageElement = document.createElement("img");
                    imageElement.id = 'moveTop'
                    imageElement.src = moveTop;
                    imageElement.style.opacity = 0;
                    imageElement.style.pointerEvents = 'none';
                    eGui.appendChild(imageElement);
                    return eGui;
                }
            })
        }
        if (this.props.hasNoFocusClass) {
            columnDefsFinal[0]['cellClass'] = "ag-cell-no-focus ag-grid-column-left";
        }
        this.setState({ columnDefsFinal: columnDefsFinal });

        this.loadGridData(this.props);
    }
    componentDidUpdate(prevProps) {
        const { disableColumns: disabled } = this.props;
        if (JSON.stringify(prevProps.columnData) != JSON.stringify(this.props.columnData)) {
            let cols = this.state.columnDefsFinal;
            cols = this.state.columnDefsFinal.map(column => {
                let check = this.props.columnData.find(c => c[COLUMN_VALUE_ACCESSOR] === column[COLUMN_VALUE_ACCESSOR]);
                if (check && check.sort && check.sort.length)
                    return Object.assign({}, column, { sort: check.sort, disabled: check.disabled || disabled });
                else {
                    delete column.sort;
                    return Object.assign({}, column, { disabled: check?.disabled || disabled });
                }
            })
            this.handleShowHideColumns();
            this.setState({ columnDefsFinal: cols });
        }
        if (disabled !== prevProps.disableColumns) {
            this.setState(({ columnDefsFinal }) => ({ columnDefsFinal: columnDefsFinal.map(col => ({ ...col, disabled })) }))
        }
    }
    componentWillUpdate(nextProps) {
        if (nextProps != undefined && (nextProps.pageParams) && (nextProps.pageParams.actualPage != this.props.pageParams.actualPage || nextProps.rowData != this.props.rowData)) {
            this.loadGridData(nextProps);
        }
        if (nextProps != undefined && !nextProps.pageParams) {
            this.loadGridData(nextProps);
        }
        //JVK for static EmbeddedList which doesn't require API hit
        if (nextProps != undefined && nextProps.pageParams && nextProps.pageParams.actualPageSize != this.props.pageParams.actualPageSize) {
            const { pageParams } = nextProps;
            this.setFilterDataList(pageParams.actualPage, pageParams.actualPageSize, nextProps.rowData, pageParams.pageSize);
        }
    }

    loadGridData = (nextProps) => {
        if (this.state.dataList.length < 0) {
            return;
        }
        if (this.checkWhetherAPICallOrNot(nextProps) && !this.props.isAPIProgress) {
            this.props.sendApi();
        } else {
            const { pageParams } = nextProps;
            if (pageParams) {
                this.setFilterDataList(pageParams.actualPage, pageParams.actualPageSize, nextProps.rowData, pageParams.pageSize);
            } else {
                this.setState({
                    dataList: nextProps.rowData
                });
            }
        }
    }

    checkWhetherAPICallOrNot = (nextProps) => {
        const { pageParams } = nextProps;
        if (!pageParams) {
            return false;
        }
        var configuredItemsCount = pageParams.pageSize;
        if (pageParams == this.props.pageParams) {
            return false;
        }
        if (pageParams.isForwardDirection) {
            var totalItemsCount = pageParams.actualPageSize * (pageParams.actualPage);
            if (totalItemsCount != 0 && (totalItemsCount % configuredItemsCount == 0)) {
                return true;
            }
        } else {
            var totalItemsCount = pageParams.actualPageSize * (pageParams.actualPage + 1);
            if (totalItemsCount % configuredItemsCount == 0) {
                return true;
            }
        }
        return false;
    }

    openMenu(val) {
        this.setState({ menuRowIndex: val.rowIndex });
    }
    openColumnMenu = (event, column) => {
        if (this.props.hasColumnMenu) {
            this.setState({ isOpenCOlumnMenu: event.currentTarget ? event.currentTarget : event, menuColumn: column });
        }
    }
    closeColumnMenu = () => {
        this.setState({ isOpenCOlumnMenu: null });
    }
    handleMenuItemClick(val) {
        switch (val.toLowerCase()) {
            case 'copy': this.copyRow();
                break;
            default: this.props.menuItemSelect(val);
                break;
        }
    }

    onColumnResized(params) {
        if (this.props.isColumnResize) {
            // params.column.colDef.headerValueGetter = (headerParams) => headerParams.colDef[this.state.valueAccessor];
            // params.api.refreshHeader();
        }
    }

    copyRow() {
        let copiedText = '';
        this.state.visibleColumns.forEach(property => {
            // for vendors list
            let field = vendorColumns.find(entry => entry.field === property);
            if ((property !== 'moreOptions') && field) {
                copiedText = copiedText + '\t' + this.state.dataList[this.state.menuRowIndex][field.name];
            }
        });
        navigator.clipboard.writeText(copiedText);
    }

    updateDisplayColumns(completeList, showCols) {
        this.setState({ visibleColumns: showCols });
        if (this.grid) {
            this.grid.columnApi.setColumnsVisible(completeList, false);
            this.grid.columnApi.setColumnsVisible(showCols, true);
            this.grid.columnApi.moveColumns(showCols, 0);
            // To prevent Column expanding
            // if (showCols && showCols.length < 5) {
            //     this.grid.api.sizeColumnsToFit();
            // }
        }
    }

    handleShowHideColumns = () => {
        let showColumns = [];
        let completeList = [];
        let showFlag = this.props.columnShowFlag;
        if (showFlag && showFlag.length) {
            this.props.columnData.forEach(col => {
                // if (col[showFlag] && col[this.state.valueAccessor] && Number(col[showFlag].trim()))
                if (col[showFlag] && Number(col[showFlag].trim()) && col[COLUMN_VALUE_ACCESSOR])
                    showColumns.push(col[this.state.valueAccessor].trim());
                (col[this.state.valueAccessor] && completeList.push(col[this.state.valueAccessor].trim()));

            })
            this.updateDisplayColumns(completeList, showColumns);
        }
    }

    onGridReady = (params) => {
        this.grid = params;
        this.props.onGridReady(params);
        this.handleShowHideColumns();
    }

    isRowSelectable = (params) => {
        if (this.props.disableRowFlag && params.data.accessor && this.props.disableAccessor.includes(params.data.accessor)) {
            return false;
        }
        return true;
    }

    postSort = (sort) => {
        if (this.props.postSort) {
            this.props.postSort(this.props.hasCustomHeader ? sort : false);
        }
    }
    handleColItemSelection = (val) => {
        this.closeColumnMenu();
        this.props.handleColItemSelection(val, this.state.menuColumn);
    }
    render() {
        return (
            <div style={{ height: '100%' }}>{/* E3C-33282, J Vamshi, 15-Dec-2021 */}
                {(this.state.hasError && this.state.errorMessage) ? <div>
                    <GridErrorMessages
                        errorMessageLabels={this.props.errorMessageLabels}
                        id={this.state.errorId}
                        replaceValues={this.state.errorMessage} />
                </div> : ''}
                <div style={{ width: this.props.width || '100%', height: this.props.height || '100%' }}>{/* E3C-33282, J Vamshi, 15-Dec-2021 */}
                    <div
                        id="myGrid"
                        style={{ height: '100%', width: '100%' }}
                        className={'ag-theme-balham ' + (this.props.className || 'ag_grid_primary') + ' ' + (this.props.focusClass ? this.props.focusClass : '')}
                        onDragOver={(e) => { e.preventDefault() }}
                        onDragStart={(e) => { this.props.onDragStart ? this.props.onDragStart(e) : '' }}
                        onDrop={this.props.onDrop}>
                        <AgGridReact
                            onClickLink={this.props.onClickLink}
                            gridCallBack={this.gridErrorCallback}
                            errorMessageLabels={this.props.errorMessageLabels}
                            listPredecessor={this.props.listPredecessor}
                            sendAPIcallOnChange={this.props.sendAPIcallOnChange}
                            onValueChanged={this.props.onValueChanged}
                            isColumnResize={this.props.isColumnResize}
                            onColumnResized={this.onColumnResized}
                            suppressRowClickSelection={this.props.suppressRowClickSelection}
                            rowSelection={this.props.rowSelection}
                            animateRows={this.props.animateRows || true}
                            rowDragManaged={this.props.rowDragManaged}
                            suppressDragLeaveHidesColumns={this.props.suppressDragLeaveHidesColumns}
                            onRowDoubleClicked={this.props.onRowDoubleClicked}
                            defaultColDef={this.props.defaultColDef || this.state.defaultColDef}
                            columnDefs={this.state.columnDefsFinal}
                            rowData={this.state.dataList}
                            frameworkComponents={this.props.frameworkComponent}
                            context={{ componentParent: this }}
                            rowHeight={this.props.rowHeight || 40}
                            headerHeight={this.props.headerHeight || 45}
                            onRowSelected={this.props.onRowSelected}
                            onCellFocused={this.props.onCellFocused}
                            onRowClicked={this.props.onRowClicked}
                            onCellClicked={this.props.onCellClicked}
                            onRowDragEnter={this.props.onRowDragEnter}
                            onSelectionChanged={this.props.onSelectionChanged}
                            onCellValueChanged={this.props.onCellValueChanged}
                            onRowDragEnd={this.props.onRowDragEnd}
                            onGridReady={(params) => this.onGridReady(params)}
                            singleClickEdit={this.props.singleClickEdit}
                            rowMultiSelectWithClick={this.props.rowMultiSelectWithClick}
                            isRowSelectable={this.isRowSelectable}
                            rowClassRules={this.props.rowClassRules}
                            enableCellTextSelection={true}
                            postSort={this.postSort}
                            globalNumberFormat={this.props.globalNumberFormat}
                            globalNumberSeparator={this.props.globalNumberSeparator}
                            globalDecimalSeparator={this.props.globalDecimalSeparator}
                        />
                    </div>
                </div>
                {Boolean(this.state.isOpenCOlumnMenu) &&
                    <ContextMenu menuList={getColumnMenu(this.props.colMenuItems, this.state.menuColumn)} isOpen={Boolean(this.state.isOpenCOlumnMenu)}
                        handleItemSelection={this.handleColItemSelection} handleMenuClose={(val) => this.closeColumnMenu(val)} menuRef={this.state.isOpenCOlumnMenu}></ContextMenu>
                }
            </div>
        );
    }
}

CustomGrid.propTypes = {
    rowHeight: PropTypes.any,
    headerHeight: PropTypes.any,
    className: PropTypes.any, // value : 'ag_grid_secondary' & 'ag_grid_tertiary'  default value: ag_grid_primary
    columnData: PropTypes.any.isRequired,
    rowData: PropTypes.any.isRequired,
    rowSelection: PropTypes.any,
    moveTop: PropTypes.bool,
    onRowClicked: PropTypes.func,
    onCellClicked: PropTypes.func,
    onRowSelected: PropTypes.func,
    onCellValueChanged: PropTypes.func,
    animateRows: PropTypes.any,
    rowDragManaged: PropTypes.any,
    suppressDragLeaveHidesColumns: PropTypes.any,
    onRowDoubleClicked: PropTypes.func,
    defaultColDef: PropTypes.any,
    frameworkComponent: PropTypes.any,
    context: PropTypes.any,
    onGridReady: PropTypes.any,
    onRowDragEnd: PropTypes.any,
    onRowDragEnter: PropTypes.any,
    suppressRowClickSelection: PropTypes.any,
    updateDisplayColumns: PropTypes.func,
    listPredecessor: PropTypes.any,
    prefixFlag: PropTypes.any,
    disableRowFlag: PropTypes.any,
    disableAccessor: PropTypes.any,
    rowMultiSelectWithClick: PropTypes.bool,
    singleClickEdit: PropTypes.bool,
    postSort: PropTypes.func,
    hasCustomHeader: PropTypes.bool,
    hasColumnMenu: PropTypes.bool,
    colMenuItems: PropTypes.any,
    handleColItemSelection: PropTypes.func,
    onDrop: PropTypes.any,
    onDragStart: PropTypes.any,
    onRowDragStart: PropTypes.any
};


function mapDispatchToProps(dispatch) {
    return {
        dispatch,
        updateColumnDefs: (data) => dispatch(updateColumnDefs(data))
    }
}


const mapStateToProps = (state) => {
    return {
        errorMessageLabels: errorMessageLabels(state),
        globalDateFormat: selectGlobalDateFormat(state),
        globalNumberFormat: selectGlobalNumberFormat(state),
        globalNumberSeparator: selectGlobalNumberSeparator(state),
        globalDecimalSeparator: selectGlobalDecimalSeparator(state)
        // columnDefsFinal: columnDefsSelector(state)
    }
}

// const withReducer = injectReducer({ key: 'customGrid', reducer });

const withConnect = connect(
    mapStateToProps,
    mapDispatchToProps,
);
export default compose(
    // withReducer,
    withConnect
)(CustomGrid);
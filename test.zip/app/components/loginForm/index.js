/**
 *
 * Loginform
 *
 */
/*
ChangeLog
*LogStart - 2021.1.0.2 AWR
    E3C-33282 - J Vamshi 15-Dec-2021 :Dynamic List Height & List rows/page defaulted to 100.
*/
import React, { useState, useEffect } from 'react';
import { compose } from 'redux';
import { FormattedMessage } from 'react-intl';
import { AgGridReact } from 'ag-grid-react';
import BlueYonderIcon from '../../images/logo-blueyonder-M.png';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';
import FormattedMessageComponent from '../common/FormattedMessageComponent';
import Spinner from 'components/Common/Spinner';
import GridErrorMessages from '../common/GridErrorMessages';

import { isEqual } from 'lodash';

import CardComponent from '../common/CardComponent';
import TextField from '@material-ui/core/TextField';
import {
    withStyles,
    Card,
    CardHeader,
    CardContent,
    Paper,
    Button,
    Link,
} from '@material-ui/core';
import {
    TEXT_EXPRESSION_EDITOR,
    TEXT_CANCEL,
    TEXT_OK,
    BASE_FRAMEWORK,
} from '../../containers/common/constants';
import DialogComponent from '../common/DialogComponent';
import ConfirmationDialog from '../common/ConfirmationDialog';
import DialogPopup from '../common/DialogPopup';


import Grid from '@material-ui/core/Grid';
const width = 320;

const style = theme => ({
    MuiInput: {
        root: {
            maxWidth: '280px',
            minWidth: '280px'
        }
    },
    loginContainer: {
        display: 'flex',
        flexDirection: 'column',
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
    },
    loginCard: {
        width: '328px',
        height: '192px',
        backgroundColor: '#F0F2FA',
        borderRadius: '4px'
    },
    textField: {
        width: '280px',
        marginLeft: '24px',
        marginRight: '24px',
        height: '48px',
        minWidth: '280px',
        maxWidth: '280px'
    },
    serverTextField: {
        marginTop: '24px',
        marginLeft: '24px',
        marginRight: '24px',
        width: '280px',
        maxWidth: '280px'
    },
    userTextField: {
        marginTop: '4px',
        marginLeft: '24px',
        marginRight: '24px'
    },
    passwordTextField: {
        marginTop: '4px',
        marginLeft: '24px',
        marginRight: '24px'
    },
    loginButton: {
        width: '280px',
        padding: '8px 16px',
        backgroundColor: '#047ABC',
        marginTop: '16px',
        marginBottom: '24px',
        marginLeft: '24px',
        marginRight: '24px',
        fontSize: '14px',
        color: '#FFFFFF',
        textAlign: "center"

    },
    paper: {
        display: 'flex',
        flexDirection: 'column',
        marginTop: '40px',

        width: '328px',
        height: '260px',
        backgroundColor: '#F0F2FA',
        borderRadius: '4px',
    },
    changePassword: {
        marginTop: '8px'
    },
    dialogMessageComponent: {

    },
    errorText: {
        fontSize: '14px',
        color: '#EA1515',
        marginLeft: '24px',
        marginBottom: '0px',
        marginTop: '8px'
    },
    copyRightImage: {
        position: 'absolute',
        top: '90%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
    },
    copyRightText: {
        marginTop: '16px',
        // marginLeft: '32px'
        marginLeft: '12px'
    },
    blueYonderIcon: {
        // width: "253px",
        // height: "30px",
        marginLeft: '24px',
        marginRight: '24px'

    }
});

class LoginForm extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            userName: '',
            password: '',
            server: '',
            openChangePassword: false,
            openErrorDialog: false,
            localErrorMessageID: 230,
            confirmationDialogMsgID: 210,
            passwordErrorMessageID: 210,
            hasLocalError: false,
            openPwdExpDlg: true,
            year: new Date().getFullYear(),
        };

        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.changePasswordEventHandler = this.changePasswordEventHandler.bind(this);
        this.handleClose = this.handleClose.bind(this);
        this.handleOK = this.handleOK.bind(this);
        this.onOkChangePassword = this.onOkChangePassword.bind(this);

    }

    componentDidMount() {
        // if (this.props.history.location.state) {
        //     let loginUser = JSON.parse(this.props.history.location.state);
        //     this.setState({ userName: loginUser.userName });
        //     this.setState({ server: loginUser.serverName });
        // }

    }

    componentDidUpdate(prevProps, prevState) {
        if (this.props.loginPage.loginInfo.token != undefined && this.props.loginPage.loginInfo.token != prevProps.loginPage.loginInfo.token) {
            if (!(parseInt(this.props.loginPage.loginInfo.pwdExpDays) &&
                parseInt(this.props.loginPage.loginInfo.pwdExpDays) > 0 &&
                parseInt(this.props.loginPage.loginInfo.pwdExpDays) <= 14
            )) {
                this.props.setLoginState({ loginSuccess: true, user: this.props.loginPage.loginInfo.userId });

            } else
                this.props.clearLoading();

        }

    }
    handleSubmit = (e) => {
        e.preventDefault();
        if ((this.state.server != undefined && this.state.userName != undefined && this.state.password != undefined) && (this.state.server == '' || this.state.userName == '' || this.state.password == '')) {
            if (this.state.server == '') {
                this.setState({
                    hasLocalError: true,
                    localErrorMessageID: 229 // Please server name.
                })
            } else if (this.state.userName == '' || this.state.password == '') {
                this.setState({
                    hasLocalError: true,
                    localErrorMessageID: 230 // Please Enter User Name or password.
                })
            }
        } else {
            this.setState({ hasLocalError: false });
            let user = {
                "userName": this.state.userName,
                "password": this.state.password,
                "serverName": this.state.server
            }
            this.setState({ openPwdExpDlg: true });
            this.props.clearLoginState(true);
            this.props.resetNightJobStatus();//E3C-31117:Ajit Fixing errors during session expiry and displaying night job errors
            this.props.verifyLogin(user);
        }
    };
    handleChange = e => {
        this.props.clearServerError();
        if (e.target.name == "userName") {
            this.setState({ userName: e.target.value.toUpperCase() })//E3C-31117:Ajit converted to upper case
        } else if (e.target.name == "serverName") {
            this.setState({ server: e.target.value })
        }
        else {
            this.setState({ password: e.target.value })
        }


    };
    onOkChangePassword = () => {
        this.setState({ openChangePassword: false });
        console.log('request to changepassword');
    };
    changePasswordEventHandler = e => {

        if ((this.state.userName != undefined && this.state.server != undefined) && (this.state.userName == '' || this.state.server == '')) {
            if (this.state.server == '') {
                this.setState({
                    hasLocalError: true,
                    localErrorMessageID: 229
                })
            } else if (this.state.userName == '') {
                this.setState({
                    hasLocalError: true,
                    localErrorMessageID: 231
                })
            }


        } else {
            this.props.history.push({
                pathname: '/changePassword',
                state: JSON.stringify({ userName: this.state.userName, serverName: this.state.server })
            })
        }


        e.preventDefault();
    };
    handleClose = () => {
        this.setState({ openErrorDialog: false })
        this.setState({ openPwdExpDlg: false });
        this.props.clearLoginSuccess();
        if ((parseInt(this.props.loginPage.loginInfo.pwdExpDays) &&
            parseInt(this.props.loginPage.loginInfo.pwdExpDays) > 0 &&
            parseInt(this.props.loginPage.loginInfo.pwdExpDays) <= 14
        ))
            this.props.setLoginState({ loginSuccess: true, user: this.props.loginPage.loginInfo.userId });

    };

    handleCancel = () => {
        this.setState({ openPwdExpDlg: false });
        //this.props.clearLoginSuccess();
        this.props.setLoading();
        this.props.clearLoginInfo();
        if ((parseInt(this.props.loginPage.loginInfo.pwdExpDays) &&
            parseInt(this.props.loginPage.loginInfo.pwdExpDays) > 0 &&
            parseInt(this.props.loginPage.loginInfo.pwdExpDays) <= 14
        ))
            this.props.setLoginState({ loginSuccess: true, user: this.props.loginPage.loginInfo.userId });
    }

    handleOK = () => {
        this.setState({ openErrorDialog: false })
        this.props.resetLoginState();
        this.props.history.push({
            pathname: '/changePassword',
            state: JSON.stringify({ userName: this.state.userName, serverName: this.state.server })
        })
    }


    render() {
        const { classes, errorMessageLabels } = this.props;
        const { loading } = this.props.loginPage;
        let pwdExpiryDays = parseInt(this.props.loginPage.loginInfo.pwdExpDays);

        return (
            <React.Fragment>
                {loading && <Spinner loading type='loading Login' />}
                <div>

                    {(pwdExpiryDays) && (pwdExpiryDays > 0 && pwdExpiryDays <= 14) ? <div>

                        <ConfirmationDialog
                            isOpen={this.state.openPwdExpDlg}
                            hasWarning={true}
                            dialogTitle={'52891'}
                            cancelText={TEXT_CANCEL}
                            submitText={TEXT_OK}
                            handleClose={this.handleClose}
                            handleCancel={this.handleCancel}
                            isBackArrow={false}
                            handleSubmit={this.handleOK}>
                            <div>{
                                this.props.errorMessageLabels[`E99941`]?.MTEXT.trim().replace('%1', pwdExpiryDays)


                            }</div>
                        </ConfirmationDialog>
                    </div> : ''
                    }
                    {(this.props.loginPage.serverErrorInfo) ? <div>

                        <ConfirmationDialog
                            isOpen={true}
                            hasWarning={true}
                            dialogTitle={'52891'}
                            cancelText={TEXT_CANCEL}
                            submitText={TEXT_OK}
                            handleClose={this.handleClose}
                            handleCancel={this.handleClose}
                            isBackArrow={false}
                            handleSubmit={this.handleOK}>
                            <div>{this.props.loginPage.serverErrorInfo.ERRMSG1}</div>
                        </ConfirmationDialog>
                    </div> : ''
                    }


                    <div className={classes.loginContainer} id="loginContainer">{/* E3C-33282, J Vamshi, 15-Dec-2021 */}
                        <img className={classes.blueYonderIcon}
                            src={BlueYonderIcon}
                            alt="jdaicon"
                        />
                        <Paper title="Login" className={classes.paper} >
                            <form onSubmit={this.handleSubmit}>
                                <TextField
                                    className={`${classes.textField} ${classes.serverTextField}`}
                                    id="standard-basic" label={<FormattedMessageComponent id={36642}></FormattedMessageComponent>} name="serverName"
                                    style={{ width }}
                                    onChange={e => this.handleChange(e)}
                                    value={this.state.server}
                                    InputProps={{
                                        style: {
                                            minWidth: '280px',
                                            maxWidth: '280px',
                                            width: '280px'
                                        },
                                    }} />
                                <TextField
                                    onChange={e => this.handleChange(e)}
                                    value={this.state.userName}
                                    className={`${classes.textField} ${classes.userTextField}`}
                                    InputProps={{
                                        style: {
                                            minWidth: '280px',
                                            maxWidth: '280px',
                                            width: '280px',
                                        },
                                    }} id="standard-basic" label={<FormattedMessageComponent id={2349}></FormattedMessageComponent>} name="userName" />
                                <TextField
                                    onChange={e => this.handleChange(e)}
                                    value={this.state.password}
                                    className={`${classes.textField} ${classes.passwordTextField}`} InputProps={{
                                        style: {
                                            minWidth: '280px',
                                            maxWidth: '280px',
                                            width: '280px'
                                        },
                                    }} type="password" id="standard-basic" label={<FormattedMessageComponent id={2218}></FormattedMessageComponent>} name="password" />

                                {(this.state.hasLocalError && errorMessageLabels) ? <div className={classes.errorText}>
                                    {

                                        this.props.errorMessageLabels[`E${this.state.localErrorMessageID}`].MTEXT.trim()}

                                </div> : ''}


                                <Button type="submit" onClick={this.handleSubmit} text={{ textAlign: 'center' }} className={classes.loginButton} variant="contained" color="primary" >{<FormattedMessageComponent id={25466}></FormattedMessageComponent>}</Button>
                            </form>

                        </Paper>

                        <Link href="" variant="body2" className={classes.changePassword} onClick={this.changePasswordEventHandler} >
                            <FormattedMessageComponent id={53328}></FormattedMessageComponent>
                        </Link>


                    </div >
                    <div className={classes.copyRightImage}>
                        <img
                            src={BlueYonderIcon}
                            // width="200px"
                            height="24px"
                            style={{
                                marginLeft: '24px', marginRight: '24px'
                            }}
                            alt="jdaicon"
                        />
                        <div className={classes.copyRightText}>{this.state.year} Blue Yonder Group, Inc</div>
                    </div>
                </div >
            </React.Fragment>
        );





    }
}

LoginForm.propTypes = {};

export default withStyles(style)(LoginForm);

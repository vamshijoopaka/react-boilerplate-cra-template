import React, { Component } from 'react';
import { withStyles, Tab, AppBar, Tabs, Button, Box } from '@material-ui/core';
import { compose } from 'redux';
import KeyboardArrowUpIcon from '@material-ui/icons/KeyboardArrowUp';
import KeyboardArrowDownIcon from '@material-ui/icons/KeyboardArrowDown';
import FormattedMessageComponent from '../common/FormattedMessageComponent';
import ContextMenu from '../common/ContextMenu';
import ContextMenuCreateNew from '../common/ContextMenuCreateNew';
import SaveIcon from '@material-ui/icons/Save';
import MoreVertIcon from '@material-ui/icons/MoreVert';
import FilterIcon from "../../images/icon_filter.png";
import { getDateFromJulian } from 'utils/util';
import { getDateFormatted } from "components/common/Form/dateTimeUtils";
import withFixedPosition from 'containers/common/withFixedPosition';
import { onChangeContextMenu, updateBreadCrumbContextMenu } from 'utils/contextMenu';
import { DEALS_LIST_PAGE } from 'components/common/constants';
import BreadcrumbContextMenu from 'components/common/BreadcrumbContextMenu';
import { LABEL_NOTE } from './DealNotes/constants';
import { Badge } from '@material-ui/core';
import { BADGE_MAX_COUNT } from 'components/common/constants';
import {
	LABEL_VENDOR_ID,
	LABEL_SUB_VENDOR_ID,
	LABEL_VENDOR_NAME,
	LABEL_WAREHOUSE_NAME,
	LABEL_WAREHOUSE_ID,
	LABEL_DEAL,
	LABEL_DEAL_CREATION_DATE, CONTEXT_MENU_DEAL_ACTIONS,
	LABEL_COPY, LABEL_DELETE, CONTEXT_MENU_HEADER_DEAL_ACTIONS,
	LABEL_ACTIONS
} from "./constants";


const style = theme => ({
	propertiesContentWrapper: {
		margin: '10px auto',
		borderRadius: '4px',
		overflow: 'hidden',
		boxShadow: '0 2px 4px var(--secondary-s10)',
		overflowX: 'auto'
	},
	propertiesHeaderContainer: {
		width: '100%',
		marginBottom: '1.5rem',
		backgroundColor: 'var(--background-app)',
		borderRadius: '4px',
		borderTopLeftRadius: '0px',
		borderTopRightRadius: '0px',
		overflow: 'hidden',
		boxShadow: '0 4px 4px var(--secondary-s10)',
		overflowX: 'auto'
	},
	boookingDetailContainer: {
		display: 'flex',
		width: '100%',
		backgroundColor: 'var(--background-content)',
		fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
		alignItems: 'center',
		padding: '0 0 0 24px',
		position: 'relative',
		minWidth: '630px'
	},
	boookingDetailDetailsWrapper: {
		width: '100%',
		display: 'flex',
	},
	pageContainer: {
		display: 'flex',
		backgroundColor: 'var(--background-app)',
		borderTop: 'none',
		padding: '10px 10px',
	},
	card: {
		padding: '0px',
		backgroundColor: 'var(--background-content)',
		borderRadius: '4px',
		width: '100%',
		margin: '10px',
		'& .MuiCardHeader-root': {
			padding: '22px 20px 0 20px'
		},
		'& .MuiCardContent-root': {
			padding: '16px 15px 10px 15px'
		}
	},
	DealReferences: {
		position: 'absolute',
		right: '3rem',
		bottom: '0px',
		'&& .MuiBadge-root': {              //Styling for Badge
			'& .MuiBadge-badge': {
				fontSize: '0.6 rem',
				padding: '2px 5px',
				height: '13.5px',
				minWidth: props => (props.notesCountWidth || '21px'),
			}
		}
	},
	marginLeftZero: {
		marginLeft: '0',
	},
	boookingArrow: {
		padding: '0 !important',
		margin: '0',
		minWidth: '16px',
		background: 'none',
		height: '16px',
		width: '16px',
	},
	bookingArrowWrapper: {
		display: 'flex',
		flexDirection: 'column',
		border: '1px solid var(--primary-default)',
		borderRadius: '4px',
		justifyContent: 'center',
		alignItems: 'baseline',
		height: '38px',
		marginTop: '24px',
		padding: '2px',
	},
	vendorDetailRow: {
		width: '75%',
		display: 'flex',
		flexWrap: 'wrap',
		padding: '0px 0 24px 0',
		paddingLeft: '15px'
	},
	vendorDetail: {
		padding: '0px 0px 0 0px',
		lineHeight: '1.1',
	},
	vendorIDBlock: {
		display: 'flex',
	},
	vendorIdDetails: {
		width: '15ch',
		padding: '0 30px 0 0px',
		lineHeight: '1.1'
	},
	vendorLabel: {
		color: 'var(--header-label-color)',
		paddingBottom: '6px',
		width: '20ch',
	},
	vendorSubVendorDetails: {
		display: 'flex',
		flexDirection: 'column',
		width: '16ch',
		padding: '0 30px 0 0px',
		lineHeight: '1.1'
	},
	nameField: {
		paddingTop: '32px'
	},
	vendorValue: {
		color: 'var(--value)',
	},
	vendorIDSubID: {
		paddingRight: '24px',
		paddingTop: '24px'
	},
	IdNameBlock: {
		paddingTop: '24px',
		paddingRight: '40px',
	},
	bookingActions: {
		top: '24px',
		padding: '0px 20px 20px 20px',
		right: '16px',
		display: 'flex',
		position: 'absolute',
		alignItems: 'center',
		justifyContent: 'space-between',
		'@media (max-width: 1220px)': {
			flexWrap: 'wrap',
			width: '250px'
		}
	},
	buttonActions: {
		display: 'flex',
		alignItems: 'center',


		'@media (max-width: 1220px)': {
			marginBottom: '20px'
		},
		'& .MuiButton-root': {
			borderRadius: '4px',
			fontSize: '14px',
			width: '120px',
			lineHeight: '14px',
		},
		'& .MuiButton-sizeLarge': {
			fontSize: '18px',
		},
		'& .MuiButton-sizeSmall': {
			fontSize: '12px',
			padding: '8px 16px',
		},
		'& .MuiButton-containedPrimary': {
			backgroundColor: theme.palette.primary.default,
			border: '1px solid rgba(0, 0, 0, 0)',
			boxShadow: 'none',
			color: 'var(--background-content)',
			'&:hover': {
				backgroundColor: theme.palette.primary.hover,
				color: 'var(--background-content)',
				border: '1px solid rgba(0, 0, 0, 0)',
			},
			'&:focus': {
				backgroundColor: theme.palette.primary.focus,
				color: 'var(--background-content)',
				border: '1px solid rgba(0, 0, 0, 0)',
			},
			'&:active': {
				backgroundColor: theme.palette.primary.active,
				color: 'var(--background-content)',
				border: '1px solid rgba(0, 0, 0, 0)',
			}
		},
		'& .MuiButton-containedSecondary': {
			backgroundColor: 'var(--background-content)',
			border: '1px solid var(--button-tertiary-color)',
			color: 'var(--button-tertiary-color)',
			boxShadow: '0px 4px 14px rgba(0, 0, 0, 0.05)',
			'&:hover': {
				backgroundColor: 'var(--background-content)',
				color: 'var(--button-tertiary-hover-color)',
				border: '1px solid var(--button-tertiary-hover-color)',
			},
			'&:focus': {
				backgroundColor: 'var(--background-content)',
				color: 'var(--button-tertiary-focused)',
				border: '1px solid var(--button-tertiary-focused)',
			},
			'&:active': {
				backgroundColor: 'var(--background-content)',
				color: 'var(--button-tertiary-hover-color)',
				border: '1px solid var(--button-tertiary-hover-color)',
			},
			'&.Mui-disabled': {
				color: theme.palette.primary.disabled,
				textDecoration: 'unset',
				backgroundColor: 'unset',
				textShadow: 'unset'
			}
		},
		'& .MuiButton-outlinedPrimary': {
			border: `${'1px solid '}${theme.palette.primary.default}`,
			boxShadow: '0px 4px 14px rgba(0, 0, 0, 0.05)',
			backgroundColor: 'var(--background-content)',
			color: theme.palette.primary.default,
			'&:hover': {
				backgroundColor: 'var(--background-content)',
				border: '1px solid var(--button-secondary-hover-border)',
				color: 'var(--button-secondary-hover-border)',
			},
			'&:focus': {
				backgroundColor: 'var(--background-content)',
				border: `${'1px solid '}${theme.palette.primary.default}`,
				color: theme.palette.primary.default
			},
			'&:active': {
				backgroundColor: 'var(--background-content)',
				border: '1px solid var(--primary-button-pressed)',
				color: 'var(--primary-button-pressed)'
			},
			'&.Mui-disabled': {
				color: theme.palette.primary.disabled,
				textDecoration: 'unset',
				backgroundColor: 'unset',
				textShadow: 'unset'
			}
		},
		'& .MuiButton-outlinedSecondary': {
			backgroundColor: 'var(--background-content)',
			border: '1px solid var(--button-tertiary-color)',
			color: 'var(--button-tertiary-color)',
			boxShadow: '0px 4px 14px rgba(0, 0, 0, 0.05)',
			'&:hover': {
				backgroundColor: 'var(--background-content)',
				color: 'var(--button-tertiary-hover-color)',
				border: '1px solid var(--button-tertiary-hover-color)',
			},
			'&:focus': {
				backgroundColor: 'var(--background-content)',
				color: 'var(--button-tertiary-focused)',
				border: '1px solid var(--button-tertiary-focused)',
			},
			'&:active': {
				backgroundColor: 'var(--background-content)',
				color: 'var(--button-tertiary-hover-color)',
				border: '1px solid var(--button-tertiary-hover-color)',
			},
			'&.Mui-disabled': {
				color: theme.palette.primary.disabled,
				textDecoration: 'unset',
				backgroundColor: 'unset',
				textShadow: 'unset'
			}
		},
	},
	bookingActionsFilter: {
		minWidth: '37px',
		border: '1px solid var(--primary-default)',
		height: '32px',
		marginLeft: '15px',
		'@media (max-width: 1220px)': {
			marginLeft: '0px'
		},
		'& img': {
			width: '14px',
			height: '14px'
		},
		'& svg': {
			width: '18px',
			height: '18px'
		}
	},
	menuButton: {
		minWidth: '37px',
		border: '1px solid var(--primary-default)',
		height: '32px',
		marginLeft: '15px',
		borderRadius: '4px',
		display: 'flex',
		alignItems: 'center',
		justifyContent: 'center',
		'@media (max-width: 1220px)': {
			marginLeft: '0px'
		},
	},
	adjustCardFieldsInline: {
		display: 'grid !important',
		width: '100%',
		gridTemplateColumns: 'auto auto',
		paddingRight: '22px'
	},
	buttonActionsSecondChild: {
		marginRight: '15px',
		'& .MuiButton-outlinedPrimary': {
			width: '100%',
			height: '28px'
		}
	},
});

class Header extends Component {
	constructor(props) {
		super();
		this.state = {
			contextMenuList: [...CONTEXT_MENU_DEAL_ACTIONS],
			isOpenActionsContextMenu: false,
			menuRef: null,
			actionList: [...CONTEXT_MENU_HEADER_DEAL_ACTIONS],
			isOpenActions: false,
			actionMenuRef: null,
		}
		this.getLabelValue = this.getLabelValue.bind(this);
		this.setIsOpenActionsContextMenu = this.setIsOpenActionsContextMenu.bind(this);
		this.setIsOpenActionsButtonContextMenu = this.setIsOpenActionsButtonContextMenu.bind(this);
		this.onClickDownArrow = this.onClickDownArrow.bind(this);
		this.onClickUpArrow = this.onClickUpArrow.bind(this);
	}
	getLabelValue(id) {
		return <FormattedMessageComponent id={id}></FormattedMessageComponent>;
	}
	handleDisableUpArrow = () => {
		const { hasPrevious, fromListPage } = this.props;
		return !hasPrevious || fromListPage != DEALS_LIST_PAGE;
	};

	handleDisableDownArrow = () => {
		const { hasNext, fromListPage } = this.props;
		return !hasNext || fromListPage != DEALS_LIST_PAGE;
	};

	setIsOpenActionsContextMenu = event => {
		this.setState({ isOpenActionsContextMenu: Boolean(event) });
		this.setState({ menuRef: event.currentTarget ? event.currentTarget : event });
		if (event) {
			let contextMenuList = this.state.contextMenuList.map(action => {
			  return { ...action, isDisable: this.props.isActionDisabled(action.key) }
			})
			this.setState({ contextMenuList })
		  }
	}

	setIsOpenActionsButtonContextMenu = event => {
		this.setState({ isOpenActions: Boolean(event) });
		this.setState({ actionMenuRef: event.currentTarget ? event.currentTarget : event });
		if (event) {
			let actionList = this.state.actionList.map(action => {
			  return { ...action, isDisable: this.props.isActionDisabled(action.key) }
			})
			this.setState({ actionList })
		  }
	}

	onClickDownArrow() {
		const { rowIndex, totalCount } = this.props;
		this.props.handleDealHeaderLeftArrowClick(rowIndex, totalCount);
	}

	onClickUpArrow() {
		const { rowIndex, totalCount } = this.props;
		this.props.handleDealHeaderRightArrowClick(rowIndex, totalCount);
	}
	handleActionSelection = action => {
		switch (action) {
			case "modelDeal":
				this.props.handleModelDeal(true)
				break;
			case "manageItems":
				this.props.handleManageItems(true)
				break;
			case 'applyChangestoItems':
				this.props.handleApplyChangestoItems(true);
				break;
		}
	};
	setIsActionClose = () => {
		this.setState({ isOpenActions: false });
	};
	render() {
		const { classes, dealData, handleDealHeaderFilterClick, handleDealHeaderSaveClick,
			saveDisabled, handleDealHeaderActionItemSelection, setSaveData, globalDateFormat, filterCriteriaDetails, pageFilterOptions,
			globalFilterOptions, columnDefs, currentPage, valuesArray, parentPage, headerFieldJson, rowIndex,
			isShowContextMenu, selectedValue, removeChildCutdownTab, vendorData,
			contextMenu, onContextMenuChange, fromListPage, dealPropertiesPage, tab, canUpdateComponent, notesCount, freezeComponentStyle } = this.props;
		const { valueData } = dealPropertiesPage;
		const creationdate = valueData && valueData['DHBRDT'] && getDateFormatted(getDateFromJulian(valueData['DHBRDT']), globalDateFormat);//E3C-32964, J Vamshi
		let menuactionList = [...CONTEXT_MENU_HEADER_DEAL_ACTIONS]
		menuactionList[2].isDisable = tab == 0 ? false : true

		return (
			<div className={classes.propertiesHeaderContainer} style={freezeComponentStyle}>
				<div className={classes.boookingDetailContainer}>
					<Box className={classes.boookingDetailDetailsWrapper}>
						<Box className={classes.bookingArrowWrapper}>
							<Button color="primary" onClick={() => this.onClickUpArrow()} className={classes.boookingArrow} disabled={this.handleDisableUpArrow()}>
								<KeyboardArrowUpIcon />
							</Button>
							<Button color="primary" onClick={() => this.onClickDownArrow()} className={classes.boookingArrow} disabled={this.handleDisableDownArrow()}>
								<KeyboardArrowDownIcon />
							</Button>
						</Box>
						<Box className={classes.vendorDetailRow}>
							<div className={classes.vendorIDSubID}>
								<div className={classes.vendorDetail}>
									<div className={classes.vendorIDBlock}>
										<div className={`${classes.vendorDetail} ${classes.vendorIdDetails}`}>
											<div className={classes.vendorLabel}>
												{this.getLabelValue(LABEL_VENDOR_ID)}
											</div>
											<div> {dealData && dealData.length && dealData[0]['DHVNDR']}</div>
										</div>
									</div>
								</div>
								<div className={`${classes.vendorName} ${classes.nameField}`}>
									<div className={`${classes.vendorLabel}`}>
										{this.getLabelValue(LABEL_VENDOR_NAME)}
									</div>
									<div> {vendorData && vendorData['VNAME']}</div>
								</div>
							</div>
							<div className={classes.IdNameBlock}>
								<div className={classes.vendorDetail}>
									<div className={classes.vendorLabel}> {this.getLabelValue(LABEL_WAREHOUSE_ID)} </div>
									<div className={classes.vendorValue}>{dealData && dealData.length && dealData[0]['DHWHSE']}</div>
								</div>
							</div>
							<div className={classes.IdNameBlock}>
								<div className={classes.vendorDetail}>
									<div className={classes.vendorLabel}> {this.getLabelValue(LABEL_DEAL)} </div>
									<div className={classes.vendorValue}>{dealData && dealData.length && dealData[0]['DHDEAL']}</div>
								</div>
								<div className={`${classes.vendorDetail} ${classes.nameField}`}>
									<div className={classes.vendorLabel}>{this.getLabelValue(LABEL_DEAL_CREATION_DATE)}</div>
									<div className={classes.vendorValue}>{creationdate}</div>
								</div>
							</div>
						</Box>
						<Box className={classes.bookingActions}>
							<div className={classes.buttonActions}>
								<div className={classes.buttonActionsSecondChild}
									onClick={(event) => this.setIsOpenActionsButtonContextMenu(event)}
									onMouseLeave={(event) => this.setIsOpenActionsButtonContextMenu(false)}>
									<Button color="primary" size="small" variant="outlined" className={classes.vendorArrow} /* disabled={this.handleDisableDownArrow()} */>
										<div>{this.getLabelValue(LABEL_ACTIONS)}</div>
										<KeyboardArrowDownIcon />
									</Button>
									<ContextMenu
										className={classes.ActionsContextMenu}
										menuList={this.state.actionList}
										isOpen={this.state.isOpenActions}
										menuRef={this.state.actionMenuRef}
										handleItemSelection={(val) => this.handleActionSelection(val)}
										handleMenuClose={(val) => this.setIsActionClose(val)}>
									</ContextMenu>
								</div>

								<div className={isShowContextMenu || true ? 'showContextMenu' : 'hideContextMenu'}>
									<BreadcrumbContextMenu
										onOptionChange={(e, val) => onContextMenuChange(e, val)} menuItems={contextMenu}
										removeChildCutdownTab={removeChildCutdownTab}
										selectedValue={selectedValue} />
								</div>
							</div>
							<Button component="div" color="primary" onClick={handleDealHeaderFilterClick} className={classes.bookingActionsFilter}>
								<img src={FilterIcon} alt="Filter Icon" />
							</Button>
							<Button component="div" color="primary" onClick={handleDealHeaderSaveClick} disabled={saveDisabled} className={classes.bookingActionsFilter}>
								<SaveIcon fontSize="large" />
							</Button>
							<Box className={classes.menuButton}>
								<div
									onMouseEnter={(event) => this.setIsOpenActionsContextMenu(event)}
									onMouseLeave={(event) => this.setIsOpenActionsContextMenu(false)}>
									<MoreVertIcon color="primary" className="cPointer"></MoreVertIcon>
									{/* //~~~CreateNewFramework--JVK */}
									<ContextMenuCreateNew
										className={classes.ActionsContextMenu}
										menuList={this.state.contextMenuList}
										isOpen={this.state.isOpenActionsContextMenu}
										menuRef={this.state.menuRef}
										handleItemSelection={(val) => handleDealHeaderActionItemSelection(val)}
										handleMenuClose={(val) => this.setIsOpenActionsContextMenu(val)}
										currentPage={currentPage}
										currentRecord={valueData}
										>
									</ContextMenuCreateNew>
									{/* //~~~CreateNewFramework--JVK */}
								</div>
							</Box>
						</Box>
						<Box className={classes.DealReferences}>
							<Button component="div" color="primary" size="small" onClick={e => { document.getElementById("dealNotes").scrollIntoView(); }}>
								{this.getLabelValue(LABEL_NOTE)}
							</Button>
							<Badge color="error" overlap="circle" anchorOrigin={{ vertical: "top", horizontal: "right" }} max={BADGE_MAX_COUNT} badgeContent={notesCount}>
							</Badge>
						</Box>
					</Box>
				</div>
			</div>
		);
	}
}

export default compose(
	withStyles(style),
)(withFixedPosition(Header));

/*
* * //==========================================================================
*
* * // Copyright 2021-2021, Blue Yonder Group, Inc.
*
* * // All Rights Reserved
*
* * //
*
* * // THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF
*
* * // BLUE YONDER GROUP, INC.
*
* * //
*
* * //
*
* * // The copyright notice above does not evidence any actual
*
* * // or intended publication of such source code.
*
* * //
*
* * // ===========================================================================
/* *******************************PATCH HISTORY******************************** */

/* E3C-33266 - SRK - AWR WEB UI graphs have hardcoded English labels
                     Removed hardcoding and retrieved label based on ID. 
                     (10-Nov-2021)
* * // ===========================================================================
*/

import React, { Component } from 'react';
import * as Highcharts from 'highcharts';
import more from 'highcharts/highcharts-more';
import HighchartsReact from 'highcharts-react-official';
more(Highcharts);
class ForecastGraph extends Component {
    constructor(props) {
        super(props);
        this.state = {
            options: {
                credits: {
                    enabled: false
                },
                legend: {
                    layout: 'vertical',
                    align: 'right',
                    verticalAlign: 'middle',
                },
                title: {
                    text: JSON.parse(localStorage["messageLabels"])["H25739"]["TLLAB"] /*E3C-33266 'Forecast History' */
                },
                yAxis: {
                    min: 0
                },
                xAxis: {
                   
                    categories:props.dates,
                    pointWidth:2
                },
               
                series: [{
                    name: JSON.parse(localStorage["messageLabels"])["H28365"]["TLLAB"] /*E3C-33266 'Expected Demand' */,
                    color:'#8E29BF',
                    trackByArea: true,
                    point: {
                    },
                    data: props.expectedDemand
                },
                 {
                    name: JSON.parse(localStorage["messageLabels"])["H28364"]["TLLAB"] /*E3C-33266 'Base Forecast' */, 
                     color:'#FBC02D',
                    data: props.baseForecast
                }
                    , {
                    name: JSON.parse(localStorage["messageLabels"])["H28366"]["TLLAB"] /*E3C-33266 'Actual Demand' */,                     
                    color:'#F2994A',
                        data: props.actualDemand
                }
                    , {
                    name: JSON.parse(localStorage["messageLabels"])["H28367"]["TLLAB"] /*E3C-33266 'Filtered Demand' */,                     
                    type:'line',
                        color:'#048bd0',
                    data: props.filteredDemand
                },{
                        type:'arearange',
                        color:'#52BE7F',
                        name: JSON.parse(localStorage["messageLabels"])["H28368"]["TLLAB"] /*E3C-33266 'Demand Filter Range' */,                     
                        data: props.demandFilterRange

                }
                ]
            }
        }
    }
    render() {
        return (
            <HighchartsReact
                options={this.state.options} />
        );
    }
}
export default ForecastGraph;